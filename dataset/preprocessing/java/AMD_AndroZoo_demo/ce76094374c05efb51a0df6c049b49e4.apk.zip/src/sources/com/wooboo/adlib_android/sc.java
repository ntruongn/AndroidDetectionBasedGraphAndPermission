package com.wooboo.adlib_android;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Pattern;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class sc {
    private static int A;
    public static boolean C;
    private static TelephonyManager b;
    private static boolean c;
    private static String d;
    private static String e;
    private static int f;
    protected static long l;
    private static int[] q;
    private static int r;
    private static String s;
    private static String t;
    private static final String[] D = {z(z("]O{\u001eF")), z(z("\\Y9")), z(z("\u0003\u0018\u007f\u0003")), z(z("\u0014\u000ea\u0012W\u0019\u00155I\u001d\u001a\f|I[\u0019\u0003`\u001e")), z(z("\u0016\u0005k\u0014W\u0004\u0012")), z(z("X\u0000k\u0002@")), z(z("\u0014\u000ea\u0012W\u0019\u00155I\u001d\u001a\f|I")), z(z("(\bk")), z(z("\u001f\u0015{\u0016\bXN>V\u001cGO?H\u0003@S \u0012W")), z(z("\u001f\u0015{\u0016\bXNn\u0002WY\u0016`\tP\u0018\u000e!\u0005]\u001aOl\b\u001d\u0003\u0004 \u0015")), z(z("\"5IK\n")), z(z("%\u0004~\u0013W\u0004\u0015/\u0003\\\u0013[")), z(z("4\u000ea\u0012W\u0019\u0015\"*W\u0019\u0006{\u000e")), z(z("/L@\b^\u001e\u000fjKz\u0018\u0012{")), z(z("4\u000ez\nVW\u000f`\u0012\u0012\u0014\r`\u0015WW\u0012{\u0014W\u0016\f")), z(z("\u001f\u0015{\u0016\bXNn\u0002WY\u0016`\tP\u0018\u000e!\u0005]\u001aOl\b\u001d\u0007\u0004")), z(z("4\u000ea\u0012W\u0019\u0015\"2K\u0007\u0004")), z(z("\u001f\u0015{\u0016\bXN>V\u001cGO?H\u0003@S \u0016WX\u0012")), z(z("W\u00115")), z(z("\u0016\u0011\u007f\n[\u0014\u0000{\u000f]\u0019NwKE\u0000\u0016\"\u0000]\u0005\f\"\u0013@\u001b\u0004a\u0005]\u0013\u0004k")), z(z("\u0007P!W\nN\u0016`\u0014Y\u0004Ol\t_")), z(z("%\u0004~\u0013W\u0004\u00155")), z(z("'.\\2")), z(z("\u0002\u0015iK\n")), z(z("\u0016\u0005jHE\u0018\u000em\t]Y\u0002`\u000b\u001c\u0014\u000f")), z(z("\u001f\u0015{\u0016\bXN>V\u001cGO?H\u0003@S \u0016W")), z(z("4\u0000a\b]\u0003A}\u0003C\u0002\u0004|\u0012\u0012\u0016\u000f/\u0007VW\u0016f\u0012Z\u0018\u0014{F{\u0019\u0015j\u0014\\\u0012\u0015/\u0016W\u0005\ff\u0015A\u001e\u000ea\u0015\u0013WA@\u0016W\u0019Ab\u0007\\\u001e\u0007j\u0015FY\u0019b\n\u0012\u0016\u000fkFX\u0002\u0012{FP\u0012\u0007`\u0014WW\u0015g\u0003\u0012\u0011\ba\u0007^W] \u000bS\u0019\bi\u0003A\u0003_/\u0012S\u0010An\u0002VMA/ZG\u0004\u0004|KB\u0012\u0013b\u000fA\u0004\b`\b\u0012\u0016\u000fk\u0014]\u001e\u00055\bS\u001a\u00042DS\u0019\u0005}\t[\u0013O\u007f\u0003@\u001a\b|\u0015[\u0018\u000f!/|#$](w#C/I\f")), z(z("\u0004\u0004a\u0002`\u0012\u0010z\u0003A\u0003[")), z(z("4\u000ez\nVW\u000f`\u0012\u0012\u001b\ba\r\u0012\u0004\u0004}\u0010W\u0005")), z(z("W\u0014}\n\u0012")), z(z("\u0012[")), z(z("\u0016\u000fk\u0014]\u001e\u0005!\u0016W\u0005\ff\u0015A\u001e\u000eaH{95J4|25")), z(z("W\u00045")), z(z("\u0000>f\u0002")), z(z("\u0016\u0015")), z(z("\u00005f\u000bW")), z(z("\u0000\bk")), z(z("4%B'")), z(z("\u0003\u0018\u007f\u0003|\u0016\fjK\f")), z(z("\u0016\u000fk\u0014]\u001e\u0005!\u0016W\u0005\ff\u0015A\u001e\u000eaHs4\"J5a(/J2e83D9a# [#")), z(z(":.M/~2")), z(z("\u0002\u000ff\u0011S\u0007")), z(z("@V8")), z(z("\u001e\u000f{\u0003@\u0019\u0004{")), z(z("D\u0006a\u0003F")), z(z("\u0002\u000ff\bW\u0003")), z(z("\u0014\fa\u0003F")), z(z("D\u0006x\u0007B")), z(z(" \"K+s")), z(z("\u0014\fx\u0007B")), z(z("\u0014\u000ea\bW\u0014\u0015f\u0010[\u0003\u0018")), z(z(" (I/")), z(z("\u0003\u0018\u007f\u0003|\u0016\fjK\fF")), z(z("\u0012\u0013}\t@")), z(z("GQ?")), z(z("FR")), z(z("EP")), z(z("FX")), z(z("EQ")), z(z("ES")), z(z("FU")), z(z("FS")), z(z("FW")), z(z("FQ")), z(z("\u0015\u0014f\nV\u0007\u0000}\u0007_\u0004\u0015}\u000f\\\u0010Ai\u0007[\u001b\u0004k")), z(z("FV")), z(z("FY")), z(z("ER")), z(z("\u0018\u000f")), z(z("FP")), z(z("\u0004\u000e")), z(z("FT")), z(z("EU")), z(z("\u0016\u000fk\u0014]\u001e\u0005P\u000fV")), z(z("GQ?V\u0002GQ?")), z(z(",QRL")), z(z("\u0007\u000f")), z(z("\u0004\u0005d")), z(z("Q\u0012k\r\u000fEO=")), z(z("\u0002\bk")), z(z("EO=")), z(z("\u001a\u0015")), z(z("Q\u0000\u007f\b\u000f")), z(z("\u0007\b{")), z(z("\u0004\bb")), z(z("\u001a\b")), z(z("\u0007\bk")), z(z("\u0002\u00112")), z(z("\u0007\bk[")), z(z("Q\u0011f\u0002\u000f")), z(z("\u0014\u000f|")), z(z("\u0007\u000fn\u000bW")), z(z("\u0012\u000f2")), z(z("\u0007\rn\u0012")), z(z("4.A {04]'f>.AFw%3@4\bWAF\bQ\u0018\u0013}\u0003Q\u0003AX\t]\u0015\u000e`9b>%!F\u0012$\t`\u0013^\u0013A<T\u0012,\u0000\"\u001c\u001eGL6;\u0012\u0014\tn\u0014S\u0014\u0015j\u0014AMA/")), z(z(".\u000ez\u0014\u0012 \u000e`\u0004]\u0018>_/vW\b|F")), z(z("\u0004\u0004{FB\u001e\u0005")), z(z(".\u000ez\u0014\u0012#\u0004c\u0003S\u0013>_/vW\b|F")), z(z("4.A {04]'f>.AFw%3@4\bWAF\bQ\u0018\u0013}\u0003Q\u0003A[\u0003^\u0012\u0000k9b>%!F\u0012$\t`\u0013^\u0013A<T\u0012,\u0000\"\u001c\u001eGL6;\u0012\u0014\tn\u0014S\u0014\u0015j\u0014AMA/")), z(z("3$\\%@\u000e\u0011{\t\u0012\u0012\u0019l\u0003B\u0003\b`\b\b")), z(z("X\u0002d")), z(z("X\u0016`")), z(z("X\u0016")), z(z("X\u0002n")), z(z("X\u0016l")), z(z("X\u0002f")), z(z("X\u0014\u007f\u0002")), z(z("X\u0012")), z(z("X\u0002")), z(z("\u001e\u0012`K\nOT6K\u0003")), z(z("4\u000ez\nVW\u000f`\u0012\u0012\u0013\u0004{\u0003@\u001a\ba\u0003\u0012\u0011\ba\u0007^W\u0002c\u000fQ\u001cAk\u0003A\u0003\ba\u0007F\u001e\u000eaFg%-!F\u0012 \bc\n\u0012\u0003\u0013vFF\u0018Ai\t^\u001b\u000exFS\u0019\u0018x\u0007KYA/")), z(z(":\u0000c\u0000]\u0005\fj\u0002\u0012\u0014\rf\u0005YW4]*\u001cWAX\u000f^\u001bA{\u0014KW\u0015`FT\u0018\rc\tEW\u0000a\u001fE\u0016\u0018!")), z(z("\u0005\u0004~\u0013W\u0004\u0015L\n[\u0014\nZ4~M")), z(z("FQ!V\u001cGO>Q\u0000")), z(z("\u0013\u0004")), z(z("\u001c\u000e")), z(z("\u0005\u0014")), z(z("\u001d\u0000")), z(z("\u001e\u0015")), z(z("\r\t")), z(z("\u0011\u0013")), z(z("\u0012\u0012")), z(z("\u0012\u000f")), z(z("\u001a\r")), z(z("\u0015\u0012")), z(z("\u001b\u0000{\n\\\u0010")), z(z("\u0014\u0000k\u0015")), z(z("\u0004\u0016")), z(z("\u001e\u0007b")), z(z("\u001a\bk")), z(z("\u0019\u0015")), z(z("\u0005\u0013")), z(z("FO=")), z(z("\u001b\u000el")), z(z("\u0016\u0011a")), z(z("\u0014\u0012k\r")), z(z("\u0015\u0014f\nV'\u0000}\u0007_$\u0015}\u000f\\\u0010Ab\u000fVM")), z(z("\u0004\u0015")), z(z("\u0005\u0004~\u0013W\u0004\u0015N\u0002\u0012\u0011\ba\u0007^\u001b\u0018/\bG\u001b\r")), z(z("\u001f\u0015{\u0016\bXN>V\u001cGO?H\u0003@S \u0012WX\u0012 ")), z(z("\u001e\u0014}\n")), z(z("\u0002\u0013c")), z(z("\u0016\u0005\\\u0003Q\u0018\u000fkK\f")), z(z("6\u0005B\u0003F\u0016[")), z(z("\u0005\u0004~\u0013W\u0004\u0015N\u0002\u0012\u0019\u0014c\n")), z(z("0\u0004{FV\u0016\u0015nFT\u001b\u000exFA\u001e\u001bjF[\u0004A?")), z(z("4\u000ez\nVW\u000f`\u0012\u0012\u0010\u0004{FS\u0013Ai\u0014]\u001aA\\\u0003@\u0001\u0004}")), z(z("\u0003\bb\u0003\u001fI")), z(z("\u001e\u0005")), z(z("Q\u0011c\u0007FJV")), z(z("\u0007\u0015")), z(z("\u0016\u0011\u007f\u000fV")), z(z("\u0016\u0013j\u0007[\u0013")), z(z("\u0016\u0005[\u0003J\u0003L1")), z(z("\u001e\fhK\f")), z(z("\u0007\b{[")), z(z("\u0016\u0005[\u001fB\u0012L1")), z(z("Q\u0011c\u0007FJP")), z(z("\u000b:r")), z(z("0\u0004{FS\u0019An\u0002\u0012\u0011\u0013`\u000b\u0012 \u000e`\u0004]\u0018A|\u0003@\u0001\u0004}\u0015")), z(z("\u0016\u0005@\u0004XY\u0006j\u0012~\u0018\u000fhFS\u0005\u0004n\u000fVW")), z(z("\u0016\u0005@\u0004XY\u0006j\u0012~\u0018\u000fhF_\u001e\u0005/")), z(z("\u0016\u0005@\u0004XY\u0006j\u0012~\u0018\u000fhFS\u0007\u0011f\u0002\u0012")), z(z("Y\u0000\u007f\r")), z(z("\u0016\u0011\u007f\n[\u0014\u0000{\u000f]\u0019On\u0016Y")), z(z("\u0004\u0004l-W\u000e")), z(z("讀氣寉铃夃赒｠")), z(z("\u0007\t`\bW")), z(z("\u0010\u0004{FQ\u0019\u0012/\u0000@\u0018\f/\u0002PW[")), z(z("OQ?V\u0002GQ?V\u0002GQ?V\u0002")), z(z("\u0004\u0000y\u0003\u0012\u0014\u000f|FF\u0018Ak\u0004\u0012M")), z(z("\u0014\u000f|\\\nGQ?V\u0002GQ?V\u0002GQ?V")), z(z("4\u000ez\nVW\u000f`\u0012\u0012\u0005\u0004n\u0002\u0012#\u0004c\u0003S\u0013>_/vW\fj\u0012SZ\u0005n\u0012SW\u0007}\t_W a\u0002@\u0018\bk+S\u0019\bi\u0003A\u0003Ow\u000b^Y")), z(z("4\u000ez\nVW\u000f`\u0012\u0012\u0005\u0004n\u0002\u0012 \u000e`\u0004]\u0018>_/vW\fj\u0012SZ\u0005n\u0012SW\u0007}\t_W a\u0002@\u0018\bk+S\u0019\bi\u0003A\u0003Ow\u000b^Y")), z(z(" \u000e`\u0004]\u0018>_/v")), z(z("\"\u0012jFF\u001f\u0004/\u0002W\u0011\u0000z\nFW,n\u0014Y\u0012\u0015P/vW\b|F")), z(z("#\tjF\u007f\u0016\u0013d\u0003F((KF[\u0004A|\u0003FW\u0015`F")), z(z("4\u000ez\nVW\u000f`\u0012\u0012\u0005\u0004n\u0002\u0012:\u0000}\rW\u0003>F\"\u0012\u001a\u0004{\u0007\u001f\u0013\u0000{\u0007\u0012\u0011\u0013`\u000b\u00126\u000fk\u0014]\u001e\u0005B\u0007\\\u001e\u0007j\u0015FY\u0019b\n\u001c")), z(z(":\u0000}\rW\u0003>F\""))};
    protected static boolean a = true;
    protected static volatile int g = 1;
    private static String h = null;
    private static Context i = null;
    private static String j = null;
    private static String k = null;
    private static int m = 0;
    protected static boolean n = true;
    private static String o = "";
    private static String p = null;
    private static String u = z(z("FXd\rm)B6!"));
    private static String v = z(z("N\u000bg\u000eV\u001c\u0015j\u0002mF\u0007"));
    private static String w = null;
    private static String x = null;
    private static String y = D[54];
    private static String z = null;
    private static int B = -2;

    public static int a() {
        return A;
    }

    public static int a(String str, String str2) {
        if (str == null) {
            return -1;
        }
        if (str2 == null) {
            return 1;
        }
        try {
            if (Long.valueOf(str).longValue() == Long.valueOf(str2).longValue()) {
                return 0;
            }
            try {
                return Long.valueOf(str).longValue() <= Long.valueOf(str2).longValue() ? 1 : -1;
            } catch (IllegalArgumentException e2) {
                throw e2;
            }
        } catch (IllegalArgumentException e3) {
            throw e3;
        }
    }

    public static fc a(fc fcVar, fc fcVar2) {
        try {
            Iterator a2 = fcVar2.a();
            while (a2.hasNext()) {
                String str = (String) a2.next();
                fcVar.c(str, fcVar2.h(str));
            }
        } catch (Exception e2) {
        }
        return fcVar;
    }

    protected static fc a(fc fcVar, String str) {
        try {
        } catch (o e2) {
            e2.printStackTrace();
            mc.c(D[64]);
        }
        if (str == null) {
            try {
                fcVar.c(D[70], "");
            } catch (IllegalArgumentException e3) {
                throw e3;
            }
        } else {
            int length = str.length();
            if (length >= 6) {
                String substring = str.substring(4, 6);
                try {
                    try {
                        try {
                            if (substring.endsWith("0") || substring.endsWith("2") || substring.endsWith("7")) {
                                fcVar.c(D[68], "5");
                                if (length >= 7) {
                                    String substring2 = str.substring(6, 7);
                                    try {
                                        if (substring2.equals("0")) {
                                            fcVar.c(D[70], "0");
                                        } else {
                                            try {
                                                if ("1".equals(substring2)) {
                                                    fcVar.c(D[70], "1");
                                                } else {
                                                    try {
                                                        if ("2".equals(substring2)) {
                                                            fcVar.c(D[70], "2");
                                                        } else {
                                                            try {
                                                                if ("3".equals(substring2)) {
                                                                    fcVar.c(D[70], "3");
                                                                } else {
                                                                    try {
                                                                        if ("4".equals(substring2)) {
                                                                            fcVar.c(D[70], "4");
                                                                        } else {
                                                                            try {
                                                                                if ("5".equals(substring2)) {
                                                                                    fcVar.c(D[70], "5");
                                                                                } else {
                                                                                    try {
                                                                                        if ("6".equals(substring2)) {
                                                                                            fcVar.c(D[70], "6");
                                                                                        } else {
                                                                                            try {
                                                                                                if ("7".equals(substring2)) {
                                                                                                    fcVar.c(D[70], "7");
                                                                                                } else {
                                                                                                    try {
                                                                                                        if ("8".equals(substring2)) {
                                                                                                            fcVar.c(D[70], "8");
                                                                                                        } else {
                                                                                                            try {
                                                                                                                if ("9".equals(substring2)) {
                                                                                                                    fcVar.c(D[70], "9");
                                                                                                                } else {
                                                                                                                    try {
                                                                                                                        if ("A".equals(substring2)) {
                                                                                                                            fcVar.c(D[70], D[63]);
                                                                                                                        } else {
                                                                                                                            try {
                                                                                                                                if ("B".equals(substring2)) {
                                                                                                                                    fcVar.c(D[70], D[69]);
                                                                                                                                } else {
                                                                                                                                    try {
                                                                                                                                        if ("C".equals(substring2)) {
                                                                                                                                            fcVar.c(D[70], D[61]);
                                                                                                                                        } else {
                                                                                                                                            try {
                                                                                                                                                if ("D".equals(substring2)) {
                                                                                                                                                    fcVar.c(D[70], D[55]);
                                                                                                                                                } else {
                                                                                                                                                    try {
                                                                                                                                                        if ("E".equals(substring2)) {
                                                                                                                                                            fcVar.c(D[70], D[60]);
                                                                                                                                                        }
                                                                                                                                                    } catch (o e4) {
                                                                                                                                                        throw e4;
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            } catch (o e5) {
                                                                                                                                                throw e5;
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    } catch (o e6) {
                                                                                                                                        throw e6;
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            } catch (o e7) {
                                                                                                                                throw e7;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    } catch (o e8) {
                                                                                                                        throw e8;
                                                                                                                    }
                                                                                                                }
                                                                                                            } catch (o e9) {
                                                                                                                throw e9;
                                                                                                            }
                                                                                                        }
                                                                                                    } catch (o e10) {
                                                                                                        throw e10;
                                                                                                    }
                                                                                                }
                                                                                            } catch (o e11) {
                                                                                                throw e11;
                                                                                            }
                                                                                        }
                                                                                    } catch (o e12) {
                                                                                        throw e12;
                                                                                    }
                                                                                }
                                                                            } catch (o e13) {
                                                                                throw e13;
                                                                            }
                                                                        }
                                                                    } catch (o e14) {
                                                                        throw e14;
                                                                    }
                                                                }
                                                            } catch (o e15) {
                                                                throw e15;
                                                            }
                                                        }
                                                    } catch (o e16) {
                                                        throw e16;
                                                    }
                                                }
                                            } catch (o e17) {
                                                throw e17;
                                            }
                                        }
                                    } catch (o e18) {
                                        throw e18;
                                    }
                                }
                            } else {
                                try {
                                    if (substring.endsWith("1")) {
                                        fcVar.c(D[68], D[69]);
                                        if (length >= 9) {
                                            String substring3 = str.substring(8, 9);
                                            try {
                                                if ("0".equals(substring3)) {
                                                    fcVar.c(D[70], D[72]);
                                                } else {
                                                    try {
                                                        if ("1".equals(substring3)) {
                                                            fcVar.c(D[70], D[71]);
                                                        } else {
                                                            try {
                                                                if ("2".equals(substring3)) {
                                                                    fcVar.c(D[70], D[62]);
                                                                } else {
                                                                    try {
                                                                        if ("5".equals(substring3)) {
                                                                            fcVar.c(D[70], D[57]);
                                                                        } else {
                                                                            try {
                                                                                if ("6".equals(substring3)) {
                                                                                    fcVar.c(D[70], D[58]);
                                                                                }
                                                                            } catch (o e19) {
                                                                                throw e19;
                                                                            }
                                                                        }
                                                                    } catch (o e20) {
                                                                        throw e20;
                                                                    }
                                                                }
                                                            } catch (o e21) {
                                                                throw e21;
                                                            }
                                                        }
                                                    } catch (o e22) {
                                                        throw e22;
                                                    }
                                                }
                                            } catch (o e23) {
                                                throw e23;
                                            }
                                        }
                                    } else {
                                        try {
                                            if (substring.endsWith("3")) {
                                                fcVar.c(D[68], D[61]);
                                                if (length >= 9) {
                                                    String substring4 = str.substring(8, 9);
                                                    try {
                                                        if ("3".equals(substring4)) {
                                                            fcVar.c(D[70], D[65]);
                                                        } else {
                                                            try {
                                                                if ("4".equals(substring4)) {
                                                                    fcVar.c(D[70], D[66]);
                                                                } else {
                                                                    try {
                                                                        if ("7".equals(substring4)) {
                                                                            fcVar.c(D[70], D[56]);
                                                                        } else {
                                                                            try {
                                                                                if ("8".equals(substring4)) {
                                                                                    fcVar.c(D[70], D[59]);
                                                                                } else if ("9".equals(substring4)) {
                                                                                    fcVar.c(D[70], D[67]);
                                                                                }
                                                                            } catch (o e24) {
                                                                                throw e24;
                                                                            }
                                                                        }
                                                                    } catch (o e25) {
                                                                        throw e25;
                                                                    }
                                                                }
                                                            } catch (o e26) {
                                                                throw e26;
                                                            }
                                                        }
                                                    } catch (o e27) {
                                                        throw e27;
                                                    }
                                                }
                                            }
                                        } catch (o e28) {
                                            throw e28;
                                        }
                                    }
                                } catch (o e29) {
                                    throw e29;
                                }
                            }
                        } catch (o e30) {
                            throw e30;
                        }
                    } catch (o e31) {
                        throw e31;
                    }
                } catch (o e32) {
                    throw e32;
                }
                e2.printStackTrace();
                mc.c(D[64]);
            }
        }
        return fcVar;
    }

    public static String a(Context context, int i2, fc fcVar, boolean z2) {
        HashMap hashMap = new HashMap();
        Iterator a2 = fcVar.a();
        while (a2.hasNext()) {
            try {
                String str = ((String) a2.next()).toString();
                try {
                    hashMap.put(str, fcVar.h(str));
                } catch (o e2) {
                }
            } catch (o e3) {
                throw e3;
            }
        }
        return a(context, i2, hashMap, z2);
    }

    public static String a(Context context, int i2, HashMap hashMap) {
        return a(context, i2, hashMap, true);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to find 'out' block for switch in B:16:0x0051. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0078 A[Catch: Exception -> 0x040f, TRY_LEAVE, TryCatch #0 {Exception -> 0x040f, blocks: (B:24:0x0054, B:26:0x0078), top: B:23:0x0054 }] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0411  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String a(android.content.Context r5, int r6, java.util.HashMap r7, boolean r8) {
        /*
            Method dump skipped, instructions count: 1106
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.sc.a(android.content.Context, int, java.util.HashMap, boolean):java.lang.String");
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x0008, code lost:
    
        if (r4.length() == 0) goto L6;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String a(android.content.Context r3, java.lang.String r4) {
        /*
            r1 = 0
            r2 = 0
            if (r4 == 0) goto La
            int r0 = r4.length()     // Catch: java.lang.IllegalArgumentException -> L2c
            if (r0 != 0) goto L13
        La:
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            java.lang.String r4 = a(r3, r2, r0)
        L13:
            java.lang.String r0 = ""
            boolean r0 = com.wooboo.download.h.d(r3)     // Catch: java.lang.IllegalArgumentException -> L2e
            if (r0 == 0) goto L3d
            java.lang.String r0 = b(r2)
            java.lang.String r0 = c(r3, r0, r4)
            if (r0 == 0) goto L32
            int r2 = r0.length()     // Catch: java.lang.IllegalArgumentException -> L30
            if (r2 <= 0) goto L32
        L2b:
            return r0
        L2c:
            r0 = move-exception
            throw r0
        L2e:
            r0 = move-exception
            throw r0
        L30:
            r0 = move-exception
            throw r0
        L32:
            java.lang.String[] r0 = com.wooboo.adlib_android.sc.D
            r2 = 166(0xa6, float:2.33E-43)
            r0 = r0[r2]
            com.wooboo.adlib_android.mc.c(r0)
            r0 = r1
            goto L2b
        L3d:
            r0 = r1
            goto L2b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.sc.a(android.content.Context, java.lang.String):java.lang.String");
    }

    public static String a(Context context, String str, String str2) {
        String a2 = a(context, false, str2);
        if (a2 == null) {
            return null;
        }
        return ob.b(str, a2);
    }

    public static String a(Context context, boolean z2) {
        return a(context, z2, (String) null);
    }

    public static String a(Context context, boolean z2, String str) {
        if (!z2) {
            try {
                if (x != null) {
                    return x;
                }
                HashMap j2 = pc.a(context, (String) null).j();
                try {
                    if (j2.containsKey(D[165])) {
                        return (String) j2.get(D[165]);
                    }
                } catch (IllegalArgumentException e2) {
                    throw e2;
                }
            } catch (IllegalArgumentException e3) {
                throw e3;
            }
        }
        try {
            x = a(context, str);
            if (x != null) {
                String str2 = x;
                x = String.valueOf(str2.substring(0, 4)) + str2.substring(12);
                pc.a(context, (String) null).d(D[165], x);
            }
            return x;
        } catch (IllegalArgumentException e4) {
            throw e4;
        }
    }

    public static String a(String str) {
        int indexOf = str.toLowerCase().indexOf(D[163]);
        if (indexOf == -1) {
            return D[164];
        }
        int lastIndexOf = str.toLowerCase().lastIndexOf("/", indexOf);
        return lastIndexOf == -1 ? str : str.substring(lastIndexOf + 1, indexOf + 4);
    }

    public static String a(String str, HashMap hashMap) {
        if (hashMap != null) {
            try {
                if (hashMap.size() != 0) {
                    String str2 = String.valueOf(str) + "?";
                    boolean z2 = true;
                    for (Map.Entry entry : hashMap.entrySet()) {
                        try {
                            if (z2) {
                                z2 = false;
                            } else {
                                str2 = String.valueOf(str2) + "&";
                            }
                            z2 = z2;
                            str2 = String.valueOf(str2) + ((String) entry.getKey()) + "=" + ((String) entry.getValue());
                        } catch (IllegalArgumentException e2) {
                            throw e2;
                        }
                    }
                    return str2;
                }
            } catch (IllegalArgumentException e3) {
                throw e3;
            }
        }
        return str;
    }

    public static HashMap a(HashMap hashMap, fc fcVar) {
        try {
            Iterator a2 = fcVar.a();
            while (a2.hasNext()) {
                String str = (String) a2.next();
                hashMap.put(str, fcVar.h(str));
            }
        } catch (Exception e2) {
        }
        return hashMap;
    }

    public static void a(int i2) {
        A = i2;
    }

    private static void a(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e2) {
                mc.c(D[14]);
            } catch (IllegalArgumentException e3) {
                throw e3;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(boolean z2) {
        c = z2;
    }

    public static void a(int[] iArr) {
        q = iArr;
    }

    public static boolean a(Context context) {
        return false;
    }

    protected static int b() {
        return g;
    }

    public static int b(Context context, String str, String str2) {
        if (str != null) {
            try {
                try {
                    try {
                        if (str.length() != 0) {
                            try {
                                if (str.length() == 3 && str.equalsIgnoreCase(D[54])) {
                                    return a(context, true, str2) != null ? 0 : -1;
                                }
                                try {
                                    new fc(str);
                                    try {
                                        try {
                                            fc fcVar = new fc(str);
                                            try {
                                                if (fcVar.i(D[53])) {
                                                    return (!fcVar.h(D[53]).equalsIgnoreCase(y) || a(context, true) == null) ? -1 : 0;
                                                }
                                                return 1;
                                            } catch (Exception e2) {
                                                throw e2;
                                            }
                                        } catch (Exception e3) {
                                            throw e3;
                                        }
                                    } catch (o e4) {
                                        e4.printStackTrace();
                                        return -1;
                                    }
                                } catch (Exception e5) {
                                    return 1;
                                }
                            } catch (Exception e6) {
                                throw e6;
                            }
                        }
                    } catch (Exception e7) {
                        throw e7;
                    }
                } catch (Exception e8) {
                    throw e8;
                }
            } catch (Exception e9) {
                throw e9;
            }
        }
        return 1;
    }

    public static fc b(Context context) {
        int i2 = 0;
        while (com.wooboo.download.h.d(context) && i2 < 3) {
            try {
                i2++;
                String c2 = c(context, b(1), a(context, 1, new HashMap()));
                if (c2 != null && c2.length() > 0) {
                    int f2 = f(context, c2);
                    if (f2 == 1) {
                        try {
                            return new fc(c2);
                        } catch (o e2) {
                            e2.printStackTrace();
                            return null;
                        }
                    }
                    if (f2 == -1) {
                        return null;
                    }
                }
            } catch (o e3) {
                throw e3;
            }
        }
        return null;
    }

    public static String b(int i2) {
        switch (i2) {
            case 0:
                try {
                    return D[100];
                } catch (IllegalArgumentException e2) {
                    throw e2;
                }
            case 1:
                return D[102];
            case 2:
                return D[103];
            case nb.p /* 3 */:
                return D[105];
            case 4:
                return D[101];
            case 5:
                return D[107];
            case nb.s /* 6 */:
                return D[108];
            case nb.t /* 7 */:
                return D[104];
            case 8:
                return D[106];
            default:
                return "";
        }
    }

    public static String b(Context context, String str) {
        String c2 = c(str);
        HashMap b2 = b(str);
        if (!b2.containsKey(D[122])) {
            return str;
        }
        String e2 = e(context, (String) b2.get(D[122]));
        if (!e2.substring(e2.length() - 1).equalsIgnoreCase(",")) {
            e2 = String.valueOf(e2) + ",";
        }
        String[] split = e2.split(",");
        while (split.length < 27) {
            try {
                String str2 = String.valueOf(e2) + ",";
                e2 = str2;
                split = str2.split(",");
            } catch (IllegalArgumentException e3) {
                throw e3;
            }
        }
        if (!e2.substring(e2.length() - 1).equalsIgnoreCase(",")) {
            e2 = String.valueOf(e2) + ",";
        }
        b2.put(D[122], d(context, String.valueOf(e2) + c(context)));
        return a(c2, b2);
    }

    public static HashMap b(String str) {
        HashMap hashMap = new HashMap();
        if (!"".equals(str)) {
            for (String str2 : str.substring(str.indexOf(63) + 1).split("&")) {
                String[] split = str2.split("=");
                try {
                    if (split.length >= 2) {
                        hashMap.put(split[0], split[1]);
                    }
                } catch (IllegalArgumentException e2) {
                    throw e2;
                }
            }
        }
        return hashMap;
    }

    private static int c() {
        return m;
    }

    /* JADX WARN: Removed duplicated region for block: B:109:0x0180 A[Catch: Exception -> 0x0186, TRY_ENTER, TRY_LEAVE, TryCatch #17 {Exception -> 0x0186, blocks: (B:118:0x0176, B:109:0x0180, B:115:0x0185, B:112:0x017b), top: B:117:0x0176, inners: #20 }] */
    /* JADX WARN: Removed duplicated region for block: B:111:0x017b A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0176 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:124:0x0164 A[Catch: Exception -> 0x016f, TryCatch #1 {Exception -> 0x016f, blocks: (B:129:0x015f, B:124:0x0164, B:126:0x0169), top: B:128:0x015f }] */
    /* JADX WARN: Removed duplicated region for block: B:126:0x0169 A[Catch: Exception -> 0x016f, TRY_LEAVE, TryCatch #1 {Exception -> 0x016f, blocks: (B:129:0x015f, B:124:0x0164, B:126:0x0169), top: B:128:0x015f }] */
    /* JADX WARN: Removed duplicated region for block: B:128:0x015f A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x01ca A[ADDED_TO_REGION, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:96:0x0089 A[Catch: Exception -> 0x01b3, TryCatch #9 {Exception -> 0x01b3, blocks: (B:100:0x0084, B:96:0x0089, B:98:0x008e), top: B:99:0x0084 }] */
    /* JADX WARN: Removed duplicated region for block: B:98:0x008e A[Catch: Exception -> 0x01b3, TRY_LEAVE, TryCatch #9 {Exception -> 0x01b3, blocks: (B:100:0x0084, B:96:0x0089, B:98:0x008e), top: B:99:0x0084 }] */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0084 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static com.wooboo.adlib_android.fc c(android.content.Context r12, java.lang.String r13) {
        /*
            Method dump skipped, instructions count: 470
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.sc.c(android.content.Context, java.lang.String):com.wooboo.adlib_android.fc");
    }

    public static String c(Context context) {
        try {
            if (w != null) {
                return w;
            }
            try {
                if (d(context)) {
                    return w;
                }
                return null;
            } catch (IllegalArgumentException e2) {
                throw e2;
            }
        } catch (IllegalArgumentException e3) {
            throw e3;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:104:0x00e6 A[Catch: Exception -> 0x0339, TRY_LEAVE, TryCatch #22 {Exception -> 0x0339, blocks: (B:101:0x00dc, B:104:0x00e6), top: B:100:0x00dc }] */
    /* JADX WARN: Removed duplicated region for block: B:117:0x010d A[Catch: Exception -> 0x0343, TRY_LEAVE, TryCatch #24 {Exception -> 0x0343, blocks: (B:114:0x0103, B:117:0x010d), top: B:113:0x0103 }] */
    /* JADX WARN: Type inference failed for: r0v20, types: [int] */
    /* JADX WARN: Type inference failed for: r3v14 */
    /* JADX WARN: Type inference failed for: r3v19 */
    /* JADX WARN: Type inference failed for: r3v30 */
    /* JADX WARN: Type inference failed for: r3v38 */
    /* JADX WARN: Type inference failed for: r4v10, types: [byte[]] */
    /* JADX WARN: Type inference failed for: r4v6, types: [byte[]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String c(android.content.Context r13, java.lang.String r14, java.lang.String r15) {
        /*
            Method dump skipped, instructions count: 892
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.sc.c(android.content.Context, java.lang.String, java.lang.String):java.lang.String");
    }

    public static String c(String str) {
        int indexOf;
        if (str == null) {
            return str;
        }
        try {
            return (str.length() <= 0 || (indexOf = str.indexOf("?")) == -1) ? str : str.substring(0, indexOf);
        } catch (IllegalArgumentException e2) {
            throw e2;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void c(int i2) {
        g = i2;
    }

    public static int d() {
        return r;
    }

    public static String d(Context context, String str) {
        String a2 = a(context, false, (String) null);
        if (a2 == null) {
            return null;
        }
        return ob.b(str, a2);
    }

    public static String d(String str) {
        if (str == null) {
            return str;
        }
        try {
            if (str.trim().length() == 0) {
                return str;
            }
            try {
                return pb.a(str, pb.a(u));
            } catch (Exception e2) {
                mc.c(D[99] + e2.getMessage());
                e2.printStackTrace();
                return str;
            }
        } catch (Exception e3) {
            throw e3;
        }
    }

    protected static void d(int i2) {
        m = i2;
    }

    public static boolean d(Context context) {
        pc a2 = pc.a(context, (String) null);
        HashMap j2 = a2.j();
        if (com.wooboo.download.h.a()) {
            pc a3 = pc.a(context, com.wooboo.download.h.b());
            HashMap j3 = a3.j();
            try {
                try {
                    if (j3.containsKey(D[33])) {
                        if (j2.containsKey(D[33])) {
                            int a4 = a((String) j3.get(D[35]), (String) j2.get(D[35]));
                            if (a4 == 1) {
                                a2.d(D[33], (String) j3.get(D[33]));
                                a2.d(D[35], (String) j3.get(D[35]));
                                j2.put(D[33], (String) j3.get(D[33]));
                                j2.put(D[35], (String) j3.get(D[35]));
                            } else if (a4 == -1) {
                                try {
                                    j3.put(D[33], (String) j2.get(D[33]));
                                    j3.put(D[35], (String) j2.get(D[35]));
                                    a3.d(D[33], (String) j2.get(D[33]));
                                    a3.d(D[35], (String) j2.get(D[35]));
                                } catch (o e2) {
                                    throw e2;
                                }
                            }
                        } else {
                            j2.put(D[33], (String) j3.get(D[33]));
                            j2.put(D[35], (String) j3.get(D[35]));
                            a2.d(D[33], (String) j3.get(D[33]));
                            a2.d(D[35], (String) j3.get(D[35]));
                        }
                    } else if (j2.containsKey(D[33])) {
                        j3.put(D[33], (String) j2.get(D[33]));
                        a3.d(D[35], (String) j2.get(D[35]));
                        a3.d(D[33], (String) j2.get(D[33]));
                    } else {
                        fc b2 = b(context);
                        if (b2 == null) {
                            return false;
                        }
                        try {
                            j3.put(D[33], b2.h(D[36]));
                            j2.put(D[33], b2.h(D[36]));
                            j3.put(D[35], b2.h(D[34]));
                            j2.put(D[35], b2.h(D[34]));
                            a2.d(D[33], b2.h(D[36]));
                            a2.d(D[35], b2.h(D[34]));
                            a3.d(D[33], b2.h(D[36]));
                            a3.d(D[35], b2.h(D[34]));
                        } catch (o e3) {
                        } catch (IllegalArgumentException e4) {
                            throw e4;
                        }
                    }
                } catch (o e5) {
                    throw e5;
                }
            } catch (o e6) {
                throw e6;
            }
        } else if (!j2.containsKey(D[33])) {
            fc b3 = b(context);
            if (b3 == null) {
                return false;
            }
            try {
                j2.put(D[33], b3.h(D[36]));
                j2.put(D[35], b3.h(D[34]));
                a2.d(D[33], b3.h(D[36]));
                a2.d(D[35], b3.h(D[34]));
            } catch (o e7) {
            } catch (IllegalArgumentException e8) {
                throw e8;
            }
        }
        w = (String) j2.get(D[33]);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int e(Context context) {
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
            if (applicationInfo != null) {
                int i2 = applicationInfo.metaData.getInt(D[178]);
                mc.a(D[176] + i2);
                return i2;
            }
        } catch (Exception e2) {
            mc.c(D[177]);
        }
        mc.a(D[175] + 1);
        return 1;
    }

    public static String e() {
        return o;
    }

    public static String e(Context context, String str) {
        return ob.a(str, a(context, false).trim());
    }

    public static String e(String str) {
        if (str == null) {
            return str;
        }
        try {
            if (str.trim().length() == 0) {
                return str;
            }
            try {
                return pb.b(str, pb.a(u));
            } catch (Exception e2) {
                mc.c(D[99] + e2.getMessage());
                e2.printStackTrace();
                return str;
            }
        } catch (Exception e3) {
            throw e3;
        }
    }

    public static void e(int i2) {
        r = i2;
    }

    public static int f(Context context, String str) {
        return b(context, str, null);
    }

    public static String f() {
        return p;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static String f(Context context) {
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
            if (applicationInfo != null) {
                return applicationInfo.metaData.getString(D[174]);
            }
            return null;
        } catch (Exception e2) {
            try {
                if (n) {
                    mc.c(D[173]);
                    return null;
                }
                mc.c(D[172]);
                return null;
            } catch (Exception e3) {
                throw e3;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void f(int i2) {
        f = i2;
    }

    public static void f(String str) {
        if (str != null) {
            try {
                if (str.trim().equals("")) {
                    return;
                }
                o = str;
            } catch (IllegalArgumentException e2) {
                throw e2;
            }
        }
    }

    protected static String g() {
        return k;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void g(int i2) {
        B = i2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void g(Context context) {
        try {
            i = context;
            b = (TelephonyManager) context.getSystemService(D[167]);
            if (h == null) {
                h = k();
            }
        } catch (IllegalArgumentException e2) {
            throw e2;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0008, code lost:
    
        if (r5.length() != 32) goto L6;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void g(android.content.Context r4, java.lang.String r5) {
        /*
            if (r5 == 0) goto La
            int r0 = r5.length()     // Catch: java.lang.IllegalArgumentException -> L6f
            r1 = 32
            if (r0 == r1) goto L24
        La:
            boolean r0 = com.wooboo.adlib_android.sc.n     // Catch: java.lang.IllegalArgumentException -> L71
            if (r0 == 0) goto L73
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch: java.lang.IllegalArgumentException -> L71
            java.lang.String[] r1 = com.wooboo.adlib_android.sc.D     // Catch: java.lang.IllegalArgumentException -> L71
            r2 = 94
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L71
            r0.<init>(r1)     // Catch: java.lang.IllegalArgumentException -> L71
            java.lang.StringBuilder r0 = r0.append(r5)     // Catch: java.lang.IllegalArgumentException -> L71
            java.lang.String r0 = r0.toString()     // Catch: java.lang.IllegalArgumentException -> L71
            j(r0)     // Catch: java.lang.IllegalArgumentException -> L71
        L24:
            boolean r0 = com.wooboo.adlib_android.sc.n     // Catch: java.lang.IllegalArgumentException -> L8a
            if (r0 == 0) goto L8c
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch: java.lang.IllegalArgumentException -> L8a
            java.lang.String[] r1 = com.wooboo.adlib_android.sc.D     // Catch: java.lang.IllegalArgumentException -> L8a
            r2 = 95
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L8a
            r0.<init>(r1)     // Catch: java.lang.IllegalArgumentException -> L8a
            java.lang.StringBuilder r0 = r0.append(r5)     // Catch: java.lang.IllegalArgumentException -> L8a
            java.lang.String r0 = r0.toString()     // Catch: java.lang.IllegalArgumentException -> L8a
            com.wooboo.adlib_android.mc.a(r0)     // Catch: java.lang.IllegalArgumentException -> L8a
        L3e:
            com.wooboo.adlib_android.sc.d = r5
            boolean r0 = l()
            if (r0 != 0) goto L6e
            r0 = 0
            com.wooboo.adlib_android.pc r0 = com.wooboo.adlib_android.pc.a(r4, r0)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String[] r2 = com.wooboo.adlib_android.sc.D
            r3 = 96
            r2 = r2[r3]
            r1.<init>(r2)
            java.lang.String r2 = com.wooboo.adlib_android.sc.d
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            com.wooboo.adlib_android.mc.c(r1)
            java.lang.String[] r1 = com.wooboo.adlib_android.sc.D
            r2 = 86
            r1 = r1[r2]
            java.lang.String r2 = com.wooboo.adlib_android.sc.d
            r0.d(r1, r2)
        L6e:
            return
        L6f:
            r0 = move-exception
            throw r0     // Catch: java.lang.IllegalArgumentException -> L71
        L71:
            r0 = move-exception
            throw r0
        L73:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String[] r1 = com.wooboo.adlib_android.sc.D
            r2 = 98
            r1 = r1[r2]
            r0.<init>(r1)
            java.lang.StringBuilder r0 = r0.append(r5)
            java.lang.String r0 = r0.toString()
            j(r0)
            goto L24
        L8a:
            r0 = move-exception
            throw r0
        L8c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String[] r1 = com.wooboo.adlib_android.sc.D
            r2 = 97
            r1 = r1[r2]
            r0.<init>(r1)
            java.lang.StringBuilder r0 = r0.append(r5)
            java.lang.String r0 = r0.toString()
            com.wooboo.adlib_android.mc.a(r0)
            goto L3e
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.sc.g(android.content.Context, java.lang.String):void");
    }

    public static void g(String str) {
        if (str != null) {
            try {
                if (str.trim().equals("")) {
                    return;
                }
                p = str;
            } catch (IllegalArgumentException e2) {
                throw e2;
            }
        }
    }

    protected static String h() {
        return j;
    }

    public static String h(int i2) {
        a(i2);
        String c2 = c(j(), b(8), a(j(), 8, new HashMap()));
        if (c2 != null) {
            try {
                if (c2.length() != 0) {
                    return c2;
                }
            } catch (IllegalArgumentException e2) {
                throw e2;
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0022, code lost:
    
        if (com.wooboo.adlib_android.sc.t.length() == 0) goto L57;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static java.lang.String h(android.content.Context r10) {
        /*
            Method dump skipped, instructions count: 239
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.sc.h(android.content.Context):java.lang.String");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void h(String str) {
        k = str;
    }

    protected static int i() {
        return f;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static String i(Context context) {
        String language = context.getResources().getConfiguration().locale.getLanguage();
        try {
            if (language.contains(D[122])) {
                return "2";
            }
            try {
                if (language.contains(D[119])) {
                    return "0";
                }
                try {
                    if (language.contains(D[115])) {
                        return "5";
                    }
                    try {
                        if (language.contains(D[120])) {
                            return "3";
                        }
                        try {
                            if (language.contains(D[121])) {
                                return "8";
                            }
                            try {
                                if (language.contains(D[114])) {
                                    return "6";
                                }
                                try {
                                    if (language.contains(D[118])) {
                                        return "7";
                                    }
                                    try {
                                        if (language.contains(D[117])) {
                                            return "4";
                                        }
                                        try {
                                            return language.contains(D[116]) ? "9" : "2";
                                        } catch (IllegalArgumentException e2) {
                                            throw e2;
                                        }
                                    } catch (IllegalArgumentException e3) {
                                        throw e3;
                                    }
                                } catch (IllegalArgumentException e4) {
                                    throw e4;
                                }
                            } catch (IllegalArgumentException e5) {
                                throw e5;
                            }
                        } catch (IllegalArgumentException e6) {
                            throw e6;
                        }
                    } catch (IllegalArgumentException e7) {
                        throw e7;
                    }
                } catch (IllegalArgumentException e8) {
                    throw e8;
                }
            } catch (IllegalArgumentException e9) {
                throw e9;
            }
        } catch (IllegalArgumentException e10) {
            throw e10;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void i(String str) {
        j = str;
    }

    public static Context j() {
        return i;
    }

    public static String j(Context context) {
        try {
            if (d == null) {
                if (!l()) {
                    d = (String) pc.a(context, (String) null).j().get(D[86]);
                }
            }
            return d;
        } catch (IllegalArgumentException e2) {
            throw e2;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void j(String str) {
        mc.c(str);
        throw new IllegalArgumentException(str);
    }

    private static String k() {
        try {
            if (b == null) {
                return null;
            }
            h = b.getSimSerialNumber();
            return h;
        } catch (IllegalArgumentException e2) {
            throw e2;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static String k(Context context) {
        String deviceId;
        try {
            if (b != null && (deviceId = b.getDeviceId()) != null) {
                try {
                    if (!deviceId.trim().equals("") && !Pattern.compile(D[75]).matcher(deviceId).matches()) {
                        return deviceId;
                    }
                } catch (Exception e2) {
                    throw e2;
                }
            }
            try {
                String string = Settings.System.getString(context.getContentResolver(), D[73]);
                if (string != null) {
                    try {
                        if (!string.trim().equals("") && !Pattern.compile(D[75]).matcher(string).matches()) {
                            return string;
                        }
                    } catch (Exception e3) {
                        throw e3;
                    }
                }
                return D[74];
            } catch (Exception e4) {
                String string2 = Settings.System.getString(context.getContentResolver(), D[73]);
                if (string2 == null) {
                    return D[74];
                }
                try {
                    return string2;
                } catch (Exception e5) {
                    throw e5;
                }
            }
        } catch (Exception e6) {
            String deviceId2 = b.getDeviceId();
            return deviceId2 == null ? D[74] : deviceId2;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void k(String str) {
        e = str;
    }

    public static String l(Context context) {
        String subscriberId;
        try {
            try {
                try {
                    if (l()) {
                        return "";
                    }
                    if (z != null) {
                        if (!z.equalsIgnoreCase(D[169])) {
                            return z;
                        }
                    }
                    pc a2 = pc.a(context, (String) null);
                    try {
                        if (b != null && (subscriberId = b.getSubscriberId()) != null) {
                            try {
                                if (!subscriberId.trim().equals("")) {
                                    mc.c(D[170] + subscriberId);
                                    z = subscriberId;
                                    a2.d(D[90], z);
                                    return z;
                                }
                            } catch (Exception e2) {
                                throw e2;
                            }
                        }
                    } catch (Exception e3) {
                    }
                    try {
                        s = a2.i(D[90]);
                        if (s != null) {
                            mc.c(D[168] + s);
                            return s;
                        }
                        mc.c(D[171]);
                        return D[169];
                    } catch (Exception e4) {
                        throw e4;
                    }
                } catch (Exception e5) {
                    throw e5;
                }
            } catch (Exception e6) {
                throw e6;
            }
        } catch (Exception e7) {
            throw e7;
        }
    }

    public static void l(String str) {
        s = str;
    }

    public static boolean l() {
        return c;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Code restructure failed: missing block: B:114:0x0481, code lost:
    
        r6.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:115:0x0484, code lost:
    
        if (r7 == null) goto L181;
     */
    /* JADX WARN: Code restructure failed: missing block: B:117:0x0487, code lost:
    
        if (r7.length <= 0) goto L181;
     */
    /* JADX WARN: Code restructure failed: missing block: B:118:0x0489, code lost:
    
        r7 = com.wooboo.adlib_android.mb.a(r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:119:0x048d, code lost:
    
        if (r7 == null) goto L179;
     */
    /* JADX WARN: Code restructure failed: missing block: B:120:0x048f, code lost:
    
        r6 = new com.wooboo.adlib_android.hb(r13);
     */
    /* JADX WARN: Code restructure failed: missing block: B:123:0x0495, code lost:
    
        r0 = (java.lang.String) r7.get(0);
        r2 = r0.indexOf(com.wooboo.adlib_android.sc.D[158(0x9e, float:2.21E-43)]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:124:0x04a5, code lost:
    
        if (r2 == (-1)) goto L164;
     */
    /* JADX WARN: Code restructure failed: missing block: B:125:0x04a7, code lost:
    
        r6.d(r0.substring(0, r2));
        r6.e(r0.substring(r2 + 3));
     */
    /* JADX WARN: Code restructure failed: missing block: B:126:0x04b8, code lost:
    
        if (r8 == false) goto L165;
     */
    /* JADX WARN: Code restructure failed: missing block: B:127:0x04c2, code lost:
    
        r0 = (java.lang.String) r7.get(1);
        r2 = r0.indexOf(com.wooboo.adlib_android.sc.D[158(0x9e, float:2.21E-43)]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:128:0x04d3, code lost:
    
        if (r2 == (-1)) goto L169;
     */
    /* JADX WARN: Code restructure failed: missing block: B:129:0x04d5, code lost:
    
        r6.g(r0.substring(0, r2));
        r6.c(java.lang.Integer.parseInt(r0.substring(r2 + 3)));
     */
    /* JADX WARN: Code restructure failed: missing block: B:130:0x04ea, code lost:
    
        if (r8 == false) goto L170;
     */
    /* JADX WARN: Code restructure failed: missing block: B:131:0x04f3, code lost:
    
        r6.e = (java.lang.String) r7.get(2);
        r6.g = ((java.lang.Byte) r7.get(3)).byteValue();
        com.wooboo.adlib_android.mc.c(com.wooboo.adlib_android.sc.D[154(0x9a, float:2.16E-43)] + r6.f);
        com.wooboo.adlib_android.mc.c(com.wooboo.adlib_android.sc.D[153(0x99, float:2.14E-43)] + r6.c);
        com.wooboo.adlib_android.mc.c(com.wooboo.adlib_android.sc.D[142(0x8e, float:1.99E-43)] + r6.f());
        com.wooboo.adlib_android.mc.c(com.wooboo.adlib_android.sc.D[156(0x9c, float:2.19E-43)] + r6.g);
        com.wooboo.adlib_android.mc.c(com.wooboo.adlib_android.sc.D[147(0x93, float:2.06E-43)] + r6.h);
        com.wooboo.adlib_android.mc.e(com.wooboo.adlib_android.sc.D[159(0x9f, float:2.23E-43)]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:132:0x058c, code lost:
    
        r0 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:134:0x058d, code lost:
    
        a(r4);
        a((java.io.Closeable) null);
     */
    /* JADX WARN: Code restructure failed: missing block: B:135:0x0593, code lost:
    
        if (r5 == null) goto L174;
     */
    /* JADX WARN: Code restructure failed: missing block: B:136:0x0595, code lost:
    
        if (r3 == null) goto L257;
     */
    /* JADX WARN: Code restructure failed: missing block: B:137:0x0597, code lost:
    
        r3.disconnect();
     */
    /* JADX WARN: Code restructure failed: missing block: B:139:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:140:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:142:0x059d, code lost:
    
        com.wooboo.adlib_android.mc.c(com.wooboo.adlib_android.sc.D[14]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:143:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:145:0x04ec, code lost:
    
        r6.g(r0);
        r6.c(0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:146:0x04ba, code lost:
    
        r6.d(r0);
        r6.e("");
     */
    /* JADX WARN: Code restructure failed: missing block: B:148:0x05f8, code lost:
    
        r2 = r3;
        r1 = r4;
        r0 = r6;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:150:0x02e4, code lost:
    
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.sc.D[28]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:152:0x02ed, code lost:
    
        a(r1);
        a((java.io.Closeable) null);
     */
    /* JADX WARN: Code restructure failed: missing block: B:153:0x02f3, code lost:
    
        if (r3 != null) goto L80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:154:0x02f5, code lost:
    
        if (r2 != null) goto L81;
     */
    /* JADX WARN: Code restructure failed: missing block: B:155:0x02f7, code lost:
    
        r2.disconnect();
     */
    /* JADX WARN: Code restructure failed: missing block: B:157:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:158:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:160:0x02fd, code lost:
    
        com.wooboo.adlib_android.mc.c(com.wooboo.adlib_android.sc.D[14]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:161:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:163:0x05db, code lost:
    
        r0 = th;
     */
    /* JADX WARN: Code restructure failed: missing block: B:164:0x05dc, code lost:
    
        r5 = r3;
        r3 = r2;
        r2 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:174:0x05a8, code lost:
    
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.sc.D[146(0x92, float:2.05E-43)]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:175:0x05b1, code lost:
    
        if (r8 == false) goto L203;
     */
    /* JADX WARN: Code restructure failed: missing block: B:176:0x05fe, code lost:
    
        r0 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:177:0x05b3, code lost:
    
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.sc.D[145(0x91, float:2.03E-43)]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:178:0x05bc, code lost:
    
        r0 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:207:0x0389, code lost:
    
        if (r8 != false) goto L111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x042a, code lost:
    
        if (r8 != false) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x0457, code lost:
    
        if (r8 != false) goto L141;
     */
    /* JADX WARN: Removed duplicated region for block: B:169:0x0328 A[Catch: Exception -> 0x05be, TRY_LEAVE, TryCatch #20 {Exception -> 0x05be, blocks: (B:166:0x031e, B:169:0x0328), top: B:165:0x031e }] */
    /* JADX WARN: Removed duplicated region for block: B:228:0x02a3 A[Catch: Exception -> 0x02de, all -> 0x031b, TRY_LEAVE, TryCatch #7 {Exception -> 0x02de, blocks: (B:226:0x029d, B:228:0x02a3), top: B:225:0x029d }] */
    /* JADX WARN: Removed duplicated region for block: B:237:0x032c A[Catch: Exception -> 0x02e0, all -> 0x031b, TRY_ENTER, TryCatch #5 {Exception -> 0x02e0, blocks: (B:63:0x0247, B:65:0x0252, B:68:0x0293, B:200:0x0365, B:202:0x0370, B:217:0x03a9, B:219:0x03bc, B:221:0x03c0, B:222:0x03cc, B:224:0x03a8, B:230:0x02a7, B:231:0x02b9, B:235:0x0308, B:237:0x032c, B:239:0x0330, B:240:0x0344, B:242:0x02df, B:247:0x0273), top: B:62:0x0247 }] */
    /* JADX WARN: Removed duplicated region for block: B:78:0x02cc A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:88:0x03f7 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v17, types: [int] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:102:0x0479 -> B:99:0x046f). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static com.wooboo.adlib_android.hb m(android.content.Context r13) {
        /*
            Method dump skipped, instructions count: 1546
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.sc.m(android.content.Context):com.wooboo.adlib_android.hb");
    }

    protected static String m() {
        return e;
    }

    protected static int n() {
        return B;
    }

    public static fc n(Context context) {
        fc fcVar = new fc();
        int d2 = d();
        try {
            fcVar.c(D[83], Integer.valueOf(d2).toString());
            if (d2 > 6) {
                fcVar.c(D[93], "7");
            } else {
                fcVar.c(D[93], "1");
            }
            try {
                fcVar.c(D[128], "4");
                if (B == -2) {
                    B = n();
                }
                try {
                    fcVar.c(D[81], Build.MODEL);
                    System.out.println(D[136] + B);
                    if (B == -1) {
                        fcVar.c(D[85], "");
                    } else {
                        fcVar.c(D[85], Integer.valueOf(B).toString());
                    }
                    try {
                        fcVar.c(D[124], "7");
                        fcVar.c(D[86], j(context));
                        fcVar.c(D[135], Build.VERSION.RELEASE);
                        if (n) {
                            fcVar.c(D[77], D[80]);
                        } else {
                            fcVar.c(D[77], D[132]);
                        }
                        fcVar.c(D[79], m());
                        fc a2 = a(fcVar, h);
                        try {
                            try {
                                if (h != null) {
                                    a2.c(D[84], h);
                                } else {
                                    a2.c(D[84], "");
                                }
                                a2.c(D[123], h());
                                a2.c(D[76], h(context));
                                a2.c(D[134], g());
                                a2.c(D[127], "");
                                try {
                                    a2.c(D[129], String.valueOf(i()));
                                    a2.c(D[130], Integer.valueOf(b()).toString());
                                    if (e() == null) {
                                        a2.c(D[125], "");
                                    } else {
                                        a2.c(D[125], e());
                                    }
                                    a2.c(D[126], pc.a(context, (String) null).n());
                                    if (f() == null) {
                                        try {
                                            a2.c(D[133], "");
                                        } catch (Exception e2) {
                                            throw e2;
                                        }
                                    } else {
                                        a2.c(D[133], URLEncoder.encode(f(), D[10]));
                                    }
                                    if (o() != null) {
                                        a2.c(D[2], kb.a(o()));
                                    } else {
                                        a2.c(D[2], "0");
                                    }
                                    a2.c(D[36], c(context));
                                    a2.c(D[131], "0");
                                    a2.c(D[90], l(context));
                                    mc.c(a2.toString());
                                    return a2;
                                } catch (Exception e3) {
                                    throw e3;
                                }
                            } catch (Exception e4) {
                                throw e4;
                            }
                        } catch (Exception e5) {
                            return a2;
                        }
                    } catch (Exception e6) {
                        throw e6;
                    }
                } catch (Exception e7) {
                    throw e7;
                }
            } catch (Exception e8) {
                throw e8;
            }
        } catch (Exception e9) {
            return fcVar;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int o(Context context) {
        String extraInfo;
        try {
            if (context.checkCallingOrSelfPermission(D[39]) == -1) {
                mc.c(D[52]);
                return 0;
            }
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(D[50]);
            if (connectivityManager != null) {
                NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
                if (activeNetworkInfo != null) {
                    try {
                        if (activeNetworkInfo.isAvailable()) {
                            String typeName = activeNetworkInfo.getTypeName();
                            try {
                                try {
                                    mc.c(D[38] + typeName);
                                    if (typeName != null) {
                                        if (typeName.equalsIgnoreCase(D[51])) {
                                            return 1;
                                        }
                                        if (typeName.equalsIgnoreCase(D[40]) && (extraInfo = activeNetworkInfo.getExtraInfo()) != null) {
                                            try {
                                                if (extraInfo.contains(D[46])) {
                                                    return 2;
                                                }
                                                try {
                                                    if (extraInfo.contains(D[49])) {
                                                        return 3;
                                                    }
                                                    try {
                                                        if (extraInfo.toUpperCase().contains(D[37])) {
                                                            return 2;
                                                        }
                                                        try {
                                                            if (extraInfo.toUpperCase().contains(D[48])) {
                                                                return 2;
                                                            }
                                                            try {
                                                                if (extraInfo.contains(D[42])) {
                                                                    return 2;
                                                                }
                                                                try {
                                                                    if (extraInfo.contains(D[44])) {
                                                                        return 2;
                                                                    }
                                                                    try {
                                                                        if (extraInfo.contains(D[47])) {
                                                                            return 4;
                                                                        }
                                                                        try {
                                                                            if (extraInfo.contains(D[41])) {
                                                                                return 5;
                                                                            }
                                                                            try {
                                                                                if (extraInfo.contains(D[45])) {
                                                                                    return 2;
                                                                                }
                                                                                try {
                                                                                    if (extraInfo.contains(D[43])) {
                                                                                        return 2;
                                                                                    }
                                                                                } catch (IllegalArgumentException e2) {
                                                                                    throw e2;
                                                                                }
                                                                            } catch (IllegalArgumentException e3) {
                                                                                throw e3;
                                                                            }
                                                                        } catch (IllegalArgumentException e4) {
                                                                            throw e4;
                                                                        }
                                                                    } catch (IllegalArgumentException e5) {
                                                                        throw e5;
                                                                    }
                                                                } catch (IllegalArgumentException e6) {
                                                                    throw e6;
                                                                }
                                                            } catch (IllegalArgumentException e7) {
                                                                throw e7;
                                                            }
                                                        } catch (IllegalArgumentException e8) {
                                                            throw e8;
                                                        }
                                                    } catch (IllegalArgumentException e9) {
                                                        throw e9;
                                                    }
                                                } catch (IllegalArgumentException e10) {
                                                    throw e10;
                                                }
                                            } catch (IllegalArgumentException e11) {
                                                throw e11;
                                            }
                                        }
                                    }
                                } catch (IllegalArgumentException e12) {
                                    throw e12;
                                }
                            } catch (IllegalArgumentException e13) {
                                throw e13;
                            }
                        }
                    } catch (IllegalArgumentException e14) {
                        throw e14;
                    }
                }
                return 0;
            }
            return 2;
        } catch (IllegalArgumentException e15) {
            throw e15;
        }
    }

    public static int[] o() {
        return q;
    }

    public static void p() {
        String str = D[0];
        if (!kb.a()) {
            kb.a(j(), str, q().getBytes());
            return;
        }
        File file = new File(String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + File.separator + str);
        if (!file.exists()) {
            try {
                kb.a(j(), file, kb.a(j(), str));
                return;
            } catch (FileNotFoundException e2) {
                String q2 = q();
                kb.a(j(), str, q2.getBytes());
                kb.a(j(), file, q2);
                return;
            }
        }
        try {
            String a2 = kb.a(j(), str);
            String obj = kb.b(file).toString();
            try {
                if (a2.compareTo(obj) < 0) {
                    kb.a(j(), file, a2);
                } else if (a2.compareTo(obj) > 0) {
                    kb.a(i, str, obj.getBytes());
                }
            } catch (FileNotFoundException e3) {
                throw e3;
            }
        } catch (FileNotFoundException e4) {
            kb.a(j(), str, kb.b(file));
        }
    }

    public static String q() {
        return null;
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i2 = 0; length > i2; i2++) {
            char c3 = cArr[i2];
            switch (i2 % 5) {
                case 0:
                    c2 = 'w';
                    break;
                case 1:
                    c2 = 'a';
                    break;
                case 2:
                    c2 = 15;
                    break;
                case nb.p /* 3 */:
                    c2 = 'f';
                    break;
                default:
                    c2 = '2';
                    break;
            }
            cArr[i2] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '2');
        }
        return charArray;
    }
}
