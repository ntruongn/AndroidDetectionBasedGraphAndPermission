package com.uucun.adsdk.c;

import android.content.Context;
import android.os.AsyncTask;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public abstract class j extends AsyncTask {
    private static final String d = j.class.getSimpleName();
    private m a;
    public String b;
    public Context c;

    public j(Context context) {
        this.c = null;
        this.a = null;
        this.c = context;
        this.a = new m(context);
    }

    public Object a(JSONObject jSONObject) {
        long currentTimeMillis = System.currentTimeMillis();
        String a = this.a.a(this.b, jSONObject);
        com.uucun.adsdk.b.h.b(d, "Connection Time :" + (com.uucun.adsdk.b.h.a(currentTimeMillis) + " s") + " " + this.b);
        if (a == null || a.equals("")) {
            return null;
        }
        long currentTimeMillis2 = System.currentTimeMillis();
        Object b = b(a);
        com.uucun.adsdk.b.h.b(d, "Parser Time :" + (com.uucun.adsdk.b.h.a(currentTimeMillis2) + " s") + " " + a);
        return b;
    }

    public abstract Object b(String str);
}
