package com.uucun.adsdk.c;

import android.content.Context;
import java.io.File;
import java.util.ArrayList;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a extends j {
    public static final String a = a.class.getSimpleName();
    private i d;
    private Context e;

    public a(String str, Context context, i iVar) {
        super(context);
        this.b = str;
        this.e = context;
        this.d = iVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(com.uucun.adsdk.d.e eVar) {
        if (eVar.d != null) {
            return;
        }
        com.uucun.adsdk.b.h.c(a, " Download AD ID : " + eVar.c + "  " + eVar.j + "  Image Url:" + eVar.b);
        byte[] b = com.uucun.adsdk.b.c.b(eVar.b, this.e);
        if (b == null || b.length <= 0) {
            return;
        }
        try {
            com.uucun.adsdk.b.c.a(b, new File(com.uucun.adsdk.b.c.a(this.e), com.uucun.adsdk.b.c.b(eVar.b)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // com.uucun.adsdk.c.j
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public ArrayList b(String str) {
        return com.uucun.adsdk.b.i.c(str);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public ArrayList doInBackground(JSONObject... jSONObjectArr) {
        try {
            com.uucun.adsdk.b.c.a(jSONObjectArr[0], this.e);
            return (ArrayList) a(jSONObjectArr[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void onPostExecute(ArrayList arrayList) {
        if (arrayList == null || arrayList.isEmpty()) {
            this.d.a();
        } else {
            com.uucun.adsdk.b.h.b(a, "AD SIZE:" + arrayList.size());
            new f(this, arrayList, arrayList.size()).start();
        }
    }
}
