package com.yong.pedometer;

import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class SpeakingTimer implements StepListener {
    float mInterval;
    PedometerSettings mSettings;
    boolean mShouldSpeak;
    Utils mUtils;
    private ArrayList<Listener> mListeners = new ArrayList<>();
    long mLastSpeakTime = System.currentTimeMillis();

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public interface Listener {
        void speak();
    }

    public SpeakingTimer(PedometerSettings settings, Utils utils) {
        this.mSettings = settings;
        this.mUtils = utils;
        reloadSettings();
    }

    public void reloadSettings() {
        this.mShouldSpeak = this.mSettings.shouldSpeak();
        this.mInterval = this.mSettings.getSpeakingInterval();
    }

    @Override // com.yong.pedometer.StepListener
    public void onStep() {
        long now = System.currentTimeMillis();
        long delta = now - this.mLastSpeakTime;
        if (delta / 60000.0d >= this.mInterval) {
            this.mLastSpeakTime = now;
            notifyListeners();
        }
    }

    @Override // com.yong.pedometer.StepListener
    public void passValue() {
    }

    public void addListener(Listener l) {
        this.mListeners.add(l);
    }

    public void notifyListeners() {
        this.mUtils.ding();
        Iterator<Listener> it = this.mListeners.iterator();
        while (it.hasNext()) {
            Listener listener = it.next();
            listener.speak();
        }
    }

    public boolean isSpeaking() {
        return this.mUtils.isSpeakingNow();
    }
}
