package com.mobclick.android;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import com.wooboo.adlib_android.nb;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import javax.microedition.khronos.opengles.GL10;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class MobclickAgent {
    private static final String A = "time";
    private static final String B = "start_millis";
    private static final String C = "end_millis";
    private static final String D = "duration";
    private static final String E = "activities";
    private static final String F = "header";
    private static final String G = "package";
    private static final String H = "sdk_version";
    private static final String I = "channel";
    private static final String J = "idmd5";
    private static final String K = "version_code";
    private static final String L = "acc";
    private static final String M = "tag";
    private static final String N = "label";
    private static final String O = "context";
    private static final String P = "last_config_time";
    private static final String Q = "report_policy";
    private static final String R = "update_internal";
    private static final String S = "online_params";
    private static /* synthetic */ int[] T = null;
    private static final int e = 0;
    private static final int f = 1;
    private static final int g = 2;
    private static final int h = 3;
    private static final String l = "type";
    private static final String m = "subtype";
    private static final String n = "update";
    private static final String o = "error";
    private static final String p = "event";
    private static final String q = "launch";
    private static final String r = "flush";
    private static final String s = "terminate";
    private static final String t = "online_config";
    private static final String u = "cache_error";
    private static final String v = "send_error";
    private static final String w = "appkey";
    private static final String x = "body";
    private static final String y = "session_id";
    private static final String z = "date";
    private Context c;
    private final Handler d;
    private static final MobclickAgent a = new MobclickAgent();
    private static int b = 1;
    private static UmengUpdateListener i = null;
    private static UmengOnlineConfigureListener j = null;
    public static String GPU_VENDER = "";
    public static String GPU_RENDERER = "";
    public static boolean mUpdateOnlyWifi = true;
    public static boolean mUseLocationService = true;
    private static JSONObject k = null;
    public static boolean updateAutoPopup = true;

    private MobclickAgent() {
        HandlerThread handlerThread = new HandlerThread(UmengConstants.LOG_TAG);
        handlerThread.start();
        this.d = new Handler(handlerThread.getLooper());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static SharedPreferences a(Context context) {
        return context.getSharedPreferences("mobclick_agent_user_" + context.getPackageName(), 0);
    }

    private String a(Context context, SharedPreferences sharedPreferences) {
        Long valueOf = Long.valueOf(System.currentTimeMillis());
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putLong(B, valueOf.longValue());
        edit.putLong(C, -1L);
        edit.commit();
        return sharedPreferences.getString(y, null);
    }

    private String a(Context context, String str, long j2) {
        StringBuilder sb = new StringBuilder();
        sb.append(j2).append(str).append(m.c(context));
        return m.b(sb.toString());
    }

    private String a(Context context, String str, SharedPreferences sharedPreferences) {
        c(context, sharedPreferences);
        long currentTimeMillis = System.currentTimeMillis();
        String a2 = a(context, str, currentTimeMillis);
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putString("appkey", str);
        edit.putString(y, a2);
        edit.putLong(B, currentTimeMillis);
        edit.putLong(C, -1L);
        edit.putLong(D, 0L);
        edit.putString(E, "");
        edit.commit();
        b(context, sharedPreferences);
        return a2;
    }

    private static String a(Context context, JSONObject jSONObject, String str, boolean z2, String str2) {
        HttpPost httpPost = new HttpPost(str);
        BasicHttpParams basicHttpParams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(basicHttpParams, 10000);
        HttpConnectionParams.setSoTimeout(basicHttpParams, nb.c);
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient(basicHttpParams);
        try {
            String a2 = n.a(context);
            if (a2 != null) {
                defaultHttpClient.getParams().setParameter("http.route.default-proxy", new HttpHost(a2, 80));
            }
            String jSONObject2 = jSONObject.toString();
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, jSONObject2);
            }
            if (!UmengConstants.COMPRESS_DATA || z2) {
                ArrayList arrayList = new ArrayList(1);
                arrayList.add(new BasicNameValuePair(UmengConstants.AtomKey_Content, jSONObject2));
                httpPost.setEntity(new UrlEncodedFormEntity(arrayList, "UTF-8"));
            } else {
                byte[] c = m.c("content=" + jSONObject2);
                httpPost.addHeader("Content-Encoding", "deflate");
                httpPost.setEntity(new InputStreamEntity(new ByteArrayInputStream(c), m.b));
            }
            SharedPreferences.Editor edit = i(context).edit();
            Date date = new Date();
            HttpResponse execute = defaultHttpClient.execute(httpPost);
            long time = new Date().getTime() - date.getTime();
            if (execute.getStatusLine().getStatusCode() != 200) {
                edit.putLong("req_time", -1L);
                return null;
            }
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "Sent message to " + str);
            }
            edit.putLong("req_time", time);
            edit.commit();
            HttpEntity entity = execute.getEntity();
            if (entity != null) {
                return a(entity.getContent());
            }
            return null;
        } catch (ClientProtocolException e2) {
            if (!UmengConstants.testMode) {
                return null;
            }
            Log.i(UmengConstants.LOG_TAG, "ClientProtocolException,Failed to send message.", e2);
            e2.printStackTrace();
            return null;
        } catch (IOException e3) {
            if (!UmengConstants.testMode) {
                return null;
            }
            Log.i(UmengConstants.LOG_TAG, "IOException,Failed to send message.", e3);
            e3.printStackTrace();
            return null;
        }
    }

    private static String a(InputStream inputStream) {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream), 8192);
        StringBuilder sb = new StringBuilder();
        while (true) {
            try {
                try {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        try {
                            inputStream.close();
                            return sb.toString();
                        } catch (IOException e2) {
                            if (!UmengConstants.testMode) {
                                return null;
                            }
                            Log.e(UmengConstants.LOG_TAG, "Caught IOException in convertStreamToString()", e2);
                            e2.printStackTrace();
                            return null;
                        }
                    }
                    sb.append(String.valueOf(readLine) + "\n");
                } catch (IOException e3) {
                    if (UmengConstants.testMode) {
                        Log.e(UmengConstants.LOG_TAG, "Caught IOException in convertStreamToString()", e3);
                        e3.printStackTrace();
                    }
                    try {
                        inputStream.close();
                        return null;
                    } catch (IOException e4) {
                        if (!UmengConstants.testMode) {
                            return null;
                        }
                        Log.e(UmengConstants.LOG_TAG, "Caught IOException in convertStreamToString()", e4);
                        e4.printStackTrace();
                        return null;
                    }
                }
            } catch (Throwable th) {
                try {
                    inputStream.close();
                    throw th;
                } catch (IOException e5) {
                    if (!UmengConstants.testMode) {
                        return null;
                    }
                    Log.e(UmengConstants.LOG_TAG, "Caught IOException in convertStreamToString()", e5);
                    e5.printStackTrace();
                    return null;
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:49:0x00ae  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private org.json.JSONArray a(org.json.JSONObject r9, org.json.JSONArray r10) {
        /*
            r8 = this;
            r1 = 1
            java.lang.String r0 = "tag"
            java.lang.String r5 = r9.getString(r0)     // Catch: java.lang.Exception -> La9
            java.lang.String r0 = "label"
            boolean r0 = r9.has(r0)     // Catch: java.lang.Exception -> La9
            if (r0 == 0) goto L2d
            java.lang.String r0 = "label"
            java.lang.String r0 = r9.getString(r0)     // Catch: java.lang.Exception -> La9
            r4 = r0
        L16:
            java.lang.String r0 = "date"
            java.lang.String r6 = r9.getString(r0)     // Catch: java.lang.Exception -> La9
            r2 = 0
            int r0 = r10.length()     // Catch: java.lang.Exception -> La9
            int r0 = r0 + (-1)
            r3 = r0
        L24:
            if (r3 >= 0) goto L30
            r0 = r2
        L27:
            if (r0 != 0) goto L2c
            r10.put(r9)     // Catch: java.lang.Exception -> La9
        L2c:
            return r10
        L2d:
            r0 = 0
            r4 = r0
            goto L16
        L30:
            java.lang.Object r0 = r10.get(r3)     // Catch: java.lang.Exception -> La9
            org.json.JSONObject r0 = (org.json.JSONObject) r0     // Catch: java.lang.Exception -> La9
            if (r4 != 0) goto L67
            java.lang.String r7 = "label"
            boolean r7 = r0.has(r7)     // Catch: java.lang.Exception -> La9
            if (r7 != 0) goto L67
            java.lang.String r7 = "tag"
            java.lang.Object r7 = r0.get(r7)     // Catch: java.lang.Exception -> La9
            boolean r7 = r5.equals(r7)     // Catch: java.lang.Exception -> La9
            if (r7 == 0) goto La4
            java.lang.String r7 = "date"
            java.lang.Object r7 = r0.get(r7)     // Catch: java.lang.Exception -> La9
            boolean r7 = r6.equals(r7)     // Catch: java.lang.Exception -> La9
            if (r7 == 0) goto La4
            java.lang.String r2 = "acc"
            java.lang.String r3 = "acc"
            int r3 = r0.getInt(r3)     // Catch: java.lang.Exception -> La9
            int r3 = r3 + 1
            r0.put(r2, r3)     // Catch: java.lang.Exception -> La9
            r0 = r1
            goto L27
        L67:
            if (r4 == 0) goto La4
            java.lang.String r7 = "label"
            boolean r7 = r0.has(r7)     // Catch: java.lang.Exception -> La9
            if (r7 == 0) goto La4
            java.lang.String r7 = "tag"
            java.lang.Object r7 = r0.get(r7)     // Catch: java.lang.Exception -> La9
            boolean r7 = r5.equals(r7)     // Catch: java.lang.Exception -> La9
            if (r7 == 0) goto La4
            java.lang.String r7 = "label"
            java.lang.Object r7 = r0.get(r7)     // Catch: java.lang.Exception -> La9
            boolean r7 = r4.equals(r7)     // Catch: java.lang.Exception -> La9
            if (r7 == 0) goto La4
            java.lang.String r7 = "date"
            java.lang.Object r7 = r0.get(r7)     // Catch: java.lang.Exception -> La9
            boolean r7 = r6.equals(r7)     // Catch: java.lang.Exception -> La9
            if (r7 == 0) goto La4
            java.lang.String r2 = "acc"
            java.lang.String r3 = "acc"
            int r3 = r0.getInt(r3)     // Catch: java.lang.Exception -> La9
            int r3 = r3 + 1
            r0.put(r2, r3)     // Catch: java.lang.Exception -> La9
            r0 = r1
            goto L27
        La4:
            int r0 = r3 + (-1)
            r3 = r0
            goto L24
        La9:
            r0 = move-exception
            boolean r1 = com.mobclick.android.UmengConstants.testMode
            if (r1 == 0) goto Lb8
            java.lang.String r1 = "MobclickAgent"
            java.lang.String r2 = "custom log merge error in tryToSendMessage"
            android.util.Log.i(r1, r2)
            r0.printStackTrace()
        Lb8:
            r10.put(r9)
            goto L2c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.mobclick.android.MobclickAgent.a(org.json.JSONObject, org.json.JSONArray):org.json.JSONArray");
    }

    private static void a(Context context, int i2) {
        if (i2 < 0 || i2 > 5) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Illegal value of report policy");
            }
        } else {
            SharedPreferences n2 = n(context);
            synchronized (UmengConstants.saveOnlineConfigMutex) {
                n2.edit().putInt(UmengConstants.Online_Config_Local_Policy, i2).commit();
            }
        }
    }

    private void a(Context context, SharedPreferences sharedPreferences, String str, String str2, int i2) {
        String string = sharedPreferences.getString(y, "");
        String c = c();
        String str3 = c.split(" ")[0];
        String str4 = c.split(" ")[1];
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", p);
            jSONObject.put(y, string);
            jSONObject.put(z, str3);
            jSONObject.put(A, str4);
            jSONObject.put(M, str);
            if (str2 != null) {
                jSONObject.put(N, str2);
            }
            jSONObject.put(L, i2);
            this.d.post(new l(this, context, jSONObject));
        } catch (JSONException e2) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "json error in emitCustomLogReport");
                e2.printStackTrace();
            }
        }
    }

    private static void a(Context context, Gender gender) {
        int i2 = 0;
        SharedPreferences a2 = a(context);
        switch (b()[gender.ordinal()]) {
            case 1:
                i2 = 1;
                break;
            case 2:
                i2 = 2;
                break;
        }
        a2.edit().putInt(UmengConstants.AtomKey_Sex, i2).commit();
    }

    private synchronized void a(Context context, String str) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", n);
            jSONObject.put("appkey", str);
            int i2 = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
            String packageName = context.getPackageName();
            jSONObject.put(K, i2);
            jSONObject.put(G, packageName);
            jSONObject.put("sdk_version", UmengConstants.SDK_VERSION);
            jSONObject.put(J, m.c(context));
            jSONObject.put(I, m.g(context));
            this.d.post(new l(this, context, jSONObject));
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "exception in updateInternal");
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void a(Context context, String str, String str2) {
        this.c = context;
        SharedPreferences k2 = k(context);
        if (k2 != null) {
            if (a(k2)) {
                String a2 = a(context, str, k2);
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "Start new session: " + a2);
                }
            } else {
                String a3 = a(context, k2);
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "Extend current session: " + a3);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void a(Context context, String str, String str2, String str3, int i2) {
        SharedPreferences k2 = k(context);
        if (k2 != null) {
            a(context, k2, str2, str3, i2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(Context context, JSONObject jSONObject) {
        int i2 = 0;
        if (!a(n, context, new String[0])) {
            if (i != null) {
                i.onUpdateReturned(UpdateStatus.No);
                return;
            }
            return;
        }
        if (UmengConstants.testMode) {
            Log.i(UmengConstants.LOG_TAG, "start to check update info ...");
        }
        String str = null;
        while (true) {
            if (i2 >= UmengConstants.UPDATE_URL_LIST.length) {
                break;
            }
            str = a(context, jSONObject, UmengConstants.UPDATE_URL_LIST[i2], true, n);
            if (str == null) {
                i2++;
            } else if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "get update info succeed: " + str);
            }
        }
        if (str != null) {
            c(context, str);
            return;
        }
        if (UmengConstants.testMode) {
            Log.i(UmengConstants.LOG_TAG, "get update info failed");
        }
        if (i != null) {
            i.onUpdateReturned(UpdateStatus.Timeout);
        }
    }

    private boolean a(SharedPreferences sharedPreferences) {
        return System.currentTimeMillis() - sharedPreferences.getLong(C, -1L) > UmengConstants.kContinueSessionMillis;
    }

    private static boolean a(String str, Context context, String... strArr) {
        if (context.getPackageManager().checkPermission("android.permission.ACCESS_NETWORK_STATE", context.getPackageName()) == 0 && !m.h(context)) {
            return false;
        }
        if (str == n || str == t) {
            return true;
        }
        b = o(context);
        if (b == 3) {
            return str == r;
        }
        if (str == "error") {
            return strArr == null || strArr.length <= 0 || !strArr[0].equals(v);
        }
        if (b == 1 && str == q) {
            return true;
        }
        if ((b != 2 || str != s) && b != 0) {
            if (b == 4) {
                return !j(context).getString(m.b(), "false").equals("true") && str.equals(q);
            }
            if (b == 5) {
                return m.f(context)[0].equals("Wi-Fi");
            }
            return false;
        }
        return true;
    }

    private static AlertDialog b(Context context, File file) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(context.getString(m.a(context, "string", "UMUpdateTitle"))).setMessage(context.getString(m.a(context, "string", "UMDialog_InstallAPK"))).setCancelable(false).setPositiveButton(context.getString(m.a(context, "string", "UMUpdateNow")), new f(context, file)).setNegativeButton(context.getString(m.a(context, "string", "UMNotNow")), new g());
        AlertDialog create = builder.create();
        create.setCancelable(true);
        return create;
    }

    private static AlertDialog b(Context context, JSONObject jSONObject) {
        try {
            String string = jSONObject.has("version") ? jSONObject.getString("version") : "";
            String string2 = jSONObject.has("update_log") ? jSONObject.getString("update_log") : "";
            String string3 = jSONObject.has("path") ? jSONObject.getString("path") : "";
            String str = m.f(context)[0].equals("Wi-Fi") ? "" : String.valueOf(context.getString(m.a(context, "string", "UMGprsCondition"))) + "\n";
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle(context.getString(m.a(context, "string", "UMUpdateTitle"))).setMessage(String.valueOf(str) + context.getString(m.a(context, "string", "UMNewVersion")) + string + "\n" + string2).setCancelable(false).setPositiveButton(context.getString(m.a(context, "string", "UMUpdateNow")), new h(context, string3, string)).setNegativeButton(context.getString(m.a(context, "string", "UMNotNow")), new i());
            AlertDialog create = builder.create();
            create.setCancelable(true);
            return create;
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Fail to create update dialog box.", e2);
                e2.printStackTrace();
            }
            return null;
        }
    }

    private static void b(Context context, int i2) {
        SharedPreferences a2 = a(context);
        if (i2 >= 0 && i2 <= 200) {
            a2.edit().putInt("age", i2).commit();
        } else if (UmengConstants.testMode) {
            Log.i(UmengConstants.LOG_TAG, "not a valid age!");
        }
    }

    private void b(Context context, SharedPreferences sharedPreferences) {
        String string = sharedPreferences.getString(y, null);
        if (string == null) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "Missing session_id, ignore message");
                return;
            }
            return;
        }
        String c = c();
        String str = c.split(" ")[0];
        String str2 = c.split(" ")[1];
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", q);
            jSONObject.put(y, string);
            jSONObject.put(z, str);
            jSONObject.put(A, str2);
            this.d.post(new l(this, context, jSONObject));
        } catch (JSONException e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "json error in emitNewSessionReport");
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void b(Context context, String str) {
        String c = c(context);
        if (c != "" && c.length() <= 10240) {
            b(context, c, u);
        }
    }

    private void b(Context context, String str, String str2) {
        String c = c();
        String str3 = c.split(" ")[0];
        String str4 = c.split(" ")[1];
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", "error");
            jSONObject.put(O, str);
            jSONObject.put(z, str3);
            jSONObject.put(A, str4);
            jSONObject.put(m, str2);
            this.d.post(new l(this, context, jSONObject));
        } catch (JSONException e2) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "json error in emitErrorReport");
                e2.printStackTrace();
            }
        }
    }

    static /* synthetic */ int[] b() {
        int[] iArr = T;
        if (iArr == null) {
            iArr = new int[Gender.valuesCustom().length];
            try {
                iArr[Gender.Female.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[Gender.Male.ordinal()] = 1;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[Gender.Unknown.ordinal()] = 3;
            } catch (NoSuchFieldError e4) {
            }
            T = iArr;
        }
        return iArr;
    }

    private static String c() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }

    private static String c(Context context) {
        String str;
        Exception e2;
        try {
            String packageName = context.getPackageName();
            ArrayList arrayList = new ArrayList();
            arrayList.add("logcat");
            arrayList.add("-d");
            arrayList.add("-v");
            arrayList.add("raw");
            arrayList.add("-s");
            arrayList.add("AndroidRuntime:E");
            arrayList.add("-p");
            arrayList.add(packageName);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec((String[]) arrayList.toArray(new String[arrayList.size()])).getInputStream()), 1024);
            boolean z2 = false;
            String readLine = bufferedReader.readLine();
            str = "";
            boolean z3 = false;
            while (readLine != null) {
                String str2 = readLine.indexOf("thread attach failed") < 0 ? String.valueOf(str) + readLine + '\n' : str;
                if (!z3 && readLine.toLowerCase().indexOf("exception") >= 0) {
                    z3 = true;
                }
                z2 = (z2 || readLine.indexOf(packageName) < 0) ? z2 : true;
                readLine = bufferedReader.readLine();
                str = str2;
            }
            if (str.length() <= 0 || !z3 || !z2) {
                str = "";
            }
            try {
                Runtime.getRuntime().exec("logcat -c");
            } catch (Exception e3) {
                try {
                    if (UmengConstants.testMode) {
                        Log.e(UmengConstants.LOG_TAG, "Failed to clear log in exec(logcat -c)");
                        e3.printStackTrace();
                    }
                } catch (Exception e4) {
                    e2 = e4;
                    if (UmengConstants.testMode) {
                        Log.e(UmengConstants.LOG_TAG, "Failed to catch error log in catchLogError");
                        e2.printStackTrace();
                    }
                    return str;
                }
            }
        } catch (Exception e5) {
            str = "";
            e2 = e5;
        }
        return str;
    }

    private void c(Context context, SharedPreferences sharedPreferences) {
        String string = sharedPreferences.getString(y, null);
        if (string == null) {
            if (UmengConstants.testMode) {
                Log.w(UmengConstants.LOG_TAG, "Missing session_id, ignore message in emitLastEndSessionReport");
                return;
            }
            return;
        }
        Long valueOf = Long.valueOf(sharedPreferences.getLong(D, -1L));
        if (valueOf.longValue() <= 0) {
            valueOf = 0L;
        }
        String c = c();
        String str = c.split(" ")[0];
        String str2 = c.split(" ")[1];
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", s);
            jSONObject.put(y, string);
            jSONObject.put(z, str);
            jSONObject.put(A, str2);
            jSONObject.put(D, String.valueOf(valueOf.longValue() / 1000));
            if (UmengConstants.ACTIVITY_DURATION_OPEN) {
                String string2 = sharedPreferences.getString(E, "");
                if (!"".equals(string2)) {
                    String[] split = string2.split(";");
                    JSONArray jSONArray = new JSONArray();
                    for (String str3 : split) {
                        jSONArray.put(new JSONArray(str3));
                    }
                    jSONObject.put(E, jSONArray);
                }
            }
            this.d.post(new l(this, context, jSONObject));
        } catch (JSONException e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "json error in emitLastEndSessionReport");
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void c(Context context, File file) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(Uri.parse("file://" + file.getAbsolutePath()), "application/vnd.android.package-archive");
        context.startActivity(intent);
    }

    private void c(Context context, String str) {
        try {
            k = new JSONObject(str);
            if (!k.getString(n).equals("Yes")) {
                if (i != null) {
                    i.onUpdateReturned(UpdateStatus.No);
                }
            } else {
                if (i != null) {
                    i.onUpdateReturned(UpdateStatus.Yes);
                }
                if (updateAutoPopup) {
                    showUpdateDialog(context);
                }
            }
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "show update dialog error");
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c(Context context, JSONObject jSONObject) {
        String str = null;
        SharedPreferences i2 = i(context);
        JSONObject e2 = m.e(context);
        long j2 = i2.getLong("req_time", 0L);
        if (j2 != 0) {
            try {
                e2.put("req_time", j2);
            } catch (JSONException e3) {
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "json error in tryToSendMessage");
                    e3.printStackTrace();
                }
            }
        }
        i2.edit().putString(F, e2.toString()).commit();
        JSONObject g2 = g(context);
        JSONObject jSONObject2 = new JSONObject();
        try {
            String string = jSONObject.getString("type");
            if (string == null) {
                return;
            }
            String str2 = jSONObject.has(m) ? (String) jSONObject.remove(m) : null;
            if (string != r) {
                jSONObject.remove("type");
                if (g2 == null) {
                    JSONObject jSONObject3 = new JSONObject();
                    JSONArray jSONArray = new JSONArray();
                    jSONArray.put(jSONObject);
                    jSONObject3.put(string, jSONArray);
                    g2 = jSONObject3;
                } else if (g2.isNull(string)) {
                    JSONArray jSONArray2 = new JSONArray();
                    jSONArray2.put(jSONObject);
                    g2.put(string, jSONArray2);
                } else {
                    g2.getJSONArray(string).put(jSONObject);
                }
            }
            if (g2 == null) {
                if (UmengConstants.testMode) {
                    Log.w(UmengConstants.LOG_TAG, "No cache message to flush in tryToSendMessage");
                    return;
                }
                return;
            }
            jSONObject2.put(F, e2);
            jSONObject2.put(x, g2);
            if (a(string, context, str2)) {
                for (int i3 = 0; i3 < UmengConstants.APPLOG_URL_LIST.length && (str = a(context, jSONObject2, UmengConstants.APPLOG_URL_LIST[i3], false, string)) == null; i3++) {
                }
                if (str != null) {
                    if (UmengConstants.testMode) {
                        Log.i(UmengConstants.LOG_TAG, "send applog succeed :" + str);
                    }
                    h(context);
                    if (b == 4) {
                        SharedPreferences.Editor edit = j(context).edit();
                        edit.putString(m.b(), "true");
                        edit.commit();
                        return;
                    }
                    return;
                }
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "send applog failed");
                }
            }
            d(context, g2);
        } catch (JSONException e4) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Fail to construct json message in tryToSendMessage.");
                e4.printStackTrace();
            }
            h(context);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void d(Context context) {
        if (this.c == context) {
            this.c = context;
            SharedPreferences k2 = k(context);
            if (k2 != null) {
                long j2 = k2.getLong(B, -1L);
                if (j2 != -1) {
                    long currentTimeMillis = System.currentTimeMillis();
                    long j3 = currentTimeMillis - j2;
                    long j4 = k2.getLong(D, 0L);
                    SharedPreferences.Editor edit = k2.edit();
                    if (UmengConstants.ACTIVITY_DURATION_OPEN) {
                        String string = k2.getString(E, "");
                        String name = context.getClass().getName();
                        if (!"".equals(string)) {
                            string = String.valueOf(string) + ";";
                        }
                        String str = String.valueOf(string) + "[" + name + "," + (j3 / 1000) + "]";
                        edit.remove(E);
                        edit.putString(E, str);
                    }
                    edit.putLong(B, -1L);
                    edit.putLong(C, currentTimeMillis);
                    edit.putLong(D, j3 + j4);
                    edit.commit();
                } else if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "onEndSession called before onStartSession");
                }
            }
        } else if (UmengConstants.testMode) {
            Log.e(UmengConstants.LOG_TAG, "onPause() called without context from corresponding onResume()");
        }
    }

    private static void d(Context context, String str) {
        SharedPreferences n2 = n(context);
        synchronized (UmengConstants.saveOnlineConfigMutex) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                try {
                    if (jSONObject.has(P)) {
                        n2.edit().putString(UmengConstants.Online_Config_Last_Modify, jSONObject.getString(P)).commit();
                    }
                } catch (Exception e2) {
                    if (UmengConstants.testMode) {
                        e2.printStackTrace();
                    }
                }
                try {
                    if (jSONObject.has(Q)) {
                        n2.edit().putInt(UmengConstants.Online_Config_Net_Policy, jSONObject.getInt(Q)).commit();
                    }
                } catch (Exception e3) {
                    if (UmengConstants.testMode) {
                        e3.printStackTrace();
                    }
                }
                try {
                    if (jSONObject.has(R)) {
                        n2.edit().putInt(UmengConstants.KEY_UPDATE_INTERNAL, jSONObject.getInt(R)).commit();
                    }
                } catch (Exception e4) {
                    if (UmengConstants.testMode) {
                        e4.printStackTrace();
                    }
                }
                try {
                    if (jSONObject.has(S)) {
                        JSONObject jSONObject2 = new JSONObject(jSONObject.getString(S));
                        Iterator<String> keys = jSONObject2.keys();
                        SharedPreferences.Editor edit = n2.edit();
                        while (keys.hasNext()) {
                            String next = keys.next();
                            edit.putString(next, jSONObject2.getString(next));
                        }
                        edit.commit();
                        if (j != null) {
                            j.onDataReceived(jSONObject2);
                        }
                        Log.i(UmengConstants.LOG_TAG, "get online setting params: " + jSONObject2);
                    }
                } catch (Exception e5) {
                    if (UmengConstants.testMode) {
                        e5.printStackTrace();
                    }
                }
            } catch (Exception e6) {
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "not json string");
                }
            }
        }
    }

    private static void d(Context context, JSONObject jSONObject) {
        try {
            FileOutputStream openFileOutput = context.openFileOutput(m(context), 0);
            openFileOutput.write(jSONObject.toString().getBytes());
            openFileOutput.close();
        } catch (FileNotFoundException e2) {
            if (UmengConstants.testMode) {
                e2.printStackTrace();
            }
        } catch (IOException e3) {
            if (UmengConstants.testMode) {
                e3.printStackTrace();
            }
        }
    }

    private static File e(Context context, JSONObject jSONObject) {
        String absolutePath;
        try {
            String string = jSONObject.has("path") ? jSONObject.getString("path") : "";
            String string2 = jSONObject.has("version") ? jSONObject.getString("version") : "";
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(string).openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setConnectTimeout(nb.e);
            httpURLConnection.connect();
            int contentLength = httpURLConnection.getContentLength();
            httpURLConnection.disconnect();
            if (Environment.getExternalStorageState().equals("mounted")) {
                File externalStorageDirectory = Environment.getExternalStorageDirectory();
                absolutePath = String.valueOf(externalStorageDirectory.getParent()) + "/" + externalStorageDirectory.getName() + "/download";
            } else {
                absolutePath = context.getFilesDir().getAbsolutePath();
            }
            File file = new File(absolutePath, a.a(context.getPackageName(), string2, contentLength));
            if (file.exists()) {
                if (file.length() == contentLength) {
                    return file;
                }
            }
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "Something happended in checking existing version , you may ignore this");
            }
        }
        return null;
    }

    private synchronized void e(Context context) {
        f(context);
    }

    private synchronized void e(Context context, String str) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", t);
            jSONObject.put("appkey", str);
            int i2 = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
            String packageName = context.getPackageName();
            jSONObject.put(K, i2);
            jSONObject.put(G, packageName);
            jSONObject.put("sdk_version", UmengConstants.SDK_VERSION);
            jSONObject.put(J, m.c(context));
            jSONObject.put(I, m.g(context));
            jSONObject.put(Q, o(context));
            jSONObject.put(P, p(context));
            this.d.post(new l(this, context, jSONObject));
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "exception in onlineConfigInternal");
            }
        }
    }

    public static void enterPage(Context context, String str) {
        onEvent(context, "_PAGE_", str);
    }

    private void f(Context context) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", r);
            this.d.post(new l(this, context, jSONObject));
        } catch (JSONException e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "json error in emitCache");
            }
        }
    }

    private static void f(Context context, String str) {
        SharedPreferences a2 = a(context);
        if (str != null && !"".equals(str)) {
            a2.edit().putString(UmengConstants.AtomKey_User_ID, str).commit();
        } else if (UmengConstants.testMode) {
            Log.i(UmengConstants.LOG_TAG, "userID is null or empty");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void f(Context context, JSONObject jSONObject) {
        if (a(t, context, new String[0])) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "start to check onlineConfig info ...");
            }
            String a2 = a(context, jSONObject, UmengConstants.CONFIG_URL, true, t);
            if (a2 == null) {
                a2 = a(context, jSONObject, UmengConstants.CONFIG_URL_BACK, true, t);
            }
            if (a2 != null) {
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "get onlineConfig info succeed !");
                }
                d(context, a2);
            } else if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "get onlineConfig info failed !");
            }
        }
    }

    public static void flush(Context context) {
        if (context == null) {
            try {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "unexpected null context in flush");
                }
            } catch (Exception e2) {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "Exception occurred in Mobclick.flush(). ");
                    e2.printStackTrace();
                    return;
                }
                return;
            }
        }
        a.e(context);
    }

    private static JSONObject g(Context context) {
        String str;
        try {
            FileInputStream openFileInput = context.openFileInput(m(context));
            String str2 = "";
            byte[] bArr = new byte[16384];
            while (true) {
                str = str2;
                int read = openFileInput.read(bArr);
                if (read == -1) {
                    break;
                }
                str2 = String.valueOf(str) + new String(bArr, 0, read);
            }
            if (str.length() == 0) {
                return null;
            }
            try {
                return new JSONObject(str);
            } catch (JSONException e2) {
                openFileInput.close();
                h(context);
                e2.printStackTrace();
                return null;
            }
        } catch (FileNotFoundException e3) {
            return null;
        } catch (IOException e4) {
            return null;
        }
    }

    public static String getConfigParams(Context context, String str) {
        return n(context).getString(str, "");
    }

    public static JSONObject getUpdateInfo() {
        return k;
    }

    private static void h(Context context) {
        context.deleteFile(l(context));
        context.deleteFile(m(context));
    }

    private static SharedPreferences i(Context context) {
        return context.getSharedPreferences("mobclick_agent_header_" + context.getPackageName(), 0);
    }

    public static boolean isDownloadingAPK() {
        return a.b();
    }

    private static SharedPreferences j(Context context) {
        return context.getSharedPreferences("mobclick_agent_update_" + context.getPackageName(), 0);
    }

    private static SharedPreferences k(Context context) {
        return context.getSharedPreferences("mobclick_agent_state_" + context.getPackageName(), 0);
    }

    private static String l(Context context) {
        return "mobclick_agent_header_" + context.getPackageName();
    }

    private static String m(Context context) {
        return "mobclick_agent_cached_" + context.getPackageName();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static SharedPreferences n(Context context) {
        return context.getSharedPreferences("mobclick_agent_online_setting_" + context.getPackageName(), 0);
    }

    private static int o(Context context) {
        SharedPreferences n2 = n(context);
        return (!n2.contains(UmengConstants.Online_Config_Net_Policy) || n2.getInt(UmengConstants.Online_Config_Net_Policy, -1) == -1) ? n2.getInt(UmengConstants.Online_Config_Local_Policy, b) : n2.getInt(UmengConstants.Online_Config_Net_Policy, b);
    }

    public static void onError(Context context) {
        try {
            String b2 = m.b(context);
            if (b2 == null || b2.length() == 0) {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "unexpected empty appkey in onError");
                }
            } else if (context != null) {
                new k(context, b2, 2).start();
            } else if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "unexpected null context in onError");
            }
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Exception occurred in Mobclick.onError()");
                e2.printStackTrace();
            }
        }
    }

    public static void onEvent(Context context, String str) {
        onEvent(context, str, 1);
    }

    public static void onEvent(Context context, String str, int i2) {
        onEvent(context, str, null, i2);
    }

    public static void onEvent(Context context, String str, String str2) {
        if (str2 != null && str2 != "") {
            onEvent(context, str, str2, 1);
        } else if (UmengConstants.testMode) {
            Log.e(UmengConstants.LOG_TAG, "label is null or empty in onEvent(4p)");
        }
    }

    public static void onEvent(Context context, String str, String str2, int i2) {
        try {
            String b2 = m.b(context);
            if (b2 == null || b2.length() == 0) {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "unexpected empty appkey in onEvent(4p)");
                }
            } else if (context == null) {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "unexpected null context in onEvent(4p)");
                }
            } else if (str == null || str == "") {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "tag is null or empty in onEvent(4p)");
                }
            } else if (i2 > 0) {
                new k(context, b2, str, str2, i2, 3).start();
            } else if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Illegal value of acc in onEvent(4p)");
            }
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Exception occurred in Mobclick.onEvent(). ");
                e2.printStackTrace();
            }
        }
    }

    public static void onPause(Context context) {
        try {
            if (context != null) {
                new k(context, 0).start();
            } else if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "unexpected null context in onPause");
            }
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Exception occurred in Mobclick.onRause(). ");
                e2.printStackTrace();
            }
        }
    }

    public static void onResume(Context context) {
        onResume(context, m.b(context), m.g(context));
    }

    public static void onResume(Context context, String str, String str2) {
        try {
            UmengConstants.channel = str2;
            if (context == null) {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "unexpected null context in onResume");
                }
            } else if (str != null && str.length() != 0) {
                new k(context, str, str2, 1).start();
            } else if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "unexpected empty appkey in onResume");
            }
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Exception occurred in Mobclick.onResume(). ");
                e2.printStackTrace();
            }
        }
    }

    public static void openActivityDurationTrack(boolean z2) {
        UmengConstants.ACTIVITY_DURATION_OPEN = z2;
    }

    private static String p(Context context) {
        return n(context).getString(UmengConstants.Online_Config_Last_Modify, "");
    }

    public static void reportError(Context context, String str) {
        if (str == "" || str.length() > 10240) {
            return;
        }
        if (context != null) {
            a.b(context, str, v);
        } else if (UmengConstants.testMode) {
            Log.e(UmengConstants.LOG_TAG, "unexpected null context in reportError");
        }
    }

    public static void setAutoLocation(boolean z2) {
        mUseLocationService = z2;
    }

    public static void setDebugMode(boolean z2) {
        UmengConstants.testMode = z2;
    }

    public static void setDefaultReportPolicy(Context context, int i2) {
        if (i2 >= 0 && i2 <= 5) {
            b = i2;
            a(context, i2);
        } else if (UmengConstants.testMode) {
            Log.e(UmengConstants.LOG_TAG, "Illegal value of report policy");
        }
    }

    public static void setOnlineConfigureListener(UmengOnlineConfigureListener umengOnlineConfigureListener) {
        j = umengOnlineConfigureListener;
    }

    public static void setOpenGLContext(GL10 gl10) {
        if (gl10 != null) {
            String[] a2 = m.a(gl10);
            if (a2.length == 2) {
                GPU_VENDER = a2[0];
                GPU_RENDERER = a2[1];
            }
        }
    }

    public static void setSessionContinueMillis(long j2) {
        UmengConstants.kContinueSessionMillis = j2;
    }

    public static void setUpdateListener(UmengUpdateListener umengUpdateListener) {
        i = umengUpdateListener;
    }

    public static void setUpdateOnlyWifi(boolean z2) {
        mUpdateOnlyWifi = z2;
    }

    public static void showUpdateDialog(Context context) {
        if (k != null && k.has(n) && k.optString(n).toLowerCase().equals("yes")) {
            File e2 = e(context, k);
            if (e2 == null || !UmengConstants.enableCacheInUpdate) {
                b(context, k).show();
            } else {
                b(context, e2).show();
            }
        }
    }

    public static void update(Context context) {
        try {
            if (a.b()) {
                m.a(context);
                return;
            }
            if (mUpdateOnlyWifi && !m.f(context)[0].equals("Wi-Fi")) {
                if (i != null) {
                    i.onUpdateReturned(UpdateStatus.NoneWifi);
                }
            } else {
                if (context != null) {
                    a.a(context, m.b(context));
                    return;
                }
                if (i != null) {
                    i.onUpdateReturned(UpdateStatus.No);
                }
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "unexpected null context in update");
                }
            }
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Exception occurred in Mobclick.update(). " + e2.getMessage());
                e2.printStackTrace();
            }
        }
    }

    public static void update(Context context, long j2) {
        if (context != null) {
            new j(context, j2).start();
        } else if (UmengConstants.testMode) {
            Log.i(UmengConstants.LOG_TAG, "unexpected null Context");
        }
    }

    public static void update(Context context, String str) {
        UmengConstants.channel = str;
        update(context);
    }

    public static void updateOnlineConfig(Context context) {
        try {
            if (context == null) {
                Log.e(UmengConstants.LOG_TAG, "unexpected null context in updateOnlineConfig");
            } else {
                a.e(context, m.b(context));
            }
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "exception in updateOnlineConfig");
            }
        }
    }

    public static void updateOnlineConfig(Context context, String str) {
        UmengConstants.channel = str;
        updateOnlineConfig(context);
    }
}
