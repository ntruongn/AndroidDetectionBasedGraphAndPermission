package com.wooboo.adlib_android;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class yc extends Thread {
    private static final String z = z(z("\u001f&`0-\u0014&R\u0004+\u0015\u0001m\u0002!\u000bcq\u00046\u001715"));
    final n a;
    private final String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public yc(n nVar, String str) {
        this.a = nVar;
        this.b = str;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'x';
                    break;
                case 1:
                    c = 'C';
                    break;
                case 2:
                    c = 20;
                    break;
                case nb.p /* 3 */:
                    c = 'v';
                    break;
                default:
                    c = 'D';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'D');
        }
        return charArray;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        try {
            kb.a(n.b(this.a), this.b);
        } catch (Exception e) {
            mc.b(z);
        }
    }
}
