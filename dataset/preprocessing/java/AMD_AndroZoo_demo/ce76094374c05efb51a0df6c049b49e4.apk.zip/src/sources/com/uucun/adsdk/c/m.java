package com.uucun.adsdk.c;

import android.content.Context;
import java.net.SocketException;
import java.net.UnknownHostException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class m {
    public String a = m.class.getSimpleName();
    private Context b;

    public m(Context context) {
        this.b = null;
        this.b = context;
    }

    private String a(String str) {
        com.uucun.adsdk.b.h.c(this.a, "Switch Domain......");
        return com.uucun.adsdk.b.k.a().a(str);
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x00fd  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private java.lang.String b(java.lang.String r10, org.json.JSONObject r11) {
        /*
            Method dump skipped, instructions count: 294
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.uucun.adsdk.c.m.b(java.lang.String, org.json.JSONObject):java.lang.String");
    }

    public String a(String str, JSONObject jSONObject) {
        try {
            return b(str, jSONObject);
        } catch (SocketException e) {
            com.uucun.adsdk.b.h.c(this.a, "SocketException:" + e.getMessage());
            String a = a(str);
            if (a != null) {
                return b(a, jSONObject);
            }
            return null;
        } catch (UnknownHostException e2) {
            com.uucun.adsdk.b.h.c(this.a, "UnknownHostException:" + e2.getMessage());
            String a2 = a(str);
            if (a2 != null) {
                return b(a2, jSONObject);
            }
            return null;
        }
    }
}
