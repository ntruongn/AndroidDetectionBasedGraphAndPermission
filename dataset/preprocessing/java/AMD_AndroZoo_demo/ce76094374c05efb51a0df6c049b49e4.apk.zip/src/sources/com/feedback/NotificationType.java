package com.feedback;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public enum NotificationType {
    AlertDialog,
    NotificationBar;

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static NotificationType[] valuesCustom() {
        NotificationType[] valuesCustom = values();
        int length = valuesCustom.length;
        NotificationType[] notificationTypeArr = new NotificationType[length];
        System.arraycopy(valuesCustom, 0, notificationTypeArr, 0, length);
        return notificationTypeArr;
    }
}
