package com.uucun.adsdk.c;

import android.content.Context;
import android.text.TextUtils;
import com.uucun.adsdk.UpdatePointListener;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class g extends j {
    private UpdatePointListener a;

    public g(UpdatePointListener updatePointListener, String str, Context context) {
        super(context);
        this.a = null;
        this.a = updatePointListener;
        this.b = str;
    }

    @Override // com.uucun.adsdk.c.j
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public com.uucun.adsdk.d.b b(String str) {
        return com.uucun.adsdk.b.i.b(str);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public com.uucun.adsdk.d.b doInBackground(JSONObject... jSONObjectArr) {
        try {
            String string = jSONObjectArr[0].getString("app_key");
            String string2 = jSONObjectArr[0].getString("imei");
            if (string == null || TextUtils.isEmpty(string.trim()) || string2 == null || TextUtils.isEmpty(string2.trim())) {
                return null;
            }
            return (com.uucun.adsdk.d.b) a(jSONObjectArr[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void onPostExecute(com.uucun.adsdk.d.b bVar) {
        if (bVar == null) {
            com.uucun.adsdk.b.h.b("Get Points", "Point Result is null ");
            if (this.a != null) {
                this.a.onError("获取信息失败.");
                return;
            }
            return;
        }
        if (bVar.a == 1) {
            this.a.onSuccess(bVar.c, bVar.d);
            return;
        }
        if (bVar.a == 0) {
            if (bVar.b == null || TextUtils.isEmpty(bVar.b.trim())) {
                this.a.onError("获取信息失败.");
            } else {
                this.a.onError(bVar.b);
            }
        }
    }
}
