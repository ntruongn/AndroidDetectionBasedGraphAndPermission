package com.mobclick.android;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public enum Gender {
    Male,
    Female,
    Unknown;

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static Gender[] valuesCustom() {
        Gender[] valuesCustom = values();
        int length = valuesCustom.length;
        Gender[] genderArr = new Gender[length];
        System.arraycopy(valuesCustom, 0, genderArr, 0, length);
        return genderArr;
    }
}
