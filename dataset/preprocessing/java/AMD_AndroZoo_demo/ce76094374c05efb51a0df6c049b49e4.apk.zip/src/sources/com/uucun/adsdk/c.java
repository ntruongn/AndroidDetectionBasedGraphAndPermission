package com.uucun.adsdk;

import android.os.Handler;
import android.os.Message;
import com.wooboo.adlib_android.nb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class c extends Handler {
    final /* synthetic */ OfferActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(OfferActivity offerActivity) {
        this.a = offerActivity;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                this.a.c();
                return;
            case 2:
                this.a.b();
                return;
            case nb.p /* 3 */:
                this.a.a(message.arg1);
                return;
            default:
                return;
        }
    }
}
