package com.kuguo.b;

import java.util.LinkedList;
import java.util.Random;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class f extends LinkedList {
    final /* synthetic */ d a;
    private Thread b;
    private int c = new Random().nextInt();

    public f(d dVar) {
        this.a = dVar;
    }

    public void a() {
        while (!isEmpty()) {
            ((b) poll()).b();
        }
    }

    @Override // java.util.LinkedList, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List, java.util.Deque, java.util.Queue
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public boolean add(b bVar) {
        boolean add = super.add(bVar);
        if (add && this.b == null) {
            this.b = new g(this);
            this.b.start();
        }
        return add;
    }

    public void b() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= size()) {
                return;
            }
            b bVar = (b) get(i2);
            if (bVar.h() == -3) {
                remove(bVar);
                i2--;
            }
            i = i2 + 1;
        }
    }

    @Override // java.util.AbstractCollection
    public String toString() {
        return "HttpConnectionQueue@" + this.c;
    }
}
