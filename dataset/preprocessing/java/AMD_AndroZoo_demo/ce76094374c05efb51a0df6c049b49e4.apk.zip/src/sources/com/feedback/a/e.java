package com.feedback.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public enum e {
    PureSending,
    PureFail,
    HasFail,
    Normal;

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static e[] valuesCustom() {
        e[] valuesCustom = values();
        int length = valuesCustom.length;
        e[] eVarArr = new e[length];
        System.arraycopy(valuesCustom, 0, eVarArr, 0, length);
        return eVarArr;
    }
}
