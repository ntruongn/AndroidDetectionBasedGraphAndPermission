package com.wooboo.download;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public interface e {
    void a(String str);

    void a(String str, int i);

    void a(String str, int i, int i2);

    void b(String str);

    void c(String str);
}
