package com.uucun.adsdk.c;

import android.content.Context;
import android.text.TextUtils;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class c extends Thread {
    public String a = c.class.getSimpleName();
    private JSONObject b;
    private String c;
    private m d;
    private boolean e;
    private Context f;

    public c(Context context, String str, JSONObject jSONObject, boolean z) {
        this.b = null;
        this.c = null;
        this.d = null;
        this.e = false;
        this.f = null;
        this.c = str;
        this.b = jSONObject;
        this.d = new m(context);
        this.e = z;
        this.f = context;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        String string;
        String string2;
        if (this.e) {
            com.uucun.adsdk.b.c.a(this.b, this.f);
        }
        long currentTimeMillis = System.currentTimeMillis();
        try {
            string = this.b.getString("app_key");
            string2 = this.b.getString("imei");
        } catch (Exception e) {
            com.uucun.adsdk.b.h.b(this.a + " DataSendThread->", e.getMessage() + "");
        }
        if (string == null || TextUtils.isEmpty(string.trim()) || string2 == null || TextUtils.isEmpty(string2.trim())) {
            return;
        }
        this.d.a(this.c, this.b);
        com.uucun.adsdk.b.h.b(this.a, "Connection Time :" + (com.uucun.adsdk.b.h.a(currentTimeMillis) + " s") + " " + this.c);
    }
}
