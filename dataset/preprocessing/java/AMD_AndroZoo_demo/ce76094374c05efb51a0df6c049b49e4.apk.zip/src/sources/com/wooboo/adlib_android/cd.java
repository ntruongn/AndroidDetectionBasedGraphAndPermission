package com.wooboo.adlib_android;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class cd extends Thread {
    private static final String[] z = {z(z("a\u000f4*O`\u0011+-S")), z(z("=Zii\u00007Z5h\u00073\u0007\"(")), z(z("8Knj[\u007f\u0010w{\u0011#\u0011}u\u000e7S\u007f4\u0002?R5w\u0000 L%k\\")), z(z("#Rin\u000ej")), z(z("\u001d^v|\u000e\"R\u007f~A3Ssy\npjHVOp\u001fMs\r<\u001fnh\u0018pKu:\u0007?Svu\u0016p^tc\u00161F4")), z(z("1Q~h\u000e9[4s\u000f$ZtnO1\\ns\u000e>\u0011I_/\u0014")), z(z("\u0019\u001f{wA8Zh\u007f")), z(z("1Q~h\u000e9[4s\u000f$ZtnO1\\ns\u000e>\u0011^S \u001c")), z(z("\"Z{vA\u0005mV7_n")), z(z("#RiE\u0003?[c")), z(z("$Zv ")), z(z("#Rin\u000ej\u001f")), z(z("1Q~h\u000e9[4s\u000f$ZtnO5Gnh\u0000~zW[(\u001c")), z(z("y\u0019`'Pf")), z(z("\u0004W\u007f:\u00158M\u007f{\u0005pVi:\u0016\"Pt}A'W\u007ftA7Zn:\b>Oon\u0012$M\u007f{\fpYhu\fp")), z(z("\u0013Pov\u0005pQunA3Sui\u0004pLnh\u00041R")), z(z("9Lmu\u000e2Pu")), z(z("p]u~\u0018j")), z(z("1Q~h\u000e9[4s\u000f$ZtnO1\\ns\u000e>\u0011LS$\u0007")), z(z("\"Z{v4\u0002s")), z(z("\u0013Pov\u0005pQunA4Zn\u007f\u0013=Vt\u007fA6Vt{\rp\\vs\u0002;\u001f~\u007f\u0012$Vt{\u00159Pt:4\u0002s4:A\u0007VvvA$Mc:\u0015?\u001f|u\r<Pm:\u0000>Fm{\u0018~\u001f:")), z(z("1Q~h\u000e9[4s\u000f$ZtnO5Gnh\u0000~lOX+\u0015|N")), z(z("\u0013^t:\u000f?K:|\b>[:[\u0005\u0011\\ns\u00179Kc:\b>\u001f[t\u0005\"Ps~,1Qs|\u0004#K4b\f<")), z(z("1Q~h\u000e9[4s\u000f$ZtnO1\\ns\u000e>\u0011I_/\u0014kU")), z(z("1Q~h\u000e9[4s\u000f$ZtnO5Gnh\u0000~k_B5")), z(z("\u0013Pov\u0005pQunA9Qn\u007f\u000f$\u001fnuA"))};
    final hb a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public cd(hb hbVar) {
        this.a = hbVar;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'P';
                    break;
                case 1:
                    c = '?';
                    break;
                case 2:
                    c = 26;
                    break;
                case nb.p /* 3 */:
                    c = 26;
                    break;
                default:
                    c = 'a';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'a');
        }
        return charArray;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(25:1|2|3|(1:5)|6|7|8|(1:9)|(3:11|12|(13:14|(4:16|17|18|19)(1:229)|20|21|(3:23|24|25)(1:219)|(2:128|129)|(2:121|122)|(1:42)|43|(5:48|49|50|51|52)|109|110|(2:112|113)(1:116)))|231|232|233|234|20|21|(0)(0)|(0)|(0)|(0)|43|(7:45|46|48|49|50|51|52)|109|110|(0)(0)|(7:(0)|(0)|(0)|(0)|(0)|(0)|(0))) */
    /* JADX WARN: Code restructure failed: missing block: B:102:0x027a, code lost:
    
        if (r6 == false) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:108:0x02be, code lost:
    
        if (r6 == false) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:135:0x0155, code lost:
    
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.cd.z[20] + r13.a.e);
     */
    /* JADX WARN: Code restructure failed: missing block: B:136:0x016f, code lost:
    
        if (r5 != null) goto L237;
     */
    /* JADX WARN: Code restructure failed: missing block: B:137:0x0174, code lost:
    
        if (r3 != null) goto L220;
     */
    /* JADX WARN: Code restructure failed: missing block: B:138:0x0179, code lost:
    
        if (r2 != null) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:139:0x017b, code lost:
    
        r2.disconnect();
     */
    /* JADX WARN: Code restructure failed: missing block: B:141:0x0176, code lost:
    
        r3.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:143:0x0197, code lost:
    
        r2 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:144:0x0198, code lost:
    
        throw r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:146:0x0181, code lost:
    
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.cd.z[15] + r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:148:0x0171, code lost:
    
        r5.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:149:0x0491, code lost:
    
        r4 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:150:0x0492, code lost:
    
        r4 = r0;
        r0 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:152:0x019d, code lost:
    
        r0.printStackTrace();
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.cd.z[14] + r13.a.e);
     */
    /* JADX WARN: Code restructure failed: missing block: B:153:0x01ba, code lost:
    
        if (r5 != null) goto L232;
     */
    /* JADX WARN: Code restructure failed: missing block: B:154:0x01bf, code lost:
    
        if (r3 != null) goto L228;
     */
    /* JADX WARN: Code restructure failed: missing block: B:155:0x01c4, code lost:
    
        if (r2 != null) goto L90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:156:0x01c6, code lost:
    
        r2.disconnect();
        r0 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:157:0x04c9, code lost:
    
        r0 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:159:0x01c1, code lost:
    
        r3.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:161:0x01cc, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:162:0x01cd, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:164:0x01cf, code lost:
    
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.cd.z[15] + r4);
        r0 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:166:0x01bc, code lost:
    
        r5.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:168:0x047c, code lost:
    
        r0 = th;
     */
    /* JADX WARN: Code restructure failed: missing block: B:169:0x047d, code lost:
    
        r1 = r3;
        r4 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:173:0x01f5, code lost:
    
        r2.disconnect();
     */
    /* JADX WARN: Code restructure failed: missing block: B:176:0x01f0, code lost:
    
        r1.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:178:0x0211, code lost:
    
        r1 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:179:0x0212, code lost:
    
        throw r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:181:0x01fc, code lost:
    
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.cd.z[15] + r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:183:0x01eb, code lost:
    
        r5.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:185:0x01f9, code lost:
    
        r1 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:186:0x01fa, code lost:
    
        throw r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:188:0x04bb, code lost:
    
        r12 = r2;
        r2 = r3;
        r3 = r0;
        r0 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:190:0x00de, code lost:
    
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.cd.z[4] + r13.a.e);
     */
    /* JADX WARN: Code restructure failed: missing block: B:191:0x00f7, code lost:
    
        if (r5 != null) goto L246;
     */
    /* JADX WARN: Code restructure failed: missing block: B:192:0x00fc, code lost:
    
        if (r2 != null) goto L244;
     */
    /* JADX WARN: Code restructure failed: missing block: B:193:0x0101, code lost:
    
        if (r0 != null) goto L56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:194:0x0103, code lost:
    
        r0.disconnect();
     */
    /* JADX WARN: Code restructure failed: missing block: B:195:0x0106, code lost:
    
        r0 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:196:0x04cc, code lost:
    
        r0 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:198:0x00fe, code lost:
    
        r2.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:200:0x0137, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:201:0x0138, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:203:0x013a, code lost:
    
        com.wooboo.adlib_android.mc.b(com.wooboo.adlib_android.cd.z[15] + r3);
        r0 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:205:0x00f9, code lost:
    
        r5.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:207:0x0474, code lost:
    
        r1 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:208:0x0475, code lost:
    
        r4 = r3;
        r12 = r0;
        r0 = r1;
        r1 = r2;
        r2 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:222:0x04af, code lost:
    
        r0 = r2;
        r3 = null;
        r2 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:224:0x049e, code lost:
    
        r3 = null;
        r0 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:225:0x0488, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:226:0x0489, code lost:
    
        r3 = null;
        r4 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:227:0x0465, code lost:
    
        r0 = th;
     */
    /* JADX WARN: Code restructure failed: missing block: B:228:0x0466, code lost:
    
        r4 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x005b, code lost:
    
        if (r6 != false) goto L21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x005f, code lost:
    
        r5.write(r8, 0, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0063, code lost:
    
        r0 = r3.read(r8);
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0068, code lost:
    
        if (r0 != (-1)) goto L262;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x006a, code lost:
    
        if (r6 != false) goto L208;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x005f, code lost:
    
        r5.write(r8, 0, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x006c, code lost:
    
        r0 = new java.lang.String(r5.toByteArray());
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0075, code lost:
    
        com.wooboo.adlib_android.mc.c(com.wooboo.adlib_android.cd.z[8] + r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x034e, code lost:
    
        if (r6 == false) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x03c9, code lost:
    
        if (r6 == false) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x02f0, code lost:
    
        if (r6 == false) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:96:0x029a, code lost:
    
        if (r6 == false) goto L40;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:103:0x029c A[EXC_TOP_SPLITTER, FALL_THROUGH, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:112:0x00ce A[Catch: MalformedURLException -> 0x045c, TRY_LEAVE, TryCatch #26 {MalformedURLException -> 0x045c, blocks: (B:110:0x00c6, B:112:0x00ce), top: B:109:0x00c6 }] */
    /* JADX WARN: Removed duplicated region for block: B:116:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:121:0x0092 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:128:0x008d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:173:0x01f5 A[Catch: Exception -> 0x01fb, TRY_ENTER, TRY_LEAVE, TryCatch #32 {Exception -> 0x01fb, blocks: (B:183:0x01eb, B:176:0x01f0, B:173:0x01f5, B:179:0x0212, B:186:0x01fa), top: B:182:0x01eb, inners: #15, #29 }] */
    /* JADX WARN: Removed duplicated region for block: B:175:0x01f0 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:182:0x01eb A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:219:0x04d3  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0056  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0097 A[Catch: Exception -> 0x0215, TRY_ENTER, TRY_LEAVE, TryCatch #25 {Exception -> 0x0215, blocks: (B:129:0x008d, B:122:0x0092, B:42:0x0097, B:125:0x022d, B:132:0x0214), top: B:128:0x008d, inners: #16, #41 }] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x02f2 A[FALL_THROUGH, PHI: r0
      0x02f2: PHI (r0v44 java.lang.String) = (r0v33 java.lang.String), (r0v41 java.lang.String) binds: [B:49:0x00ad, B:81:0x02f0] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0350 A[FALL_THROUGH, PHI: r0
      0x0350: PHI (r0v43 java.lang.String) = (r0v33 java.lang.String), (r0v44 java.lang.String) binds: [B:49:0x00ad, B:64:0x034e] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:76:0x02c0 A[EXC_TOP_SPLITTER, FALL_THROUGH, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:82:0x03cb A[EXC_TOP_SPLITTER, FALL_THROUGH, PHI: r0
      0x03cb: PHI (r0v40 java.lang.String) = (r0v33 java.lang.String), (r0v43 java.lang.String) binds: [B:49:0x00ad, B:74:0x03c9] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:91:0x027c A[EXC_TOP_SPLITTER, FALL_THROUGH, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:97:0x0232 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v50, types: [java.net.URL] */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v56 */
    /* JADX WARN: Type inference failed for: r0v57 */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v89 */
    /* JADX WARN: Type inference failed for: r0v90 */
    /* JADX WARN: Type inference failed for: r0v91 */
    /* JADX WARN: Type inference failed for: r1v8, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v2 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v46 */
    /* JADX WARN: Type inference failed for: r4v48 */
    /* JADX WARN: Type inference failed for: r4v50 */
    /* JADX WARN: Type inference failed for: r4v64 */
    /* JADX WARN: Type inference failed for: r4v7, types: [java.lang.String] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x0068 -> B:27:0x005d). Please submit an issue!!! */
    @Override // java.lang.Thread, java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void run() {
        /*
            Method dump skipped, instructions count: 1272
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.cd.run():void");
    }
}
