package com.kuguo.openads;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.StateListDrawable;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import com.kuguo.ui.NavigationBar;
import com.mobclick.android.UmengConstants;
import com.wooboo.adlib_android.nb;
import java.io.DataInputStream;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class x extends com.kuguo.c.a implements View.OnClickListener, com.kuguo.b.c {
    private d c;
    private g d;
    private k e;
    private Handler f;
    private String g;

    public x(Context context, g gVar) {
        super(context);
        this.d = gVar;
        this.e = k.a(context);
        this.f = new Handler();
        this.g = "";
    }

    private String a(DataInputStream dataInputStream) {
        return new String(com.kuguo.d.d.a(dataInputStream, dataInputStream.readInt()), "utf-8");
    }

    private void a(int i) {
        this.f.post(new p(this, i));
    }

    private void a(Bitmap bitmap, int i) {
        this.f.post(new r(this, bitmap, i));
    }

    private void a(com.kuguo.b.b bVar) {
        try {
            DataInputStream dataInputStream = new DataInputStream(bVar.f());
            if (dataInputStream.readByte() == 0) {
                b(a(dataInputStream));
                int readInt = dataInputStream.readInt();
                int readInt2 = dataInputStream.readInt();
                a(readInt2);
                if (readInt > 0) {
                    HashMap hashMap = new HashMap();
                    for (int i = 0; i < readInt; i++) {
                        hashMap.put(a(dataInputStream), a(dataInputStream));
                    }
                    a(hashMap);
                }
                if (readInt2 > 0) {
                    for (int i2 = 0; i2 < readInt2; i2++) {
                        byte[] a = com.kuguo.d.d.a(dataInputStream, dataInputStream.readInt());
                        a(BitmapFactory.decodeByteArray(a, 0, a.length), i2);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            bVar.b();
        }
    }

    private void a(Map map) {
        this.f.post(new q(this, map));
    }

    private void b(String str) {
        this.f.post(new t(this, str));
    }

    @Override // com.kuguo.b.c
    public void a(com.kuguo.b.b bVar, int i) {
        switch (i) {
            case -4:
            case -2:
            case UmengConstants.RetrieveReplyBroadcast_Fail /* -1 */:
                return;
            case -3:
                Exception i2 = bVar.i();
                if (i2 != null) {
                    i2.printStackTrace();
                    return;
                }
                return;
            case 200:
                a(bVar);
                return;
            default:
                bVar.b();
                return;
        }
    }

    public void a(String str) {
        this.g = str;
    }

    @Override // com.kuguo.c.a
    public void b() {
        this.c.a(this.d.b);
        if (this.d.e != null) {
            this.c.a(this.d.e);
        }
        this.c.b(this.d.f);
        this.c.a(this.d.h);
        this.c.d(this.g);
        this.c.a().setOnClickListener(this);
        com.kuguo.b.h a = this.e.a("showDetail");
        a.a("appId", Integer.valueOf(this.d.i));
        com.kuguo.b.a aVar = new com.kuguo.b.a(this.a, a);
        aVar.a(this);
        new com.kuguo.b.d().a(aVar);
    }

    @Override // com.kuguo.c.a
    protected View c() {
        this.c = new d(this.a);
        return this.c;
    }

    @Override // com.kuguo.c.a
    public NavigationBar d() {
        NavigationBar navigationBar = new NavigationBar(this.a);
        Button button = new Button(this.a);
        navigationBar.b(button);
        button.setOnClickListener(new s(this));
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{16842919}, com.kuguo.d.e.b(this.a, "ads/back_btn_pressed.png"));
        stateListDrawable.addState(new int[]{16842910}, com.kuguo.d.e.b(this.a, "ads/back_btn.png"));
        button.setBackgroundDrawable(stateListDrawable);
        navigationBar.a(this.d.b);
        navigationBar.setBackgroundColor(Color.parseColor("#5297be"));
        return navigationBar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (this.d.l) {
            case 0:
                this.e.a(this.d);
                return;
            case 1:
                this.e.b(this.d.b + "已正在下载中...");
                return;
            case 2:
                this.e.a(this.e.c(this.d), this.d);
                return;
            case nb.p /* 3 */:
            default:
                return;
            case 4:
                this.e.b(this.d.b + "已经安装...");
                return;
        }
    }
}
