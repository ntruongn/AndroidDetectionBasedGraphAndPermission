package com.wooboo.adlib_android;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.method.SingleLineTransformationMethod;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.Timer;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class n extends RelativeLayout implements ib, View.OnTouchListener {
    static ProgressBar B = null;
    private static n P = null;
    private static Context Q = null;
    public static ViewGroup S = null;
    public static final int X = 11100;
    public static final int Y = 11200;
    public static final int Z = 11300;
    private static final int a = -1;
    public static final int ab = 11400;
    private static final int b = -16777216;
    private static long bb = 0;
    private static final int c = 127;
    private static int cb = 0;
    private static final double d = 0.4375d;
    private static final int e = -1;
    private static final float g = 15.0f;
    private static final float i = 11.0f;
    private static final int j = -19456;
    private static final int k = -1147097;
    private static final int l = -16777216;
    private static final int m = -1147097;
    private static final float n = 3.0f;
    private static final float o = 3.0f;
    protected static hb v;
    private ImageView A;
    private int C;
    private boolean D;
    private boolean E;
    private ImageView F;
    private String G;
    private String H;
    private String I;
    private h J;
    private LinearLayout K;
    private pc L;
    private byte[] M;
    private qb N;
    private int O;
    private Context R;
    private float T;
    private Timer V;
    protected gb eb;
    private int p;
    private int q;
    private Drawable r;
    private Drawable s;
    private Drawable t;
    private Drawable u;
    private TextView w;
    private TextView x;
    private TextView y;
    private i z;
    private static final String[] fb = {z(z("\u0005\u000b\u0016nT9\u0000\u000f|H\n\u000b\u0001o\b\u0016\n\u0007")), z(z("1\u000b\u000fiI\t(\u000fhG\n7\u0005yP\u000f\u0007\u0005+u\u0012\u0005\u0012\u007f")), z(z("1\u000b\u000fiI\t7\u0005yP\u000f\u0007\u0005+u\u0012\u0005\u0012\u007f")), z(z("載互嶒组中輛ｨ讗刻中輛义徣宂裣")), z(z("\u0015\u0010\u000f{a/\"3cI\u0011D\u0005yT\t\u0016A")), z(z("掶神")), z(z("\u0013\u0016\f圻坦霸沱ｬ丆胛乭輙")), z(z("砈対")), z(z("斆7$卪旆河乯輝")), z(z("厰淬")), z(z("伆砊寺覊中輛味ｿ")), z(z("\u0000\n")), z(z("\u0002\n")), z(z("\u0007\u0000\to")), z(z("\u0005\u0005")), z(z("\u0015\u0001\u0003")), z(z("\u0013\u0016\f")), z(z("\u0005\r")), z(z("H\t\u0010?")), z(z("H\u0014\u000el")), z(z("I\u0010\u0005xRH\t\u0010?")), z(z("H4.L")), z(z("H#)M")), z(z("I\u0010\u0005xRHW\u0007{")), z(z("H\u000e\u0010l")), z(z("H)0?")), z(z("\u0011\u000b\u000fiI\t;\u0002dR\u0012\u000b\r%V\b\u0003")), z(z("\u0015\u0000\u0003jT\u0002IM5R\u000e\u0001@xB\u0005\u0005\u0012o\u0006\u000f\u0017\u000e,RF\t\u000f~H\u0012\u0001\u0004")), z(z("HW'[")), z(z("H&-[")), z(z("H\u0003\tm")), z(z("\u0012\u0001\fnG\u0002;\u0002dR\u0012\u000b\r%V\b\u0003")), z(z("H\u0006\r{")), z(z("H.0L")), z(z("HW\u0007{")), z(z("\u0011\u000b\u000fiI\t;\fdA\tJ\u0010eA")), z(z("\u0012\u0001\fnG\u0002J\u0010eA")), z(z("\u0011\u000b\u000fiI\t;Q%V\b\u0003")), z(z("\u0011\u000b\u000fiI\tJ\u0010eA")), z(z("\u0012\u0001\fnG\u0002;Q%V\b\u0003")), z(z("\u0012\u0001\fnG\u0002;\fdA\tJ\u0010eA"))};
    private static final Typeface f = Typeface.create(Typeface.SANS_SERIF, 1);
    private static final Typeface h = Typeface.create(Typeface.SANS_SERIF, 0);
    private static RelativeLayout U = null;
    protected static boolean W = true;
    public static Handler db = new b();

    public n(hb hbVar, Context context, boolean z, int i2, double d2, boolean z2, byte[] bArr, int i3, qb qbVar) {
        super(context);
        this.p = -16777216;
        this.q = -1;
        this.z = null;
        this.A = null;
        this.M = null;
        this.O = 0;
        this.V = null;
        P = this;
        this.N = qbVar;
        this.O = i3;
        cb = i2;
        if (this.L == null) {
            this.L = pc.a(context, (String) null);
        }
        this.E = z;
        if (z2) {
            this.G = fb[35];
            if (z) {
                this.H = fb[37];
            } else {
                this.H = fb[38];
            }
        } else {
            this.G = fb[40];
            if (z) {
                this.H = fb[39];
            } else {
                this.H = fb[36];
            }
        }
        this.M = bArr;
        a(hbVar, context, i2, d2);
    }

    private Drawable a(Rect rect, int i2, int i3) {
        return a(rect, i2, i3, false);
    }

    private Drawable a(Rect rect, int i2, int i3, boolean z) {
        WeakReference weakReference = new WeakReference(Bitmap.createBitmap(rect.width(), rect.height(), Bitmap.Config.ARGB_8888));
        Canvas canvas = new Canvas((Bitmap) weakReference.get());
        if (!this.E && this.O == 0) {
            a(canvas, rect, i2, i3);
        }
        if (z) {
            a(canvas, rect);
        }
        return (Drawable) new WeakReference(new BitmapDrawable((Bitmap) weakReference.get())).get();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(long j2) {
        bb = j2;
    }

    private void a(Context context, double d2, int i2) {
        Bitmap bitmap = null;
        if (0 == 0) {
            try {
                bitmap = BitmapFactory.decodeStream(getContext().getAssets().open(this.G));
            } catch (Error e2) {
                return;
            } catch (Exception e3) {
                return;
            }
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams((int) (bitmap.getWidth() * d2), (int) (bitmap.getHeight() * d2));
        if (i2 > 0) {
        }
        this.A = new ImageView(context);
        this.A.setLayoutParams(layoutParams);
        this.A.setBackgroundDrawable(new BitmapDrawable(bitmap));
        this.K.addView(this.A);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00c9 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:61:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:66:0x00d6 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v52, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v58, types: [android.graphics.Bitmap] */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.io.ByteArrayInputStream] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void a(android.content.Context r9, int r10, double r11, int r13, java.lang.String r14) {
        /*
            Method dump skipped, instructions count: 465
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.n.a(android.content.Context, int, double, int, java.lang.String):void");
    }

    private static void a(Canvas canvas, Rect rect) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(-1147097);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3.0f);
        paint.setPathEffect(new CornerPathEffect(3.0f));
        Path path = new Path();
        path.addRoundRect(new RectF(rect), 3.0f, 3.0f, Path.Direction.CW);
        canvas.drawPath(path, paint);
    }

    private static void a(Canvas canvas, Rect rect, int i2, int i3) {
        Paint paint = new Paint();
        paint.setColor(i2);
        paint.setAntiAlias(true);
        canvas.drawRect(rect, paint);
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.argb((int) c, Color.red(i3), Color.green(i3), Color.blue(i3)), i3});
        int height = ((int) (rect.height() * d)) + rect.top;
        gradientDrawable.setBounds(rect.left, rect.top, rect.right, height);
        gradientDrawable.draw(canvas);
        Rect rect2 = new Rect(rect.left, height, rect.right, rect.bottom);
        Paint paint2 = new Paint();
        paint2.setColor(i3);
        canvas.drawRect(rect2, paint2);
    }

    private void a(hb hbVar, Context context) {
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.weight = 1.0f;
        layoutParams.leftMargin = 3;
        layoutParams.rightMargin = 2;
        linearLayout.setLayoutParams(layoutParams);
        this.w = new TextView(context);
        this.w.setText(hbVar.g());
        this.w.setTypeface(f);
        this.w.setTextColor(this.q);
        this.w.setTextSize(g);
        this.w.setTransformationMethod(SingleLineTransformationMethod.getInstance());
        this.w.setSingleLine(true);
        this.w.setPadding(0, 0, 0, -2);
        this.x = new TextView(context);
        this.x.setTypeface(h);
        this.x.setPadding(0, 0, 0, 0);
        this.x.setTextColor(this.q);
        this.x.setTextSize(i);
        this.x.setSingleLine(true);
        this.y = new TextView(context);
        this.y.setTypeface(h);
        this.y.setPadding(0, 0, 0, 0);
        this.y.setTextColor(this.q);
        this.y.setTextSize(i);
        this.y.setSingleLine(true);
        linearLayout.addView(this.w);
        String f2 = hbVar.f();
        if (this.E) {
            if (f2.length() <= 20) {
                this.x.setText(f2);
                linearLayout.addView(this.x);
            } else {
                String substring = f2.substring(0, 20);
                String substring2 = f2.substring(20);
                this.x.setText(substring);
                this.y.setText(substring2);
                TranslateAnimation translateAnimation = new TranslateAnimation(1, 0.0f, 1, 0.0f, 1, 1.0f, 1, 0.0f);
                translateAnimation.setDuration(1000L);
                AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
                alphaAnimation.setDuration(1000L);
                TranslateAnimation translateAnimation2 = new TranslateAnimation(1, 0.0f, 1, 0.0f, 1, 0.0f, 1, -1.0f);
                translateAnimation2.setDuration(1000L);
                AlphaAnimation alphaAnimation2 = new AlphaAnimation(1.0f, 0.0f);
                alphaAnimation2.setDuration(1000L);
                AnimationSet animationSet = new AnimationSet(true);
                animationSet.addAnimation(translateAnimation);
                animationSet.addAnimation(alphaAnimation);
                AnimationSet animationSet2 = new AnimationSet(true);
                animationSet2.addAnimation(translateAnimation2);
                animationSet2.addAnimation(alphaAnimation2);
                ViewFlipper viewFlipper = new ViewFlipper(context);
                viewFlipper.setFlipInterval(4000);
                viewFlipper.addView(this.x);
                viewFlipper.addView(this.y);
                linearLayout.addView(viewFlipper);
                viewFlipper.startFlipping();
                viewFlipper.setInAnimation(animationSet);
                viewFlipper.setOutAnimation(animationSet2);
            }
        } else if (f2.length() <= 23) {
            this.x.setText(f2);
            linearLayout.addView(this.x);
        } else {
            String substring3 = f2.substring(0, 23);
            String substring4 = f2.substring(23);
            this.x.setText(substring3);
            this.y.setText(substring4);
            TranslateAnimation translateAnimation3 = new TranslateAnimation(1, 0.0f, 1, 0.0f, 1, 1.0f, 1, 0.0f);
            translateAnimation3.setDuration(1000L);
            AlphaAnimation alphaAnimation3 = new AlphaAnimation(0.0f, 1.0f);
            alphaAnimation3.setDuration(1000L);
            TranslateAnimation translateAnimation4 = new TranslateAnimation(1, 0.0f, 1, 0.0f, 1, 0.0f, 1, -1.0f);
            translateAnimation4.setDuration(1000L);
            AlphaAnimation alphaAnimation4 = new AlphaAnimation(1.0f, 0.0f);
            alphaAnimation4.setDuration(1000L);
            AnimationSet animationSet3 = new AnimationSet(true);
            animationSet3.addAnimation(translateAnimation3);
            animationSet3.addAnimation(alphaAnimation3);
            AnimationSet animationSet4 = new AnimationSet(true);
            animationSet4.addAnimation(translateAnimation4);
            animationSet4.addAnimation(alphaAnimation4);
            ViewFlipper viewFlipper2 = new ViewFlipper(context);
            viewFlipper2.setFlipInterval(4000);
            viewFlipper2.addView(this.x);
            viewFlipper2.addView(this.y);
            linearLayout.addView(viewFlipper2);
            viewFlipper2.startFlipping();
            viewFlipper2.setInAnimation(animationSet3);
            viewFlipper2.setOutAnimation(animationSet4);
        }
        this.K.addView(linearLayout);
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x00c4 A[Catch: Exception -> 0x0106, TRY_LEAVE, TryCatch #3 {Exception -> 0x0106, blocks: (B:13:0x00b4, B:15:0x00c4), top: B:12:0x00b4 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void a(com.wooboo.adlib_android.hb r11, android.content.Context r12, int r13, double r14) {
        /*
            Method dump skipped, instructions count: 282
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.n.a(com.wooboo.adlib_android.hb, android.content.Context, int, double):void");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(n nVar) {
        nVar.l();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(n nVar, h hVar) {
        nVar.J = hVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(n nVar, boolean z) {
        nVar.D = z;
    }

    public static void a(String str) {
        if (!kb.a()) {
            Toast.makeText(Q, fb[8], 0).show();
            return;
        }
        if (!kb.a(str)) {
            Toast.makeText(Q, fb[6], 0).show();
        } else {
            if (WoobooAdView.n) {
                return;
            }
            Looper.prepare();
            new AlertDialog.Builder(Q).setTitle(fb[5]).setMessage(fb[10]).setPositiveButton(fb[7], new y(str)).setNegativeButton(fb[9], new z()).setOnCancelListener(new ab()).show();
            Looper.loop();
        }
    }

    /* JADX WARN: Can't wrap try/catch for region: R(12:(8:134|(2:136|(2:138|(3:140|141|143)(1:146))(1:147))|106|60|(1:62)|101|64|(3:66|67|69)(1:72))|(8:114|(2:116|(2:118|(3:120|121|123)(1:126))(1:127))|106|60|(0)|101|64|(0)(0))|29|(3:31|32|(3:34|35|(2:37|(2:39|(1:41)))))|57|58|59|60|(0)|101|64|(0)(0)) */
    /* JADX WARN: Code restructure failed: missing block: B:104:0x02ad, code lost:
    
        setVisibility(8);
     */
    /* JADX WARN: Code restructure failed: missing block: B:105:0x02b2, code lost:
    
        if (r2 == false) goto L150;
     */
    /* JADX WARN: Code restructure failed: missing block: B:128:0x0213, code lost:
    
        if (r2 != false) goto L183;
     */
    /* JADX WARN: Code restructure failed: missing block: B:148:0x0197, code lost:
    
        if (r2 != false) goto L154;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x025b, code lost:
    
        if (r11.contains(com.wooboo.adlib_android.n.fb[29]) == false) goto L134;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x02b4, code lost:
    
        setFocusable(false);
        setVisibility(8);
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x02bd, code lost:
    
        if (0 == 0) goto L194;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x02bf, code lost:
    
        r3.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00d2, code lost:
    
        if (r2 != false) goto L31;
     */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00b9 A[Catch: all -> 0x02cd, Error -> 0x02d3, Exception -> 0x02d7, TryCatch #27 {Error -> 0x02d3, Exception -> 0x02d7, all -> 0x02cd, blocks: (B:60:0x0090, B:62:0x00b9, B:64:0x00ed, B:101:0x00d4, B:166:0x0083), top: B:165:0x0083 }] */
    /* JADX WARN: Removed duplicated region for block: B:66:0x00f7 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:72:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void a(java.lang.String r11, android.content.Context r12, double r13) {
        /*
            Method dump skipped, instructions count: 736
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.n.a(java.lang.String, android.content.Context, double):void");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static byte[] b(n nVar) {
        return nVar.M;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static h c(n nVar) {
        return nVar.J;
    }

    public static ViewGroup d() {
        return S;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static i d(n nVar) {
        return nVar.z;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean e(n nVar) {
        return nVar.D;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static qb f(n nVar) {
        return nVar.N;
    }

    private void f() {
        this.r = null;
        this.t = null;
        this.s = null;
        this.u = null;
    }

    private void k() {
        try {
            if (p() != null) {
                this.eb.onHideChoseButton();
            }
            U = new RelativeLayout(Q);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
            U.setGravity(16);
            U.setLayoutParams(layoutParams);
            U.setOnTouchListener(new eb(this));
            U.setBackgroundColor(-7829368);
            U.getBackground().setAlpha(200);
            ImageView imageView = new ImageView(Q);
            Bitmap bitmap = null;
            try {
                bitmap = BitmapFactory.decodeStream(getResources().getAssets().open(fb[0]));
            } catch (IOException e2) {
                e2.printStackTrace();
            }
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams((int) (bitmap.getWidth() * this.T), (int) (bitmap.getHeight() * this.T));
            layoutParams2.addRule(11);
            layoutParams2.addRule(8);
            imageView.setImageDrawable(new BitmapDrawable(bitmap));
            imageView.setLayoutParams(layoutParams2);
            imageView.setOnClickListener(new fb(this));
            U.addView(imageView);
            addView(U);
            this.V = new Timer();
            this.V.schedule(new nd(this), 30000L);
            m();
        } catch (IOException e3) {
            throw e3;
        }
    }

    private void l() {
        if (p() != null) {
            this.eb.onShowChoseButton();
        }
        if (this.V == null && U == null) {
            return;
        }
        U.setVisibility(4);
        if (this.V != null) {
            this.V.cancel();
            this.V = null;
        }
        removeView(U);
        U = null;
        n();
    }

    private void o() {
        if (v != null && v.g == 3) {
            k();
            return;
        }
        if (v == null || !isPressed()) {
            return;
        }
        setPressed(false);
        if (this.D) {
            return;
        }
        this.D = true;
        if (this.N != null) {
            this.N.closeAd();
        }
        v.m();
        this.D = false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Context q() {
        return Q;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static n r() {
        return P;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long s() {
        return bb;
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i2 = 0; length > i2; i2++) {
            char c3 = cArr[i2];
            switch (i2 % 5) {
                case 0:
                    c2 = 'f';
                    break;
                case 1:
                    c2 = 'd';
                    break;
                case 2:
                    c2 = '`';
                    break;
                case nb.p /* 3 */:
                    c2 = 11;
                    break;
                default:
                    c2 = '&';
                    break;
            }
            cArr[i2] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '&');
        }
        return charArray;
    }

    @Override // com.wooboo.adlib_android.ib
    public void a() {
        post(new ad(this));
    }

    public void a(int i2) {
        this.q = (-16777216) | i2;
        if (this.w != null) {
            this.w.setTextColor(this.q);
        }
        if (this.x != null) {
            this.x.setTextColor(this.q);
        }
        if (this.y != null) {
            this.y.setTextColor(this.q);
        }
        postInvalidate();
    }

    @Override // com.wooboo.adlib_android.ib
    public void a(Context context, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.R = context;
        Message message = new Message();
        message.what = ab;
        Bundle bundle = new Bundle();
        bundle.putString(fb[16], str);
        bundle.putString(fb[12], str2);
        bundle.putString(fb[11], str3);
        bundle.putString(fb[13], str4);
        bundle.putString(fb[14], str5);
        bundle.putString(fb[17], str6);
        bundle.putString(fb[15], str7);
        message.setData(bundle);
        db.sendMessage(message);
    }

    public void a(ViewGroup viewGroup) {
        S = viewGroup;
    }

    public void a(gb gbVar) {
        this.eb = gbVar;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        Context context = this.R;
        if (com.wooboo.download.h.a(context)) {
            pc a2 = pc.a(context, com.wooboo.download.h.b());
            if (a2.a(str, str2, str3, str4, str5, str6, str7)) {
                a2.b(str2);
                String g2 = a2.g(str);
                if (g2 != null) {
                    com.wooboo.download.f a3 = com.wooboo.download.f.a(context, (com.wooboo.download.g) null, a2, com.wooboo.download.h.b(context));
                    if (a3 != null) {
                        a3.c(g2);
                    } else {
                        Toast.makeText(context, fb[3], 0).show();
                    }
                }
            } else {
                com.wooboo.download.h.a(context);
            }
            mc.c(fb[2]);
            return;
        }
        pc a4 = pc.a(context, (String) null);
        if (a4.a(str, str2, str3, str4, str5, str6, str7)) {
            a4.b(str2);
            String g3 = a4.g(str);
            if (g3 != null) {
                com.wooboo.download.f a5 = com.wooboo.download.f.a(context, (com.wooboo.download.g) null, a4, com.wooboo.download.h.b(context));
                if (a5 != null) {
                    a5.c(g3);
                } else {
                    Toast.makeText(context, fb[3], 0).show();
                }
            }
        } else {
            com.wooboo.download.j.a(context).b();
        }
        mc.c(fb[1]);
    }

    @Override // com.wooboo.adlib_android.ib
    public void b() {
        post(new zc(this));
    }

    @Override // com.wooboo.adlib_android.ib
    public void c() {
        Message message = new Message();
        message.what = Z;
        db.sendMessage(message);
    }

    public void e() {
        f();
        if (this.z != null && this.z.getBackground() != null) {
            this.z.getBackground().setCallback(null);
            this.z.setBackgroundDrawable(null);
        }
        if (this.A == null || this.A.getBackground() == null) {
            return;
        }
        this.A.getBackground().setCallback(null);
        this.A.setBackgroundDrawable(null);
    }

    public void g() {
        if (this.z != null) {
            this.z.a();
        }
    }

    public void h() {
        try {
            if (this.z != null) {
                try {
                    this.z.b();
                    if (this.z.getBackground() != null) {
                        this.z.getBackground().setCallback(null);
                        this.z.setBackgroundDrawable(null);
                    }
                    this.z = null;
                } catch (Exception e2) {
                    throw e2;
                }
            }
        } catch (Exception e3) {
            mc.b(fb[4]);
        }
    }

    public int i() {
        return this.q;
    }

    protected hb j() {
        return v;
    }

    protected void m() {
        W = false;
    }

    protected void n() {
        W = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
        if (this.J != null) {
            this.J.a();
        }
    }

    @Override // android.view.View
    protected void onFocusChanged(boolean z, int i2, Rect rect) {
        super.onFocusChanged(z, i2, rect);
        if (this.E || this.O != 0) {
            return;
        }
        if (z) {
            setBackgroundDrawable(this.s);
        } else {
            setBackgroundDrawable(this.r);
        }
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (i2 == 66 || i2 == 23) {
            setPressed(true);
        }
        return super.onKeyDown(i2, keyEvent);
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i2, KeyEvent keyEvent) {
        if (i2 == 66 || i2 == 23) {
            o();
        }
        setPressed(false);
        return super.onKeyUp(i2, keyEvent);
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (this.w != null) {
            Typeface typeface = this.w.getTypeface();
            String g2 = v.g();
            if (g2 != null) {
                Paint paint = new Paint();
                paint.setTypeface(typeface);
                paint.setTextSize(this.w.getTextSize());
                if (paint.measureText(g2) > i2 - (this.C * 2)) {
                }
            }
        }
        if (i2 == 0 || i3 == 0 || this.E || this.O != 0) {
            return;
        }
        Rect rect = new Rect(0, 0, i2, i3);
        f();
        this.r = a(rect, -1, this.p);
        this.t = a(rect, -1147097, j);
        this.s = a(rect, -1, this.p, true);
        setBackgroundDrawable(this.r);
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (view == this.K) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            int left = getLeft();
            int top = getTop();
            int right = getRight();
            int bottom = getBottom();
            if (motionEvent.getAction() == 0) {
                setPressed(true);
                return true;
            }
            if (motionEvent.getAction() == 1) {
                if (x < left || x > right || y < top || y > bottom) {
                    setPressed(false);
                }
                if (isPressed()) {
                    o();
                }
                setPressed(false);
                return true;
            }
            if (motionEvent.getAction() == 2) {
                if (x >= left && x <= right && y >= top && y <= bottom) {
                    return true;
                }
                setPressed(false);
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        if (i2 == 0) {
            g();
        }
    }

    public gb p() {
        return this.eb;
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        this.p = (-16777216) | i2;
    }

    @Override // android.view.View
    public void setPressed(boolean z) {
        Drawable drawable;
        if ((z && this.D) || isPressed() == z) {
            return;
        }
        Drawable drawable2 = this.r;
        int i2 = this.q;
        if (z) {
            this.u = getBackground();
            drawable = this.t;
            i2 = -16777216;
        } else {
            drawable = this.u;
        }
        setBackgroundDrawable(drawable);
        if (this.w != null) {
            this.w.setTextColor(i2);
        }
        if (this.x != null) {
            this.x.setTextColor(i2);
        }
        if (this.y != null) {
            this.y.setTextColor(i2);
        }
        super.setPressed(z);
        invalidate();
    }
}
