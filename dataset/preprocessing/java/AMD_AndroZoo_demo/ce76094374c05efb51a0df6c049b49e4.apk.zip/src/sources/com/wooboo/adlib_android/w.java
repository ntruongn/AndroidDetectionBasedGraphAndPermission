package com.wooboo.adlib_android;

import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class w implements View.OnClickListener {
    final m a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public w(m mVar) {
        this.a = mVar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        AdActivity.c(m.a(this.a)).loadUrl(AdActivity.c(m.a(this.a)).getUrl());
    }
}
