package com.wooboo.adlib_android;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
final class gc {
    private static final String z = z(z("h^\u00005"));

    private gc() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gc(gc gcVar) {
        this();
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 6;
                    break;
                case 1:
                    c = '+';
                    break;
                case 2:
                    c = 'l';
                    break;
                case nb.p /* 3 */:
                    c = 'Y';
                    break;
                default:
                    c = '(';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '(');
        }
        return charArray;
    }

    protected final Object clone() {
        return this;
    }

    public boolean equals(Object obj) {
        return obj == null || obj == this;
    }

    public String toString() {
        return z;
    }
}
