package com.wooboo.adlib_android;

import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class v implements View.OnClickListener {
    final m a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public v(m mVar) {
        this.a = mVar;
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x0037, code lost:
    
        if (r0 != false) goto L6;
     */
    @Override // android.view.View.OnClickListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onClick(android.view.View r5) {
        /*
            r4 = this;
            boolean r0 = com.wooboo.adlib_android.sc.C
            com.wooboo.adlib_android.m r1 = r4.a
            com.wooboo.adlib_android.AdActivity r1 = com.wooboo.adlib_android.m.a(r1)
            android.webkit.WebView r1 = com.wooboo.adlib_android.AdActivity.c(r1)
            r1.goForward()
            com.wooboo.adlib_android.m r1 = r4.a
            com.wooboo.adlib_android.AdActivity r1 = com.wooboo.adlib_android.m.a(r1)
            android.webkit.WebView r1 = com.wooboo.adlib_android.AdActivity.c(r1)
            boolean r1 = r1.canGoForward()
            if (r1 == 0) goto L39
            com.wooboo.adlib_android.m r1 = r4.a
            com.wooboo.adlib_android.AdActivity r1 = com.wooboo.adlib_android.m.a(r1)
            android.widget.Button r1 = r1.l
            android.graphics.drawable.BitmapDrawable r2 = new android.graphics.drawable.BitmapDrawable
            com.wooboo.adlib_android.m r3 = r4.a
            com.wooboo.adlib_android.AdActivity r3 = com.wooboo.adlib_android.m.a(r3)
            android.graphics.Bitmap r3 = r3.m
            r2.<init>(r3)
            r1.setBackgroundDrawable(r2)
            if (r0 == 0) goto L51
        L39:
            com.wooboo.adlib_android.m r1 = r4.a
            com.wooboo.adlib_android.AdActivity r1 = com.wooboo.adlib_android.m.a(r1)
            android.widget.Button r1 = r1.l
            android.graphics.drawable.BitmapDrawable r2 = new android.graphics.drawable.BitmapDrawable
            com.wooboo.adlib_android.m r3 = r4.a
            com.wooboo.adlib_android.AdActivity r3 = com.wooboo.adlib_android.m.a(r3)
            android.graphics.Bitmap r3 = r3.n
            r2.<init>(r3)
            r1.setBackgroundDrawable(r2)
        L51:
            com.wooboo.adlib_android.m r1 = r4.a
            com.wooboo.adlib_android.AdActivity r1 = com.wooboo.adlib_android.m.a(r1)
            android.webkit.WebView r1 = com.wooboo.adlib_android.AdActivity.c(r1)
            boolean r1 = r1.canGoBack()
            if (r1 == 0) goto L7b
            com.wooboo.adlib_android.m r1 = r4.a
            com.wooboo.adlib_android.AdActivity r1 = com.wooboo.adlib_android.m.a(r1)
            android.widget.Button r1 = r1.i
            android.graphics.drawable.BitmapDrawable r2 = new android.graphics.drawable.BitmapDrawable
            com.wooboo.adlib_android.m r3 = r4.a
            com.wooboo.adlib_android.AdActivity r3 = com.wooboo.adlib_android.m.a(r3)
            android.graphics.Bitmap r3 = r3.j
            r2.<init>(r3)
            r1.setBackgroundDrawable(r2)
            if (r0 == 0) goto L93
        L7b:
            com.wooboo.adlib_android.m r0 = r4.a
            com.wooboo.adlib_android.AdActivity r0 = com.wooboo.adlib_android.m.a(r0)
            android.widget.Button r0 = r0.i
            android.graphics.drawable.BitmapDrawable r1 = new android.graphics.drawable.BitmapDrawable
            com.wooboo.adlib_android.m r2 = r4.a
            com.wooboo.adlib_android.AdActivity r2 = com.wooboo.adlib_android.m.a(r2)
            android.graphics.Bitmap r2 = r2.k
            r1.<init>(r2)
            r0.setBackgroundDrawable(r1)
        L93:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.v.onClick(android.view.View):void");
    }
}
