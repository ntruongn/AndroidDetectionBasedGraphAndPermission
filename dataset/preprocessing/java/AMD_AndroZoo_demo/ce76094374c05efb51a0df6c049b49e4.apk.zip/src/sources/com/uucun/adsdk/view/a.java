package com.uucun.adsdk.view;

import android.os.Handler;
import android.os.Message;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a extends WebViewClient {
    final /* synthetic */ OfferwallView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(OfferwallView offerwallView) {
        this.a = offerwallView;
    }

    @Override // android.webkit.WebViewClient
    public void onPageFinished(WebView webView, String str) {
        Handler handler;
        long j;
        long j2;
        super.onPageFinished(webView, str);
        new k(this).start();
        Message message = new Message();
        message.what = 1;
        handler = this.a.d;
        handler.sendMessage(message);
        j = this.a.f;
        if (j == -1) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        j2 = this.a.f;
        String sb2 = sb.append(com.uucun.adsdk.b.h.a(j2)).append(" s").toString();
        this.a.f = -1L;
        com.uucun.adsdk.b.h.b(OfferwallView.a, "Offerwall Connection Time:" + sb2 + " " + str);
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedError(WebView webView, int i, String str, String str2) {
        if (i < 0) {
            if (com.uucun.adsdk.b.k.a().b()) {
                this.a.loadData("<html><meta charset=\"UTF-8\" /><center>载入页面出错,请重试.</center></html>", "text/html", "utf-8");
            } else {
                com.uucun.adsdk.b.k.a().a(webView.getUrl());
                this.a.b();
            }
        }
    }
}
