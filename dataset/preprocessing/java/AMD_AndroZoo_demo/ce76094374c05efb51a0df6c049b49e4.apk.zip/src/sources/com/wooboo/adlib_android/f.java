package com.wooboo.adlib_android;

import android.os.Handler;
import android.os.Message;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class f extends Handler {
    final h a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(h hVar) {
        this.a = hVar;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        h.a(this.a, (String) message.obj);
    }
}
