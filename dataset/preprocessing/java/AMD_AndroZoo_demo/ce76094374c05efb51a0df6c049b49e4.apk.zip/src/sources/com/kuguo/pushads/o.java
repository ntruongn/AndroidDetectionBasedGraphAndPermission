package com.kuguo.pushads;

import android.content.Intent;
import com.wooboo.adlib_android.nb;
import java.io.File;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class o implements com.kuguo.a.c {
    final /* synthetic */ j a;
    final /* synthetic */ PushAdsActivity b;
    private int c = 0;

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(PushAdsActivity pushAdsActivity, j jVar) {
        this.b = pushAdsActivity;
        this.a = jVar;
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, int i) {
        j jVar;
        j jVar2;
        j jVar3;
        switch (i) {
            case 0:
            case 1:
            case 2:
            case nb.p /* 3 */:
            default:
                return;
            case 4:
                if (dVar.b() != null) {
                    PushAdsActivity pushAdsActivity = this.b;
                    int i2 = this.a.h;
                    PushAdsActivity pushAdsActivity2 = this.b;
                    File b = dVar.b();
                    jVar = this.b.a;
                    h.a(pushAdsActivity, 17301634, "下载完成", i2, 16, a.a(pushAdsActivity2, b, jVar.u), this.a.g, -1);
                    PushAdsActivity pushAdsActivity3 = this.b;
                    String path = dVar.b().getPath();
                    jVar2 = this.b.a;
                    String str = jVar2.i;
                    jVar3 = this.b.a;
                    a.a(pushAdsActivity3, path, str, jVar3.u);
                    return;
                }
                return;
            case 5:
                h.a(this.b, 17301624, "下载失败", this.a.h, 16, new Intent(), this.a.g, -1);
                return;
        }
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, long j) {
        int i = (dVar.i() * 100) / dVar.h();
        if (i - this.c > 3) {
            this.c = i;
            h.a(this.b, 17301633, "正在下载...", this.a.h, 32, new Intent(), this.a.g, this.c);
        }
    }
}
