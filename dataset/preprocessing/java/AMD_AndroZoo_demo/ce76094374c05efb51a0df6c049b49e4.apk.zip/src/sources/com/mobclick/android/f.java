package com.mobclick.android;

import android.content.Context;
import android.content.DialogInterface;
import java.io.File;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class f implements DialogInterface.OnClickListener {
    private final /* synthetic */ Context a;
    private final /* synthetic */ File b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(Context context, File file) {
        this.a = context;
        this.b = file;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        MobclickAgent.c(this.a, this.b);
    }
}
