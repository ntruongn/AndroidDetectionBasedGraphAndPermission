package com.uucun.adsdk.c;

import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class f extends Thread {
    final /* synthetic */ ArrayList a;
    final /* synthetic */ int b;
    final /* synthetic */ a c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(a aVar, ArrayList arrayList, int i) {
        this.c = aVar;
        this.a = arrayList;
        this.b = i;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        i iVar;
        this.c.a((com.uucun.adsdk.d.e) this.a.get(0));
        iVar = this.c.d;
        iVar.a(this.a);
        int i = 1;
        while (true) {
            int i2 = i;
            if (i2 >= this.b) {
                return;
            }
            com.uucun.adsdk.d.e eVar = (com.uucun.adsdk.d.e) this.a.get(i2);
            if (eVar != null) {
                this.c.a(eVar);
            }
            i = i2 + 1;
        }
    }
}
