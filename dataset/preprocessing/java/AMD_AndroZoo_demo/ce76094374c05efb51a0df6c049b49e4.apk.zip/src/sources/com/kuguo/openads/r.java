package com.kuguo.openads;

import android.graphics.Bitmap;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class r implements Runnable {
    final /* synthetic */ Bitmap a;
    final /* synthetic */ int b;
    final /* synthetic */ x c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public r(x xVar, Bitmap bitmap, int i) {
        this.c = xVar;
        this.a = bitmap;
        this.b = i;
    }

    @Override // java.lang.Runnable
    public void run() {
        d dVar;
        dVar = this.c.c;
        dVar.a(this.a, this.b);
    }
}
