package com.wooboo.adlib_android;

import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class mc {
    public static int a;
    private static final String[] z = {z(z("dn3\u001e[\\!\u000f8\u007f\u00133rN")), z(z("gd0\u0019UW!\u000f8\u007f\u00133rN"))};

    public static void a(String str) {
        if (sc.n) {
            Log.v(z[0], str);
            if (!sc.C) {
                return;
            }
        }
        Log.v(z[1], str);
    }

    public static void b(String str) {
        if (sc.n) {
            Log.w(z[0], str);
            if (!sc.C) {
                return;
            }
        }
        Log.w(z[1], str);
    }

    public static void c(String str) {
    }

    public static void e(String str) {
        if (sc.n) {
            Log.d(z[0], str);
            if (!sc.C) {
                return;
            }
        }
        Log.d(z[1], str);
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '3';
                    break;
                case 1:
                    c = 1;
                    break;
                case 2:
                    c = '\\';
                    break;
                case nb.p /* 3 */:
                    c = '|';
                    break;
                default:
                    c = '4';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '4');
        }
        return charArray;
    }
}
