package com.mobclick.android;

import android.content.Context;
import android.util.Log;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class l implements Runnable {
    private static final Object a = new Object();
    private MobclickAgent b;
    private Context c;
    private JSONObject d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(MobclickAgent mobclickAgent, Context context, JSONObject jSONObject) {
        MobclickAgent mobclickAgent2;
        mobclickAgent2 = MobclickAgent.a;
        this.b = mobclickAgent2;
        this.c = context;
        this.d = jSONObject;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            if (this.d.getString(UmengConstants.AtomKey_Type).equals("update")) {
                this.b.a(this.c, this.d);
            } else {
                if (this.d.getString(UmengConstants.AtomKey_Type).equals("online_config")) {
                    this.b.f(this.c, this.d);
                    return;
                }
                synchronized (a) {
                    this.b.c(this.c, this.d);
                }
            }
        } catch (Exception e) {
            Log.e(UmengConstants.LOG_TAG, "Exception occurred in ReportMessageHandler");
            e.printStackTrace();
        }
    }
}
