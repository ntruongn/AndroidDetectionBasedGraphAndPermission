package com.wooboo.adlib_android;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import java.util.Timer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class ImpressionAdView extends PopupWindow implements gb {
    private static n a;
    private static ImpressionAdView b;
    private static Context d;
    private static int g;
    private static View h;
    private static int i;
    private static ImageButton k;
    private static RelativeLayout l;
    private static int o;
    private static int p;
    private static kc q;
    private static int r;
    private static AdListener s;
    private static jb v;
    private static final String[] z = {z(z("o1J&\u0017")), z(z("{2J7\u001dc\u0002G!\u001c\"-K2")), z(z("%}V0\u0011c3A&Ra(V!Rn8\u0005iO,")), z(z("m1@'\u0006X4H0")), z(z("J/@&\u001a,<A&RE3Q0\u0000z<I}")), z(z("u$\\,_A\u0010\b1\u0016")), z(z("%}V0\u0011c3A&Ra(V!Rn8\u0005kO,"))};
    private static Handler c = null;
    private static int e = 0;
    private static int f = 0;
    private static Timer j = null;
    private static Bitmap m = null;
    private static double n = 0.0d;
    private static int t = 0;
    private static int u = 0;
    static Handler w = new e();

    private ImpressionAdView(Context context) {
        super(context);
    }

    protected ImpressionAdView(Context context, View view, int i2, int i3, int i4, boolean z2, jb jbVar, int[] iArr) {
        this(context, sc.f(context), view, i2, i3, i4, z2, iArr, jbVar);
    }

    public ImpressionAdView(Context context, View view, int i2, int i3, int i4, boolean z2, int[] iArr) {
        this(context, sc.f(context), view, i2, i3, i4, z2, iArr, jb.a);
    }

    protected ImpressionAdView(Context context, String str, View view, int i2, int i3, int i4, boolean z2, jb jbVar, int[] iArr) {
        this(context, str, view, i2, i3, i4, z2, iArr, jbVar);
    }

    public ImpressionAdView(Context context, String str, View view, int i2, int i3, int i4, boolean z2, int[] iArr) {
        this(context, str, view, i2, i3, i4, z2, iArr, jb.a);
    }

    private ImpressionAdView(Context context, String str, View view, int i2, int i3, int i4, boolean z2, int[] iArr, jb jbVar) {
        super(context);
        new DisplayMetrics();
        a(context.getResources().getDisplayMetrics().density);
        b = new ImpressionAdView(context);
        b.setAnimationStyle(16973827);
        b(context);
        g(i2);
        h(i3);
        sc.g(context);
        sc.a(z2);
        f(i4);
        a(view);
        sc.g(context, str);
        sc.a(iArr);
        a(jbVar);
        a(context, view);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int a() {
        return p;
    }

    protected static void a(double d2) {
        n = d2;
    }

    protected static void a(int i2) {
        p = i2;
    }

    private static void a(Context context) {
        if (c == null) {
            c = new Handler();
        }
        new jd().start();
        Message message = new Message();
        message.what = 4;
        w.sendMessage(message);
    }

    /* JADX WARN: Code restructure failed: missing block: B:26:0x0062, code lost:
    
        if (r1 != false) goto L21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0012, code lost:
    
        if (r1 != false) goto L9;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static void a(android.content.Context r6, android.view.View r7) {
        /*
            r4 = 1
            boolean r1 = com.wooboo.adlib_android.sc.C
            int r0 = com.wooboo.adlib_android.sc.e(r6)
            r2 = 200(0xc8, float:2.8E-43)
            if (r0 < r2) goto L14
            r2 = 300(0x12c, float:4.2E-43)
            if (r0 > r2) goto L14
            r2 = 0
            com.wooboo.adlib_android.sc.n = r2     // Catch: java.io.IOException -> Ldc
            if (r1 == 0) goto L17
        L14:
            r2 = 1
            com.wooboo.adlib_android.sc.n = r2     // Catch: java.io.IOException -> Ldc
        L17:
            com.wooboo.adlib_android.sc.f(r0)
            android.graphics.Bitmap r0 = com.wooboo.adlib_android.ImpressionAdView.m     // Catch: java.io.IOException -> Lde
            if (r0 != 0) goto L35
            android.content.Context r0 = h()     // Catch: java.io.IOException -> Lde
            android.content.res.AssetManager r0 = r0.getAssets()     // Catch: java.io.IOException -> Lde
            java.lang.String[] r2 = com.wooboo.adlib_android.ImpressionAdView.z     // Catch: java.io.IOException -> Lde
            r3 = 1
            r2 = r2[r3]     // Catch: java.io.IOException -> Lde
            java.io.InputStream r0 = r0.open(r2)     // Catch: java.io.IOException -> Lde
            android.graphics.Bitmap r0 = android.graphics.BitmapFactory.decodeStream(r0)     // Catch: java.io.IOException -> Lde
            com.wooboo.adlib_android.ImpressionAdView.m = r0     // Catch: java.io.IOException -> Lde
        L35:
            com.wooboo.adlib_android.jb r0 = getAdUnit()
            int r0 = r0.c()
            com.wooboo.adlib_android.sc.e(r0)     // Catch: java.io.IOException -> Le4
            if (r0 == r4) goto L45
            r2 = 6
            if (r0 != r2) goto L64
        L45:
            android.content.res.Resources r0 = r6.getResources()     // Catch: java.io.IOException -> Le6
            android.util.DisplayMetrics r0 = r0.getDisplayMetrics()     // Catch: java.io.IOException -> Le6
            int r0 = r0.widthPixels     // Catch: java.io.IOException -> Le6
            a(r0)     // Catch: java.io.IOException -> Le6
            com.wooboo.adlib_android.jb r0 = getAdUnit()     // Catch: java.io.IOException -> Le6
            int r0 = r0.b()     // Catch: java.io.IOException -> Le6
            double r2 = (double) r0     // Catch: java.io.IOException -> Le6
            double r4 = com.wooboo.adlib_android.ImpressionAdView.n     // Catch: java.io.IOException -> Le6
            double r2 = r2 * r4
            int r0 = (int) r2     // Catch: java.io.IOException -> Le6
            b(r0)     // Catch: java.io.IOException -> Le6
            if (r1 == 0) goto L84
        L64:
            com.wooboo.adlib_android.jb r0 = getAdUnit()
            int r0 = r0.a()
            double r0 = (double) r0
            double r2 = com.wooboo.adlib_android.ImpressionAdView.n
            double r0 = r0 * r2
            int r0 = (int) r0
            a(r0)
            com.wooboo.adlib_android.jb r0 = getAdUnit()
            int r0 = r0.b()
            double r0 = (double) r0
            double r2 = com.wooboo.adlib_android.ImpressionAdView.n
            double r0 = r0 * r2
            int r0 = (int) r0
            b(r0)
        L84:
            double r0 = com.wooboo.adlib_android.ImpressionAdView.n
            android.graphics.Bitmap r2 = com.wooboo.adlib_android.ImpressionAdView.m
            int r2 = r2.getWidth()
            double r2 = (double) r2
            double r0 = r0 * r2
            int r0 = (int) r0
            c(r0)
            double r0 = com.wooboo.adlib_android.ImpressionAdView.n
            android.graphics.Bitmap r2 = com.wooboo.adlib_android.ImpressionAdView.m
            int r2 = r2.getHeight()
            double r2 = (double) r2
            double r0 = r0 * r2
            int r0 = (int) r0
            d(r0)
            java.lang.String r0 = com.wooboo.adlib_android.sc.k(r6)
            com.wooboo.adlib_android.sc.k(r0)
            java.lang.String r0 = com.wooboo.adlib_android.sc.l(r6)
            com.wooboo.adlib_android.sc.l(r0)
            java.lang.String r0 = com.wooboo.adlib_android.sc.i(r6)
            com.wooboo.adlib_android.sc.i(r0)
            java.lang.String r0 = r6.getPackageName()
            com.wooboo.adlib_android.sc.h(r0)
            com.wooboo.adlib_android.qc r0 = com.wooboo.adlib_android.qc.a(r6)
            java.lang.String r1 = android.os.Build.MODEL
            int r0 = r0.a(r1)
            com.wooboo.adlib_android.sc.g(r0)
            int r0 = com.wooboo.adlib_android.sc.o(r6)
            com.wooboo.adlib_android.sc.c(r0)
            com.wooboo.adlib_android.kc r0 = new com.wooboo.adlib_android.kc
            android.content.Context r1 = h()
            r0.<init>(r1)
            com.wooboo.adlib_android.ImpressionAdView.q = r0
            return
        Ldc:
            r0 = move-exception
            throw r0
        Lde:
            r0 = move-exception
            r0.printStackTrace()
            goto L35
        Le4:
            r0 = move-exception
            throw r0     // Catch: java.io.IOException -> Le6
        Le6:
            r0 = move-exception
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ImpressionAdView.a(android.content.Context, android.view.View):void");
    }

    private static void a(View view) {
        h = view;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(ImageButton imageButton) {
        k = imageButton;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(RelativeLayout relativeLayout) {
        l = relativeLayout;
    }

    protected static void a(jb jbVar) {
        v = jbVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(n nVar) {
        a = nVar;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0031, code lost:
    
        if (com.wooboo.adlib_android.ImpressionAdView.i == 0) goto L22;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static void a(boolean r7) {
        /*
            com.wooboo.adlib_android.ImpressionAdView r6 = com.wooboo.adlib_android.ImpressionAdView.b     // Catch: java.lang.Exception -> L2b
            monitor-enter(r6)     // Catch: java.lang.Exception -> L2b
            if (r7 == 0) goto L2d
            int r0 = com.wooboo.adlib_android.ImpressionAdView.i     // Catch: java.lang.Throwable -> L28
            if (r0 <= 0) goto L2d
            java.util.Timer r0 = com.wooboo.adlib_android.ImpressionAdView.j     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            if (r0 != 0) goto L24
            java.util.Timer r0 = new java.util.Timer     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            r0.<init>()     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            com.wooboo.adlib_android.ImpressionAdView.j = r0     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            java.util.Timer r0 = com.wooboo.adlib_android.ImpressionAdView.j     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            com.wooboo.adlib_android.qd r1 = new com.wooboo.adlib_android.qd     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            r1.<init>()     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            int r2 = com.wooboo.adlib_android.ImpressionAdView.i     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            long r2 = (long) r2     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            int r4 = com.wooboo.adlib_android.ImpressionAdView.i     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            long r4 = (long) r4     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
            r0.schedule(r1, r2, r4)     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L28
        L24:
            monitor-exit(r6)     // Catch: java.lang.Throwable -> L28
        L25:
            return
        L26:
            r0 = move-exception
            throw r0     // Catch: java.lang.Throwable -> L28
        L28:
            r0 = move-exception
            monitor-exit(r6)     // Catch: java.lang.Throwable -> L28
            throw r0     // Catch: java.lang.Exception -> L2b
        L2b:
            r0 = move-exception
            goto L25
        L2d:
            if (r7 == 0) goto L33
            int r0 = com.wooboo.adlib_android.ImpressionAdView.i     // Catch: java.lang.Throwable -> L28 java.lang.Exception -> L42
            if (r0 != 0) goto L24
        L33:
            java.util.Timer r0 = com.wooboo.adlib_android.ImpressionAdView.j     // Catch: java.lang.Throwable -> L28 java.lang.Exception -> L40
            if (r0 == 0) goto L24
            java.util.Timer r0 = com.wooboo.adlib_android.ImpressionAdView.j     // Catch: java.lang.Throwable -> L28 java.lang.Exception -> L40
            r0.cancel()     // Catch: java.lang.Throwable -> L28 java.lang.Exception -> L40
            r0 = 0
            com.wooboo.adlib_android.ImpressionAdView.j = r0     // Catch: java.lang.Throwable -> L28 java.lang.Exception -> L40
            goto L24
        L40:
            r0 = move-exception
            throw r0     // Catch: java.lang.Throwable -> L28
        L42:
            r0 = move-exception
            throw r0     // Catch: java.lang.Throwable -> L28 java.lang.Exception -> L44
        L44:
            r0 = move-exception
            throw r0     // Catch: java.lang.Throwable -> L28 java.lang.Exception -> L40
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ImpressionAdView.a(boolean):void");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int b() {
        return o;
    }

    protected static void b(int i2) {
        o = i2;
    }

    private static void b(Context context) {
        d = context;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static double c() {
        return n;
    }

    protected static void c(int i2) {
        t = i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void c(Context context) {
        a(context);
    }

    public static void close() {
        if (b != null) {
            try {
                b.dismiss();
                if (l != null) {
                    l.removeAllViews();
                    l = null;
                    sc.a = false;
                }
            } catch (Exception e2) {
                b = null;
            }
        }
        mc.e(z[0]);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int d() {
        return t;
    }

    protected static void d(int i2) {
        u = i2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int e() {
        return u;
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x0064, code lost:
    
        if (r5 != false) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0032, code lost:
    
        if (r5 != false) goto L9;
     */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x009e  */
    /* JADX WARN: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:28:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static void e(int r10) {
        /*
            r9 = 3
            r2 = 120(0x78, float:1.68E-43)
            r0 = 40
            r3 = 1
            r1 = 0
            boolean r5 = com.wooboo.adlib_android.sc.C
            if (r10 > 0) goto Lb4
            if (r5 == 0) goto Lb2
            r4 = r1
        Le:
            if (r4 >= r0) goto Lb0
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            java.lang.String[] r7 = com.wooboo.adlib_android.ImpressionAdView.z
            r8 = 4
            r7 = r7[r8]
            r6.<init>(r7)
            java.lang.StringBuilder r4 = r6.append(r4)
            java.lang.String[] r6 = com.wooboo.adlib_android.ImpressionAdView.z
            r7 = 6
            r6 = r6[r7]
            java.lang.StringBuilder r4 = r4.append(r6)
            java.lang.StringBuilder r4 = r4.append(r0)
            java.lang.String r4 = r4.toString()
            com.wooboo.adlib_android.mc.b(r4)
            if (r5 == 0) goto L59
        L34:
            if (r0 <= r2) goto L59
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String[] r6 = com.wooboo.adlib_android.ImpressionAdView.z
            r7 = 4
            r6 = r6[r7]
            r4.<init>(r6)
            java.lang.StringBuilder r0 = r4.append(r0)
            java.lang.String[] r4 = com.wooboo.adlib_android.ImpressionAdView.z
            r6 = 2
            r4 = r4[r6]
            java.lang.StringBuilder r0 = r0.append(r4)
            java.lang.StringBuilder r0 = r0.append(r2)
            java.lang.String r0 = r0.toString()
            com.wooboo.adlib_android.mc.b(r0)
            r0 = r2
        L59:
            int r0 = r0 * 1000
            com.wooboo.adlib_android.ImpressionAdView.i = r0
            int r0 = com.wooboo.adlib_android.ImpressionAdView.i
            if (r0 != 0) goto L66
            a(r1)
            if (r5 == 0) goto L69
        L66:
            a(r3)
        L69:
            boolean r0 = com.wooboo.adlib_android.sc.l()
            if (r0 != 0) goto Lad
            android.content.Context r0 = com.wooboo.adlib_android.ImpressionAdView.d
            r2 = 0
            com.wooboo.adlib_android.pc r0 = com.wooboo.adlib_android.pc.a(r0, r2)
            java.lang.String[] r2 = com.wooboo.adlib_android.ImpressionAdView.z
            r2 = r2[r9]
            java.lang.String r2 = r0.i(r2)
            java.util.Date r4 = new java.util.Date
            r4.<init>()
            java.text.SimpleDateFormat r6 = new java.text.SimpleDateFormat
            java.lang.String[] r7 = com.wooboo.adlib_android.ImpressionAdView.z
            r8 = 5
            r7 = r7[r8]
            r6.<init>(r7)
            java.lang.String r4 = r6.format(r4)
            if (r2 == 0) goto L9b
            boolean r2 = r4.equalsIgnoreCase(r2)
            if (r2 != 0) goto L9c
            if (r5 == 0) goto Lae
        L9b:
            r1 = r3
        L9c:
            if (r1 == 0) goto Lad
            java.lang.String[] r1 = com.wooboo.adlib_android.ImpressionAdView.z
            r1 = r1[r9]
            r0.d(r1, r4)
            com.wooboo.adlib_android.id r0 = new com.wooboo.adlib_android.id
            r0.<init>()
            r0.start()
        Lad:
            return
        Lae:
            r1 = r3
            goto L9c
        Lb0:
            r0 = r4
            goto L34
        Lb2:
            r0 = r1
            goto L59
        Lb4:
            r4 = r10
            goto Le
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ImpressionAdView.e(int):void");
    }

    private static void f() {
        if (sc.l() || (sc.a(d, false) != null && sc.d(d))) {
            if (h.getVisibility() == 0) {
                a(d);
            }
            e(r);
        }
    }

    private static void f(int i2) {
        g = (-16777216) | i2;
    }

    private static View g() {
        return h;
    }

    private static void g(int i2) {
        f = i2;
    }

    public static jb getAdUnit() {
        return v;
    }

    private static Context h() {
        return d;
    }

    private static void h(int i2) {
        e = i2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int i() {
        return g;
    }

    private static int j() {
        return f;
    }

    private static int k() {
        return e;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static ImpressionAdView l() {
        return b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Context m() {
        return h();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static n n() {
        return a;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static RelativeLayout o() {
        return l;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static ImageButton p() {
        return k;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Bitmap q() {
        return m;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static View r() {
        return g();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int s() {
        return j();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int t() {
        return k();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static AdListener u() {
        return s;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void v() {
        f();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Context w() {
        return d;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int x() {
        return i;
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i2 = 0; length > i2; i2++) {
            char c3 = cArr[i2];
            switch (i2 % 5) {
                case 0:
                    c2 = '\f';
                    break;
                case 1:
                    c2 = ']';
                    break;
                case 2:
                    c2 = '%';
                    break;
                case nb.p /* 3 */:
                    c2 = 'U';
                    break;
                default:
                    c2 = 'r';
                    break;
            }
            cArr[i2] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'r');
        }
        return charArray;
    }

    @Override // com.wooboo.adlib_android.gb
    public void onHideChoseButton() {
        k.setVisibility(8);
    }

    @Override // com.wooboo.adlib_android.gb
    public void onShowChoseButton() {
        k.setVisibility(0);
    }

    public void onWindowFocusChanged(boolean z2) {
        a(z2);
    }

    public void setAdListener(AdListener adListener) {
        synchronized (this) {
            s = adListener;
        }
    }

    public void show() {
        r = 0;
        new Timer().schedule(new pd(this), 1000L);
    }

    public void show(int i2) {
        r = i2;
        new Timer().schedule(new od(this), 1000L);
    }
}
