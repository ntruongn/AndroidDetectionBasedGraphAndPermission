package com.kuguo.pushads;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.StateListDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.kuguo.ui.FoldView;
import com.kuguo.ui.ImageGallery;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class g extends LinearLayout implements View.OnClickListener {
    public boolean a;
    private ImageView b;
    private TextView c;
    private TextView d;
    private TextView e;
    private TextView f;
    private ImageGallery g;
    private FoldView h;
    private TextView i;
    private Button j;
    private View.OnClickListener k;

    public g(Context context, boolean z) {
        super(context);
        this.a = true;
        setOrientation(1);
        setBackgroundColor(-7158214);
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(-1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(2, 2, 2, 2);
        addView(linearLayout, layoutParams);
        int parseColor = Color.parseColor("#5297be");
        LinearLayout linearLayout2 = new LinearLayout(context);
        linearLayout2.setOrientation(0);
        linearLayout2.setBackgroundColor(parseColor);
        linearLayout.addView(linearLayout2, -1, -2);
        this.b = new ImageView(context);
        this.b.setImageResource(17301651);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 16;
        layoutParams2.leftMargin = 5;
        linearLayout2.addView(this.b, layoutParams2);
        LinearLayout linearLayout3 = new LinearLayout(context);
        linearLayout3.setOrientation(1);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2, 1.0f);
        layoutParams3.gravity = 16;
        layoutParams3.leftMargin = 5;
        linearLayout2.addView(linearLayout3, layoutParams3);
        this.c = new TextView(context);
        this.c.setTextColor(-256);
        this.c.setTextSize(16.0f);
        linearLayout3.addView(this.c, -1, -2);
        this.i = new TextView(context);
        this.i.setTextColor(-1);
        linearLayout3.addView(this.i, -1, -2);
        LinearLayout linearLayout4 = new LinearLayout(context);
        linearLayout4.setOrientation(0);
        linearLayout3.addView(linearLayout4, -1, -2);
        this.d = new TextView(context);
        this.d.setTextColor(-1);
        linearLayout4.addView(this.d, -2, -2);
        this.e = new TextView(context);
        this.e.setTextColor(-1);
        this.e.setPadding(this.e.getPaddingLeft() + 10, this.e.getPaddingTop(), this.e.getPaddingRight(), this.e.getPaddingBottom());
        linearLayout4.addView(this.e, -1, -2);
        ScrollView scrollView = new ScrollView(context);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2, 1.0f);
        layoutParams4.topMargin = 10;
        linearLayout.addView(scrollView, layoutParams4);
        LinearLayout linearLayout5 = new LinearLayout(context);
        linearLayout5.setOrientation(1);
        linearLayout5.setPadding(0, 0, 0, 30);
        scrollView.addView(linearLayout5, -1, -2);
        this.f = new TextView(context);
        this.f.setTextSize(16.0f);
        this.f.setTextColor(-16777216);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.rightMargin = 10;
        layoutParams5.leftMargin = 10;
        linearLayout5.addView(this.f, layoutParams5);
        this.g = new ImageGallery(context);
        this.g.setBackgroundColor(Color.rgb(236, 236, 236));
        this.g.setPadding(0, 20, 0, 40);
        this.g.setSpacing(10);
        this.g.a(com.kuguo.d.e.a(context, "ads/spot_default.png"), com.kuguo.d.e.a(context, "ads/spot_light.png"));
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams6.topMargin = 10;
        linearLayout5.addView(this.g, layoutParams6);
        this.h = new FoldView(context);
        this.h.a("软件权限");
        this.h.a(18);
        this.h.b(parseColor);
        this.h.a(com.kuguo.d.e.a(context, "ads/fold_arrow.png"));
        this.h.a(-7829368, 2);
        this.h.setVisibility(8);
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams7.bottomMargin = 10;
        layoutParams7.rightMargin = 10;
        layoutParams7.leftMargin = 10;
        layoutParams7.topMargin = 10;
        linearLayout5.addView(this.h, layoutParams7);
        FrameLayout frameLayout = new FrameLayout(context);
        frameLayout.setBackgroundColor(parseColor);
        LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams8.gravity = 80;
        linearLayout.addView(frameLayout, layoutParams8);
        LinearLayout linearLayout6 = new LinearLayout(context);
        FrameLayout.LayoutParams layoutParams9 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams9.gravity = 17;
        frameLayout.addView(linearLayout6, layoutParams9);
        this.j = new Button(context);
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{16842919}, com.kuguo.d.e.b(context, "ads/download_btn2_pressed.png"));
        stateListDrawable.addState(new int[]{16842910}, com.kuguo.d.e.b(context, "ads/download_btn2.png"));
        this.j.setBackgroundDrawable(stateListDrawable);
        ViewGroup.LayoutParams layoutParams10 = new LinearLayout.LayoutParams(-2, -2);
        this.j.setTag(1);
        linearLayout6.addView(this.j, layoutParams10);
        this.j.setOnClickListener(this);
        if (z) {
            Button button = new Button(context);
            StateListDrawable stateListDrawable2 = new StateListDrawable();
            stateListDrawable2.addState(new int[]{16842919}, com.kuguo.d.e.b(context, "ads/wait_download_btn2_pressed.png"));
            stateListDrawable2.addState(new int[]{16842910}, com.kuguo.d.e.b(context, "ads/wait_download_btn2.png"));
            button.setBackgroundDrawable(stateListDrawable2);
            ViewGroup.LayoutParams layoutParams11 = new LinearLayout.LayoutParams(-2, -2);
            button.setTag(0);
            linearLayout6.addView(button, layoutParams11);
            button.setOnClickListener(this);
            return;
        }
        Button button2 = new Button(context);
        StateListDrawable stateListDrawable3 = new StateListDrawable();
        stateListDrawable3.addState(new int[]{16842919}, com.kuguo.d.e.b(context, "ads/push_cancel_btn_pressed.png"));
        stateListDrawable3.addState(new int[]{16842910}, com.kuguo.d.e.b(context, "ads/push_cancel_btn.png"));
        button2.setBackgroundDrawable(stateListDrawable3);
        ViewGroup.LayoutParams layoutParams12 = new LinearLayout.LayoutParams(-2, -2);
        button2.setTag(2);
        linearLayout6.addView(button2, layoutParams12);
        button2.setOnClickListener(this);
    }

    private String b(float f) {
        return f > 1024.0f ? (((int) ((f / 1024.0f) * 100.0f)) / 100.0f) + "M" : ((int) Math.ceil(f)) + "K";
    }

    public void a() {
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{16842919}, com.kuguo.d.e.b(getContext(), "ads/visitweb_btn_pressed.png"));
        stateListDrawable.addState(new int[]{16842910}, com.kuguo.d.e.b(getContext(), "ads/visitweb_btn.png"));
        this.j.setBackgroundDrawable(stateListDrawable);
    }

    public void a(float f) {
        this.e.setText("大小: " + b(f));
    }

    public void a(int i) {
        Bitmap a = com.kuguo.d.e.a(getContext(), "ads/snapshot_empty.png");
        ArrayList arrayList = new ArrayList(i);
        for (int i2 = 0; i2 < i; i2++) {
            arrayList.add(a);
        }
        a(arrayList);
    }

    public void a(Bitmap bitmap) {
        this.b.setImageDrawable(com.kuguo.d.e.a(getContext(), bitmap));
    }

    public void a(Bitmap bitmap, int i) {
        this.g.a(bitmap, i);
    }

    public void a(View.OnClickListener onClickListener) {
        this.k = onClickListener;
    }

    public void a(String str) {
        if (this.c != null) {
            this.c.setText(str);
        }
    }

    public void a(List list) {
        this.g.a(list);
    }

    public void a(Map map) {
        if (map.isEmpty()) {
            return;
        }
        new TextView(getContext()).setTextColor(-16777216);
        StringBuilder sb = new StringBuilder();
        sb.append("<ul>");
        for (String str : map.keySet()) {
            sb.append("<li><b>");
            sb.append(str);
            String str2 = (String) map.get(str);
            if (str2 != null) {
                sb.append("</b><br/>");
                sb.append(str2);
            }
            sb.append("</li>");
        }
        sb.append("</ul>");
        String sb2 = sb.toString();
        WebView webView = new WebView(getContext());
        webView.loadDataWithBaseURL(null, sb2, "text/html", "utf-8", null);
        this.h.a(webView);
        this.h.setVisibility(0);
    }

    public void b(String str) {
        this.i.setText("类型: " + str);
    }

    public void c(String str) {
        this.d.setText("版本: " + str);
    }

    public void d(String str) {
        this.f.setText(str);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        if (this.k != null) {
            this.k.onClick(view);
        }
    }
}
