package com.feedback.ui;

import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class e implements View.OnClickListener {
    final /* synthetic */ FeedbackConversations a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(FeedbackConversations feedbackConversations) {
        this.a = feedbackConversations;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        com.feedback.b.a.a(this.a);
    }
}
