package com.feedback.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.mobclick.android.UmengConstants;
import com.mobclick.android.m;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class j implements View.OnClickListener {
    final /* synthetic */ SendFeedback a;

    private j(SendFeedback sendFeedback) {
        this.a = sendFeedback;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ j(SendFeedback sendFeedback, j jVar) {
        this(sendFeedback);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        EditText editText;
        Spinner spinner;
        int i;
        Spinner spinner2;
        JSONObject jSONObject;
        JSONObject jSONObject2;
        JSONObject jSONObject3;
        EditText editText2;
        Spinner spinner3;
        Spinner spinner4;
        EditText editText3;
        int i2 = -1;
        String str = null;
        editText = this.a.d;
        if (editText != null) {
            editText3 = this.a.d;
            str = editText3.getText().toString();
        }
        if (com.feedback.b.d.a(str)) {
            Toast.makeText(this.a, this.a.getString(m.a(this.a, "string", "UMEmptyFbNotAllowed")), 0).show();
            return;
        }
        if (str.length() > 140) {
            Toast.makeText(this.a, this.a.getString(m.a(this.a, "string", "UMContentTooLong")), 0).show();
            return;
        }
        spinner = this.a.b;
        if (spinner != null) {
            spinner4 = this.a.b;
            i = spinner4.getSelectedItemPosition();
        } else {
            i = -1;
        }
        spinner2 = this.a.c;
        if (spinner2 != null) {
            spinner3 = this.a.c;
            i2 = spinner3.getSelectedItemPosition();
        }
        SharedPreferences.Editor edit = this.a.getSharedPreferences(UmengConstants.PreName_Trivial, 0).edit();
        edit.putInt(UmengConstants.TrivialPreKey_AgeGroup, i);
        edit.putInt(UmengConstants.TrivialPreKey_Sex, i2);
        edit.commit();
        try {
            this.a.h = com.feedback.b.b.a(this.a, str, i, i2);
            SendFeedback sendFeedback = this.a;
            jSONObject2 = this.a.h;
            com.feedback.b.c.c(sendFeedback, jSONObject2);
            jSONObject3 = this.a.h;
            SendFeedback.executorService.submit(new com.feedback.c.c(jSONObject3, this.a));
            this.a.startActivity(new Intent(this.a, (Class<?>) FeedbackConversations.class).setFlags(131072));
            InputMethodManager inputMethodManager = (InputMethodManager) this.a.getSystemService("input_method");
            editText2 = this.a.d;
            inputMethodManager.hideSoftInputFromWindow(editText2.getWindowToken(), 0);
            this.a.finish();
        } catch (Exception e) {
            if (UmengConstants.testMode) {
                e.printStackTrace();
            }
            SendFeedback sendFeedback2 = this.a;
            jSONObject = this.a.h;
            com.feedback.b.c.d(sendFeedback2, jSONObject);
        }
    }
}
