package com.wooboo.adlib_android;

import android.app.AlertDialog;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class ld extends Thread {
    private static final String[] z = {z(z("掄祌")), z(z("!\u0006\u000bV\u00041#\u001d[J")), z(z("3\u0013\u001b\u0017\u0005$\u0012\u000eC\u0015\u0001\u0004\u0003\u0017\u00165\u001f\u0003R\u0014u")), z(z("也歗凢诃")), z(z("也輋旟牿")), z(z("厅珆旟牿杜輻亀C不透儙寿袪夆赕ｘ讁儧协輍聕爾权冺对袑"))};
    final WoobooAdView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ld(WoobooAdView woobooAdView) {
        this.a = woobooAdView;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static WoobooAdView a(ld ldVar) {
        return ldVar.a;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'T';
                    break;
                case 1:
                    c = 'v';
                    break;
                case 2:
                    c = 'o';
                    break;
                case nb.p /* 3 */:
                    c = '7';
                    break;
                default:
                    c = 'p';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'p');
        }
        return charArray;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        try {
            String h = sc.h(1);
            if (kb.c(h)) {
                return;
            }
            mc.b(z[1] + h);
            AlertDialog.Builder builder = new AlertDialog.Builder(this.a.getContext());
            builder.setTitle(z[0]).setMessage(z[5]);
            builder.setPositiveButton(z[4], new tc(this, h));
            builder.setNegativeButton(z[3], new uc(this));
            Message message = new Message();
            message.what = 2;
            message.obj = builder;
            this.a.q.sendMessage(message);
        } catch (Exception e) {
            mc.c(z[2]);
        }
    }
}
