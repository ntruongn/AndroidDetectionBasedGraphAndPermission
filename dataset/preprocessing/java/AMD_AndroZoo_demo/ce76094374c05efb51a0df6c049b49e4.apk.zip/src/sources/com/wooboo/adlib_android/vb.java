package com.wooboo.adlib_android;

import android.view.animation.Animation;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class vb implements Animation.AnimationListener {
    final ub a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public vb(ub ubVar) {
        this.a = ubVar;
    }

    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationEnd(Animation animation) {
        if (ub.a(this.a) != null) {
            ub.c(this.a).removeView(ub.a(this.a));
            ub.a(this.a).e();
            ub.a(this.a, null);
        }
        FullAdView.a = ub.b(this.a);
    }

    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationRepeat(Animation animation) {
    }

    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationStart(Animation animation) {
    }
}
