package com.uucun.adsdk.c;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class k extends j {
    public static String a = k.class.getSimpleName();
    private Context d;
    private Notification e;
    private int f;
    private NotificationManager g;

    public k(Context context, String str) {
        super(context);
        this.d = context;
        this.b = str;
    }

    private AlertDialog.Builder a(Context context, String str, String str2, String str3, DialogInterface.OnClickListener onClickListener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(str);
        builder.setMessage(str3);
        builder.setNegativeButton("取消", new d(this));
        builder.setPositiveButton(str2, onClickListener);
        return builder;
    }

    private void b(com.uucun.adsdk.d.c cVar) {
        this.g = (NotificationManager) this.d.getSystemService("notification");
        this.e = new Notification();
        this.e.icon = 17301634;
        this.e.flags = 16;
        this.f = (int) (Math.random() * 10000.0d);
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(cVar.c));
        intent.setFlags(268435456);
        PendingIntent activity = PendingIntent.getActivity(this.d, 0, intent, 67108864);
        this.e.setLatestEventInfo(this.d, com.uucun.adsdk.b.b.h(this.d), cVar.b, activity);
        this.g.notify(this.f, this.e);
    }

    private void c(com.uucun.adsdk.d.c cVar) {
        a(this.d, "更新提示", "更新", cVar.b, new e(this, cVar)).show();
    }

    @Override // com.uucun.adsdk.c.j
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public com.uucun.adsdk.d.c b(String str) {
        return com.uucun.adsdk.b.i.a(str);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public com.uucun.adsdk.d.c doInBackground(JSONObject... jSONObjectArr) {
        com.uucun.adsdk.d.c cVar;
        String string;
        try {
            string = jSONObjectArr[0].getString("app_key");
        } catch (Exception e) {
            com.uucun.adsdk.b.h.a(a, e.getMessage());
            cVar = null;
        }
        if (string == null || TextUtils.isEmpty(string.trim())) {
            return null;
        }
        cVar = (com.uucun.adsdk.d.c) a(jSONObjectArr[0]);
        return cVar;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void onPostExecute(com.uucun.adsdk.d.c cVar) {
        if (cVar == null) {
            return;
        }
        Activity activity = this.d instanceof Activity ? (Activity) this.d : null;
        if ("1".equals(cVar.a)) {
            if (activity == null || activity.isFinishing()) {
                b(cVar);
            } else {
                c(cVar);
            }
        }
    }
}
