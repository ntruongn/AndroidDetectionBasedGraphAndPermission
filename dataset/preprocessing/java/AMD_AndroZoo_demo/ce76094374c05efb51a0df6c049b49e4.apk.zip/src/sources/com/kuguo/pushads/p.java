package com.kuguo.pushads;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class p implements com.kuguo.a.c {
    final /* synthetic */ j a;
    final /* synthetic */ i b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(i iVar, j jVar) {
        this.b = iVar;
        this.a = jVar;
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, int i) {
        Context context;
        Context context2;
        a.a("download state == " + i);
        if (i == 4 || i == 5) {
            context = this.b.a.a;
            e.a(context, this.a);
            this.a.j = 0;
            context2 = this.b.a.a;
            a.b(context2, this.a);
            AdsReceiver.a();
        }
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, long j) {
        a.a("download size == " + j);
    }
}
