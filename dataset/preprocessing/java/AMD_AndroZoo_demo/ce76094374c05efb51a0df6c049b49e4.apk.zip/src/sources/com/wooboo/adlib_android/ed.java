package com.wooboo.adlib_android;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class ed extends Thread {
    final c a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ed(c cVar) {
        this.a = cVar;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        if (FullAdView.a(c.a(this.a)) != null) {
            FullAdView.a(c.a(this.a)).onPlayFinish();
        }
    }
}
