package com.yong.pedometer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class R {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public static final class array {
        public static final int exercise_type_preference = 0x7f050006;
        public static final int exercise_type_preference_values = 0x7f050007;
        public static final int maintain_preference = 0x7f050008;
        public static final int maintain_preference_values = 0x7f050009;
        public static final int operation_level_preference = 0x7f050002;
        public static final int operation_level_preference_values = 0x7f050003;
        public static final int sensitivity_preference = 0x7f050000;
        public static final int sensitivity_preference_values = 0x7f050001;
        public static final int speaking_interval_preference = 0x7f05000a;
        public static final int speaking_interval_preference_values = 0x7f05000b;
        public static final int units_preference = 0x7f050004;
        public static final int units_preference_values = 0x7f050005;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public static final class attr {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public static final class color {
        public static final int display_background = 0x7f060001;
        public static final int screen_background = 0x7f060000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public static final class dimen {
        public static final int box_width = 0x7f07000e;
        public static final int button = 0x7f070007;
        public static final int button_sign = 0x7f070008;
        public static final int desired_pace = 0x7f070005;
        public static final int desired_pace_width = 0x7f070006;
        public static final int distance = 0x7f07000c;
        public static final int large_half = 0x7f070000;
        public static final int margin = 0x7f070009;
        public static final int padding = 0x7f07000a;
        public static final int row_height = 0x7f07000d;
        public static final int row_spacing = 0x7f07000b;
        public static final int small_value = 0x7f070002;
        public static final int step_count = 0x7f070003;
        public static final int third_box_width = 0x7f07000f;
        public static final int third_box_width_middle = 0x7f070010;
        public static final int units = 0x7f070004;
        public static final int value = 0x7f070001;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public static final class drawable {
        public static final int ic_notification = 0x7f020000;
        public static final int icon = 0x7f020001;
        public static final int line40 = 0x7f020002;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public static final class id {
        public static final int box_calories = 0x7f09000f;
        public static final int box_distance = 0x7f090005;
        public static final int box_pace = 0x7f090009;
        public static final int box_speed = 0x7f09000c;
        public static final int box_steps = 0x7f090002;
        public static final int btn_jfq = 0x7f090017;
        public static final int button_desired_pace_lower = 0x7f090013;
        public static final int button_desired_pace_raise = 0x7f090016;
        public static final int calories_units = 0x7f090011;
        public static final int calories_value = 0x7f090010;
        public static final int desired_pace_control = 0x7f090012;
        public static final int desired_pace_label = 0x7f090014;
        public static final int desired_pace_value = 0x7f090015;
        public static final int distance_units = 0x7f090007;
        public static final int distance_value = 0x7f090006;
        public static final int main_layout = 0x7f090000;
        public static final int pace_units = 0x7f09000b;
        public static final int pace_value = 0x7f09000a;
        public static final int row_1 = 0x7f090001;
        public static final int row_2 = 0x7f090008;
        public static final int speed_units = 0x7f09000e;
        public static final int speed_value = 0x7f09000d;
        public static final int step_units = 0x7f090004;
        public static final int step_value = 0x7f090003;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public static final class layout {
        public static final int main = 0x7f030000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public static final class string {
        public static final int activity_settings = 0x7f080015;
        public static final int app_name = 0x7f080000;
        public static final int body_weight_setting = 0x7f080031;
        public static final int body_weight_setting_details = 0x7f080032;
        public static final int body_weight_setting_title = 0x7f080033;
        public static final int calories_burned = 0x7f08000a;
        public static final int centimeters = 0x7f08000b;
        public static final int desired_pace = 0x7f08000f;
        public static final int desired_speed = 0x7f080010;
        public static final int exercise_type_running = 0x7f080037;
        public static final int exercise_type_setting = 0x7f080034;
        public static final int exercise_type_setting_details = 0x7f080035;
        public static final int exercise_type_setting_title = 0x7f080036;
        public static final int exercise_type_walking = 0x7f080038;
        public static final int extra_high = 0x7f08001a;
        public static final int extra_low = 0x7f080022;
        public static final int high = 0x7f08001c;
        public static final int higher = 0x7f08001d;
        public static final int inches = 0x7f08000c;
        public static final int incorrect_step_length = 0x7f080057;
        public static final int interval_10_minutes = 0x7f080049;
        public static final int interval_15_seconds = 0x7f080044;
        public static final int interval_1_minute = 0x7f080046;
        public static final int interval_2_minutes = 0x7f080047;
        public static final int interval_30_seconds = 0x7f080045;
        public static final int interval_5_minutes = 0x7f080048;
        public static final int keep_screen_on = 0x7f080027;
        public static final int kilograms = 0x7f08000d;
        public static final int kilometers = 0x7f080005;
        public static final int kilometers_per_hour = 0x7f080008;
        public static final int low = 0x7f080020;
        public static final int lower = 0x7f08001f;
        public static final int maintain_nothing = 0x7f08003c;
        public static final int maintain_pace = 0x7f08003d;
        public static final int maintain_setting = 0x7f080039;
        public static final int maintain_setting_details = 0x7f08003a;
        public static final int maintain_setting_title = 0x7f08003b;
        public static final int maintain_speed = 0x7f08003e;
        public static final int medium = 0x7f08001e;
        public static final int miles = 0x7f080006;
        public static final int miles_per_hour = 0x7f080009;
        public static final int notification_subtitle = 0x7f080001;
        public static final int operation_level_setting = 0x7f080023;
        public static final int operation_level_setting_details = 0x7f080024;
        public static final int operation_level_setting_title = 0x7f080025;
        public static final int pause = 0x7f080011;
        public static final int pounds = 0x7f08000e;
        public static final int quit = 0x7f080058;
        public static final int reset = 0x7f080013;
        public static final int resume = 0x7f080012;
        public static final int run_in_background = 0x7f080026;
        public static final int sensitivity_setting = 0x7f080017;
        public static final int sensitivity_setting_details = 0x7f080018;
        public static final int sensitivity_setting_title = 0x7f080019;
        public static final int settings = 0x7f080014;
        public static final int speaking_interval_setting = 0x7f080042;
        public static final int speaking_interval_setting_details = 0x7f080043;
        public static final int started = 0x7f080002;
        public static final int step_length_setting = 0x7f08002e;
        public static final int step_length_setting_details = 0x7f08002f;
        public static final int step_length_setting_title = 0x7f080030;
        public static final int steps = 0x7f080004;
        public static final int steps_per_minute = 0x7f080007;
        public static final int steps_settings_title = 0x7f080016;
        public static final int stopped = 0x7f080003;
        public static final int tell_calories_setting = 0x7f080053;
        public static final int tell_calories_setting_details = 0x7f080054;
        public static final int tell_distance_setting = 0x7f08004f;
        public static final int tell_distance_setting_details = 0x7f080050;
        public static final int tell_fasterslower_setting = 0x7f080055;
        public static final int tell_fasterslower_setting_details = 0x7f080056;
        public static final int tell_pace_setting = 0x7f08004d;
        public static final int tell_pace_setting_details = 0x7f08004e;
        public static final int tell_speed_setting = 0x7f080051;
        public static final int tell_speed_setting_details = 0x7f080052;
        public static final int tell_steps_setting = 0x7f08004b;
        public static final int tell_steps_setting_details = 0x7f08004c;
        public static final int tell_what = 0x7f08004a;
        public static final int units_imperial = 0x7f08002d;
        public static final int units_metric = 0x7f08002c;
        public static final int units_setting = 0x7f080029;
        public static final int units_setting_details = 0x7f08002a;
        public static final int units_setting_title = 0x7f08002b;
        public static final int very_high = 0x7f08001b;
        public static final int very_low = 0x7f080021;
        public static final int voice_setting = 0x7f080040;
        public static final int voice_setting_details = 0x7f080041;
        public static final int voice_settings_title = 0x7f08003f;
        public static final int wake_up = 0x7f080028;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public static final class xml {
        public static final int preferences = 0x7f040000;
    }
}
