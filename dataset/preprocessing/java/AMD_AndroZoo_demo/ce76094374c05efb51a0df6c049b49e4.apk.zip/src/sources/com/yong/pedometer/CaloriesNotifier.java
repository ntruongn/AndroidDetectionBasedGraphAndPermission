package com.yong.pedometer;

import com.yong.pedometer.SpeakingTimer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class CaloriesNotifier implements StepListener, SpeakingTimer.Listener {
    float mBodyWeight;
    private double mCalories = 0.0d;
    boolean mIsMetric;
    boolean mIsRunning;
    private Listener mListener;
    PedometerSettings mSettings;
    float mStepLength;
    Utils mUtils;
    private static double METRIC_RUNNING_FACTOR = 1.02784823d;
    private static double IMPERIAL_RUNNING_FACTOR = 0.75031498d;
    private static double METRIC_WALKING_FACTOR = 0.708d;
    private static double IMPERIAL_WALKING_FACTOR = 0.517d;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public interface Listener {
        void passValue();

        void valueChanged(float f);
    }

    public CaloriesNotifier(Listener listener, PedometerSettings settings, Utils utils) {
        this.mListener = listener;
        this.mUtils = utils;
        this.mSettings = settings;
        reloadSettings();
    }

    public void setCalories(float calories) {
        this.mCalories = calories;
        notifyListener();
    }

    public void reloadSettings() {
        this.mIsMetric = this.mSettings.isMetric();
        this.mIsRunning = this.mSettings.isRunning();
        this.mStepLength = this.mSettings.getStepLength();
        this.mBodyWeight = this.mSettings.getBodyWeight();
        notifyListener();
    }

    public void resetValues() {
        this.mCalories = 0.0d;
    }

    public void isMetric(boolean isMetric) {
        this.mIsMetric = isMetric;
    }

    public void setStepLength(float stepLength) {
        this.mStepLength = stepLength;
    }

    @Override // com.yong.pedometer.StepListener
    public void onStep() {
        if (this.mIsMetric) {
            this.mCalories = ((((this.mIsRunning ? METRIC_RUNNING_FACTOR : METRIC_WALKING_FACTOR) * this.mBodyWeight) * this.mStepLength) / 100000.0d) + this.mCalories;
        } else {
            this.mCalories = ((((this.mIsRunning ? IMPERIAL_RUNNING_FACTOR : IMPERIAL_WALKING_FACTOR) * this.mBodyWeight) * this.mStepLength) / 63360.0d) + this.mCalories;
        }
        notifyListener();
    }

    private void notifyListener() {
        this.mListener.valueChanged((float) this.mCalories);
    }

    @Override // com.yong.pedometer.StepListener
    public void passValue() {
    }

    @Override // com.yong.pedometer.SpeakingTimer.Listener
    public void speak() {
        if (this.mSettings.shouldTellCalories() && this.mCalories > 0.0d) {
            this.mUtils.say(((int) this.mCalories) + " calories burned");
        }
    }
}
