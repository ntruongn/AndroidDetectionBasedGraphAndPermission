package com.uucun.adsdk.a;

import android.text.TextUtils;
import java.util.concurrent.ConcurrentLinkedQueue;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class c {
    private static final String a = c.class.getSimpleName();
    private static c b = null;
    private ConcurrentLinkedQueue c = new ConcurrentLinkedQueue();
    private ConcurrentLinkedQueue d = new ConcurrentLinkedQueue();

    private c() {
    }

    public static c a() {
        if (b == null) {
            b = new c();
        }
        return b;
    }

    public void a(com.uucun.adsdk.c.b bVar) {
        this.c.add(bVar);
        this.d.add(bVar.a);
    }

    public boolean a(String str) {
        if (str == null || TextUtils.isEmpty(str.trim())) {
            return false;
        }
        return this.d.contains(str) || b.a().a(str);
    }

    public void b(com.uucun.adsdk.c.b bVar) {
        this.c.remove(bVar);
        this.d.remove(bVar.a);
    }
}
