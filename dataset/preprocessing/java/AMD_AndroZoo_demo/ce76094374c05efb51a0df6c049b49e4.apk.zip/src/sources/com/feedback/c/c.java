package com.feedback.c;

import android.content.Context;
import java.util.concurrent.Callable;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class c implements Callable {
    static String a = "MsgWorker";
    JSONObject b;
    Context c;

    public c(JSONObject jSONObject, Context context) {
        this.b = jSONObject;
        this.c = context;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0049  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0077  */
    @Override // java.util.concurrent.Callable
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Boolean call() {
        /*
            r7 = this;
            r1 = 0
            org.json.JSONObject r0 = r7.b
            java.lang.String r2 = "type"
            java.lang.String r4 = r0.optString(r2)
            org.json.JSONObject r0 = r7.b
            java.lang.String r2 = "feedback_id"
            java.lang.String r5 = r0.optString(r2)
            java.lang.String r0 = "user_reply"
            boolean r0 = r0.equals(r4)
            if (r0 == 0) goto L6a
            java.lang.String r3 = "user_reply"
            java.lang.String r2 = "http://feedback.whalecloud.com/feedback/reply"
            java.lang.String r0 = "reply"
        L1f:
            org.json.JSONObject r6 = r7.b     // Catch: java.lang.Exception -> L71
            java.lang.String r2 = com.feedback.b.d.a(r2, r0, r6)     // Catch: java.lang.Exception -> L71
            if (r2 == 0) goto L75
            org.json.JSONObject r0 = new org.json.JSONObject     // Catch: java.lang.Exception -> L71
            r0.<init>(r2)     // Catch: java.lang.Exception -> L71
        L2c:
            android.content.Intent r2 = new android.content.Intent
            r2.<init>()
            java.lang.String r6 = "postFeedbackFinished"
            android.content.Intent r2 = r2.setAction(r6)
            java.lang.String r6 = "type"
            android.content.Intent r2 = r2.putExtra(r6, r3)
            java.lang.String r3 = "feedback_id"
            android.content.Intent r2 = r2.putExtra(r3, r5)
            boolean r0 = com.feedback.b.b.a(r0)
            if (r0 == 0) goto L77
            org.json.JSONObject r0 = r7.b
            com.feedback.b.b.e(r0)
            java.lang.String r0 = "PostFeedbackBroadcast"
            java.lang.String r3 = "succeed"
            r2.putExtra(r0, r3)
        L55:
            java.lang.String r0 = "user_reply"
            boolean r0 = r0.equals(r4)
            if (r0 == 0) goto L84
            android.content.Context r0 = r7.c
            org.json.JSONObject r3 = r7.b
            com.feedback.b.c.b(r0, r3)
        L64:
            android.content.Context r0 = r7.c
            r0.sendBroadcast(r2)
            return r1
        L6a:
            java.lang.String r3 = "new_feedback"
            java.lang.String r2 = "http://feedback.whalecloud.com/feedback/feedbacks"
            java.lang.String r0 = "feedback"
            goto L1f
        L71:
            r0 = move-exception
            r0.printStackTrace()
        L75:
            r0 = r1
            goto L2c
        L77:
            org.json.JSONObject r0 = r7.b
            com.feedback.b.b.c(r0)
            java.lang.String r0 = "PostFeedbackBroadcast"
            java.lang.String r3 = "fail"
            r2.putExtra(r0, r3)
            goto L55
        L84:
            android.content.Context r0 = r7.c
            java.lang.String r3 = "feedback"
            com.feedback.b.c.a(r0, r3, r5)
            android.content.Context r0 = r7.c
            org.json.JSONObject r3 = r7.b
            com.feedback.b.c.a(r0, r3)
            goto L64
        */
        throw new UnsupportedOperationException("Method not decompiled: com.feedback.c.c.call():java.lang.Boolean");
    }
}
