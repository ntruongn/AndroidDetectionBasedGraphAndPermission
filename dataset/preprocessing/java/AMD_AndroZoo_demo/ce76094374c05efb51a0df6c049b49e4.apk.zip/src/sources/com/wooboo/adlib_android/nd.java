package com.wooboo.adlib_android;

import android.os.Message;
import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class nd extends TimerTask {
    final n a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public nd(n nVar) {
        this.a = nVar;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        Message message = new Message();
        message.what = n.X;
        n.db.sendMessage(message);
    }
}
