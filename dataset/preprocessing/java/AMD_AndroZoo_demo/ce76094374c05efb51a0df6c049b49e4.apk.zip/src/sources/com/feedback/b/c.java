package com.feedback.b;

import android.content.Context;
import android.content.SharedPreferences;
import com.mobclick.android.UmengConstants;
import com.mobclick.android.m;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class c {
    public static synchronized String a(Context context, JSONArray jSONArray) {
        String str;
        synchronized (c.class) {
            if (jSONArray != null) {
                if (jSONArray.length() != 0) {
                    str = "";
                    for (int i = 0; i < jSONArray.length(); i++) {
                        try {
                            JSONArray jSONArray2 = jSONArray.getJSONArray(i);
                            for (int i2 = 0; i2 < jSONArray2.length(); i2++) {
                                if (!jSONArray2.getString(i2).equals("end")) {
                                    JSONObject jSONObject = jSONArray2.getJSONObject(i2);
                                    if (UmengConstants.Atom_Type_DevReply.equalsIgnoreCase(jSONObject.optString(UmengConstants.AtomKey_Type)) && b(context, jSONObject)) {
                                        str = d(context, jSONObject.optString(UmengConstants.AtomKey_FeedbackID));
                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            str = "";
        }
        return str;
    }

    public static synchronized List a(Context context) {
        ArrayList arrayList;
        synchronized (c.class) {
            arrayList = new ArrayList();
            try {
                Iterator<?> it = context.getSharedPreferences(UmengConstants.FeedbackPreName, 0).getAll().values().iterator();
                while (it.hasNext()) {
                    arrayList.add(new com.feedback.a.d(new JSONArray((String) it.next())));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return arrayList;
    }

    public static synchronized void a(Context context, com.feedback.a.d dVar, int i) {
        synchronized (c.class) {
            SharedPreferences sharedPreferences = context.getSharedPreferences(UmengConstants.FeedbackPreName, 0);
            SharedPreferences.Editor edit = sharedPreferences.edit();
            String str = dVar.c;
            String string = sharedPreferences.getString(str, null);
            try {
                JSONArray jSONArray = new JSONArray();
                JSONArray jSONArray2 = new JSONArray(string);
                if (jSONArray2.length() == 1) {
                    edit.remove(dVar.c);
                } else {
                    for (int i2 = 0; i2 <= jSONArray2.length() - 1; i2++) {
                        if (i2 != i) {
                            jSONArray.put(jSONArray2.getJSONObject(i2));
                        }
                    }
                    edit.putString(str, jSONArray.toString());
                }
                edit.commit();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            dVar.b(i);
        }
    }

    public static synchronized void a(Context context, String str) {
        synchronized (c.class) {
            SharedPreferences sharedPreferences = context.getSharedPreferences(UmengConstants.PreName_Trivial, 0);
            if (!d.a(str)) {
                String str2 = "";
                for (String str3 : sharedPreferences.getString(UmengConstants.TrivialPreKey_newreplyIds, "").split(",")) {
                    if (!d.a(str3) && !str3.equals(str)) {
                        str2 = String.valueOf(str2) + "," + str3.trim();
                    }
                }
                a(sharedPreferences, UmengConstants.TrivialPreKey_newreplyIds, str2);
            }
        }
    }

    public static synchronized void a(Context context, String str, String str2) {
        synchronized (c.class) {
            context.getSharedPreferences(str, 0).edit().remove(str2).commit();
        }
    }

    private static synchronized void a(SharedPreferences sharedPreferences, String str, String str2) {
        synchronized (c.class) {
            sharedPreferences.edit().putString(str, str2).commit();
        }
    }

    public static boolean a(Context context, com.feedback.a.d dVar) {
        return context.getSharedPreferences(UmengConstants.PreName_Trivial, 0).getString(UmengConstants.TrivialPreKey_newreplyIds, "").contains(dVar.c);
    }

    public static synchronized boolean a(Context context, JSONObject jSONObject) {
        boolean z = false;
        synchronized (c.class) {
            String optString = jSONObject.optString(UmengConstants.AtomKey_FeedbackID);
            SharedPreferences sharedPreferences = context.getSharedPreferences(UmengConstants.FeedbackPreName, 0);
            if (!d.a(optString)) {
                a(sharedPreferences, optString, "[" + jSONObject.toString() + "]");
                z = true;
            }
        }
        return z;
    }

    public static synchronized com.feedback.a.d b(Context context, String str) {
        com.feedback.a.d dVar;
        synchronized (c.class) {
            try {
                dVar = new com.feedback.a.d(new JSONArray(context.getSharedPreferences(UmengConstants.FeedbackPreName, 0).getString(str, null)));
            } catch (Exception e) {
                e.printStackTrace();
                dVar = null;
            }
        }
        return dVar;
    }

    public static synchronized boolean b(Context context, JSONObject jSONObject) {
        JSONArray jSONArray;
        boolean z = true;
        synchronized (c.class) {
            String optString = jSONObject.optString(UmengConstants.AtomKey_FeedbackID);
            SharedPreferences sharedPreferences = context.getSharedPreferences(UmengConstants.FeedbackPreName, 0);
            try {
                jSONArray = new JSONArray(sharedPreferences.getString(optString, null));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (UmengConstants.Atom_Type_UserReply.equals(jSONObject.opt(UmengConstants.AtomKey_Type))) {
                com.feedback.a.d dVar = new com.feedback.a.d(jSONArray);
                int length = jSONArray.length() - 1;
                while (true) {
                    if (length >= 0) {
                        String optString2 = jSONArray.getJSONObject(length).optString("reply_id", null);
                        String optString3 = jSONObject.optString("reply_id", null);
                        if (optString2 != null && optString2.equalsIgnoreCase(optString3)) {
                            a(context, dVar, length);
                            break;
                        }
                        length--;
                    } else {
                        break;
                    }
                }
                JSONArray jSONArray2 = new JSONArray(sharedPreferences.getString(optString, null));
                jSONArray2.put(jSONObject);
                a(sharedPreferences, optString, jSONArray2.toString());
            } else {
                SharedPreferences sharedPreferences2 = context.getSharedPreferences(UmengConstants.PreName_maxReplyIdOfFb, 0);
                String string = sharedPreferences2.getString(optString, "RP0");
                String optString4 = jSONObject.optString("reply_id");
                if (!d.a(string, optString4)) {
                    jSONObject.put(UmengConstants.AtomKey_Date, m.a(new Date()));
                    jSONArray.put(jSONObject);
                    a(sharedPreferences, optString, jSONArray.toString());
                    a(sharedPreferences2, optString, optString4);
                    a(context.getSharedPreferences(UmengConstants.PreName_Trivial, 0), UmengConstants.TrivialPreKey_MaxReplyID, optString4);
                }
                z = false;
            }
        }
        return z;
    }

    public static synchronized void c(Context context, String str) {
        synchronized (c.class) {
            context.getSharedPreferences(UmengConstants.FeedbackPreName, 0).edit().remove(str).commit();
        }
    }

    public static synchronized void c(Context context, JSONObject jSONObject) {
        synchronized (c.class) {
            b.d(jSONObject);
            e(context, jSONObject);
        }
    }

    private static synchronized String d(Context context, String str) {
        String string;
        synchronized (c.class) {
            SharedPreferences sharedPreferences = context.getSharedPreferences(UmengConstants.PreName_Trivial, 0);
            string = sharedPreferences.getString(UmengConstants.TrivialPreKey_newreplyIds, "");
            if (!string.contains(str)) {
                string = String.valueOf(string) + "," + str;
                a(sharedPreferences, UmengConstants.TrivialPreKey_newreplyIds, string);
            }
        }
        return string;
    }

    public static synchronized void d(Context context, JSONObject jSONObject) {
        synchronized (c.class) {
            b.c(jSONObject);
            e(context, jSONObject);
        }
    }

    public static synchronized boolean e(Context context, JSONObject jSONObject) {
        boolean z = false;
        synchronized (c.class) {
            String optString = jSONObject.optString(UmengConstants.AtomKey_FeedbackID);
            SharedPreferences sharedPreferences = context.getSharedPreferences(UmengConstants.FeedbackPreName, 0);
            try {
                JSONArray jSONArray = new JSONArray(sharedPreferences.getString(optString, "[]"));
                jSONArray.put(jSONObject);
                a(sharedPreferences, optString, jSONArray.toString());
                z = true;
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return z;
    }
}
