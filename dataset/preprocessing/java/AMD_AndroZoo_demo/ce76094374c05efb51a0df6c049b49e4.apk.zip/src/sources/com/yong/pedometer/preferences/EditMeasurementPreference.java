package com.yong.pedometer.preferences;

import android.content.Context;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public abstract class EditMeasurementPreference extends EditTextPreference {
    protected int mImperialUnitsResource;
    boolean mIsMetric;
    protected int mMetricUnitsResource;
    protected int mTitleResource;

    protected abstract void initPreferenceDetails();

    public EditMeasurementPreference(Context context) {
        super(context);
        initPreferenceDetails();
    }

    public EditMeasurementPreference(Context context, AttributeSet attr) {
        super(context, attr);
        initPreferenceDetails();
    }

    public EditMeasurementPreference(Context context, AttributeSet attr, int defStyle) {
        super(context, attr, defStyle);
        initPreferenceDetails();
    }

    @Override // android.preference.EditTextPreference, android.preference.DialogPreference
    protected void showDialog(Bundle state) {
        int i;
        this.mIsMetric = PreferenceManager.getDefaultSharedPreferences(getContext()).getString("units", "imperial").equals("metric");
        StringBuilder append = new StringBuilder(String.valueOf(getContext().getString(this.mTitleResource))).append(" (");
        Context context = getContext();
        if (this.mIsMetric) {
            i = this.mMetricUnitsResource;
        } else {
            i = this.mImperialUnitsResource;
        }
        setDialogTitle(append.append(context.getString(i)).append(")").toString());
        try {
            Float.valueOf(getText());
        } catch (Exception e) {
            setText("20");
        }
        super.showDialog(state);
    }

    @Override // android.preference.EditTextPreference
    protected void onAddEditTextToDialogView(View dialogView, EditText editText) {
        editText.setRawInputType(8194);
        super.onAddEditTextToDialogView(dialogView, editText);
    }

    @Override // android.preference.EditTextPreference, android.preference.DialogPreference
    public void onDialogClosed(boolean positiveResult) {
        if (positiveResult) {
            try {
                Float.valueOf(getEditText().getText().toString());
            } catch (NumberFormatException e) {
                showDialog(null);
                return;
            }
        }
        super.onDialogClosed(positiveResult);
    }
}
