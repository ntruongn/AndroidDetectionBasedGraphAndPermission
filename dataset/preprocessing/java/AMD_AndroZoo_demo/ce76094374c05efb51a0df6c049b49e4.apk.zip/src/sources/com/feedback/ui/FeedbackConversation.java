package com.feedback.ui;

import android.app.ListActivity;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import com.mobclick.android.UmengConstants;
import com.mobclick.android.m;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class FeedbackConversation extends ListActivity {
    static Context a = null;
    static final String c = FeedbackConversation.class.getSimpleName();
    static boolean d = true;
    public static ExecutorService executorService = Executors.newFixedThreadPool(3);
    boolean b = false;
    private com.feedback.a.d e;
    private c f;
    private TextView g;
    private EditText h;
    private Button i;
    private b j;

    private void a() {
        this.g.setText(getString(m.a(this, "string", "UMFeedbackConversationTitle")));
        this.i.setText(getString(m.a(this, "string", "UMFeedbackSummit")));
    }

    public static void setUserContext(Context context) {
        a = context;
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(m.a(this, "layout", "umeng_analyse_feedback_conversation"));
        String stringExtra = getIntent().getStringExtra(UmengConstants.AtomKey_FeedbackID);
        if (stringExtra != null) {
            this.e = com.feedback.b.c.b(this, stringExtra);
        }
        try {
            this.f = new c(this, this.e);
        } catch (Exception e) {
            Log.e(c, "In Feedback class,fail to initialize feedback adapter.");
            finish();
        }
        setListAdapter(this.f);
        setSelection(this.f.getCount() - 1);
        this.g = (TextView) findViewById(m.a(this, "id", "umeng_analyse_feedback_conversation_title"));
        this.h = (EditText) findViewById(m.a(this, "id", "umeng_analyse_editTxtFb"));
        this.i = (Button) findViewById(m.a(this, "id", "umeng_analyse_btnSendFb"));
        this.i.setOnClickListener(new a(this));
        this.h.requestFocus();
        registerForContextMenu(getListView());
        a();
        if (this.e.b != com.feedback.a.e.Normal) {
            this.h.setEnabled(false);
            this.i.setEnabled(false);
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyDown(i, keyEvent);
        }
        if (a != null) {
            com.feedback.b.a.b(a);
        } else {
            com.feedback.b.a.b(this);
        }
        finish();
        return true;
    }

    @Override // android.app.ListActivity
    protected void onListItemClick(ListView listView, View view, int i, long j) {
        super.onListItemClick(listView, view, i, j);
        com.feedback.a.a a2 = this.e.a(i);
        if (a2.g == com.feedback.a.b.Fail) {
            if (a2.f == com.feedback.a.c.Starting) {
                com.feedback.b.a.a(this, this.e);
                finish();
                return;
            }
            this.h.setText(a2.a());
            this.h.setEnabled(true);
            this.i.setEnabled(true);
            com.feedback.b.c.a(this, this.e, i);
            this.f.a(this.e);
            this.f.notifyDataSetChanged();
        }
    }

    @Override // android.app.Activity
    protected void onStart() {
        super.onStart();
        this.j = new b(this, null);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(UmengConstants.PostFeedbackBroadcastAction);
        intentFilter.addAction(UmengConstants.RetrieveReplyBroadcastAction);
        registerReceiver(this.j, intentFilter);
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        unregisterReceiver(this.j);
    }
}
