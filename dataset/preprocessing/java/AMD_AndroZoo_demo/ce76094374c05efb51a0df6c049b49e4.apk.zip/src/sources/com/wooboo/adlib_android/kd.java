package com.wooboo.adlib_android;

import android.content.Context;
import android.os.Bundle;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class kd extends Thread {
    private static final String[] z = {z(z("\u001d\"^5LY9\u000b<M\nmJ5\b\u001f)\u0007{\\\u0016(\u000b:L^=D(A\n$D5\b\u0017>\u000b3A\u001a)N5")), z(z("\u001a,_:")), z(z("\f(Z.M\r9j?\b_p\u000b5]\u0012!")), z(z("\f(Z.M\r9j?\b\u001b#O"))};
    final WoobooAdView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public kd(WoobooAdView woobooAdView) {
        this.a = woobooAdView;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '~';
                    break;
                case 1:
                    c = 'M';
                    break;
                case 2:
                    c = '+';
                    break;
                case nb.p /* 3 */:
                    c = '[';
                    break;
                default:
                    c = '(';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '(');
        }
        return charArray;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        try {
            Context context = this.a.getContext();
            hb m = sc.m(context);
            try {
                try {
                    mc.c(z[3]);
                    if (m != null && !m.equals("")) {
                        mc.c(z[2]);
                        if (!sc.l()) {
                            pc.a(context, (String) null).a(m);
                        }
                        byte[] a = m.a(this.a.getContext(), m.h(), true);
                        Message message = new Message();
                        message.obj = m;
                        Bundle bundle = new Bundle();
                        bundle.putByteArray(z[1], a);
                        message.setData(bundle);
                        message.what = 1;
                        this.a.q.sendMessage(message);
                        if (!sc.C) {
                            return;
                        }
                    }
                    mc.c(z[0]);
                    Message message2 = new Message();
                    message2.obj = m;
                    message2.what = 1;
                    this.a.q.sendMessage(message2);
                } catch (Exception e) {
                    throw e;
                }
            } catch (Exception e2) {
                throw e2;
            }
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }
}
