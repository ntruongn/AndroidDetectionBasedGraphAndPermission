package com.wooboo.adlib_android;

import android.os.Environment;
import android.util.Log;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class rc {
    public static final String f = z(z("5r\u000f\u001c"));
    public static final String e = z(z("ce\nC4zd\u0003\u001f\u0018\u007fi\u0012\r\u0018"));
    public static final String b = z(z("aa\u0016^h"));
    public static final String g = z(z("nf\u001c\u000574"));
    public static final String l = z(z("VA/.\u000eqI(. py\u000e\u0007.\\1\u0011\\\u0005ZY#*\u0006ZG%-\u0016#I+%\u000eYK\u0001'\u0004ZY#-5BGW\u0015\u0012W_ \u000e\u0005]0\"\u0014\u0004\"Z\u0011X\u0006]o^T\u0001o8#\u001c x[(X\b\"[1\u0016\u001fr=\r\u0018\u0000NIT6\u001ek:.\b\fz_\u0003C6M?!U!Q]W;vmc\u0013\t\u0006Y|\u0013\u0015taC\u0003\u0019uaj'\u0016\u0004\u007f8\u0002_/J|\u0000\u0014\u0003w\u007f#\u0007\u0012)I\u0000\u0014\u001fCZ\b\u0001\u007fTq\u0010X\u0002t_'\u001d\u0002~0\u0002C\u0002^?\t\u000f\u0014t|\u001eG>WJ\u0015%umz>\b#Jz\b:%kA-\u000b1hX\u001f\t0U^!\\7k}4\u001d\u0016rn(<\u0016kI1_+vG3\u0001=,bQX6X^PZ=^o6Y\u000ep~\u0004X\u0003xf<\"lr}_'\u0012P_)\u001a0N1V? 4P.\u0007)Y~$\u0007\u0011ueR\u0000vUf1&pVZ4Y6mN\u0013\bwp0^_\u0004iJ.?\u000fZ1\u000f\\\bX9((\nl~\u0003%rVP1\"\f483.~pMM\u000f6-i>;2h0?/\u0006T}%\u0014=#0\u0005\u0015\u001e*XU\n.Mn5\u000f(*9\u0011\u001c2AD2 7JA\"-\u0016ZJ"));
    public static final String i = z(z("VA/.\u000eqI(. py\u000e\u0007.\\1\u0011\\\u0005ZY#*\u0006ZG%-\u0016#I+%\u000eYK\u0001'\u0004ZY#-1+e7\u0002h0l_\u0001.txV\u0018 qJ\nY,RG0>\u0005WP\u0004\u0005vV0-\\\u001f/'\u0000'hNy\u0017+>]n1\u0005!\u007f]'Z\u0004(cR\u0000\u001fy|>\u001e\u0000zQ\u000e;-i>6\u00054My7\"7\"\u007f/)0Zr #\u000fLe<\u00063(P \n\u0003.M(\u0018\u0005mN??#CEU\r\u000eXg!\u0015~mEV]%KX>\r\u000fMq\u0002-s*n\"U\u0002Ze\u000f\u001c2LG<\u0018-Cd'8\u000f(EW>\bmES\u001bwa;U&\u0017uy$\u0002~){/\u0018hN:6\u0003\t\u007fM)\u001d\u0010s{!\u0005*ie\u0016\n&Ar\u0015\u000f\u0006x](\"vS@,\r\u0010o:\t\u00074iJ\u0013(\u000fTRS\t\u0005rl\u0014\u001a,IX2-$LBP]w#D\"\u000b7YQ\u00155\u0006+]4\u0007\u0016+NI\u001f.z:\n\u0001>m#\u0014'tI[58\u000fiX^\u0016&tl0\u0015\u0017/>U\u001csI~0'#OC?\r$-P\u0012\u0016/M_5\r om<<?]:\u00105vy?Q\u0018\u001dV'$\u0004*hE3=\u0017lA\"-\u0016ZJ"));
    public static final String a = z(z("aa\u0016C"));
    private static final String m = z(z("ZJ%(\u0002]O.%\rPD+\"\bKY4?\u0013N^14\u001eAi\u0004\u000f#~n\u0001\u0004.qc\n\u0001)tx\u0017\u001e4o}\u0010\u001b?brV]u(<SZp#1K3l4"));
    public static final String h = z(z("hq\u000b\u0001\"oz\u000f\u000fipm\u001f"));
    public static final String d = z(z("ce\nC4zd\u0003\u001f\u0018\u007fi\u0012\riaa\u0016"));
    public static final String j = z(z("VA/)1|A$-\u0003ZF$\u000b,j`\r\u0005\u0000\"\u007fV.\u0006JM -\u0006HK$' lo\u0001?,Zo#-\u0006tA$-\u0016X'56\u0004}'S_uzC\u000f\u0002\u0014)K++\u001fvY\u0001Y\u0011^M\u0012\b2W]\u001c\u001b5In\fU\u007fi15\u001d(yA0U&Q1W=\u0003tD\u00038.Ml\u0013]\"hR\u0016\u0005\u0001zG\u0010\u0003lPp1\u001c\u0006)fU- OI\"!\u0012/l\u00076*T;\u0002\u000f\u0011#X\r=u+O^:/Q9\u0005\u0016#to-\u000b%W:^\u0016\u0013M{^U#tl>&w_b0T\u0017+Y%\r\fv=?Y*)F\u00039\u0005Vn\u0005\u0016\u0011^>^\u0016)_\\6\n$p#\u0003\u0003\u0000};\u0007\u001b.(125l|9V=qki!\u001b&Pi\u0013\r+\"x\b#?lJ\u001e=w(]\u0005\u000f+kiU\r.Hq\u0015+sVkS\u0002+/O,^20Z#U\nYp?\u00025C\\\u0011\u001f\bXc \u0005?|L4>\u0000IL74lbB\u0014\r\u0010yCIZ4il &\rVm\u0015C=Uy\u000e]\u001fR'\f\u001e\"u`!U\u0012k9+\u001c/kr\u0016\ttTN06\rjKWY,4M>\r~q^\u0010\u001a2*c\u001cT\u0000\\i\u0011\u0014\u0015Z''\u000b\nYI')\u0004|o#-\u000bv@0+6z|\r[,T<I\u0002\u000eZN%>\u0005S[2\b!+f\n5\u0014Jm\u000bU\bVyT[t-8%)\u0003ZA?\t\u0003)z\u0002\u0002\u0000-0\u0007.\u0002m`$'0]=\f/!_p%\u001e\u0006Y\u007f?\u0005#B`,\u001b\bv8\u0003?\u0013]dW\u001e\u001evf$&h/d,\u0006\u0001vD\u0001Z\u000e.RQ5!XA3\u0003$n?.Z\"M#\u0017Y\r.FV90#|\u0002 \u0011M0\u0011\u001a\u0002+')85oM\u0013\u001b\u0015*bW+5Zm\u0005-1tn\u0011[\u0002Y1\u0014)~#I-\u001e6_=\u001f]\u0004hl\u0012;ws#3#7.R'--y8/+\u0012Jq\u000f=-j9\u001c\u001f(*A#\n1\\M\u000f\r2*<?\u0015$HX%*lXBR^\u000enZM\\\u0010|G#\r\u001d)\\U6\u0016,c/T$+k(\u0006#K|\u0003;lbo.\u000f0]MW\u001b\u0005aa$#\u007f_j7\u000b\u001e)R5\t\u0004Ra/\t\u0003(N\f'\u0014OI\u001f\"6sM\r_7~?\u00046p)\u007f\u0005\u0000/bY7\\ql|%)qMn\u0001_sJC$\u000b\u0016_f\r;\u001f]O\u0017\u0004lH`\u0011^5,;P\u00015p>?G\u0001]`\fT.-L\u0013\"=_'\u000e$\u0013RD3]\u0017UbI*1s?\u0002&*Zd\u00138+,r.#\u007fj#%\u0005\u0005hFI\u001b\tk^^\u001e\u0015ni__\u0010ZP\u0000;/B_\u0017<\u001eM#??\r\"_\u0002^\u0013m:\n\u0000hCx\u0012]sH<\u0005[/#q/[*cf\u0002(vNFR_\u001fo;0\u001f\u0014\u007f'7=wSI\u0002\u001f\bmB-\u0007ts~\u001c//ke\u00054\n,B\u0013.\u000by\u007f-. JL2\t\u0003Qe+?\u000f+}V\u0018\u0012a{\r\u0014\u000eJ')\r\u0013ub\u000b-+}D?(6Hd3-\niO<9\u0014L@\u000f^5R11\u0007\u0017Bl\u0003!rkb\u0007 h~[\u0012\u0015\rq\\\u0007\b\u0004tg\u0011\r\u0010^f\u001e]\u000eIa\u000f\u001cuqx\u001c\u0000)~r6CwBEM[#4r(\u0005h\\OW]w_`\u0017\t\tJR\u000e\b$(e\b \t4D\u0003\u0004\"ua*Y\u000eYm\u0014.\u000ehM(\n5O=\u0001\u001e\"QgV\u000e)Ck?\n\u0005MN+\u001f\t|E7'\u0005|Y%\u0007\u0000og\u0011\u000f\n4~\f[uv8P\u0015.j@\u00138\u007fzpU\u0004\n}J\u000f?6WF\u0014-\"y@S+(\\z.>5xeI\u00185Ao**\bIy6\u001e\u0013sg' \u001dNf+Yu4{\u000fT\u0000Y'\u0003)\u0017oAP\u000b+mE>\u0005,HCV\"hmJ\u0003<\u0016*^R]\u0015rX\u0012\u0014\u0006x;\u0002#\u007f]F4\u0019?4y3T\b.o\u0017\\6Ke\u0012U\u0004a[2\u000f!\u007fM\u0016\u0003/h@\u0013\u0003\bY>\u001e;\u000brq \u0005$Z~\n5snQ\u0007=\fYo7/t_]*(\u0015bK>\u0007+^`(\u0001%~K\f\u001cl~A6\">M~\"\u000f$B<%#\u0016Ki\u0002&*C}.43J9?\u001duzg -hxX\u0000\u00042Mb\u0015G\u0010cpI8\u0012yFU65\u007fi\u001c#\u000f_O\r9\u0014\"8\u0012<6Sg)[\u0017]iI\u00166Hc\u0015\u0006\u001emB\u001c\\\u0001s\\\"Z7v?/\u0018pyl\u0001\u001b\u0000\u007fM\u0003U\u0006IL\u0005\u00151~?\u0014 \bWXP>\u0015QK_=\u0001PLI\u0001$_]\t\u0007tKy./riJ+X\u0016PJ\u0001(\t)q\u0002U\u0002|_\u0011\u0001q^@ \u0016#zgT\"s~ER'6Qk1Grm}2\u001d ld\u0017\u001d\fj\\\u0014\u001d\u0002\\e \u0000\u001eU8\b\u001f~Ug\u0000;\u0004Yz\u0016\n/V|6\n\u0004xMP\u0000\u007fI|S!tl8!-\u000bwpU)\u000bui?[=IK^5\u0011(f,\u0018\u0000c|\n[&~Z\u001f;>U;\b*qMd.*(TY?U7*cM\"\u0015Hc\u0013)+Ol\tC\u0011WkS*\rYCI\u0018\u0006p\u007f\u0014\u001cqMC\"\u0001\u0003ldW\b"));
    public static final String c = z(z("aa\u0016_h"));
    private static final String[] z = {z(z("_m\u0004\u0019 ")), z(z("bq\u001f\u0015\nVl\u0002$\u000fve\u0015\u001f")), z(z("镤庮乫晃倱敫)")), z(z("HL%\r5\u007f(6\r3s2")), z(z("vg\u0013\u00023~l")), z(z("bq\u001f\u0015jVEK\b#;`\u000eV*v2\u0015\u001f")), z(z("N]/(gwm\b\u000b3s2"))};
    public static final String[] k = {z(z("|m\b\u00052h(\u000f\u001fgtf\u0003L7~z\u0005\t)o(\u000f\u00024ka\u0014\r3rg\bL&ulF\u0002.um\u0012\u0015jua\b\tgkm\u0014\u000f\"u|F\u001c\"i{\u0016\u00055z|\u000f\u0003):")), z(z("夲扅屗晃瘹初乃书盨瀲愄动乬瘒剁乐乕匧丱盃汌氼ｧ")), z(z("l`\u0003\u001e\";|\u000e\t5~(\u000f\u001fgz(\u0011\u0005+w(\u0012\u0004\"imF\u00054;iF\u001b&b)")), z(z("朒忟聣｠仌竄战ｧ")), z(z("smF\u001b/t(\n\r2|`\u0015L+z{\u0012L+z}\u0001\u00044;j\u0003\u001f3:")), z(z("笊券杦呢ｋ笊徟杦夑ぅ"))};

    public static String a() {
        return new SimpleDateFormat(z[5]).format(new Date());
    }

    public static String a(int i2) {
        Random random = new Random(System.currentTimeMillis());
        StringBuffer stringBuffer = new StringBuffer();
        for (int i3 = 0; i3 < i2; i3++) {
            stringBuffer.append(m.charAt(random.nextInt(m.length())));
        }
        try {
            return stringBuffer.toString();
        } catch (IllegalArgumentException e2) {
            throw e2;
        }
    }

    public static String a(String str) {
        return str.substring(str.lastIndexOf("\\") + 1);
    }

    public static String a(byte[] bArr) {
        String str = "";
        for (byte b2 : bArr) {
            try {
                String hexString = Integer.toHexString(b2 & 255);
                str = hexString.length() == 1 ? String.valueOf(str) + "0" + hexString : String.valueOf(str) + hexString;
            } catch (IllegalArgumentException e2) {
                throw e2;
            }
        }
        return str.toUpperCase();
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:18)
        */
    /* JADX WARN: Removed duplicated region for block: B:14:0x002f A[Catch: IOException -> 0x0061, TRY_ENTER, TryCatch #1 {IOException -> 0x0061, blocks: (B:8:0x0015, B:14:0x002f, B:15:0x0044, B:22:0x004c, B:20:0x0072, B:34:0x0077, B:37:0x0060, B:26:0x0054, B:28:0x0057, B:12:0x0022), top: B:7:0x0015, inners: #0, #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0057 A[Catch: IOException -> 0x0076, TRY_LEAVE, TryCatch #0 {IOException -> 0x0076, blocks: (B:26:0x0054, B:28:0x0057), top: B:25:0x0054, outer: #1 }] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x0055 -> B:11:0x0022). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:28:0x005a -> B:23:0x0052). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static java.lang.String a(java.lang.String[] r9, java.lang.String r10) {
        /*
            r1 = 0
            boolean r4 = com.wooboo.adlib_android.sc.C
            r0 = 1024(0x400, float:1.435E-42)
            byte[] r5 = new byte[r0]
            java.io.File r0 = new java.io.File
            r0.<init>(r10)
            boolean r2 = r0.exists()     // Catch: java.io.IOException -> L5d
            if (r2 == 0) goto L15
            r0.delete()     // Catch: java.io.IOException -> L5d
        L15:
            java.util.zip.ZipOutputStream r3 = new java.util.zip.ZipOutputStream     // Catch: java.io.IOException -> L61
            java.io.FileOutputStream r0 = new java.io.FileOutputStream     // Catch: java.io.IOException -> L61
            r0.<init>(r10)     // Catch: java.io.IOException -> L61
            r3.<init>(r0)     // Catch: java.io.IOException -> L61
            if (r4 == 0) goto L7a
            r0 = r1
        L22:
            java.io.File r2 = new java.io.File     // Catch: java.io.IOException -> L5f
            r6 = r9[r0]     // Catch: java.io.IOException -> L5f
            r2.<init>(r6)     // Catch: java.io.IOException -> L5f
            boolean r2 = r2.exists()     // Catch: java.io.IOException -> L5f
            if (r2 == 0) goto L52
            java.io.FileInputStream r6 = new java.io.FileInputStream     // Catch: java.io.IOException -> L61
            r2 = r9[r0]     // Catch: java.io.IOException -> L61
            r6.<init>(r2)     // Catch: java.io.IOException -> L61
            java.util.zip.ZipEntry r2 = new java.util.zip.ZipEntry     // Catch: java.io.IOException -> L61
            r7 = r9[r0]     // Catch: java.io.IOException -> L61
            java.lang.String r7 = a(r7)     // Catch: java.io.IOException -> L61
            r2.<init>(r7)     // Catch: java.io.IOException -> L61
            r3.putNextEntry(r2)     // Catch: java.io.IOException -> L61
        L44:
            int r7 = r6.read(r5)     // Catch: java.io.IOException -> L61
            if (r7 > 0) goto L70
            if (r4 != 0) goto L78
            r3.closeEntry()     // Catch: java.io.IOException -> L61
            r6.close()     // Catch: java.io.IOException -> L61
        L52:
            int r0 = r0 + 1
        L54:
            int r2 = r9.length     // Catch: java.io.IOException -> L76
            if (r0 < r2) goto L22
            r3.close()     // Catch: java.io.IOException -> L76
            if (r4 != 0) goto L52
        L5c:
            return r10
        L5d:
            r0 = move-exception
            throw r0
        L5f:
            r0 = move-exception
            throw r0     // Catch: java.io.IOException -> L61
        L61:
            r0 = move-exception
            java.lang.String[] r2 = com.wooboo.adlib_android.rc.z
            r1 = r2[r1]
            java.lang.String r0 = r0.toString()
            android.util.Log.i(r1, r0)
            java.lang.String r10 = ""
            goto L5c
        L70:
            r2 = r3
        L71:
            r8 = 0
            r2.write(r5, r8, r7)     // Catch: java.io.IOException -> L61
            goto L44
        L76:
            r0 = move-exception
            throw r0     // Catch: java.io.IOException -> L61
        L78:
            r2 = r3
            goto L71
        L7a:
            r0 = r1
            goto L54
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.rc.a(java.lang.String[], java.lang.String):java.lang.String");
    }

    public static void a(String str, String str2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(str2);
            fileOutputStream.write(str.getBytes());
            fileOutputStream.close();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public static String b() {
        return new SimpleDateFormat(z[1]).format(new Date());
    }

    public static String b(int i2) {
        String uuid = UUID.randomUUID().toString();
        Log.i(z[0], z[6] + uuid.length());
        while (uuid.length() < i2) {
            try {
                uuid = String.valueOf(uuid) + UUID.randomUUID().toString();
            } catch (IllegalArgumentException e2) {
                throw e2;
            }
        }
        return uuid.substring(0, i2);
    }

    public static String b(String str) {
        String str2 = "";
        int i2 = 0;
        int indexOf = str.indexOf("\n", 0);
        while (indexOf != -1) {
            str2 = String.valueOf(str2) + str.substring(i2, indexOf - 1);
            i2 = indexOf + 1;
            indexOf = str.indexOf("\n", i2);
        }
        return String.valueOf(str2) + str.substring(i2, str.length());
    }

    private static String b(String str, String str2) {
        File file = new File(str);
        if (!file.isDirectory()) {
            return a(new String[]{str}, str2);
        }
        File[] listFiles = file.listFiles();
        String[] strArr = new String[listFiles.length];
        for (int i2 = 0; i2 < listFiles.length; i2++) {
            try {
                strArr[i2] = listFiles[i2].getAbsolutePath();
            } catch (IllegalArgumentException e2) {
                throw e2;
            }
        }
        return a(strArr, str2);
    }

    public static byte[] b(byte[] bArr) {
        try {
            if (bArr.length % 2 != 0) {
                throw new IllegalArgumentException(z[2]);
            }
            byte[] bArr2 = new byte[bArr.length / 2];
            for (int i2 = 0; i2 < bArr.length; i2 += 2) {
                try {
                    bArr2[i2 / 2] = (byte) Integer.parseInt(new String(bArr, i2, 2), 16);
                } catch (IllegalArgumentException e2) {
                    throw e2;
                }
            }
            return bArr2;
        } catch (IllegalArgumentException e3) {
            throw e3;
        }
    }

    public static String c() {
        if (!Environment.getExternalStorageState().toLowerCase().equals(z[4])) {
            return "";
        }
        String absolutePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        if (!absolutePath.endsWith("/")) {
            absolutePath = String.valueOf(absolutePath) + "/";
        }
        Log.i(z[0], z[3] + absolutePath);
        return absolutePath;
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:18)
        */
    /* JADX WARN: Removed duplicated region for block: B:24:0x007c A[EDGE_INSN: B:24:0x007c->B:27:0x007e BREAK  A[LOOP:1: B:22:0x0075->B:26:0x0071]] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x006f A[EDGE_INSN: B:29:0x006f->B:19:0x006f BREAK  A[LOOP:1: B:22:0x0075->B:26:0x0071], SYNTHETIC] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x007a -> B:19:0x006f). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.util.Vector c(java.lang.String r11, java.lang.String r12) {
        /*
            r3 = 0
            r1 = 0
            boolean r6 = com.wooboo.adlib_android.sc.C
            java.lang.String[] r0 = com.wooboo.adlib_android.rc.z
            r0 = r0[r1]
            android.util.Log.i(r0, r11)
            java.lang.String[] r0 = com.wooboo.adlib_android.rc.z
            r0 = r0[r1]
            android.util.Log.i(r0, r12)
            java.util.Vector r2 = new java.util.Vector
            r2.<init>()
            java.io.File r0 = new java.io.File
            r0.<init>(r11)
            boolean r0 = r0.exists()
            if (r0 == 0) goto L85
            java.io.BufferedInputStream r0 = new java.io.BufferedInputStream     // Catch: java.io.IOException -> L4c
            java.io.FileInputStream r4 = new java.io.FileInputStream     // Catch: java.io.IOException -> L4c
            r4.<init>(r11)     // Catch: java.io.IOException -> L4c
            r0.<init>(r4)     // Catch: java.io.IOException -> L4c
            java.util.zip.ZipInputStream r7 = new java.util.zip.ZipInputStream     // Catch: java.io.IOException -> L4c
            r7.<init>(r0)     // Catch: java.io.IOException -> L4c
            java.io.File r0 = new java.io.File     // Catch: java.io.IOException -> L4c
            r0.<init>(r12)     // Catch: java.io.IOException -> L4c
            boolean r4 = r0.exists()     // Catch: java.io.IOException -> L4a
            if (r4 != 0) goto L3f
            r0.mkdirs()     // Catch: java.io.IOException -> L4a
        L3f:
            java.util.zip.ZipEntry r0 = r7.getNextEntry()     // Catch: java.io.IOException -> L4c
            if (r0 != 0) goto L5a
            r7.close()     // Catch: java.io.IOException -> L4c
            r0 = r2
        L49:
            return r0
        L4a:
            r0 = move-exception
            throw r0     // Catch: java.io.IOException -> L4c
        L4c:
            r0 = move-exception
            java.lang.String[] r2 = com.wooboo.adlib_android.rc.z
            r1 = r2[r1]
            java.lang.String r0 = r0.toString()
            android.util.Log.i(r1, r0)
            r0 = r3
            goto L49
        L5a:
            java.lang.String r8 = r0.getName()     // Catch: java.io.IOException -> L4c
            java.io.File r0 = new java.io.File     // Catch: java.io.IOException -> L4c
            r0.<init>(r12, r8)     // Catch: java.io.IOException -> L4c
            java.io.FileOutputStream r4 = new java.io.FileOutputStream     // Catch: java.io.IOException -> L4c
            r4.<init>(r0)     // Catch: java.io.IOException -> L4c
            r0 = 512(0x200, float:7.175E-43)
            byte[] r9 = new byte[r0]     // Catch: java.io.IOException -> L4c
            if (r6 == 0) goto L75
            r0 = r1
        L6f:
            r5 = r0
            r0 = r4
        L71:
            r10 = 0
            r0.write(r9, r10, r5)     // Catch: java.io.IOException -> L4c
        L75:
            int r0 = r7.read(r9)     // Catch: java.io.IOException -> L4c
            r5 = -1
            if (r0 != r5) goto L6f
            if (r6 != 0) goto L87
            r4.close()     // Catch: java.io.IOException -> L4c
            r2.add(r8)     // Catch: java.io.IOException -> L4c
            goto L3f
        L85:
            r0 = r3
            goto L49
        L87:
            r5 = r0
            r0 = r4
            goto L71
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.rc.c(java.lang.String, java.lang.String):java.util.Vector");
    }

    public static void c(String str) {
        File file = new File(str);
        try {
            if (file.exists()) {
                return;
            }
            file.mkdir();
        } catch (IllegalArgumentException e2) {
            throw e2;
        }
    }

    public static String d(String str) throws IOException {
        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(str));
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataInputStream));
        String str2 = "";
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine == null) {
                try {
                    dataInputStream.close();
                    return str2;
                } catch (IOException e2) {
                    throw e2;
                }
            }
            str2 = String.valueOf(str2) + readLine;
        }
    }

    public static byte[] e(String str) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(str);
        byte[] bArr = new byte[fileInputStream.available()];
        fileInputStream.read(bArr);
        return bArr;
    }

    public static String f(String str) {
        return "";
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i2 = 0; length > i2; i2++) {
            char c3 = cArr[i2];
            switch (i2 % 5) {
                case 0:
                    c2 = 27;
                    break;
                case 1:
                    c2 = '\b';
                    break;
                case 2:
                    c2 = 'f';
                    break;
                case nb.p /* 3 */:
                    c2 = 'l';
                    break;
                default:
                    c2 = 'G';
                    break;
            }
            cArr[i2] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'G');
        }
        return charArray;
    }
}
