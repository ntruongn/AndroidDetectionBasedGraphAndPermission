package com.kuguo.b;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class h {
    private String a;
    private boolean e;
    private int d = 0;
    private Map b = new LinkedHashMap();
    private Map c = new LinkedHashMap();

    public h(String str) {
        this.a = str;
    }

    public Map a() {
        return this.c;
    }

    public void a(String str, Object obj) {
        this.b.put(str, obj);
    }

    public int b() {
        return this.d;
    }

    public String c() {
        return this.a;
    }

    public String d() {
        if (this.b.isEmpty()) {
            return "";
        }
        ArrayList arrayList = new ArrayList();
        for (String str : this.b.keySet()) {
            Object obj = this.b.get(str);
            if (obj != null) {
                arrayList.add(new BasicNameValuePair(str, obj.toString()));
            }
        }
        String format = URLEncodedUtils.format(arrayList, "utf-8");
        return this.e ? com.kuguo.d.b.a(format) : format;
    }

    public String toString() {
        String d = d();
        return d.equals("") ? this.a : this.a + "?" + d;
    }
}
