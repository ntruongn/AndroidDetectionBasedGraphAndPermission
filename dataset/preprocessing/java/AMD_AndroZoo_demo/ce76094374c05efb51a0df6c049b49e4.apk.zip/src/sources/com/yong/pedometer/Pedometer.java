package com.yong.pedometer;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.kuguo.pushads.PushAdsManager;
import com.mobclick.android.MobclickAgent;
import com.mobclick.android.UmengConstants;
import com.uucun.adsdk.UUAppConnect;
import com.wooboo.adlib_android.ImpressionAdView;
import com.wooboo.adlib_android.nb;
import com.yong.pedometer.StepService;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class Pedometer extends Activity {
    private static final int CALORIES_MSG = 5;
    private static final int DISTANCE_MSG = 3;
    private static final int MENU_PAUSE = 1;
    private static final int MENU_QUIT = 9;
    private static final int MENU_RESET = 3;
    private static final int MENU_RESUME = 2;
    private static final int MENU_SETTINGS = 8;
    private static final int PACE_MSG = 2;
    private static final int SPEED_MSG = 4;
    private static final int STEPS_MSG = 1;
    private static final String TAG = "Pedometer";
    private Button btn_jfq;
    private int mCaloriesValue;
    private TextView mCaloriesValueView;
    private float mDesiredPaceOrSpeed;
    TextView mDesiredPaceView;
    private float mDistanceValue;
    private TextView mDistanceValueView;
    private boolean mIsMetric;
    private boolean mIsRunning;
    private int mMaintain;
    private float mMaintainInc;
    private int mPaceValue;
    private TextView mPaceValueView;
    private PedometerSettings mPedometerSettings;
    private StepService mService;
    private SharedPreferences mSettings;
    private float mSpeedValue;
    private TextView mSpeedValueView;
    private int mStepValue;
    private TextView mStepValueView;
    private Utils mUtils;
    private boolean mQuitting = false;
    public boolean isPause = false;
    private ServiceConnection mConnection = new ServiceConnection() { // from class: com.yong.pedometer.Pedometer.1
        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName className, IBinder service) {
            Pedometer.this.mService = ((StepService.StepBinder) service).getService();
            Pedometer.this.mService.registerCallback(Pedometer.this.mCallback);
            Pedometer.this.mService.reloadSettings();
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName className) {
            Pedometer.this.mService = null;
        }
    };
    private StepService.ICallback mCallback = new StepService.ICallback() { // from class: com.yong.pedometer.Pedometer.2
        @Override // com.yong.pedometer.StepService.ICallback
        public void stepsChanged(int value) {
            Pedometer.this.mHandler.sendMessage(Pedometer.this.mHandler.obtainMessage(1, value, 0));
        }

        @Override // com.yong.pedometer.StepService.ICallback
        public void paceChanged(int value) {
            Pedometer.this.mHandler.sendMessage(Pedometer.this.mHandler.obtainMessage(2, value, 0));
        }

        @Override // com.yong.pedometer.StepService.ICallback
        public void distanceChanged(float value) {
            Pedometer.this.mHandler.sendMessage(Pedometer.this.mHandler.obtainMessage(3, (int) (1000.0f * value), 0));
        }

        @Override // com.yong.pedometer.StepService.ICallback
        public void speedChanged(float value) {
            Pedometer.this.mHandler.sendMessage(Pedometer.this.mHandler.obtainMessage(4, (int) (1000.0f * value), 0));
        }

        @Override // com.yong.pedometer.StepService.ICallback
        public void caloriesChanged(float value) {
            Pedometer.this.mHandler.sendMessage(Pedometer.this.mHandler.obtainMessage(5, (int) value, 0));
        }
    };
    private Handler mHandler = new Handler() { // from class: com.yong.pedometer.Pedometer.3
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    Pedometer.this.mStepValue = msg.arg1;
                    Pedometer.this.mStepValueView.setText(new StringBuilder().append(Pedometer.this.mStepValue).toString());
                    return;
                case 2:
                    Pedometer.this.mPaceValue = msg.arg1;
                    if (Pedometer.this.mPaceValue <= 0) {
                        Pedometer.this.mPaceValueView.setText("0");
                        return;
                    } else {
                        Pedometer.this.mPaceValueView.setText(new StringBuilder().append(Pedometer.this.mPaceValue).toString());
                        return;
                    }
                case nb.p /* 3 */:
                    Pedometer.this.mDistanceValue = msg.arg1 / 1000.0f;
                    if (Pedometer.this.mDistanceValue <= 0.0f) {
                        Pedometer.this.mDistanceValueView.setText("0");
                        return;
                    } else {
                        Pedometer.this.mDistanceValueView.setText(new StringBuilder().append(Pedometer.this.mDistanceValue + 1.0E-6f).toString().substring(0, 5));
                        return;
                    }
                case 4:
                    Pedometer.this.mSpeedValue = msg.arg1 / 1000.0f;
                    if (Pedometer.this.mSpeedValue <= 0.0f) {
                        Pedometer.this.mSpeedValueView.setText("0");
                        return;
                    } else {
                        Pedometer.this.mSpeedValueView.setText(new StringBuilder().append(Pedometer.this.mSpeedValue + 1.0E-6f).toString().substring(0, 4));
                        return;
                    }
                case 5:
                    Pedometer.this.mCaloriesValue = msg.arg1;
                    if (Pedometer.this.mCaloriesValue <= 0) {
                        Pedometer.this.mCaloriesValueView.setText("0");
                        return;
                    } else {
                        Pedometer.this.mCaloriesValueView.setText(new StringBuilder().append(Pedometer.this.mCaloriesValue).toString());
                        return;
                    }
                default:
                    super.handleMessage(msg);
                    return;
            }
        }
    };

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "[ACTIVITY] onCreate");
        super.onCreate(savedInstanceState);
        this.mStepValue = 0;
        this.mPaceValue = 0;
        setContentView(R.layout.main);
        this.mUtils = Utils.getInstance();
        showAD();
    }

    public void showAD() {
        LinearLayout adlayout = (LinearLayout) findViewById(R.id.main_layout);
        new DisplayMetrics();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        ImpressionAdView ad = new ImpressionAdView(this, adlayout, 0, (dm.heightPixels / 2) + 50, -1, false, null);
        ad.show(60);
        UUAppConnect.getInstance(this).initSdk();
        this.btn_jfq = (Button) findViewById(R.id.btn_jfq);
        this.btn_jfq.setOnClickListener(new View.OnClickListener() { // from class: com.yong.pedometer.Pedometer.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                UUAppConnect.getInstance(Pedometer.this).showOffers();
            }
        });
    }

    @Override // android.app.Activity
    protected void onStart() {
        Log.i(TAG, "[ACTIVITY] onStart");
        super.onStart();
    }

    @Override // android.app.Activity
    protected void onResume() {
        int i;
        int i2;
        int i3;
        Log.i(TAG, "[ACTIVITY] onResume");
        super.onResume();
        this.mSettings = PreferenceManager.getDefaultSharedPreferences(this);
        this.mPedometerSettings = new PedometerSettings(this.mSettings);
        this.mUtils.setSpeak(this.mSettings.getBoolean("speak", false));
        this.mIsRunning = this.mPedometerSettings.isServiceRunning();
        if (!this.mIsRunning && this.mPedometerSettings.isNewStart()) {
            startStepService();
            bindStepService();
        } else if (this.mIsRunning) {
            bindStepService();
        }
        this.mPedometerSettings.clearServiceRunning();
        this.mStepValueView = (TextView) findViewById(R.id.step_value);
        this.mPaceValueView = (TextView) findViewById(R.id.pace_value);
        this.mDistanceValueView = (TextView) findViewById(R.id.distance_value);
        this.mSpeedValueView = (TextView) findViewById(R.id.speed_value);
        this.mCaloriesValueView = (TextView) findViewById(R.id.calories_value);
        this.mDesiredPaceView = (TextView) findViewById(R.id.desired_pace_value);
        this.mIsMetric = this.mPedometerSettings.isMetric();
        TextView textView = (TextView) findViewById(R.id.distance_units);
        if (this.mIsMetric) {
            i = R.string.kilometers;
        } else {
            i = R.string.miles;
        }
        textView.setText(getString(i));
        TextView textView2 = (TextView) findViewById(R.id.speed_units);
        if (this.mIsMetric) {
            i2 = R.string.kilometers_per_hour;
        } else {
            i2 = R.string.miles_per_hour;
        }
        textView2.setText(getString(i2));
        this.mMaintain = this.mPedometerSettings.getMaintainOption();
        ((LinearLayout) findViewById(R.id.desired_pace_control)).setVisibility(this.mMaintain != PedometerSettings.M_NONE ? 0 : 8);
        if (this.mMaintain == PedometerSettings.M_PACE) {
            this.mMaintainInc = 5.0f;
            this.mDesiredPaceOrSpeed = this.mPedometerSettings.getDesiredPace();
        } else if (this.mMaintain == PedometerSettings.M_SPEED) {
            this.mDesiredPaceOrSpeed = this.mPedometerSettings.getDesiredSpeed();
            this.mMaintainInc = 0.1f;
        }
        Button button1 = (Button) findViewById(R.id.button_desired_pace_lower);
        button1.setOnClickListener(new View.OnClickListener() { // from class: com.yong.pedometer.Pedometer.5
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Pedometer.this.mDesiredPaceOrSpeed -= Pedometer.this.mMaintainInc;
                Pedometer.this.mDesiredPaceOrSpeed = Math.round(Pedometer.this.mDesiredPaceOrSpeed * 10.0f) / 10.0f;
                Pedometer.this.displayDesiredPaceOrSpeed();
                Pedometer.this.setDesiredPaceOrSpeed(Pedometer.this.mDesiredPaceOrSpeed);
            }
        });
        Button button2 = (Button) findViewById(R.id.button_desired_pace_raise);
        button2.setOnClickListener(new View.OnClickListener() { // from class: com.yong.pedometer.Pedometer.6
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Pedometer.this.mDesiredPaceOrSpeed += Pedometer.this.mMaintainInc;
                Pedometer.this.mDesiredPaceOrSpeed = Math.round(Pedometer.this.mDesiredPaceOrSpeed * 10.0f) / 10.0f;
                Pedometer.this.displayDesiredPaceOrSpeed();
                Pedometer.this.setDesiredPaceOrSpeed(Pedometer.this.mDesiredPaceOrSpeed);
            }
        });
        if (this.mMaintain != PedometerSettings.M_NONE) {
            TextView textView3 = (TextView) findViewById(R.id.desired_pace_label);
            if (this.mMaintain == PedometerSettings.M_PACE) {
                i3 = R.string.desired_pace;
            } else {
                i3 = R.string.desired_speed;
            }
            textView3.setText(i3);
        }
        displayDesiredPaceOrSpeed();
        MobclickAgent.onResume(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void displayDesiredPaceOrSpeed() {
        if (this.mMaintain == PedometerSettings.M_PACE) {
            this.mDesiredPaceView.setText(new StringBuilder().append((int) this.mDesiredPaceOrSpeed).toString());
        } else {
            this.mDesiredPaceView.setText(new StringBuilder().append(this.mDesiredPaceOrSpeed).toString());
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        Log.i(TAG, "[ACTIVITY] onPause");
        if (this.mIsRunning) {
            unbindStepService();
        }
        if (this.mQuitting) {
            this.mPedometerSettings.saveServiceRunningWithNullTimestamp(this.mIsRunning);
        } else {
            this.mPedometerSettings.saveServiceRunningWithTimestamp(this.mIsRunning);
        }
        super.onPause();
        savePaceSetting();
        MobclickAgent.onPause(this);
    }

    @Override // android.app.Activity
    protected void onStop() {
        Log.i(TAG, "[ACTIVITY] onStop");
        super.onStop();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        Log.i(TAG, "[ACTIVITY] onDestroy");
        super.onDestroy();
        ImpressionAdView.close();
        PushAdsManager.getInstance().receivePushMessage(this);
    }

    @Override // android.app.Activity
    protected void onRestart() {
        Log.i(TAG, "[ACTIVITY] onRestart");
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setDesiredPaceOrSpeed(float desiredPaceOrSpeed) {
        if (this.mService != null) {
            if (this.mMaintain == PedometerSettings.M_PACE) {
                this.mService.setDesiredPace((int) desiredPaceOrSpeed);
            } else if (this.mMaintain == PedometerSettings.M_SPEED) {
                this.mService.setDesiredSpeed(desiredPaceOrSpeed);
            }
        }
    }

    private void savePaceSetting() {
        this.mPedometerSettings.savePaceOrSpeedSetting(this.mMaintain, this.mDesiredPaceOrSpeed);
    }

    private void startStepService() {
        if (!this.mIsRunning) {
            Log.i(TAG, "[SERVICE] Start");
            this.mIsRunning = true;
            startService(new Intent(this, (Class<?>) StepService.class));
        }
    }

    private void bindStepService() {
        Log.i(TAG, "[SERVICE] Bind");
        bindService(new Intent(this, (Class<?>) StepService.class), this.mConnection, 3);
    }

    private void unbindStepService() {
        Log.i(TAG, "[SERVICE] Unbind");
        unbindService(this.mConnection);
    }

    private void stopStepService() {
        Log.i(TAG, "[SERVICE] Stop");
        if (this.mService != null) {
            Log.i(TAG, "[SERVICE] stopService");
            stopService(new Intent(this, (Class<?>) StepService.class));
        }
        this.mIsRunning = false;
    }

    private void resetValues(boolean updateDisplay) {
        if (this.mService != null && this.mIsRunning) {
            this.mService.resetValues();
            return;
        }
        this.mStepValueView.setText("0");
        this.mPaceValueView.setText("0");
        this.mDistanceValueView.setText("0");
        this.mSpeedValueView.setText("0");
        this.mCaloriesValueView.setText("0");
        SharedPreferences state = getSharedPreferences(UmengConstants.AtomKey_State, 0);
        SharedPreferences.Editor stateEditor = state.edit();
        if (updateDisplay) {
            stateEditor.putInt("steps", 0);
            stateEditor.putInt("pace", 0);
            stateEditor.putFloat("distance", 0.0f);
            stateEditor.putFloat("speed", 0.0f);
            stateEditor.putFloat("calories", 0.0f);
            stateEditor.commit();
        }
    }

    @Override // android.app.Activity
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.clear();
        if (this.mIsRunning) {
            menu.add(0, 1, 0, R.string.pause).setIcon(17301539).setShortcut('1', 'p');
        } else {
            menu.add(0, 2, 0, R.string.resume).setIcon(17301540).setShortcut('1', 'p');
        }
        menu.add(0, 3, 0, R.string.reset).setIcon(17301560).setShortcut('2', 'r');
        menu.add(0, 8, 0, R.string.settings).setIcon(17301577).setShortcut('8', 's').setIntent(new Intent(this, (Class<?>) Settings.class));
        menu.add(0, MENU_QUIT, 0, R.string.quit).setIcon(17301552).setShortcut('9', 'q');
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                this.isPause = true;
                unbindStepService();
                stopStepService();
                return true;
            case 2:
                startStepService();
                bindStepService();
                return true;
            case nb.p /* 3 */:
                resetValues(true);
                return true;
            case 4:
            case 5:
            case nb.s /* 6 */:
            case nb.t /* 7 */:
            case 8:
            default:
                return false;
            case MENU_QUIT /* 9 */:
                resetValues(false);
                if (!this.isPause) {
                    unbindStepService();
                    stopStepService();
                }
                this.mQuitting = true;
                finish();
                return true;
        }
    }
}
