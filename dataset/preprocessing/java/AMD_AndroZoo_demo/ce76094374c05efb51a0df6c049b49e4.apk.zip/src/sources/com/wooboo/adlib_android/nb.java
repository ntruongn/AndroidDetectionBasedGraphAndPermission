package com.wooboo.adlib_android;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class nb {
    protected static final int M = 2;
    protected static final int Y = 1;
    protected static final int Z = 2;
    protected static final int ab = 3;
    public static final int c = 30000;
    public static final long d = 3600000;
    protected static final int db = 0;
    public static final int e = 5000;
    protected static final int eb = -1;
    protected static final int fb = 10;
    protected static final int gb = 8000;
    protected static final int hb = 2000;
    protected static final int kb = 6000;
    protected static final int lb = 40;
    public static final int m = 0;
    protected static final int mb = 120;
    public static final int n = 1;
    protected static final int nb = 200;
    public static final int o = 2;
    protected static final int ob = 300;
    public static final int p = 3;
    public static final int q = 4;
    public static final int r = 5;
    public static final int s = 6;
    public static final int t = 7;
    public static final int u = 8;
    protected static final String bb = z(z("/<\u0001>9\u0017s=\u0018\u001dXa@n"));
    public static final String v = z(z("缩纏狘凩乛伋｟讙穑偏醵讆ｯ"));
    public static final String h = z(z("\u0010'\u001a,lW|\u000f83V$\u000134\u0017<@?9\u0015}\r2y\f6A/"));
    public static final String tb = z(z("Ie_naO"));
    public static final String y = z(z("\u000f\u0007\u000713"));
    protected static final String pb = z(z("#2C&\u0017U)3wlW|5\u0002\n\u000b\u000eD"));
    protected static final String jb = z(z("I}\\"));
    public static final String I = z(z("惐泲杧\u000f\u0012匙｟撣伀斶沭辈蠢｝"));
    protected static final String L = z(z("\u000f<\u0001>9\u00172\nr2\u001a"));
    public static final String D = z(z("\u000b6\r\u00173\u0001"));
    public static final String H = z(z("\u0019#\u001e0?\u001b2\u001a59\u0016}\u000f,="));
    public static final String C = z(z("\u00136\u0017\b?\u00156"));
    public static final String k = z(z("\u0010'\u001a,lW|_lxH}^rgOaA,3"));
    public static final String E = z(z("\b:\n"));
    public static final String x = z(z("\u000f\f\u00078"));
    public static final String B = z(z("\b;\u000123"));
    public static final String j = z(z("W&\u001e8"));
    protected static final String ib = z(z("J}\\"));
    public static final String J = z(z("厩珣旞爔杺輗亥B书逩儵寚被奭赳ｴ认儦匤輫聹爛杂凑察袽"));
    public static final String A = z(z("\u0011>\u000b5"));
    public static final String w = z(z("\u00197<9'\r6\u001d(\u0002\u0011>\u000b"));
    public static final String g = z(z("\u0010'\u001a,lW|\u000f83V$\u000134\u0017<@?9\u0015}\r2y\b6"));
    public static final String G = z(z("\u0019?\u000b.\",:\u00039"));
    public static final String z = z(z("\u0011>\u001d5"));
    protected static final String cb = z(z(",6\u000297\u001cs=\u0018\u001dXa@n"));
    public static final String F = z(z("\u001b=\u001d"));
    public static final String b = z(z("Hc^"));
    protected static final String qb = z(z("V2\u001e7zV!\u000f.zV)\u0007,zV4\u0014px\f2\u001cr1\u0002\u007f@>,J\u007f@(7\n}\f&dT}\u0014px\f4\u0014px\f2\u001cr\"\u001f)Bre\u001f#Br;\bgBr7\u000e:Br$\u0015%\fpx\u001f:\bpx\u0012#\u000b;zV9\u001e;zV7\u0001?zV7\u0001?.T}\u001a$\"T}\u000b$3"));
    public static final String rb = z(z("\u001eg\u000bkc\u0019f\b93AbZ=e\u001d2\u000fedJ2\f?4KdVm5Ne"));
    public static final String i = z(z("W "));
    public static final String K = z(z("@c^lfHc^lfHc^lf"));
    public static final String a = z(z("\u001b<\u0003r!\u0017<\f39V\u0004\u000134\u0017<*3!\u0016?\u0001=2+6\u001c*?\u001b6"));
    public static final String f = z(z("\u00197\u000br!\u0017<\f39V0\u00011x\u001b="));
    public static final String l = z(z("\u0010'\u001a,lW|_lxH}^rgOaA(3"));
    public static final String sb = z(z("L5YeoHeYng\u001a6Zna\u001dj\u000f:aAd\njo\u001bbWla\u001b2"));
    protected static final byte[] N = {104, 116, 116, 112, 58, 47, 47, 97, 100, 101, 46, 119, 111, 111, 98, 111, 111, 46, 99, 111, 109, 46, 99, 110, 47, 97, 47, 112, 49};
    protected static final byte[] O = {104, 116, 116, 112, 58, 47, 47, 112, 49, 46, 49, 56, 57, 119, 111, 114, 107, 115, 46, 99, 111, 109, 47, 97, 47, 112, 49};
    protected static final byte[] P = {104, 116, 116, 112, 58, 47, 47, 97, 100, 101, 46, 119, 111, 111, 98, 111, 111, 46, 99, 111, 109, 46, 99, 110, 47, 116, 47, 116, 101, 115, 116};
    protected static final byte[] Q = {104, 116, 116, 112, 58, 47, 47, 112, 49, 46, 49, 56, 57, 119, 111, 114, 107, 115, 46, 99, 111, 109, 47, 116, 47, 116, 101, 115, 116};
    protected static final byte[] R = {104, 116, 116, 112, 58, 47, 47, 49, 48, 46, 48, 46, 48, 46, 49, 55, 50, 47, 116, 47, 116, 101, 115, 116};
    protected static final byte[] S = {104, 116, 116, 112, 58, 47, 47, 49, 48, 46, 48, 46, 48, 46, 49, 55, 50, 47, 97, 47, 112, 49};
    protected static final byte[] T = {104, 116, 116, 112, 58, 47, 47, 49, 48, 46, 48, 46, 48, 46, 49, 55, 50, 47, 97, 47, 112, 49};
    protected static final byte[] U = {104, 116, 116, 112, 58, 47, 47, 49, 48, 46, 48, 46, 48, 46, 49, 55, 50, 47, 116, 47, 116, 101, 115, 116};
    protected static final byte[] V = {97, 100, 101, 46, 119, 111, 111, 98, 111, 111, 46, 99, 111, 109, 46, 99, 110};
    protected static final byte[] W = {104, 116, 116, 112, 58, 47, 47, 97, 100, 101, 46, 119, 111, 111, 98, 111, 111, 46, 99, 111, 109, 46, 99, 110, 47, 116, 101, 47, 115};
    protected static final byte[] X = {104, 116, 116, 112, 58, 47, 47, 97, 100, 101, 46, 119, 111, 111, 98, 111, 111, 46, 99, 111, 109, 46, 99, 110, 47, 112, 101, 47, 115};
    public static String ub = "1";

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i2 = 0; length > i2; i2++) {
            char c3 = cArr[i2];
            switch (i2 % 5) {
                case 0:
                    c2 = 'x';
                    break;
                case 1:
                    c2 = 'S';
                    break;
                case 2:
                    c2 = 'n';
                    break;
                case 3:
                    c2 = '\\';
                    break;
                default:
                    c2 = 'V';
                    break;
            }
            cArr[i2] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'V');
        }
        return charArray;
    }
}
