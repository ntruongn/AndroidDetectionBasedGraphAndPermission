package com.wooboo.download;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;
import com.wooboo.adlib_android.AdActivity;
import com.wooboo.adlib_android.mc;
import com.wooboo.adlib_android.nb;
import com.wooboo.adlib_android.pc;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Timer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class j implements g {
    NotificationManager b;
    Notification d;
    private Context f;
    c l;
    private static final String[] z = {z(z("缚细犄冰乺伸６诅稈偮醆诏Ｓ")), z(z("乀轧十尃彷妀")), z(z("欨圲丹轸")), z(z("\u0007uQd\u001b\u0018\u007f@s\u001e(\u007f\u0012j\u0019\u0018nSw\u0003")), z(z("嶹丑轏%")), z(z("彋姑丹轸")), z(z("%uFl\u0011\"ySq\u001e$t")), z(z("\u0018\u007f@s\u001e(\u007f\u0012a\u0018<t^j\u0016/:td\u001e'\u007fV")), z(z("乀轧丟忆控祱")), z(z("\u0002TaQ6\u0007VmH6\u0005[u@%")), z(z("歵轵仄只互寂裟＾炼册枮眑")), z(z("惣朓")), z(z("8r]r9.\u007fVL\u00198nSi\u001bq")), z(z("\"iej\u0018)u]")), z(z("乀轧丟忆控祱悲")), z(z("\u0018^mA5"))};
    private static j n = null;
    public String a = "";
    private HashMap c = new HashMap();
    private ArrayList e = new ArrayList();
    private PendingIntent g = null;
    private final int h = 10000;
    private final int i = 11000;
    private pc j = null;
    private int k = 1;
    f m = null;
    private Handler o = new a(this);

    private j(Context context) {
        this.f = null;
        this.f = context;
        d();
        b();
    }

    public static j a(Context context) {
        if (n != null) {
            return n;
        }
        n = new j(context);
        return n;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(j jVar) {
        jVar.c();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(j jVar, String str) {
        jVar.a(str);
    }

    private void a(String str) {
        Toast.makeText(this.f, z[0], 1).show();
        this.m.e(str);
        if (this.c.containsKey(str)) {
            this.b.cancel(((Integer) this.c.get(str)).intValue());
        }
    }

    private void c() {
        Message message = new Message();
        message.what = 110;
        this.o.sendMessage(message);
    }

    private void d() {
        try {
            this.j = pc.a(this.f, (String) null);
            this.m = f.a(this.f, this, this.j, this.a);
            this.b = (NotificationManager) this.f.getSystemService(z[6]);
            new Timer().schedule(new m(this), 1000L, 20000L);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'K';
                    break;
                case 1:
                    c = 26;
                    break;
                case 2:
                    c = '2';
                    break;
                case nb.p /* 3 */:
                    c = 5;
                    break;
                default:
                    c = 'w';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'w');
        }
        return charArray;
    }

    @Override // com.wooboo.download.g
    public void a() {
        this.a = h.b(this.f);
    }

    @Override // com.wooboo.download.g
    public void a(int i) {
        boolean z2 = h.e;
        mc.c(z[12] + Integer.valueOf(i));
        Iterator it = this.e.iterator();
        if (z2) {
            this.b.cancel(((Integer) it.next()).intValue());
        }
        while (it.hasNext()) {
            this.b.cancel(((Integer) it.next()).intValue());
        }
        if (i == 0) {
            this.b.cancel(10000);
            if (!z2) {
                return;
            }
        }
        Intent intent = new Intent(this.f, (Class<?>) AdActivity.class);
        intent.putExtra(z[9], true);
        intent.putExtra(z[13], true);
        intent.putExtra(z[15], false);
        intent.setFlags(335544320);
        this.g = PendingIntent.getActivity(this.f, 0, intent, 134217728);
        this.d = new Notification(17301633, z[14], System.currentTimeMillis());
        this.d.setLatestEventInfo(this.f, z[8], z[11] + Integer.valueOf(i) + z[10], this.g);
        this.b.notify(10000, this.d);
    }

    @Override // com.wooboo.download.g
    public void a(d dVar) {
        if (this.a == "") {
            return;
        }
        this.j.d(dVar.k);
        dVar.g = this.a;
        this.l = new c(this.f, dVar, this.o, this.j);
        this.k++;
        this.c.put(dVar.k, Integer.valueOf(this.k));
        b(dVar.k, 0);
        this.m.a(dVar.k, this.l);
        dVar.f = this.l.a();
        this.l.d();
    }

    public void a(String str, int i) {
        b(str, i);
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x0047, code lost:
    
        if (r2 != false) goto L6;
     */
    @Override // com.wooboo.download.g
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void a(boolean r10) {
        /*
            r9 = this;
            r8 = 11000(0x2af8, float:1.5414E-41)
            r0 = 0
            r1 = 1
            boolean r2 = com.wooboo.download.h.e
            android.content.Intent r3 = new android.content.Intent
            r3.<init>()
            r4 = 335544320(0x14000000, float:6.4623485E-27)
            r3.setFlags(r4)
            android.content.Context r4 = r9.f
            r5 = 134217728(0x8000000, float:3.85186E-34)
            android.app.PendingIntent r3 = android.app.PendingIntent.getActivity(r4, r0, r3, r5)
            r9.g = r3
            android.app.Notification r3 = new android.app.Notification
            r4 = 17301633(0x1080081, float:2.4979616E-38)
            java.lang.String[] r5 = com.wooboo.download.j.z
            r5 = r5[r1]
            long r6 = java.lang.System.currentTimeMillis()
            r3.<init>(r4, r5, r6)
            r9.d = r3
            android.app.Notification r3 = r9.d
            android.content.Context r4 = r9.f
            java.lang.String[] r5 = com.wooboo.download.j.z
            r6 = 2
            r5 = r5[r6]
            java.lang.String[] r6 = com.wooboo.download.j.z
            r6 = r6[r1]
            android.app.PendingIntent r7 = r9.g
            r3.setLatestEventInfo(r4, r5, r6, r7)
            if (r10 == 0) goto L49
            android.app.NotificationManager r3 = r9.b
            android.app.Notification r4 = r9.d
            r3.notify(r8, r4)
            if (r2 == 0) goto L4e
        L49:
            android.app.NotificationManager r3 = r9.b
            r3.cancel(r8)
        L4e:
            int r3 = com.wooboo.adlib_android.mc.a
            if (r3 == 0) goto L56
            if (r2 == 0) goto L57
        L54:
            com.wooboo.download.h.e = r0
        L56:
            return
        L57:
            r0 = r1
            goto L54
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.download.j.a(boolean):void");
    }

    public void b() {
        if (this.a == "") {
            this.a = h.b(this.f);
            if (this.a != "") {
                this.m.a(true, this.a);
            }
        }
        mc.c(z[3]);
        a(this.j.e() ? false : true);
        c();
    }

    public void b(String str) {
        this.j.c(str);
        this.e.add(Integer.valueOf(((Integer) this.c.get(str)).intValue()));
        this.m.c();
        this.m.d(str);
    }

    public void b(String str, int i) {
        int intValue = ((Integer) this.c.get(str)).intValue();
        d b = this.m.b(str);
        if (b == null) {
            this.b.cancel(intValue);
            return;
        }
        Intent intent = new Intent();
        intent.setFlags(335544320);
        this.g = PendingIntent.getActivity(this.f, 0, intent, 134217728);
        this.d = new Notification(17301633, String.valueOf(b.i) + z[5], System.currentTimeMillis());
        this.d.setLatestEventInfo(this.f, z[2], String.valueOf(b.i) + z[4] + Integer.valueOf(i).toString() + "%", this.g);
        this.b.notify(intValue, this.d);
    }

    public void c(String str) {
        this.j.e(str);
        mc.c(z[7]);
        this.m.a(str, (c) null);
        this.b.cancel(((Integer) this.c.get(str)).intValue());
    }
}
