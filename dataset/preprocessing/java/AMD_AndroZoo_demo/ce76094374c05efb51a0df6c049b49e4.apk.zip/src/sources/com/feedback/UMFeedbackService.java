package com.feedback;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.feedback.ui.FeedbackConversations;
import com.mobclick.android.UmengConstants;
import com.mobclick.android.m;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class UMFeedbackService {
    private static NotificationType a;
    private static Context b;
    private static boolean c = false;

    /* JADX INFO: Access modifiers changed from: private */
    public static void b(String str) {
        CharSequence charSequence;
        if (a != NotificationType.NotificationBar) {
            LinearLayout linearLayout = (LinearLayout) LayoutInflater.from(b).inflate(m.a(b, "layout", "umeng_analyse_new_reply_alert_dialog"), (ViewGroup) null);
            TextView textView = (TextView) linearLayout.findViewById(m.a(b, "id", "umeng_analyse_new_reply_alert_title"));
            TextView textView2 = (TextView) linearLayout.findViewById(m.a(b, "id", "umeng_analyse_new_dev_reply_box"));
            textView2.setText(str);
            AlertDialog create = new AlertDialog.Builder(b).create();
            create.show();
            create.setContentView(linearLayout);
            textView.setText(b.getString(m.a(b, "string", "UMNewReplyAlertTitle")));
            ((Button) linearLayout.findViewById(m.a(b, "id", "umeng_analyse_exitBtn"))).setOnClickListener(new a(create));
            Button button = (Button) linearLayout.findViewById(m.a(b, "id", "umeng_analyse_see_detail_btn"));
            b bVar = new b(create);
            button.setOnClickListener(bVar);
            textView2.setOnClickListener(bVar);
            return;
        }
        NotificationManager notificationManager = (NotificationManager) b.getSystemService("notification");
        Notification notification = new Notification(m.a(b, "drawable", "umeng_analyse_feedback_statusbar_icon"), b.getString(m.a(b, "string", "UMNewReplyFlick")), System.currentTimeMillis());
        Intent intent = new Intent(b, (Class<?>) FeedbackConversations.class);
        intent.setFlags(131072);
        PendingIntent activity = PendingIntent.getActivity(b, 0, intent, 0);
        PackageManager packageManager = b.getPackageManager();
        try {
            charSequence = packageManager.getApplicationLabel(packageManager.getApplicationInfo(b.getPackageName(), 128));
        } catch (PackageManager.NameNotFoundException e) {
            if (UmengConstants.testMode) {
                e.printStackTrace();
            }
            charSequence = null;
        }
        if (charSequence != null) {
            charSequence = String.valueOf(charSequence) + " : ";
        }
        notification.setLatestEventInfo(b, ((Object) charSequence) + b.getString(m.a(b, "string", "UMNewReplyTitle")), b.getString(m.a(b, "string", "UMNewReplyHint")), activity);
        notification.flags = 16;
        notificationManager.notify(0, notification);
    }

    public static void enableNewReplyNotification(Context context, NotificationType notificationType) {
        c cVar = new c();
        b = context;
        a = notificationType;
        new com.feedback.c.b(context, cVar).start();
        new com.feedback.c.a(context).start();
        c = true;
    }

    public static boolean getHasCheckedReply() {
        return c;
    }

    public static void openUmengFeedbackSDK(Context context) {
        com.feedback.b.a.a(context);
    }
}
