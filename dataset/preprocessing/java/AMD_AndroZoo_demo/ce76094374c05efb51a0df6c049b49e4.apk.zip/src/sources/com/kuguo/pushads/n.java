package com.kuguo.pushads;

import android.content.Context;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class n implements com.kuguo.a.c {
    final /* synthetic */ Context a;
    final /* synthetic */ j b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public n(Context context, j jVar) {
        this.a = context;
        this.b = jVar;
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, int i) {
        if (i == 4) {
            PushAdsActivity.b(this.a, dVar.b().getPath(), this.b);
        }
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, long j) {
    }
}
