package com.wooboo.adlib_android;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;
import java.io.Closeable;
import java.io.IOException;
import java.util.Timer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class WoobooAdView extends RelativeLayout {
    private static final int c = 700;
    private static int d;
    private static int j;
    private static double k;
    private static jb l;
    private static int p;
    private n a;
    private n b;
    private Timer e;
    private int f;
    private int g;
    private AdListener h;
    private boolean i;
    private kc m;
    private Context o;
    Handler q;
    private static final String[] z = {z(z("=}\u0010-^\u0005d\u0000-E\u0001fElR\u00172\u0013dS\u00132\fc@\ra\foZ\u0001<E-o\u000bgE`C\u0017fEnW\b~ElR\u00172\u0013dS\u0013<\u0016hB2{\u0016dT\r~\fyOLD\fhAJD,^\u007f&^ $\u0018")), z(z("'}\u0010aRD|\ny\u0016\u0007~\n~SDa\u0011\u007fS\u0005\u007f")), z(z("!j\u0006hF\u0010{\nc\u0016\u0003w\u0011y_\nuEd[\u0005u\u00007\u0016D")), z(z("\ff\u0011}\fK=\u0016n^\u0001\u007f\u0004~\u0018\u0005|\u0001\u007fY\rvKnY\t=\u0004}]K`\u0000~\u0019")), z(z("\u0010w\u001dyu\u000b~\n\u007f")), z(z("\u0005v1tF\u0001")), z(z("\u0016w\u0003\u007fS\u0017z,cB\u0001`\u0013lZ")), z(z("\u0006s\u0006fQ\u0016}\u0010cR'}\tbD")), z(z("\u0010w\u0016y_\nu")), z(z("\u001dk\u001ct\u001b)_HiR")), z(z("\u0005~\u0000\u007fB0{\bh")), z(z("\"`\u0000~^Ds\u0001~\u0016-|\u0011hD\u0012s\t%")), z(z("M2\u0016hU\u000b|\u0001~\u0016\tg\u0016y\u0016\u0006wE1\u000bD")), z(z("M2\u0016hU\u000b|\u0001~\u0016\tg\u0016y\u0016\u0006wE3\u000bD"))};
    public static boolean n = false;

    public WoobooAdView(Context context, int i, int i2, boolean z2, int i3, int[] iArr) {
        this(context, null, 0, jb.a, 0);
        a(context, sc.f(context), i, i2, z2, i3, iArr);
    }

    protected WoobooAdView(Context context, int i, int i2, boolean z2, int i3, int[] iArr, jb jbVar) {
        this(context, null, 0, jbVar, 0);
        a(context, sc.f(context), i, i2, z2, i3, iArr);
    }

    public WoobooAdView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 0);
    }

    public WoobooAdView(Context context, AttributeSet attributeSet, int i, int i2) {
        this(context, attributeSet, i, jb.a, 0);
        if (attributeSet != null) {
            String str = z[3] + context.getPackageName();
            boolean attributeBooleanValue = attributeSet.getAttributeBooleanValue(str, z[8], false);
            sc.a(attributeBooleanValue);
            a(context, sc.f(context), attributeSet.getAttributeUnsignedIntValue(str, z[7], 0), attributeSet.getAttributeUnsignedIntValue(str, z[4], -1), attributeBooleanValue, attributeSet.getAttributeIntValue(str, z[6], 10), kb.b(attributeSet.getAttributeValue(str, z[5])));
        }
    }

    protected WoobooAdView(Context context, AttributeSet attributeSet, int i, jb jbVar) {
        this(context, attributeSet, i, jbVar, 0);
        if (attributeSet != null) {
            String str = z[3] + context.getPackageName();
            boolean attributeBooleanValue = attributeSet.getAttributeBooleanValue(str, z[8], false);
            a(context, sc.f(context), attributeSet.getAttributeUnsignedIntValue(str, z[7], 0), attributeSet.getAttributeUnsignedIntValue(str, z[4], -1), attributeBooleanValue, attributeSet.getAttributeIntValue(str, z[6], 10), kb.b(attributeSet.getAttributeValue(str, z[5])));
        }
    }

    private WoobooAdView(Context context, AttributeSet attributeSet, int i, jb jbVar, int i2) {
        super(context, attributeSet, i);
        this.q = new g(this);
        this.o = context;
        this.i = true;
        setFocusable(true);
        setDescendantFocusability(262144);
        setClickable(true);
        a(getResources().getDisplayMetrics().density);
        setAdUnit(jbVar);
        sc.e(getAdUnit().c());
        c((int) (getAdUnit().b() * k));
        sc.g(context);
        sc.k(sc.k(context));
        sc.l(sc.l(context));
        sc.c(sc.o(context));
        sc.i(sc.i(context));
        sc.h(context.getPackageName());
        sc.g(qc.a(context).a(Build.MODEL));
        int e = sc.e(context);
        if (e < 200 || e > 300) {
            sc.n = true;
        } else {
            sc.n = false;
        }
        sc.f(e);
    }

    protected WoobooAdView(Context context, n nVar, Timer timer, int i, int i2, AdListener adListener, boolean z2, kc kcVar, Context context2, AttributeSet attributeSet, int i3, Handler handler) {
        super(context);
        this.q = new g(this);
        this.a = nVar;
        this.e = timer;
        this.f = i;
        this.g = i2;
        this.h = adListener;
        this.i = z2;
        this.m = kcVar;
        this.q = handler;
    }

    public WoobooAdView(Context context, String str, int i, int i2, boolean z2, int i3, int[] iArr) {
        this(context, null, 0, jb.a, 0);
        a(context, str, i, i2, z2, i3, iArr);
    }

    protected WoobooAdView(Context context, String str, int i, int i2, boolean z2, int i3, int[] iArr, jb jbVar) {
        this(context, null, 0, jbVar, 0);
        a(context, str, i, i2, z2, i3, iArr);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static n a(WoobooAdView woobooAdView) {
        return woobooAdView.a;
    }

    private void a() {
        if (sc.l() || (sc.a(this.o, false) != null && sc.d(this.o))) {
            a(p);
        }
    }

    protected static void a(double d2) {
        k = d2;
    }

    private void a(Context context, String str, int i, int i2, boolean z2, int i3, int[] iArr) {
        sc.a(z2);
        b((-16777216) | i2);
        setbgColor((-16777216) | i);
        sc.a(iArr);
        sc.g(context, str);
        p = i3;
        new Timer().schedule(new rd(this), 1000L);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(WoobooAdView woobooAdView, n nVar) {
        woobooAdView.a = nVar;
    }

    private void a(n nVar) {
        this.b = nVar;
        if (this.i) {
            AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
            alphaAnimation.setDuration(350L);
            alphaAnimation.startNow();
            alphaAnimation.setInterpolator(new AccelerateInterpolator());
            nVar.startAnimation(alphaAnimation);
        }
    }

    private static void a(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                mc.c(z[1]);
            }
        }
    }

    private void a(boolean z2) {
        synchronized (this) {
            if (z2) {
                if (d > 0) {
                    if (this.e == null) {
                        this.e = new Timer();
                        this.e.schedule(new sd(this), 0L, d);
                    }
                }
            }
            if ((!z2 || d == 0) && this.e != null) {
                this.e.cancel();
                this.e = null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static AdListener b(WoobooAdView woobooAdView) {
        return woobooAdView.h;
    }

    private void b() {
        try {
            if (this.m == null) {
                this.m = new kc(getContext());
            }
        } catch (Exception e) {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void b(WoobooAdView woobooAdView, n nVar) {
        woobooAdView.a(nVar);
    }

    private void b(n nVar) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.8f);
        alphaAnimation.setDuration(500L);
        TranslateAnimation translateAnimation = new TranslateAnimation(2, 0.0f, 2, 0.0f, 2, -1.0f, 2, 0.0f);
        translateAnimation.setDuration(700L);
        translateAnimation.setAnimationListener(new vc(this, alphaAnimation, nVar));
        nVar.startAnimation(translateAnimation);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static n c(WoobooAdView woobooAdView) {
        return woobooAdView.b;
    }

    protected static void c(int i) {
        j = i;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void c(WoobooAdView woobooAdView, n nVar) {
        woobooAdView.b(nVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Context d(WoobooAdView woobooAdView) {
        return woobooAdView.o;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void d(WoobooAdView woobooAdView, n nVar) {
        woobooAdView.b = nVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void e(WoobooAdView woobooAdView) {
        woobooAdView.a();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean f(WoobooAdView woobooAdView) {
        return woobooAdView.i;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static double g() {
        return k;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void g(WoobooAdView woobooAdView) {
        woobooAdView.i();
    }

    public static jb getAdUnit() {
        return l;
    }

    protected static int h() {
        return j;
    }

    private void i() {
        if (this.b != null) {
            this.b.setVisibility(8);
            this.b.h();
            removeView(this.b);
            this.b.e();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int j() {
        return j;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int k() {
        return d;
    }

    public static void setAdUnit(jb jbVar) {
        l = jbVar;
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c3 = cArr[i];
            switch (i % 5) {
                case 0:
                    c2 = 'd';
                    break;
                case 1:
                    c2 = 18;
                    break;
                case 2:
                    c2 = 'e';
                    break;
                case nb.p /* 3 */:
                    c2 = '\r';
                    break;
                default:
                    c2 = '6';
                    break;
            }
            cArr[i] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '6');
        }
        return charArray;
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x0069, code lost:
    
        if (r5 != false) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0035, code lost:
    
        if (r5 != false) goto L9;
     */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00a4  */
    /* JADX WARN: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:28:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void a(int r11) {
        /*
            r10 = this;
            r9 = 10
            r2 = 120(0x78, float:1.68E-43)
            r0 = 40
            r3 = 1
            r1 = 0
            boolean r5 = com.wooboo.adlib_android.sc.C
            if (r11 > 0) goto Lba
            if (r5 == 0) goto Lb8
            r4 = r1
        Lf:
            if (r4 >= r0) goto Lb6
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            java.lang.String[] r7 = com.wooboo.adlib_android.WoobooAdView.z
            r8 = 11
            r7 = r7[r8]
            r6.<init>(r7)
            java.lang.StringBuilder r4 = r6.append(r4)
            java.lang.String[] r6 = com.wooboo.adlib_android.WoobooAdView.z
            r7 = 13
            r6 = r6[r7]
            java.lang.StringBuilder r4 = r4.append(r6)
            java.lang.StringBuilder r4 = r4.append(r0)
            java.lang.String r4 = r4.toString()
            com.wooboo.adlib_android.mc.b(r4)
            if (r5 == 0) goto L5e
        L37:
            if (r0 <= r2) goto L5e
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String[] r6 = com.wooboo.adlib_android.WoobooAdView.z
            r7 = 11
            r6 = r6[r7]
            r4.<init>(r6)
            java.lang.StringBuilder r0 = r4.append(r0)
            java.lang.String[] r4 = com.wooboo.adlib_android.WoobooAdView.z
            r6 = 12
            r4 = r4[r6]
            java.lang.StringBuilder r0 = r0.append(r4)
            java.lang.StringBuilder r0 = r0.append(r2)
            java.lang.String r0 = r0.toString()
            com.wooboo.adlib_android.mc.b(r0)
            r0 = r2
        L5e:
            int r0 = r0 * 1000
            com.wooboo.adlib_android.WoobooAdView.d = r0
            int r0 = com.wooboo.adlib_android.WoobooAdView.d
            if (r0 != 0) goto L6b
            r10.a(r1)
            if (r5 == 0) goto L6e
        L6b:
            r10.a(r3)
        L6e:
            boolean r0 = com.wooboo.adlib_android.sc.l()
            if (r0 != 0) goto Lb3
            android.content.Context r0 = r10.o
            r2 = 0
            com.wooboo.adlib_android.pc r0 = com.wooboo.adlib_android.pc.a(r0, r2)
            java.lang.String[] r2 = com.wooboo.adlib_android.WoobooAdView.z
            r2 = r2[r9]
            java.lang.String r2 = r0.i(r2)
            java.util.Date r4 = new java.util.Date
            r4.<init>()
            java.text.SimpleDateFormat r6 = new java.text.SimpleDateFormat
            java.lang.String[] r7 = com.wooboo.adlib_android.WoobooAdView.z
            r8 = 9
            r7 = r7[r8]
            r6.<init>(r7)
            java.lang.String r4 = r6.format(r4)
            if (r2 == 0) goto La1
            boolean r2 = r4.equalsIgnoreCase(r2)
            if (r2 != 0) goto La2
            if (r5 == 0) goto Lb4
        La1:
            r1 = r3
        La2:
            if (r1 == 0) goto Lb3
            java.lang.String[] r1 = com.wooboo.adlib_android.WoobooAdView.z
            r1 = r1[r9]
            r0.d(r1, r4)
            com.wooboo.adlib_android.ld r0 = new com.wooboo.adlib_android.ld
            r0.<init>(r10)
            r0.start()
        Lb3:
            return
        Lb4:
            r1 = r3
            goto La2
        Lb6:
            r0 = r4
            goto L37
        Lb8:
            r0 = r1
            goto L5e
        Lba:
            r4 = r11
            goto Lf
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.WoobooAdView.a(int):void");
    }

    protected void b(int i) {
        this.g = (-16777216) | i;
        invalidate();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void c() {
        if (super.getVisibility() != 0) {
            mc.b(z[0]);
        } else {
            new kd(this).start();
        }
    }

    protected int d() {
        return d;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int e() {
        return this.g;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int f() {
        return this.f;
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:18)
        */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0041 A[Catch: IOException -> 0x005f, all -> 0x0092, TRY_LEAVE, TryCatch #9 {IOException -> 0x005f, all -> 0x0092, blocks: (B:14:0x0026, B:16:0x002d, B:21:0x0037, B:23:0x003b, B:25:0x0041, B:30:0x005e), top: B:13:0x0026 }] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x003f -> B:19:0x0036). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x004d -> B:22:0x003a). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public synchronized byte[] getImgData(android.content.Context r11, java.lang.String r12, boolean r13) {
        /*
            r10 = this;
            r2 = 0
            r3 = 0
            monitor-enter(r10)
            boolean r6 = com.wooboo.adlib_android.sc.C     // Catch: java.lang.Throwable -> L8c
            r0 = 0
            byte[] r0 = (byte[]) r0     // Catch: java.lang.Throwable -> L8c
            java.net.URL r1 = new java.net.URL     // Catch: java.net.MalformedURLException -> L5a java.lang.Throwable -> L8c
            r1.<init>(r12)     // Catch: java.net.MalformedURLException -> L5a java.lang.Throwable -> L8c
            java.net.URLConnection r1 = r1.openConnection()     // Catch: java.lang.Throwable -> L80 java.io.IOException -> L98
            java.net.HttpURLConnection r1 = (java.net.HttpURLConnection) r1     // Catch: java.lang.Throwable -> L80 java.io.IOException -> L98
            r4 = 0
            r1.setConnectTimeout(r4)     // Catch: java.lang.Throwable -> L8f java.io.IOException -> L9c
            r4 = 0
            r1.setReadTimeout(r4)     // Catch: java.lang.Throwable -> L8f java.io.IOException -> L9c
            r1.setUseCaches(r13)     // Catch: java.lang.Throwable -> L8f java.io.IOException -> L9c
            r4 = 1
            r1.setDoInput(r4)     // Catch: java.lang.Throwable -> L8f java.io.IOException -> L9c
            java.io.InputStream r4 = r1.getInputStream()     // Catch: java.lang.Throwable -> L8f java.io.IOException -> L9c
            int r5 = r1.getContentLength()     // Catch: java.io.IOException -> L5f java.lang.Throwable -> L92
            r7 = -1
            if (r5 == r7) goto L50
            byte[] r5 = new byte[r5]     // Catch: java.io.IOException -> L5f java.lang.Throwable -> L92
            r0 = 512(0x200, float:7.175E-43)
            byte[] r7 = new byte[r0]     // Catch: java.io.IOException -> L5f java.lang.Throwable -> L92
            if (r6 == 0) goto L9f
            r0 = r2
        L36:
            r8 = 0
            java.lang.System.arraycopy(r7, r8, r5, r0, r2)     // Catch: java.net.MalformedURLException -> L5d java.io.IOException -> L5f java.lang.Throwable -> L92
        L3a:
            int r0 = r0 + r2
        L3b:
            int r2 = r4.read(r7)     // Catch: java.io.IOException -> L5f java.lang.Throwable -> L92
            if (r2 > 0) goto L36
            android.content.Context r8 = r10.getContext()     // Catch: java.io.IOException -> L5f java.lang.Throwable -> L92
            r9 = 0
            com.wooboo.adlib_android.pc r8 = com.wooboo.adlib_android.pc.a(r8, r9)     // Catch: java.io.IOException -> L5f java.lang.Throwable -> L92
            r8.a(r12, r5)     // Catch: java.io.IOException -> L5f java.lang.Throwable -> L92
            if (r6 != 0) goto L3a
            r0 = r5
        L50:
            a(r4)     // Catch: java.lang.Throwable -> L8c
            if (r1 == 0) goto L58
            r1.disconnect()     // Catch: java.lang.Throwable -> L8c
        L58:
            monitor-exit(r10)
            return r0
        L5a:
            r0 = move-exception
            r0 = r3
            goto L58
        L5d:
            r0 = move-exception
            throw r0     // Catch: java.io.IOException -> L5f java.lang.Throwable -> L92
        L5f:
            r0 = move-exception
            r0 = r4
        L61:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L94
            java.lang.String[] r4 = com.wooboo.adlib_android.WoobooAdView.z     // Catch: java.lang.Throwable -> L94
            r5 = 2
            r4 = r4[r5]     // Catch: java.lang.Throwable -> L94
            r2.<init>(r4)     // Catch: java.lang.Throwable -> L94
            java.lang.StringBuilder r2 = r2.append(r12)     // Catch: java.lang.Throwable -> L94
            java.lang.String r2 = r2.toString()     // Catch: java.lang.Throwable -> L94
            com.wooboo.adlib_android.mc.a(r2)     // Catch: java.lang.Throwable -> L94
            a(r0)     // Catch: java.lang.Throwable -> L8c
            if (r1 == 0) goto L7e
            r1.disconnect()     // Catch: java.lang.Throwable -> L8c
        L7e:
            r0 = r3
            goto L58
        L80:
            r0 = move-exception
            r1 = r3
            r4 = r3
        L83:
            a(r4)     // Catch: java.lang.Throwable -> L8c
            if (r1 == 0) goto L8b
            r1.disconnect()     // Catch: java.lang.Throwable -> L8c
        L8b:
            throw r0     // Catch: java.lang.Throwable -> L8c
        L8c:
            r0 = move-exception
            monitor-exit(r10)
            throw r0
        L8f:
            r0 = move-exception
            r4 = r3
            goto L83
        L92:
            r0 = move-exception
            goto L83
        L94:
            r2 = move-exception
            r4 = r0
            r0 = r2
            goto L83
        L98:
            r0 = move-exception
            r1 = r3
            r0 = r3
            goto L61
        L9c:
            r0 = move-exception
            r0 = r3
            goto L61
        L9f:
            r0 = r2
            goto L3b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.WoobooAdView.getImgData(android.content.Context, java.lang.String, boolean):byte[]");
    }

    public boolean hasAd() {
        return this.a != null;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        this.i = true;
        super.onAttachedToWindow();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.i = false;
        a(false);
    }

    @Override // android.view.View
    public void onWindowFocusChanged(boolean z2) {
        this.i = z2;
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        if (i == 8) {
            this.i = false;
            return;
        }
        if (i == 0) {
            this.i = true;
            b();
        } else if (i == 4) {
            this.i = true;
        }
    }

    public void setAdListener(AdListener adListener) {
        synchronized (this) {
            this.h = adListener;
        }
    }

    public void setbgColor(int i) {
        this.f = i;
    }
}
