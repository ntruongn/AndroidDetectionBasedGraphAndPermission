package com.wooboo.adlib_android;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class c extends Handler {
    private static final String z = z(z("c#x\u0002"));
    final FullAdView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(FullAdView fullAdView) {
        this.a = fullAdView;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static FullAdView a(c cVar) {
        return cVar.a;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 7;
                    break;
                case 1:
                    c = 'B';
                    break;
                case 2:
                    c = '\f';
                    break;
                case nb.p /* 3 */:
                    c = 'c';
                    break;
                default:
                    c = '1';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '1');
        }
        return charArray;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        boolean z2 = sc.C;
        super.handleMessage(message);
        if (message.what == 2) {
            ((AlertDialog.Builder) message.obj).show();
            if (!z2) {
                return;
            }
        }
        try {
            hb hbVar = (hb) message.obj;
            try {
                if (hbVar != null) {
                    try {
                        if (!hbVar.equals("")) {
                            byte[] byteArray = message.getData().getByteArray(z);
                            FullAdView.a = null;
                            FullAdView.a = new n(hbVar, this.a.getContext(), false, FullAdView.i(), FullAdView.a(), sc.n, byteArray, 1, this.a);
                            FullAdView.a.setBackgroundColor(this.a.g());
                            FullAdView.a.a(this.a.f());
                            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, FullAdView.i());
                            layoutParams.addRule(14);
                            FullAdView.a.setLayoutParams(layoutParams);
                            FullAdView.a.a((ViewGroup) null);
                            if (FullAdView.a(this.a) != null) {
                                try {
                                    FullAdView.a(this.a).onReceiveAd(this.a);
                                } catch (Exception e) {
                                    mc.b(e.toString());
                                }
                            }
                            try {
                                if (hbVar.k() > 0) {
                                    new Handler().postDelayed(new ed(this), hbVar.k() * 1000);
                                }
                                if (FullAdView.a.getVisibility() == 0) {
                                    try {
                                        this.a.getContext().startActivity(new Intent(this.a.getContext(), (Class<?>) FullActivity.class));
                                        if (!z2) {
                                            return;
                                        }
                                    } catch (Exception e2) {
                                        throw e2;
                                    }
                                }
                                FullAdView.a.setVisibility(8);
                                if (!z2) {
                                    return;
                                }
                            } catch (Exception e3) {
                                throw e3;
                            }
                        }
                    } catch (Exception e4) {
                        throw e4;
                    }
                }
                if (FullAdView.a(this.a) != null) {
                    try {
                        FullAdView.a(this.a).onFailedToReceiveAd(this.a);
                    } catch (Exception e5) {
                        mc.b(e5.getMessage());
                    }
                }
            } catch (Exception e6) {
                throw e6;
            }
        } catch (Exception e7) {
            e7.printStackTrace();
        }
    }
}
