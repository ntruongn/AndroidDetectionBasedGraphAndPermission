package com.feedback.c;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.feedback.b.d;
import com.mobclick.android.UmengConstants;
import com.mobclick.android.m;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b extends Thread {
    static final String a = b.class.getSimpleName();
    Context b;
    String c;
    String d;
    String e;
    int f;
    Handler g;

    public b(Context context) {
        this.c = "http://feedback.whalecloud.com/feedback/reply";
        this.f = 0;
        this.b = context;
        this.d = m.b(context);
        this.e = m.c(context);
    }

    public b(Context context, Handler handler) {
        this(context);
        this.g = handler;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        String str;
        JSONArray jSONArray;
        String str2 = "";
        Iterator<String> it = this.b.getSharedPreferences(UmengConstants.FeedbackPreName, 0).getAll().keySet().iterator();
        while (true) {
            str = str2;
            if (!it.hasNext()) {
                break;
            }
            str2 = it.next();
            if (str.length() != 0) {
                str2 = String.valueOf(str) + "," + str2;
            }
        }
        String string = this.b.getSharedPreferences(UmengConstants.PreName_Trivial, 0).getString(UmengConstants.TrivialPreKey_MaxReplyID, "RP0");
        if (d.a(str)) {
            return;
        }
        this.c = String.valueOf(this.c) + "?appkey=" + this.d + "&feedback_id=" + str;
        if (!string.equals("RP0")) {
            this.c = String.valueOf(this.c) + "&startkey=" + string;
        }
        Log.d(a, this.c);
        String b = d.b(this.c);
        Intent intent = new Intent();
        intent.setAction(UmengConstants.RetrieveReplyBroadcastAction);
        if (b != null) {
            try {
                jSONArray = new JSONArray(b);
            } catch (JSONException e) {
                e.printStackTrace();
                jSONArray = null;
            }
            String a2 = com.feedback.b.c.a(this.b, jSONArray);
            Log.d(a, "newReplyIds :" + a2);
            if (a2.length() == 0 || a2.split(",").length == 0) {
                intent.putExtra(UmengConstants.RetrieveReplyBroadcastAction, 0);
            } else {
                intent.putExtra(UmengConstants.RetrieveReplyBroadcastAction, 1);
                if (this.g != null) {
                    com.feedback.a.a aVar = com.feedback.b.c.b(this.b, a2.split(",")[r0.length - 1]).e;
                    Message message = new Message();
                    Bundle bundle = new Bundle();
                    bundle.putString("newReplyContent", aVar.a());
                    message.setData(bundle);
                    this.g.sendMessage(message);
                }
            }
        } else {
            intent.putExtra(UmengConstants.RetrieveReplyBroadcastAction, -1);
        }
        this.b.sendBroadcast(intent);
    }
}
