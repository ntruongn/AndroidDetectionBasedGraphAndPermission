package com.mobclick.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.zip.Deflater;
import javax.microedition.khronos.opengles.GL10;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class m {
    static String a = "utf-8";
    public static int b;

    public static int a(Context context, String str, String str2) {
        try {
            Field field = Class.forName(String.valueOf(context.getPackageName()) + ".R$" + str).getField(str2);
            return Integer.parseInt(field.get(field.getName()).toString());
        } catch (Exception e) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "reflect resource error");
                e.printStackTrace();
            }
            return 0;
        }
    }

    public static int a(Date date, Date date2) {
        if (!date.after(date2)) {
            date2 = date;
            date = date2;
        }
        return (int) ((date.getTime() - date2.getTime()) / 1000);
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String a() {
        /*
            r1 = 0
            java.io.FileReader r0 = new java.io.FileReader     // Catch: java.io.FileNotFoundException -> L3b
            java.lang.String r2 = "/proc/cpuinfo"
            r0.<init>(r2)     // Catch: java.io.FileNotFoundException -> L3b
            java.io.BufferedReader r2 = new java.io.BufferedReader     // Catch: java.io.IOException -> L2d java.io.FileNotFoundException -> L3b
            r3 = 1024(0x400, float:1.435E-42)
            r2.<init>(r0, r3)     // Catch: java.io.IOException -> L2d java.io.FileNotFoundException -> L3b
            java.lang.String r1 = r2.readLine()     // Catch: java.io.IOException -> L2d java.io.FileNotFoundException -> L3b
            r2.close()     // Catch: java.io.IOException -> L2d java.io.FileNotFoundException -> L3b
            r0.close()     // Catch: java.io.IOException -> L2d java.io.FileNotFoundException -> L3b
            r0 = r1
        L1a:
            if (r0 == 0) goto L28
            r1 = 58
            int r1 = r0.indexOf(r1)
            int r1 = r1 + 1
            java.lang.String r0 = r0.substring(r1)
        L28:
            java.lang.String r0 = r0.trim()
            return r0
        L2d:
            r0 = move-exception
            boolean r2 = com.mobclick.android.UmengConstants.testMode     // Catch: java.io.FileNotFoundException -> L3b
            if (r2 == 0) goto L47
            java.lang.String r2 = "MobclickAgent"
            java.lang.String r3 = "Could not read from file /proc/cpuinfo"
            android.util.Log.e(r2, r3, r0)     // Catch: java.io.FileNotFoundException -> L3b
            r0 = r1
            goto L1a
        L3b:
            r0 = move-exception
            boolean r2 = com.mobclick.android.UmengConstants.testMode
            if (r2 == 0) goto L47
            java.lang.String r2 = "MobclickAgent"
            java.lang.String r3 = "Could not open file /proc/cpuinfo"
            android.util.Log.e(r2, r3, r0)
        L47:
            r0 = r1
            goto L1a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.mobclick.android.m.a():java.lang.String");
    }

    public static String a(String str) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(str.getBytes());
            byte[] digest = messageDigest.digest();
            StringBuffer stringBuffer = new StringBuffer();
            for (byte b2 : digest) {
                stringBuffer.append(Integer.toHexString(b2 & 255));
            }
            return stringBuffer.toString();
        } catch (NoSuchAlgorithmException e) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "getMD5 error");
                e.printStackTrace();
            }
            return "";
        }
    }

    public static String a(Date date) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
    }

    public static String a(JSONObject jSONObject) {
        try {
            if (jSONObject.has("channel")) {
                jSONObject.put("channel", URLEncoder.encode(jSONObject.getString("channel"), "UTF-8"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jSONObject.toString();
    }

    public static void a(Context context) {
        Toast.makeText(context, context.getString(a(context, "string", "UMToast_IsUpdating")), 0).show();
    }

    public static void a(Context context, Date date) {
        SharedPreferences.Editor edit = context.getSharedPreferences("exchange_last_request_time", 0).edit();
        edit.putString("last_request_time", a(date));
        edit.commit();
    }

    public static boolean a(Context context, String str) {
        return context.getPackageManager().checkPermission(str, context.getPackageName()) == 0;
    }

    public static String[] a(GL10 gl10) {
        try {
            return new String[]{gl10.glGetString(7936), gl10.glGetString(7937)};
        } catch (Exception e) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Could not read gpu infor:", e);
            }
            return new String[0];
        }
    }

    public static String b() {
        return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
    }

    public static String b(Context context) {
        String str;
        ApplicationInfo applicationInfo;
        try {
            applicationInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
        } catch (Exception e) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Could not read UMENG_APPKEY meta-data from AndroidManifest.xml.");
                e.printStackTrace();
            }
        }
        if (applicationInfo != null) {
            str = applicationInfo.metaData.getString("UMENG_APPKEY");
            if (str == null) {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "Could not read UMENG_APPKEY meta-data from AndroidManifest.xml.");
                    str = null;
                }
            }
            return str.trim();
        }
        str = null;
        return str.trim();
    }

    public static String b(String str) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(str.getBytes());
            byte[] digest = messageDigest.digest();
            StringBuffer stringBuffer = new StringBuffer();
            for (byte b2 : digest) {
                int i = b2 & 255;
                if (i < 16) {
                    stringBuffer.append("0");
                }
                stringBuffer.append(Integer.toHexString(i));
            }
            return stringBuffer.toString();
        } catch (NoSuchAlgorithmException e) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "getMD5 error");
                e.printStackTrace();
            }
            return "";
        }
    }

    public static String b(JSONObject jSONObject) {
        try {
            JSONObject optJSONObject = jSONObject.optJSONObject("header");
            if (optJSONObject != null) {
                if (optJSONObject.has("access_subtype")) {
                    optJSONObject.put("access_subtype", URLEncoder.encode(optJSONObject.getString("access_subtype"), "UTF-8"));
                }
                if (optJSONObject.has("cpu")) {
                    optJSONObject.put("cpu", URLEncoder.encode(optJSONObject.getString("cpu"), "UTF-8"));
                }
                if (optJSONObject.has(UmengConstants.AtomKey_AppVersion)) {
                    optJSONObject.put(UmengConstants.AtomKey_AppVersion, URLEncoder.encode(optJSONObject.getString(UmengConstants.AtomKey_AppVersion), "UTF-8"));
                }
                if (optJSONObject.has("country")) {
                    optJSONObject.put("country", URLEncoder.encode(optJSONObject.getString("country"), "UTF-8"));
                }
                if (optJSONObject.has(UmengConstants.AtomKey_DeviceModel)) {
                    optJSONObject.put(UmengConstants.AtomKey_DeviceModel, URLEncoder.encode(optJSONObject.getString(UmengConstants.AtomKey_DeviceModel), "UTF-8"));
                }
                if (optJSONObject.has("carrier")) {
                    optJSONObject.put("carrier", URLEncoder.encode(optJSONObject.getString("carrier"), "UTF-8"));
                }
                if (optJSONObject.has("language")) {
                    optJSONObject.put("language", URLEncoder.encode(optJSONObject.getString("language"), "UTF-8"));
                }
                if (optJSONObject.has("channel")) {
                    optJSONObject.put("channel", URLEncoder.encode(optJSONObject.getString("channel"), "UTF-8"));
                }
            }
            JSONObject optJSONObject2 = jSONObject.optJSONObject("body");
            JSONArray optJSONArray = optJSONObject2.optJSONArray("event");
            if (optJSONArray != null) {
                for (int i = 0; i < optJSONArray.length(); i++) {
                    JSONObject optJSONObject3 = optJSONArray.optJSONObject(i);
                    if (optJSONObject3 != null) {
                        if (optJSONObject3.has("label")) {
                            optJSONObject3.put("label", URLEncoder.encode(optJSONObject3.getString("label")));
                        }
                        if (optJSONObject3.has("tag")) {
                            optJSONObject3.put("tag", URLEncoder.encode(optJSONObject3.getString("tag")));
                        }
                    }
                }
            }
            JSONArray optJSONArray2 = optJSONObject2.optJSONArray(UmengConstants.Atom_State_Error);
            if (optJSONArray2 != null) {
                for (int i2 = 0; i2 < optJSONArray2.length(); i2++) {
                    JSONObject optJSONObject4 = optJSONArray2.optJSONObject(i2);
                    if (optJSONObject4 != null && optJSONObject4.has("context")) {
                        optJSONObject4.put("context", URLEncoder.encode(optJSONObject4.getString("context")));
                    }
                }
            }
            return jSONObject.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return jSONObject.toString();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0029  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String c(android.content.Context r4) {
        /*
            java.lang.String r0 = "phone"
            java.lang.Object r0 = r4.getSystemService(r0)
            android.telephony.TelephonyManager r0 = (android.telephony.TelephonyManager) r0
            if (r0 != 0) goto L15
            boolean r1 = com.mobclick.android.UmengConstants.testMode
            if (r1 == 0) goto L15
            java.lang.String r1 = "MobclickAgent"
            java.lang.String r2 = "No IMEI."
            android.util.Log.w(r1, r2)
        L15:
            java.lang.String r1 = ""
            java.lang.String r2 = "android.permission.READ_PHONE_STATE"
            boolean r2 = a(r4, r2)     // Catch: java.lang.Exception -> L47
            if (r2 == 0) goto L56
            java.lang.String r0 = r0.getDeviceId()     // Catch: java.lang.Exception -> L47
        L23:
            boolean r1 = android.text.TextUtils.isEmpty(r0)
            if (r1 == 0) goto L58
            boolean r0 = com.mobclick.android.UmengConstants.testMode
            if (r0 == 0) goto L34
            java.lang.String r0 = "MobclickAgent"
            java.lang.String r1 = "No IMEI."
            android.util.Log.w(r0, r1)
        L34:
            java.lang.String r0 = i(r4)
            if (r0 != 0) goto L58
            boolean r0 = com.mobclick.android.UmengConstants.testMode
            if (r0 == 0) goto L45
            java.lang.String r0 = "MobclickAgent"
            java.lang.String r1 = "Failed to take mac as IMEI."
            android.util.Log.w(r0, r1)
        L45:
            r0 = 0
        L46:
            return r0
        L47:
            r0 = move-exception
            boolean r2 = com.mobclick.android.UmengConstants.testMode
            if (r2 == 0) goto L56
            java.lang.String r2 = "MobclickAgent"
            java.lang.String r3 = "No IMEI."
            android.util.Log.w(r2, r3)
            r0.printStackTrace()
        L56:
            r0 = r1
            goto L23
        L58:
            java.lang.String r0 = a(r0)
            goto L46
        */
        throw new UnsupportedOperationException("Method not decompiled: com.mobclick.android.m.c(android.content.Context):java.lang.String");
    }

    public static byte[] c(String str) {
        b = 0;
        Deflater deflater = new Deflater();
        deflater.setInput(str.getBytes(a));
        deflater.finish();
        byte[] bArr = new byte[8192];
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        while (!deflater.finished()) {
            int deflate = deflater.deflate(bArr);
            b += deflate;
            byteArrayOutputStream.write(bArr, 0, deflate);
        }
        deflater.end();
        return byteArrayOutputStream.toByteArray();
    }

    public static Date d(Context context) {
        return d(context.getSharedPreferences("exchange_last_request_time", 0).getString("last_request_time", "1900-01-01 00:00:00"));
    }

    public static Date d(String str) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(str);
        } catch (Exception e) {
            return null;
        }
    }

    public static JSONObject e(Context context) {
        JSONObject k;
        JSONObject jSONObject = new JSONObject();
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            String c = c(context);
            if (c == null || c.equals("")) {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "No device id");
                }
                return null;
            }
            jSONObject.put("idmd5", c);
            jSONObject.put(UmengConstants.AtomKey_DeviceModel, Build.MODEL);
            String b2 = b(context);
            if (b2 == null) {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "No appkey");
                }
                return null;
            }
            jSONObject.put(UmengConstants.AtomKey_AppKey, b2);
            jSONObject.put("channel", UmengConstants.channel != null ? UmengConstants.channel : g(context));
            try {
                PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                String str = packageInfo.versionName;
                int i = packageInfo.versionCode;
                jSONObject.put(UmengConstants.AtomKey_AppVersion, str);
                jSONObject.put("version_code", i);
            } catch (PackageManager.NameNotFoundException e) {
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "read version fail");
                    e.printStackTrace();
                }
                jSONObject.put(UmengConstants.AtomKey_AppVersion, "unknown");
                jSONObject.put("version_code", "unknown");
            }
            jSONObject.put("sdk_type", "Android");
            jSONObject.put(UmengConstants.AtomKey_SDK_Version, UmengConstants.SDK_VERSION);
            jSONObject.put("os", "Android");
            jSONObject.put(UmengConstants.AtomKey_OSVersion, Build.VERSION.RELEASE);
            Configuration configuration = new Configuration();
            Settings.System.getConfiguration(context.getContentResolver(), configuration);
            if (configuration == null || configuration.locale == null) {
                Locale locale = Locale.getDefault();
                if (!UmengConstants.canUseLCT || locale == null) {
                    jSONObject.put("country", "Unknown");
                    jSONObject.put("language", "Unknown");
                    jSONObject.put("timezone", 8);
                } else {
                    String country = locale.getCountry();
                    if (TextUtils.isEmpty(country)) {
                        jSONObject.put("country", "Unknown");
                    } else {
                        jSONObject.put("country", country);
                    }
                    String language = locale.getLanguage();
                    if (TextUtils.isEmpty(language)) {
                        jSONObject.put("language", "Unknown");
                    } else {
                        jSONObject.put("language", language);
                    }
                    Calendar calendar = Calendar.getInstance(locale);
                    if (calendar != null) {
                        TimeZone timeZone = calendar.getTimeZone();
                        if (timeZone != null) {
                            jSONObject.put("timezone", timeZone.getRawOffset() / 3600000);
                        } else {
                            jSONObject.put("timezone", 8);
                        }
                    } else {
                        jSONObject.put("timezone", 8);
                    }
                }
            } else {
                jSONObject.put("country", configuration.locale.getCountry());
                jSONObject.put("language", configuration.locale.toString());
                Calendar calendar2 = Calendar.getInstance(configuration.locale);
                if (calendar2 != null) {
                    TimeZone timeZone2 = calendar2.getTimeZone();
                    if (timeZone2 != null) {
                        jSONObject.put("timezone", timeZone2.getRawOffset() / 3600000);
                    } else {
                        jSONObject.put("timezone", 8);
                    }
                } else {
                    jSONObject.put("timezone", 8);
                }
            }
            try {
                DisplayMetrics displayMetrics = new DisplayMetrics();
                ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
                jSONObject.put("resolution", String.valueOf(String.valueOf(displayMetrics.heightPixels)) + "*" + String.valueOf(displayMetrics.widthPixels));
            } catch (Exception e2) {
                if (UmengConstants.testMode) {
                    Log.e(UmengConstants.LOG_TAG, "read resolution fail");
                    e2.printStackTrace();
                }
                jSONObject.put("resolution", "Unknown");
            }
            try {
                String[] f = f(context);
                jSONObject.put("access", f[0]);
                if (f[0].equals("2G/3G")) {
                    jSONObject.put("access_subtype", f[1]);
                }
            } catch (Exception e3) {
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "read access fail");
                    e3.printStackTrace();
                }
                jSONObject.put("access", "Unknown");
            }
            try {
                jSONObject.put("carrier", telephonyManager.getNetworkOperatorName());
            } catch (Exception e4) {
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "read carrier fail");
                    e4.printStackTrace();
                }
                jSONObject.put("carrier", "Unknown");
            }
            if (UmengConstants.LOCATION_OPEN) {
                Location j = j(context);
                if (j != null) {
                    jSONObject.put(UmengConstants.AtomKey_Lat, String.valueOf(j.getLatitude()));
                    jSONObject.put(UmengConstants.AtomKey_Lng, String.valueOf(j.getLongitude()));
                } else {
                    jSONObject.put(UmengConstants.AtomKey_Lat, 0.0d);
                    jSONObject.put(UmengConstants.AtomKey_Lng, 0.0d);
                }
            }
            jSONObject.put("cpu", a());
            if (!MobclickAgent.GPU_VENDER.equals("")) {
                jSONObject.put("gpu_vender", MobclickAgent.GPU_VENDER);
            }
            if (!MobclickAgent.GPU_RENDERER.equals("")) {
                jSONObject.put("gpu_renderer", MobclickAgent.GPU_RENDERER);
            }
            if (UmengConstants.canCollectionUserInfo && (k = k(context)) != null) {
                jSONObject.put("uinfo", k);
            }
            return jSONObject;
        } catch (Exception e5) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "getMessageHeader error");
                e5.printStackTrace();
            }
            return null;
        }
    }

    public static String[] f(Context context) {
        String[] strArr = {"Unknown", "Unknown"};
        if (context.getPackageManager().checkPermission("android.permission.ACCESS_NETWORK_STATE", context.getPackageName()) != 0) {
            strArr[0] = "Unknown";
            return strArr;
        }
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivityManager == null) {
            strArr[0] = "Unknown";
            return strArr;
        }
        if (connectivityManager.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTED) {
            strArr[0] = "Wi-Fi";
            return strArr;
        }
        NetworkInfo networkInfo = connectivityManager.getNetworkInfo(0);
        if (networkInfo.getState() != NetworkInfo.State.CONNECTED) {
            return strArr;
        }
        strArr[0] = "2G/3G";
        strArr[1] = networkInfo.getSubtypeName();
        return strArr;
    }

    public static String g(Context context) {
        String str;
        ApplicationInfo applicationInfo;
        Object obj;
        if (UmengConstants.channel != null) {
            return UmengConstants.channel;
        }
        try {
            applicationInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
        } catch (Exception e) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "Could not read UMENG_CHANNEL meta-data from AndroidManifest.xml.");
                e.printStackTrace();
            }
        }
        if (applicationInfo != null && applicationInfo.metaData != null && (obj = applicationInfo.metaData.get("UMENG_CHANNEL")) != null) {
            str = obj.toString();
            if (str == null) {
                if (UmengConstants.testMode) {
                    Log.i(UmengConstants.LOG_TAG, "Could not read UMENG_CHANNEL meta-data from AndroidManifest.xml.");
                    str = "Unknown";
                }
            }
            UmengConstants.channel = str;
            return str;
        }
        str = "Unknown";
        UmengConstants.channel = str;
        return str;
    }

    public static boolean h(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivityManager == null) {
            return false;
        }
        if (connectivityManager.getNetworkInfo(0).getState() != NetworkInfo.State.CONNECTED && connectivityManager.getNetworkInfo(1).getState() != NetworkInfo.State.CONNECTED) {
            return false;
        }
        return true;
    }

    private static String i(Context context) {
        try {
            return ((WifiManager) context.getSystemService("wifi")).getConnectionInfo().getMacAddress();
        } catch (Exception e) {
            if (UmengConstants.testMode) {
                Log.i(UmengConstants.LOG_TAG, "Could not read MAC, forget to include ACCESS_WIFI_STATE permission?", e);
            }
            return null;
        }
    }

    private static Location j(Context context) {
        if (MobclickAgent.mUseLocationService) {
            return new e(context).a();
        }
        return null;
    }

    private static JSONObject k(Context context) {
        JSONObject jSONObject = new JSONObject();
        SharedPreferences a2 = MobclickAgent.a(context);
        try {
            if (a2.getInt(UmengConstants.AtomKey_Sex, -1) != -1) {
                jSONObject.put(UmengConstants.TrivialPreKey_Sex, a2.getInt(UmengConstants.AtomKey_Sex, -1));
            }
            if (a2.getInt("age", -1) != -1) {
                jSONObject.put("age", a2.getInt("age", -1));
            }
            if (!"".equals(a2.getString(UmengConstants.AtomKey_User_ID, ""))) {
                jSONObject.put("id", a2.getString(UmengConstants.AtomKey_User_ID, ""));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (jSONObject.length() > 0) {
            return jSONObject;
        }
        return null;
    }
}
