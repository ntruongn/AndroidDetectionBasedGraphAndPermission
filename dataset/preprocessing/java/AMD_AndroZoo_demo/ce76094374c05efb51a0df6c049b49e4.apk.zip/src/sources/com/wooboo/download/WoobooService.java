package com.wooboo.download;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;
import com.wooboo.adlib_android.AdActivity;
import com.wooboo.adlib_android.mc;
import com.wooboo.adlib_android.nb;
import com.wooboo.adlib_android.pc;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Timer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class WoobooService extends Service implements g {
    private static final String[] z = {z(z("d\u001a~!'T\u001a,3!@\u0011`8/S_J6'[\u001ah")), z(z("丼輂卿屑彎姼")), z(z("歔块万輪")), z(z("罦纣犺凢乃佄ｳ读穚偗釺讪－")), z(z("D\u000bm%:s\u0010{9\"X\u001eh2<")), z(z("丼輂両徔掞礍")), z(z("丼輂両徔掞礍惗")), z(z("^\f[8!U\u0010c")), z(z("悟杶")), z(z("欉輐仺厸享宾袺\uff00烮况柒睴")), z(z("~1_\u0003\u000f{3S\u001a\u000fy>K\u0012\u001c")), z(z("d;S\u0013\f")), z(z("`\u0010c5!X,i%8^\u001ciw!Y,x6<C")), z(z("Y\u0010x>(^\u001cm#'X\u0011")), z(z("巅乴轱w")), z(z("強妴万輪"))};
    NotificationManager b;
    Notification d;
    c l;
    public String a = "";
    private HashMap c = new HashMap();
    private ArrayList e = new ArrayList();
    private Context f = null;
    private PendingIntent g = null;
    private final int h = 10000;
    private final int i = 11000;
    private pc j = null;
    private int k = 1;
    f m = null;
    private Handler n = new b(this);

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(WoobooService woobooService) {
        woobooService.b();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(WoobooService woobooService, String str) {
        woobooService.a(str);
    }

    private void a(String str) {
        Toast.makeText(this.f, z[3], 1).show();
        this.m.e(str);
        if (this.c.containsKey(str)) {
            this.b.cancel(((Integer) this.c.get(str)).intValue());
        }
    }

    private void b() {
        Message message = new Message();
        message.what = 110;
        this.n.sendMessage(message);
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '7';
                    break;
                case 1:
                    c = 127;
                    break;
                case 2:
                    c = '\f';
                    break;
                case nb.p /* 3 */:
                    c = 'W';
                    break;
                default:
                    c = 'N';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'N');
        }
        return charArray;
    }

    @Override // com.wooboo.download.g
    public void a() {
        this.a = h.b(this.f);
    }

    @Override // com.wooboo.download.g
    public void a(int i) {
        boolean z2 = h.e;
        Iterator it = this.e.iterator();
        if (z2) {
            this.b.cancel(((Integer) it.next()).intValue());
        }
        while (it.hasNext()) {
            this.b.cancel(((Integer) it.next()).intValue());
        }
        if (i == 0) {
            this.b.cancel(10000);
            if (!z2) {
                return;
            }
        }
        Intent intent = new Intent(this.f, (Class<?>) AdActivity.class);
        intent.putExtra(z[10], true);
        intent.putExtra(z[7], true);
        intent.putExtra(z[11], true);
        this.g = PendingIntent.getActivity(this.f, 0, intent, 134217728);
        this.d = new Notification(17301633, z[6], System.currentTimeMillis());
        this.d.setLatestEventInfo(this.f, z[5], z[8] + Integer.valueOf(i) + z[9], this.g);
        this.b.notify(10000, this.d);
    }

    @Override // com.wooboo.download.g
    public void a(d dVar) {
        if (this.a == "") {
            return;
        }
        this.j.d(dVar.k);
        dVar.g = this.a;
        this.l = new c(this.f, dVar, this.n, this.j);
        this.k++;
        mc.c(z[4] + dVar.k);
        this.c.put(dVar.k, Integer.valueOf(this.k));
        b(dVar.k, 0);
        this.m.a(dVar.k, this.l);
        this.l.d();
        dVar.f = this.l.a();
    }

    public void a(String str, int i) {
        b(str, i);
    }

    @Override // com.wooboo.download.g
    public void a(boolean z2) {
        boolean z3 = h.e;
        Intent intent = new Intent();
        intent.setFlags(335544320);
        this.g = PendingIntent.getActivity(this.f, 0, intent, 134217728);
        this.d = new Notification(17301633, z[1], System.currentTimeMillis());
        this.d.setLatestEventInfo(this.f, z[2], z[1], this.g);
        if (z2) {
            this.b.notify(11000, this.d);
            if (!z3) {
                return;
            } else {
                mc.a++;
            }
        }
        this.b.cancel(11000);
    }

    public void b(String str) {
        this.j.c(str);
        this.e.add(Integer.valueOf(((Integer) this.c.get(str)).intValue()));
        this.m.c();
        this.m.d(str);
    }

    public void b(String str, int i) {
        int intValue = ((Integer) this.c.get(str)).intValue();
        d h = this.j.h(str);
        if (h == null) {
            this.b.cancel(intValue);
            return;
        }
        Intent intent = new Intent();
        intent.setFlags(335544320);
        this.g = PendingIntent.getActivity(this.f, 0, intent, 134217728);
        this.d = new Notification(17301633, String.valueOf(h.i) + z[15], System.currentTimeMillis());
        this.d.setLatestEventInfo(this.f, z[2], String.valueOf(h.i) + z[14] + Integer.valueOf(i) + "%", this.g);
        this.b.notify(intValue, this.d);
    }

    public void c(String str) {
        this.j.e(str);
        mc.c(z[0]);
        this.m.a(str, (c) null);
        this.b.cancel(((Integer) this.c.get(str)).intValue());
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        try {
            if (h.a()) {
                super.onCreate();
                try {
                    this.f = getApplicationContext();
                    this.j = pc.a(this.f, h.b());
                    this.m = f.a(getApplicationContext(), this, this.j, this.a);
                    this.b = (NotificationManager) this.f.getSystemService(z[13]);
                    new Timer().schedule(new n(this), 1000L, 20000L);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e2) {
            throw e2;
        }
    }

    @Override // android.app.Service
    public void onStart(Intent intent, int i) {
        if (h.a()) {
            if (this.a == "") {
                this.a = h.b(this.f);
                if (this.m == null) {
                    this.m = f.a(getApplicationContext(), this, this.j, this.a);
                }
                if (this.a != "") {
                    this.m.a(true, this.a);
                }
            }
            mc.c(z[12]);
            a(this.j.e() ? false : true);
            b();
        }
    }
}
