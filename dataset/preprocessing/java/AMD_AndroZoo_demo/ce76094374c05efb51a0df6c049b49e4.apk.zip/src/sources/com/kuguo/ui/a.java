package com.kuguo.ui;

import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.kuguo.d.e;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a extends BaseAdapter {
    List a = new ArrayList();
    final /* synthetic */ ImageGallery b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(ImageGallery imageGallery) {
        this.b = imageGallery;
    }

    public List a() {
        return this.a;
    }

    public void a(List list) {
        this.a = list;
        notifyDataSetChanged();
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.a.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return this.a.get(i);
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        View imageView = view == null ? new ImageView(this.b.getContext()) : view;
        ((ImageView) imageView).setImageDrawable(e.a(this.b.getContext(), (Bitmap) this.a.get(i)));
        return imageView;
    }
}
