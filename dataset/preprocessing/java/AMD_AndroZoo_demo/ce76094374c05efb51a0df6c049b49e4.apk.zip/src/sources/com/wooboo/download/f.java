package com.wooboo.download;

import android.content.Context;
import com.wooboo.adlib_android.fc;
import com.wooboo.adlib_android.mc;
import com.wooboo.adlib_android.nb;
import com.wooboo.adlib_android.pc;
import com.wooboo.adlib_android.sc;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class f implements i {
    private pc b;
    private String e;
    private g f;
    private Context q;
    private static final String[] z = {z(z("B \u001f&+_\"")), z(z("U*\u0006,.P*\u0015'0")), z(z("B&\u0010,")), z(z("\\6\u0016")), z(z("D7\u001d")), z(z("B1\u001067B")), z(z("B \u0012")), z(z("X+\u0017-")), z(z("A.\u0016")), z(z("B \u001f&b\\6\u0016b$X)\u0014&x")), z(z("B1\u001006b&\u0010,")), z(z("U*\u0006,.^$\u0015\u0001#_+\u001e6\u0012C*\u0012''U")), z(z("P!\u0015b\fT2Q\u0011!P+K")), z(z("A$\u001c")), z(z("C1")), z(z("R-\u0014!)u*\u0006,.^$\u0015\u0006-_ ")), z(z("X+\u0017-lR$Q\u007f\u007f\u0011+\u0004..\u0011")), z(z("u*\u0006,.^$\u0015b-G \u0003x,D)\u001db")), z(z("X+\u0017-lB \u0012b\u007f\fe\u001f7.]e")), z(z("U \u001d'6T\b\u001411P\"\u0014x")), z(z("P!\u0015\f'F\u0001\u001e5,}*\u0010&'Ce\u0012*'R.\"'0G,\u0012'j\u0018")), z(z("P!\u0015\f'F\u0001\u001e5,}*\u0010&'C\u007f")), z(z("\u0011!\u001e5,]*\u0010&'CeP\u007fb_0\u001d."))};
    private static f a = null;
    private HashMap c = new HashMap();
    private boolean d = true;
    private boolean g = true;
    private HashMap h = new HashMap();
    private final String i = z[7];
    private final String j = z[1];
    private HashMap k = new HashMap();
    private final String l = z[0];
    private final String m = z[3];
    private final String n = z[4];
    private final String o = z[6];
    private final int p = 300000;

    private f(Context context, g gVar, pc pcVar, String str) {
        this.b = null;
        this.e = "";
        this.f = null;
        this.q = null;
        this.q = context;
        this.f = gVar;
        this.b = pcVar;
        this.e = str;
    }

    public static synchronized f a(Context context, g gVar, pc pcVar, String str) {
        f fVar;
        synchronized (f.class) {
            if (a == null) {
                a = new f(context, gVar, pcVar, str);
            }
            fVar = a;
        }
        return fVar;
    }

    private String a(String str, Long l) {
        boolean b = h.b(this.q, str);
        String l2 = Long.valueOf(l.longValue()).toString();
        return b ? String.valueOf(l2) + "1" : String.valueOf(l2) + "0";
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x006b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void a(java.lang.String r9, java.lang.String r10) {
        /*
            r8 = this;
            r7 = 2
            r6 = 1
            java.util.HashMap r0 = r8.c
            java.lang.Object r0 = r0.get(r9)
            java.util.HashMap r0 = (java.util.HashMap) r0
            java.util.HashMap r3 = new java.util.HashMap
            r3.<init>()
            java.lang.String[] r1 = com.wooboo.download.f.z
            r2 = 14
            r1 = r1[r2]
            r3.put(r1, r10)
            java.lang.String[] r1 = com.wooboo.download.f.z
            r2 = 13
            r1 = r1[r2]
            java.lang.Object r1 = r0.get(r1)
            java.lang.String r1 = (java.lang.String) r1
            java.lang.String r2 = com.wooboo.adlib_android.sc.e(r1)
            java.lang.String[] r1 = com.wooboo.download.f.z
            r4 = 6
            r1 = r1[r4]
            java.lang.Object r1 = r0.get(r1)
            java.lang.String r1 = (java.lang.String) r1
            com.wooboo.adlib_android.fc r4 = new com.wooboo.adlib_android.fc
            r4.<init>(r0)
            if (r2 == 0) goto La2
            java.lang.String r4 = r2.trim()     // Catch: com.wooboo.adlib_android.o -> L9c
            int r4 = r4.length()     // Catch: com.wooboo.adlib_android.o -> L9c
            if (r4 <= 0) goto La2
            com.wooboo.adlib_android.fc r4 = new com.wooboo.adlib_android.fc     // Catch: com.wooboo.adlib_android.o -> L9e
            r4.<init>(r2)     // Catch: com.wooboo.adlib_android.o -> L9e
            java.util.HashMap r2 = com.wooboo.adlib_android.sc.a(r3, r4)     // Catch: com.wooboo.adlib_android.o -> L9e
        L4d:
            com.wooboo.adlib_android.pc r3 = r8.b     // Catch: com.wooboo.adlib_android.o -> La4
            java.lang.String[] r4 = com.wooboo.download.f.z     // Catch: com.wooboo.adlib_android.o -> La4
            r5 = 2
            r4 = r4[r5]     // Catch: com.wooboo.adlib_android.o -> La4
            java.lang.Object r0 = r0.get(r4)     // Catch: com.wooboo.adlib_android.o -> La4
            java.lang.String r0 = (java.lang.String) r0     // Catch: com.wooboo.adlib_android.o -> La4
            java.lang.Long r0 = java.lang.Long.valueOf(r0)     // Catch: com.wooboo.adlib_android.o -> La4
            long r4 = r0.longValue()     // Catch: com.wooboo.adlib_android.o -> La4
            r3.a(r4)     // Catch: com.wooboo.adlib_android.o -> La4
            int r0 = r10.length()     // Catch: com.wooboo.adlib_android.o -> La4
            if (r0 != r7) goto L86
            r0 = 1
            java.lang.String r0 = r10.substring(r0)     // Catch: com.wooboo.adlib_android.o -> La6
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)     // Catch: com.wooboo.adlib_android.o -> La6
            int r0 = r0.intValue()     // Catch: com.wooboo.adlib_android.o -> La6
            if (r0 != r6) goto La8
            java.lang.String[] r0 = com.wooboo.download.f.z     // Catch: com.wooboo.adlib_android.o -> La6
            r3 = 15
            r0 = r0[r3]     // Catch: com.wooboo.adlib_android.o -> La6
            com.wooboo.adlib_android.mc.c(r0)     // Catch: com.wooboo.adlib_android.o -> La6
            r8.f(r9)     // Catch: com.wooboo.adlib_android.o -> La6
        L86:
            com.wooboo.adlib_android.fc r0 = new com.wooboo.adlib_android.fc
            r0.<init>(r2)
            java.lang.String r0 = r0.toString()
            java.lang.String r0 = com.wooboo.adlib_android.sc.d(r0)
            r2 = 3
            java.lang.String r2 = com.wooboo.adlib_android.sc.b(r2)
            r8.b(r9, r2, r0, r1)
            return
        L9c:
            r0 = move-exception
            throw r0
        L9e:
            r2 = move-exception
            r2.printStackTrace()
        La2:
            r2 = r3
            goto L4d
        La4:
            r0 = move-exception
            throw r0     // Catch: com.wooboo.adlib_android.o -> La6
        La6:
            r0 = move-exception
            throw r0
        La8:
            r8.c()
            goto L86
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.download.f.a(java.lang.String, java.lang.String):void");
    }

    private void a(String str, String str2, String str3, String str4, boolean z2) {
        HashMap hashMap = new HashMap();
        hashMap.put(z[0], "0");
        hashMap.put(z[3], sc.e(str3));
        hashMap.put(z[4], str2);
        hashMap.put(z[6], sc.e(str4));
        Long valueOf = Long.valueOf(System.currentTimeMillis());
        this.b.a(valueOf, hashMap);
        this.k.put(valueOf, hashMap);
        if (z2) {
            b();
        }
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:18)
        */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0047 A[Catch: all -> 0x018c, TRY_LEAVE, TryCatch #4 {, blocks: (B:18:0x0024, B:20:0x0030, B:22:0x0047, B:27:0x004d, B:30:0x0183, B:33:0x005d, B:35:0x0063), top: B:17:0x0024, inners: #5 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x005d A[EDGE_INSN: B:32:0x005d->B:33:0x005d BREAK  A[LOOP:0: B:21:0x0045->B:31:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0063 A[Catch: all -> 0x018c, DONT_GENERATE, TRY_LEAVE, TryCatch #4 {, blocks: (B:18:0x0024, B:20:0x0030, B:22:0x0047, B:27:0x004d, B:30:0x0183, B:33:0x005d, B:35:0x0063), top: B:17:0x0024, inners: #5 }] */
    /* JADX WARN: Removed duplicated region for block: B:38:0x006c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r1v30, types: [int] */
    /* JADX WARN: Type inference failed for: r1v31 */
    /* JADX WARN: Type inference failed for: r1v37, types: [boolean] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:31:0x0061 -> B:20:0x0030). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:50:0x00f9 -> B:38:0x0078). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:77:0x017c -> B:69:0x0120). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void b() {
        /*
            Method dump skipped, instructions count: 409
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.download.f.b():void");
    }

    private void b(String str, String str2, String str3, String str4) {
        a(str, str2, str3, str4, false);
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '1';
                    break;
                case 1:
                    c = 'E';
                    break;
                case 2:
                    c = 'q';
                    break;
                case nb.p /* 3 */:
                    c = 'B';
                    break;
                default:
                    c = 'B';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'B');
        }
        return charArray;
    }

    public void a() {
        HashMap d = this.b.d();
        synchronized (this.k) {
            for (Map.Entry entry : d.entrySet()) {
                if (!this.c.containsKey(entry.getKey())) {
                    this.c.put((String) entry.getKey(), (HashMap) entry.getValue());
                }
            }
        }
        HashMap i = this.b.i();
        synchronized (this.k) {
            for (Map.Entry entry2 : i.entrySet()) {
                if (!this.k.containsKey(entry2.getKey())) {
                    HashMap hashMap = (HashMap) entry2.getValue();
                    hashMap.put(z[0], "0");
                    this.k.put((Long) entry2.getKey(), hashMap);
                }
            }
        }
        List<d> f = this.b.f();
        synchronized (this.h) {
            for (d dVar : f) {
                if (!this.h.containsKey(dVar.k) && this.d) {
                    a(dVar, (c) null);
                }
            }
        }
        b();
        c();
    }

    public void a(d dVar, c cVar) {
        if (h.a()) {
            HashMap hashMap = new HashMap();
            hashMap.put(z[7], dVar);
            if (cVar != null) {
                mc.c(z[21] + dVar.k + z[22]);
                hashMap.put(z[1], cVar);
            }
            synchronized (this.h) {
                this.h.put(dVar.k, hashMap);
            }
            if (((HashMap) this.h.get(dVar.k)).containsKey(z[1])) {
                return;
            }
            mc.c(z[20]);
        }
    }

    @Override // com.wooboo.download.i
    public void a(Long l) {
        this.b.c(l);
        mc.c(z[19] + l);
    }

    @Override // com.wooboo.download.i
    public void a(Long l, String str) {
        this.b.b(l);
        mc.c(z[9] + str);
        synchronized (this.k) {
            ((HashMap) this.k.get(l)).put(z[0], "0");
        }
    }

    public void a(String str) {
        d h = this.b.h(str);
        HashMap hashMap = (HashMap) this.h.get(str);
        d dVar = (d) hashMap.get(z[7]);
        dVar.h = h.h;
        hashMap.put(z[7], dVar);
        this.h.put(str, hashMap);
    }

    public void a(String str, c cVar) {
        HashMap hashMap = (HashMap) this.h.get(str);
        if (hashMap == null) {
            return;
        }
        if (cVar == null) {
            hashMap.remove(z[1]);
        } else {
            hashMap.put(z[1], cVar);
        }
        synchronized (this.h) {
            this.h.put(str, hashMap);
        }
    }

    public void a(String str, String str2, String str3, String str4) {
        boolean b = h.b(this.q, str2);
        long currentTimeMillis = System.currentTimeMillis();
        this.b.a(currentTimeMillis, str2, str, b, str3, str4);
        HashMap hashMap = new HashMap();
        hashMap.put(z[2], Long.valueOf(currentTimeMillis).toString());
        hashMap.put(z[8], str2);
        hashMap.put(z[13], str3);
        hashMap.put(z[6], str4);
        if (b) {
            hashMap.put(z[5], "1");
        } else {
            hashMap.put(z[5], "0");
        }
        new fc((Map) hashMap);
        mc.c(z[12] + hashMap.toString());
        synchronized (this.c) {
            this.c.put(str, hashMap);
        }
    }

    public void a(boolean z2, String str) {
        this.d = z2;
        this.e = str;
    }

    public d b(String str) {
        if (((HashMap) this.h.get(str)) != null) {
            return this.b.h(str);
        }
        for (Map.Entry entry : this.b.h().entrySet()) {
            if (((d) entry.getValue()).k.equalsIgnoreCase(str)) {
                return (d) entry.getValue();
            }
        }
        return this.b.h(str);
    }

    public void c() {
        int size = this.b.g().size();
        if (this.f != null) {
            this.f.a(size);
            return;
        }
        if (this.g) {
            this.g = false;
            if (this.q != null) {
                if (h.a(this.q)) {
                    h.a(this.q);
                    return;
                }
                j a2 = j.a(this.q);
                this.f = a2;
                a2.a(size);
            }
        }
    }

    public void c(String str) {
        d b = b(str);
        String a2 = h.a(this.e, b.f);
        mc.c(z[10]);
        a(str, b.h, b.n, b.o);
        h.c(this.q, a2);
    }

    public void d(String str) {
        d b = b(str);
        if (b == null) {
            mc.c(z[17] + str);
            return;
        }
        if (b.m == null) {
            mc.c(z[16] + str);
        }
        if (b.o == null) {
            mc.c(z[18] + str);
        }
        a(str, sc.b(2), b.m, b.o, false);
        synchronized (this.h) {
            this.h.remove(str);
        }
        c(str);
    }

    public void e(String str) {
        synchronized (this.h) {
            this.h.remove(str);
        }
        mc.c(z[11]);
        f(str);
    }

    public void f(String str) {
        d b = b(str);
        if (b != null) {
            this.b.f(str);
            File file = new File(h.a(this.e, b.f));
            if (file.exists()) {
                file.delete();
            }
        }
    }
}
