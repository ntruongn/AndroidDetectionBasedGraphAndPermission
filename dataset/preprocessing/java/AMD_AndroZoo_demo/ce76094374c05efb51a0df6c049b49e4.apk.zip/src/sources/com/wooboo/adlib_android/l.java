package com.wooboo.adlib_android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.io.IOException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class l extends LinearLayout {
    private static final String[] z = {z(z(" \u000b+!K%\tv%D.")), z(z("-\u000040^,K(;M"))};
    final AdActivity a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l(AdActivity adActivity, Context context, com.wooboo.download.d dVar) {
        super(context);
        Bitmap bitmap;
        Bitmap bitmap2;
        Bitmap bitmap3 = null;
        this.a = adActivity;
        setId(dVar.e);
        setOrientation(0);
        RelativeLayout relativeLayout = new RelativeLayout(context);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        layoutParams.addRule(15);
        relativeLayout.setLayoutParams(layoutParams);
        addView(relativeLayout);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams2.addRule(15);
        layoutParams2.addRule(0, 110);
        layoutParams2.leftMargin = 5;
        layoutParams2.rightMargin = 5;
        TextView textView = new TextView(context);
        textView.setTextSize(16.0f);
        textView.setId(100);
        textView.setTypeface(Typeface.DEFAULT, 1);
        textView.setText(dVar.i);
        textView.setLayoutParams(layoutParams2);
        relativeLayout.addView(textView);
        try {
            bitmap = BitmapFactory.decodeStream(getResources().getAssets().open(z[0]));
        } catch (IOException e) {
            e.printStackTrace();
            bitmap = null;
        }
        int width = (int) (bitmap.getWidth() * AdActivity.a(adActivity));
        int height = (int) (bitmap.getHeight() * AdActivity.a(adActivity));
        RelativeLayout relativeLayout2 = new RelativeLayout(context);
        relativeLayout2.setId(110);
        RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams((width * 2) + 10, height + 10);
        layoutParams3.addRule(11);
        layoutParams3.addRule(15);
        layoutParams3.rightMargin = 5;
        relativeLayout2.setLayoutParams(layoutParams3);
        relativeLayout.addView(relativeLayout2);
        ImageView imageView = new ImageView(context);
        try {
            bitmap2 = BitmapFactory.decodeStream(getResources().getAssets().open(z[0]));
        } catch (IOException e2) {
            e2.printStackTrace();
            bitmap2 = null;
        }
        RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams((int) (bitmap2.getWidth() * AdActivity.a(adActivity)), (int) (bitmap2.getHeight() * AdActivity.a(adActivity)));
        layoutParams4.addRule(9);
        layoutParams4.addRule(15);
        layoutParams4.rightMargin = 5;
        imageView.setTag(Integer.valueOf(dVar.e));
        imageView.setImageDrawable(new BitmapDrawable(bitmap2));
        imageView.setLayoutParams(layoutParams4);
        imageView.setOnClickListener(new r(this));
        relativeLayout2.addView(imageView);
        ImageView imageView2 = new ImageView(context);
        try {
            bitmap3 = BitmapFactory.decodeStream(getResources().getAssets().open(z[1]));
        } catch (IOException e3) {
            e3.printStackTrace();
        }
        RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams((int) (bitmap3.getWidth() * AdActivity.a(adActivity)), (int) (bitmap3.getHeight() * AdActivity.a(adActivity)));
        layoutParams5.addRule(11);
        layoutParams5.addRule(15);
        layoutParams5.leftMargin = 10;
        imageView2.setImageDrawable(new BitmapDrawable(bitmap3));
        imageView2.setLayoutParams(layoutParams5);
        imageView2.setTag(Integer.valueOf(dVar.e));
        imageView2.setOnClickListener(new s(this));
        relativeLayout2.addView(imageView2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static AdActivity a(l lVar) {
        return lVar.a;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'I';
                    break;
                case 1:
                    c = 'e';
                    break;
                case 2:
                    c = 'X';
                    break;
                case nb.p /* 3 */:
                    c = 'U';
                    break;
                default:
                    c = '*';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '*');
        }
        return charArray;
    }
}
