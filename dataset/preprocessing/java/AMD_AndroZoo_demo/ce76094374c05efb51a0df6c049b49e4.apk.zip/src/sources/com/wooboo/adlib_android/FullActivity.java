package com.wooboo.adlib_android;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class FullActivity extends Activity {
    private static final String z = z(z("yP\u0019ZM\\Q\u001c@eK\\U_\u007f\u001fK\u001aB,L@\u0001\u0016mQA\u0007Ye[\u001f\u0016YbYL\u0012ud^K\u0012S\u007f\u0002\u0007\u001aDeZK\u0001WxVJ\u001bJgZ\\\u0017YmMA=_h[@\u001b\u0014"));
    private n a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public static n a(FullActivity fullActivity) {
        return fullActivity.a;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '?';
                    break;
                case 1:
                    c = '%';
                    break;
                case 2:
                    c = 'u';
                    break;
                case nb.p /* 3 */:
                    c = '6';
                    break;
                default:
                    c = '\f';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '\f');
        }
        return charArray;
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setRequestedOrientation(1);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        this.a = FullAdView.a;
        try {
            setContentView(this.a);
            new Handler().postDelayed(new dd(this), n.v.k() * 1000);
        } catch (Exception e) {
            mc.c(z);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (z2 || this.a == null) {
            return;
        }
        this.a.setVisibility(8);
        FullAdView.a = null;
        finish();
    }
}
