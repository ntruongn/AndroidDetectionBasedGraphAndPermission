package com.uucun.adsdk.view;

import android.widget.LinearLayout;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class g implements Runnable {
    final /* synthetic */ l a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(l lVar) {
        this.a = lVar;
    }

    @Override // java.lang.Runnable
    public void run() {
        LinearLayout linearLayout;
        linearLayout = this.a.c;
        linearLayout.setVisibility(8);
    }
}
