package com.wooboo.adlib_android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class pc extends oc {
    public static final String j = z(z("Z{!"));
    public static final String k = z(z("Zq+"));
    public static final String o = z(z("]\u007f)1AE>\"1"));
    public static final String h = z(z("Ys'="));
    public static final String i = z(z("Yd''[Y"));
    public static final String l = z(z("Yu%"));
    private static final String[] z = {z(z("C}!\u0017O^q")), z(z("N\u007f1=BEq\"\u0007GGu")), z(z("C}!\u001dOGu")), z(z("cT")), z(z("]\u007f)1AEq\":CM")), z(z("ut)$@F\u007f'7KXu(2CO")), z(z("Yu*6M^0\u00197A]~*<ONu46@K}#sHX\u007f+sJEg(?AKt*:]^cf$FOb#sqYd''[Y0{s\u001f\nq(7\u000eue4?\u000e\u00177")), z(z("C~56\\^0/=ZE050ODy(5AY8\u0019 MK~\u0019:J\u00060\u0019#OI{'4K\u0006O\"<YD|)2JObj\f]^q2&]\u0006O62\\K}j\f]OsosXK|36]\n8y\u007f\u0011\u0006/jl\u0002\u0015<yz")), z(z("Kt\"s@Ogf MK~|")), z(z("Yu*6M^0%<[Ddny\u0007\nq5sM\nv4<C\nc%2@C~ <]\ng.6\\O0\u0019#OI{'4K\n-a")), z(z("Nu*6ZO0 !AG0\"<YD|)2JC~ <]\ng.6\\O0\u0019&\\F0{s\u0011\n")), z(z("_`\"2ZO0\"<YD|)2JC~ <]\nc#'\u000euq+<[Ddfn\u000euq+<[Ddfx\u000e\u001501;KXuf\f[X|{l\u000eK~\"sqC~\"6V\n-fs\u0011")), z(z("ue4?")), z(z("\u007fD\u0000~\u0016")), z(z("uc#0")), z(z("Yu*6M^0\u0019&\\F<f\fHC|#=OGuj\f^Ks-2IO~'>K\u0006O52XOv/?KDq+6\u0002ut)$@F\u007f'7KXu(2CO<\u0019!KY`)=]O<\u00190O\u0006O%:\u0002uc#0\u000eLb)>\u000eN\u007f1=BEq\"?GYd5sYBu46\u000euc22Z_cfr\u0013\n!")), z(z("uv/?KDq+6")), z(z("ub# ^E~56")), z(z("us/")), z(z("uc'%KLy*6@K}#")), z(z("du#7\u000eN\u007f1=BEq\"i")), z(z("u`'0EKw#=OGu")), z(z("us'")), z(z("Nu*6ZO0 !AG05*]^u+:@L\u007ff$FOb#sq^y2?K\u0017/f")), z(z("C~56\\^0/=ZE05*]^u+:@L\u007fn\fZCd*6\u0002us)=ZO~2z\u000e\\q*&KY0nl\u0002\u00159f")), z(z("_`\"2ZO0\"<YD|)2JFy5']\nc#'\u000euc22Z_cfn\u000e\u001a01;KXuf\fJEg(?AKt#!KDq+6\u000e\u0017/f")), z(z("Nu*6ZO0 !AG050ODy(5AY01;KXuf\f]Iq(\fGN0{s\u0011\n")), z(z("f\u007f'7\u0014")), z(z("u}54qCt")), z(z("u}54")), z(z("_b*")), z(z("uc#0][|")), z(z("Gc!")), z(z("Yu*6M^0\u0019>]MO/7\u0002\nO+ I\u0006O3!B\u0006O56MYa*sHX\u007f+sCOc52IOy(5AY01;KXuf\f]^q2&]\n-fc\u000e")), z(z("Nu*6ZO0 !AG0\"<YD|)2JC~ <]\ng.6\\O0\u0019&\\F0{t")), z(z("\ns46O^uf'OH|#sGL0(<Z\nu>:]^cfs^Xu\"<YD|)2J\u0002O/7\u000eC~26IObf#\\C}'!W\n{#*\u000eKe2<GDs46CO~2\u007fqDq+6\u000eYd4:@M<f\f@Ed/5GIq2:AD05'\\C~!z")), z(z("\ns46O^uf'OH|#sGL0(<Z\nu>:]^cf>KYc'4KC~ <]\u0002O/7\u000eC~26IObf#\\C}'!W\n{#*\u000eKe2<GDs46CO~2\u007fqGc!\fGN0*<@M<f\fCYwf ZXy(4\u0002ue4?\u000eYd4:@M<\u0019 ZKd3 \u000eC~2\u007fqYu% _F05'\\C~!z")), z(z("iB\u0003\u0012zo0\u0012\u0012lfUf\u001ah\n^\t\u0007\u000eoH\u000f\u0000zy01<AH\u007f)2JC}!{\u000ecTf:@^u!6\\\n`4:CKb?sEOij:CM^'>K\nf'!MBq4\u007fJEg(?AKt\u0012:CO0\"2ZO</>Inq22\u000eH|)1\u0007")), z(z("\ns46O^uf'OH|#sGL0(<Z\nu>:]^cfsJEg(?AKt/=HEcn\fGN0/=ZOw#!\u000eZb/>OXif8KS0'&ZEy(0\\O}#=Z\u0006O3!B\nc2!GDwjsqC~\"6V\ny('\u0002uc22\\^`) \u000eC~2\u007fqO~\"#AY0/=Z\u0006O'>A_~2sGDdo")), z(z("\ns46O^uf'OH|#sGL0(<Z\nu>:]^cf$AEr)<MFy%8ON8\u0019:J\ny('KMu4s^Xy+2\\S0-6W\nq3'AC~%!KGu('\u0002ud#+Z\nc2!GDwjsqKy\"s]^b/=I\u0006O''\u000eYd4:@M<\u00192J^i66\u000eYd4:@M9")), z(z("\ns46O^uf'OH|#sGL0(<Z\nu>:]^cf$AEr)<ON8\u0019:J\ny('KMu4s^Xy+2\\S0-6W\nq3'AC~%!KGu('\u0002ud#+Z\nc2!GDwjsq^y2?K\nc2!GDwj\f[X|f ZXy(4\u0002uy+4[X|f ZXy(4\u0002uq6#GN05'\\C~!\u007fqKt2*^O0/=Z\u0006O6?OSd/>K\ny('\u0002u}/7\u000eYd4:@M<\u00192\\Oq/7\u000eYd4:@M9")), z(z("\ns46O^uf'OH|#sGL0(<Z\nu>:]^cf7A]~*<ON|/ ZY8\u0019:J\ny('KMu4s^Xy+2\\S0-6W\nq3'AC~%!KGu('\u0002ue4?\u000eYd4:@M<f\fHC|#=OGuf ZXy(4\u0002u`'0EKw#=OGuf ZXy(4\u0002ut)$@F\u007f'7KXu(2CO05'\\C~!\u007fqYq06HC|#=OGuf ZXy(4\u0002ub# ^E~56\u000eYd4:@M<\u0019 ZKd3 \u000eC~2\u007fqIyf ZXy(4\u0002us's]^b/=I\u0006O56M\nc2!GDwo")), z(z("\ns46O^uf'OH|#sGL0(<Z\nu>:]^cf MK~/=HEcn\fGN0/=ZOw#!\u000eZb/>OXif8KS0'&ZEy(0\\O}#=Z\u0006O50ODO/7\u000eF\u007f(4\u0002\nO62MAq!6\u000eYd4:@M<\u0019 ZKd3 \u000eC~2\u007fqN\u007f1=BEq\"6\\\nc2!GDwj\f^Kb'>\u000eYd4:@M<\u0019 KI05'\\C~!z")), z(z("\ns46O^uf'OH|#sGL0(<Z\nu>:]^cf WYd#>GDv){qCtf:@^u!6\\\n`4:CKb?sEOif2[^\u007f/=MXu+6@^<\u0019'G^|#sBE~!\u007f\u000eus)=ZO~2s]^b/=I\u0003")), z(z("yA\n:ZOT''OHq56")), z(z("uy\"")), z(z("Yu*6M^0\u0019:J\u0006O3!B\u00060\u00195GFu(2CO<\u0019#OI{'4KDq+6\u0002ut)$@F\u007f'7KXu(2CO<\u0019 O\\u :BO~'>K\u0006O46]Z\u007f( K\u0006O%2\u0002us/\u007fqYu%sHX\u007f+sJEg(?AKt*:]^cf$FOb#sqN\u007f1=BEq\"6\\O~'>K\n-fl")), z(z("Nu*6ZO0 !AG01<AH\u007f)0BCs-2J\ng.6\\O0\u0019:J\n-f")), z(z("C~56\\^0/=ZE01<AH\u007f)0BCs-2J\u0002O26V^<f\fOCtj\fO^<\u00192J^i66\u0007\nf'?[Ocnl\u0002\u0015<y\u007f\u0011\u0003")), z(z("Yu*6M^0\u0019:J\nv4<C\ng)<LE\u007f%?GI{'7\u000eEb\"6\\\nr?sqCtf2]I")), z(z("_`\"2ZO0+6]Yq!6GDv) \u000eYu2sqYd''[Y0{s\u001e\ng.6\\O0\u0019>]MO/7\u000e\u0017/f")), z(z("Yu*6M^0\u0019:J\u0006O3!B\u00060\u00195GFu(2CO<\u0019#OI{'4KDq+6\u0002ut)$@F\u007f'7KXu(2CO<\u0019 O\\u :BO~'>K\u0006O46]Z\u007f( K\u0006O%2\u0002us/\u007fqYu%sHX\u007f+sJEg(?AKt*:]^c")), z(z("C~56\\^0/=ZE0\"<YD|)2JFy5']\u0002O3!B\u00060\u00195GFu(2CO<\u00197A]~*<ONu46@K}#\u007fqYd''[Y<\u00190O\u0006O%:\u0002uc#0\u0007\nf'?[Ocf{\u0011\u0006/jl\u0002\u001a<y\u007f\u0011\u0006/os")), z(z("Yu*6M^0%<[Ddny\u0007\nq5sM\nv4<C\nt)$@F\u007f'7BCc2 \u000e]x#!K\nO3!B\n-a")), z(z("Nu*6ZO0 !AG06!KN\u007f1=BEq\"sYBu46\u000eu~)'GLy%2ZC\u007f(s\u0013\n/f")), z(z("uq\"'WZu")), z(z("ud/'BO")), z(z("ud#+Z")), z(z("uq46OCt")), z(z("Yu*6M^0\u0019:J\n<\u0019'KRdjsq^y2?K\u0006O3!B\u0006O/>I_b*\u007fqKt2*^O<\u0019#BKi2:CO<\u00192^Zy\"\u007fqGy\"\u007fqKb#2GN0 !AG01<AH\u007f)2J\n\u007f47KX0$*\u000euy\"sJOc%")), z(z("uq6#GN")), z(z("u`*2W^y+6")), z(z("uy+4[X|")), z(z("u}/7")), z(z("us)=ZO~2")), z(z("Yu*6M^0\u0019'G^|#\u007f\u000eus)=ZO~2sHX\u007f+s]Sc26CC~ <\u000e")), z(z("uu(7^Ec")), z(z("C~ <\u0000K})&@^*")), z(z("uc22\\^`) ")), z(z("uq+<[Dd")), z(z("Yu*6M^0\u0019&\\F<f\fGDt#+\u0002uc22\\^`) \u0002uu(7^Ecj\fOG\u007f3=Z\nv4<C\nt)$@F\u007f'7GDv) \u000e]x#!K\nO3!B\n-a")), z(z("uy(7KR")), z(z("nB\t\u0003\u000e~Q\u0004\u001fk\nY\u0000skrY\u0015\u0007}\ng)<LE\u007f'7")), z(z("nB\t\u0003\u000e~Q\u0004\u001fk\nY\u0000skrY\u0015\u0007}\nt)$@F\u007f'7BCc2 ")), z(z("nB\t\u0003\u000e~Q\u0004\u001fk\nY\u0000skrY\u0015\u0007}\ng)<LE\u007f'7GGw")), z(z("nB\t\u0003\u000e~Q\u0004\u001fk\nY\u0000skrY\u0015\u0007}\n}# ]Kw#:@L\u007f5")), z(z("nB\t\u0003\u000e~Q\u0004\u001fk\nY\u0000skrY\u0015\u0007}\nt)$@F\u007f'7GDv) ")), z(z("nB\t\u0003\u000e~Q\u0004\u001fk\nY\u0000skrY\u0015\u0007}\ng)<LE\u007f%?GI{'7")), z(z("nB\t\u0003\u000e~Q\u0004\u001fk\nY\u0000skrY\u0015\u0007}\n`46JEg(?AKt")), z(z("nB\t\u0003\u000e~Q\u0004\u001fk\nY\u0000skrY\u0015\u0007}\nc? ZO}/=HE")), z(z("nB\t\u0003\u000e~Q\u0004\u001fk\nY\u0000skrY\u0015\u0007}\nc%2@C~ <]")), z(z("Nu*6ZO0 !AG01<AH\u007f)2JC}!sYBu46\u000ecTfn\u000e")), z(z("_`\"2ZO0\"<YD|)2JFy5']\nc#'\u000eu`'0EKw#=OGufn\u000e\u001501;KXuf\f[X|fn\u0011\n")), z(z("Kt2*^O")), z(z("Ky\"")), z(z("uq/7")), z(z("Kd")), z(z("uq2")), z(z("Yu*6M^0\u0019'KRdjsqKy\"\u007fqKdj\fONd?#K\nv4<C\ng)<LE\u007f%?GI{'7\u000eEb\"6\\\nr?sqCtf7KYs")), z(z("_`\"2ZO0\"<YD|)2JFy5']\nc#'\u000euc22Z_cfn\u000e\u001b01;KXuf\fJEg(?AKt#!KDq+6\u000e\u0017/f")), z(z("Yu*6M^0\u0019 MK~\u0019:J\u00060\u0019#OI{'4K\u0006O\"<YD|)2JObj\f]^q2&]\u0006O62\\K}j\f]Osf5\\E}f MK~/=HEc")), z(z("u`'!OG")), z(z("uc22Z_c")), z(z("uc%2@uy\"")), z(z("u`'0EKw#")), z(z("ut)$@F\u007f'7KX")), z(z("_`\"2ZO0+6]Yq!6GDv) \u000eYu2sqYd''[Y0{s\u001f\ng.6\\O0\u0019>]MO/7\u000e\u0017/f")), z(z("_`\"2ZO0\"<YD|)2JFy5']\nc#'\u000euc22Z_cfn\u000e\u0007!f$FOb#sqN\u007f1=BEq\"6\\O~'>K\n-ys")), z(z("Si?*\u0003g]k7J\nx.iCG*5 ")), z(z("Yu*6M^0\u0019:J\u0006O3!B\u00060\u00195GFu(2CO<\u0019#OI{'4KDq+6\u0002ut)$@F\u007f'7KXu(2CO<\u0019 O\\u :BO~'>K\u0006O46]Z\u007f( K\u0006O%2\u0002us/\u007fqYu%sHX\u007f+sJEg(?AKt*:]^cf$FOb#sqYd''[Y0{s\u001f")), z(z("_`\"2ZO0\"<YD|)2JFy5']\nc#'\u000euc'%KLy*6@K}#s\u0013\n/f$FOb#sq_b*s\u0013\u00150")), z(z("Yu*6M^0%<[Ddny\u0007\nq5sM\nv4<C\n`46JEg(?AKtf")), z(z("C~56\\^0/=ZE0\"<YD|)2JFy5']\u0002O3!B\u00060\u00195GFu(2CO<\u00197A]~*<ONu46@K}#\u007fqXu5#ADc#\u007fqYd''[Y<\u00190O\u0006O%:\u0002uc#0\u0007\nf'?[Ocf{\u0011\u0006/jl\u0002\u0015<v\u007f\u0011\u0006/jl\u0007\n")), z(z("Yu*6M^0%<[Ddny\u0007\nq5sM\nv4<C\nt)$@F\u007f'7GDv) \u000e]x#!K\nO3!B\n-a")), z(z("Nu*6ZO0 !AG0+6]Yq!6GDv) \u000e]x#!K\nO+ Iuy\"n\u0011\n")), z(z("C~56\\^0/=ZE0+6]Yq!6GDv) \u0006u}54qCtj\fCYwj\f[X|j\f]^q2&]\u0006O56MYa*z\u000e\\q*&KY0nl\u0002\u0015<y\u007f\u0011\u0006/os")), z(z("C}!\u001dOGu{l")), z(z("C~56\\^0/=ZE06!KN\u007f1=BEq\"{qDq+6\u0002u~)'GLy%2ZC\u007f(z\u000e\\q*&KY0nl\u0002\u00159f")), z(z("Nu*6ZO0 !AG0\"<YD|)2JFy5']\ng.6\\O0\u00197A]~*<ONu46@K}#s\u0013\u00150")), z(z("Xu+<XOT)$@F\u007f'7\u000e")), z(z("Yu*6M^0\u0019:J\nv4<C\ng)<LE\u007f'7\u000eEb\"6\\\nr?sqCtf2]I")), z(z("C~56\\^0/=ZE01<AH\u007f)2J\u0002O26V^<f\fZCd*6\u0002ue4?\u0002uy+4[X|j\fONd?#K\u0006O6?OSd/>K\u0006O'#^Ctj\fCCtj\fOXu':J\u0003002B_u5{\u0011\u0006/jl\u0002\u0015<y\u007f\u0011\u0006/jl\u0002\u00159")), z(z("Nu*6ZO0 !AG01<AH\u007f)2J\ng.6\\O0\u0019&\\F0{l\u000e")), z(z("Nu*6ZO0 !AG01<AH\u007f)2J\ng.6\\O0\u0019:J\n-f")), z(z("ktf\u001aCKw#sJEu5s@Edf6VCc2 ")), z(z("ktf\u001aCKw#sOFb#2JS0#+GYd5")), z(z("C~56\\^0/=ZE0\"<YD|)2JC~ <]\u0002O3!B\u00060\u0019:@Nu>\u007fqYd'!ZZ\u007f5\u007fqO~\"#AY<\u00192CEe('\u0007\nf'?[Ocnl\u0002\u0015<y\u007f\u0011\u0006/o"))};
    private static pc m = null;
    private static pc n = null;

    public pc(Context context, String str) {
        this(context, str, null, 1);
        a(a());
    }

    private pc(Context context, String str, SQLiteDatabase.CursorFactory cursorFactory, int i2) {
        super(context, str, cursorFactory, i2);
    }

    public static synchronized pc a(Context context, String str) {
        pc pcVar;
        synchronized (pc.class) {
            if (str != null) {
                try {
                    if (n == null) {
                        n = new pc(context, str);
                    }
                    pcVar = n;
                } catch (SQLException e) {
                    throw e;
                }
            } else {
                try {
                    if (m == null) {
                        m = new pc(context, o);
                    }
                    pcVar = m;
                } catch (SQLException e2) {
                    throw e2;
                }
            }
        }
        return pcVar;
    }

    protected static String k() {
        return new SimpleDateFormat(z[98]).format(new Date());
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i2 = 0; length > i2; i2++) {
            char c2 = cArr[i2];
            switch (i2 % 5) {
                case 0:
                    c = '*';
                    break;
                case 1:
                    c = 16;
                    break;
                case 2:
                    c = 'F';
                    break;
                case nb.p /* 3 */:
                    c = 'S';
                    break;
                default:
                    c = '.';
                    break;
            }
            cArr[i2] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '.');
        }
        return charArray;
    }

    public void a(long j2) {
        a().execSQL(z[26], new Object[]{Long.valueOf(j2)});
    }

    public void a(long j2, String str, String str2, boolean z2, String str3, String str4) {
        mc.c(z[8] + str4);
        SQLiteDatabase a = a();
        Cursor rawQuery = a.rawQuery(z[9] + str + "'", null);
        int i2 = rawQuery.moveToNext() ? rawQuery.getInt(0) : 0;
        rawQuery.close();
        if (i2 == 0) {
            String str5 = z[7];
            try {
                if (z2) {
                    a.execSQL(str5, new Object[]{Long.valueOf(j2), sc.d(str), str2, 1, sc.d(str3), str4});
                } else {
                    a.execSQL(str5, new Object[]{Long.valueOf(j2), sc.d(str), str2, 0, sc.d(str3), str4});
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override // com.wooboo.adlib_android.oc
    public void a(SQLiteDatabase sQLiteDatabase) {
        mc.c(z[44]);
        try {
            sQLiteDatabase.execSQL(z[37]);
            sQLiteDatabase.execSQL(z[40]);
            sQLiteDatabase.execSQL(z[39]);
            sQLiteDatabase.execSQL(z[41]);
            sQLiteDatabase.execSQL(z[35]);
            sQLiteDatabase.execSQL(z[38]);
            sQLiteDatabase.execSQL(z[36]);
            sQLiteDatabase.execSQL(z[43]);
            sQLiteDatabase.execSQL(z[42]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // com.wooboo.adlib_android.oc
    public void a(SQLiteDatabase sQLiteDatabase, int i2, int i3) {
        sQLiteDatabase.execSQL(z[74]);
        sQLiteDatabase.execSQL(z[72]);
        sQLiteDatabase.execSQL(z[76]);
        sQLiteDatabase.execSQL(z[75]);
        sQLiteDatabase.execSQL(z[79]);
        sQLiteDatabase.execSQL(z[73]);
        sQLiteDatabase.execSQL(z[78]);
        sQLiteDatabase.execSQL(z[77]);
        sQLiteDatabase.execSQL(z[80]);
        a(sQLiteDatabase);
    }

    public void a(hb hbVar) {
        SQLiteDatabase a = a();
        a.execSQL(z[112], new Object[]{hbVar.e});
        Cursor rawQuery = a.rawQuery(z[110], null);
        if (rawQuery != null) {
            try {
                if (rawQuery.getCount() >= 20) {
                    rawQuery.moveToFirst();
                    a.execSQL(z[113] + rawQuery.getString(0));
                }
            } catch (SQLException e) {
                throw e;
            }
        }
        rawQuery.close();
        a.execSQL(z[111], new Object[]{hbVar.c, hbVar.f(), sc.d(hbVar.i()), hbVar.h(), Integer.valueOf(hbVar.j()), Integer.valueOf(hbVar.k()), sc.d(hbVar.e()), sc.d(hbVar.d()), sc.d(hbVar.c())});
    }

    public void a(hb hbVar, String str) {
        SQLiteDatabase a = a();
        Cursor rawQuery = a.rawQuery(z[49], null);
        if (rawQuery != null) {
            try {
                if (rawQuery.getCount() >= 20) {
                    rawQuery.moveToFirst();
                    a.execSQL(z[47] + rawQuery.getString(0));
                }
            } catch (SQLException e) {
                throw e;
            }
        }
        rawQuery.close();
        a.execSQL(z[48], new Object[]{hbVar.c, Integer.valueOf(hbVar.b()).toString(), str, Integer.valueOf(hbVar.j()).toString()});
    }

    public void a(com.wooboo.download.d dVar) {
        a().execSQL(z[116], new Object[]{dVar.a, Integer.valueOf(dVar.e), Integer.valueOf(dVar.b), Integer.valueOf(dVar.c), Integer.valueOf(dVar.d)});
    }

    public void a(Long l2) {
        a().execSQL(z[96], new Object[]{l2});
    }

    public void a(Long l2, HashMap hashMap) {
        a().execSQL(z[105], new Object[]{l2, sc.d((String) hashMap.get(z[32])), sc.d((String) hashMap.get(z[30])), 0, sc.d((String) hashMap.get(l))});
    }

    public void a(String str, int i2, int i3) {
        a().execSQL(z[11], new Object[]{Integer.valueOf(i3), str, Integer.valueOf(i2)});
    }

    public void a(String str, String str2) {
        String str3 = z[107];
        try {
            a().execSQL(str3, new Object[]{new String(str2.getBytes(), z[13]), str});
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        }
    }

    public void a(String str, String str2, String str3, String str4, String str5, String str6) {
        SQLiteDatabase a = a();
        Cursor rawQuery = a.rawQuery(z[53] + str + "'", null);
        int i2 = rawQuery.moveToNext() ? rawQuery.getInt(0) : 0;
        rawQuery.close();
        if (i2 == 0) {
            try {
                a.execSQL(z[52], new Object[]{str, new String(str3.getBytes(), z[13]), str2, sc.d(str4), sc.d(str5), sc.d(str6)});
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e2) {
                e2.printStackTrace();
            }
        }
    }

    public void a(String str, byte[] bArr) {
        try {
            SQLiteDatabase a = a();
            ContentValues contentValues = new ContentValues();
            contentValues.put(z[2], str);
            contentValues.put(z[1], k());
            contentValues.put(z[0], bArr);
            a.insert(z[4], z[3], contentValues);
        } catch (Exception e) {
        }
        l();
    }

    public void a(List list) {
        Iterator it = list.iterator();
        while (it.hasNext()) {
            try {
                a((com.wooboo.download.d) it.next());
            } catch (SQLException e) {
                throw e;
            }
        }
    }

    public boolean a(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        SQLiteDatabase a = a();
        Cursor rawQuery = a.rawQuery(z[53] + str + "'", null);
        int i2 = rawQuery.moveToNext() ? rawQuery.getInt(0) : 0;
        rawQuery.close();
        if (i2 != 0) {
            return true;
        }
        try {
            a.execSQL(z[102], new Object[]{str, new String(str3.getBytes(), z[13]), str2, str4, sc.d(str5), sc.d(str6), sc.d(str7)});
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
            return false;
        }
    }

    public void b(Long l2) {
        a().execSQL(z[50], new Object[]{l2});
    }

    public void b(String str) {
        a().execSQL(z[54], new Object[]{str});
    }

    public void b(String str, String str2) {
        a().execSQL(z[100], new Object[]{str2, str});
    }

    public void c(Long l2) {
        a().execSQL(z[104], new Object[]{l2});
    }

    public void c(String str) {
        a().execSQL(z[89], new Object[]{str});
    }

    public void c(String str, String str2) {
        a().execSQL(z[82], new Object[]{str2, str});
    }

    public HashMap d() {
        HashMap hashMap = new HashMap();
        Cursor rawQuery = a().rawQuery(z[90], null);
        while (rawQuery.moveToNext()) {
            try {
                HashMap hashMap2 = new HashMap();
                hashMap2.put(h, Long.valueOf(rawQuery.getLong(rawQuery.getColumnIndex(z[93]))).toString());
                hashMap2.put(i, Long.valueOf(rawQuery.getLong(rawQuery.getColumnIndex(z[92]))).toString());
                hashMap2.put(j, sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[94]))));
                hashMap2.put(k, sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[91]))));
                hashMap2.put(l, rawQuery.getString(rawQuery.getColumnIndex(z[14])));
                hashMap.put(rawQuery.getString(rawQuery.getColumnIndex(z[95])), hashMap2);
            } catch (SQLException e) {
                throw e;
            }
        }
        rawQuery.close();
        return hashMap;
    }

    public void d(String str) {
        a().execSQL(z[97], new Object[]{str});
    }

    public void d(String str, String str2) {
        SQLiteDatabase a = a();
        a.execSQL(z[23], new Object[]{sc.d(str)});
        a.execSQL(z[24], new Object[]{sc.d(str), sc.d(str2)});
    }

    public void e(String str) {
        a().execSQL(z[25], new Object[]{str});
    }

    public boolean e() {
        Cursor rawQuery = a().rawQuery(z[101], null);
        int i2 = rawQuery.moveToNext() ? rawQuery.getInt(0) : 0;
        try {
            rawQuery.close();
            return i2 == 0;
        } catch (SQLException e) {
            throw e;
        }
    }

    public List f() {
        com.wooboo.download.d dVar = null;
        boolean z2 = sc.C;
        ArrayList arrayList = new ArrayList();
        Cursor rawQuery = a().rawQuery(z[15], null);
        while (true) {
            try {
                if (rawQuery.moveToNext()) {
                    dVar = new com.wooboo.download.d();
                    dVar.a = rawQuery.getString(rawQuery.getColumnIndex(z[12]));
                    try {
                        dVar.i = new String(rawQuery.getString(rawQuery.getColumnIndex(z[16])).getBytes(), z[13]);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    dVar.h = rawQuery.getString(rawQuery.getColumnIndex(z[21]));
                    dVar.k = rawQuery.getString(rawQuery.getColumnIndex(z[5]));
                    dVar.f = rawQuery.getString(rawQuery.getColumnIndex(z[19]));
                    dVar.l = rawQuery.getString(rawQuery.getColumnIndex(z[17]));
                    dVar.m = rawQuery.getString(rawQuery.getColumnIndex(z[22]));
                    dVar.n = rawQuery.getString(rawQuery.getColumnIndex(z[18]));
                    dVar.o = rawQuery.getString(rawQuery.getColumnIndex(z[14]));
                } else {
                    rawQuery.close();
                    if (!z2) {
                        return arrayList;
                    }
                }
                com.wooboo.download.d dVar2 = dVar;
                arrayList.add(dVar2);
                mc.c(z[20] + dVar2.a);
                dVar = dVar2;
            } catch (UnsupportedEncodingException e2) {
                throw e2;
            }
        }
    }

    public void f(String str) {
        mc.c(z[109] + str);
        a().execSQL(z[108], new Object[]{str});
    }

    public String g(String str) {
        Cursor rawQuery = a().rawQuery(z[6] + str + "'", null);
        try {
            if (rawQuery.getCount() == 0) {
                return null;
            }
            rawQuery.moveToFirst();
            String string = rawQuery.getString(rawQuery.getColumnIndex(z[5]));
            rawQuery.close();
            return string;
        } catch (SQLException e) {
            throw e;
        }
    }

    public HashMap g() {
        boolean z2 = sc.C;
        HashMap hashMap = new HashMap();
        Cursor rawQuery = a().rawQuery(z[99], null);
        while (true) {
            try {
                if (rawQuery.moveToNext()) {
                    com.wooboo.download.d dVar = new com.wooboo.download.d();
                    dVar.e = rawQuery.getInt(rawQuery.getColumnIndex(z[45]));
                    dVar.a = rawQuery.getString(rawQuery.getColumnIndex(z[12]));
                    dVar.i = rawQuery.getString(rawQuery.getColumnIndex(z[16]));
                    dVar.h = rawQuery.getString(rawQuery.getColumnIndex(z[21]));
                    dVar.k = rawQuery.getString(rawQuery.getColumnIndex(z[5]));
                    dVar.f = rawQuery.getString(rawQuery.getColumnIndex(z[19]));
                    dVar.l = rawQuery.getString(rawQuery.getColumnIndex(z[17]));
                    dVar.m = rawQuery.getString(rawQuery.getColumnIndex(z[22]));
                    dVar.n = rawQuery.getString(rawQuery.getColumnIndex(z[18]));
                    dVar.o = rawQuery.getString(rawQuery.getColumnIndex(z[14]));
                    hashMap.put(Integer.valueOf(dVar.e), dVar);
                } else {
                    rawQuery.close();
                    if (!z2) {
                        return hashMap;
                    }
                }
            } catch (SQLException e) {
                throw e;
            }
        }
    }

    public com.wooboo.download.d h(String str) {
        Cursor rawQuery = a().rawQuery(z[46], new String[]{str});
        if (rawQuery != null) {
            try {
                if (rawQuery.getCount() == 1) {
                    rawQuery.moveToFirst();
                    com.wooboo.download.d dVar = new com.wooboo.download.d();
                    dVar.e = rawQuery.getInt(rawQuery.getColumnIndex(z[45]));
                    dVar.a = rawQuery.getString(rawQuery.getColumnIndex(z[12]));
                    try {
                        dVar.i = new String(rawQuery.getString(rawQuery.getColumnIndex(z[16])).getBytes(), z[13]);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    dVar.h = rawQuery.getString(rawQuery.getColumnIndex(z[21]));
                    dVar.k = rawQuery.getString(rawQuery.getColumnIndex(z[5]));
                    dVar.f = rawQuery.getString(rawQuery.getColumnIndex(z[19]));
                    dVar.l = rawQuery.getString(rawQuery.getColumnIndex(z[17]));
                    dVar.m = rawQuery.getString(rawQuery.getColumnIndex(z[22]));
                    dVar.n = rawQuery.getString(rawQuery.getColumnIndex(z[18]));
                    dVar.o = rawQuery.getString(rawQuery.getColumnIndex(z[14]));
                    rawQuery.close();
                    return dVar;
                }
            } catch (UnsupportedEncodingException e2) {
                throw e2;
            }
        }
        return null;
    }

    public HashMap h() {
        boolean z2 = sc.C;
        HashMap hashMap = new HashMap();
        Cursor rawQuery = a().rawQuery(z[51], null);
        while (true) {
            try {
                if (rawQuery.moveToNext()) {
                    com.wooboo.download.d dVar = new com.wooboo.download.d();
                    dVar.e = rawQuery.getInt(rawQuery.getColumnIndex(z[45]));
                    dVar.a = rawQuery.getString(rawQuery.getColumnIndex(z[12]));
                    dVar.i = rawQuery.getString(rawQuery.getColumnIndex(z[16]));
                    dVar.h = rawQuery.getString(rawQuery.getColumnIndex(z[21]));
                    dVar.k = rawQuery.getString(rawQuery.getColumnIndex(z[5]));
                    dVar.f = rawQuery.getString(rawQuery.getColumnIndex(z[19]));
                    dVar.l = rawQuery.getString(rawQuery.getColumnIndex(z[17]));
                    dVar.m = rawQuery.getString(rawQuery.getColumnIndex(z[22]));
                    dVar.n = rawQuery.getString(rawQuery.getColumnIndex(z[18]));
                    dVar.o = rawQuery.getString(rawQuery.getColumnIndex(z[14]));
                    hashMap.put(Integer.valueOf(dVar.e), dVar);
                } else {
                    rawQuery.close();
                    if (!z2) {
                        return hashMap;
                    }
                }
            } catch (SQLException e) {
                throw e;
            }
        }
    }

    public String i(String str) {
        HashMap j2 = j();
        try {
            if (j2.containsKey(str)) {
                return (String) j2.get(str);
            }
            return null;
        } catch (SQLException e) {
            throw e;
        }
    }

    public HashMap i() {
        HashMap hashMap = new HashMap();
        Cursor rawQuery = b().rawQuery(z[33], null);
        while (rawQuery.moveToNext()) {
            try {
                HashMap hashMap2 = new HashMap();
                hashMap2.put(z[32], sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[29]))));
                hashMap2.put(z[30], sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[12]))));
                hashMap2.put(l, sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[31]))));
                hashMap.put(Long.valueOf(rawQuery.getLong(rawQuery.getColumnIndex(z[28]))), hashMap2);
                mc.c(z[27] + Long.valueOf(rawQuery.getLong(rawQuery.getColumnIndex(z[28]))).toString() + rawQuery.getString(rawQuery.getColumnIndex(z[12])));
            } catch (SQLException e) {
                throw e;
            }
        }
        rawQuery.close();
        return hashMap;
    }

    public HashMap j() {
        HashMap hashMap = new HashMap();
        Cursor rawQuery = a().rawQuery(z[65], null);
        while (rawQuery.moveToNext()) {
            try {
                hashMap.put(sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[56]))), sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[64]))));
            } catch (SQLException e) {
                throw e;
            }
        }
        rawQuery.close();
        return hashMap;
    }

    public boolean j(String str) {
        Cursor rawQuery = a().rawQuery(z[103] + str + "'", null);
        int i2 = rawQuery.moveToNext() ? rawQuery.getInt(0) : 0;
        try {
            rawQuery.close();
            return i2 == 0;
        } catch (SQLException e) {
            throw e;
        }
    }

    public void k(String str) {
        a().execSQL(z[10], new Object[]{str});
    }

    public List l(String str) {
        ArrayList arrayList = new ArrayList();
        Cursor rawQuery = a().rawQuery(z[70] + str + "'", null);
        while (rawQuery.moveToNext()) {
            try {
                com.wooboo.download.d dVar = new com.wooboo.download.d();
                dVar.a = rawQuery.getString(rawQuery.getColumnIndex(z[12]));
                dVar.e = rawQuery.getInt(rawQuery.getColumnIndex(z[71]));
                dVar.b = rawQuery.getInt(rawQuery.getColumnIndex(z[68]));
                dVar.c = rawQuery.getInt(rawQuery.getColumnIndex(z[66]));
                dVar.d = rawQuery.getInt(rawQuery.getColumnIndex(z[69]));
                arrayList.add(dVar);
                mc.c(z[67] + dVar.d);
            } catch (SQLException e) {
                throw e;
            }
        }
        rawQuery.close();
        return arrayList;
    }

    public void l() {
        try {
            SQLiteDatabase a = a();
            Cursor query = a.query(z[4], null, null, null, null, null, null);
            if (query.getCount() > 20) {
                query.moveToFirst();
                a.execSQL(z[81] + query.getString(0));
            }
            if (query != null) {
                query.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public hb m() {
        Cursor rawQuery = a().rawQuery(z[59], null);
        if (rawQuery == null) {
            return null;
        }
        try {
            if (rawQuery.getCount() < 1) {
                return null;
            }
            rawQuery.moveToFirst();
            hb hbVar = new hb();
            hbVar.d(rawQuery.getString(rawQuery.getColumnIndex(z[57])));
            hbVar.e(rawQuery.getString(rawQuery.getColumnIndex(z[56])));
            hbVar.f(sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[12]))));
            hbVar.g(rawQuery.getString(rawQuery.getColumnIndex(z[62])));
            hbVar.b(rawQuery.getInt(rawQuery.getColumnIndex(z[55])));
            hbVar.c(rawQuery.getInt(rawQuery.getColumnIndex(z[61])));
            hbVar.c(sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[60]))));
            hbVar.b(sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[63]))));
            hbVar.a(sc.e(rawQuery.getString(rawQuery.getColumnIndex(z[58]))));
            rawQuery.close();
            return hbVar;
        } catch (SQLException e) {
            throw e;
        }
    }

    public void m(String str) {
        a().execSQL(z[34] + str + "'");
    }

    public ec n() {
        ec ecVar = new ec();
        try {
            Cursor rawQuery = a().rawQuery(z[88], null);
            while (rawQuery.moveToNext()) {
                fc fcVar = new fc();
                fcVar.c(z[84], rawQuery.getString(rawQuery.getColumnIndex(z[85])));
                fcVar.c(z[86], rawQuery.getString(rawQuery.getColumnIndex(z[87])));
                fcVar.c(z[83], rawQuery.getString(rawQuery.getColumnIndex(z[55])));
                ecVar = ecVar.a(fcVar);
            }
            rawQuery.close();
        } catch (Exception e) {
        }
        return ecVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x002f A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:16:0x002a A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0043  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean n(java.lang.String r11) {
        /*
            r10 = this;
            r9 = 1
            r8 = 0
            android.database.sqlite.SQLiteDatabase r0 = r10.a()     // Catch: java.lang.Exception -> L3b
            java.lang.String[] r1 = com.wooboo.adlib_android.pc.z     // Catch: java.lang.Exception -> L3b
            r2 = 4
            r1 = r1[r2]     // Catch: java.lang.Exception -> L3b
            r2 = 0
            java.lang.String[] r3 = com.wooboo.adlib_android.pc.z     // Catch: java.lang.Exception -> L3b
            r4 = 106(0x6a, float:1.49E-43)
            r3 = r3[r4]     // Catch: java.lang.Exception -> L3b
            r4 = 1
            java.lang.String[] r4 = new java.lang.String[r4]     // Catch: java.lang.Exception -> L3b
            r5 = 0
            r4[r5] = r11     // Catch: java.lang.Exception -> L3b
            r5 = 0
            r6 = 0
            r7 = 0
            android.database.Cursor r0 = r0.query(r1, r2, r3, r4, r5, r6, r7)     // Catch: java.lang.Exception -> L3b
            if (r0 == 0) goto L4f
            int r1 = r0.getCount()     // Catch: java.lang.Exception -> L39
            if (r1 <= 0) goto L4f
            r1 = r9
        L28:
            if (r0 == 0) goto L2d
            r0.close()     // Catch: java.lang.Exception -> L4d
        L2d:
            if (r1 == 0) goto L43
            java.lang.String[] r0 = com.wooboo.adlib_android.pc.z     // Catch: java.lang.Exception -> L41
            r2 = 115(0x73, float:1.61E-43)
            r0 = r0[r2]     // Catch: java.lang.Exception -> L41
            com.wooboo.adlib_android.mc.a(r0)     // Catch: java.lang.Exception -> L41
        L38:
            return r1
        L39:
            r0 = move-exception
            throw r0     // Catch: java.lang.Exception -> L3b
        L3b:
            r0 = move-exception
            r1 = r8
        L3d:
            r0.printStackTrace()
            goto L2d
        L41:
            r0 = move-exception
            throw r0
        L43:
            java.lang.String[] r0 = com.wooboo.adlib_android.pc.z
            r2 = 114(0x72, float:1.6E-43)
            r0 = r0[r2]
            com.wooboo.adlib_android.mc.a(r0)
            goto L38
        L4d:
            r0 = move-exception
            goto L3d
        L4f:
            r1 = r8
            goto L28
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.pc.n(java.lang.String):boolean");
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0041 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public byte[] o(java.lang.String r10) {
        /*
            r9 = this;
            r0 = 0
            r8 = r0
            byte[] r8 = (byte[]) r8
            android.database.sqlite.SQLiteDatabase r0 = r9.a()     // Catch: java.lang.Exception -> L47
            java.lang.String[] r1 = com.wooboo.adlib_android.pc.z     // Catch: java.lang.Exception -> L47
            r2 = 4
            r1 = r1[r2]     // Catch: java.lang.Exception -> L47
            r2 = 1
            java.lang.String[] r2 = new java.lang.String[r2]     // Catch: java.lang.Exception -> L47
            r3 = 0
            java.lang.String[] r4 = com.wooboo.adlib_android.pc.z     // Catch: java.lang.Exception -> L47
            r5 = 0
            r4 = r4[r5]     // Catch: java.lang.Exception -> L47
            r2[r3] = r4     // Catch: java.lang.Exception -> L47
            java.lang.String[] r3 = com.wooboo.adlib_android.pc.z     // Catch: java.lang.Exception -> L47
            r4 = 106(0x6a, float:1.49E-43)
            r3 = r3[r4]     // Catch: java.lang.Exception -> L47
            r4 = 1
            java.lang.String[] r4 = new java.lang.String[r4]     // Catch: java.lang.Exception -> L47
            r5 = 0
            r4[r5] = r10     // Catch: java.lang.Exception -> L47
            r5 = 0
            r6 = 0
            r7 = 0
            android.database.Cursor r1 = r0.query(r1, r2, r3, r4, r5, r6, r7)     // Catch: java.lang.Exception -> L47
            if (r1 == 0) goto L50
            int r0 = r1.getCount()     // Catch: java.lang.Exception -> L45
            if (r0 == 0) goto L50
            boolean r0 = r1.moveToFirst()     // Catch: java.lang.Exception -> L45
            if (r0 == 0) goto L50
            r0 = 0
            byte[] r8 = r1.getBlob(r0)     // Catch: java.lang.Exception -> L47
            r0 = r8
        L3f:
            if (r1 == 0) goto L44
            r1.close()     // Catch: java.lang.Exception -> L4e
        L44:
            return r0
        L45:
            r0 = move-exception
            throw r0     // Catch: java.lang.Exception -> L47
        L47:
            r0 = move-exception
            r1 = r0
            r0 = r8
        L4a:
            r1.printStackTrace()
            goto L44
        L4e:
            r1 = move-exception
            goto L4a
        L50:
            r0 = r8
            goto L3f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.pc.o(java.lang.String):byte[]");
    }
}
