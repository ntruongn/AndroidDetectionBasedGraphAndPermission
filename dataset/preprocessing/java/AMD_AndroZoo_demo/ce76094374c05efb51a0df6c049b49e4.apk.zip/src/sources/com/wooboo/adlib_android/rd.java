package com.wooboo.adlib_android;

import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class rd extends TimerTask {
    final WoobooAdView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public rd(WoobooAdView woobooAdView) {
        this.a = woobooAdView;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        WoobooAdView.e(this.a);
    }
}
