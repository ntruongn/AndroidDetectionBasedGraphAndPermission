package com.wooboo.adlib_android;

import android.webkit.WebChromeClient;
import android.webkit.WebView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class j extends WebChromeClient {
    final m a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(m mVar) {
        this.a = mVar;
    }

    @Override // android.webkit.WebChromeClient
    public void onProgressChanged(WebView webView, int i) {
        super.onProgressChanged(webView, i);
        this.a.b.setProgress(i);
        if (i >= 90) {
            this.a.c.sendEmptyMessage(0);
            if (AdActivity.b()) {
                AdActivity.a(false);
                if (sc.l()) {
                    return;
                }
                m.a(this.a).confirmToServer(AdActivity.d(m.a(this.a)));
            }
        }
    }
}
