package com.kuguo.pushads;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class r extends Handler {
    final /* synthetic */ c a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public r(c cVar) {
        this.a = cVar;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        Activity activity;
        g gVar;
        int i;
        g gVar2;
        g gVar3;
        Bundle data = message.getData();
        int i2 = data.getInt("tag");
        String string = data.getString("filePath");
        if (string != null) {
            activity = this.a.f;
            Bitmap a = a.a((Context) activity, string, false);
            if (a != null) {
                gVar = this.a.e;
                if (gVar != null) {
                    if (i2 == -1) {
                        gVar3 = this.a.e;
                        gVar3.a(a);
                    } else if (i2 > -1) {
                        i = this.a.c;
                        if (i2 < i) {
                            gVar2 = this.a.e;
                            gVar2.a(a, i2);
                        }
                    }
                }
            }
        }
    }
}
