package com.wooboo.adlib_android;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class lb {
    private static final String[] z = {z(z("\u007f?N#]V~S*\u0018V?z")), z(z("apT!\u0019\u0002qN9]DvO)]DvD!\u0019\u0002D"))};

    private lb() {
    }

    /* JADX WARN: Can't wrap try/catch for region: R(7:12|13|4|(1:6)|8|9|10) */
    /* JADX WARN: Code restructure failed: missing block: B:10:0x0008, code lost:
    
        return r1.getDeclaredField(r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x000c, code lost:
    
        r1 = r1.getSuperclass();
     */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0002, code lost:
    
        if (com.wooboo.adlib_android.sc.C != false) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0012, code lost:
    
        if (r1 == java.lang.Object.class) goto L12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0014, code lost:
    
        return null;
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:13:0x000c -> B:4:0x0010). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected static java.lang.reflect.Field a(java.lang.Class r1, java.lang.String r2) {
        /*
            boolean r0 = com.wooboo.adlib_android.sc.C     // Catch: java.lang.IllegalArgumentException -> L9
            if (r0 == 0) goto L10
        L4:
            java.lang.reflect.Field r0 = r1.getDeclaredField(r2)     // Catch: java.lang.IllegalArgumentException -> L9 java.lang.NoSuchFieldException -> Lb
        L8:
            return r0
        L9:
            r0 = move-exception
            throw r0
        Lb:
            r0 = move-exception
            java.lang.Class r1 = r1.getSuperclass()
        L10:
            java.lang.Class<java.lang.Object> r0 = java.lang.Object.class
            if (r1 != r0) goto L4
            r0 = 0
            goto L8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.lb.a(java.lang.Class, java.lang.String):java.lang.reflect.Field");
    }

    protected static Field a(Object obj, String str) {
        return a((Class) obj.getClass(), str);
    }

    public static void a(Object obj, String str, Object obj2) {
        Field a = a(obj, str);
        if (a == null) {
            try {
                throw new IllegalArgumentException(z[1] + str + z[0] + obj + "]");
            } catch (IllegalAccessException e) {
                throw e;
            }
        } else {
            a(a);
            try {
                a.set(obj, obj2);
            } catch (IllegalAccessException e2) {
            }
        }
    }

    protected static void a(Field field) {
        try {
            try {
                if (Modifier.isPublic(field.getModifiers()) && Modifier.isPublic(field.getDeclaringClass().getModifiers())) {
                    return;
                }
                field.setAccessible(true);
            } catch (IllegalArgumentException e) {
                throw e;
            }
        } catch (IllegalArgumentException e2) {
            throw e2;
        }
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '\"';
                    break;
                case 1:
                    c = 31;
                    break;
                case 2:
                    c = '!';
                    break;
                case nb.p /* 3 */:
                    c = 'M';
                    break;
                default:
                    c = '}';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '}');
        }
        return charArray;
    }
}
