package com.uucun.adsdk.a;

import android.content.BroadcastReceiver;
import android.text.TextUtils;
import com.uucun.adsdk.c.l;
import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b {
    private static final String a = b.class.getSimpleName();
    private static b b = null;
    private int c = 5;
    private ConcurrentLinkedQueue d = new ConcurrentLinkedQueue();
    private ConcurrentLinkedQueue e = new ConcurrentLinkedQueue();
    private ConcurrentLinkedQueue f = new ConcurrentLinkedQueue();
    private HashMap g;
    private ConcurrentLinkedQueue h;

    private b() {
        this.g = null;
        this.h = null;
        this.g = new HashMap();
        this.h = new ConcurrentLinkedQueue();
    }

    public static b a() {
        if (b == null) {
            b = new b();
        }
        return b;
    }

    private void c() {
        l lVar;
        if (this.e.size() < this.c && (lVar = (l) this.d.poll()) != null) {
            this.e.add(lVar);
            lVar.execute(new Void[0]);
        }
    }

    public void a(BroadcastReceiver broadcastReceiver) {
        this.h.add(broadcastReceiver);
    }

    public void a(l lVar) {
        this.d.add(lVar);
        this.f.add(lVar.c);
        lVar.b();
        c();
    }

    public void a(l lVar, boolean z) {
        this.e.remove(lVar);
        this.f.remove(lVar.c);
        if (lVar.b == null) {
            return;
        }
        if (z) {
            b(lVar.b);
        }
        c();
    }

    public boolean a(String str) {
        if (str == null || TextUtils.isEmpty(str.trim())) {
            return false;
        }
        return this.f.contains(str);
    }

    public void b() {
        this.h.clear();
        this.e.clear();
        this.f.clear();
        this.g.clear();
        this.d.clear();
    }

    public void b(BroadcastReceiver broadcastReceiver) {
        this.h.remove(broadcastReceiver);
    }

    public void b(String str) {
        this.g.put(str, str);
    }

    public void c(String str) {
        this.g.remove(str);
    }

    public boolean d(String str) {
        return this.g.containsKey(str);
    }
}
