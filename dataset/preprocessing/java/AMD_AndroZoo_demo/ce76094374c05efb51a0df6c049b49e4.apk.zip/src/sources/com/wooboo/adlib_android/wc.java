package com.wooboo.adlib_android;

import android.os.Message;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class wc extends Thread {
    final y a;
    private final String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public wc(y yVar, String str) {
        this.a = yVar;
        this.b = str;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        WoobooAdView.n = true;
        Message message = new Message();
        message.what = 1;
        message.obj = this.b;
        n.db.sendMessage(message);
    }
}
