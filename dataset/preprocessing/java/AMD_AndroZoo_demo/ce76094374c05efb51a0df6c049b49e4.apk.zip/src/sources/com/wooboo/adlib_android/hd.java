package com.wooboo.adlib_android;

import android.app.AlertDialog;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class hd extends Thread {
    private static final String[] z = {z(z("\b{T4\u000e\u0018^B9@")), z(z("乶欪冽计")), z(z("乶轶斀爝")), z(z("掭礱")), z(z("\u001anDu\u000f\roQ!\u001f(y\\u\u001c\u001cb\\0\u001e\\")), z(z("厬玻斀爝杖輒份\u001c乯逅儰宂裵奤赟ｱ诼典匭輇聼牃朜凘寳袸"))};

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '}';
                    break;
                case 1:
                    c = 11;
                    break;
                case 2:
                    c = '0';
                    break;
                case nb.p /* 3 */:
                    c = 'U';
                    break;
                default:
                    c = 'z';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'z');
        }
        return charArray;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        try {
            String h = sc.h(1);
            if (kb.c(h)) {
                return;
            }
            mc.b(z[0] + h);
            AlertDialog.Builder builder = new AlertDialog.Builder(HalfAdView.h());
            builder.setTitle(z[3]).setMessage(z[5]);
            builder.setPositiveButton(z[2], new zb(this, h));
            builder.setNegativeButton(z[1], new ac(this));
            Message message = new Message();
            message.what = 1;
            message.obj = builder;
            HalfAdView.p.sendMessage(message);
        } catch (Exception e) {
            mc.c(z[4]);
        }
    }
}
