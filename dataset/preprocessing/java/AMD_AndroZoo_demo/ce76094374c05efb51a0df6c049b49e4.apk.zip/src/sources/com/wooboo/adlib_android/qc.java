package com.wooboo.adlib_android;

import java.util.HashMap;
import java.util.Properties;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class qc {
    private static final String z = z(z("\u0010\u0015NS<\b%TP}\u0017\bNA6\u0015\u000eHT "));
    static Properties a = new Properties();
    static HashMap b = new HashMap();
    static qc c = null;

    private qc() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0070 A[Catch: all -> 0x000e, IOException -> 0x0076, TRY_LEAVE, TryCatch #0 {IOException -> 0x0076, blocks: (B:52:0x006b, B:47:0x0070), top: B:51:0x006b }] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x006b A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static synchronized com.wooboo.adlib_android.qc a(android.content.Context r6) {
        /*
            r2 = 0
            java.lang.Class<com.wooboo.adlib_android.qc> r4 = com.wooboo.adlib_android.qc.class
            monitor-enter(r4)
            com.wooboo.adlib_android.qc r0 = com.wooboo.adlib_android.qc.c     // Catch: java.io.IOException -> Lc java.lang.Throwable -> Le
            if (r0 == 0) goto L11
            com.wooboo.adlib_android.qc r0 = com.wooboo.adlib_android.qc.c     // Catch: java.io.IOException -> Lc java.lang.Throwable -> Le
        La:
            monitor-exit(r4)
            return r0
        Lc:
            r0 = move-exception
            throw r0     // Catch: java.lang.Throwable -> Le
        Le:
            r0 = move-exception
            monitor-exit(r4)
            throw r0
        L11:
            android.content.res.AssetManager r0 = r6.getAssets()     // Catch: java.lang.Throwable -> L66 java.io.IOException -> L80
            java.lang.String r1 = com.wooboo.adlib_android.qc.z     // Catch: java.lang.Throwable -> L66 java.io.IOException -> L80
            java.io.InputStream r1 = r0.open(r1)     // Catch: java.lang.Throwable -> L66 java.io.IOException -> L80
            java.io.BufferedReader r3 = new java.io.BufferedReader     // Catch: java.lang.Throwable -> L78 java.io.IOException -> L83
            java.io.InputStreamReader r0 = new java.io.InputStreamReader     // Catch: java.lang.Throwable -> L78 java.io.IOException -> L83
            r0.<init>(r1)     // Catch: java.lang.Throwable -> L78 java.io.IOException -> L83
            r3.<init>(r0)     // Catch: java.lang.Throwable -> L78 java.io.IOException -> L83
        L25:
            java.lang.String r0 = r3.readLine()     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            if (r0 != 0) goto L3f
            com.wooboo.adlib_android.qc r0 = new com.wooboo.adlib_android.qc     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            r0.<init>()     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            com.wooboo.adlib_android.qc.c = r0     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            if (r1 == 0) goto L37
            r1.close()     // Catch: java.lang.Throwable -> Le java.io.IOException -> L74
        L37:
            if (r3 == 0) goto L3c
            r3.close()     // Catch: java.lang.Throwable -> Le java.io.IOException -> L74
        L3c:
            com.wooboo.adlib_android.qc r0 = com.wooboo.adlib_android.qc.c     // Catch: java.lang.Throwable -> Le
            goto La
        L3f:
            java.util.StringTokenizer r2 = new java.util.StringTokenizer     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            java.lang.String r5 = "="
            r2.<init>(r0, r5)     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            java.util.HashMap r0 = com.wooboo.adlib_android.qc.b     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            java.lang.String r5 = r2.nextToken()     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            java.lang.String r2 = r2.nextToken()     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            r0.put(r5, r2)     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L7b
            goto L25
        L54:
            r0 = move-exception
            r2 = r3
        L56:
            r0.printStackTrace()     // Catch: java.lang.Throwable -> L7d
            if (r1 == 0) goto L5e
            r1.close()     // Catch: java.lang.Throwable -> Le java.io.IOException -> L64
        L5e:
            if (r2 == 0) goto L3c
            r2.close()     // Catch: java.lang.Throwable -> Le java.io.IOException -> L64
            goto L3c
        L64:
            r0 = move-exception
            goto L3c
        L66:
            r0 = move-exception
            r1 = r2
            r3 = r2
        L69:
            if (r1 == 0) goto L6e
            r1.close()     // Catch: java.lang.Throwable -> Le java.io.IOException -> L76
        L6e:
            if (r3 == 0) goto L73
            r3.close()     // Catch: java.lang.Throwable -> Le java.io.IOException -> L76
        L73:
            throw r0     // Catch: java.lang.Throwable -> Le
        L74:
            r0 = move-exception
            goto L3c
        L76:
            r1 = move-exception
            goto L73
        L78:
            r0 = move-exception
            r3 = r2
            goto L69
        L7b:
            r0 = move-exception
            goto L69
        L7d:
            r0 = move-exception
            r3 = r2
            goto L69
        L80:
            r0 = move-exception
            r1 = r2
            goto L56
        L83:
            r0 = move-exception
            goto L56
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.qc.a(android.content.Context):com.wooboo.adlib_android.qc");
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c3 = cArr[i];
            switch (i % 5) {
                case 0:
                    c2 = 'g';
                    break;
                case 1:
                    c2 = 'z';
                    break;
                case 2:
                    c2 = '!';
                    break;
                case nb.p /* 3 */:
                    c2 = '1';
                    break;
                default:
                    c2 = 'S';
                    break;
            }
            cArr[i] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'S');
        }
        return charArray;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x002e, code lost:
    
        return java.lang.Integer.parseInt(r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0033, code lost:
    
        if (r5.hasNext() != false) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:?, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:2:0x0011, code lost:
    
        if (r4 != false) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0013, code lost:
    
        r0 = (java.lang.String) r5.next();
        r1 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x001e, code lost:
    
        if (r1.indexOf(r0) == (-1)) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0020, code lost:
    
        r1 = (java.lang.String) com.wooboo.adlib_android.qc.b.get(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0028, code lost:
    
        if (r4 != false) goto L16;
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:12:0x0033 -> B:3:0x0013). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public int a(java.lang.String r7) {
        /*
            r6 = this;
            r3 = -1
            boolean r4 = com.wooboo.adlib_android.sc.C
            java.lang.String r2 = r7.toUpperCase()
            java.util.HashMap r0 = com.wooboo.adlib_android.qc.b
            java.util.Set r0 = r0.keySet()
            java.util.Iterator r5 = r0.iterator()
            if (r4 == 0) goto L2f
        L13:
            java.lang.Object r0 = r5.next()
            java.lang.String r0 = (java.lang.String) r0
            r1 = r2
        L1a:
            int r1 = r1.indexOf(r0)
            if (r1 == r3) goto L2f
            java.util.HashMap r1 = com.wooboo.adlib_android.qc.b
            java.lang.Object r1 = r1.get(r0)
            java.lang.String r1 = (java.lang.String) r1
            if (r4 != 0) goto L1a
            int r0 = java.lang.Integer.parseInt(r1)
        L2e:
            return r0
        L2f:
            boolean r0 = r5.hasNext()
            if (r0 != 0) goto L13
            r0 = r3
            goto L2e
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.qc.a(java.lang.String):int");
    }
}
