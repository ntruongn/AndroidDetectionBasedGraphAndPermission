package com.wooboo.adlib_android;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.SecretKeySpec;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class pb {
    public static DESKeySpec e;
    public static SecretKeySpec f;
    private static final String a = z(z("1\u0019\r"));
    private static final String d = z(z("Z8?|4Z8?|4Z5*{&[=0l'\u001a5:&6\u0007%.|:Z(,a%\u00199:m&[7;q"));
    private static final String b = z(z("1\u0019\rm1\u0010"));
    private static final String c = z(z("Z8?|4Z8?|4Z5*{&[=0l'\u001a5:&6\u0007%.|:Z8;{{\u001e9'"));
    private static final String[] z = {z(z("352mu990o!\u001df")), z(z("19<}2"))};

    public static File a(File file, String str, boolean z2) {
        File file2 = new File(str);
        if (!file2.exists()) {
            try {
                file2.createNewFile();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(fileInputStream.available());
            byte[] bArr = new byte[fileInputStream.available()];
            while (fileInputStream.read(bArr) != -1) {
                byte[] a2 = z2 ? a(bArr) : a(bArr, e);
                byteArrayOutputStream.write(a2, 0, a2.length);
            }
            fileInputStream.close();
            byteArrayOutputStream.close();
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
            bufferedOutputStream.write(byteArrayOutputStream.toByteArray());
            bufferedOutputStream.close();
            fileOutputStream.close();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        return file2;
    }

    public static final String a(String str, DESKeySpec dESKeySpec) {
        try {
            return rc.a(a(str.getBytes(), dESKeySpec));
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public static DESKeySpec a() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        byte[] bArr = new byte[8];
        File file = new File(c);
        try {
            if (file.exists()) {
                new FileInputStream(file).read(bArr);
            } else {
                KeyGenerator keyGenerator = KeyGenerator.getInstance(a);
                keyGenerator.init(56);
                bArr = keyGenerator.generateKey().getEncoded();
                new FileOutputStream(file).write(bArr);
            }
            return new DESKeySpec(bArr);
        } catch (IOException e2) {
            throw e2;
        }
    }

    public static DESKeySpec a(String str) throws NoSuchAlgorithmException, InvalidKeyException {
        return new DESKeySpec(str.getBytes());
    }

    public static byte[] a(byte[] bArr) throws Exception {
        Cipher cipher = Cipher.getInstance(b);
        cipher.init(1, f);
        return cipher.doFinal(bArr);
    }

    public static byte[] a(byte[] bArr, DESKeySpec dESKeySpec) throws Exception {
        SecureRandom secureRandom = new SecureRandom();
        SecretKey generateSecret = SecretKeyFactory.getInstance(a).generateSecret(dESKeySpec);
        Cipher cipher = Cipher.getInstance(a);
        cipher.init(1, generateSecret, secureRandom);
        return cipher.doFinal(bArr);
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0041, code lost:
    
        if (r1 != false) goto L7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0043, code lost:
    
        if (r10 == false) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0045, code lost:
    
        r0 = b(r5);
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0049, code lost:
    
        if (r1 == false) goto L11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0051, code lost:
    
        r4.write(r0, 0, r0.length);
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x004b, code lost:
    
        r0 = b(r5, com.wooboo.adlib_android.pb.e);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x005b, code lost:
    
        if (r3.read(r5) != (-1)) goto L7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x005d, code lost:
    
        r3.close();
        r4.close();
        r0 = new java.io.FileOutputStream(r2);
        r6 = new java.io.BufferedOutputStream(r0);
        r6.write(r4.toByteArray());
        r6.close();
        r0.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x007a, code lost:
    
        if (r1 != false) goto L10;
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:18:0x005b -> B:11:0x0043). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x007a -> B:16:0x004b). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.io.File b(java.io.File r8, java.lang.String r9, boolean r10) {
        /*
            boolean r1 = com.wooboo.adlib_android.sc.C
            java.io.File r2 = new java.io.File
            r2.<init>(r9)
            boolean r0 = r2.exists()
            if (r0 != 0) goto L10
            r2.createNewFile()     // Catch: java.lang.Exception -> L7d
        L10:
            java.io.FileInputStream r3 = new java.io.FileInputStream     // Catch: java.lang.Exception -> L82
            r3.<init>(r8)     // Catch: java.lang.Exception -> L82
            int r0 = r3.available()     // Catch: java.lang.Exception -> L82
            int r4 = r3.available()     // Catch: java.lang.Exception -> L82
            int r4 = r4 % 8
            int r0 = r0 - r4
            java.lang.String[] r4 = com.wooboo.adlib_android.pb.z     // Catch: java.lang.Exception -> L82
            r5 = 1
            r4 = r4[r5]     // Catch: java.lang.Exception -> L82
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L82
            java.lang.String[] r6 = com.wooboo.adlib_android.pb.z     // Catch: java.lang.Exception -> L82
            r7 = 0
            r6 = r6[r7]     // Catch: java.lang.Exception -> L82
            r5.<init>(r6)     // Catch: java.lang.Exception -> L82
            java.lang.StringBuilder r5 = r5.append(r0)     // Catch: java.lang.Exception -> L82
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Exception -> L82
            android.util.Log.i(r4, r5)     // Catch: java.lang.Exception -> L82
            java.io.ByteArrayOutputStream r4 = new java.io.ByteArrayOutputStream     // Catch: java.lang.Exception -> L82
            r4.<init>(r0)     // Catch: java.lang.Exception -> L82
            byte[] r5 = new byte[r0]     // Catch: java.lang.Exception -> L82
            if (r1 == 0) goto L56
        L43:
            if (r10 == 0) goto L4b
            byte[] r0 = b(r5)     // Catch: java.lang.Exception -> L82
            if (r1 == 0) goto L51
        L4b:
            javax.crypto.spec.DESKeySpec r0 = com.wooboo.adlib_android.pb.e     // Catch: java.lang.Exception -> L82
            byte[] r0 = b(r5, r0)     // Catch: java.lang.Exception -> L82
        L51:
            r6 = 0
            int r7 = r0.length     // Catch: java.lang.Exception -> L82
            r4.write(r0, r6, r7)     // Catch: java.lang.Exception -> L82
        L56:
            int r0 = r3.read(r5)     // Catch: java.lang.Exception -> L82
            r6 = -1
            if (r0 != r6) goto L43
            r3.close()     // Catch: java.lang.Exception -> L82
            r4.close()     // Catch: java.lang.Exception -> L82
            java.io.FileOutputStream r0 = new java.io.FileOutputStream     // Catch: java.lang.Exception -> L82
            r0.<init>(r2)     // Catch: java.lang.Exception -> L82
            java.io.BufferedOutputStream r6 = new java.io.BufferedOutputStream     // Catch: java.lang.Exception -> L82
            r6.<init>(r0)     // Catch: java.lang.Exception -> L82
            byte[] r7 = r4.toByteArray()     // Catch: java.lang.Exception -> L82
            r6.write(r7)     // Catch: java.lang.Exception -> L82
            r6.close()     // Catch: java.lang.Exception -> L82
            r0.close()     // Catch: java.lang.Exception -> L82
            if (r1 != 0) goto L4b
        L7c:
            return r2
        L7d:
            r0 = move-exception
            r0.printStackTrace()
            goto L10
        L82:
            r0 = move-exception
            r0.printStackTrace()
            goto L7c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.pb.b(java.io.File, java.lang.String, boolean):java.io.File");
    }

    public static final String b(String str, DESKeySpec dESKeySpec) {
        try {
            return new String(b(rc.b(str.getBytes()), dESKeySpec));
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public static DESKeySpec b(String str) throws NoSuchAlgorithmException, InvalidKeyException {
        return new DESKeySpec(rc.b(str.getBytes()));
    }

    public static SecretKeySpec b() throws IOException, NoSuchAlgorithmException {
        byte[] bArr = new byte[24];
        File file = new File(d);
        try {
            if (file.exists()) {
                new FileInputStream(file).read(bArr);
            } else {
                KeyGenerator keyGenerator = KeyGenerator.getInstance(b);
                keyGenerator.init(168);
                bArr = keyGenerator.generateKey().getEncoded();
                new FileOutputStream(file).write(bArr);
            }
            return new SecretKeySpec(bArr, b);
        } catch (IOException e2) {
            throw e2;
        }
    }

    public static byte[] b(byte[] bArr) throws Exception {
        Cipher cipher = Cipher.getInstance(b);
        cipher.init(2, f);
        return cipher.doFinal(bArr);
    }

    public static byte[] b(byte[] bArr, DESKeySpec dESKeySpec) throws Exception {
        SecureRandom secureRandom = new SecureRandom();
        SecretKey generateSecret = SecretKeyFactory.getInstance(a).generateSecret(dESKeySpec);
        Cipher cipher = Cipher.getInstance(a);
        cipher.init(2, generateSecret, secureRandom);
        return cipher.doFinal(bArr);
    }

    public static String c() {
        return rc.a(e.getKey());
    }

    public static DESKeySpec c(String str) throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        return new DESKeySpec(new String(rc.b(str.getBytes())).getBytes());
    }

    public static String d() {
        return rc.a(f.getEncoded());
    }

    public static SecretKeySpec d(String str) throws NoSuchAlgorithmException {
        return new SecretKeySpec(rc.b(str.getBytes()), b);
    }

    public static SecretKeySpec e(String str) throws NoSuchAlgorithmException {
        return new SecretKeySpec(str.getBytes(), b);
    }

    public static final String f(String str) {
        try {
            return rc.a(a(str.getBytes()));
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public static final String g(String str) {
        try {
            return new String(b(rc.b(str.getBytes())));
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c3 = cArr[i];
            switch (i % 5) {
                case 0:
                    c2 = 'u';
                    break;
                case 1:
                    c2 = '\\';
                    break;
                case 2:
                    c2 = '^';
                    break;
                case nb.p /* 3 */:
                    c2 = '\b';
                    break;
                default:
                    c2 = 'U';
                    break;
            }
            cArr[i] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'U');
        }
        return charArray;
    }
}
