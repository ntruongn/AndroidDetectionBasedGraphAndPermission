package com.uucun.adsdk.b;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class h {
    public static boolean a = true;
    public static boolean b = true;
    public static boolean c = true;
    public static boolean d = true;
    private static int f = 8192;
    private static StringBuffer g = new StringBuffer();
    public static Context e = null;

    public static float a(long j) {
        return ((float) (System.currentTimeMillis() - j)) / 1000.0f;
    }

    public static String a(Date date, String str) {
        if (date == null) {
            return null;
        }
        try {
            return new SimpleDateFormat(str).format(date);
        } catch (Exception e2) {
            return null;
        }
    }

    public static void a() {
        new e().start();
    }

    public static void a(String str, String str2) {
        if (d) {
            a("E", str, str2);
        }
        if (c) {
            Log.e(str, str2);
        }
    }

    private static void a(String str, String str2, String str3) {
        StringBuffer stringBuffer = new StringBuffer();
        StackTraceElement[] stackTrace = new Throwable().getStackTrace();
        if (stackTrace == null || stackTrace.length < 3) {
            return;
        }
        stringBuffer.append(str).append("|").append(a(new Date(), "yyyy-MM-dd HH:mm:ss")).append("|").append(stackTrace[2].getClassName()).append("|").append(stackTrace[2].getMethodName()).append("|").append(stackTrace[2].getLineNumber());
        g.append(stringBuffer.toString()).append("|").append(str3).append("\n");
        if (g.length() < f || e == null) {
            return;
        }
        new f().start();
    }

    public static void a(boolean z) {
        c = z;
        b = z;
        a = z;
        d = z;
        if (new File(Environment.getExternalStorageDirectory(), "wb.l").exists()) {
            c = true;
            b = true;
            a = true;
            d = true;
        }
    }

    public static void b(String str, String str2) {
        if (d) {
            a("I", str, str2);
        }
        if (b) {
            Log.i(str, str2);
        }
    }

    public static void c(String str, String str2) {
        if (d) {
            a("W", str, str2);
        }
        if (a) {
            Log.w(str, str2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x0011, code lost:
    
        if (com.uucun.adsdk.b.h.e != null) goto L11;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static synchronized void c(boolean r6) {
        /*
            java.lang.Class<com.uucun.adsdk.b.h> r3 = com.uucun.adsdk.b.h.class
            monitor-enter(r3)
            if (r6 != 0) goto L15
            java.lang.StringBuffer r0 = com.uucun.adsdk.b.h.g     // Catch: java.lang.Throwable -> La4
            int r0 = r0.length()     // Catch: java.lang.Throwable -> La4
            int r1 = com.uucun.adsdk.b.h.f     // Catch: java.lang.Throwable -> La4
            if (r0 < r1) goto L13
            android.content.Context r0 = com.uucun.adsdk.b.h.e     // Catch: java.lang.Throwable -> La4
            if (r0 != 0) goto L15
        L13:
            monitor-exit(r3)
            return
        L15:
            java.lang.String r0 = android.os.Environment.getExternalStorageState()     // Catch: java.lang.Throwable -> La4
            java.lang.String r1 = "mounted"
            boolean r0 = r0.equals(r1)     // Catch: java.lang.Throwable -> La4
            if (r0 == 0) goto L13
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> La4
            r0.<init>()     // Catch: java.lang.Throwable -> La4
            java.util.Date r1 = new java.util.Date     // Catch: java.lang.Throwable -> La4
            r1.<init>()     // Catch: java.lang.Throwable -> La4
            java.lang.String r2 = "yyyy-MM-dd"
            java.lang.String r1 = a(r1, r2)     // Catch: java.lang.Throwable -> La4
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch: java.lang.Throwable -> La4
            java.lang.String r1 = ".log"
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch: java.lang.Throwable -> La4
            java.lang.String r0 = r0.toString()     // Catch: java.lang.Throwable -> La4
            java.io.File r1 = new java.io.File     // Catch: java.lang.Throwable -> La4
            java.io.File r2 = android.os.Environment.getExternalStorageDirectory()     // Catch: java.lang.Throwable -> La4
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> La4
            r4.<init>()     // Catch: java.lang.Throwable -> La4
            android.content.Context r5 = com.uucun.adsdk.b.h.e     // Catch: java.lang.Throwable -> La4
            java.lang.String r5 = r5.getPackageName()     // Catch: java.lang.Throwable -> La4
            java.lang.StringBuilder r4 = r4.append(r5)     // Catch: java.lang.Throwable -> La4
            java.lang.String r5 = "/logs/"
            java.lang.StringBuilder r4 = r4.append(r5)     // Catch: java.lang.Throwable -> La4
            java.lang.String r4 = r4.toString()     // Catch: java.lang.Throwable -> La4
            r1.<init>(r2, r4)     // Catch: java.lang.Throwable -> La4
            java.io.File r4 = new java.io.File     // Catch: java.lang.Throwable -> La4
            r4.<init>(r1, r0)     // Catch: java.lang.Throwable -> La4
            boolean r0 = r1.exists()     // Catch: java.lang.Throwable -> La4
            if (r0 != 0) goto L6f
            r1.mkdirs()     // Catch: java.lang.Throwable -> La4
        L6f:
            java.lang.StringBuffer r0 = com.uucun.adsdk.b.h.g     // Catch: java.lang.Throwable -> La4
            java.lang.String r0 = r0.toString()     // Catch: java.lang.Throwable -> La4
            java.lang.StringBuffer r1 = com.uucun.adsdk.b.h.g     // Catch: java.lang.Throwable -> La4
            r2 = 0
            java.lang.StringBuffer r5 = com.uucun.adsdk.b.h.g     // Catch: java.lang.Throwable -> La4
            int r5 = r5.length()     // Catch: java.lang.Throwable -> La4
            r1.delete(r2, r5)     // Catch: java.lang.Throwable -> La4
            r1 = 0
            boolean r2 = r4.exists()     // Catch: java.lang.Exception -> La7 java.lang.Throwable -> Lb8
            if (r2 != 0) goto L8b
            r4.createNewFile()     // Catch: java.lang.Exception -> La7 java.lang.Throwable -> Lb8
        L8b:
            java.io.FileWriter r2 = new java.io.FileWriter     // Catch: java.lang.Exception -> La7 java.lang.Throwable -> Lb8
            r5 = 1
            r2.<init>(r4, r5)     // Catch: java.lang.Exception -> La7 java.lang.Throwable -> Lb8
            r2.write(r0)     // Catch: java.lang.Throwable -> Lc4 java.lang.Exception -> Lc7
            r2.flush()     // Catch: java.lang.Throwable -> Lc4 java.lang.Exception -> Lc7
            if (r2 == 0) goto L13
            r2.close()     // Catch: java.io.IOException -> L9e java.lang.Throwable -> La4
            goto L13
        L9e:
            r0 = move-exception
            r0.printStackTrace()     // Catch: java.lang.Throwable -> La4
            goto L13
        La4:
            r0 = move-exception
            monitor-exit(r3)
            throw r0
        La7:
            r0 = move-exception
        La8:
            r0.printStackTrace()     // Catch: java.lang.Throwable -> Lb8
            if (r1 == 0) goto L13
            r1.close()     // Catch: java.lang.Throwable -> La4 java.io.IOException -> Lb2
            goto L13
        Lb2:
            r0 = move-exception
            r0.printStackTrace()     // Catch: java.lang.Throwable -> La4
            goto L13
        Lb8:
            r0 = move-exception
        Lb9:
            if (r1 == 0) goto Lbe
            r1.close()     // Catch: java.lang.Throwable -> La4 java.io.IOException -> Lbf
        Lbe:
            throw r0     // Catch: java.lang.Throwable -> La4
        Lbf:
            r1 = move-exception
            r1.printStackTrace()     // Catch: java.lang.Throwable -> La4
            goto Lbe
        Lc4:
            r0 = move-exception
            r1 = r2
            goto Lb9
        Lc7:
            r0 = move-exception
            r1 = r2
            goto La8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.uucun.adsdk.b.h.c(boolean):void");
    }
}
