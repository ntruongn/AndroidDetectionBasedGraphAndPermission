package com.kuguo.pushads;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import com.mobclick.android.UmengConstants;
import com.wooboo.adlib_android.nb;
import java.util.Calendar;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class e {
    private static e b;
    private Context a;
    private Handler c = new i(this);

    private e(Context context) {
        this.a = context;
    }

    public static e a(Context context) {
        if (b == null) {
            b = new e(context);
        }
        return b;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(Context context, j jVar) {
        switch (jVar.e) {
            case 1:
            case 2:
            case 5:
            case nb.t /* 7 */:
            case 8:
                a.a(context, b(context, jVar), 17301586, jVar, jVar.t == 1 ? 32 : a.a, true, false);
                return;
            case nb.p /* 3 */:
            case 4:
            case nb.s /* 6 */:
                PushAdsActivity.a(context, jVar);
                return;
            default:
                return;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static Intent b(Context context, j jVar) {
        Intent intent = new Intent(context, (Class<?>) PushAdsActivity.class);
        intent.setFlags(268435456);
        intent.putExtra("message", jVar.a());
        intent.putExtra("sharedid", jVar.f);
        intent.putExtra("shortcut", false);
        return intent;
    }

    private void c(j jVar) {
        Intent intent = new Intent(this.a, (Class<?>) AdsReceiver.class);
        intent.setExtrasClassLoader(jVar.getClass().getClassLoader());
        intent.putExtra(UmengConstants.AtomKey_Type, "AdAlarm");
        intent.putExtra("sharedid", jVar.f);
        intent.putExtra("message", jVar.a());
        PendingIntent broadcast = PendingIntent.getBroadcast(this.a, jVar.h, intent, 134217728);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(jVar.c);
        ((AlarmManager) this.a.getSystemService("alarm")).set(0, calendar.getTimeInMillis(), broadcast);
        a.a("have set the alarm!");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a() {
        a(a.d(this.a));
    }

    protected void a(j jVar) {
        if ("WIFI".equalsIgnoreCase(h.d(this.a)) && jVar.r == 1) {
            if (jVar.e == 1 || jVar.e == 3) {
                com.kuguo.a.d dVar = new com.kuguo.a.d(jVar.d + "&networkInfo=" + h.d(this.a), a.b(this.a, jVar.i + ".apk", jVar.h));
                dVar.a((Object) (-3));
                h.a(this.a, dVar, null);
            }
            String[] a = a.a(jVar.p, ";");
            if (a != null) {
                int length = a.length;
                for (int i = 0; i < length; i++) {
                    com.kuguo.a.d dVar2 = new com.kuguo.a.d(a[i], a.b(this.a, i + ".png", jVar.h));
                    dVar2.a((Object) (-3));
                    h.a(this.a, dVar2, null);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Removed duplicated region for block: B:54:0x002b  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0030  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void a(java.io.InputStream r8) {
        /*
            r7 = this;
            r2 = 0
            r0 = 0
            java.io.ByteArrayOutputStream r1 = new java.io.ByteArrayOutputStream     // Catch: java.lang.Throwable -> L74 java.io.IOException -> L7d
            r1.<init>()     // Catch: java.lang.Throwable -> L74 java.io.IOException -> L7d
            java.io.DataInputStream r3 = new java.io.DataInputStream     // Catch: java.lang.Throwable -> L78 java.io.IOException -> L80
            r3.<init>(r8)     // Catch: java.lang.Throwable -> L78 java.io.IOException -> L80
            r2 = 512(0x200, float:7.175E-43)
            byte[] r2 = new byte[r2]     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
        L10:
            int r4 = r3.read(r2)     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            r5 = -1
            if (r4 == r5) goto L34
            r5 = 0
            r1.write(r2, r5, r4)     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            r1.flush()     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            goto L10
        L1f:
            r0 = move-exception
            r2 = r3
        L21:
            java.lang.Exception r3 = new java.lang.Exception     // Catch: java.lang.Throwable -> L27
            r3.<init>(r0)     // Catch: java.lang.Throwable -> L27
            throw r3     // Catch: java.lang.Throwable -> L27
        L27:
            r0 = move-exception
            r3 = r2
        L29:
            if (r1 == 0) goto L2e
            r1.close()
        L2e:
            if (r3 == 0) goto L33
            r3.close()
        L33:
            throw r0
        L34:
            byte[] r2 = r1.toByteArray()     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            if (r2 == 0) goto L3d
            int r4 = r2.length     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            if (r4 != 0) goto L48
        L3d:
            if (r1 == 0) goto L42
            r1.close()
        L42:
            if (r3 == 0) goto L47
            r3.close()
        L47:
            return
        L48:
            com.kuguo.pushads.j[] r2 = com.kuguo.pushads.j.a(r2)     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            if (r2 != 0) goto L59
            if (r1 == 0) goto L53
            r1.close()
        L53:
            if (r3 == 0) goto L47
            r3.close()
            goto L47
        L59:
            int r4 = r2.length     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
        L5a:
            if (r0 >= r4) goto L66
            r5 = r2[r0]     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            android.content.Context r6 = r7.a     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            com.kuguo.pushads.a.a(r6, r5)     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            int r0 = r0 + 1
            goto L5a
        L66:
            r7.a(r2)     // Catch: java.io.IOException -> L1f java.lang.Throwable -> L7b
            if (r1 == 0) goto L6e
            r1.close()
        L6e:
            if (r3 == 0) goto L47
            r3.close()
            goto L47
        L74:
            r0 = move-exception
            r1 = r2
            r3 = r2
            goto L29
        L78:
            r0 = move-exception
            r3 = r2
            goto L29
        L7b:
            r0 = move-exception
            goto L29
        L7d:
            r0 = move-exception
            r1 = r2
            goto L21
        L80:
            r0 = move-exception
            goto L21
        */
        throw new UnsupportedOperationException("Method not decompiled: com.kuguo.pushads.e.a(java.io.InputStream):void");
    }

    protected void a(j... jVarArr) {
        if (jVarArr == null) {
            return;
        }
        com.kuguo.a.f.a(this.a);
        for (j jVar : jVarArr) {
            jVar.b();
            if ((!a.b(this.a, jVar.i) || jVar.y == 1) && jVar.j.intValue() == -1) {
                c(jVar);
                if (jVar.e != 0 && jVar.o != null) {
                    com.kuguo.a.d dVar = new com.kuguo.a.d(jVar.o, a.b(this.a, "icon.png", jVar.h));
                    dVar.a((Object) (-3));
                    h.a(this.a, dVar, null);
                    a(jVar);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void b(j jVar) {
        Message message = new Message();
        message.obj = jVar;
        this.c.sendMessage(message);
    }
}
