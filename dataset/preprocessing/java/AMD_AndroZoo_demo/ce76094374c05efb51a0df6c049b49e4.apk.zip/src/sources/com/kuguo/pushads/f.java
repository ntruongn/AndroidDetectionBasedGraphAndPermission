package com.kuguo.pushads;

import android.content.Context;
import android.content.Intent;
import java.util.TimerTask;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class f extends TimerTask {
    final /* synthetic */ Context a;
    final /* synthetic */ String b;
    final /* synthetic */ AdsReceiver c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(AdsReceiver adsReceiver, Context context, String str) {
        this.c = adsReceiver;
        this.a = context;
        this.b = str;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        j a = a.a(this.a, this.b);
        if (a != null) {
            Intent intent = new Intent();
            intent.putExtra("requestMode", 10);
            AdsReceiver.a(this.a, intent);
            a.j = 3;
            a.b(this.a, a);
            a.a(this.a, this.b + ".apk", a.h, true);
            a.a(a.h);
            Intent d = a.d(this.a, this.b);
            Context context = this.a;
            int i = a.h;
            if (d == null) {
                d = new Intent();
            }
            h.a(context, 17301556, "安装完成", i, 16, d, a.g, -1);
        }
    }
}
