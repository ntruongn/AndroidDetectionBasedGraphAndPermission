package com.feedback.a;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class d implements Comparable {
    public e b;
    public String c;
    public a d;
    public a e;
    public String a = d.class.getSimpleName();
    public List f = new ArrayList();

    public d(JSONArray jSONArray) {
        this.b = e.Normal;
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                a aVar = new a(jSONArray.getJSONObject(i));
                if (aVar.g == b.Fail) {
                    this.b = e.HasFail;
                }
                this.f.add(aVar);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        if (this.f.isEmpty()) {
            return;
        }
        this.d = (a) this.f.get(0);
        this.e = (a) this.f.get(this.f.size() - 1);
        this.c = this.d.c;
        if (this.f.size() == 1) {
            if (((a) this.f.get(0)).g == b.Fail) {
                this.b = e.PureFail;
            } else if (((a) this.f.get(0)).g == b.Sending) {
                this.b = e.PureSending;
            }
        }
    }

    @Override // java.lang.Comparable
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public int compareTo(d dVar) {
        Date date = this.e.e;
        Date date2 = dVar.e.e;
        if (date2 == null || date == null || date.equals(date2)) {
            return 0;
        }
        return date.after(date2) ? -1 : 1;
    }

    public a a(int i) {
        if (i < 0 || i > this.f.size() - 1) {
            return null;
        }
        return (a) this.f.get(i);
    }

    public void b(int i) {
        if (i < 0 || i > this.f.size() - 1) {
            return;
        }
        this.f.remove(i);
    }
}
