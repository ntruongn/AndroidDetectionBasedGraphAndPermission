package com.wooboo.adlib_android;

import java.io.IOException;
import java.io.Writer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class jc {
    private static final int a = 200;
    private static final String[] z = {z(z("f\u0002p]")), z(z("t\u0011iK\u0002")), z(z("\\\u0015vL\u000e|\u0017%]\u0015`\u001fw\u0016")), z(z("_\u0019vH\u000bs\u0013`\\G}\u0012o]\u0004f^")), z(z("\\\u0005iTGy\u0015|\u0016")), z(z("_\u0019vH\u000bs\u0013`\\Gy\u0015|\u0016")), z(z("_\u0019vH\u000bs\u0013`\\Gs\u0002wY\u001e<")), z(z("_\u0019vH\u000bs\u0013`\\Gw\u001eay\u0015`\u0011|\u0016")), z(z("_\u0019vH\u000bs\u0013`\\Gw\u001eaw\u0005x\u0015fLI")), z(z("\\\u0005iTGb\u001flV\u0013w\u0002")), z(z("D\u0011iM\u00022\u001fpLG}\u0016%K\u0002c\u0005`V\u0004w^")), z(z("\\\u0015vL\u000e|\u0017%L\b}Pa]\u0002b^"))};
    private boolean b = false;
    protected char c = 'i';
    private final fc[] d = new fc[a];
    private int e = 0;
    protected Writer f;

    public jc(Writer writer) {
        this.f = writer;
    }

    private jc a(char c, char c2) throws o {
        try {
            try {
                if (this.c != c) {
                    throw new o(c == 'a' ? z[7] : z[8]);
                }
                a(c);
                try {
                    this.f.write(c2);
                    this.b = true;
                    return this;
                } catch (IOException e) {
                    throw new o(e);
                }
            } catch (IOException e2) {
                throw e2;
            }
        } catch (IOException e3) {
            throw e3;
        }
    }

    private jc a(String str) throws o {
        if (str == null) {
            try {
                throw new o(z[9]);
            } catch (IOException e) {
                throw e;
            }
        }
        try {
            if (this.c != 'o') {
                if (this.c != 'a') {
                    throw new o(z[10]);
                }
            }
            try {
                if (this.b) {
                    try {
                        if (this.c == 'a') {
                            this.f.write(44);
                        }
                    } catch (IOException e2) {
                        throw e2;
                    }
                }
                this.f.write(str);
                try {
                    if (this.c == 'o') {
                        this.c = 'k';
                    }
                    this.b = true;
                    return this;
                } catch (IOException e3) {
                    throw e3;
                }
            } catch (IOException e4) {
                throw new o(e4);
            }
        } catch (IOException e5) {
            throw e5;
        }
    }

    private void a(char c) throws o {
        char c2 = 'a';
        try {
            if (this.e <= 0) {
                throw new o(z[2]);
            }
            try {
                if ((this.d[this.e + (-1)] == null ? 'a' : 'k') != c) {
                    try {
                        throw new o(z[2]);
                    } catch (o e) {
                        throw e;
                    }
                }
                try {
                    this.e--;
                    if (this.e == 0) {
                        c2 = 'd';
                    } else {
                        try {
                            if (this.d[this.e - 1] != null) {
                                c2 = 'k';
                            }
                        } catch (o e2) {
                            throw e2;
                        }
                    }
                    this.c = c2;
                } catch (o e3) {
                    throw e3;
                }
            } catch (o e4) {
                throw e4;
            }
        } catch (o e5) {
            throw e5;
        }
    }

    private void a(fc fcVar) throws o {
        try {
            if (this.e >= a) {
                throw new o(z[11]);
            }
            try {
                this.d[this.e] = fcVar;
                this.c = fcVar == null ? 'a' : 'k';
                this.e++;
            } catch (o e) {
                throw e;
            }
        } catch (o e2) {
            throw e2;
        }
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 18;
                    break;
                case 1:
                    c = 'p';
                    break;
                case 2:
                    c = 5;
                    break;
                case nb.p /* 3 */:
                    c = '8';
                    break;
                default:
                    c = 'g';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'g');
        }
        return charArray;
    }

    public jc a() throws o {
        try {
            try {
                try {
                    if (this.c != 'i' && this.c != 'o' && this.c != 'a') {
                        throw new o(z[6]);
                    }
                    a((fc) null);
                    a("[");
                    this.b = false;
                    return this;
                } catch (o e) {
                    throw e;
                }
            } catch (o e2) {
                throw e2;
            }
        } catch (o e3) {
            throw e3;
        }
    }

    public jc a(double d) throws o {
        return a(new Double(d));
    }

    public jc a(long j) throws o {
        return a(Long.toString(j));
    }

    public jc a(Object obj) throws o {
        return a(fc.d(obj));
    }

    public jc a(boolean z2) throws o {
        String str;
        if (z2) {
            try {
                str = z[0];
            } catch (o e) {
                throw e;
            }
        } else {
            str = z[1];
        }
        return a(str);
    }

    public jc b() throws o {
        return a('a', ']');
    }

    public jc b(String str) throws o {
        if (str == null) {
            try {
                throw new o(z[4]);
            } catch (IOException e) {
                throw e;
            }
        }
        if (this.c != 'k') {
            throw new o(z[5]);
        }
        try {
            this.d[this.e - 1].d(str, Boolean.TRUE);
            if (this.b) {
                this.f.write(44);
            }
            this.f.write(fc.t(str));
            this.f.write(58);
            this.b = false;
            this.c = 'o';
            return this;
        } catch (IOException e2) {
            throw new o(e2);
        }
    }

    public jc c() throws o {
        return a('k', '}');
    }

    public jc d() throws o {
        try {
            if (this.c == 'i') {
                this.c = 'o';
            }
            try {
                try {
                    if (this.c != 'o' && this.c != 'a') {
                        throw new o(z[3]);
                    }
                    a("{");
                    a(new fc());
                    this.b = false;
                    return this;
                } catch (o e) {
                    throw e;
                }
            } catch (o e2) {
                throw e2;
            }
        } catch (o e3) {
            throw e3;
        }
    }
}
