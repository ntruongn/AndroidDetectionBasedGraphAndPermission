package com.kuguo.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.widget.ImageView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b extends ImageView {
    final /* synthetic */ FoldView a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(FoldView foldView, Context context) {
        super(context);
        this.a = foldView;
    }

    @Override // android.widget.ImageView, android.view.View
    public void onDraw(Canvas canvas) {
        canvas.save();
        if (getDrawable() != null) {
            canvas.translate((getWidth() - r0.getIntrinsicWidth()) / 2, (getHeight() - r0.getIntrinsicHeight()) / 2);
        }
        super.onDraw(canvas);
        canvas.restore();
    }
}
