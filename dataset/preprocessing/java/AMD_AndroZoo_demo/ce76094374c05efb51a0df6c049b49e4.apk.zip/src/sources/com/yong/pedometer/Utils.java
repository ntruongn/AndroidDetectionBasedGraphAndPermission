package com.yong.pedometer;

import android.app.Service;
import android.speech.tts.TextToSpeech;
import android.text.format.Time;
import android.util.Log;
import java.util.Locale;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class Utils implements TextToSpeech.OnInitListener {
    private static final String TAG = "Utils";
    private static Utils instance = null;
    private Service mService;
    private boolean mSpeak = false;
    private boolean mSpeakingEngineAvailable = false;
    private TextToSpeech mTts;

    private Utils() {
    }

    public static Utils getInstance() {
        if (instance == null) {
            instance = new Utils();
        }
        return instance;
    }

    public void setService(Service service) {
        this.mService = service;
    }

    public void initTTS() {
        Log.i(TAG, "Initializing TextToSpeech...");
        this.mTts = new TextToSpeech(this.mService, this);
    }

    public void shutdownTTS() {
        Log.i(TAG, "Shutting Down TextToSpeech...");
        this.mSpeakingEngineAvailable = false;
        this.mTts.shutdown();
        Log.i(TAG, "TextToSpeech Shut Down.");
    }

    public void say(String text) {
        if (this.mSpeak && this.mSpeakingEngineAvailable) {
            this.mTts.speak(text, 1, null);
        }
    }

    @Override // android.speech.tts.TextToSpeech.OnInitListener
    public void onInit(int status) {
        if (status == 0) {
            int result = this.mTts.setLanguage(Locale.US);
            if (result == -1 || result == -2) {
                Log.e(TAG, "Language is not available.");
                return;
            } else {
                Log.i(TAG, "TextToSpeech Initialized.");
                this.mSpeakingEngineAvailable = true;
                return;
            }
        }
        Log.e(TAG, "Could not initialize TextToSpeech.");
    }

    public void setSpeak(boolean speak) {
        this.mSpeak = speak;
    }

    public boolean isSpeakingEnabled() {
        return this.mSpeak;
    }

    public boolean isSpeakingNow() {
        return this.mTts.isSpeaking();
    }

    public void ding() {
    }

    public static long currentTimeInMillis() {
        Time time = new Time();
        time.setToNow();
        return time.toMillis(false);
    }
}
