package com.wooboo.adlib_android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.View;
import java.io.InputStream;
import java.lang.Thread;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class i extends View implements Runnable {
    private static final String[] z = {z(z("jG_Im5\r\fZe!")), z(z("jG_Ic7YKTj")), z(z("%\u0014N\u00102"))};
    private Bitmap a;
    private wb b;
    int c;
    private int d;
    private float e;
    volatile int f;
    Thread g;
    private Paint h;
    private Bitmap i;
    private Matrix j;
    volatile boolean k;

    public i(Context context, InputStream inputStream, float f) {
        super(context);
        this.g = null;
        this.h = new Paint();
        this.k = true;
        this.e = f;
        this.b = new wb();
        this.b.a(inputStream);
        this.c = 0;
        this.d = this.b.b();
        this.a = this.b.c(0);
        mc.c(z[2] + this.a);
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'G';
                    break;
                case 1:
                    c = 'y';
                    break;
                case 2:
                    c = ',';
                    break;
                case nb.p /* 3 */:
                    c = '=';
                    break;
                default:
                    c = '\f';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '\f');
        }
        return charArray;
    }

    public void a() {
        try {
            b();
            if (this.a != null) {
                try {
                    this.k = true;
                    if (this.g == null) {
                        this.g = new Thread(this);
                        this.g.start();
                    }
                    mc.c(z[0]);
                } catch (Exception e) {
                    throw e;
                }
            }
        } catch (Exception e2) {
        }
    }

    public void b() {
        try {
            this.k = false;
            if (this.g != null) {
                try {
                    if (this.g.getState() == Thread.State.RUNNABLE) {
                        this.g.stop();
                        this.g = null;
                    }
                } catch (Exception e) {
                    throw e;
                }
            }
            mc.c(z[1]);
        } catch (Exception e2) {
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0050, code lost:
    
        if (com.wooboo.adlib_android.sc.C != false) goto L13;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void onDraw(android.graphics.Canvas r8) {
        /*
            r7 = this;
            android.graphics.Bitmap r0 = r7.a     // Catch: java.lang.Exception -> L6c
            if (r0 == 0) goto L69
            android.graphics.Matrix r0 = new android.graphics.Matrix     // Catch: java.lang.Exception -> L6c
            r0.<init>()     // Catch: java.lang.Exception -> L6c
            r7.j = r0     // Catch: java.lang.Exception -> L6c
            android.graphics.Matrix r0 = r7.j     // Catch: java.lang.Exception -> L6c
            float r1 = r7.e     // Catch: java.lang.Exception -> L6c
            float r2 = r7.e     // Catch: java.lang.Exception -> L6c
            r0.postScale(r1, r2)     // Catch: java.lang.Exception -> L6c
            android.graphics.Bitmap r0 = r7.a     // Catch: java.lang.Exception -> L6c
            int r3 = r0.getWidth()     // Catch: java.lang.Exception -> L6c
            android.graphics.Bitmap r0 = r7.a     // Catch: java.lang.Exception -> L6c
            int r4 = r0.getHeight()     // Catch: java.lang.Exception -> L6c
            android.graphics.Bitmap r0 = r7.i     // Catch: java.lang.Exception -> L6a
            if (r0 == 0) goto L27
            r0 = 0
            r7.i = r0     // Catch: java.lang.Exception -> L6a
        L27:
            android.graphics.Bitmap r0 = r7.a     // Catch: java.lang.Exception -> L71
            r1 = 0
            r2 = 0
            android.graphics.Matrix r5 = r7.j     // Catch: java.lang.Exception -> L71
            r6 = 1
            android.graphics.Bitmap r0 = android.graphics.Bitmap.createBitmap(r0, r1, r2, r3, r4, r5, r6)     // Catch: java.lang.Exception -> L71
            r7.i = r0     // Catch: java.lang.Exception -> L71
            android.graphics.Bitmap r0 = r7.i     // Catch: java.lang.Exception -> L71
            r1 = 0
            r2 = 0
            android.graphics.Paint r3 = r7.h     // Catch: java.lang.Exception -> L71
            r8.drawBitmap(r0, r1, r2, r3)     // Catch: java.lang.Exception -> L71
            com.wooboo.adlib_android.wb r0 = r7.b     // Catch: java.lang.Exception -> L71
            android.graphics.Bitmap r0 = r0.f()     // Catch: java.lang.Exception -> L71
            r7.a = r0     // Catch: java.lang.Exception -> L71
            int r0 = r7.c     // Catch: java.lang.Exception -> L71
            int r1 = r7.d     // Catch: java.lang.Exception -> L71
            if (r0 != r1) goto L52
            r0 = 0
            r7.c = r0     // Catch: java.lang.Exception -> L73
            boolean r0 = com.wooboo.adlib_android.sc.C     // Catch: java.lang.Exception -> L73
            if (r0 == 0) goto L59
        L52:
            int r0 = r7.c     // Catch: java.lang.Exception -> L75
            if (r0 >= 0) goto L59
            r0 = 0
            r7.c = r0     // Catch: java.lang.Exception -> L75
        L59:
            com.wooboo.adlib_android.wb r0 = r7.b     // Catch: java.lang.Exception -> L6c
            int r1 = r7.c     // Catch: java.lang.Exception -> L6c
            int r0 = r0.b(r1)     // Catch: java.lang.Exception -> L6c
            r7.f = r0     // Catch: java.lang.Exception -> L6c
            int r0 = r7.c     // Catch: java.lang.Exception -> L6c
            int r0 = r0 + 1
            r7.c = r0     // Catch: java.lang.Exception -> L6c
        L69:
            return
        L6a:
            r0 = move-exception
            throw r0     // Catch: java.lang.Exception -> L6c
        L6c:
            r0 = move-exception
            r0.printStackTrace()
            goto L69
        L71:
            r0 = move-exception
            throw r0     // Catch: java.lang.Exception -> L73
        L73:
            r0 = move-exception
            throw r0     // Catch: java.lang.Exception -> L75
        L75:
            r0 = move-exception
            throw r0     // Catch: java.lang.Exception -> L6c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.i.onDraw(android.graphics.Canvas):void");
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:18)
        */
    /* JADX WARN: Removed duplicated region for block: B:11:0x0011 A[ADDED_TO_REGION] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:9:0x000f -> B:3:0x0004). Please submit an issue!!! */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void run() {
        /*
            r3 = this;
            boolean r0 = com.wooboo.adlib_android.sc.C
            if (r0 == 0) goto Ld
        L4:
            r3.postInvalidate()     // Catch: java.lang.Exception -> L16
            int r1 = r3.f     // Catch: java.lang.Exception -> L16
            long r1 = (long) r1     // Catch: java.lang.Exception -> L16
            java.lang.Thread.sleep(r1)     // Catch: java.lang.Exception -> L16
        Ld:
            boolean r1 = r3.k     // Catch: java.lang.Exception -> L14
            if (r1 != 0) goto L4
            if (r0 != 0) goto Ld
            return
        L14:
            r0 = move-exception
            throw r0
        L16:
            r1 = move-exception
            goto Ld
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.i.run():void");
    }
}
