package com.kuguo.pushads;

import com.wooboo.adlib_android.nb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b {
    private static final char[] a = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    /* JADX INFO: Access modifiers changed from: protected */
    public static long a(byte[] bArr) {
        switch (bArr.length) {
            case 1:
                return bArr[0] & 255;
            case 2:
                return c(bArr);
            case nb.p /* 3 */:
            case 5:
            case nb.s /* 6 */:
            case nb.t /* 7 */:
            default:
                return 0L;
            case 4:
                return b(bArr);
            case 8:
                return ((bArr[0] << 56) & (-72057594037927936L)) | ((bArr[1] << 48) & 71776119061217280L) | ((bArr[2] << 40) & 280375465082880L) | ((bArr[3] << 32) & 1095216660480L) | ((bArr[4] << 24) & 4278190080L) | ((bArr[5] << 16) & 16711680) | ((bArr[6] << 8) & 65280) | (bArr[7] & 255);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static byte[] a(int i) {
        return new byte[]{(byte) (((-16777216) & i) >> 24), (byte) ((16711680 & i) >> 16), (byte) ((65280 & i) >> 8), (byte) (i & 255)};
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static byte[] a(short s) {
        return new byte[]{(byte) ((65280 & s) >> 8), (byte) (s & 255)};
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int b(byte[] bArr) {
        return ((bArr[0] << 24) & (-16777216)) | ((bArr[1] << 16) & 16711680) | ((bArr[2] << 8) & 65280) | (bArr[3] & 255);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int c(byte[] bArr) {
        return ((bArr[0] << 8) & 65280) | (bArr[1] & 255);
    }
}
