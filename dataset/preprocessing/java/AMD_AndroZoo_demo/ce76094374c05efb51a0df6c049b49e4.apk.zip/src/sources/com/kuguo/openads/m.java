package com.kuguo.openads;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class m implements Runnable {
    final /* synthetic */ g a;
    final /* synthetic */ k b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public m(k kVar, g gVar) {
        this.b = kVar;
        this.a = gVar;
    }

    @Override // java.lang.Runnable
    public void run() {
        Set set;
        Map map;
        Map map2;
        Map map3;
        Set set2;
        String str = this.a.j;
        int i = (int) (this.a.d * this.a.m);
        set = this.b.c;
        Iterator it = set.iterator();
        while (it.hasNext()) {
            ((a) it.next()).a(str, i);
        }
        this.b.b(i);
        int d = this.b.d();
        map = this.b.p;
        Iterator it2 = map.keySet().iterator();
        while (it2.hasNext()) {
            int intValue = ((Integer) it2.next()).intValue();
            map2 = this.b.p;
            if (d >= ((Integer) map2.get(Integer.valueOf(intValue))).intValue()) {
                it2.remove();
                map3 = this.b.p;
                map3.remove(Integer.valueOf(intValue));
                set2 = this.b.c;
                Iterator it3 = set2.iterator();
                while (it3.hasNext()) {
                    ((a) it3.next()).a(intValue);
                }
            }
        }
    }
}
