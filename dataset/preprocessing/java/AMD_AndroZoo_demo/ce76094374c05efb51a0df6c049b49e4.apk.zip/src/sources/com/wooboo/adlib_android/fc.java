package com.wooboo.adlib_android;

import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class fc {
    private final Map a;
    private static final String[] z = {z(z("\u0011E")), z(z("\u0010Kjy&m\rkc<)E")), z(z("\u0003\u001ehzr&\u000e}8")), z(z("\u00078KX\u001d/\u0001au&\u0016")), z(z("\u0010Kmer#\u0004p63m\u0005q{0(\u0019*")), z(z("\u0010E")), z(z("\u0018\u0005et>(Kpyr$\u0005gd7 \u000ejbr\u0016")), z(z("$\u0018")), z(z("*\u000ep")), z(z("*\u000epR7.\u0007ed;#\fGz3>\u0018")), z(z("*\u000epU>,\u0018w")), z(z("\u0010Kmer#\u0004p63m!WY\u001c\u0002\tns19E")), z(z("\u0010Kmer#\u0004p63m!WY\u001c\f\u0019vw+c")), z(z("\u0010Kjy&m\n$e&?\u0002jq|")), z(z("#\u001ehz")), z(z("'\nrw|")), z(z("'\nrw*c")), z(z("aa")), z(z("wK")), z(z("6\u0016")), z(z("9\u0019qs")), z(z("+\nhe7")), z(z("\u0010Kmer#\u0004p63m)ky>(\nj8")), z(z("\u0003\u001ehzr=\u0004mx&(\u0019")), z(z("\u0010Kmer#\u0004p63#Kmx&c")), z(z("\u0011\u001e")), z(z("oI")), z(z("}[4")), z(z("\u0011\u0005")), z(z("\u0011\r")), z(z("\u0011\t")), z(z("\u0011\u0019")), z(z("\u0011\u001f")), z(z("\u00078KXr)\u0004aer#\u0004p63!\u0007kar#\u0004j;4$\u0005mb7m\u0005q{0(\u0019w8")), z(z("\fKNE\u001d\u0003$f|7.\u001f$b75\u001f${'>\u001f$t7*\u0002j6%$\u001fl6u6L")), z(z("\fKNE\u001d\u0003$f|7.\u001f$b75\u001f${'>\u001f$s<)Ks\u007f&%K#ku")), z(z("\b\u0013ts19\u000e`63mL(1r\"\u0019$1/j")), z(z("\b\u0013ts19\u000e`63mL>1r,\rps m\n$}74")), z(z("\t\u001etz;.\npsr&\u000e}6p")), z(z("\u0010Kmer#\u0004p63m\u0007kx5c")), z(z("\u000f\n`6$,\u0007qsr+\u0019k{r9\u0004NE\u001d\u00038pd;#\f>6"))};
    public static final Object b = new gc(null);

    public fc() {
        this.a = new HashMap();
    }

    public fc(fc fcVar, String[] strArr) {
        this();
        for (int i = 0; i < strArr.length; i++) {
            try {
                try {
                    d(strArr[i], fcVar.l(strArr[i]));
                } catch (Exception e) {
                }
            } catch (Exception e2) {
                throw e2;
            }
        }
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:14:0x0049. Please report as an issue. */
    public fc(ic icVar) throws o {
        this();
        if (icVar.e() != '{') {
            throw icVar.b(z[34]);
        }
        while (true) {
            switch (icVar.e()) {
                case 0:
                    throw icVar.b(z[35]);
                case '}':
                    return;
                default:
                    icVar.a();
                    String obj = icVar.f().toString();
                    char e = icVar.e();
                    if (e == '=') {
                        try {
                            if (icVar.d() != '>') {
                                icVar.a();
                            }
                        } catch (o e2) {
                            throw e2;
                        }
                    } else if (e != ':') {
                        try {
                            throw icVar.b(z[37]);
                        } catch (o e3) {
                            throw e3;
                        }
                    }
                    try {
                        d(obj, icVar.f());
                        switch (icVar.e()) {
                            case ',':
                            case ';':
                                try {
                                    if (icVar.e() == '}') {
                                        return;
                                    } else {
                                        icVar.a();
                                    }
                                } catch (o e4) {
                                    throw e4;
                                }
                            case '}':
                                return;
                            default:
                                throw icVar.b(z[36]);
                        }
                    } catch (o e5) {
                        throw e5;
                    }
            }
        }
    }

    public fc(Object obj) {
        this();
        b(obj);
    }

    public fc(Object obj, String[] strArr) {
        this();
        Class<?> cls = obj.getClass();
        for (String str : strArr) {
            try {
                try {
                    e(str, cls.getField(str).get(obj));
                } catch (Exception e) {
                }
            } catch (Exception e2) {
                throw e2;
            }
        }
    }

    public fc(String str) throws o {
        this(new ic(str));
    }

    public fc(String str, Locale locale) throws o {
        this();
        ResourceBundle bundle = ResourceBundle.getBundle(str, locale, Thread.currentThread().getContextClassLoader());
        Enumeration<String> keys = bundle.getKeys();
        while (keys.hasMoreElements()) {
            String nextElement = keys.nextElement();
            if (nextElement instanceof String) {
                String[] split = nextElement.split(z[0]);
                int length = split.length - 1;
                int i = 0;
                fc fcVar = this;
                while (i < length) {
                    String str2 = split[i];
                    fc q = fcVar.q(str2);
                    if (q == null) {
                        q = new fc();
                        fcVar.c(str2, q);
                    }
                    i++;
                    fcVar = q;
                }
                try {
                    fcVar.c(split[length], bundle.getString(nextElement));
                } catch (o e) {
                    throw e;
                }
            }
        }
    }

    public fc(Map map) {
        this.a = new HashMap();
        if (map != null) {
            for (Map.Entry entry : map.entrySet()) {
                Object value = entry.getValue();
                if (value != null) {
                    this.a.put(entry.getKey(), e(value));
                }
            }
        }
    }

    public static String a(double d) {
        if (Double.isInfinite(d) || Double.isNaN(d)) {
            return z[14];
        }
        String d2 = Double.toString(d);
        if (d2.indexOf(46) <= 0 || d2.indexOf(101) >= 0 || d2.indexOf(69) >= 0) {
            return d2;
        }
        while (d2.endsWith("0")) {
            d2 = d2.substring(0, d2.length() - 1);
        }
        return d2.endsWith(".") ? d2.substring(0, d2.length() - 1) : d2;
    }

    public static String a(Number number) throws o {
        if (number == null) {
            try {
                throw new o(z[23]);
            } catch (o e) {
                throw e;
            }
        }
        c(number);
        String obj = number.toString();
        try {
            try {
                try {
                    if (obj.indexOf(46) <= 0 || obj.indexOf(101) >= 0 || obj.indexOf(69) >= 0) {
                        return obj;
                    }
                    while (obj.endsWith("0")) {
                        try {
                            obj = obj.substring(0, obj.length() - 1);
                        } catch (o e2) {
                            throw e2;
                        }
                    }
                    return obj.endsWith(".") ? obj.substring(0, obj.length() - 1) : obj;
                } catch (o e3) {
                    throw e3;
                }
            } catch (o e4) {
                throw e4;
            }
        } catch (o e5) {
            throw e5;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String a(Object obj, int i, int i2) throws o {
        if (obj != null) {
            try {
                if (!obj.equals(null)) {
                    try {
                        if (obj instanceof hc) {
                            String a = ((hc) obj).a();
                            if (a instanceof String) {
                                return a;
                            }
                        }
                    } catch (Exception e) {
                    }
                    try {
                        if (obj instanceof Number) {
                            return a((Number) obj);
                        }
                        try {
                            if (obj instanceof Boolean) {
                                return obj.toString();
                            }
                            try {
                                if (obj instanceof fc) {
                                    return ((fc) obj).a(i, i2);
                                }
                                try {
                                    if (obj instanceof ec) {
                                        return ((ec) obj).c(i, i2);
                                    }
                                    try {
                                        if (obj instanceof Map) {
                                            return new fc((Map) obj).a(i, i2);
                                        }
                                        try {
                                            if (obj instanceof Collection) {
                                                return new ec((Collection) obj).c(i, i2);
                                            }
                                            try {
                                                return obj.getClass().isArray() ? new ec(obj).c(i, i2) : t(obj.toString());
                                            } catch (Exception e2) {
                                                throw e2;
                                            }
                                        } catch (Exception e3) {
                                            throw e3;
                                        }
                                    } catch (Exception e4) {
                                        throw e4;
                                    }
                                } catch (Exception e5) {
                                    throw e5;
                                }
                            } catch (Exception e6) {
                                throw e6;
                            }
                        } catch (Exception e7) {
                            throw e7;
                        }
                    } catch (Exception e8) {
                        throw e8;
                    }
                }
            } catch (Exception e9) {
                throw e9;
            }
        }
        return z[14];
    }

    public static String[] a(fc fcVar) {
        int b2 = fcVar.b();
        if (b2 == 0) {
            return null;
        }
        Iterator a = fcVar.a();
        String[] strArr = new String[b2];
        int i = 0;
        while (true) {
            int i2 = i;
            if (!a.hasNext()) {
                return strArr;
            }
            strArr[i2] = (String) a.next();
            i = i2 + 1;
        }
    }

    public static String[] a(Object obj) {
        Field[] fields;
        int length;
        String[] strArr = null;
        if (obj != null && (length = (fields = obj.getClass().getFields()).length) != 0) {
            strArr = new String[length];
            for (int i = 0; i < length; i++) {
                strArr[i] = fields[i].getName();
            }
        }
        return strArr;
    }

    private void b(Object obj) {
        Method[] methods;
        int i = 0;
        Class<?> cls = obj.getClass();
        try {
            if (cls.getClassLoader() != null) {
                try {
                    methods = cls.getMethods();
                } catch (Exception e) {
                    throw e;
                }
            } else {
                methods = cls.getDeclaredMethods();
            }
            while (true) {
                try {
                    int i2 = i;
                    if (i2 >= methods.length) {
                        return;
                    }
                    try {
                        Method method = methods[i2];
                        if (Modifier.isPublic(method.getModifiers())) {
                            String name = method.getName();
                            String str = "";
                            try {
                                if (name.startsWith(z[8])) {
                                    try {
                                        str = (name.equals(z[10]) || name.equals(z[9])) ? "" : name.substring(3);
                                    } catch (Exception e2) {
                                        throw e2;
                                    }
                                } else if (name.startsWith(z[7])) {
                                    str = name.substring(2);
                                }
                                try {
                                    if (str.length() > 0) {
                                        try {
                                            if (Character.isUpperCase(str.charAt(0))) {
                                                try {
                                                    if (method.getParameterTypes().length == 0) {
                                                        if (str.length() == 1) {
                                                            str = str.toLowerCase();
                                                        } else if (!Character.isUpperCase(str.charAt(1))) {
                                                            str = String.valueOf(str.substring(0, 1).toLowerCase()) + str.substring(1);
                                                        }
                                                        Object invoke = method.invoke(obj, null);
                                                        if (invoke != null) {
                                                            this.a.put(str, e(invoke));
                                                        }
                                                    }
                                                } catch (Exception e3) {
                                                    throw e3;
                                                }
                                            }
                                        } catch (Exception e4) {
                                            throw e4;
                                            break;
                                        }
                                    }
                                } catch (Exception e5) {
                                    throw e5;
                                    break;
                                }
                            } catch (Exception e6) {
                                throw e6;
                                break;
                            }
                        } else {
                            continue;
                        }
                    } catch (Exception e7) {
                    }
                    i = i2 + 1;
                } catch (Exception e8) {
                    throw e8;
                }
            }
        } catch (Exception e9) {
            throw e9;
        }
    }

    public static void c(Object obj) throws o {
        try {
            try {
                if (obj != null) {
                    try {
                        try {
                            try {
                                if (obj instanceof Double) {
                                    if (((Double) obj).isInfinite() || ((Double) obj).isNaN()) {
                                        throw new o(z[33]);
                                    }
                                    return;
                                }
                                try {
                                    if (obj instanceof Float) {
                                        if (((Float) obj).isInfinite() || ((Float) obj).isNaN()) {
                                            throw new o(z[33]);
                                        }
                                    }
                                } catch (o e) {
                                    throw e;
                                }
                            } catch (o e2) {
                                throw e2;
                            }
                        } catch (o e3) {
                            throw e3;
                        }
                    } catch (o e4) {
                        throw e4;
                    }
                }
            } catch (o e5) {
                throw e5;
            }
        } catch (o e6) {
            throw e6;
        }
    }

    public static String d(Object obj) throws o {
        if (obj != null) {
            try {
                if (!obj.equals(null)) {
                    if (obj instanceof hc) {
                        try {
                            String a = ((hc) obj).a();
                            try {
                                if (a instanceof String) {
                                    return a;
                                }
                                throw new o(z[40] + ((Object) a));
                            } catch (Exception e) {
                                throw e;
                            }
                        } catch (Exception e2) {
                            throw new o(e2);
                        }
                    }
                    try {
                        try {
                            try {
                                if (obj instanceof Number) {
                                    return a((Number) obj);
                                }
                                try {
                                    if ((obj instanceof Boolean) || (obj instanceof fc) || (obj instanceof ec)) {
                                        return obj.toString();
                                    }
                                    try {
                                        if (obj instanceof Map) {
                                            return new fc((Map) obj).toString();
                                        }
                                        try {
                                            if (obj instanceof Collection) {
                                                return new ec((Collection) obj).toString();
                                            }
                                            try {
                                                return obj.getClass().isArray() ? new ec(obj).toString() : t(obj.toString());
                                            } catch (Exception e3) {
                                                throw e3;
                                            }
                                        } catch (Exception e4) {
                                            throw e4;
                                        }
                                    } catch (Exception e5) {
                                        throw e5;
                                    }
                                } catch (Exception e6) {
                                    throw e6;
                                }
                            } catch (Exception e7) {
                                throw e7;
                            }
                        } catch (Exception e8) {
                            throw e8;
                        }
                    } catch (Exception e9) {
                        throw e9;
                    }
                }
            } catch (Exception e10) {
                throw e10;
            }
        }
        return z[14];
    }

    public static Object e(Object obj) {
        String name;
        try {
            if (obj == null) {
                return b;
            }
            try {
                try {
                    if (obj instanceof fc) {
                        return obj;
                    }
                    try {
                        try {
                            try {
                                if ((obj instanceof ec) || b.equals(obj)) {
                                    return obj;
                                }
                                try {
                                    if (obj instanceof hc) {
                                        return obj;
                                    }
                                    try {
                                        if (obj instanceof Byte) {
                                            return obj;
                                        }
                                        try {
                                            try {
                                                if ((obj instanceof Character) || (obj instanceof Short)) {
                                                    return obj;
                                                }
                                                try {
                                                    if (obj instanceof Integer) {
                                                        return obj;
                                                    }
                                                    try {
                                                        if ((obj instanceof Long) || (obj instanceof Boolean) || (obj instanceof Float) || (obj instanceof Double) || (obj instanceof String)) {
                                                            return obj;
                                                        }
                                                        if (obj instanceof Collection) {
                                                            return new ec((Collection) obj);
                                                        }
                                                        if (obj.getClass().isArray()) {
                                                            return new ec(obj);
                                                        }
                                                        if (obj instanceof Map) {
                                                            return new fc((Map) obj);
                                                        }
                                                        Package r0 = obj.getClass().getPackage();
                                                        if (r0 != null) {
                                                            try {
                                                                name = r0.getName();
                                                            } catch (Exception e) {
                                                                throw e;
                                                            }
                                                        } else {
                                                            name = "";
                                                        }
                                                        try {
                                                            try {
                                                                return (name.startsWith(z[15]) || name.startsWith(z[16]) || obj.getClass().getClassLoader() == null) ? obj.toString() : new fc(obj);
                                                            } catch (Exception e2) {
                                                                throw e2;
                                                            }
                                                        } catch (Exception e3) {
                                                            throw e3;
                                                        }
                                                    } catch (Exception e4) {
                                                        throw e4;
                                                    }
                                                } catch (Exception e5) {
                                                    throw e5;
                                                }
                                            } catch (Exception e6) {
                                                throw e6;
                                            }
                                        } catch (Exception e7) {
                                            throw e7;
                                        }
                                    } catch (Exception e8) {
                                        throw e8;
                                    }
                                } catch (Exception e9) {
                                    throw e9;
                                }
                            } catch (Exception e10) {
                                throw e10;
                            }
                        } catch (Exception e11) {
                            throw e11;
                        }
                    } catch (Exception e12) {
                        throw e12;
                    }
                } catch (Exception e13) {
                    throw e13;
                }
            } catch (Exception e14) {
                throw e14;
            }
        } catch (Exception e15) {
            return null;
        }
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:18)
        */
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0030  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00aa  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00b3  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00c9  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x0081 -> B:8:0x0029). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String t(java.lang.String r12) {
        /*
            r11 = 92
            r10 = 34
            r9 = 32
            r0 = 0
            boolean r3 = com.wooboo.adlib_android.sc.C
            if (r12 == 0) goto L11
            int r1 = r12.length()
            if (r1 != 0) goto L18
        L11:
            java.lang.String[] r0 = com.wooboo.adlib_android.fc.z
            r1 = 26
            r0 = r0[r1]
        L17:
            return r0
        L18:
            int r4 = r12.length()
            java.lang.StringBuffer r5 = new java.lang.StringBuffer
            int r1 = r4 + 4
            r5.<init>(r1)
            r5.append(r10)
            if (r3 == 0) goto Ld6
            r1 = r0
        L29:
            char r2 = r12.charAt(r0)
            switch(r2) {
                case 8: goto L9f;
                case 9: goto Laa;
                case 10: goto Lb3;
                case 12: goto Lbe;
                case 13: goto Lc9;
                case 34: goto L8b;
                case 47: goto L93;
                case 92: goto L8b;
                default: goto L30;
            }
        L30:
            if (r2 < r9) goto L42
            r1 = 128(0x80, float:1.794E-43)
            if (r2 < r1) goto L3a
            r1 = 160(0xa0, float:2.24E-43)
            if (r2 < r1) goto L42
        L3a:
            r1 = 8192(0x2000, float:1.14794E-41)
            if (r2 < r1) goto L7b
            r1 = 8448(0x2100, float:1.1838E-41)
            if (r2 >= r1) goto L7b
        L42:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String[] r6 = com.wooboo.adlib_android.fc.z
            r7 = 27
            r6 = r6[r7]
            r1.<init>(r6)
            java.lang.String r6 = java.lang.Integer.toHexString(r2)
            java.lang.StringBuilder r1 = r1.append(r6)
            java.lang.String r1 = r1.toString()
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            java.lang.String[] r7 = com.wooboo.adlib_android.fc.z
            r8 = 25
            r7 = r7[r8]
            r6.<init>(r7)
            int r7 = r1.length()
            int r7 = r7 + (-4)
            java.lang.String r1 = r1.substring(r7)
            java.lang.StringBuilder r1 = r6.append(r1)
            java.lang.String r1 = r1.toString()
            r5.append(r1)
            if (r3 == 0) goto L7e
        L7b:
            r5.append(r2)
        L7e:
            int r0 = r0 + 1
            r1 = r2
        L81:
            if (r0 < r4) goto L29
            r5.append(r10)
            java.lang.String r0 = r5.toString()
            goto L17
        L8b:
            r5.append(r11)
            r5.append(r2)
            if (r3 == 0) goto L7e
        L93:
            r6 = 60
            if (r1 != r6) goto L9a
            r5.append(r11)
        L9a:
            r5.append(r2)
            if (r3 == 0) goto L7e
        L9f:
            java.lang.String[] r1 = com.wooboo.adlib_android.fc.z
            r6 = 30
            r1 = r1[r6]
            r5.append(r1)
            if (r3 == 0) goto L7e
        Laa:
            java.lang.String[] r1 = com.wooboo.adlib_android.fc.z
            r1 = r1[r9]
            r5.append(r1)
            if (r3 == 0) goto L7e
        Lb3:
            java.lang.String[] r1 = com.wooboo.adlib_android.fc.z
            r6 = 28
            r1 = r1[r6]
            r5.append(r1)
            if (r3 == 0) goto L7e
        Lbe:
            java.lang.String[] r1 = com.wooboo.adlib_android.fc.z
            r6 = 29
            r1 = r1[r6]
            r5.append(r1)
            if (r3 == 0) goto L7e
        Lc9:
            java.lang.String[] r1 = com.wooboo.adlib_android.fc.z
            r6 = 31
            r1 = r1[r6]
            r5.append(r1)
            if (r3 == 0) goto L7e
            goto L30
        Ld6:
            r1 = r0
            goto L81
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.fc.t(java.lang.String):java.lang.String");
    }

    public static Object v(String str) {
        try {
            if (str.equals("")) {
                return str;
            }
            try {
                if (str.equalsIgnoreCase(z[20])) {
                    return Boolean.TRUE;
                }
                try {
                    if (str.equalsIgnoreCase(z[21])) {
                        return Boolean.FALSE;
                    }
                    try {
                        if (str.equalsIgnoreCase(z[14])) {
                            return b;
                        }
                        char charAt = str.charAt(0);
                        if ((charAt < '0' || charAt > '9') && charAt != '.' && charAt != '-' && charAt != '+') {
                            return str;
                        }
                        try {
                            if (str.indexOf(46) <= -1) {
                                try {
                                    if (str.indexOf(101) <= -1) {
                                        if (str.indexOf(69) <= -1) {
                                            Long l = new Long(str);
                                            return l.longValue() == ((long) l.intValue()) ? new Integer(l.intValue()) : l;
                                        }
                                    }
                                } catch (Exception e) {
                                    throw e;
                                }
                            }
                            Double valueOf = Double.valueOf(str);
                            try {
                                return !valueOf.isInfinite() ? !valueOf.isNaN() ? valueOf : str : str;
                            } catch (Exception e2) {
                                throw e2;
                            }
                        } catch (Exception e3) {
                            return str;
                        }
                    } catch (Exception e4) {
                        throw e4;
                    }
                } catch (Exception e5) {
                    throw e5;
                }
            } catch (Exception e6) {
                throw e6;
            }
        } catch (Exception e7) {
            throw e7;
        }
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'M';
                    break;
                case 1:
                    c = 'k';
                    break;
                case 2:
                    c = 4;
                    break;
                case nb.p /* 3 */:
                    c = 22;
                    break;
                default:
                    c = 'R';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'R');
        }
        return charArray;
    }

    public double a(String str, double d) {
        try {
            return c(str);
        } catch (Exception e) {
            return d;
        }
    }

    public int a(String str, int i) {
        try {
            return d(str);
        } catch (Exception e) {
            return i;
        }
    }

    public long a(String str, long j) {
        try {
            return g(str);
        } catch (Exception e) {
            return j;
        }
    }

    public ec a(ec ecVar) throws o {
        if (ecVar != null) {
            try {
                if (ecVar.a() != 0) {
                    ec ecVar2 = new ec();
                    for (int i = 0; i < ecVar.a(); i++) {
                        try {
                            ecVar2.a(l(ecVar.h(i)));
                        } catch (o e) {
                            throw e;
                        }
                    }
                    return ecVar2;
                }
            } catch (o e2) {
                throw e2;
            }
        }
        return null;
    }

    public fc a(String str, Object obj) throws o {
        c(obj);
        Object l = l(str);
        if (l == null) {
            try {
                if (obj instanceof ec) {
                    obj = new ec().a(obj);
                }
                c(str, obj);
            } catch (o e) {
                throw e;
            }
        } else {
            try {
                if (l instanceof ec) {
                    ((ec) l).a(obj);
                } else {
                    c(str, new ec().a(l).a(obj));
                }
            } catch (o e2) {
                throw e2;
            }
        }
        return this;
    }

    public fc a(String str, Collection collection) throws o {
        c(str, new ec(collection));
        return this;
    }

    public fc a(String str, Map map) throws o {
        c(str, new fc(map));
        return this;
    }

    public Writer a(Writer writer) throws o {
        boolean z2 = false;
        try {
            Iterator a = a();
            writer.write(123);
            while (a.hasNext()) {
                if (z2) {
                    try {
                        writer.write(44);
                    } catch (IOException e) {
                        throw e;
                    }
                }
                Object next = a.next();
                writer.write(t(next.toString()));
                writer.write(58);
                Object obj = this.a.get(next);
                try {
                    if (obj instanceof fc) {
                        ((fc) obj).a(writer);
                    } else {
                        try {
                            if (obj instanceof ec) {
                                ((ec) obj).a(writer);
                            } else {
                                writer.write(d(obj));
                            }
                        } catch (IOException e2) {
                            throw e2;
                        }
                    }
                    z2 = true;
                } catch (IOException e3) {
                    throw e3;
                }
            }
            writer.write(125);
            return writer;
        } catch (IOException e4) {
            throw new o(e4);
        }
    }

    public Object a(String str) throws o {
        if (str == null) {
            try {
                throw new o(z[2]);
            } catch (o e) {
                throw e;
            }
        }
        Object l = l(str);
        if (l != null) {
            return l;
        }
        try {
            throw new o(z[3] + t(str) + z[1]);
        } catch (o e2) {
            throw e2;
        }
    }

    public String a(int i) throws o {
        return a(i, 0);
    }

    String a(int i, int i2) throws o {
        int b2 = b();
        if (b2 == 0) {
            try {
                return z[19];
            } catch (o e) {
                throw e;
            }
        }
        Iterator a = a();
        int i3 = i2 + i;
        StringBuffer stringBuffer = new StringBuffer("{");
        try {
            if (b2 == 1) {
                Object next = a.next();
                stringBuffer.append(t(next.toString()));
                stringBuffer.append(z[18]);
                stringBuffer.append(a(this.a.get(next), i, i2));
                stringBuffer.append('}');
                return stringBuffer.toString();
            }
            stringBuffer.append('}');
            return stringBuffer.toString();
        } catch (o e2) {
            throw e2;
        }
        while (a.hasNext()) {
            try {
                Object next2 = a.next();
                try {
                    if (stringBuffer.length() > 1) {
                        stringBuffer.append(z[17]);
                    } else {
                        stringBuffer.append('\n');
                    }
                    for (int i4 = 0; i4 < i3; i4++) {
                        stringBuffer.append(' ');
                    }
                    try {
                        stringBuffer.append(t(next2.toString()));
                        stringBuffer.append(z[18]);
                        stringBuffer.append(a(this.a.get(next2), i, i3));
                    } catch (o e3) {
                        throw e3;
                    }
                } catch (o e4) {
                    throw e4;
                }
            } catch (o e5) {
                throw e5;
            }
        }
        if (stringBuffer.length() > 1) {
            stringBuffer.append('\n');
            for (int i5 = 0; i5 < i2; i5++) {
                stringBuffer.append(' ');
            }
        }
    }

    public String a(String str, String str2) {
        Object l = l(str);
        return b.equals(l) ? str2 : l.toString();
    }

    public Iterator a() {
        return this.a.keySet().iterator();
    }

    public boolean a(String str, boolean z2) {
        try {
            return b(str);
        } catch (Exception e) {
            return z2;
        }
    }

    public int b() {
        return this.a.size();
    }

    public fc b(String str, double d) throws o {
        c(str, new Double(d));
        return this;
    }

    public fc b(String str, int i) throws o {
        c(str, new Integer(i));
        return this;
    }

    public fc b(String str, long j) throws o {
        c(str, new Long(j));
        return this;
    }

    public fc b(String str, Object obj) throws o {
        c(obj);
        Object l = l(str);
        if (l == null) {
            try {
                c(str, new ec().a(obj));
            } catch (o e) {
                throw e;
            }
        } else {
            try {
                if (!(l instanceof ec)) {
                    throw new o(z[3] + str + z[12]);
                }
                c(str, ((ec) l).a(obj));
            } catch (o e2) {
                throw e2;
            }
        }
        return this;
    }

    public fc b(String str, boolean z2) throws o {
        Boolean bool;
        if (z2) {
            try {
                bool = Boolean.TRUE;
            } catch (o e) {
                throw e;
            }
        } else {
            bool = Boolean.FALSE;
        }
        c(str, bool);
        return this;
    }

    public boolean b(String str) throws o {
        Object a = a(str);
        try {
            try {
                try {
                    if (a.equals(Boolean.FALSE) || ((a instanceof String) && ((String) a).equalsIgnoreCase(z[21]))) {
                        return false;
                    }
                    try {
                        try {
                            try {
                                if (a.equals(Boolean.TRUE) || ((a instanceof String) && ((String) a).equalsIgnoreCase(z[20]))) {
                                    return true;
                                }
                                throw new o(z[3] + t(str) + z[22]);
                            } catch (o e) {
                                throw e;
                            }
                        } catch (o e2) {
                            throw e2;
                        }
                    } catch (o e3) {
                        throw e3;
                    }
                } catch (o e4) {
                    throw e4;
                }
            } catch (o e5) {
                throw e5;
            }
        } catch (o e6) {
            throw e6;
        }
    }

    public double c(String str) throws o {
        Object a = a(str);
        try {
            return a instanceof Number ? ((Number) a).doubleValue() : Double.parseDouble((String) a);
        } catch (Exception e) {
            throw new o(z[3] + t(str) + z[4]);
        }
    }

    public ec c() {
        ec ecVar = new ec();
        Iterator a = a();
        while (a.hasNext()) {
            ecVar.a(a.next());
        }
        if (ecVar.a() == 0) {
            return null;
        }
        return ecVar;
    }

    public fc c(String str, Object obj) throws o {
        if (str == null) {
            try {
                throw new o(z[2]);
            } catch (o e) {
                throw e;
            }
        }
        if (obj != null) {
            try {
                c(obj);
                this.a.put(str, obj);
            } catch (o e2) {
                throw e2;
            }
        } else {
            u(str);
        }
        return this;
    }

    public int d(String str) throws o {
        Object a = a(str);
        try {
            return a instanceof Number ? ((Number) a).intValue() : Integer.parseInt((String) a);
        } catch (Exception e) {
            throw new o(z[3] + t(str) + z[24]);
        }
    }

    public fc d(String str, Object obj) throws o {
        if (str != null && obj != null) {
            try {
                if (l(str) != null) {
                    throw new o(z[38] + str + "\"");
                }
                c(str, obj);
            } catch (o e) {
                throw e;
            }
        }
        return this;
    }

    public ec e(String str) throws o {
        Object a = a(str);
        try {
            if (a instanceof ec) {
                return (ec) a;
            }
            throw new o(z[3] + t(str) + z[12]);
        } catch (o e) {
            throw e;
        }
    }

    public fc e(String str, Object obj) throws o {
        if (str != null && obj != null) {
            try {
                c(str, obj);
            } catch (o e) {
                throw e;
            }
        }
        return this;
    }

    public fc f(String str) throws o {
        Object a = a(str);
        try {
            if (a instanceof fc) {
                return (fc) a;
            }
            throw new o(z[3] + t(str) + z[11]);
        } catch (o e) {
            throw e;
        }
    }

    public long g(String str) throws o {
        Object a = a(str);
        try {
            return a instanceof Number ? ((Number) a).longValue() : Long.parseLong((String) a);
        } catch (Exception e) {
            throw new o(z[3] + t(str) + z[39]);
        }
    }

    public String h(String str) throws o {
        Object a = a(str);
        try {
            if (a instanceof String) {
                return (String) a;
            }
            throw new o(z[3] + t(str) + z[13]);
        } catch (o e) {
            throw e;
        }
    }

    public boolean i(String str) {
        return this.a.containsKey(str);
    }

    public fc j(String str) throws o {
        Object l = l(str);
        if (l == null) {
            try {
                b(str, 1);
            } catch (o e) {
                throw e;
            }
        } else {
            try {
                if (l instanceof Integer) {
                    b(str, ((Integer) l).intValue() + 1);
                } else {
                    try {
                        if (l instanceof Long) {
                            b(str, ((Long) l).longValue() + 1);
                        } else {
                            try {
                                if (l instanceof Double) {
                                    b(str, ((Double) l).doubleValue() + 1.0d);
                                } else {
                                    try {
                                        if (!(l instanceof Float)) {
                                            throw new o(z[6] + t(str) + z[5]);
                                        }
                                        b(str, ((Float) l).floatValue() + 1.0f);
                                    } catch (o e2) {
                                        throw e2;
                                    }
                                }
                            } catch (o e3) {
                                throw e3;
                            }
                        }
                    } catch (o e4) {
                        throw e4;
                    }
                }
            } catch (o e5) {
                throw e5;
            }
        }
        return this;
    }

    public boolean k(String str) {
        return b.equals(l(str));
    }

    public Object l(String str) {
        if (str == null) {
            return null;
        }
        return this.a.get(str);
    }

    public boolean m(String str) {
        return a(str, false);
    }

    public double n(String str) {
        return a(str, Double.NaN);
    }

    public int o(String str) {
        return a(str, 0);
    }

    public ec p(String str) {
        Object l = l(str);
        if (l instanceof ec) {
            return (ec) l;
        }
        return null;
    }

    public fc q(String str) {
        Object l = l(str);
        if (l instanceof fc) {
            return (fc) l;
        }
        return null;
    }

    public long r(String str) {
        return a(str, 0L);
    }

    public String s(String str) {
        return a(str, "");
    }

    public String toString() {
        try {
            Iterator a = a();
            StringBuffer stringBuffer = new StringBuffer("{");
            while (a.hasNext()) {
                try {
                    if (stringBuffer.length() > 1) {
                        stringBuffer.append(',');
                    }
                    Object next = a.next();
                    stringBuffer.append(t(next.toString()));
                    stringBuffer.append(':');
                    stringBuffer.append(d(this.a.get(next)));
                } catch (Exception e) {
                    throw e;
                }
            }
            stringBuffer.append('}');
            return stringBuffer.toString();
        } catch (Exception e2) {
            return null;
        }
    }

    public Object u(String str) {
        return this.a.remove(str);
    }
}
