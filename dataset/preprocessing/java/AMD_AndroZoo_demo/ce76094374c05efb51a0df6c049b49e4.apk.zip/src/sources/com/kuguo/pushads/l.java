package com.kuguo.pushads;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.wooboo.adlib_android.nb;
import java.io.File;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class l implements com.kuguo.a.c {
    final /* synthetic */ c a;
    private int b;

    private l(c cVar) {
        this.a = cVar;
        this.b = 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ l(c cVar, r rVar) {
        this(cVar);
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, int i) {
        Activity activity;
        j jVar;
        j jVar2;
        Handler handler;
        Activity activity2;
        j jVar3;
        Activity activity3;
        j jVar4;
        j jVar5;
        Activity activity4;
        j jVar6;
        j jVar7;
        int intValue = ((Integer) dVar.k()).intValue();
        switch (i) {
            case 0:
            case 1:
            case 2:
            case nb.p /* 3 */:
            default:
                return;
            case 4:
                if (intValue != -2) {
                    Message obtain = Message.obtain();
                    Bundle bundle = new Bundle();
                    bundle.putString("filePath", dVar.b().getPath());
                    bundle.putInt("tag", ((Integer) dVar.k()).intValue());
                    obtain.setData(bundle);
                    handler = this.a.g;
                    handler.sendMessage(obtain);
                    return;
                }
                if (dVar.b() != null) {
                    activity2 = this.a.f;
                    jVar3 = this.a.d;
                    int i2 = jVar3.h;
                    activity3 = this.a.f;
                    File b = dVar.b();
                    jVar4 = this.a.d;
                    Intent a = a.a(activity3, b, jVar4.u);
                    jVar5 = this.a.d;
                    h.a(activity2, 17301634, "下载完成", i2, 16, a, jVar5.g, -1);
                    activity4 = this.a.f;
                    String path = dVar.b().getPath();
                    jVar6 = this.a.d;
                    String str = jVar6.i;
                    jVar7 = this.a.d;
                    a.a(activity4, path, str, jVar7.u);
                    return;
                }
                return;
            case 5:
                if (intValue == -2) {
                    activity = this.a.f;
                    jVar = this.a.d;
                    int i3 = jVar.h;
                    Intent intent = new Intent();
                    jVar2 = this.a.d;
                    h.a(activity, 17301624, "下载失败", i3, 16, intent, jVar2.k, -1);
                    return;
                }
                return;
        }
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, long j) {
        Activity activity;
        j jVar;
        j jVar2;
        if (((Integer) dVar.k()).intValue() == -2) {
            int i = (dVar.i() * 100) / dVar.h();
            if (i - this.b > 3) {
                this.b = i;
                activity = this.a.f;
                jVar = this.a.d;
                int i2 = jVar.h;
                Intent intent = new Intent();
                jVar2 = this.a.d;
                h.a(activity, 17301633, "正在下载...", i2, 32, intent, jVar2.g, this.b);
            }
        }
    }
}
