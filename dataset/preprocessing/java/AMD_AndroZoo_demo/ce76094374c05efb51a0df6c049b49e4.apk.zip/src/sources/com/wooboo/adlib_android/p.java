package com.wooboo.adlib_android;

import android.content.DialogInterface;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class p implements DialogInterface.OnClickListener {
    private static final String[] z = {z(z("1\rnE\u000e\t.nD\u0000\n1dU\u0017\u000f\u0001d\u00072\u0012\u0003sS")), z(z("1\rnE\u000e\t1dU\u0017\u000f\u0001d\u00072\u0012\u0003sS"))};
    final AdActivity a;
    private final com.wooboo.download.d b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(AdActivity adActivity, com.wooboo.download.d dVar) {
        this.a = adActivity;
        this.b = dVar;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'f';
                    break;
                case 1:
                    c = 'b';
                    break;
                case 2:
                    c = 1;
                    break;
                case nb.p /* 3 */:
                    c = '\'';
                    break;
                default:
                    c = 'a';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'a');
        }
        return charArray;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        com.wooboo.download.f.a(AdActivity.e(this.a), (com.wooboo.download.g) null, AdActivity.f(this.a), com.wooboo.download.h.b(AdActivity.e(this.a))).f(this.b.k);
        AdActivity.a(this.a, AdActivity.f(this.a).g());
        AdActivity.g(this.a).notifyDataSetChanged();
        if (com.wooboo.download.h.a(AdActivity.e(this.a))) {
            com.wooboo.download.h.a(AdActivity.e(this.a));
            mc.c(z[1]);
            if (!sc.C) {
                return;
            }
        }
        com.wooboo.download.j.a(AdActivity.e(this.a)).b();
        mc.c(z[0]);
    }
}
