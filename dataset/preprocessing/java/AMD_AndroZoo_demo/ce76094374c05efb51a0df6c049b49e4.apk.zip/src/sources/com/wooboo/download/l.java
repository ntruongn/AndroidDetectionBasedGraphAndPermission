package com.wooboo.download;

import android.content.Context;
import com.wooboo.adlib_android.nb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class l extends Thread {
    private static final String[] z = {z(z("*u\u0017V}\u0014u\nA<\u001euYT<\u0010|\u001cVqYs\u0018\\}\u0017\u007f\r\u0012:\u001cdYA8\u001a0\u0012W$")), z(z("Yc\u001cQ}C")), z(z("Yb\r\\g")), z(z("Y*")), z(z("\nu\u0017V}\u0014c\u001e\b")), z(z("\u001c~D")), z(z("*u\u0017V\u0010\u001cc\nS:\u001cD\u0011@8\u0018tYA8\u001a")), z(z("\u0018d"))};
    private Context a;
    private i b;
    String c;
    String d;
    Long e;
    String f;

    public l(Context context, i iVar, String str, String str2, Long l, String str3) {
        this.b = null;
        this.c = "";
        this.d = "";
        this.f = null;
        this.b = iVar;
        this.c = str2;
        this.e = l;
        this.a = context;
        this.d = str3;
        this.f = str;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'y';
                    break;
                case 1:
                    c = 16;
                    break;
                case 2:
                    c = 'y';
                    break;
                case nb.p /* 3 */:
                    c = '2';
                    break;
                default:
                    c = ']';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ ']');
        }
        return charArray;
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x00fe, code lost:
    
        if (r1 != false) goto L44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00df, code lost:
    
        if (r1 != false) goto L16;
     */
    @Override // java.lang.Thread, java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void run() {
        /*
            Method dump skipped, instructions count: 310
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.download.l.run():void");
    }
}
