package com.yong.pedometer;

import com.yong.pedometer.SpeakingTimer;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class PaceNotifier implements StepListener, SpeakingTimer.Listener {
    int mDesiredPace;
    PedometerSettings mSettings;
    boolean mShouldTellFasterslower;
    Utils mUtils;
    private ArrayList<Listener> mListeners = new ArrayList<>();
    int mCounter = 0;
    private long mLastStepTime = 0;
    private long[] mLastStepDeltas = {-1, -1, -1, -1};
    private int mLastStepDeltasIndex = 0;
    private long mPace = 0;
    private long mSpokenAt = 0;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public interface Listener {
        void paceChanged(int i);

        void passValue();
    }

    public PaceNotifier(PedometerSettings settings, Utils utils) {
        this.mUtils = utils;
        this.mSettings = settings;
        this.mDesiredPace = this.mSettings.getDesiredPace();
        reloadSettings();
    }

    public void setPace(int pace) {
        this.mPace = pace;
        int avg = (int) (60000.0d / this.mPace);
        for (int i = 0; i < this.mLastStepDeltas.length; i++) {
            this.mLastStepDeltas[i] = avg;
        }
        notifyListener();
    }

    public void reloadSettings() {
        this.mShouldTellFasterslower = this.mSettings.shouldTellFasterslower() && this.mSettings.getMaintainOption() == PedometerSettings.M_PACE;
        notifyListener();
    }

    public void addListener(Listener l) {
        this.mListeners.add(l);
    }

    public void setDesiredPace(int desiredPace) {
        this.mDesiredPace = desiredPace;
    }

    @Override // com.yong.pedometer.StepListener
    public void onStep() {
        long thisStepTime = System.currentTimeMillis();
        this.mCounter++;
        if (this.mLastStepTime > 0) {
            long delta = thisStepTime - this.mLastStepTime;
            this.mLastStepDeltas[this.mLastStepDeltasIndex] = delta;
            this.mLastStepDeltasIndex = (this.mLastStepDeltasIndex + 1) % this.mLastStepDeltas.length;
            long sum = 0;
            boolean isMeaningfull = true;
            int i = 0;
            while (true) {
                if (i >= this.mLastStepDeltas.length) {
                    break;
                }
                if (this.mLastStepDeltas[i] < 0) {
                    isMeaningfull = false;
                    break;
                } else {
                    sum += this.mLastStepDeltas[i];
                    i++;
                }
            }
            if (isMeaningfull && sum > 0) {
                long avg = sum / this.mLastStepDeltas.length;
                this.mPace = 60000 / avg;
                if (this.mShouldTellFasterslower && !this.mUtils.isSpeakingEnabled() && thisStepTime - this.mSpokenAt > 3000 && !this.mUtils.isSpeakingNow()) {
                    boolean spoken = true;
                    if (((float) this.mPace) < this.mDesiredPace * (1.0f - 0.5f)) {
                        this.mUtils.say("much faster!");
                    } else if (((float) this.mPace) > this.mDesiredPace * (1.0f + 0.5f)) {
                        this.mUtils.say("much slower!");
                    } else if (((float) this.mPace) < this.mDesiredPace * (1.0f - 0.3f)) {
                        this.mUtils.say("faster!");
                    } else if (((float) this.mPace) > this.mDesiredPace * (1.0f + 0.3f)) {
                        this.mUtils.say("slower!");
                    } else if (((float) this.mPace) < this.mDesiredPace * (1.0f - 0.1f)) {
                        this.mUtils.say("a little faster!");
                    } else if (((float) this.mPace) > this.mDesiredPace * (1.0f + 0.1f)) {
                        this.mUtils.say("a little slower!");
                    } else {
                        spoken = false;
                    }
                    if (spoken) {
                        this.mSpokenAt = thisStepTime;
                    }
                }
            } else {
                this.mPace = -1L;
            }
        }
        this.mLastStepTime = thisStepTime;
        notifyListener();
    }

    private void notifyListener() {
        Iterator<Listener> it = this.mListeners.iterator();
        while (it.hasNext()) {
            Listener listener = it.next();
            listener.paceChanged((int) this.mPace);
        }
    }

    @Override // com.yong.pedometer.StepListener
    public void passValue() {
    }

    @Override // com.yong.pedometer.SpeakingTimer.Listener
    public void speak() {
        if (this.mSettings.shouldTellPace() && this.mPace > 0) {
            this.mUtils.say(String.valueOf(this.mPace) + " steps per minute");
        }
    }
}
