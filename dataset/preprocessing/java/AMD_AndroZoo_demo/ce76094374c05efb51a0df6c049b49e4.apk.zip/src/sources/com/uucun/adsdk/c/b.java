package com.uucun.adsdk.c;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import com.DoEncrypt;
import com.uucun.adsdk.UUAppConnect;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b extends j {
    public String a;
    private String d;
    private String e;
    private Context f;
    private String g;
    private Notification h;
    private PendingIntent i;
    private NotificationManager j;
    private int k;
    private String l;

    public b(Context context, String str, String str2) {
        super(context);
        this.d = null;
        this.e = b.class.getSimpleName();
        this.g = null;
        this.a = "";
        this.i = null;
        this.l = "0";
        this.b = str;
        this.f = context;
        this.a = str2;
        this.d = com.uucun.adsdk.b.c.a();
        this.j = (NotificationManager) context.getSystemService("notification");
        a();
    }

    private void a() {
        this.k = (int) (Math.random() * 10000.0d);
        this.h = new Notification();
        this.h.icon = 17301633;
        this.i = PendingIntent.getActivity(this.f, 0, new Intent(), 67108864);
        this.h.setLatestEventInfo(this.f, "连接服务器...", "连接中...", this.i);
        this.j.notify(this.k, this.h);
    }

    @Override // com.uucun.adsdk.c.j
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public com.uucun.adsdk.d.f b(String str) {
        return com.uucun.adsdk.b.i.e(str);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public com.uucun.adsdk.d.f doInBackground(JSONObject... jSONObjectArr) {
        try {
            com.uucun.adsdk.b.c.a(jSONObjectArr[0], this.f);
            String string = jSONObjectArr[0].getString("app_key");
            String string2 = jSONObjectArr[0].getString("imei");
            if (string == null || TextUtils.isEmpty(string.trim()) || string2 == null || TextUtils.isEmpty(string2.trim())) {
                return null;
            }
            this.g = jSONObjectArr[0].getString("flag");
            jSONObjectArr[0].put("process_num", this.d);
            String string3 = jSONObjectArr[0].getString("app_key");
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(jSONObjectArr[0].getString("imei"));
            stringBuffer.append("|");
            com.uucun.adsdk.b.h.c(this.e, "AD ID： " + this.a);
            stringBuffer.append(this.a);
            stringBuffer.append("|");
            stringBuffer.append(com.uucun.adsdk.b.c.a());
            stringBuffer.append("|");
            if (jSONObjectArr[0].has("isInstall")) {
                this.l = jSONObjectArr[0].getString("isInstall");
                stringBuffer.append(this.l);
            } else {
                stringBuffer.append("0");
            }
            jSONObjectArr[0].put("valid_key", DoEncrypt.encodecrypt(string3, stringBuffer.toString()));
            jSONObjectArr[0].remove("ad_id");
            jSONObjectArr[0].remove("isInstall");
            return (com.uucun.adsdk.d.f) a(jSONObjectArr[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void onPostExecute(com.uucun.adsdk.d.f fVar) {
        com.uucun.adsdk.a.c.a().b(this);
        this.j.cancel(this.k);
        if (fVar == null) {
            UUAppConnect.showToast("下载出错,请重试.", this.f);
            return;
        }
        com.uucun.adsdk.b.h.b(this.e, "PackageName:" + fVar.a);
        com.uucun.adsdk.b.h.b(this.e, "Apk Url:" + fVar.b);
        com.uucun.adsdk.b.h.b(this.e, "Point:" + fVar.d + "");
        com.uucun.adsdk.b.h.b(this.e, "Version:" + fVar.e + "");
        if (com.uucun.adsdk.b.c.a(this.f, fVar.a, fVar.e)) {
            com.uucun.adsdk.a.b.a().a(new l(this.f, null, fVar, this.a, this.d, this.g, this.l));
        } else {
            com.uucun.adsdk.b.c.b(this.f, fVar.a);
        }
    }

    @Override // android.os.AsyncTask
    protected void onPreExecute() {
        super.onPreExecute();
        UUAppConnect.showToast("开始下载...", this.f);
    }
}
