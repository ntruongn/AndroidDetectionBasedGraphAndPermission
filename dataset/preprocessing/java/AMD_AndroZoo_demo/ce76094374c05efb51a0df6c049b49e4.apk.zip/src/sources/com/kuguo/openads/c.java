package com.kuguo.openads;

import android.app.Activity;
import android.content.Context;
import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class c implements View.OnClickListener {
    final /* synthetic */ u a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(u uVar) {
        this.a = uVar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        Context context;
        Context context2;
        context = this.a.a;
        if (context instanceof Activity) {
            context2 = this.a.a;
            Activity activity = (Activity) context2;
            activity.setResult(1200);
            activity.finish();
        }
    }
}
