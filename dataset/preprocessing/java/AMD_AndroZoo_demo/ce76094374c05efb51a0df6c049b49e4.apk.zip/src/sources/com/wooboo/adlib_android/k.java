package com.wooboo.adlib_android;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class k extends WebViewClient {
    private static final String[] z = {z(z("&23;\u0014,\u001a\n4\u001a:4\u0006>S")), z(z("=9\u000f`")), z(z(":4\f/\u001f-\u0013\u0015?\u0001;5\u0007?&;0/5\u0012-5\r=I")), z(z("?5\u0006-]%3\u0002>&;0Y")), z(z("(2\u0007(\u001c 8M3\u001d=9\r.](?\u00173\u001c'r'\u00132\u0005")), z(z("&23;\u0014,\u000f\u0017;\u0001=9\u0007z"))};
    final m a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(m mVar) {
        this.a = mVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static m a(k kVar) {
        return kVar.a;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'I';
                    break;
                case 1:
                    c = '\\';
                    break;
                case 2:
                    c = 'c';
                    break;
                case nb.p /* 3 */:
                    c = 'Z';
                    break;
                default:
                    c = 's';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 's');
        }
        return charArray;
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x0035, code lost:
    
        if (r0 != false) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x006d, code lost:
    
        if (r0 != false) goto L11;
     */
    @Override // android.webkit.WebViewClient
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onPageFinished(android.webkit.WebView r5, java.lang.String r6) {
        /*
            r4 = this;
            boolean r0 = com.wooboo.adlib_android.sc.C
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String[] r2 = com.wooboo.adlib_android.k.z
            r3 = 0
            r2 = r2[r3]
            r1.<init>(r2)
            java.lang.StringBuilder r1 = r1.append(r6)
            java.lang.String r1 = r1.toString()
            com.wooboo.adlib_android.mc.c(r1)
            boolean r1 = r5.canGoBack()
            if (r1 == 0) goto L37
            com.wooboo.adlib_android.m r1 = r4.a
            com.wooboo.adlib_android.AdActivity r1 = com.wooboo.adlib_android.m.a(r1)
            android.widget.Button r1 = r1.i
            android.graphics.drawable.BitmapDrawable r2 = new android.graphics.drawable.BitmapDrawable
            com.wooboo.adlib_android.m r3 = r4.a
            com.wooboo.adlib_android.AdActivity r3 = com.wooboo.adlib_android.m.a(r3)
            android.graphics.Bitmap r3 = r3.j
            r2.<init>(r3)
            r1.setBackgroundDrawable(r2)
            if (r0 == 0) goto L4f
        L37:
            com.wooboo.adlib_android.m r1 = r4.a
            com.wooboo.adlib_android.AdActivity r1 = com.wooboo.adlib_android.m.a(r1)
            android.widget.Button r1 = r1.i
            android.graphics.drawable.BitmapDrawable r2 = new android.graphics.drawable.BitmapDrawable
            com.wooboo.adlib_android.m r3 = r4.a
            com.wooboo.adlib_android.AdActivity r3 = com.wooboo.adlib_android.m.a(r3)
            android.graphics.Bitmap r3 = r3.k
            r2.<init>(r3)
            r1.setBackgroundDrawable(r2)
        L4f:
            boolean r1 = r5.canGoForward()
            if (r1 == 0) goto L6f
            com.wooboo.adlib_android.m r1 = r4.a
            com.wooboo.adlib_android.AdActivity r1 = com.wooboo.adlib_android.m.a(r1)
            android.widget.Button r1 = r1.l
            android.graphics.drawable.BitmapDrawable r2 = new android.graphics.drawable.BitmapDrawable
            com.wooboo.adlib_android.m r3 = r4.a
            com.wooboo.adlib_android.AdActivity r3 = com.wooboo.adlib_android.m.a(r3)
            android.graphics.Bitmap r3 = r3.m
            r2.<init>(r3)
            r1.setBackgroundDrawable(r2)
            if (r0 == 0) goto L87
        L6f:
            com.wooboo.adlib_android.m r0 = r4.a
            com.wooboo.adlib_android.AdActivity r0 = com.wooboo.adlib_android.m.a(r0)
            android.widget.Button r0 = r0.l
            android.graphics.drawable.BitmapDrawable r1 = new android.graphics.drawable.BitmapDrawable
            com.wooboo.adlib_android.m r2 = r4.a
            com.wooboo.adlib_android.AdActivity r2 = com.wooboo.adlib_android.m.a(r2)
            android.graphics.Bitmap r2 = r2.n
            r1.<init>(r2)
            r0.setBackgroundDrawable(r1)
        L87:
            super.onPageFinished(r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.k.onPageFinished(android.webkit.WebView, java.lang.String):void");
    }

    @Override // android.webkit.WebViewClient
    public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
        super.onPageStarted(webView, str, bitmap);
        mc.c(z[5] + str);
    }

    @Override // android.webkit.WebViewClient
    public boolean shouldOverrideUrlLoading(WebView webView, String str) {
        mc.c(z[2] + str);
        if (str.indexOf(z[1]) == 0) {
            Intent intent = new Intent();
            intent.setAction(z[4]);
            intent.setData(Uri.parse(str));
            intent.setFlags(268435456);
            m.a(this.a).startActivity(intent);
        } else {
            mc.c(z[3] + str);
            webView.loadUrl(str);
            webView.setDownloadListener(new x(this));
        }
        return true;
    }
}
