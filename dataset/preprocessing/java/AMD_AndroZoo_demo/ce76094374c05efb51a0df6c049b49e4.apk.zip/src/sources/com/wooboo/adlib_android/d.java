package com.wooboo.adlib_android;

import android.app.AlertDialog;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.Message;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class d extends Handler {
    private static final String[] z = {z(z("^m\bPJ^a\u0001FJ^~\u0001U")), z(z("Rh\u0014P")), z(z("uh\u000e\u0011@Y}@UGEy\fPW\u0016h\u000e\u0011FWe\u0006pJ``\u0005F\u0002Fe\u0005P]S)\u0003YKUb@AODh\rB\u0000"))};

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '6';
                    break;
                case 1:
                    c = '\t';
                    break;
                case 2:
                    c = '`';
                    break;
                case nb.p /* 3 */:
                    c = '1';
                    break;
                default:
                    c = '.';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '.');
        }
        return charArray;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        switch (message.what) {
            case 1:
                ((AlertDialog.Builder) message.obj).show();
                if (!sc.C) {
                    return;
                }
                break;
            case 2:
                break;
            default:
                return;
        }
        try {
            hb hbVar = (hb) message.obj;
            if (hbVar != null) {
                try {
                    if (!hbVar.equals("")) {
                        byte[] byteArray = message.getData().getByteArray(z[1]);
                        synchronized (this) {
                            sc.a = true;
                            n nVar = new n(hbVar, HalfAdView.h(), true, HalfAdView.getAdHeight(), HalfAdView.a(), sc.n, byteArray, 1, HalfAdView.i());
                            HalfAdView.close();
                            HalfAdView.a(new RelativeLayout(HalfAdView.h()));
                            HalfAdView.j().setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
                            nVar.a((ViewGroup) null);
                            HalfAdView.j().addView(nVar);
                            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(HalfAdView.b(), HalfAdView.c());
                            HalfAdView.a(new ImageButton(HalfAdView.h()));
                            layoutParams.addRule(11);
                            layoutParams.addRule(10);
                            HalfAdView.k().setId(2);
                            HalfAdView.k().setLayoutParams(layoutParams);
                            try {
                                HalfAdView.k().setBackgroundDrawable(new BitmapDrawable(HalfAdView.l()));
                            } catch (Exception e) {
                            }
                            HalfAdView.k().setOnClickListener(new yb(this));
                            try {
                                if (nVar.getVisibility() == 0) {
                                    HalfAdView.i().setContentView(HalfAdView.j());
                                    HalfAdView.i().setBackgroundDrawable(new BitmapDrawable());
                                    HalfAdView.i().setFocusable(true);
                                    try {
                                        HalfAdView.i().showAtLocation(HalfAdView.m(), 0, HalfAdView.n(), HalfAdView.o());
                                    } catch (Error e2) {
                                        try {
                                            if (HalfAdView.i() != null) {
                                                HalfAdView.i().dismiss();
                                                HalfAdView.close();
                                            }
                                            HalfAdView.a((HalfAdView) null);
                                            mc.c(z[0]);
                                        } catch (Exception e3) {
                                            throw e3;
                                        }
                                    }
                                    HalfAdView.i().update(HalfAdView.n(), HalfAdView.o(), HalfAdView.getAdWidth(), HalfAdView.getAdHeight());
                                    if (HalfAdView.p() != null) {
                                        try {
                                            HalfAdView.p().onReceiveAd(HalfAdView.i());
                                        } catch (Exception e4) {
                                            mc.b(e4.toString());
                                        }
                                    }
                                    HalfAdView.j().addView(HalfAdView.k(), layoutParams);
                                }
                            } catch (Exception e5) {
                                try {
                                    e5.printStackTrace();
                                    if (HalfAdView.i() != null) {
                                        HalfAdView.i().dismiss();
                                        HalfAdView.close();
                                    }
                                    HalfAdView.a((HalfAdView) null);
                                    mc.c(z[2]);
                                } catch (Exception e6) {
                                    throw e6;
                                }
                            }
                        }
                        return;
                    }
                } catch (Exception e7) {
                    throw e7;
                }
            }
            if (HalfAdView.p() != null) {
                try {
                    HalfAdView.p().onFailedToReceiveAd(HalfAdView.i());
                } catch (Exception e8) {
                    mc.b(e8.getMessage());
                }
            }
        } catch (Exception e9) {
            e9.printStackTrace();
        }
    }
}
