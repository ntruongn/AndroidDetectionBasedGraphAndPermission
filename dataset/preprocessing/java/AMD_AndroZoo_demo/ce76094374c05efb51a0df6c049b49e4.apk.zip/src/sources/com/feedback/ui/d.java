package com.feedback.ui;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class d {
    LinearLayout a;
    RelativeLayout b;
    TextView c;
    TextView d;
    View e;
    View f;
    final /* synthetic */ c g;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(c cVar) {
        this.g = cVar;
    }
}
