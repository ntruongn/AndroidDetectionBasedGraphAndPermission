package com.uucun.adsdk.view;

import android.os.Handler;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class d extends Handler {
    final /* synthetic */ OfferwallView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(OfferwallView offerwallView) {
        this.a = offerwallView;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                this.a.b((String) message.obj);
                return;
            case 2:
                String[] strArr = (String[]) message.obj;
                if (strArr == null || strArr.length != 3) {
                    return;
                }
                this.a.a(strArr[0], strArr[1], strArr[2]);
                return;
            default:
                return;
        }
    }
}
