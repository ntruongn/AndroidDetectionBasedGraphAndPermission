package com.uucun.adsdk.b;

import com.mobclick.android.UmengConstants;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class i {
    public static final String a = i.class.getSimpleName();

    public static com.uucun.adsdk.d.c a(String str) {
        if (str == null || str.trim().equals("")) {
            return null;
        }
        com.uucun.adsdk.d.c cVar = new com.uucun.adsdk.d.c();
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (jSONObject.has("code")) {
                cVar.a = jSONObject.getString("code");
            }
            if (jSONObject.has(UmengConstants.AtomKey_Message)) {
                cVar.b = jSONObject.getString(UmengConstants.AtomKey_Message);
            }
            if (!jSONObject.has("update_url")) {
                return cVar;
            }
            cVar.c = jSONObject.getString("update_url");
            return cVar;
        } catch (JSONException e) {
            h.a(a, "exception:" + e.getMessage());
            return null;
        }
    }

    public static com.uucun.adsdk.d.b b(String str) {
        if (str == null || str.trim().equals("")) {
            return null;
        }
        com.uucun.adsdk.d.b bVar = new com.uucun.adsdk.d.b();
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (jSONObject.has("code")) {
                bVar.a = jSONObject.getInt("code");
            }
            if (jSONObject.has(UmengConstants.AtomKey_Message)) {
                bVar.b = jSONObject.getString(UmengConstants.AtomKey_Message);
            }
            if (jSONObject.has("total")) {
                bVar.d = jSONObject.getInt("total");
            }
            if (!jSONObject.has("unit")) {
                return bVar;
            }
            bVar.c = jSONObject.getString("unit");
            return bVar;
        } catch (JSONException e) {
            h.a(a, "exception:" + e.getMessage());
            return null;
        }
    }

    public static ArrayList c(String str) {
        if (str == null || str.trim().equals("")) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        try {
            JSONObject jSONObject = new JSONObject(str);
            Iterator<String> keys = jSONObject.keys();
            while (keys.hasNext()) {
                JSONObject jSONObject2 = jSONObject.getJSONObject(keys.next());
                if (jSONObject2 != null) {
                    com.uucun.adsdk.d.e eVar = new com.uucun.adsdk.d.e();
                    if (jSONObject2.has("ad_id")) {
                        eVar.c = jSONObject2.getString("ad_id");
                    }
                    if (jSONObject2.has("img_url")) {
                        eVar.b = jSONObject2.getString("img_url");
                    }
                    if (jSONObject2.has("click_url")) {
                        eVar.a = jSONObject2.getString("click_url");
                    }
                    if (jSONObject2.has("point")) {
                        eVar.e = jSONObject2.getInt("point");
                    }
                    if (jSONObject2.has("unit")) {
                        eVar.f = jSONObject2.getString("unit");
                    }
                    if (jSONObject2.has("ad_package_name")) {
                        eVar.g = jSONObject2.getString("ad_package_name");
                    }
                    if (jSONObject2.has("balance_type_name")) {
                        eVar.j = jSONObject2.getString("balance_type_name");
                    }
                    if (jSONObject2.has("is_display")) {
                        eVar.i = jSONObject2.getString("is_display");
                        if (eVar.i != null) {
                            eVar.i = eVar.i.trim();
                        }
                    }
                    arrayList.add(eVar);
                }
            }
        } catch (JSONException e) {
            h.a(a, "exception:" + e.getMessage());
        }
        return arrayList;
    }

    public static com.uucun.adsdk.d.a d(String str) {
        if (str == null || str.trim().equals("")) {
            return null;
        }
        com.uucun.adsdk.d.a aVar = new com.uucun.adsdk.d.a();
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (jSONObject.has("code")) {
                aVar.a = jSONObject.getInt("code");
            }
            if (jSONObject.has(UmengConstants.AtomKey_Message)) {
                aVar.b = jSONObject.getString(UmengConstants.AtomKey_Message);
            }
            if (jSONObject.has("total")) {
                aVar.d = jSONObject.getInt("total");
            }
            if (!jSONObject.has("unit")) {
                return aVar;
            }
            aVar.c = jSONObject.getString("unit");
            return aVar;
        } catch (JSONException e) {
            h.a(a, "exception:" + e.getMessage());
            return null;
        }
    }

    public static com.uucun.adsdk.d.f e(String str) {
        if (str == null || str.trim().equals("")) {
            return null;
        }
        com.uucun.adsdk.d.f fVar = new com.uucun.adsdk.d.f();
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (jSONObject.has("ad_package_name")) {
                fVar.a = jSONObject.getString("ad_package_name");
                if (fVar.a != null) {
                    fVar.a = fVar.a.trim();
                }
            }
            if (jSONObject.has("apk_url")) {
                fVar.b = jSONObject.getString("apk_url");
            }
            if (jSONObject.has("ad_name")) {
                fVar.c = jSONObject.getString("ad_name");
            }
            if (jSONObject.has("point")) {
                fVar.d = jSONObject.getInt("point");
            }
            if (!jSONObject.has("version_code")) {
                return fVar;
            }
            fVar.e = jSONObject.getInt("version_code");
            return fVar;
        } catch (JSONException e) {
            h.a(a, "exception:" + e.getMessage());
            return null;
        }
    }
}
