package com.kuguo.pushads;

import com.wooboo.adlib_android.nb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class j {
    protected String a = "";
    protected String b = "";
    protected long c = -1;
    protected String d = "";
    protected byte e = 0;
    protected int f = -1;
    protected String g = "";
    protected int h = -1;
    protected String i = "";
    protected Integer j = -1;
    protected String k = "推荐";
    protected String l = "应用软件";
    protected int m = 1048576;
    protected String n = "1.0";
    protected String o = "";
    protected String p = "";
    protected int q = 1;
    protected int r = 0;
    protected String s = "";
    protected int t = 1;
    protected int u = 0;
    protected String v = "";
    protected int w = 1;
    protected int x = 1;
    protected int y = 0;

    /* JADX INFO: Access modifiers changed from: protected */
    public static j[] a(byte[] bArr) {
        int i;
        if (bArr[0] == -1) {
            return null;
        }
        byte[] bArr2 = new byte[2];
        System.arraycopy(bArr, 3, bArr2, 0, 2);
        int c = b.c(bArr2);
        int i2 = 5;
        j[] jVarArr = new j[c];
        int i3 = 0;
        while (i3 < c) {
            j jVar = new j();
            while (true) {
                i = i2 + 1;
                byte b = bArr[i2];
                if (b != -1) {
                    switch (b) {
                        case 2:
                            byte[] bArr3 = new byte[2];
                            System.arraycopy(bArr, i, bArr3, 0, 2);
                            int c2 = b.c(bArr3);
                            int i4 = i + 2;
                            byte[] bArr4 = new byte[c2];
                            System.arraycopy(bArr, i4, bArr4, 0, c2);
                            jVar.a = new String(bArr4, "UTF-8");
                            i2 = c2 + i4;
                            break;
                        case nb.p /* 3 */:
                            byte[] bArr5 = new byte[2];
                            System.arraycopy(bArr, i, bArr5, 0, 2);
                            int c3 = b.c(bArr5);
                            int i5 = i + 2;
                            byte[] bArr6 = new byte[c3];
                            System.arraycopy(bArr, i5, bArr6, 0, c3);
                            jVar.b = new String(bArr6, "UTF-8");
                            i2 = c3 + i5;
                            break;
                        case 4:
                            byte[] bArr7 = new byte[2];
                            System.arraycopy(bArr, i, bArr7, 0, 2);
                            int c4 = b.c(bArr7);
                            int i6 = i + 2;
                            byte[] bArr8 = new byte[c4];
                            System.arraycopy(bArr, i6, bArr8, 0, c4);
                            jVar.c = b.a(bArr8);
                            i2 = c4 + i6;
                            break;
                        case 5:
                            byte[] bArr9 = new byte[2];
                            System.arraycopy(bArr, i, bArr9, 0, 2);
                            int c5 = b.c(bArr9);
                            int i7 = i + 2;
                            byte[] bArr10 = new byte[c5];
                            System.arraycopy(bArr, i7, bArr10, 0, c5);
                            jVar.d = new String(bArr10);
                            i2 = c5 + i7;
                            break;
                        case nb.s /* 6 */:
                            int i8 = i + 2;
                            i2 = i8 + 1;
                            jVar.e = bArr[i8];
                            break;
                        case nb.t /* 7 */:
                            byte[] bArr11 = new byte[2];
                            System.arraycopy(bArr, i, bArr11, 0, 2);
                            int c6 = b.c(bArr11);
                            int i9 = i + 2;
                            byte[] bArr12 = new byte[c6];
                            System.arraycopy(bArr, i9, bArr12, 0, c6);
                            jVar.g = new String(bArr12, "UTF-8");
                            i2 = c6 + i9;
                            break;
                        case 8:
                            byte[] bArr13 = new byte[2];
                            System.arraycopy(bArr, i, bArr13, 0, 2);
                            int c7 = b.c(bArr13);
                            int i10 = i + 2;
                            byte[] bArr14 = new byte[c7];
                            System.arraycopy(bArr, i10, bArr14, 0, c7);
                            jVar.h = b.b(bArr14);
                            i2 = c7 + i10;
                            break;
                        case 9:
                            byte[] bArr15 = new byte[2];
                            System.arraycopy(bArr, i, bArr15, 0, 2);
                            int c8 = b.c(bArr15);
                            int i11 = i + 2;
                            byte[] bArr16 = new byte[c8];
                            System.arraycopy(bArr, i11, bArr16, 0, c8);
                            jVar.i = new String(bArr16, "UTF-8");
                            i2 = c8 + i11;
                            break;
                        case 10:
                            byte[] bArr17 = new byte[2];
                            System.arraycopy(bArr, i, bArr17, 0, 2);
                            int c9 = b.c(bArr17);
                            int i12 = i + 2;
                            byte[] bArr18 = new byte[c9];
                            System.arraycopy(bArr, i12, bArr18, 0, c9);
                            jVar.k = new String(bArr18, "UTF-8");
                            i2 = c9 + i12;
                            break;
                        case 11:
                            byte[] bArr19 = new byte[2];
                            System.arraycopy(bArr, i, bArr19, 0, 2);
                            int c10 = b.c(bArr19);
                            int i13 = i + 2;
                            byte[] bArr20 = new byte[c10];
                            System.arraycopy(bArr, i13, bArr20, 0, c10);
                            jVar.l = new String(bArr20, "UTF-8");
                            i2 = c10 + i13;
                            break;
                        case 12:
                            byte[] bArr21 = new byte[2];
                            System.arraycopy(bArr, i, bArr21, 0, 2);
                            int c11 = b.c(bArr21);
                            int i14 = i + 2;
                            byte[] bArr22 = new byte[c11];
                            System.arraycopy(bArr, i14, bArr22, 0, c11);
                            jVar.m = b.b(bArr22);
                            i2 = c11 + i14;
                            break;
                        case 13:
                            byte[] bArr23 = new byte[2];
                            System.arraycopy(bArr, i, bArr23, 0, 2);
                            int c12 = b.c(bArr23);
                            int i15 = i + 2;
                            byte[] bArr24 = new byte[c12];
                            System.arraycopy(bArr, i15, bArr24, 0, c12);
                            jVar.n = new String(bArr24, "UTF-8");
                            i2 = c12 + i15;
                            break;
                        case 14:
                            byte[] bArr25 = new byte[2];
                            System.arraycopy(bArr, i, bArr25, 0, 2);
                            int c13 = b.c(bArr25);
                            int i16 = i + 2;
                            byte[] bArr26 = new byte[c13];
                            System.arraycopy(bArr, i16, bArr26, 0, c13);
                            jVar.o = new String(bArr26, "UTF-8");
                            i2 = c13 + i16;
                            break;
                        case 15:
                            byte[] bArr27 = new byte[2];
                            System.arraycopy(bArr, i, bArr27, 0, 2);
                            int c14 = b.c(bArr27);
                            int i17 = i + 2;
                            byte[] bArr28 = new byte[c14];
                            System.arraycopy(bArr, i17, bArr28, 0, c14);
                            jVar.p = new String(bArr28, "UTF-8");
                            i2 = c14 + i17;
                            break;
                        case 16:
                            byte[] bArr29 = new byte[2];
                            System.arraycopy(bArr, i, bArr29, 0, 2);
                            int c15 = b.c(bArr29);
                            int i18 = i + 2;
                            byte[] bArr30 = new byte[c15];
                            System.arraycopy(bArr, i18, bArr30, 0, c15);
                            jVar.q = b.b(bArr30);
                            i2 = c15 + i18;
                            break;
                        case 17:
                            byte[] bArr31 = new byte[2];
                            System.arraycopy(bArr, i, bArr31, 0, 2);
                            int c16 = b.c(bArr31);
                            int i19 = i + 2;
                            byte[] bArr32 = new byte[c16];
                            System.arraycopy(bArr, i19, bArr32, 0, c16);
                            jVar.r = b.b(bArr32);
                            i2 = c16 + i19;
                            break;
                        case 18:
                            byte[] bArr33 = new byte[2];
                            System.arraycopy(bArr, i, bArr33, 0, 2);
                            int c17 = b.c(bArr33);
                            int i20 = i + 2;
                            byte[] bArr34 = new byte[c17];
                            System.arraycopy(bArr, i20, bArr34, 0, c17);
                            jVar.s = new String(bArr34, "UTF-8");
                            i2 = c17 + i20;
                            break;
                        case 19:
                            byte[] bArr35 = new byte[2];
                            System.arraycopy(bArr, i, bArr35, 0, 2);
                            int c18 = b.c(bArr35);
                            int i21 = i + 2;
                            byte[] bArr36 = new byte[c18];
                            System.arraycopy(bArr, i21, bArr36, 0, c18);
                            jVar.t = b.b(bArr36);
                            i2 = c18 + i21;
                            break;
                        case 20:
                            byte[] bArr37 = new byte[2];
                            System.arraycopy(bArr, i, bArr37, 0, 2);
                            int c19 = b.c(bArr37);
                            int i22 = i + 2;
                            byte[] bArr38 = new byte[c19];
                            System.arraycopy(bArr, i22, bArr38, 0, c19);
                            jVar.u = b.b(bArr38);
                            i2 = c19 + i22;
                            break;
                        case 21:
                            byte[] bArr39 = new byte[2];
                            System.arraycopy(bArr, i, bArr39, 0, 2);
                            int c20 = b.c(bArr39);
                            int i23 = i + 2;
                            byte[] bArr40 = new byte[c20];
                            System.arraycopy(bArr, i23, bArr40, 0, c20);
                            jVar.v = new String(bArr40, "UTF-8");
                            i2 = c20 + i23;
                            break;
                        case 22:
                            byte[] bArr41 = new byte[2];
                            System.arraycopy(bArr, i, bArr41, 0, 2);
                            int c21 = b.c(bArr41);
                            int i24 = i + 2;
                            byte[] bArr42 = new byte[c21];
                            System.arraycopy(bArr, i24, bArr42, 0, c21);
                            jVar.w = b.b(bArr42);
                            i2 = c21 + i24;
                            break;
                        case 23:
                            byte[] bArr43 = new byte[2];
                            System.arraycopy(bArr, i, bArr43, 0, 2);
                            int c22 = b.c(bArr43);
                            int i25 = i + 2;
                            byte[] bArr44 = new byte[c22];
                            System.arraycopy(bArr, i25, bArr44, 0, c22);
                            jVar.x = b.b(bArr44);
                            i2 = c22 + i25;
                            break;
                        case 24:
                            byte[] bArr45 = new byte[2];
                            System.arraycopy(bArr, i, bArr45, 0, 2);
                            int c23 = b.c(bArr45);
                            int i26 = i + 2;
                            byte[] bArr46 = new byte[c23];
                            System.arraycopy(bArr, i26, bArr46, 0, c23);
                            jVar.y = b.b(bArr46);
                            i2 = c23 + i26;
                            break;
                        default:
                            byte[] bArr47 = new byte[2];
                            System.arraycopy(bArr, i, bArr47, 0, 2);
                            i2 = b.c(bArr47) + i + 2;
                            break;
                    }
                }
            }
            jVarArr[i3] = jVar;
            i3++;
            i2 = i + 2;
        }
        return jVarArr;
    }

    public String a() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(this.a);
        stringBuffer.append("|#*");
        stringBuffer.append(this.b);
        stringBuffer.append("|#*");
        stringBuffer.append(this.d);
        stringBuffer.append("|#*");
        stringBuffer.append(this.c);
        stringBuffer.append("|#*");
        stringBuffer.append((int) this.e);
        stringBuffer.append("|#*");
        stringBuffer.append(this.g);
        stringBuffer.append("|#*");
        stringBuffer.append(this.h);
        stringBuffer.append("|#*");
        stringBuffer.append(this.i);
        stringBuffer.append("|#*");
        stringBuffer.append(this.j);
        stringBuffer.append("|#*");
        stringBuffer.append(this.k);
        stringBuffer.append("|#*");
        stringBuffer.append(this.l);
        stringBuffer.append("|#*");
        stringBuffer.append(this.m);
        stringBuffer.append("|#*");
        stringBuffer.append(this.n);
        stringBuffer.append("|#*");
        stringBuffer.append(this.o);
        stringBuffer.append("|#*");
        stringBuffer.append(this.p);
        stringBuffer.append("|#*");
        stringBuffer.append(this.q);
        stringBuffer.append("|#*");
        stringBuffer.append(this.r);
        stringBuffer.append("|#*");
        stringBuffer.append(this.v);
        stringBuffer.append("|#*");
        stringBuffer.append(this.s);
        stringBuffer.append("|#*");
        stringBuffer.append(this.u);
        stringBuffer.append("|#*");
        stringBuffer.append(this.x);
        stringBuffer.append("|#*");
        stringBuffer.append(this.y);
        return stringBuffer.toString();
    }

    public boolean a(String str) {
        String[] a = a.a(str, "|#*");
        if (a == null) {
            return false;
        }
        try {
            this.a = a[0];
            this.b = a[1];
            this.d = a[2];
            this.c = Long.valueOf(a[3]).longValue();
            this.e = Byte.valueOf(a[4]).byteValue();
            this.g = a[5];
            this.h = Integer.valueOf(a[6]).intValue();
            this.i = a[7];
            this.j = Integer.valueOf(a[8]);
            this.k = a[9];
            this.l = a[10];
            this.m = Integer.valueOf(a[11]).intValue();
            this.n = a[12];
            this.o = a[13];
            this.p = a[14];
            this.q = Integer.valueOf(a[15]).intValue();
            this.r = Integer.valueOf(a[16]).intValue();
            this.v = a[17];
            this.s = a[18];
            this.u = Integer.valueOf(a[19]).intValue();
            this.x = Integer.valueOf(a[20]).intValue();
            this.y = Integer.valueOf(a[21]).intValue();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void b() {
        a.a("address: " + this.a);
        a.a("body: " + this.b);
        a.a("date: " + this.c);
        a.a("type: " + ((int) this.e));
        a.a("url: " + this.d);
        a.a("apkName: " + this.g);
        a.a("advertId: " + this.h);
        a.a("apkPackage: " + this.i);
        a.a("title" + this.k);
        a.a("appType: " + this.l);
        a.a("appSize: " + this.m);
        a.a("appVersion: " + this.n);
        a.a("iconUrl: " + this.o);
        a.a("captureUrls: " + this.p);
        a.a("showDialog: " + this.q);
        a.a("autoDownload: " + this.r);
        a.a("forceClick: " + this.t);
        a.a("autoInstall: " + this.u);
        a.a("permissions: " + this.v);
        a.a("marketPackage: " + this.s);
        a.a("permissions: " + this.v);
        a.a("nextRequest: " + this.w);
        a.a("vibrate: " + this.x);
        a.a("testAd: " + this.y);
        a.a("----------------------------");
    }

    public String toString() {
        return a();
    }
}
