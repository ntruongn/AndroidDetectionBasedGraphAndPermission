package com.wooboo.adlib_android;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class bb implements nc {
    final xc a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public bb(xc xcVar) {
        this.a = xcVar;
    }

    @Override // com.wooboo.adlib_android.nc
    public void a() {
        xc.a(this.a).setFocusable(false);
        xc.a(this.a).setVisibility(8);
    }
}
