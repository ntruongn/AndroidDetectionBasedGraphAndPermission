package com.wooboo.adlib_android;

import android.graphics.Bitmap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class xb {
    public Bitmap a;
    public int b;

    public xb(Bitmap bitmap, int i) {
        this.a = bitmap;
        this.b = i;
    }
}
