package com.wooboo.adlib_android;

import android.content.Context;
import android.os.Environment;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.regex.Pattern;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class kb {
    private static final String[] z = {z(z("Drp:5Ly")), z(z("Axi$$['b15\t{l8$\t{w;,\t\u007f| $\tmw;\"Lnvt$[oj&`")), z(z("Axi$$['q<$\t{l8$\ttvt/\\qiu")), z(z("Axi$$['b15\t\u007f| $Z=c&.D=c=-L=u&.Jxv'aLow;3\b")), z(z("r|(.\u0000\u0004gX\u007f{\u00062^\n\u001dZ@/"))};

    kb() {
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0037 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.io.File a(byte[] r5, java.lang.String r6) {
        /*
            r2 = 0
            r4 = 1
            java.io.File r0 = new java.io.File     // Catch: java.lang.Exception -> L1a java.lang.Throwable -> L34
            r0.<init>(r6)     // Catch: java.lang.Exception -> L1a java.lang.Throwable -> L34
            java.io.FileOutputStream r3 = new java.io.FileOutputStream     // Catch: java.lang.Throwable -> L34 java.lang.Exception -> L50
            r3.<init>(r0)     // Catch: java.lang.Throwable -> L34 java.lang.Exception -> L50
            java.io.BufferedOutputStream r1 = new java.io.BufferedOutputStream     // Catch: java.lang.Throwable -> L34 java.lang.Exception -> L50
            r1.<init>(r3)     // Catch: java.lang.Throwable -> L34 java.lang.Exception -> L50
            r1.write(r5)     // Catch: java.lang.Throwable -> L4d java.lang.Exception -> L53
            if (r1 == 0) goto L19
            r1.close()     // Catch: java.io.IOException -> L44
        L19:
            return r0
        L1a:
            r0 = move-exception
            r1 = r2
            r0 = r2
        L1d:
            java.lang.String[] r2 = com.wooboo.adlib_android.kb.z     // Catch: java.lang.Throwable -> L4d
            r3 = 1
            r2 = r2[r3]     // Catch: java.lang.Throwable -> L4d
            com.wooboo.adlib_android.mc.c(r2)     // Catch: java.lang.Throwable -> L4d
            if (r1 == 0) goto L19
            r1.close()     // Catch: java.io.IOException -> L2b
            goto L19
        L2b:
            r1 = move-exception
            java.lang.String[] r1 = com.wooboo.adlib_android.kb.z
            r1 = r1[r4]
            com.wooboo.adlib_android.mc.c(r1)
            goto L19
        L34:
            r0 = move-exception
        L35:
            if (r2 == 0) goto L3a
            r2.close()     // Catch: java.io.IOException -> L3b
        L3a:
            throw r0
        L3b:
            r1 = move-exception
            java.lang.String[] r1 = com.wooboo.adlib_android.kb.z
            r1 = r1[r4]
            com.wooboo.adlib_android.mc.c(r1)
            goto L3a
        L44:
            r1 = move-exception
            java.lang.String[] r1 = com.wooboo.adlib_android.kb.z
            r1 = r1[r4]
            com.wooboo.adlib_android.mc.c(r1)
            goto L19
        L4d:
            r0 = move-exception
            r2 = r1
            goto L35
        L50:
            r1 = move-exception
            r1 = r2
            goto L1d
        L53:
            r2 = move-exception
            goto L1d
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.kb.a(byte[], java.lang.String):java.io.File");
    }

    public static String a(Context context, String str) throws FileNotFoundException {
        String str2 = "";
        try {
            FileInputStream openFileInput = context.openFileInput(str);
            StringBuffer stringBuffer = new StringBuffer();
            while (true) {
                int read = openFileInput.read();
                if (read == -1) {
                    openFileInput.close();
                    str2 = stringBuffer.toString();
                    return str2;
                }
                stringBuffer.append((char) read);
            }
        } catch (IOException e) {
            return str2;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0026, code lost:
    
        r2.append(",");
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x002b, code lost:
    
        r0 = r0 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x002e, code lost:
    
        if (r0 < r5.length) goto L8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0030, code lost:
    
        if (r1 != false) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0036, code lost:
    
        return r2.toString();
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x000d, code lost:
    
        if (r1 != false) goto L8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x000f, code lost:
    
        r2.append(new java.lang.StringBuilder(java.lang.String.valueOf(r5[r0])).toString());
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0024, code lost:
    
        if (r0 >= (r5.length - 1)) goto L12;
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:13:0x002e -> B:7:0x000f). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:14:0x0030 -> B:8:0x0021). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String a(int[] r5) {
        /*
            boolean r1 = com.wooboo.adlib_android.sc.C
            if (r5 == 0) goto L37
            int r0 = r5.length
            if (r0 == 0) goto L37
            java.lang.StringBuffer r2 = new java.lang.StringBuffer
            r2.<init>()
            r0 = 0
            if (r1 == 0) goto L2d
        Lf:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r4 = r5[r0]
            java.lang.String r4 = java.lang.String.valueOf(r4)
            r3.<init>(r4)
            java.lang.String r3 = r3.toString()
            r2.append(r3)
        L21:
            int r3 = r5.length
            int r3 = r3 + (-1)
            if (r0 >= r3) goto L2b
            java.lang.String r3 = ","
            r2.append(r3)
        L2b:
            int r0 = r0 + 1
        L2d:
            int r3 = r5.length
            if (r0 < r3) goto Lf
            if (r1 != 0) goto L21
            java.lang.String r0 = r2.toString()
        L36:
            return r0
        L37:
            r0 = 0
            goto L36
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.kb.a(int[]):java.lang.String");
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x0035 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void a(android.content.Context r5, java.io.File r6, java.lang.String r7) {
        /*
            r3 = 1
            r1 = 0
            java.io.FileOutputStream r2 = new java.io.FileOutputStream     // Catch: java.lang.Exception -> L19 java.lang.Throwable -> L32
            r2.<init>(r6)     // Catch: java.lang.Exception -> L19 java.lang.Throwable -> L32
            java.io.BufferedOutputStream r0 = new java.io.BufferedOutputStream     // Catch: java.lang.Exception -> L19 java.lang.Throwable -> L32
            r0.<init>(r2)     // Catch: java.lang.Exception -> L19 java.lang.Throwable -> L32
            byte[] r1 = r7.getBytes()     // Catch: java.lang.Throwable -> L4b java.lang.Exception -> L50
            r0.write(r1)     // Catch: java.lang.Throwable -> L4b java.lang.Exception -> L50
            if (r0 == 0) goto L18
            r0.close()     // Catch: java.io.IOException -> L42
        L18:
            return
        L19:
            r0 = move-exception
            r0 = r1
        L1b:
            java.lang.String[] r1 = com.wooboo.adlib_android.kb.z     // Catch: java.lang.Throwable -> L4b
            r2 = 1
            r1 = r1[r2]     // Catch: java.lang.Throwable -> L4b
            com.wooboo.adlib_android.mc.c(r1)     // Catch: java.lang.Throwable -> L4b
            if (r0 == 0) goto L18
            r0.close()     // Catch: java.io.IOException -> L29
            goto L18
        L29:
            r0 = move-exception
            java.lang.String[] r0 = com.wooboo.adlib_android.kb.z
            r0 = r0[r3]
            com.wooboo.adlib_android.mc.c(r0)
            goto L18
        L32:
            r0 = move-exception
        L33:
            if (r1 == 0) goto L38
            r1.close()     // Catch: java.io.IOException -> L39
        L38:
            throw r0
        L39:
            r1 = move-exception
            java.lang.String[] r1 = com.wooboo.adlib_android.kb.z
            r1 = r1[r3]
            com.wooboo.adlib_android.mc.c(r1)
            goto L38
        L42:
            r0 = move-exception
            java.lang.String[] r0 = com.wooboo.adlib_android.kb.z
            r0 = r0[r3]
            com.wooboo.adlib_android.mc.c(r0)
            goto L18
        L4b:
            r1 = move-exception
            r4 = r1
            r1 = r0
            r0 = r4
            goto L33
        L50:
            r1 = move-exception
            goto L1b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.kb.a(android.content.Context, java.io.File, java.lang.String):void");
    }

    public static void a(Context context, String str, byte[] bArr) {
        try {
            FileOutputStream openFileOutput = context.openFileOutput(str, 2);
            openFileOutput.write(bArr);
            openFileOutput.flush();
            openFileOutput.close();
        } catch (FileNotFoundException e) {
        } catch (IOException e2) {
        }
    }

    public static boolean a() {
        try {
            return Environment.getExternalStorageState().equals(z[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean a(String str) {
        return Pattern.compile(z[4]).matcher(str).matches();
    }

    public static byte[] a(File file) {
        boolean z2 = sc.C;
        byte[] bArr = (byte[]) null;
        try {
        } catch (IOException e) {
            mc.c(z[3]);
        }
        if (file == null) {
            mc.c(z[2]);
            return null;
        }
        FileInputStream fileInputStream = new FileInputStream(file);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(4096);
        byte[] bArr2 = new byte[4096];
        while (true) {
            int read = fileInputStream.read(bArr2);
            if (read == -1) {
                try {
                    fileInputStream.close();
                    byteArrayOutputStream.close();
                    if (!z2) {
                        break;
                    }
                } catch (IOException e2) {
                    throw e2;
                }
            }
            byteArrayOutputStream.write(bArr2, 0, read);
        }
        bArr = byteArrayOutputStream.toByteArray();
        return bArr;
    }

    public static byte[] b(File file) {
        boolean z2 = sc.C;
        byte[] bArr = (byte[]) null;
        try {
        } catch (IOException e) {
            mc.c(z[3]);
        }
        if (file == null) {
            mc.c(z[2]);
            return null;
        }
        FileInputStream fileInputStream = new FileInputStream(file);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
        byte[] bArr2 = new byte[1024];
        while (true) {
            int read = fileInputStream.read(bArr2);
            if (read == -1) {
                try {
                    fileInputStream.close();
                    byteArrayOutputStream.close();
                    if (!z2) {
                        break;
                    }
                } catch (IOException e2) {
                    throw e2;
                }
            }
            byteArrayOutputStream.write(bArr2, 0, read);
        }
        bArr = byteArrayOutputStream.toByteArray();
        return bArr;
    }

    public static int[] b(String str) {
        if (str == null || "".equals(str.trim())) {
            return null;
        }
        String[] split = str.split(",");
        int[] iArr = new int[split.length];
        for (int i = 0; i < split.length; i++) {
            iArr[i] = Integer.parseInt(split[i]);
        }
        return iArr;
    }

    public static boolean c(String str) {
        return str == null || "".equals(str) || str.trim().equals("");
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = ')';
                    break;
                case 1:
                    c = 29;
                    break;
                case 2:
                    c = 5;
                    break;
                case nb.p /* 3 */:
                    c = 'T';
                    break;
                default:
                    c = 'A';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'A');
        }
        return charArray;
    }
}
