package com.wooboo.adlib_android;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class mb {
    private static final String[] z = {z(z("s\u000fj8)K@V?4R\u0005wz%K\u0015i>(K\u0014%</J\u0004%..A@h55P@v//P\u0001g6#\u0004\u0001az%Q\u0012w?(P\f|")), z(z("s\u000fj8)K?U\u0013\u0002\u0004\u0004j?5\u0004\u000ej.fE\u0003q30E\u0014`>")), z(z("p\u0005i?'@?U\u0013\u0002\u0004\u0004j?5\u0004\u000ej.fA\u0018l)2")), z(z("k\u0014m?4\u0004\u0015k1(K\u0017kz#V\u0012j(")), z(z("p\u0005i?'@@V?4R\u0005wz%K\u0015i>(K\u0014%</J\u0004%..A@h55P@v//P\u0001g6#\u0004\u0001az%Q\u0012w?(P\f|")), z(z("s\u000fj8)K?U\u0013\u0002\u0004\u0004j?5\u0004\u000ej.fA\u0018l)2")), z(z("s\u000fj8)K@V?4R\u0005wz$Q\u0013|")), z(z("p\u0005i?'@@V?4R\u0005wz$Q\u0013|")), z(z("q4Cw~")), z(z("p\u0005i?'@?U\u0013\u0002\u0004\u0004j?5\u0004\u000ej.fE\u0003q30E\u0014`>"))};
    static final byte[] a = {20, 10, 1, 20};

    mb() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static ArrayList a(byte[] bArr) {
        String str;
        String str2;
        String str3;
        String str4;
        byte b;
        byte b2 = 0;
        boolean z2 = sc.C;
        try {
            try {
                try {
                    if (bArr.length == 7) {
                        try {
                            try {
                                try {
                                    try {
                                        if (bArr[6] == -32) {
                                            if (sc.n) {
                                                mc.c(z[5]);
                                                if (!z2) {
                                                    return null;
                                                }
                                            }
                                            mc.c(z[2]);
                                            if (!z2) {
                                                return null;
                                            }
                                        }
                                        try {
                                            try {
                                                try {
                                                    try {
                                                        if (bArr[6] == -31) {
                                                            if (sc.n) {
                                                                mc.c(z[6]);
                                                                if (!z2) {
                                                                    return null;
                                                                }
                                                            }
                                                            mc.c(z[7]);
                                                            if (!z2) {
                                                                return null;
                                                            }
                                                        }
                                                        try {
                                                            try {
                                                                try {
                                                                    try {
                                                                        if (bArr[6] == -30) {
                                                                            if (sc.n) {
                                                                                mc.c(z[1]);
                                                                                if (!z2) {
                                                                                    return null;
                                                                                }
                                                                            }
                                                                            mc.c(z[9]);
                                                                            if (!z2) {
                                                                                return null;
                                                                            }
                                                                        }
                                                                        try {
                                                                            try {
                                                                                try {
                                                                                    if (bArr[6] == -29) {
                                                                                        if (sc.n) {
                                                                                            mc.c(z[0]);
                                                                                            if (!z2) {
                                                                                                return null;
                                                                                            }
                                                                                        }
                                                                                        mc.c(z[4]);
                                                                                        if (!z2) {
                                                                                            return null;
                                                                                        }
                                                                                    }
                                                                                    if (bArr[6] != -28) {
                                                                                        return null;
                                                                                    }
                                                                                    mc.c(z[3]);
                                                                                    return null;
                                                                                } catch (UnsupportedEncodingException e) {
                                                                                    throw e;
                                                                                }
                                                                            } catch (UnsupportedEncodingException e2) {
                                                                                throw e2;
                                                                            }
                                                                        } catch (UnsupportedEncodingException e3) {
                                                                            throw e3;
                                                                        }
                                                                    } catch (UnsupportedEncodingException e4) {
                                                                        throw e4;
                                                                    }
                                                                } catch (UnsupportedEncodingException e5) {
                                                                    throw e5;
                                                                }
                                                            } catch (UnsupportedEncodingException e6) {
                                                                throw e6;
                                                            }
                                                        } catch (UnsupportedEncodingException e7) {
                                                            throw e7;
                                                        }
                                                    } catch (UnsupportedEncodingException e8) {
                                                        throw e8;
                                                    }
                                                } catch (UnsupportedEncodingException e9) {
                                                    throw e9;
                                                }
                                            } catch (UnsupportedEncodingException e10) {
                                                throw e10;
                                            }
                                        } catch (UnsupportedEncodingException e11) {
                                            throw e11;
                                        }
                                    } catch (UnsupportedEncodingException e12) {
                                        throw e12;
                                    }
                                } catch (UnsupportedEncodingException e13) {
                                    throw e13;
                                }
                            } catch (UnsupportedEncodingException e14) {
                                throw e14;
                            }
                        } catch (UnsupportedEncodingException e15) {
                            throw e15;
                        }
                    }
                    byte b3 = 0;
                    String str5 = null;
                    String str6 = null;
                    int length = a.length + 2;
                    String str7 = null;
                    while (true) {
                        if (length >= bArr.length) {
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(str6);
                            arrayList.add(str5);
                            arrayList.add(str7);
                            arrayList.add(Byte.valueOf(b3));
                            if (!z2) {
                                return arrayList;
                            }
                        } else {
                            b2 = bArr[length];
                            length++;
                        }
                        short a2 = a(bArr[length], bArr[length + 1]);
                        int i = length + 2;
                        try {
                            str = new String(bArr, i, a2, z[8]);
                        } catch (UnsupportedEncodingException e16) {
                            e16.printStackTrace();
                            str6 = str6;
                            length = i;
                        }
                        if (b2 == -6) {
                            if (z2) {
                                str6 = str;
                            } else {
                                byte b4 = b3;
                                str3 = str5;
                                str4 = str;
                                b = b4;
                                str6 = str4;
                                str5 = str3;
                                b3 = b;
                                length = i + a2;
                            }
                        }
                        if (b2 == -5) {
                            if (z2) {
                                str5 = str;
                            } else {
                                str4 = str6;
                                b = b3;
                                str3 = str;
                                str6 = str4;
                                str5 = str3;
                                b3 = b;
                                length = i + a2;
                            }
                        }
                        if (b2 == -4) {
                            String substring = str.substring(1);
                            if (z2) {
                                str2 = substring;
                            } else {
                                b = b3;
                                str3 = substring;
                                str4 = str6;
                                str6 = str4;
                                str5 = str3;
                                b3 = b;
                                length = i + a2;
                            }
                        } else {
                            str2 = str5;
                        }
                        str3 = str2;
                        str4 = str6;
                        str7 = str;
                        b = b2;
                        str6 = str4;
                        str5 = str3;
                        b3 = b;
                        length = i + a2;
                    }
                } catch (UnsupportedEncodingException e17) {
                    throw e17;
                }
            } catch (UnsupportedEncodingException e18) {
                throw e18;
            }
        } catch (UnsupportedEncodingException e19) {
            throw e19;
        }
    }

    static short a(byte b, byte b2) {
        return (short) (((65280 & b) << 8) + (b2 & 255));
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '$';
                    break;
                case 1:
                    c = '`';
                    break;
                case 2:
                    c = 5;
                    break;
                case nb.p /* 3 */:
                    c = 'Z';
                    break;
                default:
                    c = 'F';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'F');
        }
        return charArray;
    }
}
