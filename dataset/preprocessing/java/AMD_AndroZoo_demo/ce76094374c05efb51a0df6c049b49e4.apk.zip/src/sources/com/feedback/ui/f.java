package com.feedback.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class f extends BroadcastReceiver {
    g a;
    final /* synthetic */ FeedbackConversations b;

    public f(FeedbackConversations feedbackConversations, g gVar) {
        this.b = feedbackConversations;
        this.a = gVar;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        this.a.a(com.feedback.b.c.a(this.b));
        this.a.notifyDataSetChanged();
    }
}
