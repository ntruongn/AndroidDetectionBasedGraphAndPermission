package com.kuguo.d;

import java.util.regex.Pattern;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b {
    private static final Pattern a = Pattern.compile("%(\\d*)");

    public static String a(String str) {
        byte[] bytes = str.getBytes();
        byte[] bytes2 = "www.cooguo.com".getBytes();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            sb.append("%" + (bytes[i] + bytes2[i % bytes2.length]));
        }
        return sb.toString();
    }
}
