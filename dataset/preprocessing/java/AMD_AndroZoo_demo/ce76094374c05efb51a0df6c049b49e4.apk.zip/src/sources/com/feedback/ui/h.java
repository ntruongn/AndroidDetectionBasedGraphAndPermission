package com.feedback.ui;

import android.widget.ImageView;
import android.widget.TextView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class h {
    ImageView a;
    TextView b;
    TextView c;
    TextView d;
    final /* synthetic */ g e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h(g gVar) {
        this.e = gVar;
    }
}
