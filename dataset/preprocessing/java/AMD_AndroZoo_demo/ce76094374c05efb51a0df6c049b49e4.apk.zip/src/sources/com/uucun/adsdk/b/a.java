package com.uucun.adsdk.b;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a {
    private static a d = null;
    public SharedPreferences a;
    public SharedPreferences.Editor b;
    private Context c;

    private a(Context context, String str, int i) {
        this.c = null;
        this.a = null;
        this.b = null;
        this.c = context;
        this.a = this.c.getSharedPreferences(str, i);
        this.b = this.a.edit();
    }

    public static a a(Context context) {
        if (d == null) {
            d = new a(context, "adsdk_info", 1);
        }
        return d;
    }

    public void a() {
        this.b.commit();
    }

    public void a(String str) {
        this.b.remove(str);
    }

    public void a(String str, int i) {
        this.b.putInt(str, i);
    }

    public void a(String str, long j) {
        this.b.putLong(str, j);
    }

    public void a(String str, String str2) {
        this.b.putString(str, str2);
    }

    public int b(String str, int i) {
        return this.a.getInt(str, i);
    }

    public long b(String str, long j) {
        return this.a.getLong(str, j);
    }

    public String b(String str, String str2) {
        return this.a.getString(str, str2);
    }
}
