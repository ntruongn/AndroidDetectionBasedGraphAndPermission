package com.uucun.adsdk.view;

import android.os.Handler;
import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class j extends TimerTask {
    final /* synthetic */ l a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(l lVar) {
        this.a = lVar;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        Handler handler;
        handler = this.a.g;
        handler.post(this.a.b);
    }
}
