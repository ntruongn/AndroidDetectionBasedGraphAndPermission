package com.uucun.adsdk.view;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class h extends Thread {
    final /* synthetic */ l a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h(l lVar) {
        this.a = lVar;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        com.uucun.adsdk.d.e eVar;
        l lVar = this.a;
        eVar = this.a.f;
        lVar.a(eVar.c);
    }
}
