package com.wooboo.adlib_android;

import android.app.AlertDialog;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class e extends Handler {
    private static final String[] z = {z(z("P)s\u0002")), z(z("w)iCj[<'\u0007mG8k\u0002}\u0014)iCmY8u\u0006wG!h\rEP\u001en\u0006s\u00188k\u0006eG-'\u0000lQ+lCtU:f\u000ew\u001a"))};

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '4';
                    break;
                case 1:
                    c = 'H';
                    break;
                case 2:
                    c = 7;
                    break;
                case nb.p /* 3 */:
                    c = 'c';
                    break;
                default:
                    c = 4;
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 4);
        }
        return charArray;
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:3:0x0008. Please report as an issue. */
    @Override // android.os.Handler
    public void handleMessage(Message message) {
        boolean z2 = sc.C;
        super.handleMessage(message);
        try {
            switch (message.what) {
                case 1:
                    try {
                        hb hbVar = (hb) message.obj;
                        if (hbVar != null) {
                            try {
                                if (!hbVar.equals("")) {
                                    byte[] byteArray = message.getData().getByteArray(z[0]);
                                    synchronized (this) {
                                        ImpressionAdView.l().dismiss();
                                        ImpressionAdView.a((RelativeLayout) null);
                                        sc.a = true;
                                        ImpressionAdView.a(new n(hbVar, ImpressionAdView.m(), true, ImpressionAdView.b(), ImpressionAdView.c(), sc.n, byteArray, 0, null));
                                        ImpressionAdView.n().a(ImpressionAdView.i());
                                        ImpressionAdView.n().a(ImpressionAdView.l());
                                        ImpressionAdView.a(new RelativeLayout(ImpressionAdView.m()));
                                        ImpressionAdView.o().setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
                                        ImpressionAdView.o().addView(ImpressionAdView.n());
                                        ImpressionAdView.n().a((ViewGroup) null);
                                        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(ImpressionAdView.d(), ImpressionAdView.e());
                                        ImpressionAdView.a(new ImageButton(ImpressionAdView.m()));
                                        layoutParams.addRule(11);
                                        layoutParams.addRule(10);
                                        ImpressionAdView.p().setId(2);
                                        ImpressionAdView.p().setLayoutParams(layoutParams);
                                        try {
                                            ImpressionAdView.p().setBackgroundDrawable(new BitmapDrawable(ImpressionAdView.q()));
                                        } catch (Exception e) {
                                        }
                                        ImpressionAdView.p().setOnClickListener(new bc(this));
                                        try {
                                            ImpressionAdView.l().setContentView(ImpressionAdView.o());
                                            View r = ImpressionAdView.r();
                                            if (r != null) {
                                                try {
                                                    ImpressionAdView.l().setHeight(ImpressionAdView.b());
                                                    ImpressionAdView.l().setWidth(-1);
                                                    ImpressionAdView.l().showAtLocation(r, 0, ImpressionAdView.s(), ImpressionAdView.t());
                                                    ImpressionAdView.l().update(ImpressionAdView.s(), ImpressionAdView.t(), ImpressionAdView.a(), ImpressionAdView.b());
                                                    if (ImpressionAdView.u() != null) {
                                                        try {
                                                            ImpressionAdView.u().onReceiveAd(ImpressionAdView.l());
                                                        } catch (Exception e2) {
                                                            mc.b(e2.toString());
                                                        }
                                                    }
                                                } catch (Exception e3) {
                                                    throw e3;
                                                }
                                            }
                                        } catch (Exception e4) {
                                            mc.c(z[1]);
                                        }
                                        ImpressionAdView.o().addView(ImpressionAdView.p(), layoutParams);
                                    }
                                    return;
                                }
                            } catch (Exception e5) {
                                throw e5;
                            }
                        }
                        if (ImpressionAdView.u() != null) {
                            try {
                                ImpressionAdView.u().onFailedToReceiveAd(ImpressionAdView.l());
                            } catch (Exception e6) {
                                mc.b(e6.getMessage());
                            }
                        }
                        ImpressionAdView.l().dismiss();
                        return;
                    } catch (Exception e7) {
                        e7.printStackTrace();
                        if (!z2) {
                            return;
                        }
                    }
                case 2:
                    try {
                        ((AlertDialog.Builder) message.obj).show();
                        if (!z2) {
                            return;
                        }
                    } catch (Exception e8) {
                        throw e8;
                    }
                case nb.p /* 3 */:
                    ImpressionAdView.v();
                    if (!z2) {
                        return;
                    }
                case 4:
                    if (com.wooboo.download.h.a(ImpressionAdView.w())) {
                        return;
                    }
                    pc.a(ImpressionAdView.w(), (String) null);
                    com.wooboo.download.j.a(ImpressionAdView.w()).b();
                    return;
                default:
                    return;
            }
        } catch (Exception e9) {
            throw e9;
        }
    }
}
