package com.kuguo.pushads;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class k {
    protected String b;
    protected String c;
    protected String g;
    protected String h;
    protected int i;
    protected int k;
    protected String n;
    protected String o;
    protected int p;
    protected String a = Build.VERSION.SDK;
    protected String d = Build.PRODUCT;
    protected double e = -500.0d;
    protected double f = -500.0d;
    protected String j = "";
    protected String l = "unknown";
    protected int m = 1;

    /* JADX INFO: Access modifiers changed from: protected */
    public k(Context context) {
        this.b = "";
        this.c = "";
        this.g = "";
        this.h = "";
        this.i = 100044;
        this.k = 160;
        this.n = "";
        this.o = "";
        this.p = 0;
        this.h = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
        this.g = context.getPackageName();
        this.p = a.i(context) ? 1 : 0;
        this.c = "unknow";
        WindowManager windowManager = (WindowManager) context.getSystemService("window");
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        this.b = a.a(context);
        this.i = a.b(context);
        this.k = displayMetrics.densityDpi;
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
            if (bundle != null) {
                this.n = bundle.getString("cooId");
                this.o = bundle.getString("channelId");
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    private int b() {
        if (this.b == null) {
            this.b = "";
        }
        if (this.m == 10) {
            int length = this.b.getBytes().length + 6 + 3 + 4;
            return (this.j == null || "".equals(this.j)) ? length : length + this.j.getBytes().length + 3;
        }
        if (this.d == null) {
            this.d = "";
        }
        if (this.c == null) {
            this.c = "umknown";
        }
        if (this.h == null) {
            this.h = "";
        }
        if (this.n == null) {
            this.n = "";
        }
        if (this.o == null) {
            this.o = "";
        }
        if (this.l == null || "".equals(this.l)) {
            this.l = "unknown";
        }
        return ((this.j == null || "".equals(this.j)) ? 0 : this.j.trim().getBytes().length + 3) + "1.0.9".getBytes().length + this.a.getBytes().length + 30 + this.b.getBytes().length + this.c.getBytes().length + this.d.getBytes().length + String.valueOf(this.e).getBytes().length + String.valueOf(this.f).getBytes().length + this.g.getBytes().length + this.h.getBytes().length + 7 + 7 + 3 + this.l.getBytes().length + 7 + 3 + this.n.getBytes().length + 3 + this.o.getBytes().length + 7;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public byte[] a() {
        int b = b();
        byte[] bArr = new byte[b];
        bArr[0] = 17;
        System.arraycopy(b.a((short) (b - 3)), 0, bArr, 1, 2);
        bArr[3] = 1;
        System.arraycopy(b.a((short) this.b.getBytes().length), 0, bArr, 4, 2);
        byte[] bytes = this.b.getBytes();
        System.arraycopy(bytes, 0, bArr, 6, bytes.length);
        int length = bytes.length + 6;
        if (this.j != null && !"".equals(this.j)) {
            int i = length + 1;
            bArr[length] = 10;
            byte[] a = b.a((short) this.j.getBytes().length);
            System.arraycopy(a, 0, bArr, i, a.length);
            int i2 = i + 2;
            byte[] bytes2 = this.j.getBytes();
            System.arraycopy(bytes2, 0, bArr, i2, bytes2.length);
            length = i2 + bytes2.length;
        }
        int i3 = length + 1;
        bArr[length] = 13;
        byte[] a2 = b.a((short) 4);
        System.arraycopy(a2, 0, bArr, i3, a2.length);
        int i4 = i3 + 2;
        byte[] a3 = b.a(this.m);
        System.arraycopy(a3, 0, bArr, i4, a3.length);
        int length2 = i4 + a3.length;
        if (this.m == 10) {
            return bArr;
        }
        int i5 = length2 + 1;
        bArr[length2] = 0;
        System.arraycopy(b.a((short) this.a.getBytes().length), 0, bArr, i5, 2);
        int i6 = i5 + 2;
        byte[] bytes3 = this.a.getBytes();
        System.arraycopy(bytes3, 0, bArr, i6, bytes3.length);
        int length3 = i6 + bytes3.length;
        int i7 = length3 + 1;
        bArr[length3] = 2;
        System.arraycopy(b.a((short) this.c.getBytes().length), 0, bArr, i7, 2);
        int i8 = i7 + 2;
        byte[] bytes4 = this.c.getBytes();
        System.arraycopy(bytes4, 0, bArr, i8, bytes4.length);
        int length4 = i8 + bytes4.length;
        int i9 = length4 + 1;
        bArr[length4] = 3;
        System.arraycopy(b.a((short) this.d.getBytes().length), 0, bArr, i9, 2);
        int i10 = i9 + 2;
        byte[] bytes5 = this.d.getBytes();
        System.arraycopy(bytes5, 0, bArr, i10, bytes5.length);
        int length5 = i10 + bytes5.length;
        int i11 = length5 + 1;
        bArr[length5] = 4;
        String valueOf = String.valueOf(this.e);
        System.arraycopy(b.a((short) valueOf.getBytes().length), 0, bArr, i11, 2);
        int i12 = i11 + 2;
        byte[] bytes6 = valueOf.getBytes();
        System.arraycopy(bytes6, 0, bArr, i12, bytes6.length);
        int length6 = bytes6.length + i12;
        int i13 = length6 + 1;
        bArr[length6] = 5;
        String valueOf2 = String.valueOf(this.f);
        System.arraycopy(b.a((short) valueOf2.getBytes().length), 0, bArr, i13, 2);
        int i14 = i13 + 2;
        byte[] bytes7 = valueOf2.getBytes();
        System.arraycopy(bytes7, 0, bArr, i14, bytes7.length);
        int length7 = bytes7.length + i14;
        int i15 = length7 + 1;
        bArr[length7] = 6;
        byte[] a4 = b.a((short) this.g.getBytes().length);
        System.arraycopy(a4, 0, bArr, i15, a4.length);
        int i16 = i15 + 2;
        byte[] bytes8 = this.g.getBytes();
        System.arraycopy(bytes8, 0, bArr, i16, bytes8.length);
        int length8 = i16 + bytes8.length;
        int i17 = length8 + 1;
        bArr[length8] = 7;
        byte[] a5 = b.a((short) this.h.getBytes().length);
        System.arraycopy(a5, 0, bArr, i17, a5.length);
        int i18 = i17 + 2;
        byte[] bytes9 = this.h.getBytes();
        System.arraycopy(bytes9, 0, bArr, i18, bytes9.length);
        int length9 = i18 + bytes9.length;
        int i19 = length9 + 1;
        bArr[length9] = 8;
        byte[] a6 = b.a((short) 4);
        System.arraycopy(a6, 0, bArr, i19, a6.length);
        int i20 = i19 + 2;
        byte[] a7 = b.a(this.i);
        System.arraycopy(a7, 0, bArr, i20, a7.length);
        int length10 = i20 + a7.length;
        int i21 = length10 + 1;
        bArr[length10] = 9;
        byte[] a8 = b.a((short) "1.0.9".getBytes().length);
        System.arraycopy(a8, 0, bArr, i21, a8.length);
        int i22 = i21 + 2;
        byte[] bytes10 = "1.0.9".getBytes();
        System.arraycopy(bytes10, 0, bArr, i22, bytes10.length);
        int length11 = i22 + bytes10.length;
        int i23 = length11 + 1;
        bArr[length11] = 11;
        byte[] a9 = b.a((short) 4);
        System.arraycopy(a9, 0, bArr, i23, a9.length);
        int i24 = i23 + 2;
        byte[] a10 = b.a(this.k);
        System.arraycopy(a10, 0, bArr, i24, a10.length);
        int length12 = i24 + a10.length;
        int i25 = length12 + 1;
        bArr[length12] = 12;
        byte[] a11 = b.a((short) this.l.getBytes().length);
        System.arraycopy(a11, 0, bArr, i25, a11.length);
        int i26 = i25 + 2;
        byte[] bytes11 = this.l.getBytes();
        System.arraycopy(bytes11, 0, bArr, i26, bytes11.length);
        int length13 = i26 + bytes11.length;
        int i27 = length13 + 1;
        bArr[length13] = 14;
        byte[] a12 = b.a((short) this.n.getBytes().length);
        System.arraycopy(a12, 0, bArr, i27, a12.length);
        int i28 = i27 + 2;
        byte[] bytes12 = this.n.getBytes();
        System.arraycopy(bytes12, 0, bArr, i28, bytes12.length);
        int length14 = i28 + bytes12.length;
        int i29 = length14 + 1;
        bArr[length14] = 15;
        byte[] a13 = b.a((short) this.o.getBytes().length);
        System.arraycopy(a13, 0, bArr, i29, a13.length);
        int i30 = i29 + 2;
        byte[] bytes13 = this.o.getBytes();
        System.arraycopy(bytes13, 0, bArr, i30, bytes13.length);
        int length15 = i30 + bytes13.length;
        int i31 = length15 + 1;
        bArr[length15] = 16;
        byte[] a14 = b.a((short) 4);
        System.arraycopy(a14, 0, bArr, i31, a14.length);
        int i32 = i31 + 2;
        byte[] a15 = b.a(this.p);
        System.arraycopy(a15, 0, bArr, i32, a15.length);
        int length16 = i32 + a15.length;
        return bArr;
    }
}
