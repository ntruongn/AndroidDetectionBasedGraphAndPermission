package com.kuguo.a;

import android.content.Context;
import com.wooboo.adlib_android.nb;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class f {
    private static f b;
    Context a;
    private com.kuguo.b.d c;
    private LinkedList d;
    private b e;
    private boolean f;
    private boolean g;

    private f(Context context) {
        b = this;
        this.a = context;
        this.c = new com.kuguo.b.d();
        this.d = new LinkedList();
        this.e = new b(context);
        Iterator it = this.e.a().iterator();
        while (it.hasNext()) {
            d dVar = new d(context, (e) it.next());
            switch (dVar.g()) {
                case 1:
                case 2:
                    dVar.b(5);
                    break;
            }
            this.d.add(dVar);
        }
    }

    public static f a() {
        return b;
    }

    public static f a(Context context) {
        if (b == null) {
            b = new f(context.getApplicationContext());
        }
        return b;
    }

    private e g(d dVar) {
        e eVar = new e();
        eVar.a = dVar.j();
        eVar.b = dVar.b().toString();
        eVar.e = dVar.g();
        eVar.d = dVar.h();
        eVar.c = dVar.i();
        return eVar;
    }

    public boolean a(d dVar) {
        return this.d.contains(dVar);
    }

    public d b(d dVar) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.d.size()) {
                return null;
            }
            d dVar2 = (d) this.d.get(i2);
            if (dVar2.equals(dVar)) {
                return dVar2;
            }
            i = i2 + 1;
        }
    }

    public boolean b() {
        return this.f;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(d dVar) {
        this.d.add(dVar);
        this.e.a(g(dVar));
        this.c.a(dVar.a());
    }

    public boolean c() {
        return this.g;
    }

    public List d() {
        return this.d;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(d dVar) {
        if (this.d.remove(dVar)) {
            this.e.b(g(dVar));
            dVar.a().b();
        }
    }

    public void e() {
        Iterator it = this.d.iterator();
        while (it.hasNext()) {
            d dVar = (d) it.next();
            switch (dVar.g()) {
                case nb.p /* 3 */:
                case 5:
                    dVar.e();
                    break;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(d dVar) {
        if (this.d.contains(dVar)) {
            dVar.a().e();
            this.c.a(dVar.a());
        }
    }

    public void f() {
        while (this.d.size() > 0) {
            d((d) this.d.get(0));
        }
    }

    public void f(d dVar) {
        if (this.d.contains(dVar)) {
            this.e.c(g(dVar));
        }
    }
}
