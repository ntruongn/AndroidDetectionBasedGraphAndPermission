package com.uucun.adsdk.b;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.text.TextUtils;
import java.net.InetSocketAddress;
import java.net.Proxy;
import org.apache.http.HttpHost;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class j {
    public boolean a = false;

    public static boolean a(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        String extraInfo = activeNetworkInfo != null ? activeNetworkInfo.getExtraInfo() : null;
        return extraInfo != null && (extraInfo.equals("cmwap") || extraInfo.equals("ctwap") || extraInfo.equals("uniwap") || extraInfo.equals("3gwap"));
    }

    public static HttpHost b(Context context) {
        if (!a(context)) {
            return null;
        }
        String host = Proxy.getHost(context);
        int port = Proxy.getPort(context);
        String str = (host == null || TextUtils.isEmpty(host.trim())) ? "10.0.0.172" : host;
        if (port == -1) {
            port = 80;
        }
        return new HttpHost(str, port);
    }

    public static java.net.Proxy c(Context context) {
        if (!a(context)) {
            return null;
        }
        String host = Proxy.getHost(context);
        int port = Proxy.getPort(context);
        String str = (host == null || TextUtils.isEmpty(host.trim())) ? "10.0.0.172" : host;
        if (port == -1) {
            port = 80;
        }
        return new java.net.Proxy(Proxy.Type.HTTP, new InetSocketAddress(str, port));
    }
}
