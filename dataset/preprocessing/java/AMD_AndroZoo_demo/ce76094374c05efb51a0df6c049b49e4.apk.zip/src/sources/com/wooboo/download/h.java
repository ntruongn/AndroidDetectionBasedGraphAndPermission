package com.wooboo.download;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Environment;
import com.wooboo.adlib_android.mc;
import com.wooboo.adlib_android.nb;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class h {
    public static boolean e;
    private static final String[] z = {z(z("\u0006f\u0014f)\u0006}\u0013~%\u0011p")), z(z("\u0004g\u001ez#\fmTa\"\u0011l\u0014|b\u0004j\u000ea#\u000b',A\t2")), z(z("\u0004y\nd%\u0006h\u000ea#\u000b&\ff(Kh\u0014l>\n`\u001e&<\u0004j\u0011i+\u0000$\u001bz/\r`\fm")), z(z("6M9i>\u0001)\u0013{\"B}Ze#\u0010g\u000em(")), z(z("\bf\u000ff8\u0000m"))};
    private static String a = z(z("Jh\nx \fj\u001b|%\ng%\u007fc"));
    private static String b = String.valueOf(a) + z(z("\u0001f\rf \nh\u001e'"));
    private static String c = z(z("Kh\r&(\u0007"));
    private static String d = String.valueOf(a) + c;

    public static String a(Context context, String str) {
        try {
            PackageInfo packageArchiveInfo = context.getPackageManager().getPackageArchiveInfo(str, 1);
            return packageArchiveInfo != null ? packageArchiveInfo.applicationInfo.packageName : "";
        } catch (Exception e2) {
            return "";
        }
    }

    public static String a(String str, String str2) {
        return String.valueOf(str) + "/" + str2;
    }

    public static boolean a() {
        try {
        } catch (Exception e2) {
            mc.c(z[3]);
        }
        return Environment.getExternalStorageState().equals(z[4]);
    }

    public static boolean a(Context context) {
        return false;
    }

    public static String b() {
        try {
            if (!a()) {
                return "";
            }
            String absolutePath = Environment.getExternalStorageDirectory().getAbsolutePath();
            File file = new File(String.valueOf(absolutePath) + a);
            try {
                if (!file.exists()) {
                    file.mkdirs();
                }
                return String.valueOf(absolutePath) + d;
            } catch (Exception e2) {
                throw e2;
            }
        } catch (Exception e3) {
            mc.c(e3.getMessage());
            return "";
        }
    }

    public static String b(Context context) {
        try {
            if (!a()) {
                return "";
            }
            File file = new File(String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + b);
            try {
                if (!file.exists()) {
                    file.mkdirs();
                }
                return file.getPath();
            } catch (Exception e2) {
                throw e2;
            }
        } catch (Exception e3) {
            return "";
        }
    }

    public static boolean b(Context context, String str) {
        return c(context).contains(str);
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0016, code lost:
    
        r3.add(((android.content.pm.PackageInfo) r0.get(r4)).packageName);
        r1 = r4 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x002b, code lost:
    
        return r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:2:0x0012, code lost:
    
        if (r5 != false) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0014, code lost:
    
        r4 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0016, code lost:
    
        r3.add(((android.content.pm.PackageInfo) r0.get(r4)).packageName);
        r1 = r4 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0027, code lost:
    
        if (r1 < r0.size()) goto L12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0029, code lost:
    
        if (r5 != false) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x002c, code lost:
    
        r4 = r1;
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:6:0x0027 -> B:3:0x0014). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.util.List c(android.content.Context r6) {
        /*
            r1 = 0
            boolean r5 = com.wooboo.download.h.e
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            android.content.pm.PackageManager r0 = r6.getPackageManager()
            java.util.List r0 = r0.getInstalledPackages(r1)
            java.util.ArrayList r0 = (java.util.ArrayList) r0
            if (r5 == 0) goto L23
        L14:
            r2 = r3
            r4 = r1
        L16:
            java.lang.Object r1 = r0.get(r4)
            android.content.pm.PackageInfo r1 = (android.content.pm.PackageInfo) r1
            java.lang.String r1 = r1.packageName
            r2.add(r1)
            int r1 = r4 + 1
        L23:
            int r2 = r0.size()
            if (r1 < r2) goto L14
            if (r5 != 0) goto L2c
            return r3
        L2c:
            r2 = r3
            r4 = r1
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.download.h.c(android.content.Context):java.util.List");
    }

    public static boolean c() {
        return new File(b()).exists();
    }

    public static boolean c(Context context, String str) {
        try {
            Intent intent = new Intent(z[1]);
            intent.setFlags(268435456);
            intent.setDataAndType(Uri.fromFile(new File(str)), z[2]);
            context.startActivity(intent);
            return true;
        } catch (Exception e2) {
            e2.printStackTrace();
            return false;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0021 A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:15:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:14:0x0026 -> B:9:0x0019). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static boolean d(android.content.Context r4) {
        /*
            r1 = 0
            boolean r2 = com.wooboo.download.h.e
            java.lang.String[] r0 = com.wooboo.download.h.z
            r0 = r0[r1]
            java.lang.Object r0 = r4.getSystemService(r0)
            android.net.ConnectivityManager r0 = (android.net.ConnectivityManager) r0
            if (r0 != 0) goto L10
        Lf:
            return r1
        L10:
            android.net.NetworkInfo[] r3 = r0.getAllNetworkInfo()
            if (r3 == 0) goto Lf
            if (r2 == 0) goto L29
            r0 = r1
        L19:
            r2 = r3[r0]
            boolean r2 = r2.isConnected()
            if (r2 == 0) goto L23
            r1 = 1
            goto Lf
        L23:
            int r0 = r0 + 1
        L25:
            int r2 = r3.length
            if (r0 < r2) goto L19
            goto Lf
        L29:
            r0 = r1
            goto L25
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.download.h.d(android.content.Context):boolean");
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c3 = cArr[i];
            switch (i % 5) {
                case 0:
                    c2 = 'e';
                    break;
                case 1:
                    c2 = '\t';
                    break;
                case 2:
                    c2 = 'z';
                    break;
                case nb.p /* 3 */:
                    c2 = '\b';
                    break;
                default:
                    c2 = 'L';
                    break;
            }
            cArr[i] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'L');
        }
        return charArray;
    }
}
