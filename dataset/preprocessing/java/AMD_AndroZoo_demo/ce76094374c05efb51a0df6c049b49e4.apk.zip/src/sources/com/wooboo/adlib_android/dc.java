package com.wooboo.adlib_android;

import android.content.DialogInterface;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class dc implements DialogInterface.OnClickListener {
    final id a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public dc(id idVar) {
        this.a = idVar;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
    }
}
