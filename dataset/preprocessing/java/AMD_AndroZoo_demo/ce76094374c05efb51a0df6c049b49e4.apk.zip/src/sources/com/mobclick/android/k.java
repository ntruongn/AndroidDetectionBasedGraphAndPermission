package com.mobclick.android;

import android.content.Context;
import android.util.Log;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class k extends Thread {
    private static final Object a = new Object();
    private Context b;
    private int c;
    private String d;
    private String e;
    private String f;
    private String g;
    private int h;

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(Context context, int i) {
        this.b = context;
        this.c = i;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(Context context, String str, int i) {
        this.b = context;
        this.c = i;
        this.d = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(Context context, String str, String str2, int i) {
        this.b = context;
        this.c = i;
        this.d = str;
        this.e = str2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(Context context, String str, String str2, String str3, int i, int i2) {
        this.b = context;
        this.d = str;
        this.f = str2;
        this.g = str3;
        this.h = i;
        this.c = i2;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        MobclickAgent mobclickAgent;
        MobclickAgent mobclickAgent2;
        MobclickAgent mobclickAgent3;
        MobclickAgent mobclickAgent4;
        try {
            synchronized (a) {
                if (this.c == 0) {
                    try {
                        if (this.b == null) {
                            if (UmengConstants.testMode) {
                                Log.e(UmengConstants.LOG_TAG, "unexpected null context in invokehander flag=0");
                            }
                        } else {
                            mobclickAgent = MobclickAgent.a;
                            mobclickAgent.d(this.b);
                        }
                    } catch (Exception e) {
                        if (UmengConstants.testMode) {
                            Log.e(UmengConstants.LOG_TAG, "unexpected null context in invokehander flag=0");
                            e.printStackTrace();
                        }
                    }
                } else if (this.c == 1) {
                    mobclickAgent4 = MobclickAgent.a;
                    mobclickAgent4.a(this.b, this.d, this.e);
                } else if (this.c == 2) {
                    mobclickAgent3 = MobclickAgent.a;
                    mobclickAgent3.b(this.b, this.d);
                } else if (this.c == 3) {
                    mobclickAgent2 = MobclickAgent.a;
                    mobclickAgent2.a(this.b, this.d, this.f, this.g, this.h);
                }
            }
        } catch (Exception e2) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Exception occurred in invokehander.");
                e2.printStackTrace();
            }
        }
    }
}
