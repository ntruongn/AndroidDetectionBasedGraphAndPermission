package com.kuguo.pushads;

import android.content.Context;
import android.os.Handler;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class i extends Handler {
    final /* synthetic */ e a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public i(e eVar) {
        this.a = eVar;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        Context context;
        Context context2;
        a.a("alarm handle --- \t");
        Object obj = message.obj;
        if (obj != null) {
            j jVar = (j) obj;
            if (jVar.e != 0) {
                p pVar = new p(this, jVar);
                String str = jVar.o;
                context = this.a.a;
                com.kuguo.a.d dVar = new com.kuguo.a.d(str, a.b(context, "icon.png", jVar.h));
                context2 = this.a.a;
                h.a(context2, dVar, pVar);
            }
        }
    }
}
