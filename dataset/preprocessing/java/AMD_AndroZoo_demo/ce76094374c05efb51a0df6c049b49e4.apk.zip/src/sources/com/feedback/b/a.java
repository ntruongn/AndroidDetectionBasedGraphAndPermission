package com.feedback.b;

import android.content.Context;
import android.content.Intent;
import com.feedback.a.e;
import com.feedback.ui.FeedbackConversation;
import com.feedback.ui.FeedbackConversations;
import com.feedback.ui.SendFeedback;
import com.mobclick.android.UmengConstants;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a {
    public static void a(Context context) {
        a(context, null);
    }

    public static void a(Context context, com.feedback.a.d dVar) {
        Intent intent = new Intent(context, (Class<?>) SendFeedback.class);
        intent.setFlags(131072);
        if (dVar != null && dVar.b == e.PureFail) {
            intent.putExtra(UmengConstants.AtomKey_FeedbackID, dVar.c);
        }
        context.startActivity(intent);
    }

    public static void b(Context context) {
        Intent intent = new Intent(context, (Class<?>) FeedbackConversations.class);
        intent.setFlags(131072);
        context.startActivity(intent);
    }

    public static void b(Context context, com.feedback.a.d dVar) {
        FeedbackConversation.setUserContext(context);
        Intent intent = new Intent(context, (Class<?>) FeedbackConversation.class);
        intent.setFlags(131072);
        intent.putExtra(UmengConstants.AtomKey_FeedbackID, dVar.c);
        context.startActivity(intent);
    }
}
