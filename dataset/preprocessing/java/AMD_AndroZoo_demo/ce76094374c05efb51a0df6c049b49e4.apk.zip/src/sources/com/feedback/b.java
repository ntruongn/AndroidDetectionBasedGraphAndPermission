package com.feedback;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b implements View.OnClickListener {
    private final /* synthetic */ AlertDialog a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(AlertDialog alertDialog) {
        this.a = alertDialog;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        Context context;
        context = UMFeedbackService.b;
        com.feedback.b.a.b(context);
        this.a.dismiss();
    }
}
