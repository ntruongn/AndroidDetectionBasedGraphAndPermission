package com.uucun.adsdk.view;

import android.content.Context;
import android.os.Handler;
import android.widget.ImageView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class f extends ImageView {
    final /* synthetic */ l a;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(l lVar, Context context) {
        super(context);
        this.a = lVar;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        Handler handler;
        handler = this.a.g;
        handler.post(new b(this));
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i) {
        this.a.k = i == 0;
    }
}
