package com.wooboo.download;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.wooboo.adlib_android.mc;
import com.wooboo.adlib_android.nb;
import com.wooboo.adlib_android.pc;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class c implements e {
    public static final int b = 1110002;
    public static final int c = 1110001;
    public static final int d = 1110003;
    public static final int e = 1110004;
    public static final int f = 1110005;
    public static final int l = 1;
    private static final int n = 30000;
    private static final String[] z = {z(z("X\u0019_")), z(z("j7~\u000b6mrk\u001d*k:j\u000b*a(}\u0000dl=o\n\bg3|+2m ")), z(z("X\u0011L")), z(z("朅勳噰乩敫按旿炡纉佤)")), z(z("{7v\u0000\u0007i<v\u000b0X w\u0007!m6U\u0017#(1w\u0000!(")), z(z("O\u0017L")), z(z("j+l\u000175c")), z(z("Z3v\u0003!")), z(z("叞也刨旣亲長廴４杩勥噠也攷捥早炱线伸E")), z(z("z7k\u0014+f!}D'g6}^")), z(z("L=o\n(g3|\u00016(7j\u0016+z")), z(z("&3h\u000f"))};
    private e a;
    private String i;
    private String j;
    private int k;
    private String m;
    private Handler q;
    private pc t;
    private Context u;
    private String v;
    private HashMap g = new HashMap();
    private int h = 0;
    private int o = -1;
    private Integer p = 0;
    private List r = new ArrayList();
    boolean s = false;

    public c(Context context, d dVar, Handler handler, pc pcVar) {
        this.i = "";
        this.j = "";
        this.k = 1;
        this.m = "";
        this.t = null;
        this.u = null;
        this.u = context;
        this.i = dVar.a;
        this.j = dVar.g;
        this.q = handler;
        this.t = pcVar;
        this.k = 1;
        this.m = dVar.k;
        b();
    }

    public c(Context context, d dVar, e eVar, pc pcVar) {
        this.i = "";
        this.j = "";
        this.k = 1;
        this.m = "";
        this.t = null;
        this.u = null;
        this.u = context;
        this.i = dVar.a;
        this.j = dVar.g;
        this.a = eVar;
        this.t = pcVar;
        this.k = 1;
        this.m = dVar.k;
        b();
    }

    private void a(int i) {
        if (this.q == null) {
            this.a.a(this.m, i);
            return;
        }
        Message message = new Message();
        message.what = c;
        Bundle bundle = new Bundle();
        bundle.putString(z[0], this.m);
        bundle.putInt(z[2], i);
        message.setData(bundle);
        this.q.sendMessage(message);
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x00a7, code lost:
    
        if (r3 != false) goto L14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x012c, code lost:
    
        if (r3 == false) goto L38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00e0, code lost:
    
        if (r3 != false) goto L20;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void b() {
        /*
            Method dump skipped, instructions count: 390
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.download.c.b():void");
    }

    private void f() {
        if (this.q == null) {
            this.a.c(this.m);
            return;
        }
        Message message = new Message();
        message.what = e;
        Bundle bundle = new Bundle();
        bundle.putString(z[0], this.m);
        message.setData(bundle);
        this.q.sendMessage(message);
    }

    private void g() {
        if (this.q == null) {
            this.a.a(this.m);
            return;
        }
        Message message = new Message();
        message.what = b;
        Bundle bundle = new Bundle();
        bundle.putString(z[0], this.m);
        message.setData(bundle);
        this.q.sendMessage(message);
    }

    private void h() {
        if (this.q == null) {
            this.a.b(this.m);
            return;
        }
        Message message = new Message();
        message.what = d;
        Bundle bundle = new Bundle();
        bundle.putString(z[0], this.m);
        message.setData(bundle);
        this.q.sendMessage(message);
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c3 = cArr[i];
            switch (i % 5) {
                case 0:
                    c2 = '\b';
                    break;
                case 1:
                    c2 = 'R';
                    break;
                case 2:
                    c2 = 24;
                    break;
                case nb.p /* 3 */:
                    c2 = 'd';
                    break;
                default:
                    c2 = 'D';
                    break;
            }
            cArr[i] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'D');
        }
        return charArray;
    }

    public String a() {
        return this.v;
    }

    public String a(HttpURLConnection httpURLConnection) {
        return UUID.randomUUID() + z[11];
    }

    @Override // com.wooboo.download.e
    public void a(String str) {
        mc.c(String.valueOf(str) + z[1]);
        synchronized (this.g) {
            this.g.remove(Integer.valueOf(str));
            if (this.g.size() == 0) {
                if (e()) {
                    g();
                } else {
                    h();
                }
            }
        }
    }

    @Override // com.wooboo.download.e
    public void a(String str, int i) {
        int intValue;
        synchronized (this.p) {
            this.p = Integer.valueOf(this.p.intValue() + i);
            intValue = (this.p.intValue() * 100) / this.o;
        }
        if (intValue != this.h) {
            this.h = intValue;
            if (this.h <= 95) {
                a(this.h);
            }
        }
    }

    @Override // com.wooboo.download.e
    public void a(String str, int i, int i2) {
        this.t.a(str, i, i2);
    }

    @Override // com.wooboo.download.e
    public void b(String str) {
        synchronized (this.g) {
            this.g.remove(Integer.valueOf(str));
            if (this.g.size() == 0) {
                h();
            }
        }
    }

    public void c() {
        int i = this.o / this.k;
        int i2 = 0;
        while (i2 < this.k) {
            d dVar = new d();
            dVar.a = this.i;
            int i3 = i2 * i;
            int i4 = i2 == this.k + (-1) ? this.o : (i2 + 1) * i;
            dVar.b = i3;
            dVar.c = i4 - 1;
            dVar.d = 0;
            dVar.e = i2;
            this.r.add(dVar);
            i2++;
        }
    }

    @Override // com.wooboo.download.e
    public void c(String str) {
    }

    public void d() {
        try {
            for (d dVar : this.r) {
                this.p = Integer.valueOf(this.p.intValue() + dVar.d);
                this.g.put(Integer.valueOf(dVar.e), new k(dVar, this.j, this.i, this, this.s));
            }
            for (Map.Entry entry : this.g.entrySet()) {
                ((Thread) entry.getValue()).setPriority(2);
                ((Thread) entry.getValue()).start();
            }
        } catch (Exception e2) {
            h();
        }
    }

    public void d(String str) {
        this.v = str;
    }

    public boolean e() {
        String a = h.a(this.u, this.j);
        if (a == null) {
            return false;
        }
        try {
            this.t.m(this.i);
            this.t.c(this.i, a);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return true;
    }
}
