package com.kuguo.openads;

import android.content.Context;
import android.widget.Toast;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class n implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ k b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public n(k kVar, String str) {
        this.b = kVar;
        this.a = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        Context context;
        context = this.b.b;
        Toast.makeText(context, this.a, 1500).show();
    }
}
