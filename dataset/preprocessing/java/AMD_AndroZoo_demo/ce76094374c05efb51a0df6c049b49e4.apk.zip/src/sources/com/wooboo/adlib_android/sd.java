package com.wooboo.adlib_android;

import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class sd extends TimerTask {
    private static final String[] z = {z(z("yTp\u0014.mUQ\u0005\u000bq]G")), z(z("{_W\u001f;?D\u0002\u0016:l\u0010C\u001f\u007fyT\u0002\u0017-w]\u0002\u0012>{XG]\u007flXGQ>|\u0010R\u001e,qDK\u001e18YQQ7qTF\u00141")), z(z("|QV\u0010")), z(z("zUE\u001818BG\u0000*}CVQ>|\u0010D\u00030u\u0010Q\u0014-nUP")), z(z("YT\u0002=0yT\u0002\u0017-w]\u00025\u001d"))};
    final WoobooAdView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public sd(WoobooAdView woobooAdView) {
        this.a = woobooAdView;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 24;
                    break;
                case 1:
                    c = '0';
                    break;
                case 2:
                    c = '\"';
                    break;
                case nb.p /* 3 */:
                    c = 'q';
                    break;
                default:
                    c = '_';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '_');
        }
        return charArray;
    }

    /* JADX WARN: Code restructure failed: missing block: B:20:0x009a, code lost:
    
        if (r4 != false) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x00ee, code lost:
    
        if (r4 != false) goto L32;
     */
    @Override // java.util.TimerTask, java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void run() {
        /*
            Method dump skipped, instructions count: 289
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.sd.run():void");
    }
}
