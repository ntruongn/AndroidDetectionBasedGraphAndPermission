package com.kuguo.a;

import android.content.Context;
import com.kuguo.b.h;
import com.wooboo.adlib_android.nb;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class d implements com.kuguo.b.c {
    private com.kuguo.b.b a;
    private File b;
    private int c;
    private int d;
    private int e;
    private c f;
    private int g;
    private f h;
    private BufferedInputStream i;
    private int j;
    private int k;
    private Exception l;
    private Object m;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(Context context, e eVar) {
        this.a = new com.kuguo.b.a(context, new h(eVar.a));
        this.b = new File(eVar.b);
        this.d = eVar.c;
        this.e = eVar.d;
        this.c = eVar.e;
        l();
    }

    public d(com.kuguo.b.b bVar, File file) {
        this.a = bVar;
        this.b = file;
        this.d = 0;
        this.e = -1;
        this.c = 0;
        l();
    }

    public d(h hVar, File file) {
        this(new com.kuguo.b.a(f.a().a, hVar), file);
    }

    public d(String str, File file) {
        this(new h(str), file);
    }

    private void a(InputStream inputStream) {
        RandomAccessFile randomAccessFile;
        int i = 0;
        RandomAccessFile randomAccessFile2 = null;
        try {
            try {
                randomAccessFile = new RandomAccessFile(this.b, "rw");
                try {
                    if (this.g == 1) {
                        randomAccessFile.seek(randomAccessFile.length());
                        com.kuguo.d.d.a(inputStream, (int) randomAccessFile.length());
                    }
                    byte[] bArr = new byte[4096];
                    while (this.c == 2 && (i = inputStream.read(bArr)) != -1) {
                        randomAccessFile.write(bArr, 0, i);
                        this.d += i;
                        if (this.f != null) {
                            this.f.a(this, i);
                        }
                    }
                    if (i == -1) {
                        b(4);
                    }
                    try {
                        randomAccessFile.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    this.a.b();
                } catch (Exception e2) {
                    e = e2;
                    a(e);
                    try {
                        randomAccessFile.close();
                    } catch (IOException e3) {
                        e3.printStackTrace();
                    }
                    this.a.b();
                }
            } catch (Throwable th) {
                th = th;
                try {
                    randomAccessFile2.close();
                } catch (IOException e4) {
                    e4.printStackTrace();
                }
                this.a.b();
                throw th;
            }
        } catch (Exception e5) {
            e = e5;
            randomAccessFile = null;
        } catch (Throwable th2) {
            th = th2;
            randomAccessFile2.close();
            this.a.b();
            throw th;
        }
    }

    private void a(Exception exc) {
        int i = this.j;
        this.j = i + 1;
        if (i < this.k) {
            m();
            return;
        }
        this.j = 0;
        this.l = exc;
        b(5);
    }

    private void l() {
        this.g = 0;
        this.a.a(this);
        this.h = f.a();
    }

    private void m() {
        this.l = null;
        b(1);
        this.g = 1;
        this.h.e(this);
    }

    public com.kuguo.b.b a() {
        return this.a;
    }

    public void a(int i) {
        this.k = i;
    }

    public void a(c cVar) {
        this.f = cVar;
    }

    @Override // com.kuguo.b.c
    public void a(com.kuguo.b.b bVar, int i) {
        switch (this.c) {
            case 1:
            case 2:
                switch (i) {
                    case -4:
                    case -3:
                        a(bVar.i());
                        return;
                    case -2:
                        return;
                    case 200:
                        b(2);
                        this.i = new BufferedInputStream(bVar.f(), 4096);
                        a((InputStream) this.i);
                        return;
                    default:
                        bVar.b();
                        return;
                }
            default:
                return;
        }
    }

    public void a(Object obj) {
        this.m = obj;
    }

    public File b() {
        return this.b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(int i) {
        if (i != this.c) {
            this.c = i;
            if ((i == 4 && this.h.b()) || (i == 5 && this.h.c())) {
                f();
            } else {
                this.h.f(this);
            }
            if (this.f != null) {
                this.f.a(this, i);
            }
        }
    }

    public Exception c() {
        return this.l;
    }

    public void d() {
        switch (this.c) {
            case 0:
                if (this.h.a(this) || this.b == null) {
                    return;
                }
                this.d = 0;
                this.g = 0;
                b(1);
                this.h.c(this);
                return;
            default:
                return;
        }
    }

    public void e() {
        switch (this.c) {
            case nb.p /* 3 */:
            case 5:
                m();
                return;
            case 4:
            default:
                return;
        }
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        return j().equals(dVar.j()) && this.b.equals(dVar.b());
    }

    public void f() {
        b(0);
        this.h.d(this);
    }

    public int g() {
        return this.c;
    }

    public int h() {
        Map g;
        String str;
        if (this.e == -1 && this.a.h() == 200 && (g = this.a.g()) != null && (str = (String) g.get("Content-Length")) != null) {
            try {
                this.e = Integer.parseInt(str);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return this.e;
    }

    public int i() {
        return this.d;
    }

    public String j() {
        return this.a.d().toString();
    }

    public Object k() {
        return this.m;
    }

    public String toString() {
        return "[" + j() + " " + this.b + " " + this.c + " " + this.d + " " + this.e + "]";
    }
}
