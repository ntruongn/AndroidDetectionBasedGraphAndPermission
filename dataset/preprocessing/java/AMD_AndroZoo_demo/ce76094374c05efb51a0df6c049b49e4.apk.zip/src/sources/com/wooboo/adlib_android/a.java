package com.wooboo.adlib_android;

import android.os.Handler;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a extends Handler {
    final m a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(m mVar) {
        this.a = mVar;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0014, code lost:
    
        if (com.wooboo.adlib_android.sc.C != false) goto L8;
     */
    @Override // android.os.Handler
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void handleMessage(android.os.Message r3) {
        /*
            r2 = this;
            int r0 = r3.what
            switch(r0) {
                case 0: goto L9;
                case 1: goto L5;
                case 2: goto L16;
                default: goto L5;
            }
        L5:
            super.handleMessage(r3)
            return
        L9:
            com.wooboo.adlib_android.m r0 = r2.a
            android.widget.RelativeLayout r0 = r0.a
            r1 = 8
            r0.setVisibility(r1)
            boolean r0 = com.wooboo.adlib_android.sc.C
            if (r0 == 0) goto L5
        L16:
            com.wooboo.adlib_android.m r0 = r2.a
            android.widget.RelativeLayout r0 = r0.a
            r1 = 0
            r0.setVisibility(r1)
            goto L5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.a.handleMessage(android.os.Message):void");
    }
}
