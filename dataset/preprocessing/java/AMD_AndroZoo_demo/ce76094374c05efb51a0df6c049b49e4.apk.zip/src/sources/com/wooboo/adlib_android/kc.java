package com.wooboo.adlib_android;

import android.content.Context;
import android.telephony.TelephonyManager;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class kc {
    private static final String[] z = {z(z(";\u0001\\i\u001c>\u0001QW\t%\u000b^W\u000b8\nZ")), z(z("?\u001aKxRxAH\u007f\u001fy\tPg\u000f;\u000b\u0011k\u0007:ASg\u000bx\u0004Lg\u0006")), z(z("?\u0001L|")), z(z(";\u000fKa\u001c\"\nZ")), z(z(":\u0001]a\u000421Qm\u001c \u0001Mc74\u0001[m")), z(z(";\u0001\\i\u001c>\u0001Q")), z(z("0\u001eL")), z(z("4\u000bSd7#\u0001Hm\u001a$")), z(z("f@\u000e&X")), z(z("%\u000bN}\r$\u001a`i\f3\u001cZ{\u001b")), z(z(":\u000fO{F0\u0001Po\u00042@\\g\u0005")), z(z("'\u0006Pf\r")), z(z(":\u0001]a\u000421\\g\u001d9\u001aMq74\u0001[m")), z(z("4\u000bSd7>\n")), z(z("!\u000bM{\u00018\u0000")), z(z(";\u0001Qo\u0001#\u001b[m"))};
    private Context a;
    TelephonyManager b;

    /* JADX INFO: Access modifiers changed from: protected */
    public kc(Context context) {
        this.a = context;
        if (sc.e() == null || sc.f() == null) {
            new Thread(new lc(this, context)).start();
        }
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'W';
                    break;
                case 1:
                    c = 'n';
                    break;
                case 2:
                    c = '?';
                    break;
                case nb.p /* 3 */:
                    c = '\b';
                    break;
                default:
                    c = 'h';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'h');
        }
        return charArray;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x013f, code lost:
    
        return r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00e7, code lost:
    
        r5.append(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0140, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0141, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x00e5, code lost:
    
        if (r3 != false) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x00ee, code lost:
    
        if (r0 != null) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x00f0, code lost:
    
        java.lang.System.out.println(r5.toString());
        r0 = (com.wooboo.adlib_android.fc) new com.wooboo.adlib_android.fc(r5.toString()).a(com.wooboo.adlib_android.kc.z[5]);
        r1 = (java.lang.Double) r0.a(com.wooboo.adlib_android.kc.z[3]);
        r0 = (java.lang.Double) r0.a(com.wooboo.adlib_android.kc.z[15]);
        r2 = new android.location.Location(com.wooboo.adlib_android.kc.z[6]);
        r2.setLatitude(r1.doubleValue());
        r2.setLongitude(r0.doubleValue());
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x013c, code lost:
    
        if (r3 != false) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x00ea, code lost:
    
        r0 = r4.readLine();
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:8:0x00ea -> B:5:0x00ee). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.location.Location a(android.content.Context r11) {
        /*
            Method dump skipped, instructions count: 325
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.kc.a(android.content.Context):android.location.Location");
    }
}
