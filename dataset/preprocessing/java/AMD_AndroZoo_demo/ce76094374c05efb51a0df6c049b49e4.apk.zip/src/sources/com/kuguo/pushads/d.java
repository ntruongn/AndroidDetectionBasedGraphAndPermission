package com.kuguo.pushads;

import android.content.Context;
import java.util.TimerTask;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class d extends TimerTask {
    final /* synthetic */ Context a;
    final /* synthetic */ AdsReceiver b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(AdsReceiver adsReceiver, Context context) {
        this.b = adsReceiver;
        this.a = context;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        AdsService.a(this.a);
    }
}
