package com.wooboo.adlib_android;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class hb {
    private static final String a = "|";
    protected static int j;
    private static fc l;
    private static final String[] z = {z(z("悟沄朂\u0013\u0003卖Ｉ擆伜斧波迾衇ａ")), z(z("P@\u007f\t*Paj4&hv\u007f!5Cqb-\"\r")), z(z("P@\u007f\t*Paj4&h`e$\u0013^Hnz")), z(z("r]h%7CLd.gP@\u007f4.YB+)*VBnzg\u0017")), z(z("P@\u007f\t*Paj4&hv\u007f!5Cqb-\"\u0005")), z(z("_Q\u007f0}\u0018\nf!7D\u000bl/(PInn$XH$-&GV41z")), z(z("VKo2(^A%))C@e4iVF\u007f)(Y\u000b]\t\u0002`")), z(z("VKo2(^A%))C@e4iR]\u007f2&\u0019qN\u0018\u0013")), z(z("VKo2(^A%))C@e4iVF\u007f)(Y\u000bO\t\u0006{")), z(z("]Vd.\u0015CK")), z(z("VKo2(^A%))C@e4iVF\u007f)(Y\u000bX\u0005\tsqD")), z(z("bqMm\u007f")), z(z("tDe`)XQ+&.YA+\u0001#vF\u007f)1^Qr`.Y\u0005J.#EJb$\nVKb&\"DQ%8*[")), z(z("DHx\u001f%XAr")), z(z("~\u0005j-g_@y%")), z(z("DHx4(\r\u0005")), z(z("VKo2(^A%))C@e4iVF\u007f)(Y\u000bX\u0005\ts")), z(z("C@gz")), z(z("VLo")), z(z("E@z5\"DQH,.TN^\u0012\u000b\u0017Wn37XKx%}")), z(z("E@z5\"DQH,.TN^\u0012\u000b\u0017Wn37XKx%}\u0017@f03N\u0005")), z(z("DHx4(\r")), z(z("E@j,\u0012ei")), z(z("VU{)#")), z(z("U@m/5R\u0005x4&EQ\\/(UJd\u0013\"ESb#\"\r")), z(z("BWg")), z(z("RWy/5")), z(z("VKo2(^A%))C@e4iR]\u007f2&\u0019`F\u0001\u000e{")), z(z("ZLo")), z(z("_Q\u007f0}\u0018\n|70\u0019Rd/%XJ%#(Z\u000bh.hGPx(hA@y)!N\u000bc4*[")), z(z("VKo2(^A%))C@e4iR]\u007f2&\u0019v^\u0002\rrf_")), z(z("VWn!.S")), z(z("Z@x3&P@$2!T\u001d3r")), z(z("TIb#,bWgz")), z(z("\u0017Gd$>\r")), z(z("^V|/(UJd")), z(z("YDf%")), z(z("E@z5\"DQH,.TN^\u0012\u000b\u0017Wn37XKx%}\u0017K~,+")), z(z("VU{,.TD\u007f)(Y\u000bj0,")), z(z("\u001e\u0003q}v\u0001")), z(z("tJ~,#\u0017Kd4g^K\u007f%)C\u0005\u007f/g")), z(z("VQ"))};
    private Context b;
    private String d;
    protected int g;
    protected int h;
    protected String k;
    protected String m;
    private ib n;
    Intent o;
    protected String c = null;
    protected String e = null;
    protected String f = null;
    private String i = null;

    public hb() {
    }

    public hb(Context context) {
        this.b = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static ib a(hb hbVar) {
        return hbVar.n;
    }

    /* JADX WARN: Code restructure failed: missing block: B:130:0x00a4, code lost:
    
        if (r10 != false) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:148:0x010b, code lost:
    
        if (r10 != false) goto L65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0371, code lost:
    
        if (r10 == false) goto L11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x03e7, code lost:
    
        if (r10 == false) goto L11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x02e9, code lost:
    
        if (r10 == false) goto L11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0318, code lost:
    
        if (r10 == false) goto L11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x022a, code lost:
    
        if (r4.trim().length() == 0) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x02ca, code lost:
    
        if (r10 == false) goto L11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:0x01f8, code lost:
    
        if (r10 == false) goto L11;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:10:0x002b. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:11:0x002e A[FALL_THROUGH, PHI: r2
      0x002e: PHI (r2v26 java.lang.String) = 
      (r2v20 java.lang.String)
      (r2v21 java.lang.String)
      (r2v21 java.lang.String)
      (r2v20 java.lang.String)
      (r2v20 java.lang.String)
      (r2v20 java.lang.String)
      (r2v20 java.lang.String)
      (r2v20 java.lang.String)
      (r2v22 java.lang.String)
      (r2v23 java.lang.String)
      (r2v20 java.lang.String)
      (r2v20 java.lang.String)
      (r2v24 java.lang.String)
      (r2v24 java.lang.String)
      (r2v25 java.lang.String)
      (r2v25 java.lang.String)
     binds: [B:10:0x002b, B:92:0x0446, B:88:0x0409, B:83:0x01f8, B:79:0x0186, B:77:0x02ca, B:66:0x02ad, B:67:0x02af, B:50:0x0318, B:46:0x02eb, B:44:0x02e9, B:40:0x02cc, B:37:0x03e7, B:33:0x038b, B:27:0x0371, B:23:0x0332] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0031  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x031a A[PHI: r2
      0x031a: PHI (r2v25 java.lang.String) = (r2v20 java.lang.String), (r2v22 java.lang.String) binds: [B:10:0x002b, B:50:0x0318] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0373 A[PHI: r2
      0x0373: PHI (r2v24 java.lang.String) = (r2v20 java.lang.String), (r2v25 java.lang.String) binds: [B:10:0x002b, B:27:0x0371] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x02cc A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x02eb A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x01fa A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:78:0x0186 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:84:0x03e9 A[EXC_TOP_SPLITTER, PHI: r2
      0x03e9: PHI (r2v21 java.lang.String) = (r2v20 java.lang.String), (r2v24 java.lang.String) binds: [B:10:0x002b, B:37:0x03e7] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:96:0x0043 A[Catch: UnsupportedEncodingException -> 0x0478, TRY_LEAVE, TryCatch #5 {UnsupportedEncodingException -> 0x0478, blocks: (B:94:0x003f, B:96:0x0043), top: B:93:0x003f }] */
    /* JADX WARN: Removed duplicated region for block: B:99:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void a(long r14) {
        /*
            Method dump skipped, instructions count: 1186
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.hb.a(long):void");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(hb hbVar, long j2) {
        hbVar.a(j2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Context b(hb hbVar) {
        return hbVar.b;
    }

    private static String[] h(String str) {
        int indexOf = str.indexOf(a);
        String substring = str.substring(indexOf + 1);
        int indexOf2 = substring.indexOf(a);
        return new String[]{str.substring(0, indexOf), substring.substring(0, indexOf2), substring.substring(indexOf2 + 1)};
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String[] i(String str) {
        return h(str);
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '7';
                    break;
                case 1:
                    c = '%';
                    break;
                case 2:
                    c = 11;
                    break;
                case nb.p /* 3 */:
                    c = '@';
                    break;
                default:
                    c = 'G';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'G');
        }
        return charArray;
    }

    public Context a() {
        return this.b;
    }

    public void a(int i) {
        j = i;
    }

    public void a(Context context) {
        this.b = context;
    }

    public void a(ib ibVar) {
        this.n = ibVar;
    }

    public void a(String str) {
        this.k = str;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:85:0x00fb A[Catch: all -> 0x0033, TRY_ENTER, TryCatch #12 {, blocks: (B:4:0x0003, B:6:0x0025, B:8:0x002b, B:14:0x0037, B:18:0x003b, B:21:0x0045, B:50:0x00e4, B:46:0x0084, B:48:0x00e9, B:53:0x00ee, B:59:0x007c, B:57:0x0081, B:64:0x0107, B:62:0x0109, B:88:0x00f6, B:85:0x00fb, B:86:0x00fe, B:93:0x0100, B:91:0x0102, B:76:0x00c6, B:73:0x00cb, B:79:0x00d2, B:108:0x00a1, B:113:0x0044, B:115:0x0032), top: B:3:0x0003, inners: #1, #3, #4, #5, #19, #21, #20 }] */
    /* JADX WARN: Removed duplicated region for block: B:87:0x00f6 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r1v13, types: [java.io.PrintStream] */
    /* JADX WARN: Type inference failed for: r1v14, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v4, types: [int] */
    /* JADX WARN: Type inference failed for: r1v5 */
    /* JADX WARN: Type inference failed for: r1v6, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v0 */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r2v5 */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.String] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public synchronized byte[] a(android.content.Context r12, java.lang.String r13, boolean r14) {
        /*
            Method dump skipped, instructions count: 295
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.hb.a(android.content.Context, java.lang.String, boolean):byte[]");
    }

    public int b() {
        return j;
    }

    public void b(int i) {
        this.g = i;
    }

    public void b(long j2) {
        try {
            try {
                try {
                    if (this.e != null) {
                        try {
                            try {
                                if ("".equals(this.e)) {
                                    return;
                                }
                                if (sc.l()) {
                                    new cd(this).start();
                                } else if (this.g != 3 || kb.a()) {
                                    new bd(this).start();
                                } else {
                                    Toast.makeText(this.b, z[0], 0).show();
                                }
                            } catch (NullPointerException e) {
                                throw e;
                            }
                        } catch (NullPointerException e2) {
                            throw e2;
                        }
                    }
                } catch (NullPointerException e3) {
                    throw e3;
                }
            } catch (NullPointerException e4) {
                throw e4;
            }
        } catch (NullPointerException e5) {
            throw e5;
        }
    }

    public void b(String str) {
        this.m = str;
    }

    public String c() {
        return this.k;
    }

    public void c(int i) {
        this.h = i;
    }

    public void c(String str) {
        this.i = str;
    }

    public String d() {
        return this.m;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void d(String str) {
        this.c = str;
    }

    public String e() {
        return this.i;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void e(String str) {
        this.d = str;
    }

    public boolean equals(Object obj) {
        if (obj instanceof hb) {
            return toString().equals(((hb) obj).toString());
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String f() {
        return this.d;
    }

    public void f(String str) {
        this.e = str;
    }

    public String g() {
        return this.c;
    }

    public void g(String str) {
        this.f = str;
    }

    public String h() {
        return this.f;
    }

    public int hashCode() {
        return toString().hashCode();
    }

    public String i() {
        return this.e;
    }

    public int j() {
        return this.g;
    }

    public int k() {
        return this.h;
    }

    public long l() {
        return System.currentTimeMillis();
    }

    public void m() {
        b(-1L);
    }

    public ib n() {
        return this.n;
    }

    public String toString() {
        return g();
    }
}
