package com.mobclick.android;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class n {
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0062, code lost:
    
        if (r0.equals("uniwap") != false) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String a(android.content.Context r5) {
        /*
            r1 = 0
            android.content.pm.PackageManager r0 = r5.getPackageManager()
            java.lang.String r2 = "android.permission.ACCESS_NETWORK_STATE"
            java.lang.String r3 = r5.getPackageName()
            int r0 = r0.checkPermission(r2, r3)
            if (r0 == 0) goto L13
            r0 = r1
        L12:
            return r0
        L13:
            java.lang.String r0 = "connectivity"
            java.lang.Object r0 = r5.getSystemService(r0)     // Catch: java.lang.Exception -> L67
            android.net.ConnectivityManager r0 = (android.net.ConnectivityManager) r0     // Catch: java.lang.Exception -> L67
            android.net.NetworkInfo r0 = r0.getActiveNetworkInfo()     // Catch: java.lang.Exception -> L67
            if (r0 != 0) goto L23
            r0 = r1
            goto L12
        L23:
            int r2 = r0.getType()     // Catch: java.lang.Exception -> L67
            r3 = 1
            if (r2 != r3) goto L2c
            r0 = r1
            goto L12
        L2c:
            java.lang.String r0 = r0.getExtraInfo()     // Catch: java.lang.Exception -> L67
            boolean r2 = com.mobclick.android.UmengConstants.testMode     // Catch: java.lang.Exception -> L67
            if (r2 == 0) goto L48
            java.lang.String r2 = "TAG"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L67
            java.lang.String r4 = "net type:"
            r3.<init>(r4)     // Catch: java.lang.Exception -> L67
            java.lang.StringBuilder r3 = r3.append(r0)     // Catch: java.lang.Exception -> L67
            java.lang.String r3 = r3.toString()     // Catch: java.lang.Exception -> L67
            android.util.Log.i(r2, r3)     // Catch: java.lang.Exception -> L67
        L48:
            if (r0 != 0) goto L4c
            r0 = r1
            goto L12
        L4c:
            java.lang.String r2 = "cmwap"
            boolean r2 = r0.equals(r2)     // Catch: java.lang.Exception -> L67
            if (r2 != 0) goto L64
            java.lang.String r2 = "3gwap"
            boolean r2 = r0.equals(r2)     // Catch: java.lang.Exception -> L67
            if (r2 != 0) goto L64
            java.lang.String r2 = "uniwap"
            boolean r0 = r0.equals(r2)     // Catch: java.lang.Exception -> L67
            if (r0 == 0) goto L6b
        L64:
            java.lang.String r0 = "10.0.0.172"
            goto L12
        L67:
            r0 = move-exception
            r0.printStackTrace()
        L6b:
            r0 = r1
            goto L12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.mobclick.android.n.a(android.content.Context):java.lang.String");
    }
}
