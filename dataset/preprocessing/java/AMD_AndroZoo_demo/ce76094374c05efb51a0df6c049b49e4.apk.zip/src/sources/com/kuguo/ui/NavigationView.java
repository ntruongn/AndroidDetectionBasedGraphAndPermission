package com.kuguo.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import java.util.Stack;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class NavigationView extends FrameLayout {
    private View a;
    private Stack b;

    public NavigationView(Context context) {
        this(context, null);
    }

    public NavigationView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = new Stack();
    }

    public void a() {
        if (b()) {
            return;
        }
        TranslateAnimation translateAnimation = new TranslateAnimation(0.0f, getWidth() - this.a.getLeft(), 0.0f, 0.0f);
        translateAnimation.setDuration(300L);
        this.a.startAnimation(translateAnimation);
        TranslateAnimation translateAnimation2 = new TranslateAnimation((-this.a.getWidth()) - this.a.getLeft(), 0.0f, 0.0f, 0.0f);
        translateAnimation2.setDuration(300L);
        View view = (View) this.b.pop();
        view.startAnimation(translateAnimation2);
        removeView(this.a);
        this.a = view;
        addView(view);
    }

    public void a(View view) {
        this.a = view;
        addView(view, -1, -1);
    }

    public void b(View view) {
        TranslateAnimation translateAnimation = new TranslateAnimation(0.0f, (-this.a.getWidth()) - this.a.getLeft(), 0.0f, 0.0f);
        translateAnimation.setDuration(300L);
        this.a.startAnimation(translateAnimation);
        TranslateAnimation translateAnimation2 = new TranslateAnimation(getWidth() - this.a.getLeft(), 0.0f, 0.0f, 0.0f);
        translateAnimation2.setDuration(300L);
        view.startAnimation(translateAnimation2);
        this.b.push(this.a);
        removeView(this.a);
        this.a = view;
        addView(view, -1, -1);
    }

    public boolean b() {
        return this.b.isEmpty();
    }
}
