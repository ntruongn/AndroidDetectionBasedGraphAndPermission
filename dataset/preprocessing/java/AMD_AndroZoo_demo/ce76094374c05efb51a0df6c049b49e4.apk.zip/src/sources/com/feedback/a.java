package com.feedback;

import android.app.AlertDialog;
import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class a implements View.OnClickListener {
    private final /* synthetic */ AlertDialog a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(AlertDialog alertDialog) {
        this.a = alertDialog;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        this.a.dismiss();
    }
}
