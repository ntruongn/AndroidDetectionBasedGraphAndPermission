package com.kuguo.b;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class d {
    private boolean a = false;
    private List b = new ArrayList();

    public d() {
        a(1);
    }

    private f b() {
        f fVar = null;
        for (f fVar2 : this.b) {
            fVar2.b();
            if (fVar != null && fVar2.size() >= fVar.size()) {
                fVar2 = fVar;
            }
            fVar = fVar2;
        }
        return fVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b(b bVar) {
        bVar.a();
    }

    public void a() {
        Iterator it = this.b.iterator();
        while (it.hasNext()) {
            ((f) it.next()).a();
        }
    }

    public void a(int i) {
        if (this.b.size() < i) {
            int size = i - this.b.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.b.add(new f(this));
            }
        }
    }

    public void a(b bVar) {
        bVar.a(-1);
        if (this.a) {
            b(bVar);
            return;
        }
        f b = b();
        if (b != null) {
            b.add(bVar);
        }
    }
}
