package com.kuguo.b;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class g extends Thread {
    final /* synthetic */ f a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(f fVar) {
        this.a = fVar;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.a.size()) {
                this.a.b = null;
                return;
            }
            b bVar = (b) this.a.get(i2);
            if (bVar.h() == -1) {
                this.a.a.b(bVar);
            }
            i = i2 + 1;
        }
    }
}
