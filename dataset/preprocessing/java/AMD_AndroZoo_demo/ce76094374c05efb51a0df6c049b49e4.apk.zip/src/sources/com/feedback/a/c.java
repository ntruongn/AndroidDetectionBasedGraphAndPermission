package com.feedback.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public enum c {
    Starting,
    UserReply,
    DevReply;

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static c[] valuesCustom() {
        c[] valuesCustom = values();
        int length = valuesCustom.length;
        c[] cVarArr = new c[length];
        System.arraycopy(valuesCustom, 0, cVarArr, 0, length);
        return cVarArr;
    }
}
