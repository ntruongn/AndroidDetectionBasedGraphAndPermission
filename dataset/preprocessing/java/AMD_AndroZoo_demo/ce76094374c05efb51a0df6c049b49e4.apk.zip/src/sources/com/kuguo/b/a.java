package com.kuguo.b;

import android.content.Context;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a extends b {
    private HttpClient b;

    public a(Context context, h hVar) {
        super(context, hVar);
    }

    @Override // com.kuguo.b.b
    public void a() {
        HttpRequestBase httpRequestBase;
        if (c()) {
            if (!l()) {
                a(-4);
                return;
            }
            a((Exception) null);
            a(-2);
            this.b = new DefaultHttpClient();
            float j = j();
            if (j > 0.0f) {
                this.b.getParams().setParameter("http.socket.timeout", Integer.valueOf((int) (j * 1000.0f)));
                this.b.getParams().setParameter("http.connection.timeout", Integer.valueOf((int) (j * 1000.0f)));
            }
            e k = k();
            if (k != null) {
                this.b.getParams().setParameter("http.route.default-proxy", new HttpHost(k.a(), k.b(), "http"));
            }
            h d = d();
            if (d.b() == 0) {
                httpRequestBase = new HttpGet(d.toString());
            } else {
                HttpPost httpPost = new HttpPost(d.c());
                try {
                    httpPost.setEntity(new StringEntity(d.d()));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                httpRequestBase = httpPost;
            }
            Map a = d.a();
            for (String str : a.keySet()) {
                httpRequestBase.addHeader(str, a.get(str).toString());
            }
            try {
                HttpResponse execute = this.b.execute(httpRequestBase);
                int statusCode = execute.getStatusLine().getStatusCode();
                HashMap hashMap = new HashMap();
                for (Header header : execute.getAllHeaders()) {
                    hashMap.put(header.getName(), header.getValue());
                }
                a(hashMap);
                a(execute.getEntity().getContent());
                a(statusCode);
            } catch (Exception e2) {
                a(e2);
                a(-3);
            }
        }
    }

    @Override // com.kuguo.b.b
    public void b() {
        if (c()) {
            return;
        }
        if (this.b != null) {
            this.b.getConnectionManager().shutdown();
        }
        a((Map) null);
        a((InputStream) null);
        a((Exception) null);
        a(-3);
    }
}
