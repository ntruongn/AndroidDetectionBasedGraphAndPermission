package com.kuguo.openads;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b extends BroadcastReceiver {
    private String a(Intent intent) {
        String dataString = intent.getDataString();
        if (dataString != null) {
            String[] split = dataString.split(":");
            if (split.length > 1) {
                return split[1].trim();
            }
        }
        return null;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String a;
        k a2;
        g c;
        if (!"android.intent.action.PACKAGE_ADDED".equals(intent.getAction()) || (a = a(intent)) == null || (c = (a2 = k.a(context)).c(a)) == null) {
            return;
        }
        c.l = 4;
        a2.c();
        a2.e(c);
    }
}
