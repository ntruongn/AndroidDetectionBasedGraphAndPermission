package com.wooboo.adlib_android;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class ob {
    private static final String z = z(z("_~\u000fJ\u001fw~\"]\u001fc\u007f\u0006A\fSj\u0000J\bb{\fA"));
    private static final String a = z(z("RW0"));
    static SecretKey b = null;

    ob() {
    }

    public static final String a(String str, String str2) {
        a(str2);
        try {
            return new String(b(d(str.getBytes())));
        } catch (Exception e) {
            mc.c(e.toString());
            return null;
        }
    }

    private static void a(String str) {
        try {
            b = SecretKeyFactory.getInstance(a).generateSecret(new DESKeySpec(str.getBytes()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static byte[] a(byte[] bArr) throws Exception {
        try {
            if (b == null) {
                return null;
            }
            Cipher cipher = Cipher.getInstance(a);
            cipher.init(1, b);
            return cipher.doFinal(bArr);
        } catch (Exception e) {
            throw e;
        }
    }

    public static final String b(String str, String str2) {
        a(str2);
        try {
            return c(a(str.getBytes()));
        } catch (Exception e) {
            mc.c(e.toString());
            return null;
        }
    }

    public static byte[] b(byte[] bArr) throws Exception {
        try {
            if (b == null) {
                return null;
            }
            Cipher cipher = Cipher.getInstance(a);
            cipher.init(2, b);
            return cipher.doFinal(bArr);
        } catch (Exception e) {
            throw e;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x004d, code lost:
    
        if (r0 < r7.length) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x004f, code lost:
    
        r2 = r1.toUpperCase();
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0053, code lost:
    
        if (r4 != false) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0055, code lost:
    
        return r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0058, code lost:
    
        r2 = r0;
        r0 = r1;
        r1 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0056, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0057, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:2:0x0007, code lost:
    
        if (r4 != false) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0009, code lost:
    
        r2 = java.lang.Integer.toHexString(r7[r0] & 255);
        r3 = r2;
        r6 = r0;
        r0 = r1;
        r1 = r2;
        r2 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x001b, code lost:
    
        if (r1.length() != 1) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x001d, code lost:
    
        r0 = java.lang.String.valueOf(r0) + "0" + r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0034, code lost:
    
        if (r4 == false) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0047, code lost:
    
        r1 = r0;
        r0 = r2 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0036, code lost:
    
        r0 = java.lang.String.valueOf(r0) + r3;
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:12:0x004d -> B:3:0x0009). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x0058 -> B:4:0x0016). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String c(byte[] r7) {
        /*
            boolean r4 = com.wooboo.adlib_android.sc.C
            java.lang.String r1 = ""
            java.lang.String r3 = ""
            r0 = 0
            if (r4 == 0) goto L4c
        L9:
            r2 = r7[r0]
            r2 = r2 & 255(0xff, float:3.57E-43)
            java.lang.String r2 = java.lang.Integer.toHexString(r2)
            r3 = r2
            r6 = r0
            r0 = r1
            r1 = r2
            r2 = r6
        L16:
            int r1 = r1.length()
            r5 = 1
            if (r1 != r5) goto L36
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r0 = java.lang.String.valueOf(r0)
            r1.<init>(r0)
            java.lang.String r0 = "0"
            java.lang.StringBuilder r0 = r1.append(r0)
            java.lang.StringBuilder r0 = r0.append(r3)
            java.lang.String r0 = r0.toString()
            if (r4 == 0) goto L47
        L36:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r0 = java.lang.String.valueOf(r0)
            r1.<init>(r0)
            java.lang.StringBuilder r0 = r1.append(r3)
            java.lang.String r0 = r0.toString()
        L47:
            int r1 = r2 + 1
            r6 = r1
            r1 = r0
            r0 = r6
        L4c:
            int r2 = r7.length     // Catch: java.lang.IllegalArgumentException -> L56
            if (r0 < r2) goto L9
            java.lang.String r2 = r1.toUpperCase()     // Catch: java.lang.IllegalArgumentException -> L56
            if (r4 != 0) goto L58
            return r2
        L56:
            r0 = move-exception
            throw r0
        L58:
            r6 = r2
            r2 = r0
            r0 = r1
            r1 = r6
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ob.c(byte[]):java.lang.String");
    }

    public static byte[] d(byte[] bArr) {
        try {
            if (bArr.length % 2 != 0) {
                throw new IllegalArgumentException(z);
            }
            byte[] bArr2 = new byte[bArr.length / 2];
            for (int i = 0; i < bArr.length; i += 2) {
                try {
                    bArr2[i / 2] = (byte) Integer.parseInt(new String(bArr, i, 2), 16);
                } catch (IllegalArgumentException e) {
                    throw e;
                }
            }
            return bArr2;
        } catch (IllegalArgumentException e2) {
            throw e2;
        }
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 22;
                    break;
                case 1:
                    c = 18;
                    break;
                case 2:
                    c = 'c';
                    break;
                case nb.p /* 3 */:
                    c = '/';
                    break;
                default:
                    c = 'x';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'x');
        }
        return charArray;
    }
}
