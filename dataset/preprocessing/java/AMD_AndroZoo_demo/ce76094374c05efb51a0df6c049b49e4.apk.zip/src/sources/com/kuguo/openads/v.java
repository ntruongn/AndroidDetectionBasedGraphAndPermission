package com.kuguo.openads;

import android.content.Context;
import com.mobclick.android.UmengConstants;
import java.io.DataInputStream;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class v implements com.kuguo.b.c {
    private com.kuguo.b.d a;
    private Context b;
    private g c;
    private int d;

    public v(Context context) {
        context.getApplicationContext();
        this.a = new com.kuguo.b.d();
    }

    private void a(com.kuguo.b.b bVar) {
        try {
            byte readByte = new DataInputStream(bVar.f()).readByte();
            com.kuguo.d.a.a("handle feedback return: " + ((int) readByte));
            if (readByte == 0 && this.d == 3) {
                k.a(this.b).h(this.c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            bVar.b();
        }
    }

    @Override // com.kuguo.b.c
    public void a(com.kuguo.b.b bVar, int i) {
        switch (i) {
            case -4:
            case -2:
            case UmengConstants.RetrieveReplyBroadcast_Fail /* -1 */:
                return;
            case -3:
                Exception i2 = bVar.i();
                if (i2 != null) {
                    i2.printStackTrace();
                    return;
                }
                return;
            case 200:
                a(bVar);
                return;
            default:
                bVar.b();
                return;
        }
    }

    public void a(g gVar, int i) {
        this.c = gVar;
        this.d = i;
        com.kuguo.b.h a = k.a(this.b).a(UmengConstants.FeedbackPreName);
        a.a("appId", Integer.valueOf(gVar.i));
        a.a(UmengConstants.AtomKey_State, Integer.valueOf(i));
        com.kuguo.b.a aVar = new com.kuguo.b.a(this.b, a);
        aVar.a(this);
        this.a.a(aVar);
    }
}
