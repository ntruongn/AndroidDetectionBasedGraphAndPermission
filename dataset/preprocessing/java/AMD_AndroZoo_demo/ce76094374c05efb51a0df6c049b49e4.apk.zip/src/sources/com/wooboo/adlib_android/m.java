package com.wooboo.adlib_android;

import android.os.Handler;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class m extends LinearLayout {
    private static final String[] z = {z(z("j Jtwf(")), z(z("d*K.Xl Z4)x!J")), z(z("z*K(b{'r>h\u007f!\u0003*io")), z(z("z&J2sW+B-i&?C=")), z(z("z&J2sW:]twf(")), z(z("{'L(bla]4`")), z(z("e\u0000C6~A!I?sm=@3ii;H")), z(z("d*K.X}?\u0003*io"))};
    RelativeLayout a;
    ProgressBar b;
    Handler c;
    private ImageView d;
    final AdActivity e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0274, code lost:
    
        if (r2 != false) goto L12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x02a2, code lost:
    
        if (r2 != false) goto L17;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public m(com.wooboo.adlib_android.AdActivity r11, android.content.Context r12, java.lang.String r13) {
        /*
            Method dump skipped, instructions count: 897
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.m.<init>(com.wooboo.adlib_android.AdActivity, android.content.Context, java.lang.String):void");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static AdActivity a(m mVar) {
        return mVar.e;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '\b';
                    break;
                case 1:
                    c = 'O';
                    break;
                case 2:
                    c = '-';
                    break;
                case nb.p /* 3 */:
                    c = 'Z';
                    break;
                default:
                    c = 7;
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 7);
        }
        return charArray;
    }
}
