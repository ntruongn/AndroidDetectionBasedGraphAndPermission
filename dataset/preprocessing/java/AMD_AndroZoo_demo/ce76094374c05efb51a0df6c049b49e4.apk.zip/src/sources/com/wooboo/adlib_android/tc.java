package com.wooboo.adlib_android;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class tc implements DialogInterface.OnClickListener {
    private static final String z = z(z("\u001a\u007f'ud\u0012umne\u000ft-s%\u001ar7nd\u0015?\u0015NN,"));
    final ld a;
    private final String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public tc(ld ldVar, String str) {
        this.a = ldVar;
        this.b = str;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '{';
                    break;
                case 1:
                    c = 17;
                    break;
                case 2:
                    c = 'C';
                    break;
                case nb.p /* 3 */:
                    c = 7;
                    break;
                default:
                    c = 11;
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 11);
        }
        return charArray;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        Intent intent = new Intent();
        intent.setAction(z);
        intent.setData(Uri.parse(this.b));
        intent.setFlags(268435456);
        ld.a(this.a).getContext().startActivity(intent);
    }
}
