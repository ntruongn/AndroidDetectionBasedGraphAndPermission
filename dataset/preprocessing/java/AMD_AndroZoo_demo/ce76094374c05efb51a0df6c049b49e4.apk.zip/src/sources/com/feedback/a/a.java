package com.feedback.a;

import com.mobclick.android.UmengConstants;
import com.mobclick.android.m;
import java.util.Date;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a implements Comparable {
    String a;
    String b;
    public String c;
    public String d;
    public Date e;
    public c f;
    public b g;
    public JSONObject h;

    public a(JSONObject jSONObject) {
        this.g = b.OK;
        if (jSONObject == null) {
            throw new Exception("invalid atom");
        }
        this.h = jSONObject;
        String optString = jSONObject.optString(UmengConstants.AtomKey_Type);
        if (UmengConstants.Atom_Type_NewFeedback.equals(optString)) {
            this.f = c.Starting;
        } else if (UmengConstants.Atom_Type_DevReply.equals(optString)) {
            this.f = c.DevReply;
        } else if (UmengConstants.Atom_Type_UserReply.equals(optString)) {
            this.f = c.UserReply;
        }
        String optString2 = jSONObject.optString(UmengConstants.AtomKey_State);
        if (UmengConstants.TempState.equalsIgnoreCase(optString2)) {
            this.g = b.Sending;
        } else if ("fail".equalsIgnoreCase(optString2)) {
            this.g = b.Fail;
        } else if ("ok".equalsIgnoreCase(optString2)) {
            this.g = b.OK;
        } else if ("ReSending".equalsIgnoreCase(optString2)) {
            this.g = b.Resending;
        }
        if (this.f == c.Starting) {
            this.a = jSONObject.optString(UmengConstants.AtomKey_Thread_Title);
        }
        this.b = jSONObject.optString(UmengConstants.AtomKey_Thread_Title);
        if (com.feedback.b.d.a(this.b)) {
            this.b = jSONObject.optString(UmengConstants.AtomKey_Content);
        }
        this.c = jSONObject.optString(UmengConstants.AtomKey_FeedbackID);
        this.e = m.d(jSONObject.optString(UmengConstants.AtomKey_Date));
    }

    @Override // java.lang.Comparable
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public int compareTo(a aVar) {
        Date date = aVar.e;
        if (this.e == null || date == null || date.equals(this.e)) {
            return 0;
        }
        return date.after(this.e) ? -1 : 1;
    }

    public String a() {
        return this.f == c.Starting ? this.a : this.b;
    }
}
