package com.wooboo.adlib_android;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.RelativeLayout;
import android.widget.Toast;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class b extends Handler {
    private static final String[] z = {z(z("HL5t")), z(z("JI")), z(z("MF")), z(z("JA")), z(z("DM/c]NM")), z(z("\\Z0")), z(z("罸维狪冥丱佚Ｄ讫稝倥釤诽｝")), z(z("AI2tPLZ|}ON\u0012")), z(z("ZM?")), z(z("OF"))};

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = ')';
                    break;
                case 1:
                    c = '(';
                    break;
                case 2:
                    c = '\\';
                    break;
                case nb.p /* 3 */:
                    c = 16;
                    break;
                default:
                    c = '<';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '<');
        }
        return charArray;
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:2:0x0009. Please report as an issue. */
    @Override // android.os.Handler
    public void handleMessage(Message message) {
        boolean z2 = sc.C;
        switch (message.what) {
            case 1:
                if (n.B != null) {
                    n.B.setVisibility(8);
                }
                n.d();
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, 8);
                layoutParams.addRule(14);
                layoutParams.addRule(6);
                System.out.println(z[7] + message.obj.toString());
                if (!z2) {
                    return;
                }
            case 2:
                if (n.B == null) {
                    return;
                }
                n.B.setVisibility(8);
                if (!z2) {
                    return;
                }
            case nb.p /* 3 */:
                Toast.makeText(n.q(), message.getData().getString(z[4]), 0).show();
                super.handleMessage(message);
                if (!z2) {
                    return;
                }
            case n.X /* 11100 */:
                n.a(n.r());
                if (!z2) {
                    return;
                }
            case n.Y /* 11200 */:
                if (n.v == null) {
                    return;
                }
                n.v.b(n.s());
                if (!z2) {
                    return;
                }
            case n.Z /* 11300 */:
                Toast.makeText(n.q(), z[6], 1).show();
                if (!z2) {
                    return;
                }
            case n.ab /* 11400 */:
                Bundle data = message.getData();
                n.r().a(data.getString(z[5]), data.getString(z[2]), data.getString(z[9]), data.getString(z[0]), data.getString(z[1]), data.getString(z[3]), data.getString(z[8]));
                return;
            default:
                return;
        }
    }
}
