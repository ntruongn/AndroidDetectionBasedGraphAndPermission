package com.wooboo.adlib_android;

import android.content.DialogInterface;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class y implements DialogInterface.OnClickListener {
    private final String a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public y(String str) {
        this.a = str;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        new wc(this, this.a).start();
    }
}
