package com.feedback.ui;

import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class i implements View.OnClickListener {
    final /* synthetic */ SendFeedback a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public i(SendFeedback sendFeedback) {
        this.a = sendFeedback;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        EditText editText;
        com.feedback.b.a.b(this.a);
        this.a.finish();
        InputMethodManager inputMethodManager = (InputMethodManager) this.a.getSystemService("input_method");
        editText = this.a.d;
        inputMethodManager.hideSoftInputFromWindow(editText.getWindowToken(), 0);
    }
}
