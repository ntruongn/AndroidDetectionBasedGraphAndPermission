package com.wooboo.adlib_android;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class db implements View.OnClickListener {
    private static final String[] z = {z(z("&A_M\u0011a\u001a\\J\\`BDRI!Z\u0005^D#\u001bHS")), z(z("&A_M\u0011a\u001a\\J\\`\u0004\u0013\u0004\\!G@N\u0005-ZF")), z(z("/[OOD'Q\u0005TE:PEI\u0005/V_TD \u001b}tn\u0019"))};
    final n a;
    private final Context b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public db(n nVar, Context context) {
        this.a = nVar;
        this.b = context;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'N';
                    break;
                case 1:
                    c = '5';
                    break;
                case 2:
                    c = '+';
                    break;
                case nb.p /* 3 */:
                    c = '=';
                    break;
                default:
                    c = '+';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '+');
        }
        return charArray;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        Uri parse = sc.n ? Uri.parse(z[0]) : Uri.parse(z[1]);
        Intent intent = new Intent();
        intent.setAction(z[2]);
        intent.setData(parse);
        this.b.startActivity(intent);
    }
}
