package com.uucun.adsdk.c;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class e implements DialogInterface.OnClickListener {
    final /* synthetic */ com.uucun.adsdk.d.c a;
    final /* synthetic */ k b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(k kVar, com.uucun.adsdk.d.c cVar) {
        this.b = kVar;
        this.a = cVar;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        Context context;
        if (this.a.c == null || TextUtils.isEmpty(this.a.c)) {
            return;
        }
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(this.a.c));
        intent.setFlags(268435456);
        context = this.b.d;
        context.startActivity(intent);
    }
}
