package com.wooboo.adlib_android;

import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class bc implements View.OnClickListener {
    final e a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public bc(e eVar) {
        this.a = eVar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        ImpressionAdView.close();
    }
}
