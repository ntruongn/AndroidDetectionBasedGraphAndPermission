package com.yong.pedometer.preferences;

import android.content.Context;
import android.util.AttributeSet;
import com.yong.pedometer.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class StepLengthPreference extends EditMeasurementPreference {
    public StepLengthPreference(Context context) {
        super(context);
    }

    public StepLengthPreference(Context context, AttributeSet attr) {
        super(context, attr);
    }

    public StepLengthPreference(Context context, AttributeSet attr, int defStyle) {
        super(context, attr, defStyle);
    }

    @Override // com.yong.pedometer.preferences.EditMeasurementPreference
    protected void initPreferenceDetails() {
        this.mTitleResource = R.string.step_length_setting_title;
        this.mMetricUnitsResource = R.string.centimeters;
        this.mImperialUnitsResource = R.string.inches;
    }
}
