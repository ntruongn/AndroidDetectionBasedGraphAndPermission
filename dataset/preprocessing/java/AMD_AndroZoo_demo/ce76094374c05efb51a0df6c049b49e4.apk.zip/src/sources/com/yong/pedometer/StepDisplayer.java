package com.yong.pedometer;

import com.yong.pedometer.SpeakingTimer;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class StepDisplayer implements StepListener, SpeakingTimer.Listener {
    private int mCount = 0;
    private ArrayList<Listener> mListeners = new ArrayList<>();
    PedometerSettings mSettings;
    Utils mUtils;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public interface Listener {
        void passValue();

        void stepsChanged(int i);
    }

    public StepDisplayer(PedometerSettings settings, Utils utils) {
        this.mUtils = utils;
        this.mSettings = settings;
        notifyListener();
    }

    public void setUtils(Utils utils) {
        this.mUtils = utils;
    }

    public void setSteps(int steps) {
        this.mCount = steps;
        notifyListener();
    }

    @Override // com.yong.pedometer.StepListener
    public void onStep() {
        this.mCount++;
        notifyListener();
    }

    public void reloadSettings() {
        notifyListener();
    }

    @Override // com.yong.pedometer.StepListener
    public void passValue() {
    }

    public void addListener(Listener l) {
        this.mListeners.add(l);
    }

    public void notifyListener() {
        Iterator<Listener> it = this.mListeners.iterator();
        while (it.hasNext()) {
            Listener listener = it.next();
            listener.stepsChanged(this.mCount);
        }
    }

    @Override // com.yong.pedometer.SpeakingTimer.Listener
    public void speak() {
        if (this.mSettings.shouldTellSteps() && this.mCount > 0) {
            this.mUtils.say(this.mCount + " steps");
        }
    }
}
