package com.wooboo.download;

import java.util.TimerTask;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class n extends TimerTask {
    final WoobooService a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public n(WoobooService woobooService) {
        this.a = woobooService;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        WoobooService.a(this.a);
    }
}
