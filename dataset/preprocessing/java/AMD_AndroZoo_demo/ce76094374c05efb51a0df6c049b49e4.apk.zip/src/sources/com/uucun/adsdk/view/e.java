package com.uucun.adsdk.view;

import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class e implements View.OnClickListener {
    final /* synthetic */ l a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(l lVar) {
        this.a = lVar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        com.uucun.adsdk.a.a aVar;
        int i;
        aVar = this.a.m;
        i = this.a.h;
        com.uucun.adsdk.d.e a = aVar.a(i);
        if (a == null) {
            return;
        }
        this.a.a(a);
    }
}
