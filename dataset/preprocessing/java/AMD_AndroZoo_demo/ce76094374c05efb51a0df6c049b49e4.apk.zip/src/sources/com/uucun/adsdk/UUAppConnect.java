package com.uucun.adsdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.widget.LinearLayout;
import com.uucun.adsdk.view.l;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class UUAppConnect {
    public static final String SDK_VERSION = "1.0.0";
    private static UUAppConnect appConnect = null;
    private Context context;
    private d initSdk;

    private UUAppConnect(Activity activity, String str, String str2) {
        this.initSdk = null;
        this.context = null;
        if (str == null || TextUtils.isEmpty(str)) {
            throw new RuntimeException("App Key 不能为空.");
        }
        str2 = str2 == null ? "" : str2;
        this.context = activity;
        this.initSdk = new d(activity, str, str2);
    }

    private UUAppConnect(Context context) {
        this.initSdk = null;
        this.context = null;
        this.context = context;
        this.initSdk = new d(context);
    }

    public static UUAppConnect getInstance(Context context) {
        if (appConnect == null) {
            appConnect = new UUAppConnect(context);
        }
        return appConnect;
    }

    public static void showToast(String str, Context context) {
        new Handler().post(new a(context, str));
    }

    public void detectUpdate() {
        if (this.initSdk != null) {
            this.initSdk.e(this.context);
        }
    }

    public void exitSdk() {
        com.uucun.adsdk.b.a a = com.uucun.adsdk.b.a.a(this.context);
        a.a("last_end_time", System.currentTimeMillis());
        a.a();
        appConnect = null;
        this.initSdk.d(this.context);
        com.uucun.adsdk.a.b.a().b();
        this.initSdk = null;
        System.gc();
    }

    public void getPoints(UpdatePointListener updatePointListener) {
        this.initSdk.a(updatePointListener, this.context);
    }

    public void initSdk() {
        if (this.initSdk != null) {
            this.initSdk.a(this.context);
        }
    }

    public void showBanner(LinearLayout linearLayout, int i) {
        new l(this.context, linearLayout).a(i);
    }

    public void showOffers() {
        Intent intent = new Intent(this.context, (Class<?>) OfferActivity.class);
        intent.setFlags(268435456);
        this.context.startActivity(intent);
    }

    public void spendPoints(int i, UpdatePointListener updatePointListener) {
        if (this.initSdk != null) {
            this.initSdk.a(i, updatePointListener, this.context);
        }
    }

    public void startupCatchBugs() {
        this.initSdk.f(this.context);
    }
}
