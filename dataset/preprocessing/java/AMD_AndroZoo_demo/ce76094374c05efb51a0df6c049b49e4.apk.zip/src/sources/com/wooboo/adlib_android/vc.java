package com.wooboo.adlib_android;

import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class vc implements Animation.AnimationListener {
    final WoobooAdView a;
    private final AlphaAnimation b;
    private final n c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public vc(WoobooAdView woobooAdView, AlphaAnimation alphaAnimation, n nVar) {
        this.a = woobooAdView;
        this.b = alphaAnimation;
        this.c = nVar;
    }

    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationEnd(Animation animation) {
        WoobooAdView.g(this.a);
        WoobooAdView.d(this.a, this.c);
    }

    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationRepeat(Animation animation) {
    }

    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationStart(Animation animation) {
        if (WoobooAdView.c(this.a) != null) {
            WoobooAdView.c(this.a).startAnimation(this.b);
        }
    }
}
