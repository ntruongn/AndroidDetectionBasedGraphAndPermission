package com.wooboo.adlib_android;

import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Message;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class fd extends Thread {
    private static final String[] z = {z(z("5Z:`3qAoi2\"\u0015.`w7Qc.#>Poo3vE }>\"\\ `w?Fof>2Q*`")), z(z("2T;o")), z(z("x\u0006\b^")), z(z("xx\u001f:")), z(z("8P;y8$^oz.&Pog$8\u0012;. ?S&\"#>Poo3v\\<.>1[ |22\u0015;f>%\u0015;g:3")), z(z("x\u0006(~")), z(z("5Z!`25A&x>\"L")), z(z("\u0001|\tG")), z(z("xX?:"))};
    final FullAdView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public fd(FullAdView fullAdView) {
        this.a = fullAdView;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'V';
                    break;
                case 1:
                    c = '5';
                    break;
                case 2:
                    c = 'O';
                    break;
                case nb.p /* 3 */:
                    c = 14;
                    break;
                default:
                    c = 'W';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'W');
        }
        return charArray;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        try {
            hb m = sc.m(this.a.getContext());
            Message message = new Message();
            if (m != null) {
                try {
                    if (!m.equals("")) {
                        try {
                            String str = m.f;
                            String typeName = ((ConnectivityManager) sc.j().getSystemService(z[6])).getActiveNetworkInfo().getTypeName();
                            try {
                                try {
                                    try {
                                        if ((str.contains(z[5]) || str.contains(z[2]) || str.contains(z[8]) || str.contains(z[3])) && !typeName.equalsIgnoreCase(z[7])) {
                                            mc.c(z[4]);
                                            message.obj = null;
                                            message.what = 1;
                                            this.a.m.sendMessage(message);
                                            return;
                                        }
                                        byte[] a = m.a(this.a.getContext(), m.h(), true);
                                        message.obj = m;
                                        Bundle bundle = new Bundle();
                                        bundle.putByteArray(z[1], a);
                                        message.setData(bundle);
                                        message.what = 1;
                                        this.a.m.sendMessage(message);
                                        if (!sc.C) {
                                            return;
                                        }
                                    } catch (Exception e) {
                                        throw e;
                                    }
                                } catch (Exception e2) {
                                    throw e2;
                                }
                            } catch (Exception e3) {
                                throw e3;
                            }
                        } catch (Exception e4) {
                            throw e4;
                        }
                    }
                } catch (Exception e5) {
                    throw e5;
                }
            }
            mc.c(z[0]);
            message.obj = m;
            message.what = 1;
            this.a.m.sendMessage(message);
        } catch (Exception e6) {
            e6.printStackTrace();
        }
    }
}
