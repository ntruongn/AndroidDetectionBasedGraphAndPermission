package com.wooboo.adlib_android;

import android.content.DialogInterface;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class sb implements DialogInterface.OnClickListener {
    final FullAdView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public sb(FullAdView fullAdView) {
        this.a = fullAdView;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        FullAdView.b(this.a);
    }
}
