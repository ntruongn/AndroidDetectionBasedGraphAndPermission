package com.wooboo.download;

import android.os.Bundle;
import android.os.Handler;
import com.wooboo.adlib_android.nb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class b extends Handler {
    private static final String[] z = {z(z("z6x")), z(z("z>k"))};
    Bundle a = null;
    final WoobooService b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(WoobooService woobooService) {
        this.b = woobooService;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '*';
                    break;
                case 1:
                    c = '}';
                    break;
                case 2:
                    c = '?';
                    break;
                case nb.p /* 3 */:
                    c = 'm';
                    break;
                default:
                    c = '\"';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '\"');
        }
        return charArray;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to find 'out' block for switch in B:2:0x0005. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:10:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:13:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:16:? A[RETURN, SYNTHETIC] */
    @Override // android.os.Handler
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void handleMessage(android.os.Message r8) {
        /*
            r7 = this;
            r6 = 0
            boolean r0 = com.wooboo.download.h.e
            int r1 = r8.what
            switch(r1) {
                case 110: goto L70;
                case 1110001: goto L20;
                case 1110002: goto L9;
                case 1110003: goto L42;
                case 1110004: goto L59;
                default: goto L8;
            }
        L8:
            return
        L9:
            android.os.Bundle r1 = r8.getData()
            r7.a = r1
            com.wooboo.download.WoobooService r1 = r7.b
            android.os.Bundle r2 = r7.a
            java.lang.String[] r3 = com.wooboo.download.b.z
            r3 = r3[r6]
            java.lang.String r2 = r2.getString(r3)
            r1.b(r2)
            if (r0 == 0) goto L8
        L20:
            android.os.Bundle r1 = r8.getData()
            r7.a = r1
            com.wooboo.download.WoobooService r1 = r7.b
            android.os.Bundle r2 = r7.a
            java.lang.String[] r3 = com.wooboo.download.b.z
            r3 = r3[r6]
            java.lang.String r2 = r2.getString(r3)
            android.os.Bundle r3 = r7.a
            java.lang.String[] r4 = com.wooboo.download.b.z
            r5 = 1
            r4 = r4[r5]
            int r3 = r3.getInt(r4)
            r1.a(r2, r3)
            if (r0 == 0) goto L8
        L42:
            android.os.Bundle r1 = r8.getData()
            r7.a = r1
            com.wooboo.download.WoobooService r1 = r7.b
            android.os.Bundle r2 = r7.a
            java.lang.String[] r3 = com.wooboo.download.b.z
            r3 = r3[r6]
            java.lang.String r2 = r2.getString(r3)
            r1.c(r2)
            if (r0 == 0) goto L8
        L59:
            android.os.Bundle r1 = r8.getData()
            r7.a = r1
            com.wooboo.download.WoobooService r1 = r7.b
            android.os.Bundle r2 = r7.a
            java.lang.String[] r3 = com.wooboo.download.b.z
            r3 = r3[r6]
            java.lang.String r2 = r2.getString(r3)
            com.wooboo.download.WoobooService.a(r1, r2)
            if (r0 == 0) goto L8
        L70:
            com.wooboo.download.WoobooService r0 = r7.b
            com.wooboo.download.f r0 = r0.m
            r0.a()
            goto L8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.download.b.handleMessage(android.os.Message):void");
    }
}
