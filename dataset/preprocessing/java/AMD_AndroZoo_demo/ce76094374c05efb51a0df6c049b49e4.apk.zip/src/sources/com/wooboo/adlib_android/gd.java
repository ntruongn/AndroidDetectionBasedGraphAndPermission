package com.wooboo.adlib_android;

import android.os.Bundle;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class gd extends Thread {
    private static final String[] z = {z(z(",k\u0003%#hpV,\";$\u0017%g.`Zk3'aV*#ot\u00198.;m\u0019%g&wV#.+`\u0013%")), z(z("\u001aj\u001e*)+h\u0013/g*|\u0015.7;m\u0019%g=a\u0007>\"<p\u001f% oeV-5*w\u001ek&+*")), z(z("+e\u0002*"))};

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'O';
                    break;
                case 1:
                    c = 4;
                    break;
                case 2:
                    c = 'v';
                    break;
                case nb.p /* 3 */:
                    c = 'K';
                    break;
                default:
                    c = 'G';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'G');
        }
        return charArray;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        try {
            hb m = sc.m(HalfAdView.h());
            if (m != null) {
                try {
                    if (!m.equals("")) {
                        byte[] a = m.a(HalfAdView.h(), m.h(), true);
                        Message message = new Message();
                        message.obj = m;
                        Bundle bundle = new Bundle();
                        bundle.putByteArray(z[2], a);
                        message.setData(bundle);
                        message.what = 2;
                        HalfAdView.p.sendMessage(message);
                        if (!sc.C) {
                            return;
                        }
                    }
                } catch (Exception e) {
                    throw e;
                }
            }
            mc.c(z[0]);
            Message message2 = new Message();
            message2.obj = m;
            message2.what = 2;
            HalfAdView.p.sendMessage(message2);
        } catch (Exception e2) {
            mc.c(z[1]);
        }
    }
}
