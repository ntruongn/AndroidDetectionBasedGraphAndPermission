package com.wooboo.adlib_android;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Environment;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public abstract class oc {
    private final Context b;
    private final String c;
    private final SQLiteDatabase.CursorFactory d;
    private final int e;
    private SQLiteDatabase f = null;
    private boolean g = false;
    private static final String[] z = {z(z("(\u000eY$x\u000fBR\"o\u0002\fQwt\u0005\u000bB>|\u0007\u000bL6i\u0002\rX")), z(z("D\u0006Tx")), z(z("\u0006\rC9i\u000e\u0006")), z(z("(\u0003XpiK\u0017F0o\n\u0006Swo\u000e\u0003Rzr\u0005\u000eOwy\n\u0016W5|\u0018\u0007\u00161o\u0004\u000f\u0016!x\u0019\u0011_8sK")), z(z("\f\u0007B\u0005x\n\u0006W5q\u000e&W#|\t\u0003E2=\b\u0003Z;x\u000fBD2~\u001e\u0010E>k\u000e\u000eO")), z(z("K\u0016Yw")), z(z("$\u0012S9x\u000fB")), z(z("K\u0004Y%=\u001c\u0010_#t\u0005\u0005\u0016\u007fj\u0002\u000eZwi\u0019\u001b\u0016%x\n\u0006\u001b8s\u0007\u001b\u001fm")), z(z("QB")), z(z("K\u000bXwo\u000e\u0003Rzr\u0005\u000eOwp\u0004\u0006S")), z(z("(\rC;y\u0005EBwr\u001b\u0007Xw")), z(z("\f\u0007B\u0000o\u0002\u0016W5q\u000e&W#|\t\u0003E2=\b\u0003Z;x\u000fBD2~\u001e\u0010E>k\u000e\u000eO")), z(z("=\u0007D$t\u0004\f\u0016:h\u0018\u0016\u00165xK\\\u000bw,GBA6nK"))};
    private static final String a = oc.class.getSimpleName();

    public oc(Context context, String str, SQLiteDatabase.CursorFactory cursorFactory, int i) {
        if (i < 1) {
            throw new IllegalArgumentException(z[12] + i);
        }
        this.b = context;
        this.c = str;
        this.d = cursorFactory;
        this.e = i;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'k';
                    break;
                case 1:
                    c = 'b';
                    break;
                case 2:
                    c = '6';
                    break;
                case nb.p /* 3 */:
                    c = 'W';
                    break;
                default:
                    c = 29;
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 29);
        }
        return charArray;
    }

    /* JADX WARN: Code restructure failed: missing block: B:42:0x0053, code lost:
    
        if (r2 != false) goto L39;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public synchronized android.database.sqlite.SQLiteDatabase a() {
        /*
            Method dump skipped, instructions count: 192
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.oc.a():android.database.sqlite.SQLiteDatabase");
    }

    public File a(String str) {
        String str2 = null;
        if (Environment.getExternalStorageState().equals(z[2])) {
            str2 = String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + z[1];
            File file = new File(str2);
            try {
                if (!file.exists()) {
                    file.mkdirs();
                }
            } catch (IllegalArgumentException e) {
                throw e;
            }
        }
        return new File(String.valueOf(str2) + str);
    }

    public abstract void a(SQLiteDatabase sQLiteDatabase);

    public abstract void a(SQLiteDatabase sQLiteDatabase, int i, int i2);

    public synchronized SQLiteDatabase b() {
        SQLiteDatabase sQLiteDatabase;
        try {
            try {
                if (this.f == null || !this.f.isOpen()) {
                    try {
                        if (this.g) {
                            throw new IllegalStateException(z[4]);
                        }
                        try {
                            sQLiteDatabase = a();
                        } catch (SQLiteException e) {
                            try {
                                if (this.c == null) {
                                    throw e;
                                }
                                mc.c(z[10] + this.c + z[7] + e.getMessage());
                                SQLiteDatabase sQLiteDatabase2 = null;
                                try {
                                    this.g = true;
                                    String path = a(this.c).getPath();
                                    SQLiteDatabase openDatabase = SQLiteDatabase.openDatabase(path, this.d, 0);
                                    try {
                                        if (openDatabase.getVersion() != this.e) {
                                            throw new SQLiteException(z[3] + openDatabase.getVersion() + z[5] + this.e + z[8] + path);
                                        }
                                        b(openDatabase);
                                        mc.c(z[6] + this.c + z[9]);
                                        this.f = openDatabase;
                                        sQLiteDatabase = this.f;
                                        try {
                                            try {
                                                this.g = false;
                                                if (openDatabase != null && openDatabase != this.f) {
                                                    openDatabase.close();
                                                }
                                            } catch (SQLiteException e2) {
                                                throw e2;
                                            }
                                        } catch (SQLiteException e3) {
                                            throw e3;
                                        }
                                    } catch (SQLiteException e4) {
                                        throw e4;
                                    }
                                } catch (Throwable th) {
                                    try {
                                        try {
                                            this.g = false;
                                            if (0 != 0 && null != this.f) {
                                                sQLiteDatabase2.close();
                                            }
                                            throw th;
                                        } catch (SQLiteException e5) {
                                            throw e5;
                                        }
                                    } catch (SQLiteException e6) {
                                        throw e6;
                                    }
                                }
                            } catch (SQLiteException e7) {
                                throw e7;
                            }
                        }
                    } catch (SQLiteException e8) {
                        throw e8;
                    }
                }
                sQLiteDatabase = this.f;
            } catch (SQLiteException e9) {
                throw e9;
            }
        } catch (SQLiteException e10) {
            throw e10;
        }
        return sQLiteDatabase;
    }

    public void b(SQLiteDatabase sQLiteDatabase) {
    }

    public synchronized void c() {
        try {
            try {
                if (this.g) {
                    throw new IllegalStateException(z[0]);
                }
                try {
                    if (this.f != null && this.f.isOpen()) {
                        this.f.close();
                        this.f = null;
                    }
                } catch (IllegalArgumentException e) {
                    throw e;
                }
            } catch (IllegalArgumentException e2) {
                throw e2;
            }
        } catch (IllegalArgumentException e3) {
            throw e3;
        }
    }
}
