package com.kuguo.openads;

import android.graphics.Bitmap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class g {
    public boolean a;
    public String b;
    public String c;
    public int d;
    public Bitmap e;
    public String f;
    public int g;
    public int h;
    public int i;
    public String j;
    public String k;
    public int l = 0;
    public float m = 1.0f;
    public Object n;
}
