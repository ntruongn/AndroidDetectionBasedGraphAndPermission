package com.kuguo.pushads;

import android.app.Activity;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import com.wooboo.adlib_android.nb;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class c {
    private int c;
    private j d;
    private g e;
    private Activity f;
    l a = new l(this, null);
    private Handler g = new r(this);
    View.OnClickListener b = new s(this);

    public c(Activity activity, j jVar, boolean z) {
        this.c = 0;
        this.f = activity;
        this.d = jVar;
        com.kuguo.a.d dVar = new com.kuguo.a.d(jVar.o, a.b(activity, "icon.png", jVar.h));
        dVar.a((Object) (-1));
        h.a(activity, dVar, this.a);
        String[] a = a.a(jVar.p, ";");
        if (a != null) {
            this.c = a.length;
        }
        a(z);
        for (int i = 0; i < this.c; i++) {
            com.kuguo.a.d dVar2 = new com.kuguo.a.d(a[i], a.b(activity, i + ".png", jVar.h));
            dVar2.a(Integer.valueOf(i));
            h.a(this.f, dVar2, this.a);
        }
    }

    private Map a(String str) {
        HashMap hashMap = new HashMap();
        String[] a = a.a(str, "|");
        if (a != null) {
            for (String str2 : a) {
                String[] a2 = a.a(str2, "=");
                if (a2 != null && a2.length == 2) {
                    hashMap.put(a2[0], a2[1]);
                }
            }
        }
        return hashMap;
    }

    private void a(boolean z) {
        this.e = new g(this.f, z);
        this.e.a(this.c);
        this.e.d(this.d.b);
        this.e.b(this.d.l);
        this.e.c(this.d.n);
        this.e.a(this.d.m);
        this.e.a(this.d.k);
        this.e.a(a(this.d.v));
        this.e.a(this.b);
        switch (this.d.e) {
            case 2:
            case 4:
                this.e.a();
                return;
            case nb.p /* 3 */:
            default:
                return;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a() {
        this.f.setContentView(this.e, new LinearLayout.LayoutParams(-1, -1));
    }
}
