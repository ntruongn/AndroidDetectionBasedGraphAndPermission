package com.uucun.adsdk.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.DoEncrypt;
import com.uucun.adsdk.UUAppConnect;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class l implements com.uucun.adsdk.c.i {
    public static final String a = l.class.getSimpleName();
    private LinearLayout c;
    private ImageView d;
    private Context e;
    private Handler g;
    private int i;
    private int j;
    private com.uucun.adsdk.a.a m;
    private Timer n;
    private com.uucun.adsdk.d.e f = null;
    private int h = -1;
    private boolean k = true;
    private Bitmap l = null;
    final Runnable b = new i(this);

    public l(Context context, LinearLayout linearLayout) {
        this.g = null;
        this.i = 320;
        this.j = 480;
        this.m = null;
        this.n = null;
        this.e = context;
        this.c = linearLayout;
        this.n = new Timer();
        this.g = new Handler();
        this.m = com.uucun.adsdk.a.a.a();
        this.d = new f(this, context);
        this.d.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.c.addView(this.d);
        this.c.setVisibility(8);
        int[] a2 = com.uucun.adsdk.b.b.a(context, true);
        this.i = a2[0];
        this.j = a2[1];
        this.d.setOnClickListener(new e(this));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(String str) {
        if (!this.k || str == null || TextUtils.isEmpty(str.trim())) {
            return;
        }
        String d = this.m.d();
        JSONObject jSONObject = new JSONObject();
        HashMap c = com.uucun.adsdk.d.c(this.e);
        try {
            String str2 = (String) c.get("app_key");
            String str3 = (String) c.get("imei");
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put("flag", "1");
            jSONObject.put("old_ad_ids", d);
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(str3);
            stringBuffer.append("|");
            stringBuffer.append(str);
            stringBuffer.append("|");
            stringBuffer.append(com.uucun.adsdk.b.c.a());
            jSONObject.put("valid_key", DoEncrypt.encodecrypt(str2, stringBuffer.toString()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        new com.uucun.adsdk.c.c(this.e, com.uucun.adsdk.b.k.a().j, jSONObject, true).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d() {
        if (this.k) {
            if (this.m.c()) {
                com.uucun.adsdk.b.h.c(a, "没有广告");
                b();
                return;
            }
            if (this.h + 1 >= this.m.e()) {
                com.uucun.adsdk.b.h.c(a, "老的广告显示完，载入新的广告");
                b();
                return;
            }
            this.h++;
            this.f = this.m.a(this.h);
            if (this.f != null) {
                this.f.d = com.uucun.adsdk.b.c.a(this.f.b, this.e);
            }
            if (e()) {
                com.uucun.adsdk.b.h.c(a, "显示广告：ID:" + this.f.c + " old size: " + this.f.d.getWidth() + " x " + this.f.d.getHeight() + " new size:" + this.l.getWidth() + " x " + this.l.getHeight() + " imageView size: " + this.c.getWidth() + " x " + this.c.getHeight());
                new h(this).start();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean e() {
        if (this.f == null || this.f.d == null) {
            return false;
        }
        if (this.l != null && this.l.isRecycled()) {
            this.l.recycle();
        }
        com.uucun.adsdk.b.h.c(a, "Point:" + this.f.e + " AD ID:" + this.f.c + " " + this.f.i);
        this.l = com.uucun.adsdk.b.c.a(this.f, this.i, this.j < 480 ? 50 : (int) (this.j * 0.12d), "1".equals(this.f.i));
        this.c.setVisibility(0);
        this.c.setGravity(17);
        this.d.setImageBitmap(this.l);
        this.d.setLayoutParams(new LinearLayout.LayoutParams(this.l.getWidth(), this.l.getHeight() + 1));
        com.uucun.adsdk.b.c.b(this.d);
        return true;
    }

    @Override // com.uucun.adsdk.c.i
    public void a() {
        com.uucun.adsdk.b.h.c(a, "Can Not Fetch Ads,Remove Old And Hide The View.");
        this.c.setVisibility(8);
        c();
        com.uucun.adsdk.a.a.a = false;
    }

    public void a(int i) {
        this.n.schedule(new j(this), 0L, ((i >= 20 ? i : 20) > 60 ? 60 : r1) * 1000);
    }

    public void a(com.uucun.adsdk.d.e eVar) {
        com.uucun.adsdk.b.h.c(a, "Enter Url :" + eVar.a + " Ad id : " + eVar.c);
        if (com.uucun.adsdk.a.c.a().a(eVar.c)) {
            UUAppConnect.showToast("该任务正在进行!", this.e);
            return;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("imei", com.uucun.adsdk.d.c(this.e).get("imei"));
            jSONObject.put("event_type", "1");
            jSONObject.put("flag", "1");
            jSONObject.put("ad_id", eVar.c);
            jSONObject.put("isInstall", eVar.h);
        } catch (Exception e) {
        }
        com.uucun.adsdk.c.b bVar = new com.uucun.adsdk.c.b(this.e, eVar.a, eVar.c);
        com.uucun.adsdk.a.c.a().a(bVar);
        bVar.execute(new JSONObject[]{jSONObject});
    }

    @Override // com.uucun.adsdk.c.i
    public void a(ArrayList arrayList) {
        c();
        if (arrayList == null) {
            return;
        }
        int size = arrayList.size();
        if (this.m.c()) {
            this.h = -1;
        } else {
            this.h = size;
        }
        for (int i = 0; i < size; i++) {
            this.m.a((com.uucun.adsdk.d.e) arrayList.get(i));
        }
        this.g.post(this.b);
        com.uucun.adsdk.a.a.a = false;
    }

    public void b() {
        if (com.uucun.adsdk.a.a.a) {
            com.uucun.adsdk.b.h.c(a, "已经有抓取广告的任务了...");
            return;
        }
        HashMap c = com.uucun.adsdk.d.c(this.e);
        com.uucun.adsdk.b.h.c(a, "开启抓取广告的任务...");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("imei", c.get("imei"));
            if (com.uucun.adsdk.a.a.a().c.length() == 0) {
                jSONObject.put("old_ad_ids", "");
            } else {
                jSONObject.put("old_ad_ids", com.uucun.adsdk.a.a.a().c.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        com.uucun.adsdk.a.a.a = true;
        new com.uucun.adsdk.c.a(com.uucun.adsdk.b.k.a().i, this.e, this).execute(new JSONObject[]{jSONObject});
    }

    public void c() {
        this.g.post(new g(this));
        this.m.b();
        if (this.l == null || !this.l.isRecycled()) {
            return;
        }
        this.l.recycle();
        this.l = null;
    }
}
