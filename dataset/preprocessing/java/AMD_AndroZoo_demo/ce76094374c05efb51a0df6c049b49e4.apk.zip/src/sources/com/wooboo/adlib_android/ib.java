package com.wooboo.adlib_android;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public interface ib {
    void a();

    void a(Context context, String str, String str2, String str3, String str4, String str5, String str6, String str7);

    void b();

    void c();
}
