package com.kuguo.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.kuguo.d.c;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class NavigationBar extends FrameLayout {
    private FrameLayout a;

    public NavigationBar(Context context) {
        this(context, null);
    }

    public NavigationBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setPadding(5, 5, 5, 5);
        this.a = new FrameLayout(context);
        a(this.a);
    }

    public void a(View view) {
        removeAllViews();
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        layoutParams.gravity = 16;
        view.setLayoutParams(layoutParams);
        addView(view);
    }

    public void a(String str) {
        TextView textView = new TextView(getContext());
        textView.setText(str);
        textView.setTextSize(18.0f);
        textView.setTextColor(-1);
        textView.setGravity(17);
        c(textView);
    }

    public void b(View view) {
        View findViewById = this.a.findViewById(0);
        if (findViewById != null) {
            this.a.removeView(findViewById);
        }
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 19;
        view.setLayoutParams(layoutParams);
        this.a.addView(view);
        view.setId(0);
    }

    public void c(View view) {
        FrameLayout.LayoutParams layoutParams;
        View findViewById = this.a.findViewById(1);
        if (findViewById != null) {
            this.a.removeView(findViewById);
        }
        if (view instanceof TextView) {
            ((TextView) view).setGravity(17);
            layoutParams = new FrameLayout.LayoutParams(c.a(getContext(), 200), -2, 1);
        } else {
            layoutParams = new FrameLayout.LayoutParams(-2, -2, 1);
        }
        layoutParams.gravity = 17;
        view.setLayoutParams(layoutParams);
        this.a.addView(view);
        view.setId(1);
    }

    public void d(View view) {
        View findViewById = this.a.findViewById(2);
        if (findViewById != null) {
            this.a.removeView(findViewById);
        }
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 21;
        view.setLayoutParams(layoutParams);
        this.a.addView(view);
        view.setId(2);
    }
}
