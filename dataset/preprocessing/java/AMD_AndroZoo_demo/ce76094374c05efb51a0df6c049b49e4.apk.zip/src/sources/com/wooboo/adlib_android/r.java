package com.wooboo.adlib_android;

import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class r implements View.OnClickListener {
    final l a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public r(l lVar) {
        this.a = lVar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        AdActivity.a(l.a(this.a), ((Integer) view.getTag()).intValue());
    }
}
