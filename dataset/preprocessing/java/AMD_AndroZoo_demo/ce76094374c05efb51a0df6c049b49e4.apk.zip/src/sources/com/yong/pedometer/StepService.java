package com.yong.pedometer;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Binder;
import android.os.IBinder;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;
import com.mobclick.android.UmengConstants;
import com.yong.pedometer.CaloriesNotifier;
import com.yong.pedometer.DistanceNotifier;
import com.yong.pedometer.PaceNotifier;
import com.yong.pedometer.SpeedNotifier;
import com.yong.pedometer.StepDisplayer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class StepService extends Service {
    private static final String TAG = "name.bagi.levente.pedometer.StepService";
    private ICallback mCallback;
    private float mCalories;
    private CaloriesNotifier mCaloriesNotifier;
    private int mDesiredPace;
    private float mDesiredSpeed;
    private float mDistance;
    private DistanceNotifier mDistanceNotifier;
    private NotificationManager mNM;
    private int mPace;
    private PaceNotifier mPaceNotifier;
    private PedometerSettings mPedometerSettings;
    private Sensor mSensor;
    private SensorManager mSensorManager;
    private SharedPreferences mSettings;
    private SpeakingTimer mSpeakingTimer;
    private float mSpeed;
    private SpeedNotifier mSpeedNotifier;
    private SharedPreferences mState;
    private SharedPreferences.Editor mStateEditor;
    private StepDetector mStepDetector;
    private StepDisplayer mStepDisplayer;
    private int mSteps;
    private Utils mUtils;
    private PowerManager.WakeLock wakeLock;
    private final IBinder mBinder = new StepBinder();
    private StepDisplayer.Listener mStepListener = new StepDisplayer.Listener() { // from class: com.yong.pedometer.StepService.1
        @Override // com.yong.pedometer.StepDisplayer.Listener
        public void stepsChanged(int value) {
            StepService.this.mSteps = value;
            passValue();
        }

        @Override // com.yong.pedometer.StepDisplayer.Listener
        public void passValue() {
            if (StepService.this.mCallback != null) {
                StepService.this.mCallback.stepsChanged(StepService.this.mSteps);
            }
        }
    };
    private PaceNotifier.Listener mPaceListener = new PaceNotifier.Listener() { // from class: com.yong.pedometer.StepService.2
        @Override // com.yong.pedometer.PaceNotifier.Listener
        public void paceChanged(int value) {
            StepService.this.mPace = value;
            passValue();
        }

        @Override // com.yong.pedometer.PaceNotifier.Listener
        public void passValue() {
            if (StepService.this.mCallback != null) {
                StepService.this.mCallback.paceChanged(StepService.this.mPace);
            }
        }
    };
    private DistanceNotifier.Listener mDistanceListener = new DistanceNotifier.Listener() { // from class: com.yong.pedometer.StepService.3
        @Override // com.yong.pedometer.DistanceNotifier.Listener
        public void valueChanged(float value) {
            StepService.this.mDistance = value;
            passValue();
        }

        @Override // com.yong.pedometer.DistanceNotifier.Listener
        public void passValue() {
            if (StepService.this.mCallback != null) {
                StepService.this.mCallback.distanceChanged(StepService.this.mDistance);
            }
        }
    };
    private SpeedNotifier.Listener mSpeedListener = new SpeedNotifier.Listener() { // from class: com.yong.pedometer.StepService.4
        @Override // com.yong.pedometer.SpeedNotifier.Listener
        public void valueChanged(float value) {
            StepService.this.mSpeed = value;
            passValue();
        }

        @Override // com.yong.pedometer.SpeedNotifier.Listener
        public void passValue() {
            if (StepService.this.mCallback != null) {
                StepService.this.mCallback.speedChanged(StepService.this.mSpeed);
            }
        }
    };
    private CaloriesNotifier.Listener mCaloriesListener = new CaloriesNotifier.Listener() { // from class: com.yong.pedometer.StepService.5
        @Override // com.yong.pedometer.CaloriesNotifier.Listener
        public void valueChanged(float value) {
            StepService.this.mCalories = value;
            passValue();
        }

        @Override // com.yong.pedometer.CaloriesNotifier.Listener
        public void passValue() {
            if (StepService.this.mCallback != null) {
                StepService.this.mCallback.caloriesChanged(StepService.this.mCalories);
            }
        }
    };
    private BroadcastReceiver mReceiver = new BroadcastReceiver() { // from class: com.yong.pedometer.StepService.6
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("android.intent.action.SCREEN_OFF")) {
                StepService.this.unregisterDetector();
                StepService.this.registerDetector();
                if (StepService.this.mPedometerSettings.wakeAggressively()) {
                    StepService.this.wakeLock.release();
                    StepService.this.acquireWakeLock();
                }
            }
        }
    };

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public interface ICallback {
        void caloriesChanged(float f);

        void distanceChanged(float f);

        void paceChanged(int i);

        void speedChanged(float f);

        void stepsChanged(int i);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public class StepBinder extends Binder {
        public StepBinder() {
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public StepService getService() {
            return StepService.this;
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        Log.i(TAG, "[SERVICE] onCreate");
        super.onCreate();
        this.mNM = (NotificationManager) getSystemService("notification");
        showNotification();
        this.mSettings = PreferenceManager.getDefaultSharedPreferences(this);
        this.mPedometerSettings = new PedometerSettings(this.mSettings);
        this.mState = getSharedPreferences(UmengConstants.AtomKey_State, 0);
        this.mUtils = Utils.getInstance();
        this.mUtils.setService(this);
        this.mUtils.initTTS();
        acquireWakeLock();
        this.mStepDetector = new StepDetector();
        this.mSensorManager = (SensorManager) getSystemService("sensor");
        registerDetector();
        IntentFilter filter = new IntentFilter("android.intent.action.SCREEN_OFF");
        registerReceiver(this.mReceiver, filter);
        this.mStepDisplayer = new StepDisplayer(this.mPedometerSettings, this.mUtils);
        StepDisplayer stepDisplayer = this.mStepDisplayer;
        int i = this.mState.getInt("steps", 0);
        this.mSteps = i;
        stepDisplayer.setSteps(i);
        this.mStepDisplayer.addListener(this.mStepListener);
        this.mStepDetector.addStepListener(this.mStepDisplayer);
        this.mPaceNotifier = new PaceNotifier(this.mPedometerSettings, this.mUtils);
        PaceNotifier paceNotifier = this.mPaceNotifier;
        int i2 = this.mState.getInt("pace", 0);
        this.mPace = i2;
        paceNotifier.setPace(i2);
        this.mPaceNotifier.addListener(this.mPaceListener);
        this.mStepDetector.addStepListener(this.mPaceNotifier);
        this.mDistanceNotifier = new DistanceNotifier(this.mDistanceListener, this.mPedometerSettings, this.mUtils);
        DistanceNotifier distanceNotifier = this.mDistanceNotifier;
        float f = this.mState.getFloat("distance", 0.0f);
        this.mDistance = f;
        distanceNotifier.setDistance(f);
        this.mStepDetector.addStepListener(this.mDistanceNotifier);
        this.mSpeedNotifier = new SpeedNotifier(this.mSpeedListener, this.mPedometerSettings, this.mUtils);
        SpeedNotifier speedNotifier = this.mSpeedNotifier;
        float f2 = this.mState.getFloat("speed", 0.0f);
        this.mSpeed = f2;
        speedNotifier.setSpeed(f2);
        this.mPaceNotifier.addListener(this.mSpeedNotifier);
        this.mCaloriesNotifier = new CaloriesNotifier(this.mCaloriesListener, this.mPedometerSettings, this.mUtils);
        CaloriesNotifier caloriesNotifier = this.mCaloriesNotifier;
        float f3 = this.mState.getFloat("calories", 0.0f);
        this.mCalories = f3;
        caloriesNotifier.setCalories(f3);
        this.mStepDetector.addStepListener(this.mCaloriesNotifier);
        this.mSpeakingTimer = new SpeakingTimer(this.mPedometerSettings, this.mUtils);
        this.mSpeakingTimer.addListener(this.mStepDisplayer);
        this.mSpeakingTimer.addListener(this.mPaceNotifier);
        this.mSpeakingTimer.addListener(this.mDistanceNotifier);
        this.mSpeakingTimer.addListener(this.mSpeedNotifier);
        this.mSpeakingTimer.addListener(this.mCaloriesNotifier);
        this.mStepDetector.addStepListener(this.mSpeakingTimer);
        reloadSettings();
        Toast.makeText(this, getText(R.string.started), 0).show();
    }

    @Override // android.app.Service
    public void onStart(Intent intent, int startId) {
        Log.i(TAG, "[SERVICE] onStart");
        super.onStart(intent, startId);
    }

    @Override // android.app.Service
    public void onDestroy() {
        Log.i(TAG, "[SERVICE] onDestroy");
        this.mUtils.shutdownTTS();
        unregisterReceiver(this.mReceiver);
        unregisterDetector();
        this.mStateEditor = this.mState.edit();
        this.mStateEditor.putInt("steps", this.mSteps);
        this.mStateEditor.putInt("pace", this.mPace);
        this.mStateEditor.putFloat("distance", this.mDistance);
        this.mStateEditor.putFloat("speed", this.mSpeed);
        this.mStateEditor.putFloat("calories", this.mCalories);
        this.mStateEditor.commit();
        this.mNM.cancel(R.string.app_name);
        this.wakeLock.release();
        super.onDestroy();
        this.mSensorManager.unregisterListener(this.mStepDetector);
        Toast.makeText(this, getText(R.string.stopped), 0).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void registerDetector() {
        this.mSensor = this.mSensorManager.getDefaultSensor(1);
        this.mSensorManager.registerListener(this.mStepDetector, this.mSensor, 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void unregisterDetector() {
        this.mSensorManager.unregisterListener(this.mStepDetector);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        Log.i(TAG, "[SERVICE] onBind");
        return this.mBinder;
    }

    public void registerCallback(ICallback cb) {
        this.mCallback = cb;
    }

    public void setDesiredPace(int desiredPace) {
        this.mDesiredPace = desiredPace;
        if (this.mPaceNotifier != null) {
            this.mPaceNotifier.setDesiredPace(this.mDesiredPace);
        }
    }

    public void setDesiredSpeed(float desiredSpeed) {
        this.mDesiredSpeed = desiredSpeed;
        if (this.mSpeedNotifier != null) {
            this.mSpeedNotifier.setDesiredSpeed(this.mDesiredSpeed);
        }
    }

    public void reloadSettings() {
        this.mSettings = PreferenceManager.getDefaultSharedPreferences(this);
        if (this.mStepDetector != null) {
            this.mStepDetector.setSensitivity(Float.valueOf(this.mSettings.getString("sensitivity", "10")).floatValue());
        }
        if (this.mStepDisplayer != null) {
            this.mStepDisplayer.reloadSettings();
        }
        if (this.mPaceNotifier != null) {
            this.mPaceNotifier.reloadSettings();
        }
        if (this.mDistanceNotifier != null) {
            this.mDistanceNotifier.reloadSettings();
        }
        if (this.mSpeedNotifier != null) {
            this.mSpeedNotifier.reloadSettings();
        }
        if (this.mCaloriesNotifier != null) {
            this.mCaloriesNotifier.reloadSettings();
        }
        if (this.mSpeakingTimer != null) {
            this.mSpeakingTimer.reloadSettings();
        }
    }

    public void resetValues() {
        this.mStepDisplayer.setSteps(0);
        this.mPaceNotifier.setPace(0);
        this.mDistanceNotifier.setDistance(0.0f);
        this.mSpeedNotifier.setSpeed(0.0f);
        this.mCaloriesNotifier.setCalories(0.0f);
    }

    private void showNotification() {
        CharSequence text = getText(R.string.app_name);
        Notification notification = new Notification(R.drawable.ic_notification, null, System.currentTimeMillis());
        notification.flags = 34;
        Intent pedometerIntent = new Intent();
        pedometerIntent.setComponent(new ComponentName(this, (Class<?>) Pedometer.class));
        pedometerIntent.addFlags(67108864);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, pedometerIntent, 0);
        notification.setLatestEventInfo(this, text, getText(R.string.notification_subtitle), contentIntent);
        this.mNM.notify(R.string.app_name, notification);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void acquireWakeLock() {
        int wakeFlags;
        PowerManager pm = (PowerManager) getSystemService("power");
        if (this.mPedometerSettings.wakeAggressively()) {
            wakeFlags = 268435462;
        } else if (this.mPedometerSettings.keepScreenOn()) {
            wakeFlags = 6;
        } else {
            wakeFlags = 1;
        }
        this.wakeLock = pm.newWakeLock(wakeFlags, TAG);
        this.wakeLock.acquire();
    }
}
