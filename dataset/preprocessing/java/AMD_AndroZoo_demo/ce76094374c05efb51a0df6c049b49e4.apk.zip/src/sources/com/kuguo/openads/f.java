package com.kuguo.openads;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import com.wooboo.adlib_android.nb;
import java.io.File;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class f implements com.kuguo.a.c {
    int a = -1;
    final /* synthetic */ k b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(k kVar) {
        this.b = kVar;
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, int i) {
        Context context;
        Context context2;
        NotificationManager notificationManager;
        File file;
        Context context3;
        Context context4;
        NotificationManager notificationManager2;
        Context context5;
        Context context6;
        NotificationManager notificationManager3;
        Context context7;
        Context context8;
        NotificationManager notificationManager4;
        g gVar = (g) dVar.k();
        switch (i) {
            case 1:
                gVar.l = 1;
                this.b.c();
                Notification notification = new Notification(17301633, gVar.b, System.currentTimeMillis());
                context7 = this.b.b;
                String str = gVar.b;
                context8 = this.b.b;
                notification.setLatestEventInfo(context7, "正在等待下载...", str, PendingIntent.getActivity(context8, 0, new Intent(), 0));
                notificationManager4 = this.b.j;
                notificationManager4.notify(gVar.i, notification);
                gVar.n = notification;
                return;
            case 2:
                Notification notification2 = (Notification) gVar.n;
                if (notification2 != null) {
                    context5 = this.b.b;
                    String str2 = gVar.b;
                    context6 = this.b.b;
                    notification2.setLatestEventInfo(context5, "正在下载中...", str2, PendingIntent.getActivity(context6, 0, new Intent(), 0));
                    notificationManager3 = this.b.j;
                    notificationManager3.notify(gVar.i, notification2);
                    return;
                }
                return;
            case nb.p /* 3 */:
            default:
                return;
            case 4:
                gVar.l = 2;
                this.b.f(gVar);
                Notification notification3 = (Notification) gVar.n;
                if (notification3 != null) {
                    notification3.icon = 17301634;
                    context3 = this.b.b;
                    String str3 = gVar.b;
                    context4 = this.b.b;
                    notification3.setLatestEventInfo(context3, "下载完成", str3, PendingIntent.getActivity(context4, 0, new Intent(), 0));
                    notification3.flags = 16;
                    notificationManager2 = this.b.j;
                    notificationManager2.notify(gVar.i, notification3);
                }
                File b = dVar.b();
                String path = b.getPath();
                if (path.endsWith(".apk_")) {
                    file = new File(path.substring(0, path.length() - 1));
                    b.renameTo(file);
                } else {
                    file = b;
                }
                this.b.a(file, gVar);
                return;
            case 5:
                gVar.l = 0;
                this.b.c();
                Notification notification4 = (Notification) gVar.n;
                if (notification4 != null) {
                    notification4.icon = 17301624;
                    context = this.b.b;
                    String str4 = gVar.b;
                    context2 = this.b.b;
                    notification4.setLatestEventInfo(context, "下载失败", str4, PendingIntent.getActivity(context2, 0, new Intent(), 0));
                    notification4.flags = 16;
                    notificationManager = this.b.j;
                    notificationManager.notify(gVar.i, notification4);
                }
                this.b.b(gVar.b + "下载失败...");
                this.b.g(gVar);
                dVar.f();
                Exception c = dVar.c();
                if (c != null) {
                    c.printStackTrace();
                    return;
                }
                return;
        }
    }

    @Override // com.kuguo.a.c
    public void a(com.kuguo.a.d dVar, long j) {
        Context context;
        Context context2;
        NotificationManager notificationManager;
        int i = (dVar.i() * 100) / dVar.h();
        if (i - this.a > 3) {
            this.a = i;
            com.kuguo.d.a.a("on downloading: " + j);
            g gVar = (g) dVar.k();
            Notification notification = (Notification) gVar.n;
            StringBuffer stringBuffer = new StringBuffer();
            if (this.a > -1 && this.a <= 100) {
                stringBuffer.append(this.a);
                stringBuffer.append("%    ");
            }
            stringBuffer.append(gVar.b);
            context = this.b.b;
            String stringBuffer2 = stringBuffer.toString();
            context2 = this.b.b;
            notification.setLatestEventInfo(context, "正在下载...", stringBuffer2, PendingIntent.getActivity(context2, 0, new Intent(), 0));
            notificationManager = this.b.j;
            notificationManager.notify(gVar.i, notification);
        }
    }
}
