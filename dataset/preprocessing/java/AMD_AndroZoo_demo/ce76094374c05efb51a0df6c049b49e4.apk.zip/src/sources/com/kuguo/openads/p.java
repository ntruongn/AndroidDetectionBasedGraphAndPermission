package com.kuguo.openads;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class p implements Runnable {
    final /* synthetic */ int a;
    final /* synthetic */ x b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(x xVar, int i) {
        this.b = xVar;
        this.a = i;
    }

    @Override // java.lang.Runnable
    public void run() {
        d dVar;
        dVar = this.b.c;
        dVar.a(this.a);
    }
}
