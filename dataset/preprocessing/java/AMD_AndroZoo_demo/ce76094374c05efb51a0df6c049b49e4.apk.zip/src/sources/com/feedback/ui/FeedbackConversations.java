package com.feedback.ui;

import android.app.ListActivity;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import com.feedback.UMFeedbackService;
import com.mobclick.android.UmengConstants;
import com.mobclick.android.m;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class FeedbackConversations extends ListActivity {
    private static final int c = 0;
    private static final int d = 1;
    private static final int e = 2;
    private static final int f = 3;
    private static final int g = 4;
    private static /* synthetic */ int[] h;
    f a;
    ImageButton b;

    static /* synthetic */ int[] a() {
        int[] iArr = h;
        if (iArr == null) {
            iArr = new int[com.feedback.a.e.valuesCustom().length];
            try {
                iArr[com.feedback.a.e.HasFail.ordinal()] = 3;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[com.feedback.a.e.Normal.ordinal()] = 4;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[com.feedback.a.e.PureFail.ordinal()] = 2;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[com.feedback.a.e.PureSending.ordinal()] = 1;
            } catch (NoSuchFieldError e5) {
            }
            h = iArr;
        }
        return iArr;
    }

    private void b() {
        g gVar = (g) getListAdapter();
        gVar.a(com.feedback.b.c.a(this));
        gVar.notifyDataSetChanged();
    }

    @Override // android.app.Activity
    public boolean onContextItemSelected(MenuItem menuItem) {
        com.feedback.a.d b = ((g) getListAdapter()).b(((AdapterView.AdapterContextMenuInfo) menuItem.getMenuInfo()).position);
        switch (menuItem.getItemId()) {
            case 0:
            case 2:
                com.feedback.b.c.a(this, b.c);
                com.feedback.b.a.b(this, b);
                break;
            case 1:
                com.feedback.b.c.c(this, b.c);
                b();
                break;
            case 3:
                com.feedback.b.a.a(this, b);
                break;
            case 4:
                com.feedback.b.c.c(this, b.c);
                b();
                break;
        }
        return super.onContextItemSelected(menuItem);
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(m.a(this, "layout", "umeng_analyse_feedback_conversations"));
        this.b = (ImageButton) findViewById(m.a(this, "id", "umeng_analyse_imgBtn_submitFb"));
        if (this.b != null) {
            this.b.setOnClickListener(new e(this));
        }
        TextView textView = (TextView) findViewById(m.a(this, "id", "umeng_analyse_um_feedbacklist_title"));
        if (textView != null) {
            textView.setText(getString(m.a(this, "string", "UMFeedbackListTitle")));
        }
        if (!UMFeedbackService.getHasCheckedReply()) {
            new com.feedback.c.b(this).start();
            new com.feedback.c.a(this).start();
        }
        registerForContextMenu(getListView());
        setListAdapter(new g(this, com.feedback.b.c.a(this)));
    }

    @Override // android.app.Activity, android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        super.onCreateContextMenu(contextMenu, view, contextMenuInfo);
        com.feedback.a.e eVar = ((g) getListAdapter()).b(((AdapterView.AdapterContextMenuInfo) contextMenuInfo).position).b;
        if (eVar == com.feedback.a.e.Normal) {
            contextMenu.add(0, 0, 0, getString(m.a(this, "string", "UMViewThread")));
            contextMenu.add(0, 1, 0, getString(m.a(this, "string", "UMDeleteThread")));
        } else if (eVar == com.feedback.a.e.PureSending) {
            contextMenu.add(0, 2, 0, getString(m.a(this, "string", "UMViewFeedback")));
            contextMenu.add(0, 4, 0, getString(m.a(this, "string", "UMDeleteFeedback")));
        } else if (eVar == com.feedback.a.e.PureFail) {
            contextMenu.add(0, 3, 0, getString(m.a(this, "string", "UMResendFeedback")));
            contextMenu.add(0, 4, 0, getString(m.a(this, "string", "UMDeleteFeedback")));
        }
    }

    @Override // android.app.ListActivity
    protected void onListItemClick(ListView listView, View view, int i, long j) {
        super.onListItemClick(listView, view, i, j);
        synchronized (((g) getListAdapter()).b(i)) {
            com.feedback.a.d b = ((g) getListAdapter()).b(i);
            com.feedback.a.e eVar = b.b;
            com.feedback.b.c.a(this, b.c);
            switch (a()[eVar.ordinal()]) {
                case 2:
                    com.feedback.b.a.a(this, b);
                    break;
                default:
                    com.feedback.b.a.b(this, b);
                    break;
            }
        }
    }

    @Override // android.app.Activity
    protected void onRestart() {
        super.onRestart();
        b();
    }

    @Override // android.app.Activity
    protected void onStart() {
        super.onStart();
        this.a = new f(this, (g) getListAdapter());
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(UmengConstants.PostFeedbackBroadcastAction);
        intentFilter.addAction(UmengConstants.RetrieveReplyBroadcastAction);
        registerReceiver(this.a, intentFilter);
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        unregisterReceiver(this.a);
    }
}
