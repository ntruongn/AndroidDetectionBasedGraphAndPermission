package com.feedback.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.mobclick.android.UmengConstants;
import com.mobclick.android.m;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class SendFeedback extends Activity {
    static boolean a = true;
    public static ExecutorService executorService = Executors.newFixedThreadPool(3);
    private Spinner b;
    private Spinner c;
    private EditText d;
    private TextView e;
    private TextView f;
    private ImageButton g;
    private JSONObject h;

    private void a() {
        this.b = (Spinner) findViewById(m.a(this, "id", "umeng_analyse_feedback_age_spinner"));
        this.c = (Spinner) findViewById(m.a(this, "id", "umeng_analyse_feedback_gender_spinner"));
        this.e = (TextView) findViewById(m.a(this, "id", "umeng_analyse_feedback_submit"));
        this.d = (EditText) findViewById(m.a(this, "id", "umeng_analyse_feedback_content"));
        this.f = (TextView) findViewById(m.a(this, "id", "umeng_analyse_feedback_umeng_title"));
        this.g = (ImageButton) findViewById(m.a(this, "id", "umeng_analyse_feedback_see_list_btn"));
        if (this.b != null) {
            ArrayAdapter arrayAdapter = new ArrayAdapter(this, 17367048, getResources().getStringArray(m.a(this, "array", "UMageList")));
            arrayAdapter.setDropDownViewResource(17367049);
            this.b.setAdapter((SpinnerAdapter) arrayAdapter);
        }
        if (this.c != null) {
            ArrayAdapter arrayAdapter2 = new ArrayAdapter(this, 17367048, getResources().getStringArray(m.a(this, "array", "UMgenderList")));
            arrayAdapter2.setDropDownViewResource(17367049);
            this.c.setAdapter((SpinnerAdapter) arrayAdapter2);
        }
        if (this.g != null) {
            this.g.setOnClickListener(new i(this));
        }
        b();
        c();
    }

    private void b() {
        if (this.f != null) {
            this.f.setText(getString(m.a(this, "string", "UMFeedbackUmengTitle")));
        }
        if (this.d != null) {
            this.d.setHint(getString(m.a(this, "string", "UMFeedbackContent")));
        }
        if (this.e != null) {
            this.e.setText(getString(m.a(this, "string", "UMFeedbackSummit")));
        }
    }

    private void c() {
        int e;
        int d;
        String stringExtra = getIntent().getStringExtra(UmengConstants.AtomKey_FeedbackID);
        if (stringExtra != null && this.d != null) {
            String string = getSharedPreferences(UmengConstants.FeedbackPreName, 0).getString(stringExtra, null);
            if (!com.feedback.b.d.a(string)) {
                try {
                    this.d.setText(new com.feedback.a.a(new JSONArray(string).getJSONObject(0)).a());
                    com.feedback.b.c.a(this, UmengConstants.FeedbackPreName, stringExtra);
                } catch (Exception e2) {
                    if (UmengConstants.testMode) {
                        e2.printStackTrace();
                    }
                }
            }
        }
        if (this.b != null && (d = d()) != -1) {
            this.b.setSelection(d);
        }
        if (this.c == null || (e = e()) == -1) {
            return;
        }
        this.c.setSelection(e);
    }

    private int d() {
        return getSharedPreferences(UmengConstants.PreName_Trivial, 0).getInt(UmengConstants.TrivialPreKey_AgeGroup, -1);
    }

    private int e() {
        return getSharedPreferences(UmengConstants.PreName_Trivial, 0).getInt(UmengConstants.TrivialPreKey_Sex, -1);
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(m.a(this, "layout", "umeng_analyse_send_feedback"));
        a();
        if (this.e != null) {
            this.e.setOnClickListener(new j(this, null));
            if (this.d != null) {
                ((InputMethodManager) getSystemService("input_method")).toggleSoftInput(2, 0);
            }
        }
    }
}
