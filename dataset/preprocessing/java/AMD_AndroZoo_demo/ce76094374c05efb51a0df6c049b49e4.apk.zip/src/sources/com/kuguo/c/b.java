package com.kuguo.c;

import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import com.kuguo.ui.NavigationBar;
import com.kuguo.ui.NavigationView;
import java.util.Stack;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b extends a implements View.OnKeyListener {
    private NavigationView c;
    private a d;
    private Stack e;

    public b(Context context, a aVar) {
        super(context);
        this.e = new Stack();
        aVar.b = this;
        this.d = aVar;
        this.c = new NavigationView(context);
        this.c.a(b(aVar));
        this.c.setOnKeyListener(this);
        this.c.setFocusableInTouchMode(true);
    }

    private View b(a aVar) {
        LinearLayout linearLayout = new LinearLayout(this.a);
        linearLayout.setOrientation(1);
        NavigationBar d = aVar.d();
        d.setId(100);
        linearLayout.addView(d, -1, -2);
        View a = aVar.a();
        a.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 1.0f));
        linearLayout.addView(a);
        return linearLayout;
    }

    public void a(a aVar) {
        aVar.b = this;
        View b = b(aVar);
        this.e.push(this.d);
        this.c.b(b);
        this.d = aVar;
    }

    @Override // com.kuguo.c.a
    protected View c() {
        return this.c;
    }

    public void f() {
        if (g()) {
            return;
        }
        this.d.b = null;
        this.d = (a) this.e.pop();
        this.c.a();
    }

    public boolean g() {
        return this.e.isEmpty();
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 0 || i != 4 || g()) {
            return false;
        }
        f();
        return true;
    }
}
