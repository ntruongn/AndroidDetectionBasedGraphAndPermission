package com.kuguo.openads;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.TelephonyManager;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class k {
    private static k a;
    private Context b;
    private String e;
    private String f;
    private String g;
    private String h;
    private NotificationManager j;
    private BroadcastReceiver k;
    private List l;
    private PackageManager m;
    private f n;
    private v o;
    private Map p = new HashMap();
    private Handler i = new Handler();
    private Set c = new HashSet();
    private Set d = new HashSet();

    private k(Context context) {
        this.b = context;
        this.e = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
        this.f = com.kuguo.pushads.a.a(context);
        this.m = context.getPackageManager();
        try {
            Bundle bundle = this.m.getApplicationInfo(context.getPackageName(), 128).metaData;
            if (bundle != null) {
                this.g = bundle.getString("cooId");
                this.h = bundle.getString("channelId");
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        com.kuguo.a.f.a(context).f();
        this.j = (NotificationManager) context.getSystemService("notification");
        this.k = new b();
        IntentFilter intentFilter = new IntentFilter("android.intent.action.PACKAGE_ADDED");
        intentFilter.addDataScheme("package");
        context.registerReceiver(this.k, intentFilter);
        this.l = new w(this, null);
        this.n = new f(this);
    }

    public static k a(Context context) {
        if (a == null) {
            a = new k(context.getApplicationContext());
        }
        return a;
    }

    private void f() {
        c(0);
        com.kuguo.d.a.a("delete applist cache: " + new File("local_applist").delete());
    }

    private boolean i(g gVar) {
        return this.m.getPackageInfo(gVar.j, 128).versionCode >= gVar.g;
    }

    private boolean j(g gVar) {
        com.kuguo.a.d k = k(gVar);
        return k != null && k.g() == 2;
    }

    private com.kuguo.a.d k(g gVar) {
        for (com.kuguo.a.d dVar : com.kuguo.a.f.a().d()) {
            if (gVar == dVar.k()) {
                return dVar;
            }
        }
        return null;
    }

    public int a(int i) {
        SharedPreferences sharedPreferences = this.b.getSharedPreferences("ads_pref", 2);
        int i2 = sharedPreferences.getInt("points", 0) - i;
        sharedPreferences.edit().putInt("points", i2).commit();
        return i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public com.kuguo.b.h a(String str) {
        return new aa(this, str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List a() {
        return this.l;
    }

    public void a(a aVar) {
        this.c.add(aVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(g gVar) {
        com.kuguo.a.d dVar = new com.kuguo.a.d(gVar.k, b(gVar));
        dVar.a(2);
        dVar.a(gVar);
        dVar.a((com.kuguo.a.c) this.n);
        dVar.a().a(20.0f);
        dVar.d();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(z zVar) {
        this.d.add(zVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(File file, g gVar) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(Uri.parse("file://" + file), "application/vnd.android.package-archive");
        intent.setFlags(268435456);
        this.b.startActivity(intent);
    }

    public int b(int i) {
        return a(-i);
    }

    File b() {
        File file = new File("/sdcard/openads");
        file.mkdirs();
        return file;
    }

    File b(g gVar) {
        return new File(b(), gVar.j + "-" + gVar.g + ".apk_");
    }

    public void b(a aVar) {
        this.c.remove(aVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(z zVar) {
        this.d.remove(zVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(String str) {
        com.kuguo.d.a.a(str);
        this.i.post(new n(this, str));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public g c(String str) {
        for (g gVar : this.l) {
            if (str.equals(gVar.j)) {
                return gVar;
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public File c(g gVar) {
        return new File(b(), gVar.j + "-" + gVar.g + ".apk");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.l.size()) {
                break;
            }
            if (((g) this.l.get(i2)).l == 4) {
                this.l.remove(i2);
                i2--;
            }
            i = i2 + 1;
        }
        Iterator it = this.d.iterator();
        while (it.hasNext()) {
            ((z) it.next()).a(this.l);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(int i) {
        this.b.getSharedPreferences("ads_pref", 2).edit().putInt("list_version", i).commit();
    }

    public int d() {
        return this.b.getSharedPreferences("ads_pref", 1).getInt("points", 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(g gVar) {
        if (i(gVar)) {
            gVar.l = 4;
            return;
        }
        if (c(gVar).exists()) {
            gVar.l = 2;
        } else if (j(gVar)) {
            gVar.l = 1;
        } else {
            gVar.l = 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int e() {
        return this.b.getSharedPreferences("ads_pref", 1).getInt("list_version", 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(g gVar) {
        com.kuguo.d.a.a("feed back app installed !");
        this.o = new v(this.b);
        this.o.a(gVar, 3);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void f(g gVar) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void g(g gVar) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h(g gVar) {
        com.kuguo.d.a.a("notify app installed !");
        com.kuguo.a.d k = k(gVar);
        if (k != null) {
            k.f();
        }
        f();
        this.i.post(new m(this, gVar));
    }
}
