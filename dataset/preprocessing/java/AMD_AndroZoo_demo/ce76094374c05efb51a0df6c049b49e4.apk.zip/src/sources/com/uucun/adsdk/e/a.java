package com.uucun.adsdk.e;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.DoEncrypt;
import com.uucun.adsdk.a.b;
import com.uucun.adsdk.b.h;
import com.uucun.adsdk.b.k;
import com.uucun.adsdk.c.c;
import com.uucun.adsdk.d;
import java.util.HashMap;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a extends BroadcastReceiver {
    public static final String a = a.class.getSimpleName();
    private Context b;
    private String c;
    private boolean d = true;
    private String e;

    public a(Context context, String str, String str2) {
        this.b = null;
        this.e = null;
        this.b = context;
        this.c = str;
        this.e = str2 != null ? str2.trim() : str2;
        b.a().a(this);
    }

    private void a(String str) {
        if (str == null || TextUtils.isEmpty(str.trim()) || com.uucun.adsdk.b.b.a(this.b, str) == -1) {
            return;
        }
        HashMap c = d.c(this.b);
        JSONObject jSONObject = new JSONObject();
        try {
            String str2 = (String) c.get("app_key");
            jSONObject.put("imei", (String) c.get("imei"));
            jSONObject.put("app_key", str2);
            jSONObject.put("req_type", "1");
            jSONObject.put("packages", str);
            new c(this.b, k.a().o, jSONObject, false).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void a(String str, String str2, String str3, String str4) {
        HashMap c = d.c(this.b);
        JSONObject jSONObject = new JSONObject();
        try {
            String str5 = (String) c.get("app_key");
            String str6 = (String) c.get("imei");
            jSONObject.put("event_type", "2");
            jSONObject.put("flag", str3);
            jSONObject.put("process_num", str2);
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(str6);
            stringBuffer.append("|");
            stringBuffer.append(str4);
            stringBuffer.append("|");
            stringBuffer.append(com.uucun.adsdk.b.c.a());
            jSONObject.put("valid_key", DoEncrypt.encodecrypt(str5, stringBuffer.toString()));
            new c(this.b, k.a().n, jSONObject, true).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void a(String str, String str2, String str3, String str4, int i) {
        HashMap c = d.c(this.b);
        JSONObject jSONObject = new JSONObject();
        try {
            String str5 = (String) c.get("app_key");
            String str6 = (String) c.get("imei");
            jSONObject.put("event_type", "3");
            jSONObject.put("flag", str3);
            jSONObject.put("process_num", str2);
            jSONObject.put("point", i + "");
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(str6);
            stringBuffer.append("|");
            stringBuffer.append(str4);
            stringBuffer.append("|");
            stringBuffer.append(com.uucun.adsdk.b.c.a());
            jSONObject.put("valid_key", DoEncrypt.encodecrypt(str5, stringBuffer.toString()));
            new c(this.b, k.a().m, jSONObject, true).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void a(String str, String str2, String str3, boolean z) {
        com.uucun.adsdk.b.a a2 = com.uucun.adsdk.b.a.a(this.b);
        a2.a(str + "_process_num");
        a2.a(str + "_from_" + str2);
        String b = a2.b(str + "_adid", "");
        if (!"2".equals(str3)) {
            a2.a(str + "_points");
            a2.a(str + "_adid");
        } else if (z) {
            a2.a("n_ad_pg", a2.b("n_ad_pg", "") + "," + str);
        }
        com.uucun.adsdk.a.a.a().a(b);
        a2.a();
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        this.b = context;
        if (this.d) {
            context.unregisterReceiver(this);
        }
        String action = intent.getAction();
        b.a().b(this);
        h.b(a, "AppInstalledReceiver.onReceive() " + action);
        if (action == null || !"android.intent.action.PACKAGE_ADDED".equals(action)) {
            return;
        }
        Uri data = intent.getData();
        if (data == null) {
            h.b(a, "No intent Data,Return.");
            return;
        }
        String schemeSpecificPart = data.getSchemeSpecificPart();
        h.c(a, "package name : " + this.c);
        if (this.d) {
            if (schemeSpecificPart == null || this.c == null || TextUtils.isEmpty(this.c) || !schemeSpecificPart.equals(this.c)) {
                return;
            }
        } else if (!b.a().d(schemeSpecificPart)) {
            h.c(a, "Static Regedit Receiver,Not Package In Download Manager");
            return;
        }
        h.c(a, "AppInstalledReceiver.onReceive()isDynamicRegedit:" + this.d);
        b.a().c(schemeSpecificPart);
        this.c = schemeSpecificPart;
        com.uucun.adsdk.b.a a2 = com.uucun.adsdk.b.a.a(context);
        boolean equals = "0".equals(this.e);
        String b = a2.b(this.c + "_process_num", "");
        String b2 = a2.b(this.c + "_from_" + b, "");
        String b3 = a2.b(this.c + "_adid", "");
        int b4 = a2.b(this.c + "_points", 0);
        h.b(a, "processNum:" + this.c + "  " + b + " point:" + b4 + " isVaildCPA:" + equals);
        a(this.c);
        if (!com.uucun.adsdk.b.c.c(context, this.c)) {
            a(this.c, b, b2, false);
            return;
        }
        if (equals) {
            a(this.c, b, b2, b3);
        }
        if (!com.uucun.adsdk.b.c.b(context, this.c)) {
            a(this.c, b, b2, false);
            return;
        }
        if (equals) {
            a(this.c, b, b2, b3, b4);
        }
        a(this.c, b, b2, true);
    }
}
