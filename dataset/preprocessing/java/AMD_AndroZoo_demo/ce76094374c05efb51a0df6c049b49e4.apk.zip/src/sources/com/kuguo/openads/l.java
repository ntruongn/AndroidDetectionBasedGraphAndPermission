package com.kuguo.openads;

import android.widget.ListView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class l implements Runnable {
    final /* synthetic */ u a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(u uVar) {
        this.a = uVar;
    }

    @Override // java.lang.Runnable
    public void run() {
        ListView listView;
        this.a.i();
        listView = this.a.c;
        ((y) listView.getAdapter()).notifyDataSetChanged();
    }
}
