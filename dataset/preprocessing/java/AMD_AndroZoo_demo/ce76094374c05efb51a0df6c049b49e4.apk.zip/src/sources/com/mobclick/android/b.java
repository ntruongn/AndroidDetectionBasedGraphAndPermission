package com.mobclick.android;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b extends Handler {
    final /* synthetic */ a a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(a aVar) {
        this.a = aVar;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        String str;
        String str2;
        Context context;
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            StringBuilder sb = new StringBuilder("file://");
            str = this.a.c;
            StringBuilder append = sb.append(str).append("/");
            str2 = this.a.d;
            intent.setDataAndType(Uri.parse(append.append(str2).toString()), "application/vnd.android.package-archive");
            context = this.a.a;
            context.startActivity(intent);
        } catch (Exception e) {
            if (UmengConstants.testMode) {
                Log.e(UmengConstants.LOG_TAG, "Download send install intent error" + e.getMessage());
            }
            this.a.j = false;
        }
    }
}
