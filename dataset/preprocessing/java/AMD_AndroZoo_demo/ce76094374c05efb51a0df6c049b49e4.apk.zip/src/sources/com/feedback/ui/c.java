package com.feedback.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.mobclick.android.m;
import com.wooboo.adlib_android.nb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class c extends BaseAdapter {
    private static /* synthetic */ int[] f;
    Context a;
    LayoutInflater b;
    String c;
    String d = "FeedbackAdapter";
    com.feedback.a.d e;

    public c(Context context, com.feedback.a.d dVar) {
        this.a = context;
        this.e = dVar;
        this.b = LayoutInflater.from(context);
    }

    private void a(com.feedback.a.a aVar, TextView textView) {
        switch (a()[aVar.g.ordinal()]) {
            case 1:
                textView.setText(this.a.getString(m.a(this.a, "string", "UMFb_Atom_State_Sending")));
                textView.setTextColor(-7829368);
                return;
            case 2:
                textView.setText(this.a.getString(m.a(this.a, "string", "UMFb_Atom_State_Fail")));
                textView.setTextColor(-65536);
                return;
            case nb.p /* 3 */:
            default:
                String b = com.feedback.b.d.b(aVar.e, this.a);
                if ("".equals(b)) {
                    textView.setText("");
                    return;
                } else {
                    textView.setText(b);
                    textView.setTextColor(-7829368);
                    return;
                }
            case 4:
                textView.setText(this.a.getString(m.a(this.a, "string", "UMFb_Atom_State_Resending")));
                textView.setTextColor(-65536);
                return;
        }
    }

    static /* synthetic */ int[] a() {
        int[] iArr = f;
        if (iArr == null) {
            iArr = new int[com.feedback.a.b.valuesCustom().length];
            try {
                iArr[com.feedback.a.b.Fail.ordinal()] = 2;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[com.feedback.a.b.OK.ordinal()] = 3;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[com.feedback.a.b.Resending.ordinal()] = 4;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[com.feedback.a.b.Sending.ordinal()] = 1;
            } catch (NoSuchFieldError e4) {
            }
            f = iArr;
        }
        return iArr;
    }

    public void a(com.feedback.a.d dVar) {
        this.e = dVar;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.e == null) {
            return 0;
        }
        return this.e.f.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        d dVar;
        if (view == null) {
            view = this.b.inflate(m.a(this.a, "layout", "umeng_analyse_feedback_conversation_item"), (ViewGroup) null);
            d dVar2 = new d(this);
            dVar2.a = (LinearLayout) view.findViewById(m.a(this.a, "id", "umeng_analyse_atomLinearLayout"));
            dVar2.b = (RelativeLayout) dVar2.a.findViewById(m.a(this.a, "id", "umeng_analyse_bubble"));
            dVar2.c = (TextView) dVar2.a.findViewById(m.a(this.a, "id", "umeng_analyse_atomtxt"));
            dVar2.d = (TextView) dVar2.a.findViewById(m.a(this.a, "id", "umeng_analyse_stateOrTime"));
            dVar2.e = view.findViewById(m.a(this.a, "id", "umeng_analyse_atom_left_margin"));
            dVar2.f = view.findViewById(m.a(this.a, "id", "umeng_analyse_atom_right_margin"));
            view.setTag(dVar2);
            dVar = dVar2;
        } else {
            dVar = (d) view.getTag();
        }
        com.feedback.a.a a = this.e.a(i);
        a(a, dVar.d);
        dVar.c.setText(a.a());
        if (a.f == com.feedback.a.c.DevReply) {
            dVar.a.setGravity(5);
            dVar.b.setBackgroundResource(m.a(this.a, "drawable", "umeng_analyse_dev_bubble"));
            dVar.f.setVisibility(8);
            dVar.e.setVisibility(0);
        } else {
            dVar.a.setGravity(3);
            dVar.b.setBackgroundResource(m.a(this.a, "drawable", "umeng_analyse_user_bubble"));
            dVar.f.setVisibility(0);
            dVar.e.setVisibility(8);
        }
        return view;
    }
}
