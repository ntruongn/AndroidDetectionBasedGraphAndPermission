package com.wooboo.adlib_android;

import android.os.Bundle;
import android.os.Message;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class qd extends TimerTask {
    private static final String[] z = {z(z("?Hh2`\u001fHh\u0018}\u0011Ah:M")), z(z("\u001fH\u001a\u001b~\u000bI;\n[\u0017A-")), z(z("\u001aM<\u001f")), z(z("\u001cI/\u0017a^^-\u000fz\u001b_<^n\u001a\f.\f`\u0013\f;\u001b}\bI:")), z(z("\u001dC=\u0010kYXh\u0019j\n\f)\u0010/\u001fHh\u0018}\u0011Ah\u001dn\u001dD-R/\nD-^n\u001a\f8\u0011|\u0017X!\u0011a^E;^g\u0017H,\u001ba"))};

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '~';
                    break;
                case 1:
                    c = ',';
                    break;
                case 2:
                    c = 'H';
                    break;
                case nb.p /* 3 */:
                    c = '~';
                    break;
                default:
                    c = 15;
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 15);
        }
        return charArray;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        boolean z2;
        pc pcVar = null;
        boolean z3 = sc.C;
        if (ImpressionAdView.r().isShown()) {
            if ((ImpressionAdView.n() == null || !n.W) && ImpressionAdView.n() != null) {
                return;
            }
            long currentTimeMillis = System.currentTimeMillis();
            if (sc.l()) {
                z2 = true;
            } else {
                pc a = pc.a(ImpressionAdView.w(), (String) null);
                HashMap j = a.j();
                if (j.containsKey(z[1])) {
                    if (new BigDecimal((currentTimeMillis - Long.valueOf((String) j.get(z[1])).longValue()) / 1000).setScale(0, 4).intValue() < (ImpressionAdView.x() / 1000) - 10) {
                        pcVar = a;
                        z2 = false;
                    } else if (!z3) {
                        pcVar = a;
                        z2 = true;
                    }
                }
                pcVar = a;
                z2 = true;
            }
            if (z2) {
                if (!sc.l()) {
                    pcVar.d(z[1], Long.valueOf(currentTimeMillis).toString());
                }
                mc.c(z[3]);
                ImpressionAdView.c(ImpressionAdView.m());
                if (!z3) {
                    return;
                }
            }
            if (sc.l()) {
                return;
            }
            hb m = pcVar.m();
            if (m != null && !m.equals("")) {
                mc.c(z[0]);
                m.a(ImpressionAdView.w());
                byte[] a2 = m.a(ImpressionAdView.m(), m.h(), true);
                Message message = new Message();
                message.obj = m;
                Bundle bundle = new Bundle();
                bundle.putByteArray(z[2], a2);
                message.setData(bundle);
                message.what = 1;
                ImpressionAdView.w.sendMessage(message);
                if (!z3) {
                    return;
                }
            }
            mc.c(z[4]);
            Message message2 = new Message();
            message2.obj = m;
            message2.what = 1;
            ImpressionAdView.w.sendMessage(message2);
        }
    }
}
