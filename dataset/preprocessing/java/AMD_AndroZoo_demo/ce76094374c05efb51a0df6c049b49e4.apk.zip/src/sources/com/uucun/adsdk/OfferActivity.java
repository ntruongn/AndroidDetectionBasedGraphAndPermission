package com.uucun.adsdk;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import com.uucun.adsdk.b.h;
import com.uucun.adsdk.view.OfferwallView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class OfferActivity extends Activity {
    public static final String a = OfferActivity.class.getSimpleName();
    private OfferwallView b = null;
    private Handler c = null;
    private ProgressBar d = null;
    private RelativeLayout e = null;
    private String f = "javascript:changePoint(\"%s\",\"%s\",\"%s\");";

    private RelativeLayout.LayoutParams a(int i, int i2) {
        return new RelativeLayout.LayoutParams(i, i2);
    }

    private void d() {
        this.e = new RelativeLayout(getApplicationContext());
        RelativeLayout.LayoutParams a2 = a(-1, -1);
        RelativeLayout.LayoutParams a3 = a(-1, 10);
        this.e.setLayoutParams(a2);
        this.b = new OfferwallView(this.c, this);
        this.e.addView(this.b);
        this.b.setLayoutParams(a2);
        setContentView(this.e);
        this.d = new ProgressBar(getApplicationContext(), null, 16842872);
        this.d.setMax(100);
        a3.addRule(10, -1);
        this.d.setLayoutParams(a3);
        this.e.addView(this.d);
        this.d.setVisibility(8);
    }

    public Handler a() {
        return new c(this);
    }

    public void a(int i) {
        this.d.setProgress(i);
    }

    public void b() {
        this.d.setMax(100);
        this.d.setProgress(0);
        this.d.setVisibility(0);
    }

    public void c() {
        this.d.setVisibility(8);
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        this.c = a();
        d();
        this.b.a();
        this.b.b();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 4 && this.b != null) {
            if (this.b.canGoBack()) {
                this.b.goBack();
            } else {
                finish();
            }
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        com.uucun.adsdk.b.a a2 = com.uucun.adsdk.b.a.a(getApplicationContext());
        String b = a2.b("n_ad_pg", "");
        if (b == null || TextUtils.isEmpty(b.trim())) {
            h.c(a, "package or adid is null...");
            return;
        }
        String[] split = b.split(",");
        if (split == null || split.length <= 0) {
            return;
        }
        for (String str : split) {
            String b2 = a2.b(str + "_adid", "");
            if (str == null || TextUtils.isEmpty(str.trim()) || b2 == null || TextUtils.isEmpty(b2.trim())) {
                h.c(a, "package or adid is null...");
            } else {
                int b3 = a2.b(str + "_points", 0);
                a2.a(str + "_points");
                a2.a(str + "_adid");
                h.c(a, " Chage Point package:" + str + "  Points:" + b3 + " adId:" + b2);
                String format = String.format(this.f, str.trim(), Integer.valueOf(b3), b2.trim());
                if (b3 == 0) {
                    return;
                }
                h.c(a, "change points:" + format);
                this.b.loadUrl(format);
            }
        }
        a2.a("n_ad_pg");
        a2.a();
    }
}
