package com.kuguo.openads;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.StateListDrawable;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.kuguo.ui.FoldView;
import com.kuguo.ui.ImageGallery;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class d extends LinearLayout {
    private ImageView a;
    private TextView b;
    private TextView c;
    private TextView d;
    private TextView e;
    private ImageGallery f;
    private FoldView g;
    private Button h;
    private TextView i;

    public d(Context context) {
        super(context);
        setOrientation(1);
        setBackgroundColor(-1);
        int parseColor = Color.parseColor("#5297be");
        ScrollView scrollView = new ScrollView(context);
        addView(scrollView, new LinearLayout.LayoutParams(-1, -2, 1.0f));
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        scrollView.addView(linearLayout, -1, -2);
        LinearLayout linearLayout2 = new LinearLayout(context);
        linearLayout2.setOrientation(0);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = 10;
        layoutParams.rightMargin = 10;
        layoutParams.leftMargin = 10;
        linearLayout.addView(linearLayout2, layoutParams);
        this.a = new ImageView(context);
        this.a.setImageResource(17301651);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 16;
        linearLayout2.addView(this.a, layoutParams2);
        LinearLayout linearLayout3 = new LinearLayout(context);
        linearLayout3.setOrientation(1);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2, 1.0f);
        layoutParams3.gravity = 16;
        layoutParams3.leftMargin = 10;
        linearLayout2.addView(linearLayout3, layoutParams3);
        this.i = new TextView(context);
        this.i.setTextSize(16.0f);
        this.i.setTextColor(Color.parseColor("#fbc003"));
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams4.gravity = 21;
        linearLayout2.addView(this.i, layoutParams4);
        this.c = new TextView(context);
        this.c.setTextColor(parseColor);
        linearLayout3.addView(this.c, -1, -2);
        this.d = new TextView(context);
        this.d.setTextColor(parseColor);
        linearLayout3.addView(this.d, -1, -2);
        this.e = new TextView(context);
        this.e.setTextSize(16.0f);
        this.e.setTextColor(-16777216);
        this.e.setText("正在加载中...");
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.rightMargin = 10;
        layoutParams5.leftMargin = 10;
        linearLayout.addView(this.e, layoutParams5);
        this.f = new ImageGallery(context);
        this.f.setBackgroundColor(Color.rgb(236, 236, 236));
        this.f.setPadding(0, 20, 0, 40);
        this.f.setSpacing(10);
        this.f.a(com.kuguo.d.e.a(context, "ads/spot_default.png"), com.kuguo.d.e.a(context, "ads/spot_light.png"));
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams6.topMargin = 10;
        linearLayout.addView(this.f, layoutParams6);
        this.g = new FoldView(context);
        this.g.a("权限");
        this.g.a(18);
        this.g.b(parseColor);
        this.g.a(com.kuguo.d.e.a(context, "ads/fold_arrow.png"));
        this.g.a(-7829368, 2);
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams7.rightMargin = 10;
        layoutParams7.leftMargin = 10;
        layoutParams7.topMargin = 10;
        layoutParams7.bottomMargin = 50;
        linearLayout.addView(this.g, layoutParams7);
        FrameLayout frameLayout = new FrameLayout(context);
        frameLayout.setBackgroundColor(parseColor);
        addView(frameLayout, new LinearLayout.LayoutParams(-1, -2));
        this.h = new Button(context);
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{16842919}, com.kuguo.d.e.b(context, "ads/download_btn2_pressed.png"));
        stateListDrawable.addState(new int[]{16842910}, com.kuguo.d.e.b(context, "ads/download_btn2.png"));
        this.h.setBackgroundDrawable(stateListDrawable);
        FrameLayout.LayoutParams layoutParams8 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams8.gravity = 17;
        frameLayout.addView(this.h, layoutParams8);
    }

    private String b(float f) {
        return f > 1024.0f ? (((int) ((f / 1024.0f) * 100.0f)) / 100.0f) + "M" : ((int) Math.ceil(f)) + "K";
    }

    public Button a() {
        return this.h;
    }

    public void a(float f) {
        this.d.setText("大小: " + b(f));
    }

    public void a(int i) {
        Bitmap a = com.kuguo.d.e.a(getContext(), "ads/snapshot_empty.png");
        ArrayList arrayList = new ArrayList(i);
        for (int i2 = 0; i2 < i; i2++) {
            arrayList.add(a);
        }
        a(arrayList);
    }

    public void a(Bitmap bitmap) {
        this.a.setImageDrawable(com.kuguo.d.e.a(getContext(), bitmap));
    }

    public void a(Bitmap bitmap, int i) {
        this.f.a(bitmap, i);
    }

    public void a(String str) {
        if (this.b != null) {
            this.b.setText(str);
        }
    }

    public void a(List list) {
        this.f.a(list);
    }

    public void a(Map map) {
        if (map.isEmpty()) {
            return;
        }
        new TextView(getContext()).setTextColor(-16777216);
        StringBuilder sb = new StringBuilder();
        sb.append("<ul>");
        for (String str : map.keySet()) {
            sb.append("<li><b>");
            sb.append(str);
            String str2 = (String) map.get(str);
            if (str2 != null) {
                sb.append("</b><br/>");
                sb.append(str2);
            }
            sb.append("</li>");
        }
        sb.append("</ul>");
        String sb2 = sb.toString();
        WebView webView = new WebView(getContext());
        webView.loadDataWithBaseURL(null, sb2, "text/html", "utf-8", null);
        this.g.a(webView);
    }

    public void b(String str) {
        this.c.setText("版本: " + str);
    }

    public void c(String str) {
        this.e.setText(str);
    }

    public void d(String str) {
        this.i.setText(str);
    }
}
