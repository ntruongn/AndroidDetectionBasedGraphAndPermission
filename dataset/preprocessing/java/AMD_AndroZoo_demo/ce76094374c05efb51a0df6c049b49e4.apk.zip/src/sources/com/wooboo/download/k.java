package com.wooboo.download;

import com.wooboo.adlib_android.nb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class k extends Thread {
    private static final String[] z = {z(z("6-n")), z(z("\u0003\u001f^")), z(z("\u0013\u0011No\u0016L")), z(z("Q\u001aOdK_F")), z(z("#\tTm\u0000")), z(z("5\u0007Md\t\u001e\t^^\r\u0003\r[nE\u001e\u001e_x")), z(z("2\u0007Td\u0000\u0012\u001cSe\u000b")), z(z("5\u0007Mf\n\u0010\fnb\u0017\u0014\t^* \u0003\u001aUx_")), z(z("\u0005\u0000Ho\u0004\u0015H")), z(z(":\r_zH0\u0004S|\u0000"))};
    private String a;
    private d b;
    private String c;
    private e d;
    private boolean e = false;
    private int f = 0;
    private boolean g;

    public k(d dVar, String str, String str2, e eVar, boolean z2) {
        this.g = false;
        this.b = dVar;
        this.a = str;
        this.c = str2;
        this.d = eVar;
        this.g = z2;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'q';
                    break;
                case 1:
                    c = 'h';
                    break;
                case 2:
                    c = ':';
                    break;
                case nb.p /* 3 */:
                    c = '\n';
                    break;
                default:
                    c = 'e';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'e');
        }
        return charArray;
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x00a5, code lost:
    
        if (r6 != false) goto L13;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:101:0x0177 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0111 A[Catch: Exception -> 0x01a4, TRY_LEAVE, TryCatch #17 {Exception -> 0x01a4, blocks: (B:40:0x0100, B:42:0x0111), top: B:39:0x0100 }] */
    /* JADX WARN: Removed duplicated region for block: B:45:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0181 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:95:? A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:96:0x017c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4 */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x00d1 -> B:22:0x00b3). Please submit an issue!!! */
    @Override // java.lang.Thread, java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void run() {
        /*
            Method dump skipped, instructions count: 454
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.download.k.run():void");
    }
}
