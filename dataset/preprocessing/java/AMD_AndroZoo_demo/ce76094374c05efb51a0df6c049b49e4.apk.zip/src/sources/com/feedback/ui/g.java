package com.feedback.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.mobclick.android.m;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class g extends BaseAdapter {
    LayoutInflater a;
    Context b;
    List c;
    JSONArray d;
    String[] e;
    String f = "";
    String g = "FeedbackListAdapter";

    public g(Context context, List list) {
        this.b = context;
        this.a = LayoutInflater.from(context);
        Collections.sort(list);
        this.c = list;
    }

    private String a(com.feedback.a.d dVar) {
        return dVar.d.a();
    }

    private String b(com.feedback.a.d dVar) {
        if (dVar.b == com.feedback.a.e.Normal) {
            for (int size = dVar.f.size() - 1; size >= 0; size--) {
                com.feedback.a.b bVar = dVar.a(size).g;
                if (bVar == com.feedback.a.b.Sending) {
                    return this.b.getString(m.a(this.b, "string", "UMFbList_ListItem_State_Sending"));
                }
                if (bVar == com.feedback.a.b.Fail) {
                    return this.b.getString(m.a(this.b, "string", "UMFbList_ListItem_State_Fail"));
                }
                if (bVar == com.feedback.a.b.Resending) {
                    return this.b.getString(m.a(this.b, "string", "UMFbList_ListItem_State_Resending"));
                }
            }
        } else {
            if (dVar.b == com.feedback.a.e.PureFail) {
                return this.b.getString(m.a(this.b, "string", "UMFbList_ListItem_State_ReSend"));
            }
            if (dVar.b == com.feedback.a.e.PureSending) {
                return this.b.getString(m.a(this.b, "string", "UMFbList_ListItem_State_Sending"));
            }
        }
        return "";
    }

    private String c(com.feedback.a.d dVar) {
        if (dVar.f.size() == 1 || dVar.e.f != com.feedback.a.c.DevReply) {
            return null;
        }
        return dVar.e.a();
    }

    private String d(com.feedback.a.d dVar) {
        return com.feedback.b.d.a(dVar.e.e, this.b);
    }

    public com.feedback.a.e a(int i) {
        return ((com.feedback.a.d) this.c.get(i)).b;
    }

    public void a(List list) {
        Collections.sort(list);
        this.c = list;
    }

    public com.feedback.a.d b(int i) {
        return (com.feedback.a.d) this.c.get(i);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.c.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        h hVar;
        if (view == null || view.getTag() == null) {
            view = this.a.inflate(m.a(this.b, "layout", "umeng_analyse_feedback_conversations_item"), (ViewGroup) null);
            hVar = new h(this);
            hVar.a = (ImageView) view.findViewById(m.a(this.b, "id", "umeng_analyse_new_reply_notifier"));
            hVar.b = (TextView) view.findViewById(m.a(this.b, "id", "umeng_analyse_feedbackpreview"));
            hVar.c = (TextView) view.findViewById(m.a(this.b, "id", "umeng_analyse_dev_reply"));
            hVar.d = (TextView) view.findViewById(m.a(this.b, "id", "umeng_analyse_state_or_date"));
            view.setTag(hVar);
        } else {
            hVar = (h) view.getTag();
        }
        com.feedback.a.d dVar = (com.feedback.a.d) this.c.get(i);
        String a = a(dVar);
        String c = c(dVar);
        String b = b(dVar);
        String d = d(dVar);
        hVar.b.setText(a);
        if (c == null) {
            hVar.c.setVisibility(8);
        } else {
            hVar.c.setVisibility(0);
            hVar.c.setText(c);
        }
        if (com.feedback.b.d.a(b)) {
            hVar.d.setText(d);
        } else {
            hVar.d.setText(b);
        }
        if (com.feedback.b.c.a(this.b, dVar)) {
            hVar.a.setVisibility(0);
            hVar.a.setBackgroundResource(m.a(this.b, "drawable", "umeng_analyse_point_new"));
        } else {
            hVar.a.setVisibility(4);
        }
        return view;
    }
}
