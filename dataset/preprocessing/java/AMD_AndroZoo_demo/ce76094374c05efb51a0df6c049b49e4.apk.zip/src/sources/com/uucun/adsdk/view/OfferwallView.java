package com.uucun.adsdk.view;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.DoEncrypt;
import com.uucun.adsdk.OfferActivity;
import com.uucun.adsdk.UUAppConnect;
import java.util.HashMap;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class OfferwallView extends WebView {
    public static final String a = OfferwallView.class.getSimpleName();
    public OfferActivity b;
    private Handler c;
    private Handler d;
    private String e;
    private long f;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public class AndroidJs {
        private Handler handlerInJs;

        public AndroidJs(Handler handler) {
            this.handlerInJs = null;
            this.handlerInJs = handler;
        }

        public void download(String str) {
            com.uucun.adsdk.b.h.c(OfferwallView.a, "enterUrl " + str);
            Message message = new Message();
            message.what = 2;
            String[] strArr = new String[3];
            String a = com.uucun.adsdk.b.c.a(str, "id");
            String a2 = com.uucun.adsdk.b.c.a(str, "isInstall");
            strArr[0] = str;
            strArr[1] = a;
            if (a2 == null || TextUtils.isEmpty(a2.trim())) {
                strArr[2] = "0";
            } else {
                strArr[2] = a2;
            }
            message.obj = strArr;
            this.handlerInJs.sendMessage(message);
        }

        public void gopage(String str) {
            Message message = new Message();
            message.what = 1;
            message.obj = str;
            this.handlerInJs.sendMessage(message);
        }
    }

    public OfferwallView(Handler handler, Context context) {
        super(context);
        this.c = null;
        this.b = null;
        this.d = null;
        this.e = "1";
        this.f = -1L;
        this.b = (OfferActivity) context;
        this.d = handler;
        clearCache(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b(String str) {
        this.e = str;
        b();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c() {
        JSONObject jSONObject = new JSONObject();
        HashMap c = com.uucun.adsdk.d.c(this.b);
        try {
            String str = (String) c.get("app_key");
            String str2 = (String) c.get("imei");
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put("flag", "2");
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(str2);
            stringBuffer.append("|");
            stringBuffer.append("|");
            stringBuffer.append(com.uucun.adsdk.b.c.a());
            jSONObject.put("valid_key", DoEncrypt.encodecrypt(str, stringBuffer.toString()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        new com.uucun.adsdk.c.c(this.b, com.uucun.adsdk.b.k.a().k, jSONObject, true).start();
    }

    private void d() {
        addJavascriptInterface(new AndroidJs(this.c), "android");
    }

    private Handler e() {
        return new d(this);
    }

    public JSONObject a(String str) {
        HashMap c = com.uucun.adsdk.d.c(this.b);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put("channel_id", c.get("channel_id"));
            jSONObject.put("imei", c.get("imei"));
            jSONObject.put("flag", "2");
            jSONObject.put("page_num", str);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jSONObject;
    }

    public void a() {
        this.c = e();
        WebSettings settings = getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setSupportZoom(false);
        setScrollBarStyle(0);
        d();
        this.f = System.currentTimeMillis();
        setWebViewClient(new a(this));
        setWebChromeClient(new c(this));
    }

    public void a(String str, String str2, String str3) {
        if (com.uucun.adsdk.a.b.a().a(str2)) {
            UUAppConnect.showToast("该任务正在下载!", this.b);
            return;
        }
        HashMap c = com.uucun.adsdk.d.c(this.b);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("ad_id", str2);
            jSONObject.put("imei", c.get("imei"));
            jSONObject.put("event_type", "1");
            jSONObject.put("flag", "2");
            jSONObject.put("isInstall", str3);
        } catch (Exception e) {
            e.printStackTrace();
        }
        com.uucun.adsdk.c.b bVar = new com.uucun.adsdk.c.b(this.b, str, str2);
        com.uucun.adsdk.a.c.a().a(bVar);
        bVar.execute(new JSONObject[]{jSONObject});
    }

    public void b() {
        Message message = new Message();
        message.what = 2;
        this.d.sendMessage(message);
        String str = com.uucun.adsdk.b.k.a().b + "?jsonString=" + a(this.e).toString();
        com.uucun.adsdk.b.h.c(a, str);
        loadUrl(str);
    }
}
