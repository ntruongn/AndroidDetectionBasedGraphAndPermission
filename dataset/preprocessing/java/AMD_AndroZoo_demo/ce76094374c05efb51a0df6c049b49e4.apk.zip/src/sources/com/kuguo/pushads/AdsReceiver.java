package com.kuguo.pushads;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.PowerManager;
import android.util.Log;
import com.mobclick.android.UmengConstants;
import java.util.Timer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class AdsReceiver extends BroadcastReceiver {
    static PowerManager.WakeLock a;
    static PowerManager.WakeLock c;
    static final Object b = new Object();
    static final Object d = new Object();

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a() {
        synchronized (d) {
            if (c != null) {
                c.release();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(Service service, int i) {
        synchronized (b) {
            if (a != null && service.stopSelfResult(i)) {
                a.release();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(Context context, Intent intent) {
        synchronized (b) {
            if (a == null) {
                a = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "StartingAlertService");
                a.setReferenceCounted(false);
            }
            a.acquire();
            intent.setClass(context, AdsService.class);
            context.startService(intent);
        }
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        com.kuguo.a.f.a(context);
        String action = intent.getAction();
        if ("android.intent.action.BOOT_COMPLETED".equals(action)) {
            new Timer().schedule(new d(this, context), 60000L);
            return;
        }
        if ("android.intent.action.PACKAGE_ADDED".equals(action)) {
            String uri = intent.getData().toString();
            String substring = uri.substring("package:".length(), uri.length());
            Log.d("android__log", substring);
            new Timer().schedule(new f(this, context, substring), 0L);
            return;
        }
        if (action != null) {
            if ("android.net.wifi.WIFI_STATE_CHANGED".equals(action) && ((WifiManager) context.getSystemService("wifi")).getWifiState() == 3) {
                com.kuguo.a.f a2 = com.kuguo.a.f.a();
                if (a2 == null) {
                    a2 = com.kuguo.a.f.a(context);
                }
                a2.e();
                return;
            }
            return;
        }
        String stringExtra = intent.getStringExtra(UmengConstants.AtomKey_Type);
        a.a("-reciever type == " + stringExtra);
        if (stringExtra == null) {
            a(context, intent);
            return;
        }
        if ("AdAlarm".equals(stringExtra)) {
            synchronized (d) {
                if (c == null) {
                    c = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "StartingAlertMessage");
                    c.setReferenceCounted(false);
                }
                j jVar = new j();
                if (jVar.a(intent.getStringExtra("message"))) {
                    jVar.f = intent.getIntExtra("sharedid", -1);
                    c.acquire();
                    e.a(context).b(jVar);
                }
            }
        }
    }
}
