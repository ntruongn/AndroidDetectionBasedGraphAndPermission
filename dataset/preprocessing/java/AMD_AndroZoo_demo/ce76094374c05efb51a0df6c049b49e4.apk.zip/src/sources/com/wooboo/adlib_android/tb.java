package com.wooboo.adlib_android;

import android.view.animation.Animation;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class tb implements Animation.AnimationListener {
    final FullAdView a;
    private final n b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public tb(FullAdView fullAdView, n nVar) {
        this.a = fullAdView;
        this.b = nVar;
    }

    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationEnd(Animation animation) {
        this.a.post(new ub(this.a, this.b));
    }

    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationRepeat(Animation animation) {
    }

    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationStart(Animation animation) {
    }
}
