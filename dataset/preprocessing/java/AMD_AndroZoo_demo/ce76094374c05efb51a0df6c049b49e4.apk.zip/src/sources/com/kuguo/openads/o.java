package com.kuguo.openads;

import android.content.Context;
import android.os.Handler;
import android.widget.TextView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class o extends TextView implements Runnable {
    final /* synthetic */ u a;
    private int b;
    private String c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(u uVar, Context context, String str) {
        super(context);
        Handler handler;
        this.a = uVar;
        a(str);
        handler = uVar.f;
        handler.post(this);
    }

    private void a() {
        this.b++;
        if (this.b > 3) {
            this.b = 0;
        }
        String str = this.c;
        for (int i = 0; i < this.b; i++) {
            str = str + ".";
        }
        setText(str);
    }

    public void a(String str) {
        this.c = str;
        setText(str);
    }

    @Override // java.lang.Runnable
    public void run() {
        Handler handler;
        a();
        handler = this.a.f;
        handler.postDelayed(this, 500L);
    }
}
