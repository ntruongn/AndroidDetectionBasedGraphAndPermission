package com.uucun.adsdk.b;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Environment;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import com.mobclick.android.UmengConstants;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class c {
    private static DateFormat a = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");

    public static float a(Paint paint, String str) {
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return ((int) Math.ceil(fontMetrics.descent - fontMetrics.top)) + 2;
    }

    private static long a(long j, long j2) {
        long random = ((long) (Math.random() * (j2 - j))) + j;
        return (random == j || random == j2) ? a(j, j2) : random;
    }

    public static Intent a(Context context, BroadcastReceiver broadcastReceiver, String... strArr) {
        IntentFilter intentFilter = new IntentFilter();
        for (String str : strArr) {
            intentFilter.addAction(str);
        }
        intentFilter.addDataScheme("package");
        intentFilter.setPriority(Integer.MAX_VALUE);
        return context.registerReceiver(broadcastReceiver, intentFilter);
    }

    public static Bitmap a(com.uucun.adsdk.d.e eVar, int i, int i2, boolean z) {
        if (eVar == null || eVar.d == null || eVar.d.isRecycled()) {
            return null;
        }
        int width = (int) ((i / eVar.d.getWidth()) * eVar.d.getHeight());
        if (width <= i2) {
            i2 = width;
        }
        try {
            Bitmap createScaledBitmap = Bitmap.createScaledBitmap(eVar.d, i, i2, false);
            if (eVar.e <= 0 || !z) {
                return createScaledBitmap;
            }
            Bitmap createBitmap = Bitmap.createBitmap(createScaledBitmap.getWidth(), createScaledBitmap.getHeight(), Bitmap.Config.RGB_565);
            Canvas canvas = new Canvas(createBitmap);
            canvas.drawBitmap(createScaledBitmap, 0.0f, 0.0f, (Paint) null);
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            String str = eVar.j + eVar.e + eVar.f;
            paint.setTextSize(i2 * 0.2f);
            paint.setColor(Color.parseColor("#CCFF00"));
            paint.setFakeBoldText(true);
            canvas.drawText(str, (float) ((i - ((int) b(paint, str))) - 15), (int) a(paint, str), paint);
            return createBitmap;
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap a(String str, Context context) {
        try {
            File file = new File(a(context), b(str));
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 4;
            return BitmapFactory.decodeFile(file.getPath(), options);
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            return null;
        }
    }

    public static File a(Context context) {
        File file = new File(Environment.getExternalStorageDirectory(), "tt.tmp");
        try {
            if (file.createNewFile()) {
                file.delete();
            }
            File a2 = a(context.getPackageName() + File.separator + "download");
            if (a2.exists()) {
                return a2;
            }
            a2.mkdirs();
            return a2;
        } catch (IOException e) {
            return context.getFilesDir();
        }
    }

    public static File a(String str) {
        return new File(Environment.getExternalStorageDirectory(), str);
    }

    public static String a() {
        return Long.toString(System.currentTimeMillis()) + ((long) (Math.random() * 1.0E8d));
    }

    public static String a(String str, String str2) {
        if (str == null || TextUtils.isEmpty(str)) {
            return null;
        }
        return Uri.parse(str).getQueryParameter(str2);
    }

    public static void a(Context context, String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setFlags(268435456);
        intent.setDataAndType(Uri.parse("file://" + str), "application/vnd.android.package-archive");
        context.startActivity(intent);
    }

    public static void a(View view) {
        view.clearAnimation();
        AnimationSet animationSet = new AnimationSet(true);
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(1000L);
        alphaAnimation.setStartOffset(1000L);
        animationSet.addAnimation(alphaAnimation);
        animationSet.setFillBefore(false);
        animationSet.setFillAfter(true);
        view.startAnimation(animationSet);
    }

    public static void a(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                h.a("SdkUtils", e.getMessage());
            }
        }
    }

    public static void a(JSONObject jSONObject, Context context) {
        try {
            HashMap c = com.uucun.adsdk.d.c(context);
            if (c == null) {
                return;
            }
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put("imei", c.get("imei"));
            jSONObject.put("channel_id", c.get("channel_id"));
            jSONObject.put("device_name", c.get("device_name"));
            jSONObject.put("network_type", b.e(context));
            jSONObject.put(UmengConstants.AtomKey_OSVersion, c.get(UmengConstants.AtomKey_OSVersion));
            jSONObject.put("resolution", c.get("resolution"));
            jSONObject.put("simcard_type", c.get("simcard_type"));
            jSONObject.put("area", c.get("area"));
            jSONObject.put("simcard_number", c.get("simcard_number"));
            jSONObject.put("ip", b.c());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void a(byte[] bArr, File file) {
        if (file.exists()) {
            file.delete();
        }
        file.createNewFile();
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        fileOutputStream.write(bArr);
        fileOutputStream.flush();
        a(fileOutputStream);
    }

    public static boolean a(Context context, String str, int i) {
        if (i == 0) {
            return true;
        }
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(str, 1);
            if (packageInfo == null) {
                return true;
            }
            String str2 = packageInfo.packageName;
            return i != packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            return true;
        }
    }

    public static byte[] a(InputStream inputStream) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[1024];
        while (true) {
            int read = inputStream.read(bArr);
            if (read == -1) {
                byteArrayOutputStream.close();
                inputStream.close();
                return byteArrayOutputStream.toByteArray();
            }
            byteArrayOutputStream.write(bArr, 0, read);
            byteArrayOutputStream.flush();
        }
    }

    public static float b(Paint paint, String str) {
        if (str == null) {
            return 0.0f;
        }
        return paint.measureText(str) + 0.5f;
    }

    public static String b(String str) {
        return (str == null || TextUtils.isEmpty(str.trim())) ? System.currentTimeMillis() + "" : str.replaceAll("/", "").replace(":", "");
    }

    public static void b(View view) {
        switch ((int) a(0L, 5L)) {
            case 4:
                a(view);
                return;
            default:
                a(view);
                return;
        }
    }

    public static boolean b(Context context, String str) {
        Intent launchIntentForPackage = context.getPackageManager().getLaunchIntentForPackage(str);
        if (launchIntentForPackage == null) {
            return false;
        }
        launchIntentForPackage.setFlags(268435456);
        context.startActivity(launchIntentForPackage);
        return true;
    }

    public static byte[] b(String str, Context context) {
        try {
            URL url = new URL(str);
            Proxy c = j.c(context);
            HttpURLConnection httpURLConnection = c != null ? (HttpURLConnection) url.openConnection(c) : (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setConnectTimeout(20000);
            if (httpURLConnection.getResponseCode() == 200) {
                return a(httpURLConnection.getInputStream());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean c(Context context, String str) {
        return context.getPackageManager().getLaunchIntentForPackage(str) != null;
    }

    public static boolean d(Context context, String str) {
        try {
            return context.getPackageManager().getPackageInfo(str, 1) != null;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public static String e(Context context, String str) {
        PackageInfo packageArchiveInfo = context.getPackageManager().getPackageArchiveInfo(str, 1);
        return packageArchiveInfo != null ? packageArchiveInfo.packageName : "";
    }
}
