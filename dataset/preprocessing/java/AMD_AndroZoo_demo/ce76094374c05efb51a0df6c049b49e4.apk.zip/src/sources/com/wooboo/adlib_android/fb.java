package com.wooboo.adlib_android;

import android.view.View;
import java.util.Timer;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class fb implements View.OnClickListener {
    final n a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public fb(n nVar) {
        this.a = nVar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        if (n.v == null || !view.isPressed()) {
            return;
        }
        view.setPressed(false);
        if (n.e(this.a)) {
            return;
        }
        n.a(this.a, true);
        if (n.f(this.a) != null) {
            n.f(this.a).closeAd();
        }
        n.a(this.a);
        n.a(this.a, false);
        n.a(n.v.l());
        new Timer().schedule(new md(this), 1000L);
    }
}
