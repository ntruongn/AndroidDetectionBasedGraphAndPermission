package com.uucun.adsdk.b;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b {
    public static int a(Context context, String str) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(str, 8192);
            if (packageInfo != null) {
                return packageInfo.versionCode;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static String a() {
        return "unknow".equalsIgnoreCase(Build.BRAND) ? Build.MANUFACTURER + " " + Build.MODEL : Build.BRAND + " " + Build.MODEL;
    }

    public static String a(Context context) {
        if (context.checkCallingOrSelfPermission("android.permission.READ_PHONE_STATE") != 0) {
            return "";
        }
        String deviceId = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
        return (deviceId == null || TextUtils.isEmpty(deviceId)) ? g(context) : deviceId;
    }

    public static int[] a(Context context, boolean z) {
        int[] iArr = new int[2];
        Configuration configuration = context.getResources().getConfiguration();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
        int i = displayMetrics.widthPixels;
        int i2 = displayMetrics.heightPixels;
        if (!z) {
            iArr[0] = i;
            iArr[1] = i2;
        } else if (configuration.orientation == 2) {
            iArr[0] = i2;
            iArr[1] = i;
        } else {
            iArr[0] = i;
            iArr[1] = i2;
        }
        return iArr;
    }

    public static int b(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            return 0;
        }
    }

    public static String b() {
        return Build.VERSION.RELEASE;
    }

    public static String c() {
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                Enumeration<InetAddress> inetAddresses = networkInterfaces.nextElement().getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress nextElement = inetAddresses.nextElement();
                    if (!nextElement.isLoopbackAddress()) {
                        return nextElement.getHostAddress().toString();
                    }
                }
            }
        } catch (SocketException e) {
            h.a("IpAddress", e.toString());
        }
        return null;
    }

    public static String c(Context context) {
        return ((TelephonyManager) context.getSystemService("phone")).getSimCountryIso();
    }

    public static String d(Context context) {
        return context.getResources().getConfiguration().locale.getCountry();
    }

    public static String e(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo == null ? "unknow" : activeNetworkInfo.getType() == 1 ? "wifi" : activeNetworkInfo.getType() == 0 ? "2G/3G" : "unknow";
    }

    public static String f(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
        String subscriberId = telephonyManager.getSubscriberId();
        String simOperator = (subscriberId == null || TextUtils.isEmpty(subscriberId)) ? telephonyManager.getSimOperator() : subscriberId;
        if (simOperator != null) {
            if (simOperator.startsWith("46000") || simOperator.startsWith("46002")) {
                return "中国移动";
            }
            if (simOperator.startsWith("46001")) {
                return "中国联通";
            }
            if (simOperator.startsWith("46003")) {
                return "中国电信";
            }
        }
        return "unknow";
    }

    public static String g(Context context) {
        return ((TelephonyManager) context.getSystemService("phone")).getSubscriberId();
    }

    public static String h(Context context) {
        try {
            String packageName = context.getPackageName();
            PackageManager packageManager = context.getPackageManager();
            PackageInfo packageInfo = packageManager.getPackageInfo(packageName, 8192);
            if (packageInfo != null && packageInfo.applicationInfo != null) {
                CharSequence loadLabel = packageInfo.applicationInfo.loadLabel(packageManager);
                StringBuffer stringBuffer = new StringBuffer();
                stringBuffer.append(loadLabel);
                return stringBuffer.toString();
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ArrayList i(Context context) {
        int i = 0;
        ArrayList arrayList = new ArrayList();
        PackageManager packageManager = context.getPackageManager();
        List<PackageInfo> installedPackages = packageManager.getInstalledPackages(0);
        while (true) {
            int i2 = i;
            if (i2 >= installedPackages.size()) {
                return arrayList;
            }
            PackageInfo packageInfo = installedPackages.get(i2);
            d dVar = new d();
            dVar.a = packageInfo.applicationInfo.loadLabel(packageManager).toString();
            dVar.b = packageInfo.packageName;
            dVar.c = packageInfo.versionName;
            dVar.d = packageInfo.versionCode;
            if ((packageInfo.applicationInfo.flags & 1) == 0) {
                arrayList.add(dVar);
            }
            i = i2 + 1;
        }
    }

    public static String j(Context context) {
        StringBuilder sb = new StringBuilder();
        ArrayList i = i(context);
        if (i != null && i.size() > 0) {
            int i2 = 0;
            while (true) {
                int i3 = i2;
                if (i3 >= i.size()) {
                    break;
                }
                if (i3 != 0) {
                    sb.append(",");
                }
                sb.append(((d) i.get(i3)).b);
                i2 = i3 + 1;
            }
        }
        return sb.toString();
    }

    public static String k(Context context) {
        String[] split = l(context).split(",");
        if (split.length != 2) {
            return "";
        }
        Geocoder geocoder = new Geocoder(context);
        StringBuilder sb = new StringBuilder();
        try {
            List<Address> fromLocation = geocoder.getFromLocation(Double.valueOf(split[1]).doubleValue(), Double.valueOf(split[0]).doubleValue(), 1);
            if (fromLocation.size() > 0) {
                Address address = fromLocation.get(0);
                sb.append(address.getCountryName()).append("|").append(address.getAdminArea()).append("|").append(address.getLocality());
            }
        } catch (IOException e) {
            h.a("getLocationAddress.", e.getMessage());
        }
        return sb.toString();
    }

    public static String l(Context context) {
        String str = null;
        Criteria criteria = new Criteria();
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(true);
        LocationManager locationManager = (LocationManager) context.getSystemService("location");
        StringBuilder sb = new StringBuilder();
        if (context.checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0) {
            criteria.setAccuracy(1);
            str = locationManager.getBestProvider(criteria, true);
        }
        if (str == null) {
            h.c("buildLocation", "cannot get location provider.");
            return "";
        }
        Iterator<String> it = locationManager.getAllProviders().iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Location lastKnownLocation = locationManager.getLastKnownLocation(it.next());
            if (lastKnownLocation != null) {
                sb.append(lastKnownLocation.getLongitude()).append(",").append(lastKnownLocation.getLatitude());
                break;
            }
        }
        return sb.toString();
    }
}
