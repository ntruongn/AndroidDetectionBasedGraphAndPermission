package com.feedback.c;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import com.feedback.a.d;
import com.feedback.a.e;
import com.mobclick.android.UmengConstants;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a extends Thread {
    private static ExecutorService b = Executors.newFixedThreadPool(3);
    private Context a;

    public a(Context context) {
        this.a = context;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        boolean z = false;
        ArrayList<d> arrayList = new ArrayList();
        SharedPreferences sharedPreferences = this.a.getSharedPreferences(UmengConstants.FeedbackPreName, 0);
        Iterator<String> it = sharedPreferences.getAll().keySet().iterator();
        while (it.hasNext()) {
            String string = sharedPreferences.getString(it.next(), null);
            if (!com.feedback.b.d.a(string) && string.indexOf("fail") != -1) {
                try {
                    arrayList.add(new d(new JSONArray(string)));
                } catch (Exception e) {
                }
            }
        }
        for (d dVar : arrayList) {
            if (dVar.b != e.Normal && dVar.b != e.PureSending) {
                boolean z2 = z;
                int i = -1;
                for (com.feedback.a.a aVar : dVar.f) {
                    i++;
                    if (aVar.g == com.feedback.a.b.Fail) {
                        try {
                            JSONArray jSONArray = new JSONArray(sharedPreferences.getString(dVar.c, null));
                            jSONArray.put(i, aVar.h.put(UmengConstants.AtomKey_State, com.feedback.a.b.Resending));
                            sharedPreferences.edit().putString(dVar.c, jSONArray.toString()).commit();
                            b.submit(new c(aVar.h, this.a));
                            z2 = true;
                        } catch (JSONException e2) {
                        }
                    }
                }
                z = z2;
            }
        }
        if (z) {
            this.a.sendBroadcast(new Intent().setAction(UmengConstants.PostFeedbackBroadcastAction));
        }
    }
}
