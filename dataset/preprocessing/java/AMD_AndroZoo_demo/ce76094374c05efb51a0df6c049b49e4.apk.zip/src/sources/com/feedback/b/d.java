package com.feedback.b;

import android.content.Context;
import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class d {
    static final String a = "Util";
    private static final int b = 30000;

    public static String a() {
        return "RP" + String.valueOf(System.currentTimeMillis()) + String.valueOf((int) (1000.0d + (Math.random() * 9000.0d)));
    }

    public static String a(String str, String str2, String str3) {
        return String.valueOf(str) + "[" + str2 + "_" + str3 + "]" + String.valueOf(System.currentTimeMillis()) + String.valueOf((int) (1000.0d + (Math.random() * 9000.0d)));
    }

    public static String a(String str, String str2, JSONObject jSONObject) {
        return b(str, str2, jSONObject);
    }

    public static String a(Date date, Context context) {
        if (date == null) {
            return "";
        }
        Locale locale = context.getResources().getConfiguration().locale;
        return (Locale.CHINA.equals(locale) ? new SimpleDateFormat("M月d日", locale) : new SimpleDateFormat("dd MMMM", locale)).format(date);
    }

    public static boolean a(String str) {
        return str == null || str.trim().length() == 0;
    }

    public static boolean a(String str, String str2) {
        Log.i(a, "[reply_id_of_b]" + str2);
        if (str == null || str2 == null) {
            return false;
        }
        try {
            return Double.parseDouble(str.substring(2)) >= Double.parseDouble(str2.substring(2));
        } catch (Exception e) {
            Log.w(a, "reply id invalid.LocalMaxReplyId:" + str + "reply_id_of_b:" + str2);
            return true;
        }
    }

    public static String b(String str) {
        return b(str, null, null);
    }

    private static String b(String str, String str2, JSONObject jSONObject) {
        HttpRequestBase httpGet;
        if (str2 != null) {
            ArrayList arrayList = new ArrayList(1);
            arrayList.add(new BasicNameValuePair(str2, jSONObject.toString()));
            try {
                UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(arrayList, "UTF-8");
                HttpRequestBase httpPost = new HttpPost(str);
                httpPost.addHeader(urlEncodedFormEntity.getContentType());
                ((HttpPost) httpPost).setEntity(urlEncodedFormEntity);
                httpGet = httpPost;
            } catch (UnsupportedEncodingException e) {
                throw new AssertionError(e);
            }
        } else {
            httpGet = new HttpGet(str);
        }
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
        HttpParams params = defaultHttpClient.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 30000);
        HttpConnectionParams.setSoTimeout(params, 30000);
        ConnManagerParams.setTimeout(params, 30000L);
        try {
            HttpResponse execute = defaultHttpClient.execute(httpGet);
            if (execute.getStatusLine().getStatusCode() == 200) {
                return EntityUtils.toString(execute.getEntity());
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return null;
    }

    public static String b(Date date, Context context) {
        return date == null ? "" : new SimpleDateFormat("yyyy-M-d HH:mm", context.getResources().getConfiguration().locale).format(date);
    }
}
