package com.uucun.adsdk;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import com.mobclick.android.UmengConstants;
import com.uucun.adsdk.b.h;
import com.uucun.adsdk.b.k;
import com.uucun.adsdk.c.g;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class d {
    private static final String a = d.class.getSimpleName();
    private static HashMap c = new HashMap();
    private b b = null;

    public d(Context context) {
        b(context);
    }

    public d(Context context, String str, String str2) {
        a(context, str, str2);
    }

    private String a(Context context, String str) {
        Object obj;
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
            return (bundle == null || (obj = bundle.get(str)) == null) ? "" : obj.toString();
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return "";
        }
    }

    private void a(Context context, String str, String str2) {
        c.put("app_key", str);
        c.put("channel_id", str2);
        g(context);
        i(context);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b(Context context, String str) {
        if (str == null) {
            return;
        }
        if (str.length() > 4000) {
            str = str.substring(0, 3999);
        }
        if (c == null || c.isEmpty()) {
            i(context);
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put("channel_id", c.get("channel_id"));
            jSONObject.put(UmengConstants.AtomKey_AppVersion, c.get(UmengConstants.AtomKey_AppVersion));
            jSONObject.put("device_name", c.get("device_name"));
            jSONObject.put("imei", c.get("imei"));
            jSONObject.put(UmengConstants.AtomKey_OSVersion, c.get(UmengConstants.AtomKey_OSVersion));
            jSONObject.put("error_msg", str);
            jSONObject.put("date", System.currentTimeMillis() + "");
            jSONObject.put("req_type", "2");
        } catch (Exception e) {
        }
        h.b(a, "发送BUG信息...");
        new com.uucun.adsdk.c.c(context, k.a().g, jSONObject, false).start();
    }

    public static HashMap c(Context context) {
        if (c == null) {
            UUAppConnect.getInstance(context);
            return c;
        }
        String str = (String) c.get("app_key");
        if (str == null || "".equals(str.trim())) {
            new d(context);
            c.put("area", com.uucun.adsdk.b.b.k(context));
        }
        return c;
    }

    private void g(Context context) {
        String a2 = com.uucun.adsdk.b.b.a(context);
        if (a2 == null || TextUtils.isEmpty(a2.trim())) {
            a2 = com.uucun.adsdk.b.b.g(context);
        }
        h.b(a, "imei:" + a2);
        c.put("imei", a2);
    }

    private void h(Context context) {
        h.e = context;
        h.a(false);
    }

    private void i(Context context) {
        h(context);
        c.put("device_name", com.uucun.adsdk.b.b.a());
        c.put(UmengConstants.AtomKey_OSVersion, com.uucun.adsdk.b.b.b());
        c.put("language", com.uucun.adsdk.b.b.d(context));
        c.put("local_code", com.uucun.adsdk.b.b.c(context));
        c.put("package_name", context.getPackageName());
        c.put("simcard_number", com.uucun.adsdk.b.b.g(context));
        int[] a2 = com.uucun.adsdk.b.b.a(context, true);
        c.put("resolution", a2[0] + "x" + a2[1]);
        c.put("simcard_type", com.uucun.adsdk.b.b.f(context));
        c.put(UmengConstants.AtomKey_AppVersion, Integer.toString(com.uucun.adsdk.b.b.b(context)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void j(Context context) {
        com.uucun.adsdk.b.a a2 = com.uucun.adsdk.b.a.a(context);
        long b = a2.b("last_startup_time", 0L);
        long b2 = a2.b("last_end_time", 0L);
        a2.a("last_startup_time", System.currentTimeMillis());
        a2.a("last_end_time");
        a2.a();
        if (b == 0) {
            return;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put("channel_id", c.get("channel_id"));
            jSONObject.put("imei", c.get("imei"));
            jSONObject.put("startup_time", Long.toString(b));
            jSONObject.put("exit_time", Long.toString(b2));
            jSONObject.put("req_type", "3");
            jSONObject.put("device_name", c.get("device_name"));
            jSONObject.put("network_type", com.uucun.adsdk.b.b.e(context));
            jSONObject.put("language", c.get("language"));
            jSONObject.put("local_code", c.get("language"));
            jSONObject.put(UmengConstants.AtomKey_OSVersion, c.get(UmengConstants.AtomKey_OSVersion));
            jSONObject.put("resolution", c.get("resolution"));
            jSONObject.put("simcard_type", c.get("simcard_type"));
            jSONObject.put("area", c.get("area"));
            jSONObject.put("simcard_number", c.get("simcard_number"));
        } catch (Exception e) {
        }
        new com.uucun.adsdk.c.c(context, k.a().c, jSONObject, false).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void k(Context context) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put("channel_id", c.get("channel_id"));
            jSONObject.put("device_name", c.get("device_name"));
            jSONObject.put("imei", c.get("imei"));
            jSONObject.put("network_type", com.uucun.adsdk.b.b.e(context));
            jSONObject.put("language", c.get("language"));
            jSONObject.put("local_code", c.get("language"));
            jSONObject.put(UmengConstants.AtomKey_OSVersion, c.get(UmengConstants.AtomKey_OSVersion));
            jSONObject.put("resolution", c.get("resolution"));
            jSONObject.put("simcard_type", c.get("simcard_type"));
            jSONObject.put("packages", com.uucun.adsdk.b.b.j(context));
            jSONObject.put("area", c.get("area"));
            jSONObject.put("simcard_number", c.get("simcard_number"));
            jSONObject.put("req_type", "4");
        } catch (Exception e) {
        }
        new com.uucun.adsdk.c.c(context, k.a().f, jSONObject, false).start();
    }

    public void a() {
        if (this.b != null) {
            this.b.a();
        }
    }

    public void a(float f, UpdatePointListener updatePointListener, Context context) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put("imei", c.get("imei"));
            jSONObject.put("point", f);
            jSONObject.put("req_type", "2");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        new com.uucun.adsdk.c.h(updatePointListener, k.a().e, context).execute(new JSONObject[]{jSONObject});
    }

    public void a(Context context) {
        new e(this, context).start();
        e(context);
    }

    public void a(UpdatePointListener updatePointListener, Context context) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put("imei", c.get("imei"));
            jSONObject.put("req_type", "1");
        } catch (Exception e) {
        }
        new g(updatePointListener, k.a().d, context).execute(new JSONObject[]{jSONObject});
    }

    public void b(Context context) {
        String a2 = a(context, "UU_APP_KEY");
        c.put("app_key", a2 == null ? "" : a2.trim());
        String a3 = a(context, "UU_CHANNEL_ID");
        c.put("channel_id", a3 == null ? "" : a3.trim());
        h.b(a, "appKey:" + a2 + " channel: " + a3);
        g(context);
        i(context);
    }

    public void d(Context context) {
        a();
        h.a();
    }

    public void e(Context context) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("app_key", c.get("app_key"));
            jSONObject.put(UmengConstants.AtomKey_AppVersion, c.get(UmengConstants.AtomKey_AppVersion));
            jSONObject.put("req_type", "1");
        } catch (Exception e) {
            e.printStackTrace();
        }
        new com.uucun.adsdk.c.k(context, k.a().h).execute(new JSONObject[]{jSONObject});
    }

    public void f(Context context) {
        if (this.b == null) {
            this.b = new b(this, context);
            this.b.start();
        }
    }
}
