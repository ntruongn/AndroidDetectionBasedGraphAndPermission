package com.wooboo.adlib_android;

import android.os.Message;
import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class od extends TimerTask {
    final ImpressionAdView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public od(ImpressionAdView impressionAdView) {
        this.a = impressionAdView;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        Message message = new Message();
        message.what = 3;
        ImpressionAdView.w.sendMessage(message);
    }
}
