package com.uucun.adsdk.view;

import android.os.Handler;
import android.os.Message;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class c extends WebChromeClient {
    final /* synthetic */ OfferwallView a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(OfferwallView offerwallView) {
        this.a = offerwallView;
    }

    @Override // android.webkit.WebChromeClient
    public void onProgressChanged(WebView webView, int i) {
        Handler handler;
        Message message = new Message();
        message.what = 3;
        message.arg1 = i;
        handler = this.a.d;
        handler.sendMessage(message);
    }
}
