package com.kuguo.pushads;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Environment;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.wooboo.adlib_android.nb;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a {
    protected static int a = -99;

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0049 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.io.BufferedReader] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.io.BufferedReader] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static int a(android.content.Context r6, java.lang.String r7, int r8) {
        /*
            r1 = 0
            android.content.res.AssetManager r2 = r6.getAssets()     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L46
            java.io.BufferedReader r0 = new java.io.BufferedReader     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L46
            java.io.InputStreamReader r3 = new java.io.InputStreamReader     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L46
            r4 = 3
            java.io.InputStream r2 = r2.open(r7, r4)     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L46
            r3.<init>(r2)     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L46
            r0.<init>(r3)     // Catch: java.lang.Exception -> L26 java.lang.Throwable -> L46
            java.lang.String r1 = r0.readLine()     // Catch: java.lang.Throwable -> L51 java.lang.Exception -> L56
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch: java.lang.Throwable -> L51 java.lang.Exception -> L56
            int r8 = r1.intValue()     // Catch: java.lang.Throwable -> L51 java.lang.Exception -> L56
            if (r0 == 0) goto L25
            r0.close()     // Catch: java.io.IOException -> L4d
        L25:
            return r8
        L26:
            r0 = move-exception
            r0 = r1
        L28:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L51
            r1.<init>()     // Catch: java.lang.Throwable -> L51
            java.lang.StringBuilder r1 = r1.append(r7)     // Catch: java.lang.Throwable -> L51
            java.lang.String r2 = " is not exist!"
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch: java.lang.Throwable -> L51
            java.lang.String r1 = r1.toString()     // Catch: java.lang.Throwable -> L51
            a(r1)     // Catch: java.lang.Throwable -> L51
            if (r0 == 0) goto L25
            r0.close()     // Catch: java.io.IOException -> L44
            goto L25
        L44:
            r0 = move-exception
            goto L25
        L46:
            r0 = move-exception
        L47:
            if (r1 == 0) goto L4c
            r1.close()     // Catch: java.io.IOException -> L4f
        L4c:
            throw r0
        L4d:
            r0 = move-exception
            goto L25
        L4f:
            r1 = move-exception
            goto L4c
        L51:
            r1 = move-exception
            r5 = r1
            r1 = r0
            r0 = r5
            goto L47
        L56:
            r1 = move-exception
            goto L28
        */
        throw new UnsupportedOperationException("Method not decompiled: com.kuguo.pushads.a.a(android.content.Context, java.lang.String, int):int");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static Intent a(Context context, File file, int i) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
        intent.addFlags(268435456);
        return intent;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static Bitmap a(Context context, String str, boolean z) {
        if (z) {
            try {
                return BitmapFactory.decodeStream(context.getAssets().open(str));
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
        try {
            return BitmapFactory.decodeStream(new FileInputStream(str));
        } catch (FileNotFoundException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static Bitmap a(Bitmap bitmap, Bitmap bitmap2) {
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        Paint paint = new Paint();
        Canvas canvas = new Canvas(createBitmap);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
        canvas.drawBitmap(bitmap2, 0.0f, r1 - bitmap2.getHeight(), paint);
        return createBitmap;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static j a(Context context, String str) {
        if (str == null || str.trim().equals("")) {
            return null;
        }
        j[] d = d(context);
        if (d == null || d.length <= 0) {
            return null;
        }
        for (j jVar : d) {
            if (str.equals(jVar.i)) {
                return jVar;
            }
        }
        return null;
    }

    public static String a(Context context) {
        String subscriberId = ((TelephonyManager) context.getSystemService("phone")).getSubscriberId();
        a("imsi == " + subscriberId);
        return subscriberId;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(Context context, Intent intent, int i, j jVar, int i2, boolean z, boolean z2) {
        int i3 = jVar.h + 10000;
        NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
        if (z2) {
            notificationManager.cancel(i3);
            return;
        }
        Notification notification = new Notification(i, jVar.k, System.currentTimeMillis());
        notification.setLatestEventInfo(context, jVar.k, jVar.b, PendingIntent.getActivity(context, i3, intent, 134217728));
        if (i2 != a) {
            notification.flags = i2;
        }
        if (z) {
            notification.defaults |= 4;
            if (jVar.x == 1) {
                notification.defaults |= 2;
            }
            notification.flags |= 1;
            notification.ledARGB = -16711936;
            notification.ledOnMS = 500;
            notification.ledOffMS = 2000;
        }
        notificationManager.notify(i3, notification);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(Context context, String str, int i, boolean z) {
        if ("mounted".equals(Environment.getExternalStorageState())) {
            new File(Environment.getExternalStorageDirectory(), "download/ads/" + i + "/" + str).delete();
        }
    }

    public static void a(Context context, String str, String str2, int i) {
        if (str == null || "".equals(str) || str2 == null || "".equals(str2)) {
            return;
        }
        context.startActivity(a(context, new File(str), i));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(String str) {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean a(int i) {
        File[] listFiles;
        if (!"mounted".equals(Environment.getExternalStorageState())) {
            return false;
        }
        File file = new File(Environment.getExternalStorageDirectory(), "download/ads/" + i);
        if (file.exists() && file.isDirectory() && (listFiles = file.listFiles()) != null) {
            for (File file2 : listFiles) {
                file2.delete();
            }
        }
        return file.delete();
    }

    private static boolean a(Context context, int i) {
        SharedPreferences.Editor edit = context.getSharedPreferences("request_prefs", 0).edit();
        edit.putInt("nextRequest", i);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        edit.putString("date", calendar.get(1) + "-" + calendar.get(2) + "-" + calendar.get(5));
        return edit.commit();
    }

    private static boolean a(Context context, int i, int i2) {
        if (i2 == -1) {
            return false;
        }
        SharedPreferences sharedPreferences = context.getSharedPreferences("request_prefs", 0);
        String string = sharedPreferences.getString("adsState", "");
        SharedPreferences.Editor edit = sharedPreferences.edit();
        if ("".equals(string)) {
            edit.putString("adsState", "" + i + "," + i2);
        } else {
            HashMap hashMap = new HashMap();
            String[] a2 = a(string, ";");
            if (a2 != null) {
                for (String str : a2) {
                    String[] a3 = a(str, ",");
                    if (a3 != null && a3.length == 2) {
                        hashMap.put(a3[0], a3[1]);
                    }
                }
            }
            hashMap.put(String.valueOf(i), String.valueOf(i2));
            StringBuffer stringBuffer = null;
            for (String str2 : hashMap.keySet()) {
                if (stringBuffer == null) {
                    stringBuffer = new StringBuffer();
                } else {
                    stringBuffer.append(";");
                }
                StringBuffer stringBuffer2 = stringBuffer;
                String str3 = (String) hashMap.get(str2);
                stringBuffer2.append(str2);
                stringBuffer2.append(",");
                stringBuffer2.append(str3);
                stringBuffer = stringBuffer2;
            }
            if (stringBuffer != null) {
                edit.putString("adsState", stringBuffer.toString());
            }
        }
        return edit.commit();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean a(Context context, j jVar) {
        int i = 0;
        SharedPreferences sharedPreferences = context.getSharedPreferences("message_prefs", 0);
        a(context, jVar.w);
        while (sharedPreferences.contains("" + i)) {
            i++;
        }
        jVar.f = i;
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putString("" + i, jVar.a());
        return edit.commit();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean a(String str, int i) {
        if (str == null || str.trim().equals("") || !"mounted".equals(Environment.getExternalStorageState())) {
            return false;
        }
        return new File(Environment.getExternalStorageDirectory(), "download/ads/" + i + "/" + str).exists();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static String[] a(String str, String str2) {
        int i = 0;
        if (str == null || str.equals("") || str2 == null || str2.equals("")) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        int i2 = 0;
        while (true) {
            int indexOf = str.indexOf(str2, i2);
            if (indexOf == -1) {
                break;
            }
            arrayList.add(str.substring(i2, indexOf));
            i2 = str2.length() + indexOf;
        }
        if (str.length() > i2) {
            arrayList.add(str.substring(i2));
        }
        String[] strArr = new String[arrayList.size()];
        ListIterator listIterator = arrayList.listIterator();
        while (listIterator.hasNext()) {
            strArr[i] = (String) listIterator.next();
            i++;
        }
        return strArr;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int b(Context context) {
        int a2 = a(context, "ads/p.txt", 100061);
        a("projectId == " + a2);
        return a2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static File b(Context context, String str, int i) {
        if (!"mounted".equals(Environment.getExternalStorageState())) {
            return null;
        }
        String str2 = "download/ads/" + i;
        File file = new File(Environment.getExternalStorageDirectory(), str2);
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(Environment.getExternalStorageDirectory(), str2 + "/" + str);
        if (!file2.exists()) {
            try {
                file2.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
        return file2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean b(Context context, j jVar) {
        j[] d;
        if (jVar == null) {
            return false;
        }
        SharedPreferences sharedPreferences = context.getSharedPreferences("message_prefs", 0);
        String str = "" + jVar.f;
        if (!sharedPreferences.contains(str) || (d = d(context)) == null) {
            return false;
        }
        for (j jVar2 : d) {
            if (jVar2.f == jVar.f) {
                if (jVar2.j.intValue() == 3) {
                    return false;
                }
                if (jVar2.j.intValue() >= jVar.j.intValue() && jVar.j.intValue() != 3) {
                    return false;
                }
                SharedPreferences.Editor edit = sharedPreferences.edit();
                edit.remove(str);
                edit.putString(str, jVar.a());
                a(context, jVar.h, jVar.j.intValue());
                return edit.commit();
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean b(Context context, String str) {
        try {
            context.getPackageManager().getPackageInfo(str.trim(), 256);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int c(Context context) {
        int a2 = a(context, "ads/m.txt", 1);
        Log.d("android__log", "-------startMode == " + a2);
        return a2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean c(Context context, j jVar) {
        String[] a2;
        if (jVar.s == null || (a2 = a(jVar.s, ";")) == null) {
            return false;
        }
        for (String str : a2) {
            if (b(context, str)) {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse("market://details?id=" + jVar.i.trim()));
                intent.setPackage(str);
                intent.setFlags(268435456);
                try {
                    context.startActivity(intent);
                    return true;
                } catch (Exception e) {
                }
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean c(Context context, String str) {
        Intent d = d(context, str);
        if (d == null) {
            return false;
        }
        context.startActivity(d);
        return true;
    }

    public static Intent d(Context context, String str) {
        ResolveInfo resolveInfo;
        if (str == null || str.trim().equals("")) {
            return null;
        }
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent("android.intent.action.MAIN", (Uri) null);
        intent.addCategory("android.intent.category.LAUNCHER");
        List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 0);
        if (queryIntentActivities != null) {
            int size = queryIntentActivities.size();
            for (int i = 0; i < size; i++) {
                resolveInfo = queryIntentActivities.get(i);
                if (str.equals(resolveInfo.activityInfo.packageName)) {
                    break;
                }
            }
        }
        resolveInfo = null;
        if (resolveInfo == null) {
            return null;
        }
        ComponentName componentName = new ComponentName(str, resolveInfo.activityInfo.name);
        Intent intent2 = new Intent();
        intent2.setComponent(componentName);
        intent2.setFlags(268435456);
        return intent2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static j[] d(Context context) {
        int i = 0;
        SharedPreferences sharedPreferences = context.getSharedPreferences("message_prefs", 0);
        Map<String, ?> all = sharedPreferences.getAll();
        if (all == null || all.size() <= 0) {
            return null;
        }
        Iterator<String> it = all.keySet().iterator();
        j[] jVarArr = new j[all.size()];
        while (true) {
            int i2 = i;
            if (!it.hasNext()) {
                return jVarArr;
            }
            String next = it.next();
            String string = sharedPreferences.getString(next, null);
            j jVar = new j();
            if (!jVar.a(string)) {
                sharedPreferences.edit().clear().commit();
                return null;
            }
            jVar.f = Integer.valueOf(next).intValue();
            i = i2 + 1;
            jVarArr[i2] = jVar;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int e(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("request_prefs", 0);
        if (sharedPreferences.getInt("nextRequest", 1) == 1) {
            return 0;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        String str = calendar.get(1) + "-" + calendar.get(2) + "-" + calendar.get(5);
        if (str.equals(sharedPreferences.getString("date", str))) {
            return sharedPreferences.getString("adsState", null) != null ? 2 : -1;
        }
        return 1;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean f(Context context) {
        SharedPreferences.Editor edit = context.getSharedPreferences("request_prefs", 0).edit();
        edit.remove("adsState");
        return edit.commit();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void g(Context context) {
        j[] d = d(context);
        if (d == null) {
            return;
        }
        SharedPreferences.Editor edit = context.getSharedPreferences("message_prefs", 0).edit();
        for (j jVar : d) {
            String str = "" + jVar.f;
            if (jVar.c + 864000000 >= System.currentTimeMillis()) {
                switch (jVar.e) {
                    case 0:
                        if (jVar.j.intValue() == 1) {
                            edit.remove(str);
                            break;
                        } else {
                            break;
                        }
                    case 1:
                    case nb.p /* 3 */:
                        if (jVar.j.intValue() == 3) {
                            edit.remove(str);
                            break;
                        } else {
                            break;
                        }
                    case 2:
                    case 4:
                    case nb.s /* 6 */:
                    case 8:
                        if (jVar.j.intValue() == 2) {
                            edit.remove(str);
                            break;
                        } else {
                            break;
                        }
                }
            } else {
                edit.remove(str);
            }
        }
        edit.commit();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static String h(Context context) {
        String string = context.getSharedPreferences("request_prefs", 0).getString("adsState", null);
        a("adsState == " + string);
        return string;
    }

    public static boolean i(Context context) {
        return (context.getApplicationInfo().flags & 1) > 0;
    }
}
