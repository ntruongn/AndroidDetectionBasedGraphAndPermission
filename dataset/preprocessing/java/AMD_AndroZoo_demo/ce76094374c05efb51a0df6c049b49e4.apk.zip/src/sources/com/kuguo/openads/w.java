package com.kuguo.openads;

import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class w extends ArrayList {
    final /* synthetic */ k a;

    private w(k kVar) {
        this.a = kVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ w(k kVar, n nVar) {
        this(kVar);
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public boolean add(g gVar) {
        if (gVar.l != 0) {
            return super.add(gVar);
        }
        for (int size = size() - 1; size >= 0; size--) {
            if (((g) get(size)).l == 0) {
                add(size + 1, gVar);
                return true;
            }
        }
        add(0, gVar);
        return true;
    }
}
