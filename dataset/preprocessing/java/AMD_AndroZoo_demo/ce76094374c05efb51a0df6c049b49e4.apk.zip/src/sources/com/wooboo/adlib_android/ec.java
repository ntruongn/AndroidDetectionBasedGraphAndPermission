package com.wooboo.adlib_android;

import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class ec {
    private static final String[] z = {z(z("\u0003\u0001z`e0Ng3$~Of~';S=")), z(z("\u0014r\\]\u0004,Srj\u001e")), z(z("\u0003\u0001}|1~G|f+:\u000f")), z(z("\u001f\u0001Y@\n\u0010`aa$'\u0001gv=*\u0001~f6*\u0001`g$,U3d,*I34\u001ey")), z(z("\u001bYcv&*Dw3$~\u0006?4e1S34\u0018y")), z(z("8@\u007f` ")), z(z("*Sfv")), z(z("\u0003\u0001z`e0Ng3$~C||);@}=")), z(z("\u0014r\\]\u0004,Srje7Ozg,?M3e$2Tv366Nf\u007f!~Cv3$~Rga,0F3|7~B|\u007f);Bgz*0\u0001|ae?Sar<p")), z(z("\u0003\u0001z`e0Ng3$~k@\\\u000b\u0011Cyv&*\u000f")), z(z("\u0003\u0001z`e0Ng3$~k@\\\u000b\u001fSar<p")), z(z("r+")), z(z("\u0005|")), z(z("\u0003\u0001}|1~@3`1,H}tk"))};
    private final ArrayList a;

    public ec() {
        this.a = new ArrayList();
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:17:0x0036. Please report as an issue. */
    public ec(ic icVar) throws o {
        this();
        if (icVar.e() != '[') {
            throw icVar.b(z[3]);
        }
        try {
            if (icVar.e() == ']') {
                return;
            }
            icVar.a();
            while (true) {
                try {
                    if (icVar.e() == ',') {
                        icVar.a();
                        this.a.add(fc.b);
                    } else {
                        icVar.a();
                        this.a.add(icVar.f());
                    }
                    try {
                        switch (icVar.e()) {
                            case ',':
                            case ';':
                                try {
                                    if (icVar.e() == ']') {
                                        return;
                                    } else {
                                        icVar.a();
                                    }
                                } catch (o e) {
                                    throw e;
                                }
                            case ']':
                                return;
                            default:
                                throw icVar.b(z[4]);
                        }
                    } catch (o e2) {
                        throw e2;
                    }
                } catch (o e3) {
                    throw e3;
                }
            }
        } catch (o e4) {
            throw e4;
        }
    }

    public ec(Object obj) throws o {
        this();
        if (!obj.getClass().isArray()) {
            throw new o(z[8]);
        }
        int length = Array.getLength(obj);
        for (int i = 0; i < length; i++) {
            a(fc.e(Array.get(obj, i)));
        }
    }

    public ec(String str) throws o {
        this(new ic(str));
    }

    public ec(Collection collection) {
        this.a = new ArrayList();
        if (collection != null) {
            Iterator it = collection.iterator();
            while (it.hasNext()) {
                this.a.add(fc.e(it.next()));
            }
        }
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '^';
                    break;
                case 1:
                    c = '!';
                    break;
                case 2:
                    c = 19;
                    break;
                case nb.p /* 3 */:
                    c = 19;
                    break;
                default:
                    c = 'E';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'E');
        }
        return charArray;
    }

    public double a(int i, double d) {
        try {
            return c(i);
        } catch (Exception e) {
            return d;
        }
    }

    public int a() {
        return this.a.size();
    }

    public int a(int i, int i2) {
        try {
            return d(i);
        } catch (Exception e) {
            return i2;
        }
    }

    public long a(int i, long j) {
        try {
            return g(i);
        } catch (Exception e) {
            return j;
        }
    }

    public ec a(double d) throws o {
        Double d2 = new Double(d);
        fc.c(d2);
        a(d2);
        return this;
    }

    public ec a(int i, Object obj) throws o {
        try {
            fc.c(obj);
            if (i < 0) {
                throw new o(z[1] + i + z[2]);
            }
            try {
                if (i < a()) {
                    this.a.set(i, obj);
                } else {
                    while (i != a()) {
                        try {
                            a(fc.b);
                        } catch (o e) {
                            throw e;
                        }
                    }
                    a(obj);
                }
                return this;
            } catch (o e2) {
                throw e2;
            }
        } catch (o e3) {
            throw e3;
        }
    }

    public ec a(int i, Collection collection) throws o {
        a(i, new ec(collection));
        return this;
    }

    public ec a(int i, Map map) throws o {
        a(i, new fc(map));
        return this;
    }

    public ec a(long j) {
        a(new Long(j));
        return this;
    }

    public ec a(Object obj) {
        this.a.add(obj);
        return this;
    }

    public ec a(Collection collection) {
        a((Object) new ec(collection));
        return this;
    }

    public ec a(Map map) {
        a(new fc(map));
        return this;
    }

    public ec a(boolean z2) {
        a(z2 ? Boolean.TRUE : Boolean.FALSE);
        return this;
    }

    public fc a(ec ecVar) throws o {
        if (ecVar != null) {
            try {
                try {
                    if (ecVar.a() != 0 && a() != 0) {
                        fc fcVar = new fc();
                        for (int i = 0; i < ecVar.a(); i++) {
                            try {
                                fcVar.c(ecVar.h(i), j(i));
                            } catch (o e) {
                                throw e;
                            }
                        }
                        return fcVar;
                    }
                } catch (o e2) {
                    throw e2;
                }
            } catch (o e3) {
                throw e3;
            }
        }
        return null;
    }

    public Writer a(Writer writer) throws o {
        boolean z2 = false;
        try {
            int a = a();
            writer.write(91);
            int i = 0;
            while (i < a) {
                if (z2) {
                    try {
                        writer.write(44);
                    } catch (IOException e) {
                        throw e;
                    }
                }
                Object obj = this.a.get(i);
                try {
                    if (obj instanceof fc) {
                        ((fc) obj).a(writer);
                    } else {
                        try {
                            if (obj instanceof ec) {
                                ((ec) obj).a(writer);
                            } else {
                                writer.write(fc.d(obj));
                            }
                        } catch (IOException e2) {
                            throw e2;
                        }
                    }
                    i++;
                    z2 = true;
                } catch (IOException e3) {
                    throw e3;
                }
            }
            writer.write(93);
            return writer;
        } catch (IOException e4) {
            throw new o(e4);
        }
    }

    public Object a(int i) throws o {
        Object j = j(i);
        if (j != null) {
            return j;
        }
        try {
            throw new o(z[1] + i + z[2]);
        } catch (o e) {
            throw e;
        }
    }

    public String a(int i, String str) {
        Object j = j(i);
        return fc.b.equals(j) ? j.toString() : str;
    }

    public String a(String str) throws o {
        int a = a();
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < a; i++) {
            if (i > 0) {
                try {
                    stringBuffer.append(str);
                } catch (o e) {
                    throw e;
                }
            }
            stringBuffer.append(fc.d(this.a.get(i)));
        }
        try {
            return stringBuffer.toString();
        } catch (o e2) {
            throw e2;
        }
    }

    public boolean a(int i, boolean z2) {
        try {
            return b(i);
        } catch (Exception e) {
            return z2;
        }
    }

    public ec b(int i, double d) throws o {
        a(i, new Double(d));
        return this;
    }

    public ec b(int i, int i2) throws o {
        a(i, new Integer(i2));
        return this;
    }

    public ec b(int i, long j) throws o {
        a(i, new Long(j));
        return this;
    }

    public ec b(int i, boolean z2) throws o {
        Boolean bool;
        if (z2) {
            try {
                bool = Boolean.TRUE;
            } catch (o e) {
                throw e;
            }
        } else {
            bool = Boolean.FALSE;
        }
        a(i, bool);
        return this;
    }

    public boolean b(int i) throws o {
        Object a = a(i);
        try {
            try {
                try {
                    if (a.equals(Boolean.FALSE) || ((a instanceof String) && ((String) a).equalsIgnoreCase(z[5]))) {
                        return false;
                    }
                    try {
                        try {
                            try {
                                if (a.equals(Boolean.TRUE) || ((a instanceof String) && ((String) a).equalsIgnoreCase(z[6]))) {
                                    return true;
                                }
                                throw new o(z[1] + i + z[7]);
                            } catch (o e) {
                                throw e;
                            }
                        } catch (o e2) {
                            throw e2;
                        }
                    } catch (o e3) {
                        throw e3;
                    }
                } catch (o e4) {
                    throw e4;
                }
            } catch (o e5) {
                throw e5;
            }
        } catch (o e6) {
            throw e6;
        }
    }

    public double c(int i) throws o {
        Object a = a(i);
        try {
            return a instanceof Number ? ((Number) a).doubleValue() : Double.parseDouble((String) a);
        } catch (Exception e) {
            throw new o(z[1] + i + z[0]);
        }
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:18)
        */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0043  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x004d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0088  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0038 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:15:0x004b -> B:11:0x0044). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:18:0x005a -> B:14:0x0049). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x005e -> B:8:0x0036). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:32:0x006e -> B:24:0x0067). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:40:0x0086 -> B:9:0x0041). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    java.lang.String c(int r10, int r11) throws com.wooboo.adlib_android.o {
        /*
            r9 = this;
            r8 = 10
            r1 = 0
            boolean r3 = com.wooboo.adlib_android.sc.C
            int r4 = r9.a()
            if (r4 != 0) goto L14
            java.lang.String[] r0 = com.wooboo.adlib_android.ec.z     // Catch: com.wooboo.adlib_android.o -> L12
            r1 = 12
            r0 = r0[r1]     // Catch: com.wooboo.adlib_android.o -> L12
        L11:
            return r0
        L12:
            r0 = move-exception
            throw r0
        L14:
            java.lang.StringBuffer r5 = new java.lang.StringBuffer
            java.lang.String r0 = "["
            r5.<init>(r0)
            r0 = 1
            if (r4 != r0) goto L2e
            java.util.ArrayList r0 = r9.a     // Catch: com.wooboo.adlib_android.o -> L7a
            r2 = 0
            java.lang.Object r0 = r0.get(r2)     // Catch: com.wooboo.adlib_android.o -> L7a
            java.lang.String r0 = com.wooboo.adlib_android.fc.a(r0, r10, r11)     // Catch: com.wooboo.adlib_android.o -> L7a
            r5.append(r0)     // Catch: com.wooboo.adlib_android.o -> L7a
            if (r3 == 0) goto L70
        L2e:
            int r6 = r11 + r10
            r5.append(r8)
            if (r3 == 0) goto L8a
            r0 = r1
        L36:
            if (r0 <= 0) goto L41
            java.lang.String[] r2 = com.wooboo.adlib_android.ec.z     // Catch: com.wooboo.adlib_android.o -> L7c
            r7 = 11
            r2 = r2[r7]     // Catch: com.wooboo.adlib_android.o -> L7c
            r5.append(r2)     // Catch: com.wooboo.adlib_android.o -> L7c
        L41:
            if (r3 == 0) goto L88
            r2 = r1
        L44:
            r7 = 32
            r5.append(r7)     // Catch: com.wooboo.adlib_android.o -> L7e
        L49:
            int r2 = r2 + 1
        L4b:
            if (r2 < r6) goto L44
            java.util.ArrayList r7 = r9.a     // Catch: com.wooboo.adlib_android.o -> L80
            java.lang.Object r7 = r7.get(r0)     // Catch: com.wooboo.adlib_android.o -> L80
            java.lang.String r7 = com.wooboo.adlib_android.fc.a(r7, r10, r6)     // Catch: com.wooboo.adlib_android.o -> L80
            r5.append(r7)     // Catch: com.wooboo.adlib_android.o -> L80
            if (r3 != 0) goto L49
            int r0 = r0 + 1
        L5e:
            if (r0 < r4) goto L36
            r5.append(r8)
            if (r3 != 0) goto L86
            if (r3 == 0) goto L6e
        L67:
            r0 = 32
            r5.append(r0)     // Catch: com.wooboo.adlib_android.o -> L82
            int r1 = r1 + 1
        L6e:
            if (r1 < r11) goto L67
        L70:
            r0 = 93
            r5.append(r0)     // Catch: com.wooboo.adlib_android.o -> L84
            java.lang.String r0 = r5.toString()     // Catch: com.wooboo.adlib_android.o -> L84
            goto L11
        L7a:
            r0 = move-exception
            throw r0
        L7c:
            r0 = move-exception
            throw r0
        L7e:
            r0 = move-exception
            throw r0
        L80:
            r0 = move-exception
            throw r0
        L82:
            r0 = move-exception
            throw r0
        L84:
            r0 = move-exception
            throw r0
        L86:
            r0 = r1
            goto L41
        L88:
            r2 = r1
            goto L4b
        L8a:
            r0 = r1
            goto L5e
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ec.c(int, int):java.lang.String");
    }

    public int d(int i) throws o {
        Object a = a(i);
        try {
            return a instanceof Number ? ((Number) a).intValue() : Integer.parseInt((String) a);
        } catch (Exception e) {
            throw new o(z[1] + i + z[0]);
        }
    }

    public ec e(int i) throws o {
        Object a = a(i);
        try {
            if (a instanceof ec) {
                return (ec) a;
            }
            throw new o(z[1] + i + z[10]);
        } catch (o e) {
            throw e;
        }
    }

    public fc f(int i) throws o {
        Object a = a(i);
        try {
            if (a instanceof fc) {
                return (fc) a;
            }
            throw new o(z[1] + i + z[9]);
        } catch (o e) {
            throw e;
        }
    }

    public long g(int i) throws o {
        Object a = a(i);
        try {
            return a instanceof Number ? ((Number) a).longValue() : Long.parseLong((String) a);
        } catch (Exception e) {
            throw new o(z[1] + i + z[0]);
        }
    }

    public String h(int i) throws o {
        Object a = a(i);
        try {
            if (a instanceof String) {
                return (String) a;
            }
            throw new o(z[1] + i + z[13]);
        } catch (o e) {
            throw e;
        }
    }

    public boolean i(int i) {
        return fc.b.equals(j(i));
    }

    public Object j(int i) {
        if (i < 0 || i >= a()) {
            return null;
        }
        return this.a.get(i);
    }

    public boolean k(int i) {
        return a(i, false);
    }

    public double l(int i) {
        return a(i, Double.NaN);
    }

    public int m(int i) {
        return a(i, 0);
    }

    public ec n(int i) {
        Object j = j(i);
        if (j instanceof ec) {
            return (ec) j;
        }
        return null;
    }

    public fc o(int i) {
        Object j = j(i);
        if (j instanceof fc) {
            return (fc) j;
        }
        return null;
    }

    public long p(int i) {
        return a(i, 0L);
    }

    public String q(int i) {
        return a(i, "");
    }

    public ec r(int i) {
        a(new Integer(i));
        return this;
    }

    public Object s(int i) {
        Object j = j(i);
        this.a.remove(i);
        return j;
    }

    public String t(int i) throws o {
        return c(i, 0);
    }

    public String toString() {
        try {
            return String.valueOf('[') + a(",") + ']';
        } catch (Exception e) {
            return null;
        }
    }
}
