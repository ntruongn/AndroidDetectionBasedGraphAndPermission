package com.wooboo.adlib_android;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class rb implements DialogInterface.OnClickListener {
    private static final String z = z(z("\u0001VTt[\t\\\u001eoZ\u0014]^r\u001a\u0001[Do[\u000e\u0016fOq7"));
    final FullAdView a;
    private final String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public rb(FullAdView fullAdView, String str) {
        this.a = fullAdView;
        this.b = str;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '`';
                    break;
                case 1:
                    c = '8';
                    break;
                case 2:
                    c = '0';
                    break;
                case nb.p /* 3 */:
                    c = 6;
                    break;
                default:
                    c = '4';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '4');
        }
        return charArray;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        Intent intent = new Intent();
        intent.setAction(z);
        intent.setData(Uri.parse(this.b));
        intent.setFlags(268435456);
        this.a.getContext().startActivity(intent);
        FullAdView.b(this.a);
    }
}
