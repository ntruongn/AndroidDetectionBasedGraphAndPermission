package com.wooboo.adlib_android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class AdActivity extends Activity {
    private static final int q = 100;
    private static final int r = 110;
    private Context c;
    private WebView d;
    private float e;
    private boolean f;
    private String g;
    Button i;
    Bitmap j;
    Bitmap k;
    Button l;
    Bitmap m;
    Bitmap n;
    private static final String[] z = {z(z("M\u0017\u0003")), z(z("{\u0004\u0003k`[\n\u0001a)J\b;h\u0013]\u0017\u0019b2\u0002")), z(z("U\u0016\b")), z(z("K\u0000\f")), z(z("Y\f\u000b")), z(z("悐泄杦T\u0004卙ｩ撢佛斠泭达蠣＆")), z(z("轗亓嶝终之轅ｩ讘刷之轅么徬宎袅")), z(z("m1)*x")), z(z("V\u0004\u0002b")), z(z("悐砋寵覆剠陜")), z(z("揨祟")), z(z("启Z")), z(z("O\n\u0000e/W:\u001bn4T\u0000\u0003h'WK\u001fi'")), z(z("L\f\u001bk%Z\u0002Aw._")), z(z("L\u0000\u0003b!\\:\u001bn4T\u0000\u0003h'WK\u001fi'")), z(z("J\u0000\u000ek\u0015j)")), z(z("R\u0016\u0000i\u0012L\u000b")), z(z("q+<S\u0001t)0J\u0001v$(B\u0012")), z(z("M\u0017\u0003:")), z(z("Q\u00168h/Z\n\u0000")), z(z("k!0C\u0002"))};
    private static boolean h = true;
    private static String o = null;
    private HashMap a = null;
    private pc b = null;
    private CustomAdapter p = null;
    private boolean s = false;
    private RelativeLayout t = null;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public class CustomAdapter extends BaseAdapter {
        public static final String a = z(z("#Z7\\ \rn I?\u0014J6"));
        private Context b;
        final AdActivity c;

        public CustomAdapter(AdActivity adActivity, Context context) {
            this.c = adActivity;
            this.b = context;
        }

        private static String z(char[] cArr) {
            char c;
            int length = cArr.length;
            for (int i = 0; length > i; i++) {
                char c2 = cArr[i];
                switch (i % 5) {
                    case 0:
                        c = '`';
                        break;
                    case 1:
                        c = '/';
                        break;
                    case 2:
                        c = 'D';
                        break;
                    case nb.p /* 3 */:
                        c = '(';
                        break;
                    default:
                        c = 'O';
                        break;
                }
                cArr[i] = (char) (c ^ c2);
            }
            return new String(cArr).intern();
        }

        private static char[] z(String str) {
            char[] charArray = str.toCharArray();
            if (charArray.length < 2) {
                charArray[0] = (char) (charArray[0] ^ 'O');
            }
            return charArray;
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return AdActivity.b(this.c).size();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i) {
            return AdActivity.b(this.c).get(Integer.valueOf(i));
        }

        @Override // android.widget.Adapter
        public long getItemId(int i) {
            return i;
        }

        @Override // android.widget.Adapter
        public View getView(int i, View view, ViewGroup viewGroup) {
            return new l(this.c, this.b, (com.wooboo.download.d) AdActivity.b(this.c).get(AdActivity.b(this.c).keySet().toArray()[i]));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static float a(AdActivity adActivity) {
        return adActivity.e;
    }

    private void a() {
        try {
            this.t = new RelativeLayout(this.c);
            this.t.setId(0);
            this.t.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            Bitmap decodeStream = BitmapFactory.decodeStream(getResources().getAssets().open(z[13]));
            ImageView imageView = new ImageView(this.c);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, (int) (decodeStream.getHeight() * this.e));
            layoutParams.leftMargin = (int) (this.e * (-50.0f));
            layoutParams.rightMargin = (int) (this.e * (-50.0f));
            imageView.setLayoutParams(layoutParams);
            imageView.setBackgroundDrawable(new BitmapDrawable(decodeStream));
            this.t.addView(imageView);
            ImageView imageView2 = new ImageView(this.c);
            imageView2.setId(1);
            String str = z[12];
            Bitmap decodeStream2 = BitmapFactory.decodeStream(getResources().getAssets().open(this.f ? z[12] : z[14]));
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams((int) (decodeStream2.getWidth() * this.e), (int) (decodeStream2.getHeight() * this.e));
            layoutParams2.addRule(9);
            layoutParams2.addRule(15);
            layoutParams2.leftMargin = 10;
            imageView2.setLayoutParams(layoutParams2);
            imageView2.setBackgroundDrawable(new BitmapDrawable(decodeStream2));
            this.t.addView(imageView2);
        } catch (Exception e) {
        }
    }

    private void a(int i) {
        com.wooboo.download.f.a(this.c, (com.wooboo.download.g) null, this.b, com.wooboo.download.h.b(this.c)).c(((com.wooboo.download.d) this.a.get(Integer.valueOf(i))).k);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(AdActivity adActivity, int i) {
        adActivity.a(i);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(AdActivity adActivity, WebView webView) {
        adActivity.d = webView;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(AdActivity adActivity, String str, String str2, String str3, String str4, long j) {
        adActivity.a(str, str2, str3, str4, j);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(AdActivity adActivity, HashMap hashMap) {
        adActivity.a = hashMap;
    }

    /* JADX WARN: Code restructure failed: missing block: B:34:0x00d1, code lost:
    
        if (r8 != false) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x011f, code lost:
    
        if (r8 != false) goto L38;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void a(java.lang.String r12, java.lang.String r13, java.lang.String r14, java.lang.String r15, long r16) {
        /*
            Method dump skipped, instructions count: 330
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.AdActivity.a(java.lang.String, java.lang.String, java.lang.String, java.lang.String, long):void");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(boolean z2) {
        h = z2;
    }

    static HashMap b(AdActivity adActivity) {
        return adActivity.a;
    }

    private void b(int i) {
        com.wooboo.download.d dVar = (com.wooboo.download.d) this.a.get(Integer.valueOf(i));
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(z[10]).setMessage(z[9] + dVar.i + z[11]).setPositiveButton("是", new p(this, dVar)).setNegativeButton("否", new q(this)).create();
        builder.show();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void b(AdActivity adActivity, int i) {
        adActivity.b(i);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean b() {
        return h;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static WebView c(AdActivity adActivity) {
        return adActivity.d;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String d(AdActivity adActivity) {
        return adActivity.g;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Context e(AdActivity adActivity) {
        return adActivity.c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static pc f(AdActivity adActivity) {
        return adActivity.b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static CustomAdapter g(AdActivity adActivity) {
        return adActivity.p;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '8';
                    break;
                case 1:
                    c = 'e';
                    break;
                case 2:
                    c = 'o';
                    break;
                case nb.p /* 3 */:
                    c = 7;
                    break;
                default:
                    c = '@';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '@');
        }
        return charArray;
    }

    public void confirmToServer(String str) {
        try {
            HashMap hashMap = new HashMap();
            hashMap.put(z[2], sc.a(this.c, 4, sc.a(new HashMap(), new fc(o)), false));
            hashMap.put(z[0], sc.b(4));
            hashMap.put(z[3], sc.a(this.c, 0, new HashMap()));
            mc.c(z[1] + hashMap);
            if (sc.a(this.c)) {
                pc.a(this.c, com.wooboo.download.h.b()).a(Long.valueOf(System.currentTimeMillis()), hashMap);
                sc.a(this.c);
            } else {
                pc.a(this.c, (String) null).a(Long.valueOf(System.currentTimeMillis()), hashMap);
                com.wooboo.download.j.a(this.c).b();
            }
        } catch (o e) {
            e.printStackTrace();
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        this.c = getApplicationContext();
        Intent intent = getIntent();
        this.e = getResources().getDisplayMetrics().density;
        if (!intent.getBooleanExtra(z[17], false)) {
            String dataString = getIntent().getDataString();
            String stringExtra = getIntent().getStringExtra(z[15]);
            o = getIntent().getStringExtra(z[16]);
            if (o == null) {
                o = "";
            }
            this.g = dataString.substring(dataString.indexOf(z[18]) + 4);
            this.g = this.g.replace("&", "?");
            this.f = getIntent().getBooleanExtra(z[19], true);
            setContentView(new m(this, this, stringExtra));
            return;
        }
        this.f = intent.getBooleanExtra(z[19], true);
        a();
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        linearLayout.addView(this.t);
        this.s = true;
        if (intent.getBooleanExtra(z[20], false)) {
            this.b = pc.a(this.c, com.wooboo.download.h.b());
        } else {
            this.b = pc.a(this.c, (String) null);
        }
        this.a = this.b.g();
        ListView listView = new ListView(this.c);
        listView.setBackgroundColor(-7829368);
        linearLayout.addView(listView, new LinearLayout.LayoutParams(-1, -2, 1.0f));
        this.p = new CustomAdapter(this, this.c);
        listView.setAdapter((ListAdapter) this.p);
        setContentView(linearLayout);
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        try {
            this.d.stopLoading();
            this.d.destroy();
            this.d = null;
        } catch (Exception e) {
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (this.s || i != 4 || !this.d.canGoBack()) {
            return super.onKeyDown(i, keyEvent);
        }
        this.d.goBack();
        return true;
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        if (this.b != null) {
            this.a = this.b.g();
            this.p.notifyDataSetChanged();
        }
    }
}
