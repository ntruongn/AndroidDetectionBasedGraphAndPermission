package com.uucun.adsdk.c;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.text.TextUtils;
import com.uucun.adsdk.UUAppConnect;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class l extends AsyncTask {
    public static final String a = l.class.getSimpleName();
    public String c;
    private Notification d;
    private Context e;
    private NotificationManager f;
    private String j;
    private String k;
    private int l;
    private com.uucun.adsdk.d.f m;
    private File n;
    private File o;
    private String r;
    private String s;
    private String t;
    private long g = 0;
    private long h = 0;
    private long i = 0;
    private PendingIntent p = null;
    public String b = null;
    private StringBuffer q = new StringBuffer();

    public l(Context context, Handler handler, com.uucun.adsdk.d.f fVar, String str, String str2, String str3, String str4) {
        this.c = null;
        this.r = null;
        this.s = null;
        this.t = null;
        this.e = context;
        this.m = fVar;
        this.r = str2;
        this.s = str3;
        this.t = str4;
        this.f = (NotificationManager) context.getSystemService("notification");
        this.n = com.uucun.adsdk.b.c.a(context);
        try {
            this.l = Integer.parseInt(str) + 100000;
        } catch (Exception e) {
            this.l = 100000;
        }
        this.c = str;
        a();
    }

    /* JADX WARN: Removed duplicated region for block: B:67:0x0154  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private java.lang.Integer a(com.uucun.adsdk.d.f r15) {
        /*
            Method dump skipped, instructions count: 375
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.uucun.adsdk.c.l.a(com.uucun.adsdk.d.f):java.lang.Integer");
    }

    private void a(String str) {
        com.uucun.adsdk.b.h.b(a, "AdDownloadTask.regeditAction()  " + str);
        com.uucun.adsdk.b.c.a(this.e, new com.uucun.adsdk.e.a(this.e, str, this.t), "android.intent.action.PACKAGE_REMOVED", "android.intent.action.PACKAGE_ADDED");
    }

    private void a(String str, boolean z) {
        this.d.tickerText = str;
        if (z) {
            this.d.icon = 17301634;
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.addFlags(268435456);
            intent.setDataAndType(Uri.fromFile(this.o), "application/vnd.android.package-archive");
            PendingIntent activity = PendingIntent.getActivity(this.e, 0, intent, 134217728);
            this.d.flags = 16;
            this.d.setLatestEventInfo(this.e, this.j, this.j + "下载完成.", activity);
        } else {
            this.d.setLatestEventInfo(this.e, this.j, str, this.p);
        }
        this.f.notify(this.l, this.d);
    }

    private boolean a(Context context, File file) {
        if (!file.exists()) {
            return false;
        }
        String e = com.uucun.adsdk.b.c.e(context, file.getAbsolutePath());
        if (e != null && !TextUtils.isEmpty(e.trim())) {
            return true;
        }
        file.delete();
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public Integer doInBackground(Void... voidArr) {
        this.k = this.m.a + "_" + this.m.e + ".apk";
        this.j = this.m.c;
        a("准备下载..." + this.j, false);
        this.o = new File(this.n, this.k);
        if (a(this.e, this.o)) {
            return 3;
        }
        return a(this.m);
    }

    public void a() {
        this.d = new Notification();
        this.d.icon = 17301633;
        this.p = PendingIntent.getActivity(this.e, 0, new Intent(), 134217728);
        this.d.setLatestEventInfo(this.e, this.j, "准备下载...0%", this.p);
    }

    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void onPostExecute(Integer num) {
        if (1 != num.intValue()) {
            if (2 == num.intValue()) {
                this.f.cancel(this.l);
                UUAppConnect.showToast("下载" + this.j + "失败,请重试.", this.e);
                com.uucun.adsdk.b.h.b(a, "下载失败");
            } else if (3 == num.intValue()) {
                this.q.append(100).append("%").append(" 已下载.");
                a(this.q.toString(), true);
                com.uucun.adsdk.b.c.a(this.e, this.o.getPath());
            }
            com.uucun.adsdk.a.b.a().a(this, false);
            return;
        }
        this.b = com.uucun.adsdk.b.c.e(this.e, this.o.getPath());
        com.uucun.adsdk.b.h.b("Old PackageName:", this.m.a);
        com.uucun.adsdk.b.h.b("PackageName In Apk:", this.b);
        if (this.b == null || TextUtils.isEmpty(this.b.trim())) {
            if (this.m.a == null || TextUtils.isEmpty(this.m.a.trim())) {
                this.f.cancel(this.l);
                UUAppConnect.showToast("下载" + this.j + "文件出错,请重试.", this.e);
                com.uucun.adsdk.a.b.a().a(this, false);
                return;
            }
            this.b = this.m.a;
        }
        this.m.a = this.b;
        if ("0".equals(this.t) && com.uucun.adsdk.b.c.d(this.e, this.b)) {
            this.t = "1";
        }
        com.uucun.adsdk.b.a a2 = com.uucun.adsdk.b.a.a(this.e);
        a2.a(this.b + "_process_num", this.r);
        a2.a(this.b + "_from_" + this.r, this.s);
        a2.a(this.b + "_points", this.m.d);
        a2.a(this.b + "_adid", this.c);
        a2.a();
        com.uucun.adsdk.b.c.a(this.e, this.o.getPath());
        a(this.b);
        com.uucun.adsdk.a.b.a().a(this, true);
    }

    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void onProgressUpdate(Integer... numArr) {
        if (numArr[0].intValue() % 2 != 0) {
            return;
        }
        this.q.delete(0, this.q.length());
        this.q.append(numArr[0]).append("%").append(" 已下载.");
        a(this.q.toString(), numArr[0].intValue() >= 100);
    }

    public void b() {
        this.d = new Notification();
        this.d.icon = 17301633;
        this.p = PendingIntent.getActivity(this.e, 0, new Intent(), 134217728);
        this.d.setLatestEventInfo(this.e, this.j, "正在排队下载...", this.p);
        this.f.notify(this.l, this.d);
    }
}
