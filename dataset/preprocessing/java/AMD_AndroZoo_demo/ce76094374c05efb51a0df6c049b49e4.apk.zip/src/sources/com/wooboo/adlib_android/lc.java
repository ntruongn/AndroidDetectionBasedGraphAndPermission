package com.wooboo.adlib_android;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class lc implements Runnable {
    private static final String[] z = {z(z("$gQ\u0015\u001dY")), z(z("$gQ\u0015\u001dZ")), z(z("$gQ\u0015\u001d["))};
    final kc a;
    private final Context b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public lc(kc kcVar, Context context) {
        this.a = kcVar;
        this.b = context;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'h';
                    break;
                case 1:
                    c = '\b';
                    break;
                case 2:
                    c = '2';
                    break;
                case nb.p /* 3 */:
                    c = 't';
                    break;
                default:
                    c = 'q';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'q');
        }
        return charArray;
    }

    @Override // java.lang.Runnable
    public void run() {
        List<Address> list;
        System.out.println(z[0]);
        Location a = this.a.a(this.b);
        if (a != null) {
            double latitude = a.getLatitude();
            double longitude = a.getLongitude();
            sc.f(String.valueOf(latitude) + "," + longitude);
            try {
                list = new Geocoder(this.b, Locale.CHINA).getFromLocation(latitude, longitude, 1);
            } catch (IOException e) {
                list = null;
                System.out.println(z[2]);
                e.printStackTrace();
            }
            if (list != null) {
                try {
                    if (list.size() > 0) {
                        Address address = list.get(0);
                        sc.g(String.valueOf(address.getCountryName()) + "," + address.getLocality() + "," + address.getAdminArea() + "," + address.getThoroughfare() + "," + address.getFeatureName());
                        System.out.println(sc.f());
                    }
                } catch (IOException e2) {
                    throw e2;
                }
            }
            System.out.println(z[1]);
        }
    }
}
