package com.kuguo.c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.kuguo.ui.NavigationBar;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a {
    protected Context a;
    protected a b;
    private int c;
    private View d;
    private NavigationBar e;

    public a(Context context) {
        this(context, -1);
    }

    public a(Context context, int i) {
        this.a = context;
        this.c = i;
    }

    public View a() {
        if (this.d == null) {
            this.d = c();
            b();
        }
        return this.d;
    }

    protected void b() {
    }

    protected View c() {
        return this.c != -1 ? LayoutInflater.from(this.a).inflate(this.c, (ViewGroup) null) : new View(this.a);
    }

    public NavigationBar d() {
        if (this.e == null) {
            this.e = e();
        }
        return this.e;
    }

    protected NavigationBar e() {
        return new NavigationBar(this.a);
    }
}
