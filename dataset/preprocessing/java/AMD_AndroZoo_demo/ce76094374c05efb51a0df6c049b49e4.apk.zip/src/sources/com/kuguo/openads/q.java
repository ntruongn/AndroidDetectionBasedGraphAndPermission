package com.kuguo.openads;

import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class q implements Runnable {
    final /* synthetic */ Map a;
    final /* synthetic */ x b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public q(x xVar, Map map) {
        this.b = xVar;
        this.a = map;
    }

    @Override // java.lang.Runnable
    public void run() {
        d dVar;
        dVar = this.b.c;
        dVar.a(this.a);
    }
}
