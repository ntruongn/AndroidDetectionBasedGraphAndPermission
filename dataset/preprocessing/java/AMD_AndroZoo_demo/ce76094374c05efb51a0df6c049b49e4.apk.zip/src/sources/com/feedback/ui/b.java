package com.feedback.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import com.mobclick.android.UmengConstants;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class b extends BroadcastReceiver {
    final /* synthetic */ FeedbackConversation a;

    private b(FeedbackConversation feedbackConversation) {
        this.a = feedbackConversation;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ b(FeedbackConversation feedbackConversation, b bVar) {
        this(feedbackConversation);
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        com.feedback.a.d dVar;
        com.feedback.a.d dVar2;
        EditText editText;
        Button button;
        EditText editText2;
        Button button2;
        c cVar;
        com.feedback.a.d dVar3;
        c cVar2;
        String stringExtra = intent.getStringExtra(UmengConstants.AtomKey_FeedbackID);
        dVar = this.a.e;
        if (dVar.c.equalsIgnoreCase(stringExtra)) {
            this.a.e = com.feedback.b.c.b(this.a, stringExtra);
            cVar = this.a.f;
            dVar3 = this.a.e;
            cVar.a(dVar3);
            cVar2 = this.a.f;
            cVar2.notifyDataSetChanged();
        }
        dVar2 = this.a.e;
        if (dVar2.b != com.feedback.a.e.Normal) {
            editText2 = this.a.h;
            editText2.setEnabled(false);
            button2 = this.a.i;
            button2.setEnabled(false);
            return;
        }
        editText = this.a.h;
        editText.setEnabled(true);
        button = this.a.i;
        button.setEnabled(true);
    }
}
