package com.yong.pedometer;

import com.yong.pedometer.PaceNotifier;
import com.yong.pedometer.SpeakingTimer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class SpeedNotifier implements PaceNotifier.Listener, SpeakingTimer.Listener {
    float mDesiredSpeed;
    boolean mIsMetric;
    private Listener mListener;
    PedometerSettings mSettings;
    boolean mShouldTellFasterslower;
    boolean mShouldTellSpeed;
    float mStepLength;
    Utils mUtils;
    int mCounter = 0;
    float mSpeed = 0.0f;
    private long mSpokenAt = 0;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public interface Listener {
        void passValue();

        void valueChanged(float f);
    }

    public SpeedNotifier(Listener listener, PedometerSettings settings, Utils utils) {
        this.mListener = listener;
        this.mUtils = utils;
        this.mSettings = settings;
        this.mDesiredSpeed = this.mSettings.getDesiredSpeed();
        reloadSettings();
    }

    public void setSpeed(float speed) {
        this.mSpeed = speed;
        notifyListener();
    }

    public void reloadSettings() {
        this.mIsMetric = this.mSettings.isMetric();
        this.mStepLength = this.mSettings.getStepLength();
        this.mShouldTellSpeed = this.mSettings.shouldTellSpeed();
        this.mShouldTellFasterslower = this.mSettings.shouldTellFasterslower() && this.mSettings.getMaintainOption() == PedometerSettings.M_SPEED;
        notifyListener();
    }

    public void setDesiredSpeed(float desiredSpeed) {
        this.mDesiredSpeed = desiredSpeed;
    }

    private void notifyListener() {
        this.mListener.valueChanged(this.mSpeed);
    }

    @Override // com.yong.pedometer.PaceNotifier.Listener
    public void paceChanged(int value) {
        if (this.mIsMetric) {
            this.mSpeed = ((value * this.mStepLength) / 100000.0f) * 60.0f;
        } else {
            this.mSpeed = ((value * this.mStepLength) / 63360.0f) * 60.0f;
        }
        tellFasterSlower();
        notifyListener();
    }

    private void tellFasterSlower() {
        if (this.mShouldTellFasterslower && this.mUtils.isSpeakingEnabled()) {
            long now = System.currentTimeMillis();
            if (now - this.mSpokenAt > 3000 && !this.mUtils.isSpeakingNow()) {
                boolean spoken = true;
                if (this.mSpeed < this.mDesiredSpeed * (1.0f - 0.5f)) {
                    this.mUtils.say("much faster!");
                } else if (this.mSpeed > this.mDesiredSpeed * (1.0f + 0.5f)) {
                    this.mUtils.say("much slower!");
                } else if (this.mSpeed < this.mDesiredSpeed * (1.0f - 0.3f)) {
                    this.mUtils.say("faster!");
                } else if (this.mSpeed > this.mDesiredSpeed * (1.0f + 0.3f)) {
                    this.mUtils.say("slower!");
                } else if (this.mSpeed < this.mDesiredSpeed * (1.0f - 0.1f)) {
                    this.mUtils.say("a little faster!");
                } else if (this.mSpeed > this.mDesiredSpeed * (1.0f + 0.1f)) {
                    this.mUtils.say("a little slower!");
                } else {
                    spoken = false;
                }
                if (spoken) {
                    this.mSpokenAt = now;
                }
            }
        }
    }

    @Override // com.yong.pedometer.PaceNotifier.Listener
    public void passValue() {
    }

    @Override // com.yong.pedometer.SpeakingTimer.Listener
    public void speak() {
        if (this.mSettings.shouldTellSpeed() && this.mSpeed >= 0.01f) {
            this.mUtils.say(String.valueOf(new StringBuilder().append(this.mSpeed + 1.0E-6f).toString().substring(0, 4)) + (this.mIsMetric ? " kilometers per hour" : " miles per hour"));
        }
    }
}
