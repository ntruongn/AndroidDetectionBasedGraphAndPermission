package com.uucun.adsdk;

import android.content.Context;
import java.util.HashMap;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class e extends Thread {
    final /* synthetic */ Context a;
    final /* synthetic */ d b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(d dVar, Context context) {
        this.b = dVar;
        this.a = context;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        HashMap hashMap;
        hashMap = d.c;
        hashMap.put("area", com.uucun.adsdk.b.b.k(this.a));
        this.b.k(this.a);
        this.b.j(this.a);
    }
}
