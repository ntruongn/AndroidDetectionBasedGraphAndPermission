package com.wooboo.adlib_android;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class jb {
    public static final jb a = new jb(320, 50, 1);
    public static final jb b = new jb(300, 250, 5);
    public static final jb c = new jb(320, 480, 6);
    public static final jb d = new jb(320, 50, 7);
    private int e;
    private int f;
    private int g;

    private jb(int i, int i2) {
        this(i, i2, 1);
    }

    private jb(int i, int i2, int i3) {
        this.e = i;
        this.f = i2;
        this.g = i3;
    }

    public int a() {
        return this.e;
    }

    public int b() {
        return this.f;
    }

    public int c() {
        return this.g;
    }
}
