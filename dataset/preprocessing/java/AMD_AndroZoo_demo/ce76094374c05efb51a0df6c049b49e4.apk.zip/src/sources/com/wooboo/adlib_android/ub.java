package com.wooboo.adlib_android;

import android.view.animation.AlphaAnimation;
import android.view.animation.DecelerateInterpolator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
final class ub implements Runnable {
    private n a;
    private n b;
    final FullAdView c;

    public ub(FullAdView fullAdView, n nVar) {
        this.c = fullAdView;
        this.a = nVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static n a(ub ubVar) {
        return ubVar.b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(ub ubVar, n nVar) {
        ubVar.b = nVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static n b(ub ubVar) {
        return ubVar.a;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static FullAdView c(ub ubVar) {
        return ubVar.c;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.b = FullAdView.a;
        if (this.b != null) {
            this.b.setVisibility(8);
            this.b.h();
        }
        this.a.setVisibility(0);
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(700L);
        alphaAnimation.setFillAfter(true);
        alphaAnimation.setInterpolator(new DecelerateInterpolator());
        alphaAnimation.setAnimationListener(new vb(this));
        this.c.startAnimation(alphaAnimation);
    }
}
