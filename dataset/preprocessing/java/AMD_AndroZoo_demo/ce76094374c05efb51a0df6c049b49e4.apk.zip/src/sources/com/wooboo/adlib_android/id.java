package com.wooboo.adlib_android;

import android.app.AlertDialog;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class id extends Thread {
    private static final String[] z = {z(z("乆欽凣讍")), z(z("掝礦")), z(z("*y\u001aY:=x\u000f\r*\u0018n\u0002Y),u\u0002\u001c+l")), z(z("厜玬旞爱杣輢仪B乃逰儀宕被奈赪ａ诫儦匁輲职牔杂凴密袈")), z(z("8l\n\u0018;(I\u001c\u0015u")), z(z("乆轡旞爱"))};

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'M';
                    break;
                case 1:
                    c = 28;
                    break;
                case 2:
                    c = 'n';
                    break;
                case nb.p /* 3 */:
                    c = 'y';
                    break;
                default:
                    c = 'O';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'O');
        }
        return charArray;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        try {
            String h = sc.h(1);
            if (kb.c(h)) {
                return;
            }
            mc.b(z[4] + h);
            AlertDialog.Builder builder = new AlertDialog.Builder(ImpressionAdView.m());
            builder.setTitle(z[1]).setMessage(z[3]);
            builder.setPositiveButton(z[5], new cc(this, h));
            builder.setNegativeButton(z[0], new dc(this));
            Message message = new Message();
            message.what = 2;
            message.obj = builder;
            ImpressionAdView.w.sendMessage(message);
        } catch (Exception e) {
            mc.c(z[2]);
        }
    }
}
