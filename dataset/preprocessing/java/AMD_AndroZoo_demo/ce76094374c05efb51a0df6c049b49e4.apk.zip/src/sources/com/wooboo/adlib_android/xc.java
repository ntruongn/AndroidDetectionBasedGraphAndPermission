package com.wooboo.adlib_android;

import android.widget.RelativeLayout;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class xc extends Thread {
    private static final String z = z(z("aXhiRjXZ]Tk\u007fe[^u\u001dy]IiO="));
    final n a;
    private final String b;
    private final RelativeLayout c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public xc(n nVar, String str, RelativeLayout relativeLayout) {
        this.a = nVar;
        this.b = str;
        this.c = relativeLayout;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static n a(xc xcVar) {
        return xcVar.a;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 6;
                    break;
                case 1:
                    c = '=';
                    break;
                case 2:
                    c = 28;
                    break;
                case nb.p /* 3 */:
                    c = '/';
                    break;
                default:
                    c = ';';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ ';');
        }
        return charArray;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        try {
            kb.a(n.b(this.a), this.b);
            n.a(this.a, new h(this.a.getContext(), new bb(this), this.b));
            this.c.addView(n.c(this.a));
        } catch (Exception e) {
            mc.b(z);
        }
    }
}
