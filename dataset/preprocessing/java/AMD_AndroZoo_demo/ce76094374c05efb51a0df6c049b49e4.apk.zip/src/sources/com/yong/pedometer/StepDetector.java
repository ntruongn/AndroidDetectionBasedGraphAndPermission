package com.yong.pedometer;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class StepDetector implements SensorEventListener {
    private static final String TAG = "StepDetector";
    private float mLimit = 10.0f;
    private float[] mLastValues = new float[6];
    private float[] mScale = new float[2];
    private float[] mLastDirections = new float[6];
    private float[][] mLastExtremes = {new float[6], new float[6]};
    private float[] mLastDiff = new float[6];
    private int mLastMatch = -1;
    private ArrayList<StepListener> mStepListeners = new ArrayList<>();
    private float mYOffset = 480 * 0.5f;

    public StepDetector() {
        this.mScale[0] = -(480 * 0.5f * 0.05098581f);
        this.mScale[1] = -(480 * 0.5f * 0.016666668f);
    }

    public void setSensitivity(float sensitivity) {
        this.mLimit = sensitivity;
    }

    public void addStepListener(StepListener sl) {
        this.mStepListeners.add(sl);
    }

    @Override // android.hardware.SensorEventListener
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;
        synchronized (this) {
            if (sensor.getType() != 3) {
                int j = sensor.getType() == 1 ? 1 : 0;
                if (j == 1) {
                    float vSum = 0.0f;
                    for (int i = 0; i < 3; i++) {
                        vSum += this.mYOffset + (event.values[i] * this.mScale[j]);
                    }
                    float v = vSum / 3.0f;
                    float direction = v > this.mLastValues[0] ? 1 : v < this.mLastValues[0] ? -1 : 0;
                    if (direction == (-this.mLastDirections[0])) {
                        int extType = direction > 0.0f ? 0 : 1;
                        this.mLastExtremes[extType][0] = this.mLastValues[0];
                        float diff = Math.abs(this.mLastExtremes[extType][0] - this.mLastExtremes[1 - extType][0]);
                        if (diff > this.mLimit) {
                            boolean isAlmostAsLargeAsPrevious = diff > (this.mLastDiff[0] * 2.0f) / 3.0f;
                            boolean isPreviousLargeEnough = this.mLastDiff[0] > diff / 3.0f;
                            boolean isNotContra = this.mLastMatch != 1 - extType;
                            if (isAlmostAsLargeAsPrevious && isPreviousLargeEnough && isNotContra) {
                                Log.i(TAG, "step");
                                Iterator<StepListener> it = this.mStepListeners.iterator();
                                while (it.hasNext()) {
                                    StepListener stepListener = it.next();
                                    stepListener.onStep();
                                }
                                this.mLastMatch = extType;
                            } else {
                                this.mLastMatch = -1;
                            }
                        }
                        this.mLastDiff[0] = diff;
                    }
                    this.mLastDirections[0] = direction;
                    this.mLastValues[0] = v;
                }
            }
        }
    }

    @Override // android.hardware.SensorEventListener
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}
