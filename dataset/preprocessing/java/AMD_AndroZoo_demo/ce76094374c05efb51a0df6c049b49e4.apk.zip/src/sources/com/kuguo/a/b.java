package com.kuguo.a;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.mobclick.android.UmengConstants;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class b {
    private a a;

    public b(Context context) {
        this.a = new a(context);
    }

    public List a() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = this.a.getReadableDatabase();
        Cursor query = readableDatabase.query("downloads", null, null, null, null, null, null);
        while (query.moveToNext()) {
            e eVar = new e();
            eVar.a = query.getString(query.getColumnIndex("url"));
            eVar.b = query.getString(query.getColumnIndex("file"));
            eVar.c = query.getInt(query.getColumnIndex("size"));
            eVar.d = query.getInt(query.getColumnIndex("total_size"));
            eVar.e = query.getInt(query.getColumnIndex(UmengConstants.AtomKey_State));
            arrayList.add(eVar);
        }
        query.close();
        readableDatabase.close();
        return arrayList;
    }

    public void a(e eVar) {
        SQLiteDatabase writableDatabase = this.a.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("url", eVar.a);
        contentValues.put("file", eVar.b);
        contentValues.put("size", Integer.valueOf(eVar.c));
        contentValues.put("total_size", Integer.valueOf(eVar.d));
        contentValues.put(UmengConstants.AtomKey_State, Integer.valueOf(eVar.e));
        writableDatabase.insert("downloads", null, contentValues);
        writableDatabase.close();
    }

    public void b(e eVar) {
        SQLiteDatabase writableDatabase = this.a.getWritableDatabase();
        writableDatabase.delete("downloads", "url = ? and file = ?", new String[]{eVar.a, eVar.b});
        writableDatabase.close();
    }

    public void c(e eVar) {
        SQLiteDatabase writableDatabase = this.a.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("url", eVar.a);
        contentValues.put("file", eVar.b);
        contentValues.put("size", Integer.valueOf(eVar.c));
        contentValues.put("total_size", Integer.valueOf(eVar.d));
        contentValues.put(UmengConstants.AtomKey_State, Integer.valueOf(eVar.e));
        writableDatabase.update("downloads", contentValues, "url = ? and file = ?", new String[]{eVar.a, eVar.b});
        writableDatabase.close();
    }
}
