package com.uucun.adsdk.a;

import android.text.TextUtils;
import com.uucun.adsdk.d.e;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class a {
    public static boolean a = false;
    public static a b = null;
    public StringBuffer c = new StringBuffer();
    public ArrayList d;
    private ConcurrentHashMap e;

    private a() {
        this.e = null;
        this.d = null;
        this.e = new ConcurrentHashMap();
        this.d = new ArrayList();
    }

    public static a a() {
        if (b == null) {
            b = new a();
        }
        return b;
    }

    public e a(int i) {
        if (i == -1 || i >= this.d.size()) {
            return null;
        }
        return (e) this.e.get((String) this.d.get(i));
    }

    public void a(e eVar) {
        if (eVar == null || TextUtils.isEmpty(eVar.c.trim())) {
            return;
        }
        if (this.c.length() != 0) {
            this.c.append(",");
        }
        String str = eVar.c;
        this.d.add(str);
        this.c.append(str);
        this.e.put(eVar.c, eVar);
    }

    public void a(String str) {
        e eVar;
        if (str == null || (eVar = (e) this.e.get(str)) == null) {
            return;
        }
        eVar.h = "1";
    }

    public void b() {
        int e = e();
        for (int i = 0; i < e; i++) {
            e a2 = a(i);
            if (a2 != null && a2.d != null && a2.d.isRecycled()) {
                a2.d.recycle();
                a2.d = null;
            }
        }
        this.d.clear();
        this.e.clear();
        this.c.delete(0, this.c.length());
    }

    public boolean c() {
        return this.d.isEmpty();
    }

    public String d() {
        return this.c.toString();
    }

    public int e() {
        return this.d.size();
    }
}
