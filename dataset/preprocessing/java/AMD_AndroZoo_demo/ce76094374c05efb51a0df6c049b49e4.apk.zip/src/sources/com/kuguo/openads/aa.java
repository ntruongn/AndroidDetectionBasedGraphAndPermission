package com.kuguo.openads;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class aa extends com.kuguo.b.h {
    final /* synthetic */ k a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public aa(k kVar, String str) {
        super("http://www.cooguo.com/gw/ads.action");
        String str2;
        String str3;
        String str4;
        String str5;
        this.a = kVar;
        str2 = kVar.g;
        a("cooId", str2);
        str3 = kVar.h;
        a("channelId", str3);
        str4 = kVar.e;
        a("imei", str4);
        str5 = kVar.f;
        a("imsi", str5);
        a("protocol", 1);
        a("method", str);
    }
}
