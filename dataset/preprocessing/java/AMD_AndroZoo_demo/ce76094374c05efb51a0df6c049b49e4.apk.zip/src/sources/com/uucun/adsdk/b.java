package com.uucun.adsdk;

import android.content.Context;
import android.text.TextUtils;
import com.uucun.adsdk.b.g;
import com.uucun.adsdk.b.h;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class b extends Thread {
    final /* synthetic */ d a;
    private Context b;
    private boolean c = true;

    public b(d dVar, Context context) {
        this.a = dVar;
        this.b = context;
    }

    public void a() {
        this.c = false;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        String str;
        g gVar = new g(this.b);
        while (this.c) {
            String a = gVar.a();
            if (!TextUtils.isEmpty(a)) {
                str = d.a;
                h.b(str, "捕捉到得异常:\n  " + a);
                this.a.b(this.b, a);
                return;
            } else {
                try {
                    sleep(200L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        gVar.b();
    }
}
