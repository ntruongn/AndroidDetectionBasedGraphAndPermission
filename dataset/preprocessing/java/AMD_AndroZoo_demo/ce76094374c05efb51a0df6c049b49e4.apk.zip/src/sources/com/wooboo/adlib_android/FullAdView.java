package com.wooboo.adlib_android;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.widget.RelativeLayout;
import java.text.SimpleDateFormat;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class FullAdView extends RelativeLayout implements qb {
    protected static n a = null;
    private static final int b = 700;
    private static int c;
    private static int j;
    private static double k;
    private static jb l;
    private int d;
    private int e;
    private boolean f;
    private AdListener g;
    private boolean h;
    Handler m;
    private static final String[] z = {z(z("丂輹旅牲")), z(z("变珴旅牲朽车亲Y一遮兄寍袰夋贴％讳儽卂转耈爌杙冷官裌")), z(z("丂步凸诎")), z(z("|4\u0011[el\u0011\u0007V+")), z(z("P+\u0000\u001ayh2\u0010\u001abl0U[uzd\u0003St~d\u001cTg`7\u001cX}ljU\u001aHf1UWdz0UYpe(U[uzd\u0003St~j\u0006_e_-\u0006Ss`(\u001cNh!\u0012\u001c_f'\u0012<iXK\b0\u0013?")), z(z("n!\u0001\u001ady \u0014Nt\\6\u0019\u001awh-\u0019_u(")), z(z("揙祾")), z(z("p=\fC<D\tX^u")), z(z("h(\u0010He]-\u0018_")), z(z("}!\u0006Nxg#")), z(z("k%\u0016Qv{+\u0000TuJ+\u0019Uc")), z(z("}!\rNRf(\u001aH")), z(z("a0\u0001J+&k\u0006Yyl)\u0014I?h*\u0011H~` [Y~dk\u0014Jz&6\u0010I>"))};
    private static Handler i = new Handler();

    public FullAdView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public FullAdView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.m = new c(this);
        this.h = false;
        setFocusable(true);
        setDescendantFocusability(262144);
        setClickable(true);
        if (attributeSet != null) {
            String str = z[12] + context.getPackageName();
            setAdUnit(jb.c);
            boolean attributeBooleanValue = attributeSet.getAttributeBooleanValue(str, z[9], false);
            if (attributeBooleanValue) {
                sc.a(attributeBooleanValue);
            }
            int attributeUnsignedIntValue = attributeSet.getAttributeUnsignedIntValue(str, z[11], -1);
            int attributeUnsignedIntValue2 = attributeSet.getAttributeUnsignedIntValue(str, z[10], 0);
            a(true);
            b(attributeUnsignedIntValue);
            setBackgroundColor(attributeUnsignedIntValue2);
            sc.g(context, sc.f(context));
            a(context);
        }
    }

    protected FullAdView(Context context, AttributeSet attributeSet, int i2, jb jbVar) {
        super(context, attributeSet, i2);
        this.m = new c(this);
        this.h = false;
        setFocusable(true);
        setDescendantFocusability(262144);
        setClickable(true);
        if (attributeSet != null) {
            String str = z[12] + context.getPackageName();
            setAdUnit(jbVar);
            boolean attributeBooleanValue = attributeSet.getAttributeBooleanValue(str, z[9], false);
            if (attributeBooleanValue) {
                sc.a(attributeBooleanValue);
            }
            int attributeUnsignedIntValue = attributeSet.getAttributeUnsignedIntValue(str, z[11], -1);
            int attributeUnsignedIntValue2 = attributeSet.getAttributeUnsignedIntValue(str, z[10], 0);
            a(true);
            b(attributeUnsignedIntValue);
            setBackgroundColor(attributeUnsignedIntValue2);
            a(context);
            sc.g(context, sc.f(context));
        }
    }

    public FullAdView(Context context, AttributeSet attributeSet, jb jbVar) {
        this(context, attributeSet, 0, jbVar);
    }

    protected FullAdView(Context context, jb jbVar, boolean z2, int[] iArr) {
        super(context, null, 0);
        this.m = new c(this);
        this.h = false;
        setFocusable(true);
        setDescendantFocusability(262144);
        setClickable(true);
        if (z2) {
            sc.a(z2);
        }
        b(this.e);
        setBackgroundColor(this.d);
        setAdUnit(jbVar);
        a(true);
        sc.g(context, sc.f(context));
        sc.a(iArr);
        a(context);
    }

    protected FullAdView(Context context, String str, jb jbVar, boolean z2, int[] iArr) {
        super(context, null, 0);
        this.m = new c(this);
        this.h = false;
        setFocusable(true);
        setDescendantFocusability(262144);
        setClickable(true);
        if (z2) {
            sc.a(z2);
        }
        b(this.e);
        setBackgroundColor(this.d);
        setAdUnit(jbVar);
        a(true);
        sc.g(context, str);
        sc.a(iArr);
        a(context);
    }

    public FullAdView(Context context, String str, boolean z2, int[] iArr) {
        super(context, null, 0);
        this.m = new c(this);
        this.h = false;
        setFocusable(true);
        setDescendantFocusability(262144);
        setClickable(true);
        if (z2) {
            sc.a(z2);
        }
        setAdUnit(jb.c);
        a(true);
        sc.g(context, str);
        sc.a(iArr);
        a(context);
    }

    public FullAdView(Context context, boolean z2, int[] iArr) {
        super(context, null, 0);
        this.m = new c(this);
        this.h = false;
        setFocusable(true);
        setDescendantFocusability(262144);
        setClickable(true);
        if (z2) {
            sc.a(z2);
        }
        setAdUnit(jb.c);
        a(true);
        sc.g(context, sc.f(context));
        sc.a(iArr);
        a(context);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static double a() {
        return k;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static AdListener a(FullAdView fullAdView) {
        return fullAdView.g;
    }

    protected static void a(double d) {
        k = d;
    }

    protected static void a(int i2) {
        j = i2;
    }

    private void a(Context context) {
        double d = getResources().getDisplayMetrics().density;
        a(d);
        sc.e(getAdUnit().c());
        a((int) (d * getAdUnit().b()));
        sc.g(context);
        sc.k(sc.k(context));
        sc.l(sc.l(context));
        String i2 = sc.i(context);
        sc.c(sc.o(context));
        sc.i(i2);
        sc.h(context.getPackageName());
        sc.g(qc.a(context).a(Build.MODEL));
        int e = sc.e(context);
        if (e < 200 || e > 300) {
            sc.n = true;
        } else {
            sc.n = false;
        }
        sc.f(e);
        if (sc.l() || (sc.a(context, false) != null && sc.d(context))) {
            c();
        }
    }

    private void a(n nVar) {
        if (a != null) {
            a.h();
        }
        a = nVar;
        if (this.h) {
            AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
            alphaAnimation.setDuration(233L);
            alphaAnimation.startNow();
            alphaAnimation.setFillAfter(true);
            alphaAnimation.setInterpolator(new AccelerateInterpolator());
            startAnimation(alphaAnimation);
        }
    }

    protected static int b() {
        return j;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void b(FullAdView fullAdView) {
        fullAdView.d();
    }

    private void b(n nVar) {
        nVar.setVisibility(8);
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
        alphaAnimation.setDuration(700L);
        alphaAnimation.setFillAfter(true);
        alphaAnimation.setInterpolator(new AccelerateInterpolator());
        alphaAnimation.setAnimationListener(new tb(this, nVar));
        startAnimation(alphaAnimation);
    }

    private void d() {
        new fd(this).start();
    }

    public static jb getAdUnit() {
        return l;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int i() {
        return j;
    }

    public static void setAdUnit(jb jbVar) {
        l = jbVar;
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i2 = 0; length > i2; i2++) {
            char c3 = cArr[i2];
            switch (i2 % 5) {
                case 0:
                    c2 = '\t';
                    break;
                case 1:
                    c2 = 'D';
                    break;
                case 2:
                    c2 = 'u';
                    break;
                case nb.p /* 3 */:
                    c2 = ':';
                    break;
                default:
                    c2 = 17;
                    break;
            }
            cArr[i2] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 17);
        }
        return charArray;
    }

    protected void a(boolean z2) {
        this.f = z2;
    }

    protected void b(int i2) {
        this.e = (-16777216) | i2;
        if (a != null) {
            a.a(i2);
        }
        invalidate();
    }

    protected void c() {
        boolean z2 = true;
        boolean z3 = sc.C;
        try {
            if (super.getVisibility() != 0) {
                mc.b(z[4]);
                if (!z3) {
                    return;
                }
            }
            try {
                if (!sc.l()) {
                    pc a2 = pc.a(getContext(), (String) null);
                    String i2 = a2.i(z[8]);
                    String format = new SimpleDateFormat(z[7]).format(new Date());
                    if (i2 != null) {
                        try {
                            if (format.equalsIgnoreCase(i2)) {
                                z2 = false;
                            } else if (z3) {
                            }
                        } catch (Exception e) {
                            throw e;
                        }
                    }
                    if (z2) {
                        a2.d(z[8], format);
                        String h = sc.h(1);
                        if (kb.c(h)) {
                            return;
                        }
                        mc.b(z[3] + h);
                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                        builder.setTitle(z[6]).setMessage(z[1]).setCancelable(false);
                        builder.setPositiveButton(z[0], new rb(this, h));
                        builder.setNegativeButton(z[2], new sb(this));
                        Message message = new Message();
                        try {
                            message.what = 2;
                            message.obj = builder;
                            this.m.sendMessage(message);
                            if (!z3) {
                                return;
                            }
                        } catch (Exception e2) {
                            throw e2;
                        }
                    }
                    d();
                    if (!z3) {
                        return;
                    }
                }
                d();
            } catch (Exception e3) {
                mc.c(z[5]);
            }
        } catch (Exception e4) {
            throw e4;
        }
    }

    public void close() {
        setVisibility(8);
    }

    @Override // com.wooboo.adlib_android.qb
    public void closeAd() {
        setVisibility(8);
    }

    protected int e() {
        return c;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int f() {
        return this.e;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int g() {
        return this.d;
    }

    @Override // android.view.View
    public int getVisibility() {
        if (!this.f || hasAd()) {
            return super.getVisibility();
        }
        return 8;
    }

    protected boolean h() {
        return this.f;
    }

    public boolean hasAd() {
        return a != null;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        this.h = true;
        super.onAttachedToWindow();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.h = false;
    }

    public void setAdListener(AdListener adListener) {
        synchronized (this) {
            this.g = adListener;
        }
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        this.d = (-16777216) | i2;
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        if (super.getVisibility() != i2) {
            synchronized (this) {
                int childCount = getChildCount();
                for (int i3 = 0; i3 < childCount; i3++) {
                    getChildAt(i3).setVisibility(i2);
                }
                super.setVisibility(i2);
            }
        }
    }
}
