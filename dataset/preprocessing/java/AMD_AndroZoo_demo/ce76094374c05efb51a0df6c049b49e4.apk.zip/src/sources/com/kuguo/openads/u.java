package com.kuguo.openads;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.StateListDrawable;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.kuguo.ui.NavigationBar;
import com.mobclick.android.UmengConstants;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class u extends com.kuguo.c.a implements View.OnClickListener, AdapterView.OnItemClickListener, com.kuguo.b.c, a, z {
    private ListView c;
    private k d;
    private com.kuguo.b.d e;
    private Handler f;
    private int g;
    private int h;
    private boolean i;
    private o j;

    public u(Context context, int i) {
        super(context);
        this.h = i;
        this.d = k.a(context);
        this.e = new com.kuguo.b.d();
        this.f = new Handler();
        this.d.a((z) this);
        this.d.a((a) this);
        this.g = -1;
        this.i = false;
    }

    private String a(DataInputStream dataInputStream) {
        return new String(com.kuguo.d.d.a(dataInputStream, dataInputStream.readInt()), "utf-8");
    }

    private void a(int i, int i2, int i3, List list, List list2, int i4) {
        boolean z;
        FileOutputStream fileOutputStream = null;
        try {
            try {
                fileOutputStream = this.a.openFileOutput("local_applist", 2);
                DataOutputStream dataOutputStream = new DataOutputStream(fileOutputStream);
                dataOutputStream.writeInt(i);
                dataOutputStream.writeInt(i2);
                dataOutputStream.writeInt(i3);
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    g gVar = (g) it.next();
                    dataOutputStream.writeInt(gVar.i);
                    dataOutputStream.writeInt(gVar.d);
                    dataOutputStream.writeInt(gVar.h);
                    dataOutputStream.writeInt(gVar.g);
                    a(dataOutputStream, gVar.f);
                    a(dataOutputStream, gVar.j);
                    a(dataOutputStream, gVar.b);
                    a(dataOutputStream, gVar.c);
                    a(dataOutputStream, gVar.k);
                }
                Iterator it2 = list2.iterator();
                while (it2.hasNext()) {
                    byte[] bArr = (byte[]) it2.next();
                    dataOutputStream.writeInt(bArr.length);
                    dataOutputStream.write(bArr);
                }
                com.kuguo.d.d.a(fileOutputStream);
                z = false;
            } catch (Exception e) {
                e.printStackTrace();
                z = true;
                com.kuguo.d.d.a(fileOutputStream);
            }
            if (z) {
                com.kuguo.d.a.a("cache applist failed !");
                this.a.deleteFile("local_applist");
            } else {
                com.kuguo.d.a.a("cache applist success !");
                this.d.c(i4);
            }
        } catch (Throwable th) {
            com.kuguo.d.d.a(fileOutputStream);
            throw th;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x008f A[Catch: Exception -> 0x0104, all -> 0x019b, TryCatch #6 {all -> 0x019b, blocks: (B:3:0x0001, B:10:0x006b, B:12:0x008f, B:14:0x00e8, B:17:0x00fc, B:20:0x010f, B:22:0x011e, B:24:0x0135, B:28:0x016f, B:29:0x013d, B:33:0x0183, B:53:0x0105), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x011e A[Catch: Exception -> 0x0104, all -> 0x019b, TryCatch #6 {all -> 0x019b, blocks: (B:3:0x0001, B:10:0x006b, B:12:0x008f, B:14:0x00e8, B:17:0x00fc, B:20:0x010f, B:22:0x011e, B:24:0x0135, B:28:0x016f, B:29:0x013d, B:33:0x0183, B:53:0x0105), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0183 A[Catch: Exception -> 0x0104, all -> 0x019b, TRY_LEAVE, TryCatch #6 {all -> 0x019b, blocks: (B:3:0x0001, B:10:0x006b, B:12:0x008f, B:14:0x00e8, B:17:0x00fc, B:20:0x010f, B:22:0x011e, B:24:0x0135, B:28:0x016f, B:29:0x013d, B:33:0x0183, B:53:0x0105), top: B:2:0x0001 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void a(com.kuguo.b.b r22) {
        /*
            Method dump skipped, instructions count: 445
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.kuguo.openads.u.a(com.kuguo.b.b):void");
    }

    private void a(DataOutputStream dataOutputStream, String str) {
        byte[] bytes = str.getBytes("utf-8");
        dataOutputStream.writeInt(bytes.length);
        dataOutputStream.write(bytes);
    }

    private boolean a(g gVar) {
        if (gVar.l == 4) {
            return true;
        }
        return gVar.d == 0 && !this.d.c(gVar).exists();
    }

    private void h() {
        if (this.j == null) {
            this.j = new o(this, this.a, "正在加载中");
            this.j.setTextSize(18.0f);
            this.j.setTextColor(-16777216);
            this.j.setBackgroundColor(0);
            Paint paint = new Paint(1);
            paint.setTextSize(TypedValue.applyDimension(2, 18.0f, this.a.getResources().getDisplayMetrics()));
            this.j.setMinimumWidth((int) paint.measureText("正在加载中..."));
        }
        WindowManager windowManager = (WindowManager) this.a.getSystemService("window");
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.gravity = 17;
        layoutParams.format = -2;
        layoutParams.flags = 8;
        windowManager.addView(this.j, layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void i() {
        if (this.j != null) {
            ((WindowManager) this.a.getSystemService("window")).removeView(this.j);
            this.j = null;
        }
    }

    private void j() {
        this.f.post(new l(this));
    }

    private void k() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this.a);
        builder.setTitle("酷果应用列表");
        builder.setMessage("对不起，暂时无法加载该页面，请重试。");
        builder.setPositiveButton("重试", new j(this));
        builder.setNegativeButton("取消", new i(this));
        this.f.post(new h(this, builder));
    }

    @Override // com.kuguo.openads.a
    public void a(int i) {
    }

    @Override // com.kuguo.b.c
    public void a(com.kuguo.b.b bVar, int i) {
        switch (i) {
            case -4:
            case -2:
            case UmengConstants.RetrieveReplyBroadcast_Fail /* -1 */:
                return;
            case -3:
                Exception i2 = bVar.i();
                if (i2 != null) {
                    i2.printStackTrace();
                    k();
                    return;
                }
                return;
            case 200:
                a(bVar);
                return;
            default:
                bVar.b();
                return;
        }
    }

    public void a(String str) {
        if (str == null) {
            d().findViewById(101).setVisibility(8);
            d().findViewById(102).setVisibility(8);
        } else {
            d().findViewById(101).setVisibility(0);
            d().findViewById(102).setVisibility(8);
            ((TextView) d().findViewById(101)).setText(str);
        }
    }

    @Override // com.kuguo.openads.a
    public void a(String str, int i) {
        if (this.g != -1) {
            this.g += i;
            b(this.g);
        }
    }

    @Override // com.kuguo.openads.z
    public void a(List list) {
        j();
    }

    public void a(boolean z) {
        this.i = z;
    }

    @Override // com.kuguo.c.a
    protected void b() {
        this.c.setAdapter((ListAdapter) new y(this.a));
        h();
        g();
    }

    public void b(int i) {
        this.g = i;
        if (i == -1) {
            d().findViewById(101).setVisibility(8);
            d().findViewById(102).setVisibility(8);
        } else {
            d().findViewById(101).setVisibility(0);
            d().findViewById(102).setVisibility(0);
            ((TextView) d().findViewById(101)).setText(i + "");
        }
    }

    @Override // com.kuguo.c.a
    protected View c() {
        this.c = new ListView(this.a);
        this.c.setCacheColorHint(0);
        this.c.setOnItemClickListener(this);
        return this.c;
    }

    @Override // com.kuguo.c.a
    public NavigationBar e() {
        NavigationBar navigationBar = new NavigationBar(this.a);
        if (this.i) {
            Button button = new Button(this.a);
            navigationBar.b(button);
            button.setOnClickListener(new c(this));
            StateListDrawable stateListDrawable = new StateListDrawable();
            stateListDrawable.addState(new int[]{16842919}, com.kuguo.d.e.b(this.a, "ads/wait_download_btn_pressed.png"));
            stateListDrawable.addState(new int[]{16842910}, com.kuguo.d.e.b(this.a, "ads/wait_download_btn.png"));
            button.setBackgroundDrawable(stateListDrawable);
        }
        Button button2 = new Button(this.a);
        button2.setOnClickListener(this);
        navigationBar.d(button2);
        StateListDrawable stateListDrawable2 = new StateListDrawable();
        stateListDrawable2.addState(new int[]{16842919}, com.kuguo.d.e.b(this.a, "ads/download_btn_pressed.png"));
        stateListDrawable2.addState(new int[]{16842910}, com.kuguo.d.e.b(this.a, "ads/download_btn.png"));
        button2.setBackgroundDrawable(stateListDrawable2);
        LinearLayout linearLayout = new LinearLayout(this.a);
        linearLayout.setOrientation(0);
        ImageView imageView = new ImageView(this.a);
        imageView.setId(102);
        imageView.setImageDrawable(com.kuguo.d.e.b(this.a, "ads/money.png"));
        linearLayout.addView(imageView, -2, -1);
        imageView.setVisibility(8);
        TextView textView = new TextView(this.a);
        textView.setId(101);
        textView.setText("250");
        textView.setTextSize(17.0f);
        textView.setTextColor(-256);
        textView.setGravity(17);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(com.kuguo.d.c.a(this.a, 200), -1);
        layoutParams.leftMargin = 2;
        linearLayout.addView(textView, layoutParams);
        textView.setVisibility(8);
        navigationBar.c(linearLayout);
        navigationBar.setBackgroundColor(Color.parseColor("#5297be"));
        return navigationBar;
    }

    public void f() {
        this.d.b((z) this);
        this.d.b((a) this);
        i();
        this.e.a();
    }

    public void g() {
        com.kuguo.b.h a = this.d.a("showOffers");
        a.a(UmengConstants.AtomKey_Type, Integer.valueOf(this.h));
        a.a("page", "1");
        com.kuguo.b.a aVar = new com.kuguo.b.a(this.a, a);
        aVar.a(20.0f);
        aVar.a(this);
        this.e.a(aVar);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        for (g gVar : ((y) this.c.getAdapter()).c()) {
            if (gVar.a) {
                this.d.a(gVar);
            }
        }
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        y yVar = (y) adapterView.getAdapter();
        g gVar = (g) yVar.getItem(i);
        if (gVar.l == 2) {
            this.d.a(this.d.c(gVar), gVar);
            return;
        }
        x xVar = new x(this.a, gVar);
        if (yVar.b()) {
            xVar.a("送" + ((int) (gVar.m * gVar.d)) + yVar.a());
        }
        ((com.kuguo.c.b) this.b).a(xVar);
    }
}
