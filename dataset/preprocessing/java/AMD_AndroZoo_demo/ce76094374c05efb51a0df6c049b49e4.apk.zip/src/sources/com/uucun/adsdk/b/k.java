package com.uucun.adsdk.b;

import java.net.MalformedURLException;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class k {
    public static String a = k.class.getSimpleName();
    private static k K = null;
    private String p = "http://cloud2.devopenserv.com";
    private String q = "http://dp2.devopenserv.com";
    private String r = "http://ck2.devopenserv.com";
    private String s = "http://dp3.devopenserv.com";
    private String t = "http://cloud2.devopenserv.com";
    private String u = "http://dp2.devopenserv.com";
    private String v = "http://ck2.devopenserv.com";
    private String w = "http://dp3.devopenserv.com";
    private String x = "/integral";
    private String y = "/integral";
    private String z = "/advDisplay";
    private String A = "/advDisplayCount";
    private String B = "/advDownload";
    private String C = "/advInstall";
    private String D = "/advStart";
    private String E = "/collectAppInfo";
    private String F = "/collectAppInfo";
    private String G = "/collectAppInfo";
    private String H = "/collectAppInfo";
    private String I = "/offerwallList";
    private String J = "/appUpdate";
    public String b = null;
    public String c = null;
    public String d = null;
    public String e = null;
    public String f = null;
    public String g = null;
    public String h = null;
    public String i = null;
    public String j = null;
    public String k = null;
    public String l = null;
    public String m = null;
    public String n = null;
    public String o = null;
    private boolean L = false;

    public k() {
        c();
    }

    public static k a() {
        if (K == null) {
            K = new k();
        }
        return K;
    }

    private StringBuffer a(URL url) {
        String path = url.getPath();
        String query = url.getQuery();
        StringBuffer stringBuffer = new StringBuffer();
        String host = url.getHost();
        String str = null;
        if (host.contains("cloud2")) {
            str = this.t;
        } else if (host.contains("dp2")) {
            str = this.u;
        } else if (host.contains("ck2")) {
            str = this.v;
        } else if (host.contains("dp3")) {
            str = this.w;
        }
        if (str == null) {
            return stringBuffer.append(url.toString());
        }
        stringBuffer.append(str);
        if (path != null) {
            stringBuffer.append(path);
        }
        if (query == null) {
            return stringBuffer;
        }
        stringBuffer.append("?");
        stringBuffer.append(query);
        return stringBuffer;
    }

    private void c() {
        this.b = this.s + this.I;
        this.c = this.p + this.F;
        this.d = this.p + this.x;
        this.e = this.p + this.y;
        this.f = this.p + this.E;
        this.g = this.p + this.G;
        this.h = this.p + this.J;
        this.o = this.p + this.H;
        this.i = this.q + this.z;
        this.j = this.q + this.A;
        this.k = this.q + this.A;
        this.l = this.r + this.B;
        this.m = this.r + this.D;
        this.n = this.r + this.C;
    }

    private void d() {
        this.b = this.w + this.I;
        this.c = this.t + this.F;
        this.d = this.t + this.x;
        this.e = this.t + this.y;
        this.f = this.t + this.E;
        this.g = this.t + this.G;
        this.h = this.t + this.J;
        this.o = this.t + this.H;
        this.i = this.u + this.z;
        this.j = this.u + this.A;
        this.k = this.u + this.A;
        this.l = this.v + this.B;
        this.m = this.v + this.D;
        this.n = this.v + this.C;
    }

    public synchronized String a(String str) {
        URL url;
        String str2 = null;
        synchronized (this) {
            h.c(a, "Switch Domain....");
            try {
                url = new URL(str);
            } catch (MalformedURLException e) {
                e.printStackTrace();
                url = null;
            }
            if (url != null) {
                StringBuffer a2 = a(url);
                if (!this.L) {
                    this.L = true;
                    d();
                }
                str2 = a2.toString();
            }
        }
        return str2;
    }

    public boolean b() {
        return this.L;
    }
}
