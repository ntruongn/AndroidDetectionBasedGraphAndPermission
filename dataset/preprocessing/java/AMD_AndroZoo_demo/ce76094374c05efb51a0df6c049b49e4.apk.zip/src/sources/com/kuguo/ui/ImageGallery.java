package com.kuguo.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.Gallery;
import android.widget.SpinnerAdapter;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class ImageGallery extends Gallery {
    private Bitmap a;
    private Bitmap b;

    public ImageGallery(Context context) {
        this(context, null);
    }

    public ImageGallery(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setAdapter((SpinnerAdapter) new a(this));
    }

    private void a(Canvas canvas) {
        int count = getAdapter().getCount();
        if (count <= 0 || this.a == null || this.b == null) {
            return;
        }
        int width = this.a.getWidth();
        int height = this.a.getHeight();
        int selectedItemPosition = getSelectedItemPosition();
        int width2 = ((getWidth() - (width * count)) - ((count - 1) * 10)) / 2;
        int height2 = (getHeight() - height) - 10;
        for (int i = 0; i < count; i++) {
            if (i != selectedItemPosition) {
                canvas.drawBitmap(this.a, width2, height2, (Paint) null);
            } else {
                canvas.drawBitmap(this.b, width2, height2, (Paint) null);
            }
            width2 += width + 10;
        }
    }

    public void a(Bitmap bitmap, int i) {
        a aVar = (a) getAdapter();
        aVar.a().set(i, bitmap);
        aVar.notifyDataSetChanged();
    }

    public void a(Bitmap bitmap, Bitmap bitmap2) {
        this.a = bitmap;
        this.b = bitmap2;
    }

    public void a(List list) {
        ((a) getAdapter()).a(list);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        a(canvas);
    }
}
