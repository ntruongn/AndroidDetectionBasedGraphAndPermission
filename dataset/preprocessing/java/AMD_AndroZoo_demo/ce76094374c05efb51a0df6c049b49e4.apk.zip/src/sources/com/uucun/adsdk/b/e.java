package com.uucun.adsdk.b;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public final class e extends Thread {
    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        h.c(true);
        h.e = null;
    }
}
