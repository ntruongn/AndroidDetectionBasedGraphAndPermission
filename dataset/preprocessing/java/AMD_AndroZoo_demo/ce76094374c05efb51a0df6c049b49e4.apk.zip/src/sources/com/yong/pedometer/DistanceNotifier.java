package com.yong.pedometer;

import com.yong.pedometer.SpeakingTimer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class DistanceNotifier implements StepListener, SpeakingTimer.Listener {
    float mDistance = 0.0f;
    boolean mIsMetric;
    private Listener mListener;
    PedometerSettings mSettings;
    float mStepLength;
    Utils mUtils;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
    public interface Listener {
        void passValue();

        void valueChanged(float f);
    }

    public DistanceNotifier(Listener listener, PedometerSettings settings, Utils utils) {
        this.mListener = listener;
        this.mUtils = utils;
        this.mSettings = settings;
        reloadSettings();
    }

    public void setDistance(float distance) {
        this.mDistance = distance;
        notifyListener();
    }

    public void reloadSettings() {
        this.mIsMetric = this.mSettings.isMetric();
        this.mStepLength = this.mSettings.getStepLength();
        notifyListener();
    }

    @Override // com.yong.pedometer.StepListener
    public void onStep() {
        if (this.mIsMetric) {
            this.mDistance += (float) (this.mStepLength / 100000.0d);
        } else {
            this.mDistance += (float) (this.mStepLength / 63360.0d);
        }
        notifyListener();
    }

    private void notifyListener() {
        this.mListener.valueChanged(this.mDistance);
    }

    @Override // com.yong.pedometer.StepListener
    public void passValue() {
    }

    @Override // com.yong.pedometer.SpeakingTimer.Listener
    public void speak() {
        if (this.mSettings.shouldTellDistance() && this.mDistance >= 0.001f) {
            this.mUtils.say(String.valueOf(new StringBuilder().append(this.mDistance + 1.0E-6f).toString().substring(0, 4)) + (this.mIsMetric ? " kilometers" : " miles"));
        }
    }
}
