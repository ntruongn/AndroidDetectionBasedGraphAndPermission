package com.kuguo.openads;

import android.app.AlertDialog;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class h implements Runnable {
    final /* synthetic */ AlertDialog.Builder a;
    final /* synthetic */ u b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h(u uVar, AlertDialog.Builder builder) {
        this.b = uVar;
        this.a = builder;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.a.create().show();
    }
}
