package com.wooboo.adlib_android;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Message;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.io.File;
import java.io.FileInputStream;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class h extends SurfaceView implements MediaPlayer.OnBufferingUpdateListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnVideoSizeChangedListener, SurfaceHolder.Callback {
    private int b;
    private int c;
    private MediaPlayer d;
    private SurfaceHolder e;
    private boolean f;
    private boolean g;
    private nc h;
    private String i;
    Handler j;
    private static final String z = z(z("){ik4({Hk12\u007fUb4\"{w"));
    private static final String a = z(z("\u0016{ag4\u000brdw0)Z`c:"));

    public h(Context context, nc ncVar, String str) {
        super(context);
        this.f = false;
        this.g = false;
        this.j = new f(this);
        this.h = ncVar;
        this.i = str;
        this.e = getHolder();
        this.e.addCallback(this);
        this.e.setType(3);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(h hVar, String str) {
        hVar.a(str);
    }

    private void a(String str) {
        try {
            this.d = new MediaPlayer();
            this.d.setDataSource(new FileInputStream(new File(str)).getFD());
            this.d.setDisplay(this.e);
            this.d.prepare();
            this.d.setOnBufferingUpdateListener(this);
            this.d.setOnCompletionListener(this);
            this.d.setOnPreparedListener(this);
            this.d.setOnVideoSizeChangedListener(this);
            this.d.setAudioStreamType(3);
            b();
        } catch (Exception e) {
            e.printStackTrace();
            onCompletion(this.d);
        }
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '[';
                    break;
                case 1:
                    c = 30;
                    break;
                case 2:
                    c = 5;
                    break;
                case nb.p /* 3 */:
                    c = 14;
                    break;
                default:
                    c = 'U';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'U');
        }
        return charArray;
    }

    public void a() {
        if (this.d != null) {
            this.d.release();
            this.d = null;
            mc.c(z);
        }
    }

    protected void b() {
        this.e.setFixedSize(this.b, this.c);
        this.d.start();
    }

    @Override // android.media.MediaPlayer.OnBufferingUpdateListener
    public void onBufferingUpdate(MediaPlayer mediaPlayer, int i) {
    }

    @Override // android.media.MediaPlayer.OnCompletionListener
    public void onCompletion(MediaPlayer mediaPlayer) {
        this.h.a();
        a();
    }

    @Override // android.media.MediaPlayer.OnPreparedListener
    public void onPrepared(MediaPlayer mediaPlayer) {
    }

    @Override // android.media.MediaPlayer.OnVideoSizeChangedListener
    public void onVideoSizeChanged(MediaPlayer mediaPlayer, int i, int i2) {
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        if (!kb.a()) {
            this.h.a();
            a();
        } else {
            Message message = new Message();
            message.obj = this.i;
            this.j.sendMessage(message);
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
    }
}
