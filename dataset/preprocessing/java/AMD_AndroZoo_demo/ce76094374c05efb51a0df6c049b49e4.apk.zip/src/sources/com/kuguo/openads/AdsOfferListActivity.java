package com.kuguo.openads;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import com.mobclick.android.UmengConstants;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class AdsOfferListActivity extends Activity {
    private u a;

    private void a(String str) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("酷果应用列表");
        builder.setMessage(str);
        builder.setNeutralButton("确定", new e(this));
        builder.create().show();
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        this.a = new u(this, getIntent().getIntExtra(UmengConstants.AtomKey_Type, 0));
        this.a.a(getIntent().getBooleanExtra("need_back", false));
        this.a.b(getIntent().getIntExtra("points", -1));
        String stringExtra = getIntent().getStringExtra("title");
        if (stringExtra != null) {
            this.a.a(stringExtra);
        }
        View a = new com.kuguo.c.b(this, this.a).a();
        a.setBackgroundColor(-1);
        setContentView(a);
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        this.a.f();
    }

    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        String stringExtra = getIntent().getStringExtra("show_dialog");
        if (stringExtra != null) {
            a(stringExtra);
        }
    }
}
