package com.wooboo.adlib_android;

import android.os.Message;
import java.util.TimerTask;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class md extends TimerTask {
    final fb a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public md(fb fbVar) {
        this.a = fbVar;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        Message message = new Message();
        message.what = n.Y;
        message.obj = n.v;
        n.db.sendMessage(message);
    }
}
