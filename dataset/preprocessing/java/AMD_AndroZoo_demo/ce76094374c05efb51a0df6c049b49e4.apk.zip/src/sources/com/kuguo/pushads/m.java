package com.kuguo.pushads;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
final class m extends Handler {
    final /* synthetic */ AdsService a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m(AdsService adsService, Looper looper) {
        super(looper);
        this.a = adsService;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        boolean b;
        int i;
        int i2;
        int intExtra = ((Intent) message.obj).getIntExtra("requestMode", 0);
        Log.d("android__log", " ready to request...");
        b = this.a.b();
        if (!b) {
            i2 = AdsService.e;
            if (i2 == 2 && intExtra != 2) {
                Log.d("android__log", " ----------------------- noon request");
                AdsReceiver.a(this.a, message.arg1);
            }
        }
        if (intExtra != 10) {
            int e = a.e(this.a);
            Log.d("android__log", " reqeust code: " + e);
            switch (e) {
                case 0:
                case 1:
                    AdsService adsService = this.a;
                    i = AdsService.e;
                    adsService.a(i);
                    break;
                case 2:
                    this.a.a(10);
                    break;
            }
        } else {
            this.a.a(10);
        }
        AdsReceiver.a(this.a, message.arg1);
    }
}
