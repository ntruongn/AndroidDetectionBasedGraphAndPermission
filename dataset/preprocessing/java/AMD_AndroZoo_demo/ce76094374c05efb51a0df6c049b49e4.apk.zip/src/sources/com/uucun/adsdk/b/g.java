package com.uucun.adsdk.b;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class g {
    private String[] a;
    private String b;
    private Process c = null;

    public g(Context context) {
        this.a = null;
        this.b = null;
        ArrayList arrayList = new ArrayList();
        this.b = context.getPackageName();
        arrayList.add("logcat");
        arrayList.add("-d");
        arrayList.add("-v");
        arrayList.add("raw");
        arrayList.add("-s");
        arrayList.add("AndroidRuntime:E");
        arrayList.add("-p");
        arrayList.add(this.b);
        this.a = (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    private void c() {
        try {
            Runtime.getRuntime().exec("logcat -c").destroy();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String a() {
        String str;
        Exception e;
        try {
            this.c = Runtime.getRuntime().exec(this.a);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.c.getInputStream()), 1024);
            boolean z = false;
            String readLine = bufferedReader.readLine();
            str = "";
            boolean z2 = false;
            while (readLine != null) {
                String str2 = readLine.indexOf("thread attach failed") < 0 ? str + readLine + '\n' : str;
                if (!z2 && readLine.toLowerCase().indexOf("exception") >= 0) {
                    z2 = true;
                }
                z = !z ? readLine.indexOf(this.b) < 0 ? z : true : z;
                readLine = bufferedReader.readLine();
                str = str2;
            }
            if (str.length() <= 0 || !z2 || !z) {
                str = "";
            }
            try {
                c();
            } catch (Exception e2) {
                e = e2;
                e.printStackTrace();
                this.c.destroy();
                return str;
            }
        } catch (Exception e3) {
            str = "";
            e = e3;
        }
        this.c.destroy();
        return str;
    }

    public void b() {
        if (this.c != null) {
            this.c.destroy();
            c();
        }
    }
}
