package com.feedback.ui;

import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;
import com.mobclick.android.m;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class a implements View.OnClickListener {
    final /* synthetic */ FeedbackConversation a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(FeedbackConversation feedbackConversation) {
        this.a = feedbackConversation;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        EditText editText;
        JSONObject jSONObject;
        EditText editText2;
        EditText editText3;
        com.feedback.a.d dVar;
        c cVar;
        com.feedback.a.d dVar2;
        c cVar2;
        c cVar3;
        com.feedback.a.d dVar3;
        editText = this.a.h;
        String editable = editText.getText().toString();
        if (editable == null || editable.trim().length() == 0) {
            return;
        }
        if (editable.length() > 140) {
            Toast.makeText(this.a, this.a.getString(m.a(this.a, "string", "UMContentTooLong")), 0).show();
            return;
        }
        try {
            FeedbackConversation feedbackConversation = this.a;
            dVar3 = this.a.e;
            jSONObject = com.feedback.b.b.a(feedbackConversation, editable, dVar3.c);
        } catch (Exception e) {
            Toast.makeText(this.a, e.getMessage(), 0).show();
            com.feedback.b.c.d(this.a, (JSONObject) null);
            Log.d(FeedbackConversation.c, e.getMessage());
            jSONObject = null;
        }
        editText2 = this.a.h;
        editText2.setText("");
        InputMethodManager inputMethodManager = (InputMethodManager) this.a.getSystemService("input_method");
        editText3 = this.a.h;
        inputMethodManager.hideSoftInputFromWindow(editText3.getWindowToken(), 0);
        com.feedback.b.c.c(this.a, jSONObject);
        FeedbackConversation feedbackConversation2 = this.a;
        FeedbackConversation feedbackConversation3 = this.a;
        dVar = this.a.e;
        feedbackConversation2.e = com.feedback.b.c.b(feedbackConversation3, dVar.c);
        cVar = this.a.f;
        dVar2 = this.a.e;
        cVar.a(dVar2);
        cVar2 = this.a.f;
        cVar2.notifyDataSetChanged();
        FeedbackConversation feedbackConversation4 = this.a;
        cVar3 = this.a.f;
        feedbackConversation4.setSelection(cVar3.getCount() - 1);
        FeedbackConversation.executorService.submit(new com.feedback.c.c(jSONObject, this.a));
    }
}
