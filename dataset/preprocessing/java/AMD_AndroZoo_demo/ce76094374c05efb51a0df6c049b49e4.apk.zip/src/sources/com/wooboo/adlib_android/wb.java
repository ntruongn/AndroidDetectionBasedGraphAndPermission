package com.wooboo.adlib_android;

import android.graphics.Bitmap;
import java.io.InputStream;
import java.util.Vector;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class wb {
    protected static final int M = 4096;
    private static final String[] T = {z(z("M\u0015A")), z(z("D\u0019S\u0012OK\fBs\":"))};
    public static final int a = 0;
    public static final int b = 1;
    public static final int c = 2;
    protected int A;
    protected int B;
    protected Bitmap C;
    protected Bitmap D;
    protected int L;
    protected short[] N;
    protected byte[] O;
    protected byte[] P;
    protected byte[] Q;
    protected Vector R;
    protected int S;
    protected InputStream d;
    protected int e;
    protected int f;
    protected int g;
    protected boolean h;
    protected int i;
    protected int[] k;
    protected int[] l;
    protected int[] m;
    protected int n;
    protected int o;
    protected int p;
    protected int q;
    protected boolean r;
    protected boolean s;
    protected int t;
    protected int u;
    protected int v;
    protected int w;
    protected int x;
    protected int y;
    protected int z;
    protected int j = 1;
    protected int E = 0;
    protected byte[] F = new byte[256];
    protected int G = 0;
    protected int H = 0;
    protected int I = 0;
    protected boolean J = false;
    protected int K = 0;

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c3 = cArr[i];
            switch (i % 5) {
                case 0:
                    c2 = '\n';
                    break;
                case 1:
                    c2 = '\\';
                    break;
                case 2:
                    c2 = 7;
                    break;
                case nb.p /* 3 */:
                    c2 = 'A';
                    break;
                default:
                    c2 = '\f';
                    break;
            }
            cArr[i] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '\f');
        }
        return charArray;
    }

    public int a() {
        return this.E;
    }

    public int a(InputStream inputStream) {
        try {
            try {
                try {
                    i();
                    if (inputStream != null) {
                        this.d = inputStream;
                        n();
                        if (!h()) {
                            l();
                            if (this.S < 0) {
                                this.e = 1;
                            }
                        }
                    } else {
                        this.e = 2;
                    }
                    try {
                        inputStream.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return this.e;
                } catch (Exception e2) {
                    throw e2;
                }
            } catch (Exception e3) {
                throw e3;
            }
        } catch (Exception e4) {
            throw e4;
        }
    }

    public void a(int i) {
        this.E = i;
        if (i > this.R.size() - 1) {
        }
    }

    public int b() {
        return this.S;
    }

    public int b(int i) {
        this.K = -1;
        if (i >= 0 && i < this.S) {
            this.K = ((xb) this.R.elementAt(i)).b;
        }
        return this.K;
    }

    public Bitmap c() {
        return c(0);
    }

    public Bitmap c(int i) {
        if (i < 0 || i >= this.S) {
            return null;
        }
        return ((xb) this.R.elementAt(i)).a;
    }

    public int d() {
        return this.j;
    }

    protected int[] d(int i) {
        int i2;
        int i3 = i * 3;
        int[] iArr = (int[]) null;
        byte[] bArr = new byte[i3];
        try {
            i2 = this.d.read(bArr);
        } catch (Exception e) {
            e.printStackTrace();
            i2 = 0;
        }
        if (i2 < i3) {
            try {
                this.e = 1;
            } catch (Exception e2) {
                throw e2;
            }
        } else {
            iArr = new int[256];
            int i4 = 0;
            for (int i5 = 0; i5 < i; i5++) {
                int i6 = i4 + 1;
                int i7 = i6 + 1;
                i4 = i7 + 1;
                iArr[i5] = ((bArr[i4] & 255) << 16) | (-16777216) | ((bArr[i6] & 255) << 8) | (bArr[i7] & 255);
            }
        }
        return iArr;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    protected void e() {
        int i;
        int[] iArr = new int[this.f * this.g];
        if (this.I > 0) {
            if (this.I == 3) {
                int i2 = this.S - 2;
                if (i2 > 0) {
                    this.D = c(i2 - 1);
                } else {
                    this.D = null;
                }
            }
            if (this.D != null) {
                this.D.getPixels(iArr, 0, this.f, 0, 0, this.f, this.g);
                if (this.I == 2) {
                    int i3 = !this.J ? this.p : 0;
                    for (int i4 = 0; i4 < this.B; i4++) {
                        int i5 = ((this.z + i4) * this.f) + this.y;
                        int i6 = this.A + i5;
                        while (i5 < i6) {
                            iArr[i5] = i3;
                            i5++;
                        }
                    }
                }
            }
        }
        int i7 = 8;
        int i8 = 1;
        int i9 = 0;
        for (int i10 = 0; i10 < this.x; i10++) {
            if (this.s) {
                if (i9 >= this.x) {
                    i8++;
                    switch (i8) {
                        case 2:
                            i9 = 4;
                            break;
                        case nb.p /* 3 */:
                            i9 = 2;
                            i7 = 4;
                            break;
                        case 4:
                            i9 = 1;
                            i7 = 2;
                            break;
                    }
                }
                int i11 = i9;
                i9 += i7;
                i = i11;
            } else {
                i = i10;
            }
            int i12 = i + this.v;
            if (i12 < this.g) {
                int i13 = this.f * i12;
                int i14 = i13 + this.u;
                int i15 = this.w + i14;
                if (this.f + i13 < i15) {
                    i15 = this.f + i13;
                }
                int i16 = this.w * i10;
                int i17 = i14;
                while (i17 < i15) {
                    int i18 = i16 + 1;
                    int i19 = this.m[this.Q[i16] & 255];
                    if (i19 != 0) {
                        iArr[i17] = i19;
                    }
                    i17++;
                    i16 = i18;
                }
            }
        }
        this.C = Bitmap.createBitmap(iArr, this.f, this.g, Bitmap.Config.RGB_565);
    }

    public Bitmap f() {
        this.E++;
        if (this.E > this.R.size() - 1) {
            this.E = 0;
        }
        return ((xb) this.R.elementAt(this.E)).a;
    }

    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:18)
        */
    /* JADX WARN: Removed duplicated region for block: B:22:0x007d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x007b -> B:17:0x0069). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:37:0x01a9 -> B:34:0x019e). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:41:0x01ae -> B:42:0x017f). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:46:0x01b6 -> B:25:0x0093). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:72:0x0118 -> B:69:0x00fc). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:87:0x01d1 -> B:70:0x0111). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void g() {
        /*
            Method dump skipped, instructions count: 568
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.wb.g():void");
    }

    protected boolean h() {
        return this.e != 0;
    }

    protected void i() {
        this.e = 0;
        this.S = 0;
        this.R = new Vector();
        this.k = null;
        this.l = null;
    }

    protected int j() {
        try {
            return this.d.read();
        } catch (Exception e) {
            this.e = 1;
            return 0;
        }
    }

    protected int k() {
        this.G = j();
        int i = 0;
        if (this.G > 0) {
            while (i < this.G) {
                try {
                    int read = this.d.read(this.F, i, this.G - i);
                    if (read != -1) {
                        i += read;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            try {
                if (i < this.G) {
                    this.e = 1;
                }
            } catch (Exception e2) {
                throw e2;
            }
        }
        return i;
    }

    protected void l() {
        boolean z = false;
        while (!z && !h()) {
            switch (j()) {
                case 0:
                    break;
                case 33:
                    switch (j()) {
                        case 249:
                            m();
                            break;
                        case 255:
                            k();
                            String str = "";
                            for (int i = 0; i < 11; i++) {
                                str = String.valueOf(str) + ((char) this.F[i]);
                            }
                            if (str.equals(T[1])) {
                                q();
                                break;
                            } else {
                                t();
                                break;
                            }
                        default:
                            t();
                            break;
                    }
                case 44:
                    o();
                    break;
                case 59:
                    z = true;
                    break;
                default:
                    this.e = 1;
                    break;
            }
        }
    }

    protected void m() {
        j();
        int j = j();
        this.H = (j & 28) >> 2;
        if (this.H == 0) {
            this.H = 1;
        }
        this.J = (j & 1) != 0;
        this.K = r() * 10;
        this.L = j();
        j();
    }

    protected void n() {
        String str = "";
        for (int i = 0; i < 6; i++) {
            str = String.valueOf(str) + ((char) j());
        }
        if (!str.startsWith(T[0])) {
            this.e = 1;
            return;
        }
        p();
        if (!this.h || h()) {
            return;
        }
        this.k = d(this.i);
        this.o = this.k[this.n];
    }

    protected void o() {
        int i = 0;
        this.u = r();
        this.v = r();
        this.w = r();
        this.x = r();
        int j = j();
        this.r = (j & 128) != 0;
        this.s = (j & 64) != 0;
        this.t = 2 << (j & 7);
        if (this.r) {
            this.l = d(this.t);
            this.m = this.l;
        } else {
            this.m = this.k;
            if (this.n == this.L) {
                this.o = 0;
            }
        }
        if (this.J) {
            int i2 = this.m[this.L];
            this.m[this.L] = 0;
            i = i2;
        }
        if (this.m == null) {
            this.e = 1;
        }
        if (h()) {
            return;
        }
        g();
        t();
        if (h()) {
            return;
        }
        this.S++;
        this.C = Bitmap.createBitmap(this.f, this.g, Bitmap.Config.RGB_565);
        e();
        this.R.addElement(new xb(this.C, this.K));
        if (this.J) {
            this.m[this.L] = i;
        }
        s();
    }

    protected void p() {
        this.f = r();
        this.g = r();
        int j = j();
        this.h = (j & 128) != 0;
        this.i = 2 << (j & 7);
        this.n = j();
        this.q = j();
    }

    protected void q() {
        do {
            k();
            if (this.F[0] == 1) {
                this.j = (this.F[1] & 255) | ((this.F[2] & 255) << 8);
            }
            if (this.G <= 0) {
                return;
            }
        } while (!h());
    }

    protected int r() {
        return j() | (j() << 8);
    }

    protected void s() {
        this.I = this.H;
        this.y = this.u;
        this.z = this.v;
        this.A = this.w;
        this.B = this.x;
        this.D = this.C;
        this.p = this.o;
        this.H = 0;
        this.J = false;
        this.K = 0;
        this.l = null;
    }

    protected void t() {
        do {
            k();
            if (this.G <= 0) {
                return;
            }
        } while (!h());
    }
}
