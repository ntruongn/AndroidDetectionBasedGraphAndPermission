package com.mobclick.android;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class j extends Thread {
    private final /* synthetic */ Context a;
    private final /* synthetic */ long b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(Context context, long j) {
        this.a = context;
        this.b = j;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        SharedPreferences n;
        n = MobclickAgent.n(this.a);
        long j = n.getLong(UmengConstants.KEY_LAST_UPDATE_TIME, 0L);
        long j2 = n.getLong(UmengConstants.KEY_UPDATE_INTERNAL, this.b);
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - j > j2) {
            MobclickAgent.update(this.a);
            n.edit().putLong(UmengConstants.KEY_LAST_UPDATE_TIME, currentTimeMillis).commit();
        }
    }
}
