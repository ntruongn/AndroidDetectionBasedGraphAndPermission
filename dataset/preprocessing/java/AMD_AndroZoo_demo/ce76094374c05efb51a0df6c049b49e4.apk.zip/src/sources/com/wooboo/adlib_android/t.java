package com.wooboo.adlib_android;

import android.content.Intent;
import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class t implements View.OnClickListener {
    private static final String[] z = {z(z("x'S\fp|.J\u00111")), z(z("m,O\n0e&\u0005\u00111x'E\fqi:_\n>\"\u0011~:\u0015I\u0001\u007f")), z(z("m,O\n0e&\u0005\u00111x'E\fqi:_\n>\"\u0016n \u000b")), z(z("m,O\n0e&\u0005\u00111x'E\fqm!_\u00110blx=\u0011H")), z(z("刊仩臘")), z(z("粲弫幔吲凚宵ｎ严惐剙产ｎ"))};
    final m a;
    private final String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public t(m mVar, String str) {
        this.a = mVar;
        this.b = str;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '\f';
                    break;
                case 1:
                    c = 'B';
                    break;
                case 2:
                    c = '+';
                    break;
                case nb.p /* 3 */:
                    c = 'x';
                    break;
                default:
                    c = '_';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ '_');
        }
        return charArray;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        Intent intent = new Intent(z[3]);
        intent.setType(z[0]);
        intent.putExtra(z[1], "");
        intent.putExtra(z[2], z[5] + this.b);
        m.a(this.a).startActivity(Intent.createChooser(intent, z[4]));
    }
}
