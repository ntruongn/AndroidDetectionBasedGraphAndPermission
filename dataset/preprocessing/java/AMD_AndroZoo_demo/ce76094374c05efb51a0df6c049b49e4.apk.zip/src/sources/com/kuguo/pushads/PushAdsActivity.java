package com.kuguo.pushads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Toast;
import com.kuguo.openads.AdsOfferListActivity;
import com.mobclick.android.UmengConstants;
import com.wooboo.adlib_android.nb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class PushAdsActivity extends Activity {
    private j a;

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(Context context, j jVar) {
        if (jVar.o == null || jVar.o.trim().equals("")) {
            b(context, null, jVar);
            return;
        }
        com.kuguo.a.d dVar = new com.kuguo.a.d(jVar.o, a.b(context, "icon.png", jVar.h));
        dVar.a((Object) 0);
        h.a(context, dVar, new n(context, jVar));
    }

    private void a(j jVar, boolean z) {
        boolean z2;
        boolean z3 = false;
        if (!z) {
            switch (jVar.e) {
                case 1:
                case 2:
                case 5:
                case 8:
                    z2 = false;
                    break;
                case nb.t /* 7 */:
                    z2 = true;
                    break;
            }
            a.a(this, e.b(this, jVar), 17301586, jVar, a.a, false, false);
            z3 = z2;
        }
        if (jVar.e == 4 || jVar.e == 2) {
            h.a(this, jVar.d);
            jVar.j = 2;
            a.b(this, jVar);
            finish();
            return;
        }
        a.a("======= shortcut= " + z);
        if (z) {
            if (a.c(this, jVar.i)) {
                finish();
                return;
            }
            if (6 == jVar.e || 8 == jVar.e) {
                Intent intent = new Intent(this, (Class<?>) AdsOfferListActivity.class);
                intent.putExtra(UmengConstants.AtomKey_Type, jVar.h);
                intent.putExtra("need_back", false);
                intent.putExtra("title", jVar.k);
                startActivity(intent);
                finish();
                jVar.j = 2;
                a.b(this, jVar);
                return;
            }
        } else if (jVar.e == 8) {
            Intent intent2 = new Intent(this, (Class<?>) AdsOfferListActivity.class);
            intent2.putExtra(UmengConstants.AtomKey_Type, jVar.h);
            intent2.putExtra("need_back", true);
            intent2.putExtra("title", jVar.k);
            startActivityForResult(intent2, 100011);
            return;
        }
        if (jVar.e == 5) {
            jVar.j = 2;
            a.b(this, jVar);
            if (a.c(this, jVar)) {
                finish();
                return;
            } else if (jVar.q == 0) {
                a.a(this, null, -1, jVar, a.a, false, true);
                finish();
                return;
            }
        }
        if (jVar.q == 1 && !a.a(jVar.i + ".apk", jVar.h)) {
            new c(this, jVar, z3).a();
            return;
        }
        jVar.j = 2;
        a.b(this, jVar);
        com.kuguo.a.d dVar = new com.kuguo.a.d(jVar.d + "&networkInfo=" + h.d(this), a.b(this, jVar.i + ".apk", jVar.h));
        dVar.a((Object) 0);
        h.a(this, dVar, new o(this, jVar));
        h.a(this, 17301633, "正在下载...", jVar.h, 32, new Intent(), jVar.g, 0);
        finish();
    }

    private static Intent b(Context context, j jVar) {
        Intent intent = new Intent(context, (Class<?>) PushAdsActivity.class);
        intent.setFlags(268435456);
        intent.putExtra("shortcut", true);
        intent.putExtra("sharedid", jVar.f);
        intent.putExtra("message", jVar.a());
        return intent;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void b(Context context, String str, j jVar) {
        Intent intent = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
        intent.putExtra("android.intent.extra.shortcut.NAME", jVar.g);
        intent.putExtra("duplicate", true);
        intent.putExtra("android.intent.extra.shortcut.INTENT", b(context, jVar));
        Bitmap a = str != null ? a.a(context, str, false) : null;
        if (a == null) {
            a = BitmapFactory.decodeResource(context.getResources(), 17301651);
        }
        intent.putExtra("android.intent.extra.shortcut.ICON", a.a(a, a.a(context, "ads/shortcut.png", true)));
        context.sendBroadcast(intent);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 100011 && i2 == 1200 && this.a != null) {
            Toast.makeText(this, "您可稍候通过桌面上 [" + this.a.g + "] 快捷方式进入软件列表页面！", 1).show();
            a(this, this.a);
            a.a(this, null, -1, this.a, a.a, false, true);
        }
        finish();
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        com.kuguo.a.f.a(this);
        requestWindowFeature(1);
        Intent intent = getIntent();
        this.a = new j();
        if (!this.a.a(intent.getStringExtra("message"))) {
            finish();
            return;
        }
        boolean booleanExtra = intent.getBooleanExtra("shortcut", false);
        this.a.f = intent.getIntExtra("sharedid", -1);
        this.a.j = 1;
        a.b(this, this.a);
        a(this.a, booleanExtra);
    }
}
