package com.kuguo.openads;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class t implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ x b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public t(x xVar, String str) {
        this.b = xVar;
        this.a = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        d dVar;
        dVar = this.b.c;
        dVar.c(this.a);
    }
}
