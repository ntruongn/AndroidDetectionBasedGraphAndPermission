package com;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class DoEncrypt {
    private static String a(String str) {
        if (str == null) {
            return "";
        }
        String str2 = "";
        try {
            str2 = URLDecoder.decode(str, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String[] split = str2.split("\\^");
        String str3 = "";
        for (String str4 : split) {
            str3 = String.valueOf(str3) + ((char) Integer.parseInt(str4));
        }
        return str3;
    }

    private static String a(String str, String str2) {
        int[] iArr = new int[256];
        for (int i = 0; i < 256; i++) {
            iArr[i] = i;
        }
        int i2 = 0;
        for (int i3 = 0; i3 < 256; i3++) {
            i2 = ((i2 + iArr[i3]) + str.charAt(i3 % str.length())) % 256;
            int i4 = iArr[i3];
            iArr[i3] = iArr[i2];
            iArr[i2] = i4;
        }
        StringBuffer stringBuffer = new StringBuffer();
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < str2.length(); i7++) {
            i5 = (i5 + 1) % 256;
            i6 = (i6 + iArr[i5]) % 256;
            int i8 = iArr[i5];
            iArr[i5] = iArr[i6];
            iArr[i6] = i8;
            stringBuffer.append((char) (str2.charAt(i7) ^ iArr[(iArr[i5] + iArr[i6]) % 256]));
        }
        return stringBuffer.toString();
    }

    private static String b(String str) {
        if (str == null) {
            return "";
        }
        String str2 = "";
        int i = 0;
        while (i < str.length()) {
            if (i > 0) {
                str2 = String.valueOf(str2) + "^";
            }
            String str3 = String.valueOf(str2) + ((int) str.charAt(i));
            i++;
            str2 = str3;
        }
        try {
            return URLEncoder.encode(str2, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return str2;
        }
    }

    public static String decodecrypt(String str, String str2) {
        return str2 == null ? "" : a(str, a(str2));
    }

    public static String encodecrypt(String str, String str2) {
        return str2 == null ? "" : b(a(str, str2));
    }

    public static void main(String[] strArr) {
    }
}
