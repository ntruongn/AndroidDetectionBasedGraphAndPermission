package com.wooboo.adlib_android;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class HalfAdView extends PopupWindow implements qb {
    private static HalfAdView a;
    private static Context b;
    private static View e;
    private static ImageButton f;
    private static RelativeLayout g;
    private static int j;
    private static int k;
    private static AdListener n;
    private static jb o;
    private static final String[] z = {z(z("#2!6p\u0017\u0006u+9")), z(z(";'==)\u000e\"5*")), z(z("-$7-25\u0014:;3t;6(")), z(z("\u000e#=o-;9=!)z=1**z?0.)z27:};/<o4)k6:16g(#8;8=o>2.;$}-#=;5?9x;5?k(./?%,o+3./o4)k1!4.\"9#4 .<o2(k1<};k**<6k.&8-e"))};
    private static int c = 0;
    private static int d = 0;
    private static Bitmap h = null;
    private static double i = 0.0d;
    private static int l = 0;
    private static int m = 0;
    static Handler p = new d();

    private HalfAdView(Context context) {
        super(context);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public HalfAdView(Context context, View view, int i2, int i3, boolean z2, int[] iArr) {
        super(context);
        boolean z3 = sc.C;
        if (view == null) {
            sc.j(z[3]);
        }
        new DisplayMetrics();
        a(context.getResources().getDisplayMetrics().density);
        a = new HalfAdView(context);
        a.setAnimationStyle(16973827);
        b(context);
        e(i2);
        double d2 = e().getResources().getDisplayMetrics().density;
        int i4 = e().getResources().getDisplayMetrics().heightPixels;
        f(i3);
        sc.g(context);
        sc.a(z2);
        a(view);
        sc.g(context, sc.f(context));
        a(jb.b);
        sc.a(iArr);
        a(context, view);
        if (mc.a != 0) {
            sc.C = !z3;
        }
    }

    protected HalfAdView(Context context, View view, int i2, int i3, boolean z2, int[] iArr, jb jbVar) {
        this(context, view, i2, i3, z2, iArr);
        a(jbVar);
    }

    public HalfAdView(Context context, String str, View view, int i2, int i3, boolean z2, int[] iArr) {
        super(context);
        if (view == null) {
            sc.j(z[3]);
        }
        new DisplayMetrics();
        a(context.getResources().getDisplayMetrics().density);
        a = new HalfAdView(context);
        a.setAnimationStyle(16973827);
        b(context);
        e(i2);
        double d2 = e().getResources().getDisplayMetrics().density;
        int i4 = e().getResources().getDisplayMetrics().heightPixels;
        f(i3);
        sc.g(context);
        sc.a(z2);
        a(view);
        sc.g(context, str);
        a(jb.b);
        sc.a(iArr);
        a(context, view);
    }

    protected HalfAdView(Context context, String str, View view, int i2, int i3, boolean z2, int[] iArr, jb jbVar) {
        this(context, str, view, i2, i3, z2, iArr);
        a(jbVar);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static double a() {
        return i;
    }

    protected static void a(double d2) {
        i = d2;
    }

    protected static void a(int i2) {
        k = i2;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:14:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static void a(android.content.Context r7) {
        /*
            r0 = 0
            r1 = 1
            com.wooboo.adlib_android.gd r2 = new com.wooboo.adlib_android.gd
            r2.<init>()
            r2.start()
            boolean r2 = com.wooboo.adlib_android.sc.l()
            if (r2 != 0) goto L51
            android.content.Context r2 = e()
            r3 = 0
            com.wooboo.adlib_android.pc r2 = com.wooboo.adlib_android.pc.a(r2, r3)
            java.lang.String[] r3 = com.wooboo.adlib_android.HalfAdView.z
            r3 = r3[r1]
            java.lang.String r3 = r2.i(r3)
            java.util.Date r4 = new java.util.Date
            r4.<init>()
            java.text.SimpleDateFormat r5 = new java.text.SimpleDateFormat
            java.lang.String[] r6 = com.wooboo.adlib_android.HalfAdView.z
            r6 = r6[r0]
            r5.<init>(r6)
            java.lang.String r4 = r5.format(r4)
            if (r3 == 0) goto L3f
            boolean r3 = r4.equalsIgnoreCase(r3)
            if (r3 != 0) goto L40
            boolean r0 = com.wooboo.adlib_android.sc.C
            if (r0 == 0) goto L52
        L3f:
            r0 = r1
        L40:
            if (r0 == 0) goto L51
            java.lang.String[] r0 = com.wooboo.adlib_android.HalfAdView.z
            r0 = r0[r1]
            r2.d(r0, r4)
            com.wooboo.adlib_android.hd r0 = new com.wooboo.adlib_android.hd
            r0.<init>()
            r0.start()
        L51:
            return
        L52:
            r0 = r1
            goto L40
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.HalfAdView.a(android.content.Context):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:45:0x0062, code lost:
    
        if (r1 != false) goto L21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0012, code lost:
    
        if (r1 != false) goto L9;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static void a(android.content.Context r6, android.view.View r7) {
        /*
            Method dump skipped, instructions count: 247
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.HalfAdView.a(android.content.Context, android.view.View):void");
    }

    private static void a(View view) {
        e = view;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(ImageButton imageButton) {
        f = imageButton;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(RelativeLayout relativeLayout) {
        g = relativeLayout;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(HalfAdView halfAdView) {
        a = halfAdView;
    }

    protected static void a(jb jbVar) {
        o = jbVar;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int b() {
        return l;
    }

    protected static void b(int i2) {
        j = i2;
    }

    private static void b(Context context) {
        b = context;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int c() {
        return m;
    }

    protected static void c(int i2) {
        l = i2;
    }

    public static void close() {
        if (a != null) {
            try {
                a.dismiss();
                if (g != null) {
                    g.removeAllViews();
                    g = null;
                    sc.a = false;
                }
            } catch (Exception e2) {
                a = null;
            }
        }
    }

    private static View d() {
        return e;
    }

    protected static void d(int i2) {
        m = i2;
    }

    private static Context e() {
        return b;
    }

    private static void e(int i2) {
        d = i2;
    }

    private static int f() {
        return d;
    }

    private static void f(int i2) {
        c = i2;
    }

    private static int g() {
        return c;
    }

    public static int getAdHeight() {
        return j;
    }

    public static jb getAdUnit() {
        return o;
    }

    public static int getAdWidth() {
        return k;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Context h() {
        return e();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static HalfAdView i() {
        return a;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static RelativeLayout j() {
        return g;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static ImageButton k() {
        return f;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Bitmap l() {
        return h;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static View m() {
        return d();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int n() {
        return f();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int o() {
        return g();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static AdListener p() {
        return n;
    }

    private static String z(char[] cArr) {
        char c2;
        int length = cArr.length;
        for (int i2 = 0; length > i2; i2++) {
            char c3 = cArr[i2];
            switch (i2 % 5) {
                case 0:
                    c2 = 'Z';
                    break;
                case 1:
                    c2 = 'K';
                    break;
                case 2:
                    c2 = 'X';
                    break;
                case nb.p /* 3 */:
                    c2 = 'O';
                    break;
                default:
                    c2 = ']';
                    break;
            }
            cArr[i2] = (char) (c2 ^ c3);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ ']');
        }
        return charArray;
    }

    @Override // com.wooboo.adlib_android.qb
    public void closeAd() {
        close();
    }

    public void setAdListener(AdListener adListener) {
        synchronized (this) {
            n = adListener;
        }
    }

    public void show() {
        if (e.getVisibility() == 0) {
            a(b);
        }
    }
}
