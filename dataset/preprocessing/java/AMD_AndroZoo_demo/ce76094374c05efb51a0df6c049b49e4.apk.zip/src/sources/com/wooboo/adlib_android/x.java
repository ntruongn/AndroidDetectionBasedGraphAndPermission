package com.wooboo.adlib_android;

import android.webkit.DownloadListener;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class x implements DownloadListener {
    private static final String z = z(z("g\u001a8=&f\u0018\u001335[\u0000\u001d %"));
    final k a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public x(k kVar) {
        this.a = kVar;
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = '\b';
                    break;
                case 1:
                    c = 't';
                    break;
                case 2:
                    c = '|';
                    break;
                case nb.p /* 3 */:
                    c = 'R';
                    break;
                default:
                    c = 'Q';
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 'Q');
        }
        return charArray;
    }

    @Override // android.webkit.DownloadListener
    public void onDownloadStart(String str, String str2, String str3, String str4, long j) {
        mc.c(z + str);
        if (sc.l()) {
            return;
        }
        AdActivity.a(m.a(k.a(this.a)), str, str2, str3, str4, j);
    }
}
