package com.kuguo.openads;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
class y extends BaseAdapter implements View.OnClickListener {
    private Context b;
    private List a = new ArrayList();
    private String c = "积分";
    private boolean d = true;

    public y(Context context) {
        this.b = context;
    }

    private View a(Context context) {
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(0);
        linearLayout.setPadding(10, 5, 10, 5);
        ImageView imageView = new ImageView(context);
        imageView.setClickable(true);
        imageView.setOnClickListener(this);
        imageView.setId(1000000);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 16;
        layoutParams.rightMargin = 5;
        linearLayout.addView(imageView, layoutParams);
        ImageView imageView2 = new ImageView(context);
        imageView2.setClickable(true);
        imageView2.setOnClickListener(this);
        imageView2.setId(10000001);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 16;
        layoutParams2.rightMargin = 5;
        linearLayout.addView(imageView2, layoutParams2);
        LinearLayout linearLayout2 = new LinearLayout(context);
        linearLayout2.setOrientation(1);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2, 1.0f);
        layoutParams3.gravity = 16;
        linearLayout.addView(linearLayout2, layoutParams3);
        LinearLayout linearLayout3 = new LinearLayout(context);
        linearLayout.setOrientation(0);
        linearLayout2.addView(linearLayout3, new LinearLayout.LayoutParams(-1, -2));
        TextView textView = new TextView(context);
        textView.setId(10000004);
        textView.setTextColor(Color.parseColor("#929292"));
        textView.setLines(2);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.gravity = 16;
        linearLayout2.addView(textView, layoutParams4);
        TextView textView2 = new TextView(context);
        textView2.setTextColor(Color.parseColor("#29688b"));
        textView2.setTextSize(16.0f);
        textView2.setId(10000002);
        linearLayout3.addView(textView2, new LinearLayout.LayoutParams(-2, -2, 1.0f));
        TextView textView3 = new TextView(context);
        textView3.setTextSize(16.0f);
        textView3.setId(10000003);
        textView3.setTextColor(Color.parseColor("#5396c0"));
        linearLayout3.addView(textView3, new LinearLayout.LayoutParams(-2, -2));
        if (!this.d) {
            textView3.setVisibility(4);
        }
        return linearLayout;
    }

    private String a(float f) {
        return f > 1024.0f ? (((int) ((f / 1024.0f) * 100.0f)) / 100.0f) + "M" : ((int) Math.ceil(f)) + "K";
    }

    private void a(View view, g gVar) {
        ImageView imageView = (ImageView) view.findViewById(1000000);
        if (gVar.l == 1 || gVar.l == 2) {
            imageView.setImageDrawable(com.kuguo.d.e.b(this.b, "ads/download_icon.png"));
        } else if (gVar.a) {
            imageView.setImageDrawable(com.kuguo.d.e.b(this.b, "ads/selected_icon.png"));
        } else if (!gVar.a) {
            imageView.setImageDrawable(com.kuguo.d.e.b(this.b, "ads/unselected_icon.png"));
        }
        imageView.setTag(gVar);
        ImageView imageView2 = (ImageView) view.findViewById(10000001);
        if (gVar.e != null) {
            imageView2.setImageDrawable(com.kuguo.d.e.a(this.b, gVar.e));
        } else {
            imageView2.setImageResource(17301651);
        }
        TextView textView = (TextView) view.findViewById(10000002);
        if (gVar.b != null) {
            textView.setText(gVar.b + "  " + a(gVar.h));
        }
        TextView textView2 = (TextView) view.findViewById(10000003);
        int i = (int) (gVar.d * gVar.m);
        if (i <= 0) {
            textView2.setText("");
        } else {
            textView2.setText("送" + i + this.c);
        }
        TextView textView3 = (TextView) view.findViewById(10000004);
        if (gVar.c != null) {
            textView3.setText(gVar.c);
        }
    }

    public String a() {
        return this.c;
    }

    public void a(String str) {
        this.c = str;
    }

    public void a(List list) {
        this.a = list;
    }

    public void a(boolean z) {
        this.d = z;
    }

    public boolean b() {
        return this.d;
    }

    public List c() {
        return this.a;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.a.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return this.a.get(i);
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = a(this.b);
            if (i < 2) {
                ((g) this.a.get(i)).a = true;
            }
        }
        a(view, (g) this.a.get(i));
        return view;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        ImageView imageView = (ImageView) ((ViewGroup) view.getParent()).findViewById(1000000);
        g gVar = (g) imageView.getTag();
        if (gVar == null || gVar.l != 0) {
            return;
        }
        gVar.a = !gVar.a;
        if (gVar.a) {
            imageView.setImageDrawable(com.kuguo.d.e.b(this.b, "ads/selected_icon.png"));
        } else {
            if (gVar.a) {
                return;
            }
            imageView.setImageDrawable(com.kuguo.d.e.b(this.b, "ads/unselected_icon.png"));
        }
    }
}
