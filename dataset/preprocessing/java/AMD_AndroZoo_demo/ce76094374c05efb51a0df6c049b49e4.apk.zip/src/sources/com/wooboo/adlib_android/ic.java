package com.wooboo.adlib_android;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/ce76094374c05efb51a0df6c049b49e4.apk/classes.dex */
public class ic {
    private static final String[] z = {z(z("'\u0001s+~\u0016\u001cgn:")), z(z("EYb yB\u0010m=i\u0007\u0018gnn\u0003\u000e#i")), z(z("+\u0015o+z\u0003\u0015#+n\u0001\u0018s+3")), z(z("7\u0017w+o\u000f\u0010m/i\u0007\u001d#=i\u0010\u0010m)")), z(z("B\u0015j xB")), z(z("B\"`&|\u0010\u0018`:x\u0010Y")), z(z("B\u0018wn")), z(z("1\fa=i\u0010\u0010m)=\u0000\u0016v y\u0011Yf<o\r\u000b")), z(z("1\rf>m\u000b\u0017dn\u007f\u0003\u001ahni\u0015\u0016#=i\u0007\tpnt\u0011Ym!iB\nv>m\r\u000bw+y")), z(z("NC^32>[X5&_Z")), z(z("/\u0010p=t\f\u001e#8|\u000e\ff"))};
    private int a;
    private boolean b;
    private int c;
    private int d;
    private char e;
    private final Reader f;
    private boolean g;

    public ic(InputStream inputStream) throws o {
        this(new InputStreamReader(inputStream));
    }

    public ic(Reader reader) {
        this.f = reader.markSupported() ? reader : new BufferedReader(reader);
        this.b = false;
        this.g = false;
        this.e = (char) 0;
        this.c = 0;
        this.a = 1;
        this.d = 1;
    }

    public ic(String str) {
        this(new StringReader(str));
    }

    public static int a(char c) {
        if (c >= '0' && c <= '9') {
            return c - '0';
        }
        if (c >= 'A' && c <= 'F') {
            return c - '7';
        }
        if (c < 'a' || c > 'f') {
            return -1;
        }
        return c - 'W';
    }

    private static String z(char[] cArr) {
        char c;
        int length = cArr.length;
        for (int i = 0; length > i; i++) {
            char c2 = cArr[i];
            switch (i % 5) {
                case 0:
                    c = 'b';
                    break;
                case 1:
                    c = 'y';
                    break;
                case 2:
                    c = 3;
                    break;
                case nb.p /* 3 */:
                    c = 'N';
                    break;
                default:
                    c = 29;
                    break;
            }
            cArr[i] = (char) (c ^ c2);
        }
        return new String(cArr).intern();
    }

    private static char[] z(String str) {
        char[] charArray = str.toCharArray();
        if (charArray.length < 2) {
            charArray[0] = (char) (charArray[0] ^ 29);
        }
        return charArray;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public String a(int i) throws o {
        if (i == 0) {
            return "";
        }
        char[] cArr = new char[i];
        for (int i2 = 0; i2 < i; i2++) {
            try {
                cArr[i2] = d();
                if (b()) {
                    throw b(z[7]);
                }
            } catch (o e) {
                throw e;
            }
        }
        try {
            return new String(cArr);
        } catch (o e2) {
            throw e2;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x001b, code lost:
    
        a();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.String a(java.lang.String r4) throws com.wooboo.adlib_android.o {
        /*
            r3 = this;
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r0.<init>()
        L5:
            char r1 = r3.d()
            int r2 = r4.indexOf(r1)     // Catch: com.wooboo.adlib_android.o -> L27
            if (r2 >= 0) goto L19
            if (r1 == 0) goto L19
            r2 = 10
            if (r1 == r2) goto L19
            r2 = 13
            if (r1 != r2) goto L31
        L19:
            if (r1 == 0) goto L1e
            r3.a()     // Catch: com.wooboo.adlib_android.o -> L2f
        L1e:
            java.lang.String r0 = r0.toString()
            java.lang.String r0 = r0.trim()
            return r0
        L27:
            r0 = move-exception
            throw r0     // Catch: com.wooboo.adlib_android.o -> L29
        L29:
            r0 = move-exception
            throw r0     // Catch: com.wooboo.adlib_android.o -> L2b
        L2b:
            r0 = move-exception
            throw r0     // Catch: com.wooboo.adlib_android.o -> L2d
        L2d:
            r0 = move-exception
            throw r0     // Catch: com.wooboo.adlib_android.o -> L2f
        L2f:
            r0 = move-exception
            throw r0
        L31:
            r0.append(r1)
            goto L5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ic.a(java.lang.String):java.lang.String");
    }

    public void a() throws o {
        try {
            try {
                if (this.g || this.c <= 0) {
                    throw new o(z[8]);
                }
                this.c--;
                this.a--;
                this.g = true;
                this.b = false;
            } catch (o e) {
                throw e;
            }
        } catch (o e2) {
            throw e2;
        }
    }

    public char b(char c) throws o {
        char d = d();
        if (d == c) {
            return d;
        }
        try {
            throw b(z[0] + c + z[1] + d + "'");
        } catch (o e) {
            throw e;
        }
    }

    public o b(String str) {
        return new o(String.valueOf(str) + toString());
    }

    public boolean b() {
        return this.b && !this.g;
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:10:0x0023. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:18:0x003e A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0045 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x004c A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0053 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0064 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0026 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0007 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0007 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0007 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0007 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0007 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0007 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.String c(char r6) throws com.wooboo.adlib_android.o {
        /*
            r5 = this;
            boolean r0 = com.wooboo.adlib_android.sc.C
            java.lang.StringBuffer r1 = new java.lang.StringBuffer
            r1.<init>()
        L7:
            char r2 = r5.d()
            switch(r2) {
                case 0: goto L15;
                case 10: goto L15;
                case 13: goto L15;
                case 92: goto L1f;
                default: goto Le;
            }
        Le:
            if (r2 != r6) goto L6e
            java.lang.String r0 = r1.toString()     // Catch: com.wooboo.adlib_android.o -> L6c
            return r0
        L15:
            java.lang.String[] r0 = com.wooboo.adlib_android.ic.z
            r1 = 3
            r0 = r0[r1]
            com.wooboo.adlib_android.o r0 = r5.b(r0)
            throw r0
        L1f:
            char r2 = r5.d()
            switch(r2) {
                case 34: goto L64;
                case 39: goto L64;
                case 47: goto L64;
                case 92: goto L64;
                case 98: goto L30;
                case 102: goto L45;
                case 110: goto L3e;
                case 114: goto L4c;
                case 116: goto L37;
                case 117: goto L53;
                default: goto L26;
            }
        L26:
            java.lang.String[] r0 = com.wooboo.adlib_android.ic.z
            r1 = 2
            r0 = r0[r1]
            com.wooboo.adlib_android.o r0 = r5.b(r0)
            throw r0
        L30:
            r3 = 8
            r1.append(r3)     // Catch: com.wooboo.adlib_android.o -> L6a
            if (r0 == 0) goto L7
        L37:
            r3 = 9
            r1.append(r3)
            if (r0 == 0) goto L7
        L3e:
            r3 = 10
            r1.append(r3)
            if (r0 == 0) goto L7
        L45:
            r3 = 12
            r1.append(r3)
            if (r0 == 0) goto L7
        L4c:
            r3 = 13
            r1.append(r3)
            if (r0 == 0) goto L7
        L53:
            r3 = 4
            java.lang.String r3 = r5.a(r3)
            r4 = 16
            int r3 = java.lang.Integer.parseInt(r3, r4)
            char r3 = (char) r3
            r1.append(r3)
            if (r0 == 0) goto L7
        L64:
            r1.append(r2)
            if (r0 == 0) goto L7
            goto L26
        L6a:
            r0 = move-exception
            throw r0
        L6c:
            r0 = move-exception
            throw r0
        L6e:
            r1.append(r2)
            goto L7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ic.c(char):java.lang.String");
    }

    public boolean c() throws o {
        try {
            d();
            if (b()) {
                return false;
            }
            a();
            return true;
        } catch (o e) {
            throw e;
        }
    }

    public char d() throws o {
        int read;
        if (this.g) {
            this.g = false;
            read = this.e;
        } else {
            try {
                read = this.f.read();
                if (read <= 0) {
                    this.b = true;
                    read = 0;
                }
            } catch (IOException e) {
                throw new o(e);
            }
        }
        try {
            try {
                this.c++;
                if (this.e == '\r') {
                    this.d++;
                    this.a = read != 10 ? 1 : 0;
                } else if (read == 10) {
                    try {
                        this.d++;
                        this.a = 0;
                    } catch (IOException e2) {
                        throw e2;
                    }
                } else {
                    this.a++;
                }
                this.e = (char) read;
                return this.e;
            } catch (IOException e3) {
                throw e3;
            }
        } catch (IOException e4) {
            throw e4;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x0017, code lost:
    
        a();
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0023, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0024, code lost:
    
        throw r0;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.String d(char r4) throws com.wooboo.adlib_android.o {
        /*
            r3 = this;
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r0.<init>()
        L5:
            char r1 = r3.d()
            if (r1 == r4) goto L15
            if (r1 == 0) goto L15
            r2 = 10
            if (r1 == r2) goto L15
            r2 = 13
            if (r1 != r2) goto L25
        L15:
            if (r1 == 0) goto L1a
            r3.a()     // Catch: com.wooboo.adlib_android.o -> L23
        L1a:
            java.lang.String r0 = r0.toString()
            java.lang.String r0 = r0.trim()
            return r0
        L23:
            r0 = move-exception
            throw r0
        L25:
            r0.append(r1)
            goto L5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ic.d(char):java.lang.String");
    }

    public char e() throws o {
        char d;
        do {
            d = d();
            if (d == 0) {
                break;
            }
        } while (d <= ' ');
        return d;
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x0014, code lost:
    
        r5.f.reset();
        r5.c = r1;
        r5.a = r2;
        r5.d = r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public char e(char r6) throws com.wooboo.adlib_android.o {
        /*
            r5 = this;
            int r1 = r5.c     // Catch: java.io.IOException -> L26
            int r2 = r5.a     // Catch: java.io.IOException -> L26
            int r3 = r5.d     // Catch: java.io.IOException -> L26
            java.io.Reader r0 = r5.f     // Catch: java.io.IOException -> L26
            r4 = 2147483647(0x7fffffff, float:NaN)
            r0.mark(r4)     // Catch: java.io.IOException -> L26
        Le:
            char r0 = r5.d()     // Catch: java.io.IOException -> L26
            if (r0 != 0) goto L20
            java.io.Reader r4 = r5.f     // Catch: java.io.IOException -> L26
            r4.reset()     // Catch: java.io.IOException -> L26
            r5.c = r1     // Catch: java.io.IOException -> L26
            r5.a = r2     // Catch: java.io.IOException -> L26
            r5.d = r3     // Catch: java.io.IOException -> L26
        L1f:
            return r0
        L20:
            if (r0 != r6) goto Le
            r5.a()
            goto L1f
        L26:
            r0 = move-exception
            com.wooboo.adlib_android.o r1 = new com.wooboo.adlib_android.o
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ic.e(char):char");
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x002f A[Catch: o -> 0x003a, TryCatch #2 {o -> 0x003a, blocks: (B:13:0x0027, B:15:0x002f, B:16:0x0039), top: B:12:0x0027 }] */
    /* JADX WARN: Removed duplicated region for block: B:18:0x005f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object f() throws com.wooboo.adlib_android.o {
        /*
            r4 = this;
            char r0 = r4.e()
            switch(r0) {
                case 34: goto L3c;
                case 39: goto L3c;
                case 91: goto L4c;
                case 123: goto L43;
                default: goto L7;
            }
        L7:
            java.lang.StringBuffer r1 = new java.lang.StringBuffer
            r1.<init>()
        Lc:
            r2 = 32
            if (r0 < r2) goto L1c
            java.lang.String[] r2 = com.wooboo.adlib_android.ic.z     // Catch: com.wooboo.adlib_android.o -> L5d
            r3 = 9
            r2 = r2[r3]     // Catch: com.wooboo.adlib_android.o -> L5d
            int r2 = r2.indexOf(r0)     // Catch: com.wooboo.adlib_android.o -> L5d
            if (r2 < 0) goto L55
        L1c:
            r4.a()
            java.lang.String r0 = r1.toString()
            java.lang.String r0 = r0.trim()
            java.lang.String r1 = ""
            boolean r1 = r0.equals(r1)     // Catch: com.wooboo.adlib_android.o -> L3a
            if (r1 == 0) goto L5f
            java.lang.String[] r0 = com.wooboo.adlib_android.ic.z     // Catch: com.wooboo.adlib_android.o -> L3a
            r1 = 10
            r0 = r0[r1]     // Catch: com.wooboo.adlib_android.o -> L3a
            com.wooboo.adlib_android.o r0 = r4.b(r0)     // Catch: com.wooboo.adlib_android.o -> L3a
            throw r0     // Catch: com.wooboo.adlib_android.o -> L3a
        L3a:
            r0 = move-exception
            throw r0
        L3c:
            java.lang.String r0 = r4.c(r0)     // Catch: com.wooboo.adlib_android.o -> L41
        L40:
            return r0
        L41:
            r0 = move-exception
            throw r0
        L43:
            r4.a()
            com.wooboo.adlib_android.fc r0 = new com.wooboo.adlib_android.fc
            r0.<init>(r4)
            goto L40
        L4c:
            r4.a()
            com.wooboo.adlib_android.ec r0 = new com.wooboo.adlib_android.ec
            r0.<init>(r4)
            goto L40
        L55:
            r1.append(r0)
            char r0 = r4.d()
            goto Lc
        L5d:
            r0 = move-exception
            throw r0
        L5f:
            java.lang.Object r0 = com.wooboo.adlib_android.fc.v(r0)
            goto L40
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wooboo.adlib_android.ic.f():java.lang.Object");
    }

    public String toString() {
        return z[6] + this.c + z[5] + this.a + z[4] + this.d + "]";
    }
}
