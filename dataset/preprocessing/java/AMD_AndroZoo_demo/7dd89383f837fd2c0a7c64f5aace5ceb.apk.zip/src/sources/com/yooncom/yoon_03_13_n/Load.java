package com.yooncom.yoon_03_13_n;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.widget.ImageView;
import android.widget.Toast;

@SuppressLint({"HandlerLeak"})
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class Load extends Cm {
    public static boolean check_net = false;
    public static Activity loadActivity;
    public ImageView launchImg;
    private boolean launchImgExist;
    private boolean mFlag = false;
    private Handler mHandler;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.yooncom.yoon_03_13_n.Cm, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.load_img);
        ConnectivityManager cm = (ConnectivityManager) getSystemService("connectivity");
        NetworkInfo ni = cm.getNetworkInfo(1);
        boolean isWifiConn = ni != null ? ni.isConnected() : false;
        NetworkInfo ni2 = cm.getNetworkInfo(0);
        boolean isMobileConn = ni2 != null ? ni2.isConnected() : false;
        loadActivity = this;
        this.mHandler = new Handler() { // from class: com.yooncom.yoon_03_13_n.Load.1
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    Load.this.mFlag = false;
                }
            }
        };
        check_network();
        this.launchImg = (ImageView) findViewById(R.id.launchImg);
        int launchImgResource = getResources().getIdentifier("launch", "drawable", getPackageName());
        this.launchImgExist = launchImgResource != 0;
        if (this.launchImgExist) {
            this.launchImg.setImageResource(launchImgResource);
        } else if (isWifiConn || isMobileConn) {
            this.launchImg.setVisibility(8);
            showLoading(getString(R.string.is_page_loding), this);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void check_network() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService("connectivity");
        NetworkInfo ni = cm.getNetworkInfo(1);
        boolean isWifiConn = ni != null ? ni.isConnected() : false;
        NetworkInfo ni2 = cm.getNetworkInfo(0);
        boolean isMobileConn = ni2 != null ? ni2.isConnected() : false;
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(getString(R.string.app_name));
        alert.setIcon(R.drawable.icon);
        if (isWifiConn || isMobileConn) {
            check_net = true;
            return;
        }
        alert.setMessage(getString(R.string.no_network));
        alert.setPositiveButton(getString(R.string.retry), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Load.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                Tab_Home.wb.reload();
                Load.this.check_network();
                dialog.cancel();
            }
        });
        alert.setNegativeButton(getString(R.string.end), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Load.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                Main mainActivity = (Main) Main.mainActivity;
                mainActivity.finish();
                Load.this.moveTaskToBack(true);
                dialog.cancel();
                Load.this.finish();
            }
        });
        alert.show();
    }

    @Override // android.support.v4.app.FragmentActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (!this.mFlag) {
                Toast.makeText(this, getString(R.string.is_back_end), 0).show();
                this.mFlag = true;
                this.mHandler.sendEmptyMessageDelayed(0, 2000L);
                return false;
            }
            Main mainActivity = (Main) Main.mainActivity;
            mainActivity.finish();
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
