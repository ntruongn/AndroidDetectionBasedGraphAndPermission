package com.yooncom.yoon_03_13_n;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TabWidget;

@SuppressLint({"HandlerLeak"})
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class ChromeClient extends WebChromeClient {
    public static Activity mActivity;
    public static View mCustomView;
    public static WebChromeClient.CustomViewCallback mCustomViewCollback;
    public static FullscreenHolder mFullscreenContainer;
    public static int mOriginalOrientation;
    private boolean mFlag = false;
    private Handler mHandler;
    public TabWidget mTabWidget;

    public ChromeClient(Activity activity) {
        mActivity = activity;
    }

    public ChromeClient(Tab_Home tab_Home) {
    }

    @Override // android.webkit.WebChromeClient
    public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
        result.confirm();
        return super.onJsAlert(view, url, message, result);
    }

    @Override // android.webkit.WebChromeClient
    public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
        if (mCustomView != null) {
            callback.onCustomViewHidden();
            return;
        }
        mOriginalOrientation = mActivity.getRequestedOrientation();
        FrameLayout decor = (FrameLayout) mActivity.getWindow().getDecorView();
        mFullscreenContainer = new FullscreenHolder(mActivity);
        mFullscreenContainer.addView(view, -1);
        decor.addView(mFullscreenContainer, -1);
        mCustomView = view;
        mCustomViewCollback = callback;
        mActivity.setRequestedOrientation(mOriginalOrientation);
    }

    @Override // android.webkit.WebChromeClient
    public void onHideCustomView() {
        if (mCustomView != null) {
            FrameLayout decor = (FrameLayout) mActivity.getWindow().getDecorView();
            decor.removeView(mFullscreenContainer);
            mFullscreenContainer = null;
            mCustomView = null;
            mCustomViewCollback.onCustomViewHidden();
            mActivity.setRequestedOrientation(mOriginalOrientation);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public class FullscreenHolder extends FrameLayout {
        public FullscreenHolder(Context ctx) {
            super(ctx);
            ChromeClient.this.mHandler = new Handler() { // from class: com.yooncom.yoon_03_13_n.ChromeClient.FullscreenHolder.1
                @Override // android.os.Handler
                public void handleMessage(Message msg) {
                    if (msg.what == 0) {
                        ChromeClient.this.mFlag = false;
                    }
                }
            };
            setBackgroundColor(ctx.getResources().getColor(17170444));
        }

        @Override // android.view.View
        public boolean onTouchEvent(MotionEvent evt) {
            return true;
        }
    }
}
