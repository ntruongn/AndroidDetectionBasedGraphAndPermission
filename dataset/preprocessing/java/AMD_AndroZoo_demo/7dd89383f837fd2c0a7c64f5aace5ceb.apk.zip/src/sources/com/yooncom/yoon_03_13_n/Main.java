package com.yooncom.yoon_03_13_n;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LightingColorFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint({"HandlerLeak"})
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class Main extends Cm implements View.OnClickListener {
    public static final int FRAGMENT_ALARM = 2;
    public static final int FRAGMENT_ALLARTICLE = 1;
    public static final int FRAGMENT_HOME = 0;
    public static final int FRAGMENT_SET = 3;
    public static boolean is_app;
    static int mCurrentFragmentIndex;
    public static Activity mainActivity;
    static CmViewPager pager;
    static LinearLayout[] tab_btn_array;
    static int tab_cnt = 4;
    static ImageView[] tab_img_array;
    static String[] tab_img_array_resource;
    static LinearLayout tab_layout;
    static TextView tab_new_version;
    static TextView tab_pushcnt;
    static TextView[] tab_txt_array;
    public static Boolean viewpager_set_ck;
    Cm cmActivity;
    private boolean mFlag = false;
    private Handler mHandler;
    String[] tab_btn_array_resource;
    String[] tab_txt_array_resource;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.yooncom.yoon_03_13_n.Cm, android.support.v4.app.FragmentActivity, android.app.Activity
    @SuppressLint({"InlinedApi"})
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mainActivity = this;
        CmApi.check_version(getString(R.string.site_no));
        this.cmActivity = (Cm) Cm.CmActivity;
        this.cmActivity.setTitleBar();
        Intent intent = new Intent(this, (Class<?>) Load.class);
        startActivity(intent);
        init_view_pager();
        init_tab();
        is_new_version();
        SharedPreferences sp = getSharedPreferences("app_on", 0);
        SharedPreferences.Editor is_app2 = sp.edit();
        is_app2.putBoolean("on", true);
        is_app2.commit();
        SharedPreferences pref = getSharedPreferences("pushAlarmSet", 0);
        viewpager_set_ck = Boolean.valueOf(pref.getBoolean("viewpager_alarm", true));
        if (!viewpager_set_ck.booleanValue()) {
            pager.setPagingEnabled(false);
        }
        NotificationManager nm = (NotificationManager) getSystemService("notification");
        nm.cancel(0);
        this.mHandler = new Handler() { // from class: com.yooncom.yoon_03_13_n.Main.1
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    Main.this.mFlag = false;
                }
            }
        };
        if (Build.VERSION.SDK_INT >= 11) {
            getWindow().setFlags(ViewCompat.MEASURED_STATE_TOO_SMALL, ViewCompat.MEASURED_STATE_TOO_SMALL);
        }
    }

    private void init_view_pager() {
        pager = (CmViewPager) findViewById(R.id.view_fragment);
        pager.setAdapter(new CmPagerAdapter(getSupportFragmentManager()));
        pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() { // from class: com.yooncom.yoon_03_13_n.Main.2
            @Override // android.support.v4.view.ViewPager.OnPageChangeListener
            public void onPageSelected(int arg0) {
                Main.mCurrentFragmentIndex = arg0;
                Main.this.tab_on_set(Main.mCurrentFragmentIndex);
            }

            @Override // android.support.v4.view.ViewPager.OnPageChangeListener
            public void onPageScrolled(int arg0, float arg1, int arg2) {
            }

            @Override // android.support.v4.view.ViewPager.OnPageChangeListener
            public void onPageScrollStateChanged(int arg0) {
            }
        });
        pager.setOffscreenPageLimit(4);
    }

    public static void is_push_msg() {
        if (Pushmsg.pushCount > 0 && Pushmsg.pushCount < 10) {
            tab_pushcnt = (TextView) mainActivity.findViewById(R.id.pushcnt);
            tab_pushcnt.setText(String.valueOf(Pushmsg.pushCount));
            tab_pushcnt.setPadding(15, 3, 15, 3);
            tab_pushcnt.setVisibility(0);
            return;
        }
        if (Pushmsg.pushCount >= 10 && Pushmsg.pushCount < 100) {
            tab_pushcnt = (TextView) mainActivity.findViewById(R.id.pushcnt);
            tab_pushcnt.setText(String.valueOf(Pushmsg.pushCount));
            tab_pushcnt.setPadding(6, 3, 6, 3);
            tab_pushcnt.setVisibility(0);
            return;
        }
        if (Pushmsg.pushCount >= 100) {
            tab_pushcnt = (TextView) mainActivity.findViewById(R.id.pushcnt);
            tab_pushcnt.setText("99+");
            tab_pushcnt.setPadding(5, 8, 5, 8);
            tab_pushcnt.setVisibility(0);
            return;
        }
        tab_pushcnt = (TextView) mainActivity.findViewById(R.id.pushcnt);
        tab_pushcnt.setVisibility(8);
    }

    public static void is_new_version() {
        if (newVersionCode > versionCode) {
            tab_new_version = (TextView) mainActivity.findViewById(R.id.new_version);
            tab_new_version.setPadding(15, 3, 15, 3);
            tab_new_version.setVisibility(0);
        } else {
            tab_new_version = (TextView) mainActivity.findViewById(R.id.new_version);
            tab_new_version.setVisibility(8);
        }
    }

    private void init_tab() {
        tab_layout = (LinearLayout) findViewById(R.id.tab_layout);
        tab_btn_array = new LinearLayout[tab_cnt];
        tab_img_array = new ImageView[tab_cnt];
        tab_txt_array = new TextView[tab_cnt];
        this.tab_btn_array_resource = new String[]{"tab_home_btn", "tab_allarticle_btn", "tab_alarm_btn", "tab_set_btn"};
        tab_img_array_resource = new String[]{"tab_home_img", "tab_allarticle_img", "tab_alarm_img", "tab_set_img"};
        this.tab_txt_array_resource = new String[]{"tab_home_txt", "tab_allarticle_txt", "tab_alarm_txt", "tab_set_txt"};
        for (int i = 0; i < tab_cnt; i++) {
            tab_btn_array[i] = (LinearLayout) findViewById(getResources().getIdentifier(this.tab_btn_array_resource[i], "id", getPackageName()));
            tab_img_array[i] = (ImageView) findViewById(getResources().getIdentifier(tab_img_array_resource[i], "id", getPackageName()));
            tab_txt_array[i] = (TextView) findViewById(getResources().getIdentifier(this.tab_txt_array_resource[i], "id", getPackageName()));
            tab_btn_array[i].setOnClickListener(this);
            tab_img_array[i].setBackgroundResource(getResources().getIdentifier(tab_img_array_resource[i], "drawable", getPackageName()));
        }
        tab_on_set(0);
    }

    public void fragmentReplace(int reqNewFragmentIndex) {
        pager.setCurrentItem(reqNewFragmentIndex);
    }

    public void tab_on_set(int tab_btn) {
        for (int i = 0; i < tab_cnt; i++) {
            if (i != tab_btn) {
                tab_img_array[i].getBackground().setColorFilter(new LightingColorFilter(Color.parseColor("#929292"), Color.parseColor("#929292")));
                tab_txt_array[i].setTextColor(Color.parseColor("#929292"));
            } else {
                tab_img_array[i].getBackground().setColorFilter(new LightingColorFilter(Color.parseColor(Cm.tab_point_color), Color.parseColor(Cm.tab_point_color)));
                tab_txt_array[i].setTextColor(Color.parseColor(Cm.tab_point_color));
                if (!Cm.is_swipe.booleanValue()) {
                    pager.setPagingEnabled(true);
                }
            }
        }
    }

    public void setGrayScale(ImageView v) {
        ColorMatrix matrix = new ColorMatrix();
        matrix.setSaturation(0.0f);
        ColorMatrixColorFilter cf = new ColorMatrixColorFilter(matrix);
        v.setColorFilter(cf);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tab_home_btn /* 2131230723 */:
                if (mCurrentFragmentIndex == 0) {
                    Tab_Home.wb.loadUrl(home_url);
                    return;
                }
                tab_on_set(0);
                mCurrentFragmentIndex = 0;
                fragmentReplace(mCurrentFragmentIndex);
                return;
            case R.id.tab_allarticle_btn /* 2131230726 */:
                if (mCurrentFragmentIndex == 1) {
                    Tab_Allarticle.wb.loadUrl(allarticle_url);
                    return;
                }
                tab_on_set(1);
                mCurrentFragmentIndex = 1;
                fragmentReplace(mCurrentFragmentIndex);
                return;
            case R.id.tab_alarm_btn /* 2131230729 */:
                if (mCurrentFragmentIndex == 2) {
                    Tab_Alarm.wb.loadUrl(alarm_url);
                } else {
                    tab_on_set(2);
                    mCurrentFragmentIndex = 2;
                    fragmentReplace(mCurrentFragmentIndex);
                }
                if (Pushmsg.pushCount > 0) {
                    Tab_Alarm.wb.reload();
                    Pushmsg.pushCount = 0;
                    is_push_msg();
                    NotificationManager nm = (NotificationManager) getSystemService("notification");
                    nm.cancel(0);
                    return;
                }
                return;
            case R.id.tab_set_btn /* 2131230733 */:
                tab_on_set(3);
                mCurrentFragmentIndex = 3;
                fragmentReplace(mCurrentFragmentIndex);
                return;
            default:
                return;
        }
    }

    @Override // android.support.v4.app.FragmentActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        WebView back_wb = null;
        String homeurl = "";
        switch (mCurrentFragmentIndex) {
            case 0:
                back_wb = Tab_Home.wb;
                homeurl = home_url;
                break;
            case 1:
                back_wb = Tab_Allarticle.wb;
                homeurl = allarticle_url;
                break;
            case 2:
                back_wb = Tab_Alarm.wb;
                homeurl = alarm_url;
                break;
        }
        if (keyCode == 4 && mCurrentFragmentIndex != 3 && back_wb.canGoBack() && !back_wb.getUrl().contentEquals(homeurl)) {
            back_wb.goBack();
            return true;
        }
        if (keyCode == 4) {
            if (!this.mFlag) {
                Toast.makeText(this, getString(R.string.is_back_end), 0).show();
                this.mFlag = true;
                this.mHandler.sendEmptyMessageDelayed(0, 2000L);
                return false;
            }
            SharedPreferences sp = getSharedPreferences("app_on", 0);
            SharedPreferences.Editor is_app2 = sp.edit();
            is_app2.putBoolean("on", false);
            is_app2.commit();
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
