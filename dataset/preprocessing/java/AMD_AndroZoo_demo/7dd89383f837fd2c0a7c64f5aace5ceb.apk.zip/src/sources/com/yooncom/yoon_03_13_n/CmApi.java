package com.yooncom.yoon_03_13_n;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutionException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class CmApi extends Cm {
    static String data = "";
    static String param;
    public static Send_Post_Task send_post_task;
    static String urlValue;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.yooncom.yoon_03_13_n.Cm, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public static String send_post(String UrlValue, String Param) {
        urlValue = UrlValue;
        param = Param;
        send_post_task = new Send_Post_Task();
        try {
            data = send_post_task.execute(new String[0]).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e2) {
            e2.printStackTrace();
        }
        return data;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static class Send_Post_Task extends AsyncTask<String, String, String> {
        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... params) {
            try {
                URL url = new URL(CmApi.urlValue);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setDoInput(true);
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                con.setRequestMethod("POST");
                OutputStream out_stream = con.getOutputStream();
                out_stream.write(CmApi.param.getBytes("UTF-8"));
                out_stream.flush();
                out_stream.close();
                InputStream is = con.getInputStream();
                BufferedReader in = new BufferedReader(new InputStreamReader(is), 8192);
                StringBuffer buff = new StringBuffer();
                while (true) {
                    String line = in.readLine();
                    if (line == null) {
                        break;
                    }
                    buff.append(String.valueOf(line) + "\n");
                }
                CmApi.data = buff.toString().trim();
                Log.d("post_test", CmApi.data);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            return CmApi.data;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String result) {
            super.onPostExecute((Send_Post_Task) result);
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            super.onCancelled();
        }
    }

    public static boolean update_gps(String site_no, String latitude, String longitude) {
        String param2 = String.valueOf("") + "site_no=" + site_no;
        String result = send_post(String.valueOf(API_URL) + "app_update_gps.cm", String.valueOf(String.valueOf(String.valueOf(param2) + "&device_id=" + URLEncoder.encode(device_id)) + "&latitude=" + latitude) + "&longitude=" + longitude);
        return result.compareTo("SUCCESS") == 0;
    }

    public static boolean login(String site_no, int member_no) {
        String param2 = String.valueOf("") + "device_id=" + URLEncoder.encode(device_id);
        String result = send_post(String.valueOf(API_URL) + "app_login.cm", String.valueOf(String.valueOf(String.valueOf(param2) + "&site_no=" + site_no) + "&type=android") + "&member=" + member_no);
        return result.compareTo("SUCCESS") == 0;
    }

    public static boolean check_version(String site_no) {
        String param2 = "site_no=" + site_no;
        String result = "";
        String xmlMsg = send_post(String.valueOf(API_URL) + "android_app_check_version.cm", param2);
        try {
            XmlPullParserFactory parserCreator = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserCreator.newPullParser();
            ByteArrayInputStream xmlMsgStream = new ByteArrayInputStream(xmlMsg.getBytes());
            parser.setInput(xmlMsgStream, null);
            String tag = "";
            for (int parserEvent = parser.getEventType(); parserEvent != 1; parserEvent = parser.next()) {
                switch (parserEvent) {
                    case 2:
                        tag = parser.getName();
                        break;
                    case 3:
                        tag = parser.getName();
                        break;
                    case 4:
                        if (tag.compareTo("result") == 0) {
                            result = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("version_code") == 0) {
                            newVersionName = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("version_num") == 0) {
                            newVersionCode = Integer.parseInt(parser.getText().toString());
                            break;
                        } else if (tag.compareTo("app_url") == 0) {
                            app_url = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("pc_url") == 0) {
                            pc_url = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("b2b_name") == 0) {
                            b2b_name = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("b2b_cal") == 0) {
                            b2b_cal = parser.getText().toString();
                            break;
                        } else {
                            break;
                        }
                }
            }
        } catch (Exception e) {
        }
        return result.compareTo("SUCCESS") == 0;
    }

    public static boolean setTitleInfo(String site_no) {
        String param2 = "site_no=" + site_no;
        String result = "";
        String xmlMsg = send_post(String.valueOf(API_URL) + "android_app_set_title_info.cm", param2);
        try {
            XmlPullParserFactory parserCreator = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserCreator.newPullParser();
            ByteArrayInputStream xmlMsgStream = new ByteArrayInputStream(xmlMsg.getBytes());
            parser.setInput(xmlMsgStream, null);
            String tag = "";
            for (int parserEvent = parser.getEventType(); parserEvent != 1; parserEvent = parser.next()) {
                switch (parserEvent) {
                    case 2:
                        tag = parser.getName();
                        Log.d("xml parsing", "START_TAG - " + tag);
                        break;
                    case 3:
                        tag = parser.getName();
                        Log.d("xml parsing", "END_TAG - " + tag);
                        break;
                    case 4:
                        if (tag.compareTo("result") == 0) {
                            result = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("title_font_color") == 0) {
                            title_font_color = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("title_img") == 0) {
                            title_img_src = parser.getText().toString();
                            Log.d("test1", "111 : " + title_img_src);
                            break;
                        } else if (tag.compareTo("title_bg") == 0) {
                            title_bg_color = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("title_grad") == 0) {
                            title_grad = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("title_shadow") == 0) {
                            title_shadow = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("title_user_image") == 0) {
                            title_user_img_src = parser.getText().toString();
                            Log.d("test1", "222 : " + title_user_img_src);
                            break;
                        } else if (tag.compareTo("back_user_image") == 0) {
                            back_user_img_src = parser.getText().toString();
                            Log.d("test1", "333 : " + back_user_img_src);
                            break;
                        } else if (tag.compareTo("back_img") == 0) {
                            back_img_src = parser.getText().toString();
                            Log.d("test1", "444 : " + back_img_src);
                            break;
                        } else if (tag.compareTo("back_bg") == 0) {
                            back_bg_color = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("back_pattern") == 0) {
                            back_pattern = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("tab_point_color") == 0) {
                            tab_point_color = "";
                            tab_point_color = parser.getText().toString();
                            break;
                        } else {
                            break;
                        }
                }
            }
        } catch (Exception e) {
            Log.d("xml parsing", "Error in network call" + e);
        }
        return result.compareTo("SUCCESS") == 0;
    }

    public static boolean setUserInfo(String site_no) {
        String param2 = "site_no=" + site_no;
        String result = "";
        String xmlMsg = send_post(String.valueOf(API_URL) + "android_app_check_user_info.cm", param2);
        try {
            XmlPullParserFactory parserCreator = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserCreator.newPullParser();
            ByteArrayInputStream xmlMsgStream = new ByteArrayInputStream(xmlMsg.getBytes());
            parser.setInput(xmlMsgStream, null);
            String tag = "";
            for (int parserEvent = parser.getEventType(); parserEvent != 1; parserEvent = parser.next()) {
                switch (parserEvent) {
                    case 2:
                        tag = parser.getName();
                        Log.d("xml parsing", "START_TAG - " + tag);
                        break;
                    case 3:
                        tag = parser.getName();
                        Log.d("xml parsing", "END_TAG - " + tag);
                        break;
                    case 4:
                        Log.d("xml parsing", "TEXT - " + tag);
                        if (tag.compareTo("result") == 0) {
                            result = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("is_info") == 0) {
                            is_info = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("name_info") == 0) {
                            name_info = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("num_info") == 0) {
                            num_info = parser.getText().toString();
                            break;
                        } else {
                            break;
                        }
                }
            }
        } catch (Exception e) {
            Log.d("xml parsing", "Error in network call" + e);
        }
        return result.compareTo("SUCCESS") == 0;
    }

    public static boolean register(String site_no, String c2dm_id) {
        Log.d("api", "register() - " + site_no + "," + device_id);
        String param2 = String.valueOf("") + "device_id=" + URLEncoder.encode(device_id);
        if (c2dm_id != null) {
            param2 = String.valueOf(param2) + "&c2dm_id=" + URLEncoder.encode(c2dm_id);
        }
        String xmlMsg = send_post(String.valueOf(API_URL) + "app_register.cm", String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(param2) + "&push_type=gcm") + "&site_no=" + site_no) + "&model=" + URLEncoder.encode(Build.MODEL) + " " + Build.VERSION.RELEASE) + "&type=android") + "&version=" + Main.versionCode);
        String result = "";
        try {
            XmlPullParserFactory parserCreator = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserCreator.newPullParser();
            ByteArrayInputStream xmlMsgStream = new ByteArrayInputStream(xmlMsg.getBytes());
            parser.setInput(xmlMsgStream, null);
            String tag = "";
            for (int parserEvent = parser.getEventType(); parserEvent != 1; parserEvent = parser.next()) {
                switch (parserEvent) {
                    case 2:
                        tag = parser.getName();
                        Log.d("xml parsing", "START_TAG - " + tag);
                        break;
                    case 3:
                        tag = parser.getName();
                        Log.d("xml parsing", "END_TAG - " + tag);
                        break;
                    case 4:
                        if (tag.compareTo("result") == 0) {
                            result = parser.getText().toString();
                            break;
                        } else if (tag.compareTo("url") == 0) {
                            url = parser.getText().toString();
                            home_url = url;
                            allarticle_url = url.replace("?from_app=", "allarticle/from_app=");
                            alarm_url = url.replace("?from_app=", "alarm/from_app=");
                            break;
                        } else if (tag.compareTo("pushcount") == 0) {
                            pushcount = Integer.parseInt(parser.getText().toString());
                            Log.d("test1", "푸시갯수 : " + pushcount);
                            break;
                        } else {
                            break;
                        }
                }
            }
        } catch (Exception e) {
            Log.d("xml parsing", "Error in network call" + e);
        }
        return result.compareTo("SUCCESS") == 0;
    }
}
