package com.yooncom.yoon_03_13_n;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class User_info extends Cm {
    public static boolean user_in = false;
    ArrayList<String> alt;
    ArrayAdapter<String> apt;
    ListView list;
    View user_info_view;
    boolean us = false;
    boolean ls = false;
    String user_info_t = "";
    String lot_info_t = "";

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.yooncom.yoon_03_13_n.Cm, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences pref = getSharedPreferences("user_infos", 0);
        user_in = pref.getBoolean("user_info", false);
        if (CmApi.setUserInfo(getString(R.string.site_no))) {
            get_user_info();
            if (user_in || is_info.equals("Y")) {
                if (!user_in) {
                    SharedPreferences sp = getSharedPreferences("user_infos", 0);
                    SharedPreferences.Editor edit = sp.edit();
                    edit.putBoolean("user_info", true);
                    edit.commit();
                }
                Intent user_infoAct = new Intent(this, (Class<?>) Main.class);
                startActivity(user_infoAct);
                finish();
                return;
            }
            this.user_info_view = getLayoutInflater().inflate(R.layout.user_info, (ViewGroup) null);
            this.alt = new ArrayList<>();
            this.alt.add(getString(R.string.is_user_info));
            this.alt.add(getString(R.string.is_lot_info));
            this.apt = new ArrayAdapter<>(this, (int) R.drawable.unser_info_list, this.alt);
            this.list = (ListView) this.user_info_view.findViewById(R.id.list);
            this.list.setAdapter((ListAdapter) this.apt);
            this.list.setChoiceMode(2);
            this.list.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.yooncom.yoon_03_13_n.User_info.1
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> parent, View view, int position, long arg3) {
                    if (arg3 == 0) {
                        if (User_info.this.us) {
                            User_info.this.us = false;
                            return;
                        } else {
                            User_info.this.userInfo();
                            User_info.this.us = true;
                            return;
                        }
                    }
                    if (User_info.this.ls) {
                        User_info.this.ls = false;
                    } else {
                        User_info.this.lotInfo();
                        User_info.this.ls = true;
                    }
                }
            });
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle(getString(R.string.user_info_title));
            alert.setView(this.user_info_view);
            alert.setPositiveButton(getString(R.string.user_info_confirm), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.User_info.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    if (User_info.this.us && User_info.this.ls) {
                        SharedPreferences sp2 = User_info.this.getSharedPreferences("user_infos", 0);
                        SharedPreferences.Editor edit2 = sp2.edit();
                        edit2.putBoolean("user_info", true);
                        edit2.commit();
                        Intent user_infoAct2 = new Intent(User_info.this, (Class<?>) Main.class);
                        User_info.this.startActivity(user_infoAct2);
                        dialog.cancel();
                        User_info.this.finish();
                        return;
                    }
                    Toast.makeText(User_info.this, User_info.this.getString(R.string.is_user_info_confirm), 0).show();
                    User_info.this.finish();
                    Intent user_infoAct3 = new Intent(User_info.this, (Class<?>) User_info.class);
                    User_info.this.startActivity(user_infoAct3);
                }
            });
            alert.setNegativeButton(getString(R.string.user_info_confirm_no), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.User_info.3
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(User_info.this, User_info.this.getString(R.string.is_user_info_confirm2), 0).show();
                    User_info.this.finish();
                    dialog.cancel();
                }
            });
            alert.show();
            return;
        }
        Toast.makeText(this, "android_app_open_error", 0).show();
    }

    public void get_user_info() {
        this.user_info_t = "1. 수집회사 및 연락처\n\t- 회사명 : " + name_info + "\n\t- 연락처 : " + num_info + "\n2. 수집하는 개인정보 항목 및 수집방법\n \t문자메시지 전송 등 각종 서비스제공을 위해 아래와 같은 개인정보를 수집하고 있습니다.\n \t가. 수집항목\n \t\t이용자의 휴대전화번호,단말기정보(모델명,OS버전,기기고유번호)\n \t나. 개인정보 수집방법\n \t\t이용자가 문자메시지 전송 서비스를 이용시에만\n \t\t개인정보를 수집합니다.\n\n 3. 개인정보의 수집 및 이용목적\n \t수집한 개인정보는 다음의 목정을 위해 고지한 범위내에서 사용 및 활용하며, 원칙적으로 이용자의 사전 동의없이는 동 범위를\n \t초과하여 이용하거나 이용자의 개인정보를 외부에 공개하지 않습니다.(단 이용자가 사전에 개인정보 공개에 대하여 동의한 경우와 법령의 규정에\n \t의거하거나, 수사목적으로 법령에 정해진 절차와 방법에 따라 수사기관의 요구가 있는 경우에는 외부에 공개합니다.)\n \t가. 콘텐츠 제공, 특정 맞춤 서비스 제공,요금결제\n \t나. 고객 서비스 이용에 따른 본인확인, 개인식별, 불량 고객의 부정 이용방지와 비인가 사용방지, 인증 의사 확인, 분쟁조정을 위한 기록보존,\n \t\t불만처리등 민원처리 고지사항 전달\n \t다. 신규 서비스 개발, 통계학적 특성에 따른 서비스 제공 및 광고게재, 서비스의 유효성 확인, 이벤트 및 광고성 정보 제공 및 참여기회 제공,\n \t\t접속빈도 파악, 고객의 서비스이용에 대한 통계\n\n 4. 개인정보의 보유 및 이용기간\n \t개인정보 수집 및 이용목적이 달성된 후에는 해당 정보를 지체 없이 파기합니다.\n \t단, 관계법령의 규정에 의하여 보존할 필요가 있는 경우 회사는 아래와 같이 관계법령에서 정한 일정한 기간 동안 개인정보를 보관합니다.\n \t가. 보존 항목\n \t\t\"2. 수집하는 개인정보 항목 및 수집방법\"중\"가.수집항목\"의 내용 모두를 보존합니다.\n \t나. 관계법령에 의한 정보보유사유\n \t\t상법,전자상거래 등에서의 소비자보호에 관한 법률 등 관계법령의 규정에 의하여 보존할 필요가 있는 경우, 관계법령에서 정한 일정한 기간동안\n \t\t고객 정보를 보관합니다.\n \t\t이 경우 보관하는 정보를 그 보관의 복적으로만 이용하며 보존기간은 아래와 같습니다.\n \t\t1) 계약 또는 청약철회 등에 관한기록\n \t\t\t가) 보존이유 : 전자상거래 등에서의 소비자보호에 관한 법률\n \t\t\t나) 보존기간 : 5년\n \t\t2) 전자상거래등에서의 소비자보호에 관한 법률\n \t\t\t가) 보존이유 : 통신비밀 보호법\n \t\t\t나) 보존기간 : 3개월\n \t다. 고객은 언제라도 정보 또는 광고의 수신을 거부할 수 있습니다.\n\n 5. 개인정보 자동 수집 장치의 설치/운영에 관한 사항\n \t원할한 app 이용을 위하여 이용자가 특정서비스(스쿨버스, 메시지전송)등을 이용할 경우 기기식별번호(device Id)를 자동으로 수집합니다.\n \t이용자가 수집을 거부하는 경우 app을 이용할 수 없습니다.\n\n 6. 제한\n\t고객은 서비스 이용에 있어 다음과 같은 행위를 하여서는 안됩니다.\n \t가. 관련 법령, 회사의 정책 또는 제 3자의 권리를 위한 또는 침해하는 행위\n \t나. 회사의 업무나 시스템에 악영향을 미칠 수 잇는 행위\n \t다. 회사의 동의없이 콘텐츠를 불법으로 복제, 수정, 배포, 판매하는 행위\n 고객이 서비스 이용과 관련하여 이 약관에서 정한 사항을 위반하거나 프로그램등을 이용하여 데이터를 조작하는 행위를 했을경우, 또한\n 중대한 부정행위의 경우에는 관계법에 의거 처벌받으실 수 있음을 알려드립니다.\n";
        this.lot_info_t = "1. 수집회사 및 연락처\n \t- 회사명 : " + name_info + "\n\t- 연락처 : " + num_info + "\n2. 수집하는 위치정보 및 수집방법\n \t차량 위치추적등 각종 서비스제공을 위해 아래와 같은 위치정보를 수집하고 있습니다.\n \t가. 수집항목\n \t\t위치정보\n \t나. 위치정보 수집방법\n \t\t이용자가 특정서비스(스쿨버스 위치추적 등)를 사용시에만 위치정보를 수집합니다.\n\n 3. 위치정보의 수집 및 이용목적\n \t수집한 위치정보를 다음의 목정을 위해 고지한 범위내에서 사용 및 활용하며, 원칙적으로 이용자의 사전 동의없이는 동 범위를\n \t초과하여 이용하거나 이용자의 개인정보를 외부에 공개하지 않습니다.(단 이용자가 사전에 위치정보 공개에 대하여 동의한 경우와 법령의 규정에\n \t의거하거나, 수사목적으로 법령에 정해진 절차와 방법에 따라 수사기관의 요구가 있는 경우에는 외부에 공개합니다.)\n\n 4. 위치정보의 보유 및 이용기간\n \t위치정보 수집 및 이용목적이 달성된 후에는 해당 정보를 지체 없이 파기합니다.\n \t단, 관계법령의 규정에 의하여 보존할 필요가 있는 경우 회사는 아래와 같이 관계법령에서 정한 일정한 기간 동안 위치정보를 보관합니다.\n \t가. 보존 항목\n \t\t\"2. 수집하는 위치정보 항목 및 수집방법\"중 \"가.수집항목\"의 내용 모두를 보존합니다.\n \t나. 관계법령에 의한 정보보유사유\n \t\t상법,전자상거래 등에서의 소비자보호에 관한 법률 등 관계법령의 규정에 의하여 보존할 필요가 있는 경우, 관계법령에서 정한 일정한 기간동안\n \t\t고객 정보를 보관합니다.\n \t\t이 경우 보관하는 정보를 그 보관의 복적으로만 이용하며 보존기간은 아래와 같습니다.\n \t\t1) 계약 또는 청약철회 등에 관한기록\n \t\t\t가) 보존이유 : 전자상거래 등에서의 소비자보호에 관한 법률\n \t\t\t나) 보존기간 : 5년\n \t\t2) 전자상거래등에서의 소비자보호에 관한 법률\n \t\t\t가) 보존이유 : 통신비밀 보호법\n \t\t\t나) 보존기간 : 3개월\n \t다. 고객은 언제라도 정보 또는 광고의 수신을 거부할 수 있습니다.\n\n 5. 위치정보 자동 수집 장치의 설치/운영에 관한 사항\n \t원할한 app 이용을 위하여 이용자가 특정서비스(스쿨버스)등을 이용할 경우 위치정보를 자동으로 수집합니다.\n \t이용자가 수집을 거부하는 경우 app을 이용할 수 없습니다.";
    }

    public void userInfo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        ScrollView scroll = new ScrollView(this);
        TextView user_memo = new TextView(this);
        user_memo.setText(this.user_info_t);
        user_memo.setTextSize(13.0f);
        scroll.addView(user_memo);
        builder.setTitle(getString(R.string.userInfo_title));
        builder.setView(scroll);
        builder.setPositiveButton(getString(R.string.confirm), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.User_info.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    public void lotInfo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        ScrollView scroll = new ScrollView(this);
        TextView user_memo = new TextView(this);
        user_memo.setText(this.lot_info_t);
        user_memo.setTextSize(13.0f);
        scroll.addView(user_memo);
        builder.setTitle(getString(R.string.userLot_title));
        builder.setView(scroll);
        builder.setPositiveButton(getString(R.string.confirm), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.User_info.5
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }
}
