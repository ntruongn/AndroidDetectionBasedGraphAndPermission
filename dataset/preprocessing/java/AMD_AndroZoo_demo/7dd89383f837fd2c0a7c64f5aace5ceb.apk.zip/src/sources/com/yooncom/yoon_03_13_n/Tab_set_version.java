package com.yooncom.yoon_03_13_n;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.MotionEventCompat;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class Tab_set_version extends Cm implements View.OnClickListener, View.OnTouchListener {
    public static String sub_code;
    public static String sub_newcode;
    private Button newdown;
    private TextView newver;
    private TextView prever;
    int sc;
    int sn;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.yooncom.yoon_03_13_n.Cm, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_set_version);
        sub_code = String.valueOf(versionCode);
        this.sc = sub_code.length();
        sub_code = sub_code.substring(this.sc - 1, this.sc);
        sub_newcode = String.valueOf(newVersionCode);
        this.sn = sub_newcode.length();
        sub_newcode = sub_newcode.substring(this.sn - 1, this.sn);
        this.prever = (TextView) findViewById(R.id.preversion);
        this.newver = (TextView) findViewById(R.id.newversion);
        this.prever.setText(String.valueOf(getString(R.string.pre_version)) + versionName + "." + sub_code);
        this.newver.setText(String.valueOf(getString(R.string.new_version)) + newVersionName + "." + sub_newcode);
        this.newdown = (Button) findViewById(R.id.newversion_down);
        this.newdown.setOnClickListener(this);
        this.newdown.setOnTouchListener(this);
        this.newdown.setBackgroundResource(R.drawable.btn_border_up);
        this.newdown.setTextColor(Color.rgb(0, 0, 0));
        this.newdown.setText(R.string.new_version_down);
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View v, MotionEvent e) {
        if (e.getAction() == 0) {
            this.newdown.setBackgroundResource(R.drawable.btn_border_down);
            this.newdown.setTextColor(Color.rgb((int) MotionEventCompat.ACTION_MASK, (int) MotionEventCompat.ACTION_MASK, (int) MotionEventCompat.ACTION_MASK));
        } else {
            this.newdown.setBackgroundResource(R.drawable.btn_border_up);
            this.newdown.setTextColor(Color.rgb(0, 0, 0));
        }
        return false;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        try {
            if (newVersionCode > versionCode) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(app_url));
                startActivity(intent);
            } else {
                Toast.makeText(this, getString(R.string.is_new_version), 0).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.is_new_version_uploading), 0).show();
        }
    }
}
