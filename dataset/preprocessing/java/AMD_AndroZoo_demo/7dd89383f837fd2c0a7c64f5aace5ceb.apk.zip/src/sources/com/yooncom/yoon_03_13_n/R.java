package com.yooncom.yoon_03_13_n;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public final class R {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static final class attr {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static final class dimen {
        public static final int activity_horizontal_margin = 0x7f040000;
        public static final int activity_vertical_margin = 0x7f040001;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static final class drawable {
        public static final int bgtoggle = 0x7f020000;
        public static final int bracket = 0x7f020001;
        public static final int btn_border_down = 0x7f020002;
        public static final int btn_border_up = 0x7f020003;
        public static final int button_round = 0x7f020004;
        public static final int icon = 0x7f020005;
        public static final int icon_middle = 0x7f020006;
        public static final int launch = 0x7f020007;
        public static final int new_version = 0x7f020008;
        public static final int pushcount = 0x7f020009;
        public static final int pushmsg_round = 0x7f02000a;
        public static final int round_border_bottom = 0x7f02000b;
        public static final int round_border_bottom_down = 0x7f02000c;
        public static final int round_border_bottom_up = 0x7f02000d;
        public static final int round_border_down = 0x7f02000e;
        public static final int round_border_top = 0x7f02000f;
        public static final int round_border_top_down = 0x7f020010;
        public static final int round_border_top_up = 0x7f020011;
        public static final int round_border_up = 0x7f020012;
        public static final int round_no_border = 0x7f020013;
        public static final int switch_off = 0x7f020014;
        public static final int switch_on = 0x7f020015;
        public static final int tab_alarm_img = 0x7f020016;
        public static final int tab_allarticle_img = 0x7f020017;
        public static final int tab_back = 0x7f020018;
        public static final int tab_home_img = 0x7f020019;
        public static final int tab_set_img = 0x7f02001a;
        public static final int title_bar_gradiant = 0x7f02001b;
        public static final int title_bar_shadow = 0x7f02001c;
        public static final int titlebar = 0x7f02001d;
        public static final int unser_info_list = 0x7f02001e;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static final class id {
        public static final int alarm_lay = 0x7f080017;
        public static final int all_lay = 0x7f08001d;
        public static final int app_info = 0x7f080028;
        public static final int btnCancel = 0x7f080016;
        public static final int btnOk = 0x7f080015;
        public static final int home_lay = 0x7f080020;
        public static final int home_layout = 0x7f08001f;
        public static final int launchImg = 0x7f080000;
        public static final int list = 0x7f080035;
        public static final int new_version = 0x7f08000f;
        public static final int newversion = 0x7f080032;
        public static final int newversion_down = 0x7f080033;
        public static final int nonMsg = 0x7f080014;
        public static final int pcPrever = 0x7f08002b;
        public static final int pcPrever_text = 0x7f08002c;
        public static final int prever = 0x7f080029;
        public static final int prever_text = 0x7f08002a;
        public static final int preversion = 0x7f080031;
        public static final int push_alarm_set = 0x7f080023;
        public static final int push_toggleButton = 0x7f08002d;
        public static final int pushcnt = 0x7f08000b;
        public static final int s_off_preview_toggleButton = 0x7f08002e;
        public static final int setTitle = 0x7f08001a;
        public static final int setTitle_gra = 0x7f080019;
        public static final int setTitle_img = 0x7f080018;
        public static final int setTitle_shadow = 0x7f08001b;
        public static final int set_alarm = 0x7f080024;
        public static final int set_alarm_text = 0x7f080025;
        public static final int set_lay = 0x7f080022;
        public static final int sound_alarm_toggleButton = 0x7f080030;
        public static final int tab_alarm_btn = 0x7f080009;
        public static final int tab_alarm_img = 0x7f08000a;
        public static final int tab_alarm_txt = 0x7f08000c;
        public static final int tab_allarticle_btn = 0x7f080006;
        public static final int tab_allarticle_img = 0x7f080007;
        public static final int tab_allarticle_txt = 0x7f080008;
        public static final int tab_home_btn = 0x7f080003;
        public static final int tab_home_img = 0x7f080004;
        public static final int tab_home_txt = 0x7f080005;
        public static final int tab_layout = 0x7f080002;
        public static final int tab_set_btn = 0x7f08000d;
        public static final int tab_set_img = 0x7f08000e;
        public static final int tab_set_txt = 0x7f080010;
        public static final int test_image = 0x7f080011;
        public static final int txtMsg = 0x7f080012;
        public static final int txtTitle = 0x7f080013;
        public static final int user_title = 0x7f080034;
        public static final int vibrate_alarm_toggleButton = 0x7f08002f;
        public static final int view_fragment = 0x7f080001;
        public static final int viewpager_set_toggleButton = 0x7f080027;
        public static final int viewpager_text = 0x7f080026;
        public static final int webview_alram = 0x7f08001c;
        public static final int webview_board = 0x7f08001e;
        public static final int webview_home = 0x7f080021;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static final class layout {
        public static final int load_img = 0x7f030000;
        public static final int main = 0x7f030001;
        public static final int pushmsg = 0x7f030002;
        public static final int pushmsg_lock = 0x7f030003;
        public static final int tab_alarm = 0x7f030004;
        public static final int tab_allarticle = 0x7f030005;
        public static final int tab_home = 0x7f030006;
        public static final int tab_set = 0x7f030007;
        public static final int tab_set_alarm = 0x7f030008;
        public static final int tab_set_version = 0x7f030009;
        public static final int user_info = 0x7f03000a;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static final class menu {
        public static final int main = 0x7f070000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static final class string {
        public static final int album = 0x7f050020;
        public static final int app_name = 0x7f050001;
        public static final int app_server = 0x7f050000;
        public static final int camera = 0x7f05001f;
        public static final int cancle = 0x7f05001d;
        public static final int confirm = 0x7f05001c;
        public static final int datanetwork_warning = 0x7f050003;
        public static final int end = 0x7f050027;
        public static final int gps_connect = 0x7f050022;
        public static final int gps_connecting = 0x7f050023;
        public static final int is_alarm_receive = 0x7f050029;
        public static final int is_back_end = 0x7f050028;
        public static final int is_file = 0x7f05002c;
        public static final int is_gps = 0x7f050024;
        public static final int is_loading = 0x7f05002a;
        public static final int is_lot_info = 0x7f050034;
        public static final int is_new_version = 0x7f05002f;
        public static final int is_new_version_uploading = 0x7f050031;
        public static final int is_page_loding = 0x7f050025;
        public static final int is_photo_save = 0x7f05001b;
        public static final int is_photo_saving = 0x7f05001e;
        public static final int is_push_alarm = 0x7f050014;
        public static final int is_pushservice_no = 0x7f05002b;
        public static final int is_user_info = 0x7f050033;
        public static final int is_user_info_confirm = 0x7f050037;
        public static final int is_user_info_confirm2 = 0x7f050038;
        public static final int new_version = 0x7f05002e;
        public static final int new_version_down = 0x7f050030;
        public static final int no_network = 0x7f050004;
        public static final int pc_page_no = 0x7f050032;
        public static final int photo_down_complete = 0x7f05001a;
        public static final int photo_upload = 0x7f050021;
        public static final int pre_version = 0x7f05002d;
        public static final int push_alarm = 0x7f05000c;
        public static final int push_alarm_help = 0x7f05000d;
        public static final int retry = 0x7f050026;
        public static final int s_off_preview_alarm = 0x7f05000e;
        public static final int s_off_preview_alarm_help = 0x7f05000f;
        public static final int set = 0x7f050015;
        public static final int set_alarm = 0x7f050016;
        public static final int set_app_info = 0x7f050017;
        public static final int set_pc_version = 0x7f050019;
        public static final int set_pre_version = 0x7f050018;
        public static final int site_no = 0x7f050002;
        public static final int sound_alarm = 0x7f050012;
        public static final int sound_alarm_help = 0x7f050013;
        public static final int tab_alarm_title = 0x7f050007;
        public static final int tab_allarticle_title = 0x7f050006;
        public static final int tab_home_title = 0x7f050005;
        public static final int tab_set_title = 0x7f050008;
        public static final int userInfo_title = 0x7f05000a;
        public static final int userLot_title = 0x7f05000b;
        public static final int user_info_confirm = 0x7f050035;
        public static final int user_info_confirm_no = 0x7f050036;
        public static final int user_info_title = 0x7f050009;
        public static final int vibrate_alarm = 0x7f050010;
        public static final int vibrate_alarm_help = 0x7f050011;
        public static final int viewpager_set = 0x7f05003a;
        public static final int viewpager_text = 0x7f050039;
        public static final int viewpager_text_help = 0x7f05003b;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static final class style {
        public static final int AppBaseTheme = 0x7f060000;
        public static final int AppTheme = 0x7f060001;
        public static final int Theme_pushDialog = 0x7f060002;
        public static final int Theme_pushDialogBlack = 0x7f060003;
    }
}
