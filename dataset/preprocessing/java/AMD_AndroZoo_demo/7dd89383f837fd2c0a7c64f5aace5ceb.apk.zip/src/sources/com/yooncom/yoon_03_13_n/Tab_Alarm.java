package com.yooncom.yoon_03_13_n;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieSyncManager;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class Tab_Alarm extends Fragment implements View.OnClickListener {
    private static final int FILECHOOSER_RESULTCODE = 1;
    public static View setTitleShadow;
    public static WebView wb;
    Cm cmActivity;
    private ValueCallback<Uri> mUploadMessage;
    Main mainActivity;
    public ImageView setTitle_img;
    public TextView setTitle_text;
    public ImageView setTtitle_Gra;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.tab_alarm, container, false);
        this.cmActivity = (Cm) Cm.CmActivity;
        this.mainActivity = (Main) Main.mainActivity;
        set_titlebar(v);
        initWeb(Cm.alarm_url, v);
        return v;
    }

    public void set_titlebar(View v) {
        if (this.cmActivity.setTitleBar().booleanValue()) {
            this.setTitle_text = (TextView) v.findViewById(R.id.setTitle);
            this.setTitle_img = (ImageView) v.findViewById(R.id.setTitle_img);
            this.setTtitle_Gra = (ImageView) v.findViewById(R.id.setTitle_gra);
            setTitleShadow = v.findViewById(R.id.setTitle_shadow);
            this.setTitle_img.setAdjustViewBounds(true);
            this.setTitle_img.setScaleType(ImageView.ScaleType.FIT_XY);
            this.setTitle_text.setTextColor(Color.parseColor(Cm.title_font_color));
            this.setTitle_text.setText(R.string.tab_alarm_title);
            this.setTitle_text.setOnClickListener(this);
            this.setTitle_img.setOnClickListener(this);
            this.setTtitle_Gra.setOnClickListener(this);
            if (!Cm.title_user_img_src.equals("")) {
                this.setTitle_img.setImageBitmap(Cm.bitMap);
                Log.d("checktitle", "유져타이틀");
            } else if (!Cm.title_bg_color.equals("")) {
                this.setTitle_img.setBackgroundColor(Color.parseColor(Cm.title_bg_color));
                Log.d("checktitle", "상단배경색");
            } else if (!Cm.title_img_src.equals("")) {
                this.setTitle_img.setImageBitmap(Cm.bitMap);
                Log.d("checktitle", "스킨");
            } else if (!Cm.back_user_img_src.equals("")) {
                if (!Cm.back_pattern.equals("Y")) {
                    this.setTitle_img.setImageBitmap(Cm.bitMap);
                }
            } else if (!Cm.back_bg_color.equals("")) {
                this.setTitle_img.setBackgroundColor(Color.parseColor(Cm.back_bg_color));
            } else if (!Cm.back_img_src.equals("")) {
                this.setTitle_img.setImageBitmap(Cm.bitMap);
            }
            if (!Cm.title_grad.equals("Y")) {
                this.setTtitle_Gra.setVisibility(8);
            }
            if (!Cm.title_shadow.equals("Y")) {
                setTitleShadow.setVisibility(8);
            }
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    @TargetApi(11)
    private void initWeb(String url, View v) {
        wb = (WebView) v.findViewById(R.id.webview_alram);
        wb.getSettings().setJavaScriptEnabled(true);
        wb.getSettings().setGeolocationEnabled(true);
        wb.addJavascriptInterface(new CmJavascript(getActivity()), "android");
        wb.getSettings().setLoadsImagesAutomatically(true);
        wb.getSettings().setCacheMode(0);
        wb.getSettings().setSupportZoom(true);
        wb.getSettings().setBuiltInZoomControls(true);
        wb.getSettings().setSupportMultipleWindows(false);
        wb.getSettings().setSaveFormData(false);
        wb.getSettings().setSavePassword(false);
        wb.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        wb.setHorizontalScrollBarEnabled(false);
        wb.setVerticalScrollBarEnabled(true);
        wb.setVerticalScrollbarOverlay(true);
        wb.getSettings().setDomStorageEnabled(true);
        wb.setWebChromeClient(new ChromeClient(getActivity()));
        if (Build.VERSION.SDK_INT >= 11) {
            getActivity().getWindow().setFlags(ViewCompat.MEASURED_STATE_TOO_SMALL, ViewCompat.MEASURED_STATE_TOO_SMALL);
            wb.getSettings().setDisplayZoomControls(false);
        }
        wb.loadUrl(url);
        wb.setWebViewClient(new wbClient(this, null));
        wb.setWebChromeClient(new ChromeClient(getActivity()) { // from class: com.yooncom.yoon_03_13_n.Tab_Alarm.1
            @Override // android.webkit.WebChromeClient
            public void onCloseWindow(WebView window) {
                super.onCloseWindow(window);
                onHideCustomView();
            }

            @Override // android.webkit.WebChromeClient
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            public void openFileChooser(ValueCallback<Uri> uploadFile, String acceptType) {
                openFileChooser(uploadFile);
            }

            public void openFileChooser(ValueCallback<Uri> uploadMsg) {
                Tab_Alarm.this.mUploadMessage = uploadMsg;
                Intent i = new Intent("android.intent.action.GET_CONTENT");
                i.addCategory("android.intent.category.OPENABLE");
                i.setType("image/*");
                Tab_Alarm.this.startActivityForResult(Intent.createChooser(i, Tab_Alarm.this.getString(R.string.is_file)), 1);
            }

            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
                openFileChooser(uploadMsg, "");
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public class wbClient extends WebViewClient {
        private wbClient() {
        }

        /* synthetic */ wbClient(Tab_Alarm tab_Alarm, wbClient wbclient) {
            this();
        }

        @Override // android.webkit.WebViewClient
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, 0, description, "");
            AlertDialog.Builder alert = new AlertDialog.Builder(Tab_Alarm.this.getActivity());
            alert.setMessage(Tab_Alarm.this.getString(R.string.no_network));
            alert.setPositiveButton(Tab_Alarm.this.getString(R.string.retry), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Tab_Alarm.wbClient.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                    Tab_Alarm.wb.reload();
                }
            });
            alert.setNegativeButton(Tab_Alarm.this.getString(R.string.end), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Tab_Alarm.wbClient.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                    SharedPreferences sp = Tab_Alarm.this.getActivity().getSharedPreferences("app_on", 0);
                    SharedPreferences.Editor is_app = sp.edit();
                    is_app.putBoolean("on", false);
                    is_app.commit();
                    Main mainActivity = (Main) Main.mainActivity;
                    mainActivity.finish();
                }
            });
            alert.show();
        }

        @Override // android.webkit.WebViewClient
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            CookieSyncManager.getInstance().sync();
            if (!Cm.is_lock_screen && !Cm.gps_started && Cm.mWakeLock != null && Cm.mWakeLock.isHeld()) {
                Cm.mWakeLock.release();
            }
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url.startsWith("http://")) {
                Cm.is_lock_screen = false;
                try {
                    URL urlNew = new URL(url);
                    URL urlCurrent = new URL(Cm.alarm_url);
                    if (urlNew.getHost().equals(urlCurrent.getHost())) {
                        if (url.contains("alarm") || url.contains("site_logout")) {
                            view.loadUrl(url);
                        } else if (url.contains("join") || url.contains("modify") || url.contains("agreement") || url.contains("privacy") || url.contains("login")) {
                            view.loadUrl(Cm.alarm_url);
                            Tab_Home.wb.loadUrl(url);
                            Cm.showLoading(Tab_Alarm.this.getString(R.string.is_page_loding), Tab_Alarm.this.getActivity());
                            Main.mCurrentFragmentIndex = 0;
                            Tab_Alarm.this.mainActivity.fragmentReplace(0);
                            Tab_Alarm.this.mainActivity.tab_on_set(0);
                        } else if (url.contains("%")) {
                            view.loadUrl(Cm.alarm_url);
                            Tab_Home.wb.reload();
                            Tab_Allarticle.wb.reload();
                        } else if (url.contains("idx")) {
                            view.loadUrl(Cm.alarm_url);
                            Tab_Home.wb.loadUrl(url);
                            Cm.showLoading(Tab_Alarm.this.getString(R.string.is_page_loding), Tab_Alarm.this.getActivity());
                            Main.mCurrentFragmentIndex = 0;
                            Tab_Alarm.this.mainActivity.fragmentReplace(0);
                            Tab_Alarm.this.mainActivity.tab_on_set(0);
                        } else if (url.contains("message")) {
                            view.loadUrl(Cm.alarm_url);
                            Tab_Home.wb.loadUrl(url);
                            Cm.showLoading(Tab_Alarm.this.getString(R.string.is_page_loding), Tab_Alarm.this.getActivity());
                            Main.mCurrentFragmentIndex = 0;
                            Tab_Alarm.this.mainActivity.fragmentReplace(0);
                            Tab_Alarm.this.mainActivity.tab_on_set(0);
                        } else {
                            view.loadUrl(String.valueOf(url) + "alarm");
                            Tab_Home.wb.reload();
                            Tab_Allarticle.wb.reload();
                        }
                    } else {
                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.setData(Uri.parse(url));
                        Tab_Alarm.this.startActivity(intent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return true;
            }
            Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse(url));
            intent2.addCategory("android.intent.category.BROWSABLE");
            intent2.putExtra("com.android.browser.application_id", Tab_Alarm.this.getActivity().getPackageName());
            if (url.startsWith("sms:")) {
                Tab_Alarm.this.startActivity(new Intent("android.intent.action.SENDTO", Uri.parse(url)));
                return true;
            }
            if (url.startsWith("tel:")) {
                Tab_Alarm.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse(url)));
                return true;
            }
            if (url.startsWith("mailto:")) {
                Tab_Alarm.this.startActivity(new Intent("android.intent.action.SENDTO", Uri.parse(url)));
                return true;
            }
            if (url.startsWith("newwin:")) {
                Intent i = new Intent("android.intent.action.VIEW");
                i.setData(Uri.parse(url.replace("newwin:", "http:")));
                Tab_Alarm.this.startActivity(i);
                return true;
            }
            try {
                Tab_Alarm.this.startActivity(intent2);
                return true;
            } catch (ActivityNotFoundException e2) {
                return false;
            }
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        if (v.getId() == this.setTitle_text.getId() || v.getId() == this.setTitle_img.getId() || v.getId() == this.setTtitle_Gra.getId()) {
            wb.loadUrl(Cm.alarm_url);
        }
    }
}
