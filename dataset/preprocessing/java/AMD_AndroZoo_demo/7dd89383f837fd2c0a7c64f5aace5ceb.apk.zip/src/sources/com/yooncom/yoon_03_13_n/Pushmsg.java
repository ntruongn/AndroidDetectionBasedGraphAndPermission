package com.yooncom.yoon_03_13_n;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.util.Timer;
import java.util.TimerTask;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class Pushmsg extends Activity {
    Context con;
    PendingIntent content;
    Intent i;
    Main mainActivity;
    NotificationManager nm;
    Notification not;
    private PowerManager pm;
    private Timer timerClose;
    TextView txtMsg;
    public static int pushCount = 0;
    public static int _pushcount = 0;
    public static int main_menu_code = 0;
    public static boolean is_app = false;
    private long keep_time = 3000;
    private String msg = "";
    String msgTitle = "";
    String tag = "";
    String xmlMsg = "";
    Boolean push_check = true;
    Boolean s_off_pre_ck = true;
    Boolean s_on_pre_ck = true;
    Boolean vibrate_alarm_ck = true;
    Boolean sound_alarm_ck = true;
    Boolean top_alarm_ck = true;
    int parserEvent = 0;
    TimerTask timerTask = new TimerTask() { // from class: com.yooncom.yoon_03_13_n.Pushmsg.1
        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            Pushmsg.this.finish();
        }
    };

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:35:0x0241 -> B:16:0x00aa). Please submit an issue!!! */
    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        Log.d("test", "t3");
        SharedPreferences pref = getSharedPreferences("menucode_check", 0);
        main_menu_code = pref.getInt("menucode", 0);
        SharedPreferences pref2 = getSharedPreferences("app_on", 0);
        is_app = pref2.getBoolean("on", false);
        this.pm = (PowerManager) getSystemService("power");
        SharedPreferences pushAlarmSet = getSharedPreferences("pushAlarmSet", 0);
        this.xmlMsg = "";
        this.push_check = Boolean.valueOf(pushAlarmSet.getBoolean("push_alarm", true));
        if (this.push_check.booleanValue()) {
            this.xmlMsg = getIntent().getStringExtra("msg");
        } else {
            this.xmlMsg = "";
        }
        try {
            XmlPullParserFactory parserCreator = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserCreator.newPullParser();
            ByteArrayInputStream xmlMsgStream = new ByteArrayInputStream(this.xmlMsg.getBytes());
            parser.setInput(xmlMsgStream, null);
            this.parserEvent = parser.getEventType();
            while (this.parserEvent != 1) {
                switch (this.parserEvent) {
                    case 2:
                        this.tag = parser.getName();
                        Log.d("xml parsing", "START_TAG - " + this.tag);
                        break;
                    case 3:
                        this.tag = parser.getName();
                        Log.d("xml parsing", "END_TAG - " + this.tag);
                        break;
                    case 4:
                        Log.d("xml parsing", "TEXT - " + this.tag);
                        if (this.tag.compareTo("msg") == 0) {
                            this.msg = parser.getText().toString();
                            break;
                        } else if (this.tag.compareTo("title") == 0) {
                            this.msgTitle = parser.getText().toString();
                            break;
                        } else if (this.tag.compareTo("count") != 0) {
                            break;
                        } else {
                            pushCount = Integer.parseInt(parser.getText().toString());
                            _pushcount = Integer.parseInt(parser.getText().toString());
                            break;
                        }
                }
                this.parserEvent = parser.next();
            }
        } catch (Exception e) {
            Log.d("xml parsing", "Error in network call" + e);
        }
        if (!this.pm.isScreenOn()) {
            try {
                Log.d("push", "screen off");
                super.setTheme(R.style.Theme_pushDialogBlack);
                super.onCreate(savedInstanceState);
                this.s_off_pre_ck = Boolean.valueOf(pushAlarmSet.getBoolean("s_off_preview", true));
                if (this.s_off_pre_ck.booleanValue()) {
                    s_off_pre();
                } else {
                    finish();
                }
            } catch (Exception e2) {
            }
        } else {
            try {
                Log.d("push", "screen on");
                super.setTheme(R.style.Theme_pushDialog);
                super.onCreate(savedInstanceState);
                this.s_on_pre_ck = Boolean.valueOf(pushAlarmSet.getBoolean("s_on_preview", true));
                if (is_app) {
                    Main.is_push_msg();
                }
                finish();
            } catch (Exception e3) {
            }
        }
        try {
            this.nm = (NotificationManager) getSystemService("notification");
            this.con = getApplicationContext();
            this.i = new Intent(this.con, (Class<?>) Main.class);
            this.i.addFlags(1006698496);
            Log.d("test", String.valueOf(this.i.getAction()));
            this.i.putExtra("fromPush", true);
            this.content = PendingIntent.getActivity(this.con, 0, this.i, 134217728);
            this.top_alarm_ck = Boolean.valueOf(pushAlarmSet.getBoolean("top_alarm", true));
            if (this.top_alarm_ck.booleanValue()) {
                sound_alarm();
            } else {
                this.not = new Notification();
            }
            this.vibrate_alarm_ck = Boolean.valueOf(pushAlarmSet.getBoolean("vibrate_alarm", true));
            this.sound_alarm_ck = Boolean.valueOf(pushAlarmSet.getBoolean("sound_alarm", true));
            if (this.vibrate_alarm_ck.booleanValue()) {
                this.not.defaults |= 2;
            }
            if (this.sound_alarm_ck.booleanValue()) {
                this.not.defaults |= 1;
            }
            this.not.flags |= 16;
            this.nm.notify(0, this.not);
        } catch (Exception e4) {
            Toast.makeText(this, "not Error" + e4.toString(), 0).show();
        }
        if (this.keep_time > 0) {
            this.timerClose = new Timer();
            this.timerClose.schedule(new TimerTask() { // from class: com.yooncom.yoon_03_13_n.Pushmsg.2
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    Pushmsg.this.timerClose.cancel();
                    Pushmsg.this.finish();
                }
            }, this.keep_time);
        }
    }

    public void sound_alarm() {
        if (pushCount > 1) {
            this.not = new Notification(R.drawable.icon, getString(R.string.app_name), System.currentTimeMillis());
            this.not.number = pushCount;
            this.not.setLatestEventInfo(this.con, getString(R.string.app_name), String.valueOf(pushCount) + getString(R.string.is_alarm_receive), this.content);
            return;
        }
        this.not = new Notification(R.drawable.icon, this.msgTitle, System.currentTimeMillis());
        this.not.number = pushCount;
        this.not.setLatestEventInfo(this.con, this.msgTitle, this.msg, this.content);
    }

    public void s_off_pre() {
        setContentView(R.layout.pushmsg_lock);
        getWindow().addFlags(2621568);
        Button btnOK = (Button) findViewById(R.id.btnOk);
        Button btnCancel = (Button) findViewById(R.id.btnCancel);
        btnOK.setOnClickListener(new View.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Pushmsg.3
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                Log.d("test", String.valueOf(Pushmsg.is_app));
                Intent intent = new Intent(Pushmsg.this, (Class<?>) Main.class);
                intent.putExtra("fromPush", true);
                Pushmsg.this.startActivity(intent);
                Pushmsg.this.finish();
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Pushmsg.4
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                if (Pushmsg.is_app) {
                    try {
                        Main mainAct = (Main) Main.mainActivity;
                        mainAct.finish();
                    } catch (Exception e) {
                    }
                }
                NotificationManager nm = (NotificationManager) Pushmsg.this.getSystemService("notification");
                nm.cancel(0);
                Pushmsg.this.finish();
            }
        });
        this.keep_time = 0L;
        TextView txtTitle = (TextView) findViewById(R.id.txtTitle);
        TextView txtMsg = (TextView) findViewById(R.id.txtMsg);
        txtTitle.setText(this.msgTitle);
        txtMsg.setText(this.msg);
        Timer timer = new Timer();
        timer.schedule(this.timerTask, 45000L);
    }
}
