package com.yooncom.yoon_03_13_n;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.ExifInterface;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.widget.Toast;
import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.ExecutionException;

@SuppressLint({"HandlerLeak"})
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class Cm extends FragmentActivity {
    static Activity CmActivity = null;
    public static final int PICK_FROM_ALBUM = 200;
    public static final int PICK_FROM_CAMERA = 100;
    public static Bitmap bitMap;
    public static String downloadImgFileName;
    public static String downloadImgUrl;
    public static ProgressDialog loading;
    static PowerManager.WakeLock mWakeLock;
    public static Send_img_Task send_img_task;
    static String[] test;
    public static ProgressDialog upImg;
    public ProgressDialog gpsLoading;
    public LocationListener mGPSListener;
    public GpsStatus.Listener mGPSStatus;
    public File mImageCaptureUri;
    public LocationManager mLocationManager;
    Title_image title_image;
    public static boolean fullscreen = false;
    public static int menuCode = 0;
    private static FileInputStream mFileInputStream = null;
    private static URL connectUrl = null;
    static String cameraImgName = "";
    static String albumImgName = "";
    public static String up_thumb_img = "";
    public static String up_file_name = "";
    static String lineEnd = "\r\n";
    static String twoHyphens = "--";
    static String boundary = "*****";
    static String s_filename = "";
    static String s_thumb = "";
    public static String url = null;
    public static String home_url = null;
    public static String allarticle_url = null;
    public static String alarm_url = null;
    public static String device_id = null;
    public static int member = -1;
    public static boolean is_lock_screen = false;
    public static boolean gps_started = false;
    public static boolean isLoading = false;
    public static int versionCode = 0;
    public static int newVersionCode = 0;
    public static String versionName = null;
    public static String newVersionName = null;
    public static String app_url = "";
    public static String pc_url = "";
    public static int pushcount = 0;
    public static String is_info = null;
    public static String name_info = null;
    public static String num_info = null;
    public static String title_url = "";
    public static String title_img_src = "";
    public static String title_font_color = "";
    public static String title_bg_color = "";
    public static String title_grad = "";
    public static String title_shadow = "";
    public static String title_user_img_src = "";
    public static String back_img_src = "";
    public static String back_user_img_src = "";
    public static String back_bg_color = "";
    public static String back_pattern = "";
    public static String tab_point_color = "#0078ff";
    public static String b2b_name = "";
    public static String b2b_cal = "";
    public static String API_URL = "";
    public static String IMG_URL = "";
    public static String skin_url = "";
    public static boolean isRegister = false;
    public static String TEMP_FILE_DIR = "/.cm/";
    public static String File_temp = "";
    static String urlString = "";
    static String params = "";
    static String fileName = "";
    static Boolean is_swipe = true;
    static URL imageURL = null;
    boolean isUpImg = true;
    public boolean gps_connected = false;
    public boolean isGpsLoading = false;
    Boolean viewpager_set_ck = true;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CmActivity = this;
        PackageManager packageManager = getPackageManager();
        PackageInfo infor = null;
        try {
            infor = packageManager.getPackageInfo(getPackageName(), 128);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        versionCode = infor.versionCode;
        versionName = infor.versionName;
        if (getString(R.string.app_server).contentEquals("real")) {
            API_URL = "http://cocoam.co.kr/api/";
            IMG_URL = "http://cocoam.co.kr/mobile/";
            skin_url = "http://cocoam.co.kr/upload_skin/";
        } else {
            API_URL = "http://testcocoa.com/api/";
            IMG_URL = "http://testcocoa.com/mobile/";
            skin_url = "http://testcocoa.com/upload_skin/";
        }
        is_folder();
        SharedPreferences pref = getSharedPreferences("pushAlarmSet", 0);
        this.viewpager_set_ck = Boolean.valueOf(pref.getBoolean("viewpager_alarm", true));
    }

    @SuppressLint({"NewApi"})
    public Boolean setTitleBar() {
        if (CmApi.setTitleInfo(getString(R.string.site_no))) {
            try {
                if (!title_user_img_src.equals("")) {
                    title_url = title_user_img_src;
                } else if (!title_img_src.equals("")) {
                    title_url = title_img_src;
                } else if (!back_user_img_src.equals("")) {
                    title_url = back_user_img_src;
                } else if (!back_img_src.equals("")) {
                    title_url = back_img_src;
                }
                imageURL = new URL(String.valueOf(skin_url) + title_url);
                this.title_image = new Title_image();
                try {
                    this.title_image.execute(new String[0]).get();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e2) {
                    e2.printStackTrace();
                }
                return true;
            } catch (IOException e3) {
                e3.printStackTrace();
            }
        }
        return false;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static class Title_image extends AsyncTask<String, String, String> {
        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... params) {
            try {
                URLConnection conn = Cm.imageURL.openConnection();
                conn.connect();
                InputStream is = conn.getInputStream();
                BufferedInputStream bis = new BufferedInputStream(is);
                Cm.bitMap = BitmapFactory.decodeStream(bis);
                bis.close();
                is.close();
                return null;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String result) {
            super.onPostExecute((Title_image) result);
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            super.onCancelled();
        }
    }

    public static void showLoading(String msg, Context context) {
        hideLoading();
        isLoading = true;
        loading = new ProgressDialog(context);
        loading.setMessage(msg);
        loading.setCancelable(false);
        loading.show();
    }

    public static void hideLoading() {
        if (isLoading) {
            isLoading = false;
            loading.dismiss();
        }
    }

    public static void showAlert(Context context, String msg) {
        Toast.makeText(context, msg.toString(), 1).show();
    }

    @SuppressLint({"SdCardPath"})
    public void is_folder() {
        String str = Environment.getExternalStorageState();
        if (str.equals("mounted")) {
            String dirPath = "/sdcard" + TEMP_FILE_DIR;
            File file = new File(dirPath);
            if (!file.exists()) {
                file.mkdirs();
                Log.d("img", "폴더 생성");
            } else {
                Log.d("img", "폴더 있음");
            }
            media_scan(file);
            return;
        }
        Toast.makeText(this, "SD Card 인식 실패", 0).show();
    }

    public void media_scan(File file) {
        MediaScannerConnection.scanFile(this, new String[]{file.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() { // from class: com.yooncom.yoon_03_13_n.Cm.1
            @Override // android.media.MediaScannerConnection.OnScanCompletedListener
            public void onScanCompleted(String path, Uri uri) {
                Log.d("ExternalStorage", "Scanned " + path + ":");
                Log.d("ExternalStorage", "-> uri=" + uri);
            }
        });
    }

    public void up_img() {
        try {
            String mFilePath = "";
            if (menuCode == 100) {
                mFilePath = Environment.getExternalStorageDirectory() + TEMP_FILE_DIR + cameraImgName;
            } else if (menuCode == 200) {
                mFilePath = albumImgName;
            }
            int img_rotate = imgOrientation(mFilePath);
            BitmapFactory.Options options = new BitmapFactory.Options();
            Bitmap src = BitmapFactory.decodeFile(mFilePath, options);
            int width = src.getWidth();
            int height = src.getHeight();
            Matrix matrix = new Matrix();
            float width_ratio = 1024.0f / width;
            float height_ratio = 2000.0f / height;
            if (width_ratio >= 1.0f && height_ratio >= 1.0f) {
                matrix.setRotate(img_rotate);
            } else {
                float ratio = width_ratio < height_ratio ? width_ratio : height_ratio;
                matrix.setRotate(img_rotate);
                matrix.postScale(ratio, ratio);
            }
            Bitmap resizeSrc = Bitmap.createBitmap(src, 0, 0, width, height, matrix, true);
            File file = null;
            if (menuCode == 100) {
                file = new File(Environment.getExternalStorageDirectory(), String.valueOf(TEMP_FILE_DIR) + cameraImgName);
            } else if (menuCode == 200) {
                String[] fname1 = albumImgName.split("/");
                String fname = fname1[fname1.length - 1];
                String fpath = Environment.getExternalStorageDirectory() + TEMP_FILE_DIR + "cm_" + fname;
                mFilePath = fpath;
                file = new File(mFilePath);
            }
            File_temp = mFilePath;
            FileOutputStream out = new FileOutputStream(file);
            resizeSrc.compress(Bitmap.CompressFormat.JPEG, 100, out);
            media_scan(file);
            Log.d("img", file + " / " + resizeSrc);
            DoFileUpload(mFilePath);
        } catch (Exception e) {
        }
    }

    private void DoFileUpload(String filePath) throws IOException {
        HttpFileUpload(String.valueOf(CmApi.IMG_URL) + "android_img_up.cm", "", filePath);
    }

    private void HttpFileUpload(String UrlString, String Params, String FileName) {
        urlString = UrlString;
        params = Params;
        fileName = FileName;
        send_img_task = new Send_img_Task();
        send_img_task.execute(new String[0]);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static class Send_img_Task extends AsyncTask<String, String, String> {
        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... params) {
            try {
                Cm.mFileInputStream = new FileInputStream(Cm.fileName);
                Cm.connectUrl = new URL(Cm.urlString);
                HttpURLConnection conn = (HttpURLConnection) Cm.connectUrl.openConnection();
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setUseCaches(false);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + Cm.boundary);
                DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
                dos.writeBytes(String.valueOf(Cm.twoHyphens) + Cm.boundary + Cm.lineEnd);
                dos.writeBytes("Content-Disposition: form-data; name=\"file\";filename=\"" + Cm.fileName + "\"" + Cm.lineEnd);
                dos.writeBytes(Cm.lineEnd);
                int bytesAvailable = Cm.mFileInputStream.available();
                int bufferSize = Math.min(bytesAvailable, 1024);
                byte[] buffer = new byte[bufferSize];
                int bytesRead = Cm.mFileInputStream.read(buffer, 0, bufferSize);
                while (bytesRead > 0) {
                    dos.write(buffer, 0, bufferSize);
                    int bytesAvailable2 = Cm.mFileInputStream.available();
                    bufferSize = Math.min(bytesAvailable2, 1024);
                    bytesRead = Cm.mFileInputStream.read(buffer, 0, bufferSize);
                }
                dos.writeBytes(Cm.lineEnd);
                dos.writeBytes(String.valueOf(Cm.twoHyphens) + Cm.boundary + Cm.twoHyphens + Cm.lineEnd);
                Cm.mFileInputStream.close();
                dos.flush();
                InputStream is = conn.getInputStream();
                StringBuffer b = new StringBuffer();
                while (true) {
                    int ch = is.read();
                    if (ch != -1) {
                        b.append((char) ch);
                    } else {
                        String s = b.toString();
                        Cm.test = s.split(",");
                        Cm.s_filename = Cm.test[0];
                        Cm.s_thumb = Cm.test[1];
                        Cm.upImg.dismiss();
                        dos.close();
                        return null;
                    }
                }
            } catch (Exception e) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String result) {
            super.onPostExecute((Send_img_Task) result);
            Tab_Home.wb.loadUrl("javascript:board_upload_image_complete('" + Cm.s_filename + "','" + Cm.s_thumb + "')");
            if (Cm.menuCode == 100 || Cm.menuCode == 200) {
                File file = new File(Cm.File_temp);
                if (file.exists()) {
                    file.delete();
                    Log.d("img", "삭제");
                }
            }
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            super.onCancelled();
        }
    }

    public static synchronized int imgOrientation(String filepath) {
        int degree;
        synchronized (Cm.class) {
            degree = 0;
            ExifInterface exif = null;
            try {
                ExifInterface exif2 = new ExifInterface(filepath);
                exif = exif2;
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (exif != null) {
                int orientation = exif.getAttributeInt("Orientation", -1);
                if (orientation != -1) {
                    switch (orientation) {
                        case 3:
                            degree = 180;
                            break;
                        case 6:
                            degree = 90;
                            break;
                        case 8:
                            degree = 270;
                            break;
                    }
                }
            }
        }
        return degree;
    }

    public String getRealPathFromURI(Uri contentUri) {
        String[] proj = {"_data"};
        Cursor cursor = managedQuery(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow("_data");
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public void update_gps(Location location) {
        double lat = location.getLatitude();
        double lon = location.getLongitude();
        this.gps_connected = true;
        CmApi.update_gps(getString(R.string.site_no), String.valueOf(lat), String.valueOf(lon));
        Log.d("GPS", "Latitude - " + lat + ", Longitude - " + lon);
    }

    public void start_gps() {
        if (!gps_started) {
            gps_started = true;
            this.mLocationManager = (LocationManager) getSystemService("location");
            show_gps_progress();
            this.mGPSListener = new LocationListener() { // from class: com.yooncom.yoon_03_13_n.Cm.2
                @Override // android.location.LocationListener
                public void onLocationChanged(Location location) {
                    if (!Cm.this.gps_connected) {
                        Cm.this.hide_gps_progress();
                        Toast.makeText(Cm.this, Cm.this.getString(R.string.gps_connect), 1).show();
                    }
                    Cm.this.update_gps(location);
                }

                @Override // android.location.LocationListener
                public void onProviderDisabled(String provider) {
                    Cm.this.hide_gps_progress();
                    Log.d("GPS", "disabled");
                    AlertDialog.Builder alert = new AlertDialog.Builder(Cm.this);
                    alert.setMessage(Cm.this.getString(R.string.is_gps));
                    alert.setPositiveButton(Cm.this.getString(R.string.confirm), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Cm.2.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            Intent gpsOptionsIntent = new Intent("android.settings.LOCATION_SOURCE_SETTINGS");
                            Cm.this.startActivity(gpsOptionsIntent);
                        }
                    });
                    alert.setNegativeButton(Cm.this.getString(R.string.cancle), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Cm.2.2
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    alert.show();
                }

                @Override // android.location.LocationListener
                public void onProviderEnabled(String provider) {
                    Log.d("GPS", "enabled");
                    Cm.this.show_gps_progress();
                }

                @Override // android.location.LocationListener
                public void onStatusChanged(String provider, int status, Bundle extras) {
                    Log.d("GPS", "status change" + status);
                }
            };
            this.mGPSStatus = new GpsStatus.Listener() { // from class: com.yooncom.yoon_03_13_n.Cm.3
                @Override // android.location.GpsStatus.Listener
                public void onGpsStatusChanged(int event) {
                    switch (event) {
                        case 1:
                        case 2:
                        case 3:
                        default:
                            return;
                    }
                }
            };
            this.mLocationManager.addGpsStatusListener(this.mGPSStatus);
            this.mLocationManager.requestLocationUpdates("network", 5000L, 30.0f, this.mGPSListener);
        }
    }

    public void stop_gps() {
        if (gps_started) {
            hide_gps_progress();
            gps_started = false;
            this.mLocationManager.removeUpdates(this.mGPSListener);
            this.mLocationManager.removeGpsStatusListener(this.mGPSStatus);
            this.mLocationManager = null;
            this.gps_connected = false;
        }
    }

    public void show_gps_progress() {
        hide_gps_progress();
        this.isGpsLoading = true;
        this.gpsLoading = new ProgressDialog(this);
        this.gpsLoading.setMessage(getString(R.string.gps_connecting));
        this.gpsLoading.setCancelable(false);
        this.gpsLoading.setButton(getString(R.string.cancle), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Cm.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                Cm.gps_started = true;
                Cm.this.stop_gps();
            }
        });
        this.gpsLoading.show();
    }

    public void hide_gps_progress() {
        if (this.isGpsLoading) {
            this.gpsLoading.dismiss();
            this.isGpsLoading = false;
        }
    }
}
