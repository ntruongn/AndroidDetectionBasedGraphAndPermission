package com.yooncom.yoon_03_13_n;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

@SuppressLint({"HandlerLeak"})
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class Tab_set_alarm extends Cm implements CompoundButton.OnCheckedChangeListener {
    private ToggleButton push_alarm_Btn;
    private ToggleButton s_off_pre_Btn;
    private ToggleButton sound_alarm_Btn;
    private ToggleButton vibrate_alarm_Btn;
    Boolean push_alarm_ck = true;
    Boolean s_off_preview_ck = true;
    Boolean vibrate_alarm_ck = true;
    Boolean sound_alarm_ck = true;

    @Override // com.yooncom.yoon_03_13_n.Cm, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_set_alarm);
        this.push_alarm_Btn = (ToggleButton) findViewById(R.id.push_toggleButton);
        this.s_off_pre_Btn = (ToggleButton) findViewById(R.id.s_off_preview_toggleButton);
        this.vibrate_alarm_Btn = (ToggleButton) findViewById(R.id.vibrate_alarm_toggleButton);
        this.sound_alarm_Btn = (ToggleButton) findViewById(R.id.sound_alarm_toggleButton);
        set_alarm_init();
        this.push_alarm_Btn.setOnCheckedChangeListener(this);
        this.s_off_pre_Btn.setOnCheckedChangeListener(this);
        this.vibrate_alarm_Btn.setOnCheckedChangeListener(this);
        this.sound_alarm_Btn.setOnCheckedChangeListener(this);
    }

    public void set_alarm_init() {
        SharedPreferences pref = getSharedPreferences("pushAlarmSet", 0);
        this.push_alarm_ck = Boolean.valueOf(pref.getBoolean("push_alarm", true));
        this.push_alarm_Btn.setChecked(this.push_alarm_ck.booleanValue());
        this.s_off_preview_ck = Boolean.valueOf(pref.getBoolean("s_off_preview", true));
        this.s_off_pre_Btn.setChecked(this.s_off_preview_ck.booleanValue());
        this.vibrate_alarm_ck = Boolean.valueOf(pref.getBoolean("vibrate_alarm", true));
        this.vibrate_alarm_Btn.setChecked(this.vibrate_alarm_ck.booleanValue());
        this.sound_alarm_ck = Boolean.valueOf(pref.getBoolean("sound_alarm", true));
        this.sound_alarm_Btn.setChecked(this.sound_alarm_ck.booleanValue());
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        SharedPreferences sp = getSharedPreferences("pushAlarmSet", 0);
        SharedPreferences.Editor edit = sp.edit();
        if (buttonView.equals(this.push_alarm_Btn)) {
            if (isChecked) {
                this.s_off_pre_Btn.setChecked(true);
                this.vibrate_alarm_Btn.setChecked(true);
                this.sound_alarm_Btn.setChecked(true);
                edit.putBoolean("sound_alarm", true);
                edit.putBoolean("vibrate_alarm", true);
                edit.putBoolean("s_off_preview", true);
                edit.putBoolean("push_alarm", true);
                edit.commit();
                return;
            }
            this.s_off_pre_Btn.setChecked(false);
            this.vibrate_alarm_Btn.setChecked(false);
            this.sound_alarm_Btn.setChecked(false);
            edit.putBoolean("sound_alarm", false);
            edit.putBoolean("vibrate_alarm", false);
            edit.putBoolean("s_off_preview", false);
            edit.putBoolean("push_alarm", false);
            edit.commit();
            return;
        }
        if (buttonView.equals(this.s_off_pre_Btn)) {
            if (isChecked) {
                edit.putBoolean("s_off_preview", true);
                edit.commit();
                return;
            } else {
                edit.putBoolean("s_off_preview", false);
                edit.commit();
                return;
            }
        }
        if (buttonView.equals(this.vibrate_alarm_Btn)) {
            if (isChecked) {
                edit.putBoolean("vibrate_alarm", true);
                edit.commit();
                return;
            } else {
                edit.putBoolean("vibrate_alarm", false);
                edit.commit();
                return;
            }
        }
        if (buttonView.equals(this.sound_alarm_Btn)) {
            if (isChecked) {
                edit.putBoolean("sound_alarm", true);
                edit.commit();
            } else {
                edit.putBoolean("sound_alarm", false);
                edit.commit();
            }
        }
    }
}
