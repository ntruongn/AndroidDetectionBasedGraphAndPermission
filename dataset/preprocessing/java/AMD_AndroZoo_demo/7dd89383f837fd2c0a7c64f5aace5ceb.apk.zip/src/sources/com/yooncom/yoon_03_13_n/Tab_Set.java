package com.yooncom.yoon_03_13_n;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.MotionEventCompat;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class Tab_Set extends Fragment implements View.OnClickListener, View.OnTouchListener, CompoundButton.OnCheckedChangeListener {
    public static View setTitleShadow;
    public static ImageView setTitle_img;
    public static ImageView setTtitle_Gra;
    private TextView app_info;
    Cm cmActivity;
    private TableRow pcPreVer;
    private TextView pcPreVer_text;
    private TableRow preVer;
    private TextView preVer_text;
    private TextView push_alarm_set;
    private TextView setTitle_text;
    private TableRow set_alarm;
    private TextView set_alarm_text;
    boolean viewpager_set_ck = true;
    private ToggleButton viewpager_toglel;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.tab_set, container, false);
        this.cmActivity = (Cm) Cm.CmActivity;
        set_titlebar(v);
        this.preVer = (TableRow) v.findViewById(R.id.prever);
        this.preVer_text = (TextView) v.findViewById(R.id.prever_text);
        this.pcPreVer = (TableRow) v.findViewById(R.id.pcPrever);
        this.pcPreVer_text = (TextView) v.findViewById(R.id.pcPrever_text);
        this.set_alarm = (TableRow) v.findViewById(R.id.set_alarm);
        this.set_alarm_text = (TextView) v.findViewById(R.id.set_alarm_text);
        this.set_alarm_text.setText(getString(R.string.set_alarm));
        this.push_alarm_set = (TextView) v.findViewById(R.id.push_alarm_set);
        this.push_alarm_set.setText(getString(R.string.is_push_alarm));
        this.app_info = (TextView) v.findViewById(R.id.app_info);
        this.app_info.setText(getString(R.string.set_app_info));
        this.viewpager_toglel = (ToggleButton) v.findViewById(R.id.viewpager_set_toggleButton);
        SharedPreferences pref = getActivity().getSharedPreferences("pushAlarmSet", 0);
        this.viewpager_set_ck = pref.getBoolean("viewpager_alarm", true);
        this.viewpager_toglel.setChecked(this.viewpager_set_ck);
        this.preVer.setBackgroundResource(R.drawable.round_border_top_up);
        if (Cm.newVersionCode > Cm.versionCode) {
            this.preVer_text.setText(Html.fromHtml(String.valueOf(getString(R.string.set_pre_version)) + "<font color='#ff0000'>New</font>"));
        } else {
            this.preVer_text.setText(getString(R.string.set_pre_version));
        }
        this.preVer_text.setTextColor(Color.rgb(0, 0, 0));
        this.pcPreVer.setBackgroundResource(R.drawable.round_border_bottom_up);
        this.pcPreVer_text.setTextColor(Color.rgb(0, 0, 0));
        this.pcPreVer_text.setText(R.string.set_pc_version);
        this.preVer_text.setOnClickListener(this);
        this.preVer.setOnClickListener(this);
        this.preVer_text.setOnTouchListener(this);
        this.preVer.setOnTouchListener(this);
        this.pcPreVer_text.setOnClickListener(this);
        this.pcPreVer.setOnClickListener(this);
        this.pcPreVer_text.setOnTouchListener(this);
        this.pcPreVer.setOnTouchListener(this);
        this.set_alarm.setOnClickListener(this);
        this.set_alarm_text.setOnTouchListener(this);
        this.set_alarm.setOnTouchListener(this);
        this.set_alarm_text.setOnTouchListener(this);
        this.viewpager_toglel.setOnCheckedChangeListener(this);
        return v;
    }

    public void set_titlebar(View v) {
        if (this.cmActivity.setTitleBar().booleanValue()) {
            this.setTitle_text = (TextView) v.findViewById(R.id.setTitle);
            setTitle_img = (ImageView) v.findViewById(R.id.setTitle_img);
            setTtitle_Gra = (ImageView) v.findViewById(R.id.setTitle_gra);
            setTitleShadow = v.findViewById(R.id.setTitle_shadow);
            setTitle_img.setAdjustViewBounds(true);
            setTitle_img.setScaleType(ImageView.ScaleType.FIT_XY);
            this.setTitle_text.setTextColor(Color.parseColor(Cm.title_font_color));
            this.setTitle_text.setText(R.string.tab_set_title);
            this.setTitle_text.setOnClickListener(this);
            setTitle_img.setOnClickListener(this);
            setTtitle_Gra.setOnClickListener(this);
            if (!Cm.title_user_img_src.equals("")) {
                setTitle_img.setImageBitmap(Cm.bitMap);
            } else if (!Cm.title_bg_color.equals("")) {
                setTitle_img.setBackgroundColor(Color.parseColor(Cm.title_bg_color));
            } else if (!Cm.title_img_src.equals("")) {
                setTitle_img.setImageBitmap(Cm.bitMap);
            } else if (!Cm.back_user_img_src.equals("")) {
                if (!Cm.back_pattern.equals("Y")) {
                    setTitle_img.setImageBitmap(Cm.bitMap);
                }
            } else if (!Cm.back_bg_color.equals("")) {
                setTitle_img.setBackgroundColor(Color.parseColor(Cm.back_bg_color));
            } else if (!Cm.back_img_src.equals("")) {
                setTitle_img.setImageBitmap(Cm.bitMap);
            }
            if (!Cm.title_grad.equals("Y")) {
                setTtitle_Gra.setVisibility(8);
            }
            if (!Cm.title_shadow.equals("Y")) {
                setTitleShadow.setVisibility(8);
            }
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        if (v.getId() == 2131230761 || v.getId() == 2131230762) {
            Intent intent = new Intent(getActivity(), (Class<?>) Tab_set_version.class);
            startActivity(intent);
            return;
        }
        if (v.getId() == 2131230763 || v.getId() == 2131230764) {
            if (Cm.pc_url != "") {
                if (!Cm.pc_url.startsWith("http://")) {
                    Cm.pc_url = "http://" + Cm.pc_url;
                }
                Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse(Cm.pc_url));
                startActivity(intent2);
                Cm.pc_url = "";
                return;
            }
            Toast.makeText(getActivity(), getString(R.string.pc_page_no), 0).show();
            return;
        }
        if (v.getId() == 2131230756 || v.getId() == 2131230757) {
            Intent intent3 = new Intent(getActivity(), (Class<?>) Tab_set_alarm.class);
            startActivity(intent3);
        }
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View v, MotionEvent e) {
        if (v.getId() == 2131230761 || v.getId() == 2131230762) {
            if (e.getAction() == 0) {
                this.preVer.setBackgroundResource(R.drawable.round_border_top_down);
                this.preVer_text.setTextColor(Color.rgb((int) MotionEventCompat.ACTION_MASK, (int) MotionEventCompat.ACTION_MASK, (int) MotionEventCompat.ACTION_MASK));
            } else {
                this.preVer.setBackgroundResource(R.drawable.round_border_top_up);
                this.preVer_text.setTextColor(Color.rgb(0, 0, 0));
            }
        } else if (v.getId() == 2131230763 || v.getId() == 2131230764) {
            if (e.getAction() == 0) {
                this.pcPreVer.setBackgroundResource(R.drawable.round_border_bottom_down);
                this.pcPreVer_text.setTextColor(Color.rgb((int) MotionEventCompat.ACTION_MASK, (int) MotionEventCompat.ACTION_MASK, (int) MotionEventCompat.ACTION_MASK));
            } else {
                this.pcPreVer.setBackgroundResource(R.drawable.round_border_bottom_up);
                this.pcPreVer_text.setTextColor(Color.rgb(0, 0, 0));
            }
        } else if (v.getId() == 2131230756 || v.getId() == 2131230757) {
            if (e.getAction() == 0) {
                this.set_alarm.setBackgroundResource(R.drawable.round_border_down);
                this.set_alarm_text.setTextColor(Color.rgb((int) MotionEventCompat.ACTION_MASK, (int) MotionEventCompat.ACTION_MASK, (int) MotionEventCompat.ACTION_MASK));
            } else {
                this.set_alarm.setBackgroundResource(R.drawable.round_border_up);
                this.set_alarm_text.setTextColor(Color.rgb(0, 0, 0));
            }
        }
        return false;
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        SharedPreferences sp = getActivity().getSharedPreferences("pushAlarmSet", 0);
        SharedPreferences.Editor edit = sp.edit();
        if (buttonView.equals(this.viewpager_toglel)) {
            if (isChecked) {
                this.viewpager_toglel.setChecked(true);
                edit.putBoolean("viewpager_alarm", true);
                edit.commit();
                Main.pager.setPagingEnabled(true);
                return;
            }
            this.viewpager_toglel.setChecked(false);
            edit.putBoolean("viewpager_alarm", false);
            edit.commit();
            Main.pager.setPagingEnabled(false);
        }
    }
}
