package com.yooncom.yoon_03_13_n;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import com.google.android.gcm.GCMBaseIntentService;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class GCMIntentService extends GCMBaseIntentService {
    Boolean push_check = true;

    @Override // com.google.android.gcm.GCMBaseIntentService
    protected void onError(Context arg0, String arg1) {
        Log.d("GCMIntentService", "onError() - " + arg1);
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(arg0);
        String c2dm_id = pref.getString("device_id", null);
        Cm.device_id = "no push";
        if (CmApi.register(getString(R.string.site_no), c2dm_id)) {
            if (c2dm_id != null) {
                SharedPreferences.Editor editor = pref.edit();
                editor.putString("device_id", null);
                editor.commit();
            }
            Cm.isRegister = true;
            Intent i = new Intent(arg0, (Class<?>) Main.class);
            i.addFlags(268435456);
            i.addFlags(65536);
            i.addFlags(67108864);
            arg0.startActivity(i);
        }
    }

    @Override // com.google.android.gcm.GCMBaseIntentService
    protected void onMessage(Context arg0, Intent arg1) {
        Log.d("GCMIntentService", "onMessage() - " + arg1.getStringExtra("message"));
        SharedPreferences Push_info = getSharedPreferences("pushAlarmSet", 0);
        this.push_check = Boolean.valueOf(Push_info.getBoolean("push_alarm", true));
        if (this.push_check.booleanValue()) {
            try {
                Intent i = new Intent(arg0, (Class<?>) Pushmsg.class);
                i.putExtra("msg", arg1.getStringExtra("message"));
                i.addFlags(939786240);
                PendingIntent pendingIntent = PendingIntent.getActivity(arg0, 0, i, 268435456);
                pendingIntent.send();
            } catch (PendingIntent.CanceledException e) {
                Log.d("test", "인텐트 에러");
                e.printStackTrace();
            }
        }
    }

    @Override // com.google.android.gcm.GCMBaseIntentService
    protected void onRegistered(Context arg0, String arg1) {
        Log.d("GCMIntentService", "onRegistered() - " + arg1);
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(arg0);
        String c2dm_id = pref.getString("device_id", null);
        Cm.device_id = arg1;
        if (CmApi.register(getString(R.string.site_no), c2dm_id)) {
            if (c2dm_id != null) {
                SharedPreferences.Editor editor = pref.edit();
                editor.putString("device_id", null);
                editor.commit();
            }
            Cm.isRegister = true;
            Intent i = new Intent(arg0, (Class<?>) Main.class);
            i.addFlags(268435456);
            i.addFlags(65536);
            i.addFlags(67108864);
            arg0.startActivity(i);
        }
    }

    @Override // com.google.android.gcm.GCMBaseIntentService
    protected void onUnregistered(Context arg0, String arg1) {
        Log.d("GCMIntentService", "onUnregistered() - " + arg1);
    }
}
