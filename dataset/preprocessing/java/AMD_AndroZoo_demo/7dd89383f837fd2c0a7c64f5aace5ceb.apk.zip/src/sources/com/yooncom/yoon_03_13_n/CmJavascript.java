package com.yooncom.yoon_03_13_n;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.PowerManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.ByteArrayBuffer;

@SuppressLint({"ValidFragment"})
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class CmJavascript extends Cm {
    static Activity CmJavascriptActivity;
    static Context mContext;
    Cm CmActivity;

    /* JADX INFO: Access modifiers changed from: package-private */
    public CmJavascript(Context c) {
        mContext = c;
        CmJavascriptActivity = this;
        this.CmActivity = (Cm) Cm.CmActivity;
    }

    @JavascriptInterface
    public void change_viewpager(String state) {
        if (this.viewpager_set_ck.booleanValue()) {
            if (state.contentEquals("off")) {
                Log.d("tet123", "여기여기");
                Main.pager.setPagingEnabled(false);
                is_swipe = false;
            } else if (state.contentEquals("on")) {
                Main.pager.setPagingEnabled(true);
                is_swipe = true;
            }
        }
    }

    @JavascriptInterface
    public void lock_screen() {
        if (mWakeLock == null) {
            PowerManager pm = (PowerManager) mContext.getSystemService("power");
            mWakeLock = pm.newWakeLock(26, "CocoamApp");
        }
        if (!mWakeLock.isHeld()) {
            is_lock_screen = true;
            mWakeLock.acquire();
        }
    }

    @JavascriptInterface
    public void nolock_screen() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            is_lock_screen = false;
            mWakeLock.release();
        }
    }

    @JavascriptInterface
    public String get_tel_no() {
        TelephonyManager telManager = (TelephonyManager) getSystemService("phone");
        return telManager != null ? telManager.getLine1Number() : "";
    }

    @Override // com.yooncom.yoon_03_13_n.Cm
    @JavascriptInterface
    public void start_gps() {
        this.CmActivity.start_gps();
    }

    @Override // com.yooncom.yoon_03_13_n.Cm
    @JavascriptInterface
    public void stop_gps() {
        this.CmActivity.stop_gps();
    }

    @JavascriptInterface
    public void alert_t(String e) {
        Toast.makeText(mContext, e, 0).show();
    }

    @JavascriptInterface
    public void setLoginMember(int member_no) {
        if (member_no != member && CmApi.login(mContext.getString(R.string.site_no), member_no)) {
            member = member_no;
        }
    }

    @JavascriptInterface
    public String getDeviceCode() {
        return device_id;
    }

    @JavascriptInterface
    public void downloadImage(String imgUrl, String fileName) {
        downloadImgUrl = imgUrl;
        downloadImgFileName = fileName;
        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
        alert.setMessage(mContext.getString(R.string.is_photo_save));
        alert.setPositiveButton(mContext.getString(R.string.confirm), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.CmJavascript.1
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                Cm.showLoading(CmJavascript.mContext.getString(R.string.is_photo_saving), CmJavascript.mContext);
                Log.d("test6", "asdasdsa111");
                Image_Down_Task img_down = new Image_Down_Task();
                img_down.execute(new String[0]);
            }
        });
        alert.setNegativeButton(mContext.getString(R.string.cancle), new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.CmJavascript.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alert.show();
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public static class Image_Down_Task extends AsyncTask<String, String, String> {
        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override // android.os.AsyncTask
        public String doInBackground(String... params) {
            try {
                Log.d("ExternalStorage", "test  : " + CmJavascript.downloadImgUrl + " / " + CmJavascript.downloadImgFileName);
                HttpClient httpclient = new DefaultHttpClient();
                HttpGet httpget = new HttpGet(CmJavascript.downloadImgUrl);
                HttpResponse response = httpclient.execute(httpget);
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    String path = String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + "/DCIM/Camera/" + CmJavascript.downloadImgFileName;
                    String path1 = Environment.getExternalStorageDirectory() + "/DCIM/Camera/" + CmJavascript.downloadImgFileName;
                    File tempFile = new File(path);
                    if (!tempFile.exists()) {
                        tempFile.createNewFile();
                    }
                    InputStream instream = entity.getContent();
                    BufferedInputStream bufferedInputStream = new BufferedInputStream(instream);
                    ByteArrayBuffer buffer = new ByteArrayBuffer(1024);
                    while (true) {
                        int current = bufferedInputStream.read();
                        if (current != -1) {
                            buffer.append((byte) current);
                        } else {
                            FileOutputStream stream = new FileOutputStream(tempFile);
                            stream.write(buffer.toByteArray());
                            stream.flush();
                            stream.close();
                            File tempFile1 = new File(path1);
                            MediaScannerConnection.scanFile(CmJavascript.mContext, new String[]{tempFile1.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() { // from class: com.yooncom.yoon_03_13_n.CmJavascript.Image_Down_Task.1
                                @Override // android.media.MediaScannerConnection.OnScanCompletedListener
                                public void onScanCompleted(String path2, Uri uri) {
                                    Log.d("ExternalStorage", "Scanned " + path2 + ":");
                                    Log.d("ExternalStorage", "-> uri=" + uri);
                                }
                            });
                            return null;
                        }
                    }
                } else {
                    return null;
                }
            } catch (IOException e) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String result) {
            super.onPostExecute((Image_Down_Task) result);
            Cm.hideLoading();
            Cm.showAlert(CmJavascript.mContext, CmJavascript.mContext.getString(R.string.photo_down_complete));
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            super.onCancelled();
        }
    }
}
