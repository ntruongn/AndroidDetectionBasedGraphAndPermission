package com.yooncom.yoon_03_13_n;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.View;
import android.view.ViewGroup;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class CmPagerAdapter extends FragmentPagerAdapter {
    public CmPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override // android.support.v4.app.FragmentPagerAdapter
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                Fragment newFragment = new Tab_Home();
                return newFragment;
            case 1:
                Fragment newFragment2 = new Tab_Allarticle();
                return newFragment2;
            case 2:
                Fragment newFragment3 = new Tab_Alarm();
                return newFragment3;
            case 3:
                Fragment newFragment4 = new Tab_Set();
                return newFragment4;
            default:
                return null;
        }
    }

    @Override // android.support.v4.app.FragmentPagerAdapter, android.support.v4.view.PagerAdapter
    public boolean isViewFromObject(View view, Object object) {
        return super.isViewFromObject(view, object);
    }

    @Override // android.support.v4.view.PagerAdapter
    public int getCount() {
        return 4;
    }

    @Override // android.support.v4.app.FragmentPagerAdapter, android.support.v4.view.PagerAdapter
    public void destroyItem(ViewGroup container, int position, Object object) {
    }
}
