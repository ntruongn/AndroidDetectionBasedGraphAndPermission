package com.yooncom.yoon_03_13_n;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.ViewCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieSyncManager;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import com.google.android.gcm.GCMRegistrar;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Date;
import java.text.SimpleDateFormat;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
public class Tab_Home extends DialogFragment {
    private static final int FILECHOOSER_RESULTCODE = 1;
    public static String back_src = "";
    static Context home_context;
    static RelativeLayout home_lay;
    static WebView wb;
    Cm cmActivity;
    private ValueCallback<Uri> mUploadMessage;
    Main mainActivity;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.tab_home, container, false);
        home_context = getActivity();
        wb = (WebView) v.findViewById(R.id.webview_home);
        this.mainActivity = (Main) Main.mainActivity;
        this.cmActivity = (Cm) Cm.CmActivity;
        home_lay = (RelativeLayout) v.findViewById(R.id.home_layout);
        register_start();
        check_push();
        return v;
    }

    public void register_start() {
        if (Cm.isRegister) {
            initWeb(Cm.url);
            Cm.isRegister = false;
        } else {
            registerGCM();
        }
    }

    public void registerGCM() {
        GCMRegistrar.checkDevice(getActivity());
        GCMRegistrar.checkManifest(getActivity());
        String regId = GCMRegistrar.getRegistrationId(getActivity());
        if (regId.equals("")) {
            GCMRegistrar.register(getActivity(), "192732450136");
            return;
        }
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String c2dm_id = pref.getString("device_id", null);
        Cm.device_id = regId;
        if (CmApi.register(getString(R.string.site_no), c2dm_id)) {
            if (c2dm_id != null) {
                SharedPreferences.Editor editor = pref.edit();
                editor.putString("device_id", null);
                editor.commit();
            }
            Cm.isRegister = true;
            register_start();
        }
    }

    private void check_push() {
        if (Cm.pushcount > 0) {
            this.mainActivity.fragmentReplace(2);
            this.mainActivity.tab_on_set(2);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "InlinedApi"})
    @TargetApi(11)
    public void initWeb(String url) {
        wb.getSettings().setJavaScriptEnabled(true);
        wb.getSettings().setGeolocationEnabled(true);
        wb.addJavascriptInterface(new CmJavascript(getActivity()), "android");
        wb.getSettings().setLoadsImagesAutomatically(true);
        wb.getSettings().setCacheMode(0);
        wb.getSettings().setSupportZoom(true);
        wb.getSettings().setBuiltInZoomControls(true);
        wb.getSettings().setSupportMultipleWindows(false);
        wb.getSettings().setSaveFormData(false);
        wb.getSettings().setSavePassword(false);
        wb.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        wb.setHorizontalScrollBarEnabled(false);
        wb.setVerticalScrollBarEnabled(true);
        wb.setVerticalScrollbarOverlay(true);
        wb.getSettings().setDomStorageEnabled(true);
        wb.setWebChromeClient(new ChromeClient(this));
        if (Build.VERSION.SDK_INT >= 11) {
            getActivity().getWindow().setFlags(ViewCompat.MEASURED_STATE_TOO_SMALL, ViewCompat.MEASURED_STATE_TOO_SMALL);
            wb.getSettings().setDisplayZoomControls(false);
        }
        back_src = url;
        wb.loadUrl(url);
        wb.setWebViewClient(new wbClient(this, null));
        wb.setWebChromeClient(new ChromeClient(this) { // from class: com.yooncom.yoon_03_13_n.Tab_Home.1
            @Override // android.webkit.WebChromeClient
            public void onCloseWindow(WebView window) {
                super.onCloseWindow(window);
                onHideCustomView();
                Log.d("tt", "123");
            }

            @Override // android.webkit.WebChromeClient
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            public void openFileChooser(ValueCallback<Uri> uploadFile, String acceptType) {
                openFileChooser(uploadFile);
            }

            public void openFileChooser(ValueCallback<Uri> uploadMsg) {
                Tab_Home.this.mUploadMessage = uploadMsg;
                Intent i = new Intent("android.intent.action.GET_CONTENT");
                i.addCategory("android.intent.category.OPENABLE");
                i.setType("image/*");
                Tab_Home.this.startActivityForResult(Intent.createChooser(i, Tab_Home.this.getString(R.string.is_file)), 1);
            }

            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
                openFileChooser(uploadMsg, "");
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/7dd89383f837fd2c0a7c64f5aace5ceb.apk/classes.dex */
    public class wbClient extends WebViewClient {
        private wbClient() {
        }

        /* synthetic */ wbClient(Tab_Home tab_Home, wbClient wbclient) {
            this();
        }

        @Override // android.webkit.WebViewClient
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, 0, description, "");
        }

        @Override // android.webkit.WebViewClient
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            CookieSyncManager.getInstance().sync();
            Cm.hideLoading();
            if (Load.check_net) {
                Load loadActivity = (Load) Load.loadActivity;
                loadActivity.finish();
                Load.check_net = false;
            }
        }

        @Override // android.webkit.WebViewClient
        @SuppressLint({"NewApi"})
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url.startsWith("http://")) {
                Cm.is_lock_screen = false;
                try {
                    if (url.contains("alarm")) {
                        if (Tab_Home.back_src.contains("facebook.com") || Tab_Home.back_src.contains("twitter.com")) {
                            Tab_Home.back_src = Cm.home_url;
                        }
                        view.loadUrl(Tab_Home.back_src);
                        Tab_Alarm.wb.reload();
                        Main.mCurrentFragmentIndex = 2;
                        Tab_Home.this.mainActivity.fragmentReplace(2);
                        Tab_Home.this.mainActivity.tab_on_set(2);
                    } else if (url.contains("mobile-ok")) {
                        view.loadUrl(url);
                    } else if (url.contains("logout") || url.contains("login")) {
                        view.loadUrl(url);
                        Tab_Allarticle.wb.reload();
                        Tab_Alarm.wb.reload();
                    } else {
                        Tab_Home.back_src = url;
                        view.loadUrl(url);
                        Tab_Allarticle.wb.reload();
                        Tab_Alarm.wb.reload();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return true;
            }
            if (url.startsWith("https://")) {
                view.loadUrl(url);
                return true;
            }
            if (url.startsWith("photo://")) {
                Tab_Home.this.photo();
                return true;
            }
            Log.d("testkakao", url);
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
            intent.addCategory("android.intent.category.BROWSABLE");
            intent.putExtra("com.android.browser.application_id", Tab_Home.this.getActivity().getPackageName());
            if (url.startsWith("sms:")) {
                Tab_Home.this.startActivity(new Intent("android.intent.action.SENDTO", Uri.parse(url)));
                return true;
            }
            if (url.startsWith("tel:")) {
                Tab_Home.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse(url)));
                return true;
            }
            if (url.startsWith("mailto:")) {
                Tab_Home.this.startActivity(new Intent("android.intent.action.SENDTO", Uri.parse(url)));
                return true;
            }
            if (url.startsWith("newwin:")) {
                Log.d("newte", url.toString());
                Intent i = new Intent("android.intent.action.VIEW");
                i.setData(Uri.parse(url.replace("newwin:", "http:")));
                Tab_Home.this.startActivity(i);
                return true;
            }
            try {
                Tab_Home.this.startActivity(intent);
                return true;
            } catch (ActivityNotFoundException e2) {
                return false;
            }
        }
    }

    @Override // android.support.v4.app.Fragment
    @SuppressLint({"SdCardPath"})
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        Uri result;
        if (requestCode == 1) {
            if (this.mUploadMessage != null) {
                if (intent != null) {
                    getActivity();
                    if (resultCode == -1) {
                        result = intent.getData();
                        this.mUploadMessage.onReceiveValue(result);
                        this.mUploadMessage = null;
                    }
                }
                result = null;
                this.mUploadMessage.onReceiveValue(result);
                this.mUploadMessage = null;
            } else {
                return;
            }
        }
        getActivity();
        if (resultCode == -1) {
            File file = new File("/sdcard" + Cm.TEMP_FILE_DIR);
            switch (requestCode) {
                case Cm.PICK_FROM_CAMERA /* 100 */:
                    this.cmActivity.media_scan(file);
                    Cm.menuCode = 100;
                    this.cmActivity.up_img();
                    return;
                case Cm.PICK_FROM_ALBUM /* 200 */:
                    this.cmActivity.media_scan(file);
                    Cm.menuCode = Cm.PICK_FROM_ALBUM;
                    Uri imgUri = intent.getData();
                    Cm.albumImgName = this.cmActivity.getRealPathFromURI(imgUri);
                    this.cmActivity.up_img();
                    return;
                default:
                    return;
            }
        }
    }

    public void photo() {
        final CharSequence[] photo_list = {getString(R.string.camera), getString(R.string.album)};
        new AlertDialog.Builder(getActivity()).setTitle(getString(R.string.photo_upload)).setItems(photo_list, new DialogInterface.OnClickListener() { // from class: com.yooncom.yoon_03_13_n.Tab_Home.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int item) {
                if (photo_list[item] == Tab_Home.this.getString(R.string.camera)) {
                    Tab_Home.this.photo_camera();
                } else {
                    if (photo_list[item] != Tab_Home.this.getString(R.string.album)) {
                        return;
                    }
                    Tab_Home.this.photo_album();
                }
            }
        }).show();
    }

    @SuppressLint({"SimpleDateFormat"})
    public void photo_camera() {
        this.cmActivity.is_folder();
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat date2 = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String date3 = date2.format((java.util.Date) date);
        Cm.cameraImgName = String.valueOf("cm_" + date3 + ".jpg");
        File file = new File(Environment.getExternalStorageDirectory(), String.valueOf(Cm.TEMP_FILE_DIR) + Cm.cameraImgName);
        intent.putExtra("output", Uri.fromFile(file));
        startActivityForResult(intent, 100);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void photo_album() {
        this.cmActivity.is_folder();
        Intent intent = new Intent("android.intent.action.PICK");
        intent.setType("vnd.android.cursor.dir/image");
        startActivityForResult(intent, Cm.PICK_FROM_ALBUM);
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        super.onResume();
        callHiddenWebViewMethod("onResume");
        CookieSyncManager.getInstance().startSync();
    }

    @Override // android.support.v4.app.Fragment
    public void onPause() {
        super.onPause();
        callHiddenWebViewMethod("onPause");
        CookieSyncManager.getInstance().stopSync();
    }

    private void callHiddenWebViewMethod(String name) {
        if (wb != null) {
            try {
                Method method = WebView.class.getMethod(name, new Class[0]);
                method.invoke(wb, new Object[0]);
            } catch (IllegalAccessException e) {
                Log.e("Illegal Access: " + name, e.toString());
            } catch (NoSuchMethodException e2) {
                Log.e("No such method: " + name, e2.toString());
            } catch (InvocationTargetException e3) {
                Log.e("Invocation Target Exception: " + name, e3.toString());
            }
        }
    }
}
