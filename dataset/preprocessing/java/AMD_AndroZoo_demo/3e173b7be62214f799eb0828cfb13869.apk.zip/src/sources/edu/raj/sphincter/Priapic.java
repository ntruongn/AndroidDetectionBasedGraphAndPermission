package edu.raj.sphincter;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/3e173b7be62214f799eb0828cfb13869.apk/classes.dex */
public class Priapic {
    public static String[] a;
    private static final int[] b = {0, 4, 4, 11, 15, 6, 21, 3, 24, 18, 42, 8, 50, 4, 54, 5, 59, 15, 74, 4, 78, 8, 86, 20, 106, 5, 111, 31, 142, 6, 148, 8};
    private static byte[] c = {19, 2, 23, 11, 7, 6, 27, 38, 15, 6, 14, 6, 13, 23, 16, 14, 37, 10, 15, 6, 16, 7, 6, 27, 77, 47, 10, 5, 6, 16, 10, 25, 6, 7, 34, 0, 23, 10, 21, 10, 23, 26, 23, 6, 16, 23, 77, 7, 2, 23, 77, 7, 6, 27, 14, 39, 6, 27, 16, 14, 2, 8, 6, 39, 6, 27, 38, 15, 6, 14, 6, 13, 23, 16, 7, 6, 27, 81, 19, 2, 23, 11, 47, 10, 16, 23, 43, 2, 13, 7, 16, 23, 2, 13, 7, 34, 19, 19, 15, 10, 0, 2, 23, 10, 12, 13, 14, 57, 10, 19, 16, 7, 6, 27, 38, 15, 6, 14, 6, 13, 23, 16, 48, 22, 19, 19, 17, 6, 16, 16, 6, 7, 38, 27, 0, 6, 19, 23, 10, 12, 13, 16, 14, 51, 2, 23, 11, 16, 23, 6, 16, 23, 77, 2, 19, 8};

    /* JADX WARN: Unreachable blocks removed: 3, instructions: 3 */
    static {
        try {
            a = new String[b.length / 2];
            for (int i = 0; i < c.length; i++) {
                byte[] bArr = c;
                bArr[i] = (byte) (bArr[i] ^ 99);
            }
            for (int i2 = 0; i2 < b.length; i2 += 2) {
                a[i2 / 2] = new String(c, b[i2 + 0], b[i2 + 1], "UTF-8");
            }
        } catch (Exception e) {
        }
    }
}
