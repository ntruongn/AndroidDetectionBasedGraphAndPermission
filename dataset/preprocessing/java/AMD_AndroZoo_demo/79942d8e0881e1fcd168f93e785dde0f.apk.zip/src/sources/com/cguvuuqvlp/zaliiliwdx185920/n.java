package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.util.Log;
import android.webkit.WebView;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
class n implements e {
    static List<NameValuePair> b;
    private static Context c;
    private static SharedPreferences e;
    static JSONObject a = null;
    private static String d = "0";

    public n(Context context) {
        c = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a() {
        try {
            Util.f(new WebView(c).getSettings().getUserAgentString());
            o oVar = new o(c);
            try {
                Location d2 = oVar.d();
                if (d2 != null) {
                    String str = "" + d2.getLatitude();
                    String str2 = "" + d2.getLongitude();
                    Util.i(oVar.c());
                    Util.a(d2.getAccuracy());
                    Util.j(d2.getProvider());
                    Util.a("Location: lat " + str + ", lon " + str2);
                    Util.g(str);
                    Util.h(str2);
                } else {
                    Util.a("Location null: ");
                }
            } catch (Exception e2) {
            }
            d = oVar.a() + "" + Util.j() + "" + Util.r();
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(d.getBytes(), 0, d.length());
            d = new BigInteger(1, messageDigest.digest()).toString(16);
        } catch (Exception e3) {
            Util.a("Token conversion Error ");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static List<NameValuePair> a(Context context) throws NullPointerException, Exception {
        c = context;
        b = new ArrayList();
        b.add(new BasicNameValuePair(e.APIKEY, Util.i()));
        b.add(new BasicNameValuePair(e.APP_ID, Util.j()));
        b.add(new BasicNameValuePair(e.IMEI, Util.g()));
        b.add(new BasicNameValuePair(e.IMEI_SHA, Util.h()));
        b.add(new BasicNameValuePair(e.TOKEN, d));
        b.add(new BasicNameValuePair(e.REQUEST_TIMESTAMP, Util.r()));
        b.add(new BasicNameValuePair(e.PACKAGE_NAME, Util.f(c)));
        b.add(new BasicNameValuePair("version", Util.t()));
        b.add(new BasicNameValuePair(e.CARRIER, Util.g(c)));
        b.add(new BasicNameValuePair(e.NETWORK_OPERATOR, Util.h(c)));
        b.add(new BasicNameValuePair(e.PHONE_MODEL, Util.s()));
        b.add(new BasicNameValuePair(e.MANUFACTURER, Util.v()));
        b.add(new BasicNameValuePair(e.LONGITUDE, Util.m()));
        b.add(new BasicNameValuePair(e.LATITUDE, Util.l()));
        b.add(new BasicNameValuePair(e.SDK_VERSION, Util.a()));
        b.add(new BasicNameValuePair("wifi", "" + Util.i(c)));
        b.add(new BasicNameValuePair(e.USER_AGENT, Util.k()));
        b.add(new BasicNameValuePair(e.ANDROID_ID, Util.d(c)));
        b.add(new BasicNameValuePair(e.ANDROID_ID_SHA, Util.e(c)));
        b.add(new BasicNameValuePair(e.SCREEN_SIZE, Util.l(c)));
        b.add(new BasicNameValuePair(e.DEVICE_UNIQUENESS, Util.w()));
        b.add(new BasicNameValuePair(e.NETWORK_SUBTYPE, Util.j(c)));
        b.add(new BasicNameValuePair(e.isTABLET, String.valueOf(Util.b(c))));
        b.add(new BasicNameValuePair(e.SCREEN_DENSITY, Util.n(c)));
        b.add(new BasicNameValuePair(e.isCONNECTION_FAST, "" + Util.k(c)));
        b.add(new BasicNameValuePair(e.UNKNOWN_SOURCE, "" + Util.r(c)));
        b.add(new BasicNameValuePair("appName", Util.q(c)));
        b.add(new BasicNameValuePair("dpi", Util.o(c)));
        b.add(new BasicNameValuePair("src", "premium"));
        b.add(new BasicNameValuePair("sessionId", Util.e()));
        b.add(new BasicNameValuePair(e.LANGUAGE, "" + Util.x()));
        b.add(new BasicNameValuePair("locale", "" + Locale.getDefault()));
        b.add(new BasicNameValuePair("locProvider", Util.q()));
        b.add(new BasicNameValuePair("locType", Util.o()));
        b.add(new BasicNameValuePair("locAccuracy", "" + Util.p()));
        b.add(new BasicNameValuePair("adv_id", "" + Util.c()));
        b.add(new BasicNameValuePair("adOpt", "" + Util.b()));
        try {
            String[] m = Util.m(c);
            b.add(new BasicNameValuePair(e.COUNTRY, "" + m[0]));
            b.add(new BasicNameValuePair(e.ZIP, "" + m[1]));
        } catch (NullPointerException e2) {
        } catch (Exception e3) {
        }
        return b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean b(Context context) {
        boolean z = false;
        if (context == null) {
            return false;
        }
        try {
            e = null;
            e = context.getSharedPreferences("next_ad_call", 0);
            SharedPreferences.Editor edit = e.edit();
            long currentTimeMillis = 10000 + System.currentTimeMillis();
            edit.putLong(e.START_TIME, currentTimeMillis);
            z = edit.commit();
            Log.i(e.TAG, "Next Smart Wall ad call time: " + new Date(currentTimeMillis).toString());
            return z;
        } catch (Exception e2) {
            return z;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long c(Context context) {
        e = null;
        if (context == null) {
            return 0L;
        }
        e = context.getSharedPreferences("next_ad_call", 0);
        if (e != null) {
            return e.getLong(e.START_TIME, 0L);
        }
        return 0L;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean d(Context context) {
        try {
            e = null;
            e = context.getSharedPreferences("video_ad_call", 0);
            SharedPreferences.Editor edit = e.edit();
            long currentTimeMillis = 30000 + System.currentTimeMillis();
            edit.putLong(e.START_TIME, currentTimeMillis);
            Util.a("Next Video ad ad call time: " + new Date(currentTimeMillis).toString());
            return edit.commit();
        } catch (Exception e2) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long e(Context context) {
        e = null;
        if (context == null) {
            return 0L;
        }
        e = context.getSharedPreferences("video_ad_call", 0);
        if (e != null) {
            return e.getLong(e.START_TIME, 0L);
        }
        return 0L;
    }
}
