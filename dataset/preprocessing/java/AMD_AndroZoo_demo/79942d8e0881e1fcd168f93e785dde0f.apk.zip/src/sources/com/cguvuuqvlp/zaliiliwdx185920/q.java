package com.cguvuuqvlp.zaliiliwdx185920;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import com.cguvuuqvlp.zaliiliwdx185920.XmlParser;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.wallet.WalletConstants;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
abstract class q extends Activity {
    private static final String TAG = "PrmVast";
    private static Context c;
    private boolean A;
    private int B;
    private int C;
    private int D;
    private boolean E;
    private String F;
    private XmlParser a;
    private XmlParser.Creative b;
    Set<NameValuePair> d;
    int e = 100;
    int f = 101;
    int g = LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY;
    int h = 200;
    int i = 201;
    int j = 202;
    int k = 203;
    int l = 300;
    int m = 301;
    int n = 302;
    int o = 303;
    int p = 400;
    int q = 401;
    int r = WalletConstants.ERROR_CODE_SERVICE_UNAVAILABLE;
    int s = 403;
    int t = WalletConstants.ERROR_CODE_MERCHANT_ACCOUNT_ERROR;
    int u = 900;
    int v = 901;
    private boolean w;
    private int x;
    private int y;
    private boolean z;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    enum a {
        AdLoaded,
        AdStarted,
        AdStopped,
        AdSkipped,
        AdSkippableStateChange,
        AdSizeChange,
        AdLinearChange,
        AdDurationChange,
        AdExpandedChange,
        AdRemainingTimeChange,
        AdVolumeChange,
        AdImpression,
        AdVideoStart,
        AdVideoFirstQuartile,
        AdVideoMidpoint,
        AdVideoThirdQuartile,
        AdClickThru,
        AdInteraction,
        AdUserAcceptInvitation,
        AdUserMinimize,
        AdUserClose,
        AdVideoComplete,
        AdPaused,
        AdPlaying,
        AdLog
    }

    abstract void a();

    abstract void a(int i);

    abstract void a(int i, int i2, String str);

    abstract void a(int i, int i2, String str, int i3, String str2, String str3);

    abstract void b();

    abstract void c();

    abstract void d();

    String b(String str) {
        return "2.0";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(String str) {
        this.F = str;
    }

    boolean e() {
        return this.w;
    }

    void a(boolean z) {
        this.w = z;
    }

    int f() {
        return this.x;
    }

    void b(int i) {
        this.x = i;
    }

    int g() {
        return this.y;
    }

    void c(int i) {
        this.y = i;
    }

    boolean h() {
        return this.z;
    }

    void b(boolean z) {
        this.z = z;
    }

    boolean i() {
        return this.A;
    }

    void c(boolean z) {
        this.A = z;
    }

    int j() {
        return this.B;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(int i) {
        this.B = i;
    }

    int k() {
        return this.C;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(int i) {
        this.C = i;
    }

    int l() {
        return this.D;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void f(int i) {
        this.D = i;
    }

    boolean m() {
        return this.E;
    }

    void d(boolean z) {
        this.E = z;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(XmlParser xmlParser) {
        this.a = xmlParser;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(XmlParser.Creative creative) {
        this.b = creative;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(Context context) {
        c = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(a aVar) {
        switch (aVar) {
            case AdImpression:
                this.d.add(new BasicNameValuePair("impression", "1"));
                o();
                return;
            case AdClickThru:
                this.d.add(new BasicNameValuePair("click", "1"));
                p();
                return;
            case AdVideoComplete:
                this.d.add(new BasicNameValuePair(h.EVENT_COMPLETE, "1"));
                d(h.EVENT_COMPLETE);
                return;
            case AdSkipped:
                this.d.add(new BasicNameValuePair(h.EVENT_SKIP, "1"));
                d(h.EVENT_SKIP);
                return;
            case AdPaused:
                this.d.add(new BasicNameValuePair(h.EVENT_PAUSE, "1"));
                d(h.EVENT_PAUSE);
                return;
            case AdPlaying:
                this.d.add(new BasicNameValuePair(h.EVENT_RESUME, "1"));
                d(h.EVENT_RESUME);
                return;
            case AdVideoStart:
                this.d.add(new BasicNameValuePair(h.EVENT_START, "1"));
                d(h.EVENT_START);
                return;
            case AdVideoFirstQuartile:
                this.d.add(new BasicNameValuePair(h.EVENT_FIRST_QUARTILE, "1"));
                d(h.EVENT_FIRST_QUARTILE);
                return;
            case AdVideoMidpoint:
                this.d.add(new BasicNameValuePair(h.EVENT_MID_POINT, "1"));
                d(h.EVENT_MID_POINT);
                return;
            case AdVideoThirdQuartile:
                this.d.add(new BasicNameValuePair(h.EVENT_THIRD_QUARTILE, "1"));
                d(h.EVENT_THIRD_QUARTILE);
                return;
            case AdLoaded:
                this.d.add(new BasicNameValuePair(h.EVENT_CREATIVE_VIEW, "1"));
                d(h.EVENT_CREATIVE_VIEW);
                return;
            case AdVolumeChange:
                if (this.D == 0) {
                    this.d.add(new BasicNameValuePair(h.EVENT_MUTE, "1"));
                    d(h.EVENT_MUTE);
                    return;
                } else {
                    this.d.add(new BasicNameValuePair(h.EVENT_UNMUTE, "1"));
                    d(h.EVENT_UNMUTE);
                    return;
                }
            case AdUserClose:
                this.d.add(new BasicNameValuePair(h.EVENT_CLOSE, "1"));
                d(h.EVENT_CLOSE);
                return;
            default:
                return;
        }
    }

    private static synchronized void a(final String str) {
        synchronized (q.class) {
            synchronized (str) {
                if (Util.p(c)) {
                    new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.q.1
                        @Override // java.lang.Runnable
                        public void run() {
                            try {
                                Log.i("PrmVast", "Sending vast event:" + str);
                                Util.a("URL: " + str);
                                HttpResponse execute = new DefaultHttpClient().execute(new HttpGet(str));
                                int statusCode = execute == null ? 0 : execute.getStatusLine().getStatusCode();
                                Log.i("PrmVast", "Status code: " + statusCode);
                                if (statusCode == 200) {
                                    Log.i("PrmVast", "VAST Data: " + EntityUtils.toString(execute.getEntity()));
                                } else {
                                    Log.i("PrmVast", "Error reason: " + execute.getStatusLine().getReasonPhrase());
                                }
                            } catch (Exception e) {
                                Log.e("PrmVast", "Exception: ", e);
                            }
                        }
                    }, "vast_event").start();
                }
            }
        }
    }

    private void o() {
        try {
            if (this.a != null) {
                for (HashMap<String, String> hashMap : this.a.f()) {
                    synchronized (hashMap) {
                        String str = hashMap.get(h.IMPRESSION);
                        Log.i("PrmVast", "Sending impression data: " + hashMap.get(h.ID));
                        if (str != null && !str.equals("")) {
                            a(str);
                        } else {
                            Log.i("PrmVast", "impression url not present");
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e("PrmVast", "Error occurred while sending impression data: ", e);
        }
    }

    private void p() {
        try {
            if (this.b != null) {
                try {
                    for (HashMap<String, String> hashMap : this.b.getVideoClickTracking()) {
                        String str = hashMap.get(h.CLICK_TRACKING);
                        Log.i("PrmVast", "Sending click data: " + hashMap.get(h.ID));
                        if (str != null && !str.equals("")) {
                            a(str);
                        } else {
                            Log.i("PrmVast", "url is null");
                        }
                    }
                } catch (Exception e) {
                    Log.e("PrmVast", "Error occurred while sending click tracking data: ", e);
                }
                for (HashMap<String, String> hashMap2 : this.b.getVideoCustomClickTracking()) {
                    Log.i("PrmVast", "Sending cutom click data: " + hashMap2.get(h.ID));
                    String str2 = hashMap2.get(h.CUSTOM_CLICK);
                    if (str2 != null && !str2.equals("")) {
                        a(str2);
                    } else {
                        Log.i("PrmVast", "url is null");
                    }
                }
            }
        } catch (Exception e2) {
            Log.e("PrmVast", "Error occurred while sending click data: ", e2);
        }
    }

    private synchronized void d(String str) {
        try {
            if (this.b != null && str != null && !str.equalsIgnoreCase("")) {
                HashMap<String, String> trackingEventMap = this.b.getTrackingEventMap();
                if (trackingEventMap != null && trackingEventMap.containsKey(str)) {
                    String str2 = trackingEventMap.get(str);
                    Log.i("PrmVast", "Sending tracking data: " + str);
                    if (str2 != null && !str2.equals("")) {
                        a(str2);
                    } else {
                        Log.i("PrmVast", "url is null");
                    }
                } else {
                    Log.i("PrmVast", "Tracking event key not present in vast xml " + str);
                }
            }
        } catch (Exception e) {
            Log.e("PrmVast", "Error occurred while sending tracking data: ", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void g(int i) {
        try {
            if (this.a != null) {
                this.d.add(new BasicNameValuePair(IM.EVENT_ERROR, "1"));
                Log.i("PrmVast", "Sending error data: ");
                String j = this.a.j();
                if (j != null && !j.equals("")) {
                    String adParams = this.b.getAdParams();
                    if (j.contains("[ERRORCODE]")) {
                        j = j.replace("[ERRORCODE]", "" + i);
                    }
                    if (adParams != null && (adParams.startsWith("&") || j.endsWith("&"))) {
                        j = j + adParams;
                    } else if (adParams != null && !adParams.equalsIgnoreCase("")) {
                        j = j + "&" + adParams;
                    }
                    a(j);
                    return;
                }
                Log.i("PrmVast", "error url is null");
            }
        } catch (Exception e) {
            Log.e("PrmVast", "Error occurred while sending error data: ", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void n() {
        try {
            try {
                if (this.b != null) {
                    String adParams = this.b.getAdParams();
                    if (adParams != null && !adParams.equals("")) {
                        for (String str : URLDecoder.decode(adParams, "UTF-8").split("&")) {
                            String[] split = str.split("=");
                            this.d.add(new BasicNameValuePair(split[0], split[1]));
                        }
                    } else {
                        Log.i("PrmVast", "Ad param is null");
                    }
                }
            } catch (Exception e) {
                Log.e("PrmVast", "Error occurred while sending: ", e);
            }
            this.d.add(new BasicNameValuePair("adduration", "" + this.C));
            this.d.add(new BasicNameValuePair("adRemainingTime", "" + this.B));
            synchronized (this.d) {
                if (Util.p(c)) {
                    new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.q.2
                        @Override // java.lang.Runnable
                        public void run() {
                            try {
                                String decodeString = Base64.decodeString(e.URL_VAST_EVENT_API);
                                DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
                                HttpPost httpPost = new HttpPost(decodeString);
                                BasicHttpParams basicHttpParams = new BasicHttpParams();
                                defaultHttpClient.getParams().setParameter("http.useragent", q.this.F);
                                ArrayList arrayList = new ArrayList();
                                arrayList.addAll(q.this.d);
                                Log.i("PrmVast", "Sending vast event:" + arrayList);
                                httpPost.setEntity(new UrlEncodedFormEntity(arrayList));
                                httpPost.setParams(basicHttpParams);
                                HttpConnectionParams.setConnectionTimeout(basicHttpParams, 15000);
                                HttpConnectionParams.setSoTimeout(basicHttpParams, 15000);
                                HttpResponse execute = defaultHttpClient.execute(httpPost);
                                int statusCode = execute == null ? 0 : execute.getStatusLine().getStatusCode();
                                Log.i("PrmVast", "Status code: " + statusCode);
                                if (statusCode == 200) {
                                    Log.i("PrmVast", "Vast impression: " + EntityUtils.toString(execute.getEntity()));
                                } else {
                                    Log.i("PrmVast", "Error reason: " + execute.getStatusLine().getReasonPhrase());
                                }
                            } catch (Exception e2) {
                                Log.e("PrmVast", "Exception: ", e2);
                            }
                        }
                    }, "vast_report").start();
                }
            }
        } catch (Exception e2) {
            Log.e("PrmVast", "Error occurred while sending data: ", e2);
        }
    }
}
