package com.cguvuuqvlp.zaliiliwdx185920;

import android.graphics.Bitmap;
import android.os.AsyncTask;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
final class g extends AsyncTask<Void, Void, Void> {
    Bitmap a = null;
    final String b;
    final a<Bitmap> c;

    public g(String str, a<Bitmap> aVar) {
        this.b = str;
        this.c = aVar;
        Util.a("Image URL: " + str);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Removed duplicated region for block: B:23:0x007e  */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Void doInBackground(java.lang.Void... r8) {
        /*
            r7 = this;
            r2 = 0
            java.net.URL r0 = new java.net.URL     // Catch: java.lang.Throwable -> L7b java.lang.Exception -> L89
            java.lang.String r1 = r7.b     // Catch: java.lang.Throwable -> L7b java.lang.Exception -> L89
            r0.<init>(r1)     // Catch: java.lang.Throwable -> L7b java.lang.Exception -> L89
            java.net.URLConnection r0 = r0.openConnection()     // Catch: java.lang.Throwable -> L7b java.lang.Exception -> L89
            java.net.HttpURLConnection r0 = (java.net.HttpURLConnection) r0     // Catch: java.lang.Throwable -> L7b java.lang.Exception -> L89
            java.lang.String r1 = "GET"
            r0.setRequestMethod(r1)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            r1 = 20000(0x4e20, float:2.8026E-41)
            r0.setConnectTimeout(r1)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            r1 = 20000(0x4e20, float:2.8026E-41)
            r0.setReadTimeout(r1)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            r1 = 0
            r0.setUseCaches(r1)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            r1 = 0
            r0.setDefaultUseCaches(r1)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            r0.connect()     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            int r1 = r0.getResponseCode()     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            r3 = 200(0xc8, float:2.8E-43)
            if (r1 != r3) goto L40
            java.io.InputStream r1 = r0.getInputStream()     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            android.graphics.Bitmap r1 = android.graphics.BitmapFactory.decodeStream(r1)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            r7.a = r1     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
        L3a:
            if (r0 == 0) goto L3f
            r0.disconnect()
        L3f:
            return r2
        L40:
            java.lang.String r3 = "PrmSDK"
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            r4.<init>()     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            java.lang.String r5 = "Http code: "
            java.lang.StringBuilder r4 = r4.append(r5)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            java.lang.StringBuilder r1 = r4.append(r1)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            java.lang.String r4 = "message: "
            java.lang.StringBuilder r1 = r1.append(r4)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            java.lang.String r4 = r0.getResponseMessage()     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            java.lang.StringBuilder r1 = r1.append(r4)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            java.lang.String r1 = r1.toString()     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            android.util.Log.w(r3, r1)     // Catch: java.lang.Exception -> L67 java.lang.Throwable -> L82
            goto L3a
        L67:
            r1 = move-exception
            r6 = r1
            r1 = r0
            r0 = r6
        L6b:
            r0.printStackTrace()     // Catch: java.lang.Throwable -> L86
            java.lang.String r0 = "PrmSDK"
            java.lang.String r3 = "Network Error, please try again later"
            android.util.Log.e(r0, r3)     // Catch: java.lang.Throwable -> L86
            if (r1 == 0) goto L3f
            r1.disconnect()
            goto L3f
        L7b:
            r0 = move-exception
        L7c:
            if (r2 == 0) goto L81
            r2.disconnect()
        L81:
            throw r0
        L82:
            r1 = move-exception
            r2 = r0
            r0 = r1
            goto L7c
        L86:
            r0 = move-exception
            r2 = r1
            goto L7c
        L89:
            r0 = move-exception
            r1 = r2
            goto L6b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.cguvuuqvlp.zaliiliwdx185920.g.doInBackground(java.lang.Void[]):java.lang.Void");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void onPostExecute(Void r3) {
        if (this.c != null) {
            this.c.a(this.a);
        }
    }
}
