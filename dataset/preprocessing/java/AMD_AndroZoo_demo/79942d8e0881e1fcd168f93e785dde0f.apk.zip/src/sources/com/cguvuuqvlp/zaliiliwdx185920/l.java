package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class l {
    static final int BANNER_AD_BROWSER_ACTIVTY_NOT_FOUND = 109;
    static final int INVALID_APIKEY = 101;
    static final int REQUIRED_PERMISSIONS_NOT_FOUND = 100;
    static final int REQUIRED_VIDEO_AD_PERMISSIONS_NOT_FOUND = 110;
    static final int SMARTWALL_ACTIVITY_NOT_FOUND = 103;
    static final int SMARTWALL_BROWSER_ACTITY_NOT_FOUND = 104;
    static final int VIDEO_AD_ACTIVITY_NOT_FOUND = 102;
    private Context a;

    public l(Context context, int i) {
        if (context != null) {
            this.a = context;
            if (Util.p(context)) {
                a(i);
            }
        }
    }

    private void a(final int i) {
        synchronized (this) {
            try {
            } catch (Exception e) {
                Log.e(e.TAG, "Sending integration error failed.", e);
            }
            if (Util.j() == null || Util.j().equals("0")) {
                Log.i(e.TAG, "Appid is invalid. Sending report aborted.");
            } else {
                new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.l.1
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            PackageInfo packageInfo = l.this.a.getPackageManager().getPackageInfo(l.this.a.getPackageName(), 0);
                            String str = "" + packageInfo.versionCode;
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(new BasicNameValuePair("appVersion", str));
                            arrayList.add(new BasicNameValuePair(e.APP_ID, Util.j()));
                            arrayList.add(new BasicNameValuePair("errorCode", "" + i));
                            arrayList.add(new BasicNameValuePair(e.PACKAGE_NAME, l.this.a.getPackageName()));
                            arrayList.add(new BasicNameValuePair("appName", l.this.a.getPackageManager().getApplicationLabel(packageInfo.applicationInfo).toString()));
                            Log.i(e.TAG, "Error values: " + arrayList);
                            DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
                            HttpPost httpPost = new HttpPost(Base64.decodeString(e.ERROR_URL));
                            httpPost.setEntity(new UrlEncodedFormEntity(arrayList));
                            BasicHttpParams basicHttpParams = new BasicHttpParams();
                            httpPost.setParams(basicHttpParams);
                            HttpConnectionParams.setConnectionTimeout(basicHttpParams, 7000);
                            HttpConnectionParams.setSoTimeout(basicHttpParams, 7000);
                            HttpResponse execute = defaultHttpClient.execute(httpPost);
                            int statusCode = execute != null ? execute.getStatusLine().getStatusCode() : 0;
                            Log.i(e.TAG, "Status code: " + statusCode);
                            if (statusCode == 200) {
                                Log.i(e.TAG, "Error sent: " + EntityUtils.toString(execute.getEntity()));
                            } else {
                                Log.i(e.TAG, "Status Code: " + statusCode + ", Reason: " + execute.getStatusLine().getReasonPhrase());
                            }
                        } catch (PackageManager.NameNotFoundException e2) {
                            e2.printStackTrace();
                        } catch (UnsupportedEncodingException e3) {
                            e3.printStackTrace();
                        } catch (ClientProtocolException e4) {
                            e4.printStackTrace();
                        } catch (IOException e5) {
                            e5.printStackTrace();
                        } catch (Exception e6) {
                            e6.printStackTrace();
                        }
                    }
                }).start();
            }
        }
    }
}
