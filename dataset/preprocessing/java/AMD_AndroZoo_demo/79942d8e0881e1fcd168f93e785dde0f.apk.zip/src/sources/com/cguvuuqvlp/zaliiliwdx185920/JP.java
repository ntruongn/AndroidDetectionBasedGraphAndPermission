package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.Context;
import android.util.Log;
import com.google.android.gms.plus.PlusShare;
import java.io.IOException;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
abstract class JP implements e {
    private static final String ERROR_KEY = "error";
    private static final String STATUS_KEY = "status";
    private static final String URL_KEY = "url";

    JP() {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public static final class ParseMraidJson {
        private String a;
        private boolean b;
        private String c;
        private String d;
        private String e;
        private boolean f;
        private String g;
        private int h;
        private boolean i;
        private boolean j;
        private String k;
        private int l;
        private int m;

        public ParseMraidJson(Context context, JSONObject jsonObject) throws JSONException, Exception {
            int i = jsonObject.getInt(JP.STATUS_KEY);
            String string = jsonObject.getString("message");
            this.f = jsonObject.isNull("error") ? false : jsonObject.getBoolean("error");
            this.h = jsonObject.isNull("refreshtime") ? 45 : jsonObject.getInt("refreshtime");
            if (i == 200 && string.equalsIgnoreCase("Success")) {
                JSONObject jSONObject = new JSONObject(jsonObject.getString("data"));
                this.e = jSONObject.isNull("guid") ? "" : jSONObject.getString("guid");
                this.a = jSONObject.isNull("url") ? "" : jSONObject.getString("url");
                this.l = jSONObject.isNull("width") ? 320 : jSONObject.getInt("width");
                this.m = jSONObject.isNull("height") ? 50 : jSONObject.getInt("height");
                this.g = jSONObject.isNull("impurl") ? "" : jSONObject.getString("impurl");
                switch (jSONObject.isNull("istag") ? 0 : jSONObject.getInt("istag")) {
                    case 0:
                        this.i = false;
                        this.j = false;
                        this.b = false;
                        break;
                    case 1:
                        this.i = false;
                        this.j = true;
                        this.b = false;
                        break;
                    case 2:
                        this.i = true;
                        this.j = false;
                        this.b = false;
                        break;
                    case 3:
                        this.i = false;
                        this.j = false;
                        this.b = true;
                        break;
                    case 4:
                        this.i = false;
                        this.j = false;
                        this.b = true;
                        break;
                    default:
                        this.i = false;
                        this.j = false;
                        this.b = false;
                        break;
                }
                this.k = jSONObject.isNull("tag") ? "" : jSONObject.getString("tag");
                return;
            }
            throw new IOException(string);
        }

        public int getHeight() {
            return this.m;
        }

        public int getWidth() {
            return this.l;
        }

        public String getTag() {
            return this.k;
        }

        public boolean isHtmlAd() {
            return this.j;
        }

        public boolean isJsAd() {
            return this.i;
        }

        public String getAd_url() {
            return this.a;
        }

        public boolean isInlineScript() {
            return this.b;
        }

        public String getCampId() {
            return this.c;
        }

        public String getCreativeId() {
            return this.d;
        }

        public String getGuid() {
            return this.e;
        }

        public boolean isErrorReporting() {
            return this.f;
        }

        public String getImpression_url() {
            return this.g;
        }

        public int getRefreshTime() {
            return this.h;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public static final class ParseBannerAd {
        private String a;
        private String b;
        private String c;
        private String d;
        private String e;
        private String f;
        private String g;
        private String h;
        private String i;
        private String j;
        private String k;
        private String l;
        private boolean m;
        private String n;
        private boolean o;
        private boolean p;
        private boolean q;
        private boolean r;
        private int s;
        private String t;
        private String u;
        private int v;
        private int w;
        private HashMap<String, String> x;
        private final String y = "imp_url";

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean a(Context context, JSONObject jSONObject, String str) throws JSONException, Exception {
            String string;
            String string2;
            String string3;
            Util.a("Parsing banner json");
            String str2 = e.INVALID;
            this.m = jSONObject.isNull("error") ? false : jSONObject.getBoolean("error");
            int i = jSONObject.isNull(JP.STATUS_KEY) ? 0 : jSONObject.getInt(JP.STATUS_KEY);
            if (jSONObject.isNull("message")) {
                string = e.INVALID;
            } else {
                string = jSONObject.getString("message");
            }
            if (jSONObject.isNull("adtype")) {
                string2 = e.INVALID;
            } else {
                string2 = jSONObject.getString("adtype");
            }
            this.f = string2;
            this.e = jSONObject.getString("banner_type");
            if (i != 200 || !string.equalsIgnoreCase("Success")) {
                return false;
            }
            String string4 = jSONObject.isNull("data") ? "nodata" : jSONObject.getString("data");
            if (string4.equals("nodata")) {
                Log.i(e.TAG, "No data is not found in JSON.");
                return false;
            }
            JSONObject jSONObject2 = new JSONObject(string4);
            if (jSONObject2.isNull("url")) {
                string3 = e.INVALID;
            } else {
                string3 = jSONObject2.getString("url");
            }
            this.a = string3;
            if (!jSONObject2.isNull(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE)) {
                str2 = jSONObject2.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE);
            }
            this.d = str2;
            this.b = jSONObject2.isNull("adimage") ? "" : jSONObject2.getString("adimage");
            this.g = jSONObject2.isNull("creativeid") ? "" : jSONObject2.getString("creativeid");
            this.h = jSONObject2.isNull("campaignid") ? "" : jSONObject2.getString("campaignid");
            this.k = jSONObject2.isNull("sms") ? "" : jSONObject2.getString("sms");
            this.l = jSONObject2.isNull("number") ? "" : jSONObject2.getString("number");
            this.j = jSONObject2.isNull("banner_bg") ? "#000000" : jSONObject2.getString("banner_bg");
            this.i = jSONObject2.isNull("text_color") ? "#FFFFFF" : jSONObject2.getString("text_color");
            this.v = jSONObject2.isNull("width") ? 320 : jSONObject2.getInt("width");
            this.w = jSONObject2.isNull("height") ? 50 : jSONObject2.getInt("height");
            if (str.endsWith("text")) {
                if (this.i.equals("")) {
                    this.i = "#FFFFFF";
                    this.j = "#000000";
                    Log.w(IM.TAG, "Text color missing");
                }
                if (this.j.equals("")) {
                    this.i = "#FFFFFF";
                    this.j = "#000000";
                    Log.w(IM.TAG, "Banner bg missing");
                }
            }
            this.c = jSONObject2.isNull("text") ? "" : jSONObject2.getString("text");
            this.n = jSONObject2.isNull("api_url") ? "" : jSONObject2.getString("api_url");
            this.x = new HashMap<>();
            this.x.put("imp_url13", a(this.n, "13"));
            this.x.put("imp_url14", a(this.n, "14"));
            this.x.put("imp_url89", a(this.n, IM.MRAID_EVENT_ERROR));
            Util.a("Urls: " + this.x);
            this.u = jSONObject2.isNull("beacon") ? "" : jSONObject2.getString("beacon");
            switch (jSONObject2.isNull("istag") ? 0 : jSONObject2.getInt("istag")) {
                case 0:
                    this.o = false;
                    this.p = false;
                    this.r = false;
                    this.q = false;
                    break;
                case 1:
                    this.o = false;
                    this.p = true;
                    this.r = false;
                    this.q = false;
                    break;
                case 2:
                    this.o = true;
                    this.p = false;
                    this.r = false;
                    this.q = false;
                    break;
                case 3:
                    this.o = false;
                    this.p = false;
                    this.r = true;
                    this.q = false;
                    break;
                case 4:
                    this.o = false;
                    this.p = false;
                    this.r = false;
                    this.q = true;
                    break;
                default:
                    this.o = false;
                    this.p = false;
                    this.r = false;
                    this.q = false;
                    break;
            }
            this.t = jSONObject2.isNull("tag") ? "" : jSONObject2.getString("tag");
            this.s = jSONObject.isNull("refreshtime") ? 45 : jSONObject.getInt("refreshtime");
            return true;
        }

        private String a(String str, String str2) {
            if (str.contains("%event%")) {
                return str.replace("%event%", str2);
            }
            return str;
        }

        public String getEventUrl(String key) {
            if (this.x != null) {
                return this.x.get("imp_url" + key);
            }
            return null;
        }

        public void removeEventUrl(String key) {
            if (this.x != null) {
                this.x.remove("imp_url" + key);
            }
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean a() {
            return this.r;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean b() {
            return this.q;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String c() {
            return this.a;
        }

        public String getAdimage() {
            return this.b;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String d() {
            return this.c;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String e() {
            return this.d;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String f() {
            return this.e;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String g() {
            return this.f;
        }

        String h() {
            return this.g;
        }

        String i() {
            return this.h;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String j() {
            return this.i;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String k() {
            return this.j;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String l() {
            return this.k;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String m() {
            return this.l;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean n() {
            return this.m;
        }

        public String getApi_url() {
            return this.n;
        }

        public boolean isJsAd() {
            return this.o;
        }

        public int getRefreshTime() {
            return this.s;
        }

        public boolean isHtmlAd() {
            return this.p;
        }

        public String getTag() {
            return this.t;
        }

        public String getBeaconUrl() {
            return this.u;
        }

        public int getWidth() {
            return this.v;
        }

        public int getHeight() {
            return this.w;
        }
    }
}
