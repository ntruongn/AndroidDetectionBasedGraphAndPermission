package com.cguvuuqvlp.zaliiliwdx185920;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Paint;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import com.cguvuuqvlp.zaliiliwdx185920.AdView;
import com.cguvuuqvlp.zaliiliwdx185920.JP;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class IB extends WebView {
    private final String a;
    private JP.ParseBannerAd b;
    private AdView.a c;
    private boolean d;
    private AdView e;
    private boolean f;

    @SuppressLint({"SetJavaScriptEnabled"})
    public IB(Context context, int newWidth, int newHeight, final Handler loadingListener, JP.ParseBannerAd ad, AdView.a animationListener, boolean isTestMode, AdView adView) {
        super(context);
        this.a = IM.TAG;
        try {
            this.d = isTestMode;
            clearView();
            this.c = animationListener;
            this.e = adView;
            this.b = ad;
            setVerticalScrollBarEnabled(false);
            setHorizontalScrollBarEnabled(false);
            setScrollBarStyle(33554432);
            WebSettings settings = getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setLoadWithOverviewMode(true);
            settings.setLoadsImagesAutomatically(true);
            settings.setUseWideViewPort(false);
            a(settings);
            setBackgroundColor(0);
            setWebViewClient(new WebViewClient() { // from class: com.cguvuuqvlp.zaliiliwdx185920.IB.1
                @Override // android.webkit.WebViewClient
                public void onLoadResource(WebView view, String url) {
                    if (IB.this.f && !url.equals(IB.this.b.getTag())) {
                        IB.this.b(url);
                        IB.this.stopLoading();
                    } else {
                        super.onLoadResource(view, url);
                    }
                }

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    if (IB.this.f && !url.equals(IB.this.b.getTag())) {
                        IB.this.b(url);
                    } else {
                        view.loadUrl(url);
                    }
                    return true;
                }

                @Override // android.webkit.WebViewClient
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    super.onReceivedError(view, errorCode, description, failingUrl);
                    IB.this.c(IM.MRAID_EVENT_ERROR);
                    if (loadingListener != null) {
                        loadingListener.sendEmptyMessage(8);
                        Util.a("Error in ad loading.");
                    }
                    if (AdView.b != null) {
                        AdView.b.onErrorListener(description);
                    }
                }

                @Override // android.webkit.WebViewClient
                public void onPageFinished(WebView view, String url) {
                    if (loadingListener != null) {
                        loadingListener.sendEmptyMessage(0);
                        Util.a("Ad loading complete");
                    }
                    IB.this.c("14");
                    if (AdView.b != null) {
                        AdView.b.onAdLoadedListener();
                    }
                }
            });
            if (Build.VERSION.SDK_INT >= 11) {
                try {
                    try {
                        try {
                            getClass().getMethod("setLayerType", Integer.TYPE, Paint.class).invoke(this, 1, null);
                        } catch (InvocationTargetException e) {
                            e.printStackTrace();
                        }
                    } catch (IllegalAccessException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                } catch (IllegalArgumentException e4) {
                    e4.printStackTrace();
                } catch (NoSuchMethodException e5) {
                }
            }
            setLayoutParams(new FrameLayout.LayoutParams(this.e.getadWidth(), this.e.getadHeight()));
            if (this.b.a()) {
                StringBuilder sb = new StringBuilder();
                sb.append("<style>* {margin:0;padding:0; width: " + newWidth + "; height: " + newHeight + ";}</style>\n");
                sb.append(this.b.getTag());
                loadDataWithBaseURL(null, sb.toString(), "text/html", "UTF-8", null);
                return;
            }
            if (this.b.b()) {
                if (this.b.getTag() != null && !this.b.getTag().equals("")) {
                    loadUrl(this.b.getTag());
                    return;
                } else {
                    Log.e(IM.TAG, "Url is null");
                    return;
                }
            }
            if (this.b.isJsAd()) {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("<html><head>\n");
                sb2.append(this.b.getTag());
                sb2.append("\n<style>* {margin:0;padding:0; width: " + newWidth + "; height: " + newHeight + ";}</style></head><body>");
                sb2.append("</body></html>");
                loadDataWithBaseURL(null, sb2.toString(), "text/html", "UTF-8", null);
                return;
            }
            if (this.b.isHtmlAd()) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append("<html><head><style>* {margin:0;padding:0; width: " + newWidth + "; height: " + newHeight + ";}</style></head><body>\n").append(this.b.getTag()).append("\n</body></html>");
                loadDataWithBaseURL(null, sb3.toString(), "text/html", "UTF-8", null);
                return;
            }
            if (this.b.f().equals("text")) {
                StringBuilder sb4 = new StringBuilder();
                sb4.append("<html><head><style>* {margin:0;}</style></head><body>");
                sb4.append("<div style='background-color: " + this.b.k() + "; width: " + newWidth + "; height: " + newHeight + ";'><table><tr>");
                sb4.append("<td rowspan='2' align='center'><img alt='icon' style='padding: 2' src='" + this.b.getAdimage() + "'></td>");
                sb4.append("<td><font color='" + this.b.j() + "'><b>" + this.b.e() + "</b><br></font>");
                sb4.append("</td><tr><td><font size=2 color='" + this.b.j() + "'>" + this.b.d() + "</font></td></tr>");
                sb4.append("</table></div>");
                if (this.b.getBeaconUrl() != null && !this.b.getBeaconUrl().equals("")) {
                    sb4.append("<img src='" + this.b.getBeaconUrl() + "' height='1' width='1' />");
                }
                sb4.append("</body></html>");
                loadDataWithBaseURL(null, sb4.toString(), "text/html", "UTF-8", null);
                return;
            }
            StringBuilder sb5 = new StringBuilder();
            sb5.append("<html><head><style>* {margin:0;padding:0;}</style></head><body>").append("<img src=\"" + this.b.getAdimage() + "\" height=\"" + newHeight + "\" width=\"" + newWidth + "\"/>");
            if (this.b.getBeaconUrl() != null && !this.b.getBeaconUrl().equals("")) {
                sb5.append("<img src='" + this.b.getBeaconUrl() + "' height='1' width='1' />");
            }
            sb5.append("</body></html>");
            loadDataWithBaseURL(null, sb5.toString(), "text/html", "UTF-8", null);
        } catch (Exception e6) {
            Log.w(IM.TAG, "Error occurred while laoding banner: ", e6);
            c(IM.MRAID_EVENT_ERROR);
        }
    }

    @Override // android.webkit.WebView
    public void loadDataWithBaseURL(String baseUrl, String data, String mimeType, String encoding, String historyUrl) {
        a(data);
        super.loadDataWithBaseURL(baseUrl, data, mimeType, encoding, historyUrl);
    }

    private void a(String str) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void b(String str) {
        this.f = false;
        if (str != null) {
            try {
            } catch (Exception e) {
                Log.w(IM.TAG, "Not able to redirect: ", e);
                c(IM.MRAID_EVENT_ERROR);
            }
            if (!str.equals("")) {
                Log.i(IM.TAG, "Redirecting>> ");
                if (this.d) {
                    Util.a("Ad in test mode.");
                    c.a(getContext(), str);
                } else {
                    String encode = URLEncoder.encode(str, "UTF-8");
                    String eventUrl = this.b.getEventUrl("13");
                    String str2 = eventUrl + "&airpush_url=" + encode;
                    if (eventUrl != null && !eventUrl.equals("")) {
                        str = str2;
                    }
                    Util.a("Redirect url: " + str);
                    c.a(getContext(), str);
                }
                if (AdView.b != null) {
                    AdView.b.onAdClickListener();
                }
                this.b.removeEventUrl("13");
                this.e.d = true;
                this.e.c = 0L;
                this.e.getAd();
            }
        }
        Log.e(IM.TAG, "Redirect url is null: ");
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == 0) {
            if (this.b.isJsAd() || this.b.isHtmlAd() || this.b.a() || this.b.b()) {
                this.f = true;
                return super.dispatchTouchEvent(event);
            }
            try {
                String g = this.b.g();
                if (g.equalsIgnoreCase("BAU")) {
                    Log.i(e.TAG, "Banner url Ads.....");
                    b(this.b.c());
                    return true;
                }
                if (g.equalsIgnoreCase("BACC")) {
                    Log.i(e.TAG, "Banner CC Ads.....");
                    c.b(getContext(), this.b.m());
                } else if (g.equalsIgnoreCase("BACM")) {
                    Log.i(e.TAG, "Banner CM Ads.....");
                    c.a(getContext(), this.b.l(), this.b.m());
                } else {
                    Log.w(IM.TAG, "Invalid ad type for banner ad." + g);
                    return super.dispatchTouchEvent(event);
                }
                c("13");
                if (AdView.b == null) {
                    return true;
                }
                AdView.b.onAdClickListener();
                return true;
            } catch (Exception e) {
                Log.w(IM.TAG, "Error occurred while handling click", e);
                c(IM.MRAID_EVENT_ERROR);
                return true;
            }
        }
        return super.dispatchTouchEvent(event);
    }

    @Override // android.view.View
    protected void onAnimationEnd() {
        super.onAnimationEnd();
        if (this.c != null) {
            this.c.a();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void c(final String str) {
        synchronized (str) {
            if (this.d) {
                Util.a("Ad in test mode. Sending ignored.");
            } else if (Util.p(getContext())) {
                new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.IB.2
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            if (!IB.this.b.n() && str.equals(IM.MRAID_EVENT_ERROR)) {
                                Util.a("Error reporting is off.");
                                return;
                            }
                            Log.i(IM.TAG, "Sending banner event: ");
                            String eventUrl = IB.this.b.getEventUrl(str);
                            Util.a("URL: " + eventUrl);
                            if (eventUrl == null || eventUrl.equals("")) {
                                Log.i(IM.TAG, "Event url null");
                                Thread.currentThread().interrupt();
                                return;
                            }
                            DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
                            HttpPost httpPost = new HttpPost(eventUrl);
                            BasicHttpParams basicHttpParams = new BasicHttpParams();
                            httpPost.setParams(basicHttpParams);
                            HttpConnectionParams.setConnectionTimeout(basicHttpParams, 15000);
                            HttpConnectionParams.setSoTimeout(basicHttpParams, 10000);
                            HttpResponse execute = defaultHttpClient.execute(httpPost);
                            int statusCode = execute == null ? 0 : execute.getStatusLine().getStatusCode();
                            Log.i(IM.TAG, "Status code: " + statusCode);
                            if (statusCode == 200) {
                                Log.i(IM.TAG, "Banner Data: " + EntityUtils.toString(execute.getEntity()));
                                IB.this.b.removeEventUrl(str);
                            }
                        } catch (Exception e) {
                            Log.w(IM.TAG, "Exception: Sending banner event failed:" + e.getMessage());
                            Util.a("Error in banner event", e);
                        }
                    }
                }, "banner_event").start();
            }
        }
    }

    @SuppressLint({"InlinedApi"})
    void a(WebSettings webSettings) {
        try {
            if (Build.VERSION.SDK_INT >= 8) {
                webSettings.setPluginState(WebSettings.PluginState.ON);
            }
        } catch (Throwable th) {
        }
    }

    @Override // android.webkit.WebView
    public void clearView() {
        try {
            if (Build.VERSION.SDK_INT >= 18) {
                loadUrl("about:blank");
            } else {
                super.clearView();
            }
        } catch (Exception e) {
            Util.a("Error in clear view", e);
        }
    }
}
