package com.cguvuuqvlp.zaliiliwdx185920;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;
import com.cguvuuqvlp.zaliiliwdx185920.AdListener;
import com.cguvuuqvlp.zaliiliwdx185920.XmlParser;
import com.cguvuuqvlp.zaliiliwdx185920.q;
import com.google.android.gms.drive.DriveFile;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class VDActivity extends q implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener, View.OnClickListener {
    static final String ACTION_PLAY = "play_video";
    private static final int ID_AD_INFO_TEXT_VIEW = 106;
    private static final int ID_AD_PROGRESS_TEXT = 111;
    private static final int ID_ICON_IMAGE_VIEW = 102;
    private static final int ID_MUTE_BUTTON = 112;
    private static final int ID_PLAY_BUTTON = 107;
    private static final int ID_SEEK_BAR = 109;
    private static final int ID_SKIP_BUTTON = 110;
    private static final int ID_VIDEO_PLAYER = 108;
    private XmlParser.Creative B;
    private Uri C;
    private ProgressBar D;
    private TextView E;
    private Button F;
    private ImageButton G;
    private ImageButton H;
    private int L;
    private int M;
    private int N;
    private int O;
    Handler a;
    private ProgressDialog x;
    private XmlParser y;
    private VideoView z;
    private final String w = h.TAG;
    private boolean A = true;
    private boolean I = true;
    private int J = 0;
    private boolean K = false;
    View.OnTouchListener b = new View.OnTouchListener() { // from class: com.cguvuuqvlp.zaliiliwdx185920.VDActivity.1
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View v, MotionEvent event) {
            String videoClickThrough;
            try {
                if (v == VDActivity.this.z && event.getAction() == 0 && (videoClickThrough = VDActivity.this.B.getVideoClickThrough()) != null && !videoClickThrough.equals("")) {
                    VDActivity.this.a(videoClickThrough);
                    VDActivity.this.A = false;
                    VDActivity.this.a(q.a.AdClickThru);
                    VDActivity.this.z.stopPlayback();
                    VDActivity.this.finish();
                    return true;
                }
            } catch (Exception e) {
                e.printStackTrace();
                Log.e(h.TAG, "Error occured while on video click", e);
                VDActivity.this.A = true;
                VDActivity.this.a(VDActivity.this.u);
            }
            return false;
        }
    };
    Runnable c = new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.VDActivity.2
        @Override // java.lang.Runnable
        public void run() {
            VDActivity.this.e(VDActivity.this.I);
        }
    };

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x0127 -> B:6:0x004c). Please submit an issue!!! */
    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        Intent intent;
        super.onCreate(savedInstanceState);
        this.a = new Handler();
        MainActivity.a(true);
        this.d = new HashSet();
        a((Context) this);
        getWindow().setFormat(-3);
        getWindow().addFlags(128);
        try {
            c(new WebView(this).getSettings().getUserAgentString());
            intent = getIntent();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(h.TAG, "Excetion occurred in video ad.", e);
        }
        if (!intent.getAction().equals(ACTION_PLAY)) {
            finish();
            return;
        }
        this.C = intent.getData();
        Util.a("VideoAdActivty: url: " + this.C);
        setRequestedOrientation(0);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        this.x = ProgressDialog.show(this, null, "Loading....");
        this.y = p.b();
        a(this.y);
        a(q.a.AdImpression);
        List<XmlParser.Creative> m = this.y.m();
        if (m != null && m.size() > 0) {
            this.B = m.get(0);
            a(this.B);
            HashMap<String, Object> hashMap = this.B.getMediaFiles().get(0);
            int intValue = ((Integer) hashMap.get(h.MEDIA_FILE_BIT_RATE)).intValue();
            int intValue2 = ((Integer) hashMap.get("width")).intValue();
            int intValue3 = ((Integer) hashMap.get("height")).intValue();
            Object obj = hashMap.get("apiFramework");
            if (obj != null && !obj.equals("VPAID")) {
                Log.e(h.TAG, "Invalid apiFramwork: " + obj);
                g(this.v);
                return;
            } else {
                a(intValue2, intValue3, h.EVENT_FULL_SCREEN, intValue, this.B.getAdParams(), null);
                return;
            }
        }
        if (this.x != null) {
            this.x.dismiss();
        }
        finish();
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.q
    void a(int i, int i2, String str, int i3, String str2, String str3) {
        try {
            ((AudioManager) getSystemService("audio")).setStreamMute(3, false);
        } catch (Exception e) {
        }
        try {
            setContentView(new VpaidLayout(this));
            this.E = (TextView) findViewById(ID_AD_PROGRESS_TEXT);
            this.D = (ProgressBar) findViewById(ID_SEEK_BAR);
            this.z = (VideoView) findViewById(ID_VIDEO_PLAYER);
            this.F = (Button) findViewById(ID_SKIP_BUTTON);
            this.F.setOnClickListener(this);
            this.G = (ImageButton) findViewById(ID_PLAY_BUTTON);
            this.G.setOnClickListener(this);
            this.H = (ImageButton) findViewById(ID_MUTE_BUTTON);
            this.H.setOnClickListener(this);
            this.z.setVideoURI(this.C);
            this.z.setOnTouchListener(this.b);
            this.z.setOnPreparedListener(this);
            this.z.setOnCompletionListener(this);
            this.z.setOnErrorListener(this);
            this.z.requestFocus();
            this.z.setKeepScreenOn(true);
            setVolumeControlStream(3);
            this.z.start();
            a(q.a.AdLoaded);
        } catch (Exception e2) {
            Log.e(h.TAG, "Exception occurred while initializing video", e2);
            finish();
        } catch (Throwable th) {
            Log.e(h.TAG, "Error occurred while initializing video", th);
            finish();
        }
    }

    void a(String str) {
        Log.i(h.TAG, "Video clicked>>");
        try {
            try {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
                intent.setFlags(DriveFile.MODE_READ_ONLY);
                intent.addFlags(8388608);
                intent.addCategory("android.intent.category.LAUNCHER");
                intent.setClassName("com.android.browser", "com.android.browser.BrowserActivity");
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                try {
                    Log.i(h.TAG, "Browser not found.");
                    Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse(str));
                    intent2.setFlags(DriveFile.MODE_READ_ONLY);
                    intent2.addFlags(8388608);
                    startActivity(intent2);
                } catch (ActivityNotFoundException e2) {
                    Log.e(h.TAG, "Error whlie displaying push ad......: ", e2);
                }
            }
        } catch (Exception e3) {
            Log.e(h.TAG, "Error whlie displaying url......: ", e3);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.q
    void a(int i, int i2, String str) {
    }

    @Override // android.media.MediaPlayer.OnPreparedListener
    public void onPrepared(MediaPlayer mp) {
        try {
            if (this.x != null) {
                this.x.dismiss();
            }
            this.G.setBackgroundResource(17301539);
            if (this.B.isAdLinearSkipable()) {
                String skipOffSet = this.B.getSkipOffSet();
                if (skipOffSet == null || skipOffSet.equals("") || skipOffSet.equals("0:0:0") || skipOffSet.equals("%")) {
                    this.A = true;
                    a(this.e);
                    Log.e(h.TAG, "Invalid skip offset: " + skipOffSet);
                } else if (skipOffSet.contains(":")) {
                    this.J = (int) (VU.a(skipOffSet) / 1000);
                    this.F.setText("Skip in " + this.J + "s");
                } else if (skipOffSet.contains("%")) {
                    this.J = ((Integer.parseInt(skipOffSet.replace("%", "")) * this.z.getDuration()) / 100) / 1000;
                    this.F.setText("Skip in " + this.J + " sec");
                } else {
                    this.A = true;
                    a(this.e);
                    Log.e(h.TAG, "Invalid skip offset: " + skipOffSet);
                }
            }
            a();
        } catch (IllegalStateException e) {
            finish();
            e.printStackTrace();
        } catch (Exception e2) {
            finish();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.q
    void a() {
        if (Prm.adListener != null) {
            Prm.adListener.onSmartWallAdShowing();
        }
        try {
            if (this.B.isAdLinearSkipable()) {
                this.F.setVisibility(0);
                this.F.setEnabled(false);
            }
            this.O = this.z.getDuration();
            this.D.setMax(this.O);
            e(this.O);
            h(this.O / 1000);
            this.I = true;
            this.a.post(this.c);
            a(q.a.AdVideoStart);
        } catch (Exception e) {
            Log.e(h.TAG, "Exception occurred in start ad", e);
            finish();
            this.A = true;
            a(this.t);
        } catch (Throwable th) {
            Log.e(h.TAG, "Error occurred in start ad", th);
            this.A = true;
            a(this.t);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e(boolean z) {
        int currentPosition;
        int duration;
        try {
            if (this.z != null && z && (currentPosition = this.z.getCurrentPosition() / 1000) < (duration = this.z.getDuration() / 1000)) {
                if (this.B.isAdLinearSkipable() && currentPosition < this.J) {
                    this.F.setText("Skip in " + (this.J - currentPosition) + "s");
                }
                int i = duration - currentPosition;
                this.E.setText("Ad: " + VU.a(i));
                if (this.B.isAdLinearSkipable() && this.J == currentPosition) {
                    this.F.setEnabled(true);
                    this.F.setText("Skip Ad");
                    this.F.setClickable(true);
                }
                d(i);
                this.D.setProgress(this.z.getCurrentPosition());
                this.a.postDelayed(this.c, 1000L);
                if (this.L == currentPosition) {
                    a(q.a.AdVideoFirstQuartile);
                } else if (this.M == currentPosition) {
                    a(q.a.AdVideoMidpoint);
                } else if (this.N == currentPosition) {
                    a(q.a.AdVideoThirdQuartile);
                }
            }
        } catch (Exception e) {
            Log.e(h.TAG, "Exception occurred in updatePlayer", e);
        } catch (Throwable th) {
            Log.e(h.TAG, "Error occurred in updatePlayer", th);
        }
    }

    private void h(int i) {
        this.L = (i * 25) / 100;
        this.M = (i * 50) / 100;
        this.N = (i * 75) / 100;
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.q
    void b() {
        try {
            if (this.z != null && this.z.isPlaying()) {
                this.z.pause();
                this.I = false;
                this.G.setBackgroundResource(17301540);
                this.a.removeCallbacks(this.c);
                a(q.a.AdPaused);
            }
        } catch (IllegalStateException e) {
            this.A = true;
            a(this.u);
            Log.e(h.TAG, "Error occurred in pausing", e);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.q
    void c() {
        try {
            if (this.z != null && !this.z.isPlaying()) {
                this.z.start();
                this.I = true;
                this.G.setBackgroundResource(17301539);
                this.a.post(this.c);
                a(q.a.AdPlaying);
            }
        } catch (IllegalStateException e) {
            this.A = true;
            a(this.v);
            Log.e(h.TAG, "Error occurred in resume", e);
        }
    }

    @Override // android.media.MediaPlayer.OnCompletionListener
    public void onCompletion(MediaPlayer mp) {
        try {
            if (this.z != null) {
                this.z.stopPlayback();
            }
            mp.release();
        } catch (Exception e) {
            Log.e(h.TAG, "Error occurred in onCompletion", e);
        }
        this.A = false;
        a(this.v);
        o();
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.q
    void a(int i) {
        if (this.A) {
            Log.e(h.TAG, "Stopping ad. An error is occurred.");
            g(i);
        } else {
            Log.i(h.TAG, "Sending impression data>>");
            a(q.a.AdVideoComplete);
        }
        finish();
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.q
    void d() {
        this.A = false;
        a(q.a.AdSkipped);
        try {
            this.z.stopPlayback();
        } catch (Exception e) {
        }
        finish();
    }

    @Override // android.media.MediaPlayer.OnErrorListener
    public boolean onError(MediaPlayer mp, int what, int extra) {
        Log.e(h.TAG, "An error occurred while playing ad video. Error code: " + what);
        this.A = true;
        a(this.t);
        if (Prm.adListener != null) {
            Prm.sendAdError("An error occurred while playing video.");
        }
        return true;
    }

    private void o() {
        try {
            new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.VDActivity.3
                @Override // java.lang.Runnable
                public void run() {
                    VU.a(new File(Environment.getExternalStorageDirectory(), "ap_video"));
                }
            }, "delete").start();
        } catch (Exception e) {
            Log.e(h.TAG, "Not able to delete video.", e);
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case ID_PLAY_BUTTON /* 107 */:
                if (this.I) {
                    b();
                    return;
                } else {
                    c();
                    return;
                }
            case ID_VIDEO_PLAYER /* 108 */:
            case ID_SEEK_BAR /* 109 */:
            case ID_AD_PROGRESS_TEXT /* 111 */:
            default:
                return;
            case ID_SKIP_BUTTON /* 110 */:
                d();
                return;
            case ID_MUTE_BUTTON /* 112 */:
                if (this.K) {
                    ((AudioManager) getSystemService("audio")).setStreamMute(3, false);
                    this.K = false;
                    f(1);
                    this.H.setBackgroundResource(17301554);
                } else {
                    ((AudioManager) getSystemService("audio")).setStreamMute(3, true);
                    this.K = true;
                    f(0);
                    this.H.setBackgroundResource(17301553);
                }
                a(q.a.AdVolumeChange);
                return;
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        try {
            if (this.z.getCurrentPosition() > 0) {
                a(q.a.AdUserClose);
            }
        } catch (Exception e) {
        }
        if (this.x != null) {
            this.x.dismiss();
        }
        this.z.stopPlayback();
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public class VpaidLayout extends RelativeLayout implements h {
        private final float b;
        private Context c;

        @SuppressLint({"InlinedApi"})
        public VpaidLayout(Activity context) throws NullPointerException, Exception {
            super(context);
            this.c = context;
            this.b = context.getResources().getDisplayMetrics().density;
            setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
            XmlParser.Creative creative = VDActivity.this.y.m().get(0);
            final ImageView imageView = new ImageView(context);
            imageView.setId(102);
            try {
                List<HashMap<String, Object>> icons = creative.getIcons();
                if (icons == null || icons.isEmpty()) {
                    Util.a("hashmap empty");
                }
                HashMap<String, Object> hashMap = icons.get(0);
                if (hashMap.isEmpty()) {
                    Util.a("hash map");
                }
                int intValue = ((Integer) hashMap.get("width")).intValue();
                int intValue2 = ((Integer) hashMap.get("height")).intValue();
                System.out.println("width: " + intValue);
                String obj = hashMap.get(h.X_POSITION).toString();
                String obj2 = hashMap.get(h.Y_POSITION).toString();
                String obj3 = hashMap.containsKey(h.OFFSET) ? null : hashMap.get(h.OFFSET).toString();
                final String obj4 = hashMap.containsKey(h.DURATION) ? null : hashMap.get(h.DURATION).toString();
                String obj5 = hashMap.get(h.STATIC_RESOURCE).toString();
                System.out.println("icon url: " + obj5);
                a(obj5, imageView);
                if (obj3 != null && obj3.contains(":")) {
                    VDActivity.this.a.postDelayed(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.VDActivity.VpaidLayout.1
                        @Override // java.lang.Runnable
                        public void run() {
                            imageView.setVisibility(0);
                            Runnable runnable = new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.VDActivity.VpaidLayout.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    imageView.setVisibility(8);
                                }
                            };
                            if (obj4 != null && obj4.contains(":")) {
                                try {
                                    VDActivity.this.a.postDelayed(runnable, VU.a(obj4));
                                } catch (NullPointerException e) {
                                    e.printStackTrace();
                                } catch (NumberFormatException e2) {
                                    e2.printStackTrace();
                                } catch (Exception e3) {
                                    e3.printStackTrace();
                                }
                            }
                        }
                    }, VU.a(obj3));
                }
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(intValue, intValue2);
                if (obj.equals("left")) {
                    layoutParams.addRule(9);
                } else if (obj.equals("right")) {
                    layoutParams.addRule(11);
                } else {
                    try {
                        layoutParams.leftMargin = (int) Util.b(Float.parseFloat(obj), context);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (obj2.equals("top")) {
                    layoutParams.addRule(10);
                } else if (obj2.equals("bottom")) {
                    layoutParams.addRule(12);
                } else {
                    try {
                        layoutParams.topMargin = (int) Util.b(Float.parseFloat(obj2), context);
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
                imageView.setLayoutParams(layoutParams);
            } catch (Exception e3) {
                Util.a("Icon not present");
            }
            StringBuilder sb = new StringBuilder();
            String e4 = VDActivity.this.y.e();
            if (e4 != null && !e4.equals("")) {
                sb.append(VDActivity.this.y.e() + " ");
            }
            if (VDActivity.this.y.g() != null && !VDActivity.this.y.g().equals("")) {
                sb.append(VDActivity.this.y.g());
            }
            String h = VDActivity.this.y.h();
            if (h != null && !h.equals("")) {
                sb.append(" - by " + h);
            }
            TextView textView = new TextView(context);
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams2.addRule(1, 102);
            layoutParams2.addRule(10);
            layoutParams2.leftMargin = (int) (10.0f * this.b);
            textView.setLayoutParams(layoutParams2);
            textView.setId(VDActivity.ID_AD_INFO_TEXT_VIEW);
            textView.setSingleLine();
            textView.setTextAppearance(context, 16973892);
            textView.setText(sb.toString());
            VideoView videoView = new VideoView(context);
            videoView.setId(VDActivity.ID_VIDEO_PLAYER);
            RelativeLayout.LayoutParams layoutParams3 = Build.VERSION.SDK_INT > 17 ? new RelativeLayout.LayoutParams(-1, -1) : new RelativeLayout.LayoutParams(-2, -2);
            layoutParams3.bottomMargin = (int) (this.b * 17.0f);
            layoutParams3.topMargin = (int) (this.b * 17.0f);
            layoutParams3.rightMargin = (int) (this.b * 30.0f);
            layoutParams3.leftMargin = (int) (this.b * 30.0f);
            layoutParams3.addRule(13, -1);
            videoView.setLayoutParams(layoutParams3);
            Button button = new Button(context);
            button.setId(VDActivity.ID_SKIP_BUTTON);
            RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams4.addRule(11);
            layoutParams4.addRule(12);
            layoutParams4.bottomMargin = (int) (35.0f * this.b);
            button.setLayoutParams(layoutParams4);
            button.setBackgroundColor(-16777216);
            button.setTextColor(-1);
            button.setTypeface(Typeface.MONOSPACE, 16973892);
            button.setClickable(false);
            button.setVisibility(8);
            ImageButton imageButton = new ImageButton(context);
            imageButton.setId(VDActivity.ID_PLAY_BUTTON);
            RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams5.addRule(12);
            layoutParams5.addRule(9);
            imageButton.setLayoutParams(layoutParams5);
            imageButton.setBackgroundResource(17301539);
            ImageButton imageButton2 = new ImageButton(context);
            imageButton2.setId(VDActivity.ID_MUTE_BUTTON);
            RelativeLayout.LayoutParams layoutParams6 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams6.addRule(12);
            layoutParams6.addRule(1, VDActivity.ID_PLAY_BUTTON);
            imageButton2.setLayoutParams(layoutParams6);
            imageButton2.setBackgroundResource(17301554);
            ProgressBar progressBar = new ProgressBar(context, null, 16842872);
            RelativeLayout.LayoutParams layoutParams7 = new RelativeLayout.LayoutParams(-1, (int) (10.0f * this.b));
            layoutParams7.addRule(12);
            layoutParams7.addRule(1, VDActivity.ID_MUTE_BUTTON);
            layoutParams7.setMargins(((int) this.b) * 5, 0, ((int) this.b) * 65, (int) (this.b * 7.0f));
            progressBar.setLayoutParams(layoutParams7);
            progressBar.setId(VDActivity.ID_SEEK_BAR);
            TextView textView2 = new TextView(context);
            RelativeLayout.LayoutParams layoutParams8 = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams8.addRule(11);
            layoutParams8.addRule(12);
            textView2.setLayoutParams(layoutParams8);
            textView2.setTextColor(-1);
            textView2.setTextAppearance(context, 16973894);
            textView2.setBackgroundColor(-16777216);
            textView2.setId(VDActivity.ID_AD_PROGRESS_TEXT);
            addView(videoView);
            addView(imageView);
            addView(textView);
            addView(imageButton);
            addView(imageButton2);
            addView(progressBar);
            addView(button);
            addView(textView2);
        }

        void a(final String str, final ImageView imageView) throws NullPointerException {
            a<Bitmap> aVar = new a<Bitmap>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.VDActivity.VpaidLayout.2
                @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                public void a(final Bitmap bitmap) {
                    if (bitmap != null && VDActivity.this.a != null) {
                        VDActivity.this.a.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.VDActivity.VpaidLayout.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                imageView.setImageBitmap(bitmap);
                            }
                        });
                    }
                }

                @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                public void a() {
                    new g(str, this).execute(new Void[0]);
                }
            };
            if (Util.p(this.c)) {
                aVar.a();
            }
        }
    }

    @Override // android.app.Activity
    protected void onStop() {
        n();
        super.onStop();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        if (Prm.adListener != null) {
            Prm.adListener.onSmartWallAdClosed();
        }
        MainActivity.a(false);
        try {
            b bVar = new b(this);
            bVar.d(AdListener.AdType.video);
            if (bVar.a()) {
                bVar.c(AdListener.AdType.smartwall);
                bVar.a(false);
            }
        } catch (Exception e) {
        }
        try {
            ((AudioManager) getSystemService("audio")).setStreamMute(3, false);
        } catch (Exception e2) {
        }
        super.onDestroy();
    }
}
