package com.cguvuuqvlp.zaliiliwdx185920;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
abstract class i implements f {
    abstract void downloadApp(String str);

    abstract void open(String str);

    abstract void printJSLog(String str);

    abstract void sendSms(String str, String str2);

    abstract void setExpandProperties(String str);

    abstract void setOrientationProperties(String str);

    abstract void setResizeProperties(String str);

    abstract void showDialer(String str);

    abstract void showLocation(String str, String str2);
}
