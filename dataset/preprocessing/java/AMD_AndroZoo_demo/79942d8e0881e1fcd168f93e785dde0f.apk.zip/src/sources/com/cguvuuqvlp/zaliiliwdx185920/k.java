package com.cguvuuqvlp.zaliiliwdx185920;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import com.google.android.gms.drive.DriveFile;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class k extends Dialog implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    static final String AD_TYPE_DIALOG_CC = "DCC";
    static final String AD_TYPE_DIALOG_CM = "DCM";
    static final String AD_TYPE_DIALOG_U = "DAU";
    static final String AD_TYPE_OVERLAY = "OLAU";
    private static String n;
    private static String p;
    Activity a;
    View.OnTouchListener b;
    private final String c;
    private final String d;
    private final String e;
    private final String f;
    private final String g;
    private final String h;
    private final String i;
    private final String j;
    private final String k;
    private WebView q;
    private boolean s;
    private boolean t;
    private static int l = 250;
    private static int m = 300;
    private static boolean o = false;
    private static String r = "";

    @SuppressLint({"SetJavaScriptEnabled"})
    public k(Activity activity) {
        super(activity);
        this.c = e.TAG;
        this.d = "23";
        this.e = "24";
        this.f = "25";
        this.g = "43";
        this.h = "44";
        this.i = "45";
        this.j = "184";
        this.k = "183";
        this.s = false;
        this.t = false;
        this.b = new View.OnTouchListener() { // from class: com.cguvuuqvlp.zaliiliwdx185920.k.2
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View v, MotionEvent event) {
                if (v == k.this.q && event.getAction() == 0) {
                    k.this.t = true;
                    return false;
                }
                return false;
            }
        };
        try {
            this.a = activity;
            requestWindowFeature(1);
            getWindow().setBackgroundDrawable(new ColorDrawable(0));
            setCancelable(false);
            setCanceledOnTouchOutside(false);
            setOnCancelListener(this);
            setOnDismissListener(this);
            RelativeLayout relativeLayout = new RelativeLayout(activity);
            relativeLayout.setId(76);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams.addRule(13);
            relativeLayout.setLayoutParams(layoutParams);
            this.q = new WebView(activity);
            this.q.setId(54);
            this.q.getSettings().setJavaScriptEnabled(true);
            this.q.setWebChromeClient(new WebChromeClient());
            this.q.setHorizontalScrollBarEnabled(false);
            this.q.setVerticalScrollBarEnabled(false);
            this.q.getSettings().setCacheMode(-1);
            this.q.setBackgroundColor(0);
            this.q.setScrollBarStyle(33554432);
            this.q.addJavascriptInterface(new a(), "Overlay");
            this.q.setOnTouchListener(this.b);
            this.q.setWebViewClient(new WebViewClient() { // from class: com.cguvuuqvlp.zaliiliwdx185920.k.1
                @Override // android.webkit.WebViewClient
                public void onLoadResource(WebView view, String url) {
                    if (k.this.t && k.this.isShowing()) {
                        k.this.e(url);
                    } else {
                        super.onLoadResource(view, url);
                    }
                }

                @Override // android.webkit.WebViewClient
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    try {
                        if (k.this.s) {
                            Log.i(e.TAG, "Error in loading");
                            k.this.dismiss();
                            if (k.r.equals("DAU") || k.r.equals("DCC") || k.r.equals("DCM")) {
                                k.this.a("184");
                                return;
                            } else {
                                k.this.a("183");
                                return;
                            }
                        }
                        k.this.show();
                        if (k.r.equals("DAU") || k.r.equals("DCC") || k.r.equals("DCM")) {
                            k.this.a("43");
                        } else {
                            k.this.a("23");
                        }
                        if (Prm.adListener != null) {
                            Prm.adListener.onSmartWallAdShowing();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        k.this.a.finish();
                    }
                }

                @Override // android.webkit.WebViewClient
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    k.this.s = true;
                    try {
                        k.this.dismiss();
                        k.this.a.finish();
                    } catch (Throwable th) {
                        Log.e(e.TAG, "Error occurred while loading Overlay Ad: code " + errorCode + ", desc: " + description);
                    }
                    super.onReceivedError(view, errorCode, description, failingUrl);
                }

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    try {
                    } catch (Exception e) {
                        e.printStackTrace();
                        k.this.dismiss();
                        k.this.a.finish();
                    }
                    if (k.this.t) {
                        k.this.e(url);
                        return true;
                    }
                    view.loadUrl(url);
                    return true;
                }
            });
            this.q.loadDataWithBaseURL(null, n, "text/html", "UTF-8", null);
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(m, l);
            layoutParams2.addRule(13);
            this.q.setLayoutParams(layoutParams2);
            relativeLayout.addView(this.q);
            setContentView(relativeLayout);
        } catch (Exception e) {
            Log.e(e.TAG, "An error occured while starting Overlay Ad.");
            try {
                dismiss();
                activity.finish();
            } catch (Exception e2) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e(String str) {
        try {
            try {
                dismiss();
                try {
                    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
                    intent.setFlags(DriveFile.MODE_READ_ONLY);
                    intent.addFlags(8388608);
                    intent.addCategory("android.intent.category.LAUNCHER");
                    intent.setClassName("com.android.browser", "com.android.browser.BrowserActivity");
                    this.a.startActivity(intent);
                    if (r.equals("DAU") || r.equals("DCC") || r.equals("DCM")) {
                        a("44");
                    } else {
                        a("24");
                    }
                } catch (ActivityNotFoundException e) {
                    Log.i(e.TAG, "Browser not found.");
                    Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse(str));
                    intent2.setFlags(DriveFile.MODE_READ_ONLY);
                    intent2.addFlags(8388608);
                    this.a.startActivity(intent2);
                    if (r.equals("DAU") || r.equals("DCC") || r.equals("DCM")) {
                        a("44");
                    } else {
                        a("24");
                    }
                    this.a.finish();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                this.a.finish();
            }
        } catch (ActivityNotFoundException e3) {
            Log.e(e.TAG, "Error whlie displaying dialog ad......: " + e3.getMessage());
            this.a.finish();
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    private class a {
        private a() {
        }

        @JavascriptInterface
        public void close() {
            k.this.dismiss();
            if (k.r.equals("DAU") || k.r.equals("DCC") || k.r.equals("DCM")) {
                k.this.a("45");
            } else {
                k.this.a("25");
            }
            k.this.a.finish();
        }

        @JavascriptInterface
        public void open(String url) {
            k.this.e(url);
            k.this.a.finish();
        }

        @JavascriptInterface
        public void call(String number) {
            try {
                k.this.dismiss();
                Intent intent = new Intent("android.intent.action.DIAL", Uri.parse("tel:" + number));
                intent.addFlags(DriveFile.MODE_READ_ONLY);
                k.this.a.startActivity(intent);
                if (k.r.equals("DAU") || k.r.equals("DCC") || k.r.equals("DCM")) {
                    k.this.a("44");
                } else {
                    k.this.a("24");
                }
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
            } catch (Exception e2) {
            }
            k.this.a.finish();
        }

        @JavascriptInterface
        public void sms(String number, String text) {
            try {
                k.this.dismiss();
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.addFlags(DriveFile.MODE_READ_ONLY);
                intent.setType("vnd.android-dir/mms-sms");
                intent.putExtra("address", number);
                intent.putExtra("sms_body", text);
                k.this.a.startActivity(intent);
                if (k.r.equals("DAU") || k.r.equals("DCC") || k.r.equals("DCM")) {
                    k.this.a("44");
                } else {
                    k.this.a("24");
                }
            } catch (Exception e) {
                k.this.a.finish();
                e.printStackTrace();
            }
        }
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialog) {
        if (dialog != null) {
            try {
                dialog.dismiss();
            } catch (Exception e) {
                return;
            }
        }
        this.a.finish();
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialog) {
        if (this != null) {
            try {
                if (this.q != null) {
                    this.q.stopLoading();
                    this.q.removeAllViews();
                    this.q.destroy();
                }
                dismiss();
            } catch (Exception e) {
            } catch (Throwable th) {
            }
        }
        try {
            this.a.finish();
        } catch (Exception e2) {
            this.a.finish();
        }
    }

    final void a(final String str) {
        synchronized (str) {
            if (Util.p(getContext())) {
                new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.k.3
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            Log.i(e.TAG, "Sending overlay event: ");
                            if (k.o || (!str.equals("184") && !str.equals("183"))) {
                                String str2 = k.p;
                                if (k.p.contains("%event%")) {
                                    str2 = str2.replace("%event%", str);
                                }
                                Util.a("URL: " + str2);
                                DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
                                HttpPost httpPost = new HttpPost(str2);
                                BasicHttpParams basicHttpParams = new BasicHttpParams();
                                httpPost.setParams(basicHttpParams);
                                HttpConnectionParams.setConnectionTimeout(basicHttpParams, 15000);
                                HttpConnectionParams.setSoTimeout(basicHttpParams, 10000);
                                HttpResponse execute = defaultHttpClient.execute(httpPost);
                                int statusCode = execute == null ? 0 : execute.getStatusLine().getStatusCode();
                                Log.i(e.TAG, "Status code: " + statusCode);
                                if (statusCode == 200) {
                                    Log.i(e.TAG, "Overlay Data: " + EntityUtils.toString(execute.getEntity()));
                                    return;
                                }
                                return;
                            }
                            Util.a("Error reporting is off.");
                        } catch (Exception e) {
                            Log.e(e.TAG, "Exception in overlay: ", e);
                        }
                    }
                }, "overlay_event").start();
            }
        }
    }

    public static void a(int i) {
        l = i;
    }

    public static void b(int i) {
        m = i;
    }

    public static void b(String str) {
        n = str;
    }

    public static void a(boolean z) {
        o = z;
    }

    public static void c(String str) {
        p = str;
    }

    public static void d(String str) {
        r = str;
    }
}
