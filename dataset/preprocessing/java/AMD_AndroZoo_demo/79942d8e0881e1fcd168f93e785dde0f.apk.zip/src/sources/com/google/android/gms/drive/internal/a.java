package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.internal.p;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class a extends p.a {
    @Override // com.google.android.gms.drive.internal.p
    public void a(OnContentsResponse onContentsResponse) throws RemoteException {
    }

    @Override // com.google.android.gms.drive.internal.p
    public void a(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
    }

    @Override // com.google.android.gms.drive.internal.p
    public void a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
    }

    @Override // com.google.android.gms.drive.internal.p
    public void a(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
    }

    @Override // com.google.android.gms.drive.internal.p
    public void a(OnMetadataResponse onMetadataResponse) throws RemoteException {
    }

    @Override // com.google.android.gms.drive.internal.p
    public void m(Status status) throws RemoteException {
    }

    @Override // com.google.android.gms.drive.internal.p
    public void onSuccess() throws RemoteException {
    }
}
