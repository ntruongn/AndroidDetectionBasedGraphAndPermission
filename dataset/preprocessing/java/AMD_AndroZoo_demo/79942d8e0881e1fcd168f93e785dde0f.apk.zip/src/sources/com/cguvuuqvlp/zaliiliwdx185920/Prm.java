package com.cguvuuqvlp.zaliiliwdx185920;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import com.cguvuuqvlp.zaliiliwdx185920.AdListener;
import com.cguvuuqvlp.zaliiliwdx185920.JP;
import com.cguvuuqvlp.zaliiliwdx185920.Util;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.plus.PlusShare;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class Prm extends m {
    static final String TAG = "PrmSDK";
    private static Activity activity;
    static AdListener adListener;
    private static b cA;
    static Handler handler;
    static JP.ParseMraidJson parseMraidJson;
    private static boolean isIntegrationIssue = false;
    static boolean enableCaching = true;

    public Prm(Activity activity2, AdListener adListener2, boolean enableCaching2) {
        adListener = adListener2;
        enableCaching = enableCaching2;
        Log.i("PrmSDK", "Starting standard SDK 6.31");
        if (activity2 == null) {
            Log.e("PrmSDK", "Activity reference must not be null.");
            sendIntegrationError("Activty reference must not be null.");
            return;
        }
        if (!(activity2 instanceof Activity)) {
            Log.e("PrmSDK", "Invalid activty reference.");
            sendIntegrationError("Invalid Activity reference.");
            return;
        }
        activity = activity2;
        Util.c(activity2);
        if (checkRequiredDetails(activity2) && checkSmartWallintegration()) {
            isIntegrationIssue = false;
            Log.i("PrmSDK", "AppId: " + Util.j());
            Log.i("PrmSDK", "Caching enabled: " + enableCaching2);
            Util.d();
            cA = new b(activity2);
            SharedPreferences sharedPreferences = activity2.getSharedPreferences(e.SDK_PREFERENCE, 0);
            if (sharedPreferences == null || !sharedPreferences.contains(e.SDK_ENABLED)) {
                enableSDK(activity2, true);
            }
            handler = new Handler();
            if (validate(activity2)) {
                Util.a(activity2);
                return;
            }
            return;
        }
        isIntegrationIssue = true;
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.d
    public void runSmartWalllAd() {
        try {
            Log.i("PrmSDK", "Initialising SmartWall.....");
            if (!isIntegrationIssue && checkSmartWallintegration() && p.a((Context) activity)) {
                if (!Util.a(activity, (Class<?>) VDActivity.class)) {
                    Log.e("PrmSDK", "Required VDActivity not found in Manifest. Please add");
                    sendIntegrationError("Required VDActivity not found in Manifest. Please add");
                    new l(activity, LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
                    return;
                }
                if (activity == null || !isSDKEnabled(activity)) {
                    Log.i("PrmSDK", "Prm is disabled Please enable to recive ads.");
                    sendAdError("Prm is disabled Please enable to recive ads.");
                    return;
                }
                if (n.c(activity) > System.currentTimeMillis()) {
                    Log.i("PrmSDK", "SmartWall Ad called within 10 secs. Ignoring request.");
                    sendAdError("SmartWall Ad called within 10 secs. Ignoring request.");
                    return;
                }
                if (MainActivity.a()) {
                    Log.i("PrmSDK", "Another ad is showing on screen.");
                    sendAdError("Another ad is showing on screen.");
                    return;
                }
                if (cA == null) {
                    cA = new b(activity);
                }
                if (cA.e(AdListener.AdType.smartwall)) {
                    Log.i("PrmSDK", "SmartWall Ad already available in cache. Request ignored.");
                    sendAdError("SmartWall Ad already available in cache. Request Ignored.");
                    return;
                }
                n.b(activity);
                a<String> aVar = new a<String>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.Prm.1
                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a(String str) {
                        Log.i("PrmSDK", "SmartWall JSON: " + str);
                        if (str != null) {
                            try {
                                if (str.contains("<VAST") && Build.VERSION.SDK_INT > 7) {
                                    if (Prm.enableCaching) {
                                        new p(Prm.activity).a(str, true);
                                        return;
                                    } else {
                                        Prm.this.parseSmartwallJson(str);
                                        return;
                                    }
                                }
                                JSONObject jSONObject = new JSONObject(str);
                                int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                String string = jSONObject.isNull("message") ? "" : jSONObject.getString("message");
                                String string2 = jSONObject.isNull("adtype") ? "" : jSONObject.getString("adtype");
                                if (i == 200 && string.equalsIgnoreCase("Success") && !string2.equals("")) {
                                    if (Prm.enableCaching) {
                                        Prm.cA.a(AdListener.AdType.smartwall, str);
                                        m.sendAdCached(AdListener.AdType.smartwall);
                                        Prm.cA.a(true);
                                        return;
                                    }
                                    Prm.this.parseSmartwallJson(str);
                                    return;
                                }
                                Prm.validateStatusCode(i, string);
                            } catch (Exception e) {
                                Log.e("PrmSDK", "Error: ", e);
                            }
                        }
                    }

                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a() {
                        try {
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(new BasicNameValuePair("banner_type", "rich_media"));
                            arrayList.add(new BasicNameValuePair("supports", "" + Util.t(Prm.activity)));
                            arrayList.add(new BasicNameValuePair("placement_type", "fullpage"));
                            new Thread(new j(Prm.activity, this, arrayList, e.URL_INTERSTITIAL, 0L, true), "SmartWall").start();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                };
                if (Util.p(activity)) {
                    aVar.a();
                }
            }
        } catch (Exception e) {
            Log.e("PrmSDK", "Error occurred in startSmartWall method: ", e);
        }
    }

    void parseSmartwallJson(String result) {
        try {
            if (result.contains("<VAST") && Build.VERSION.SDK_INT > 7) {
                new p(activity).a(result, true);
                return;
            }
            JSONObject jSONObject = new JSONObject(result);
            int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
            String string = jSONObject.isNull("message") ? "" : jSONObject.getString("message");
            String string2 = jSONObject.isNull("adtype") ? "" : jSONObject.getString("adtype");
            if (i == 200 && !string2.equals("")) {
                if (string2.equalsIgnoreCase(e.AD_TYPE_AW)) {
                    parseAppWallJson(result);
                    return;
                }
                if (string2.equals("OLAU") || string2.equals(e.AD_TYPE_DAU) || string2.equals(e.AD_TYPE_DCC) || string2.equals(e.AD_TYPE_DCM)) {
                    showOverlayAd(result);
                    return;
                }
                if (!string2.equals("") && string2.equalsIgnoreCase(e.AD_TYPE_FP)) {
                    Log.w("PrmSDK", "Landing page ad not supported in this version");
                    return;
                } else if (!string2.equals("") && string2.equalsIgnoreCase(e.AD_TYPE_MFP)) {
                    parseRichMediaInterstitialJson(jSONObject);
                    return;
                } else {
                    Log.i("PrmSDK", "Invalid ad type delivered in SmartWall: " + string2);
                    return;
                }
            }
            validateStatusCode(i, string);
        } catch (JSONException e) {
            Log.e("PrmSDK", "Error in Smart Wall json: ", e);
        } catch (Exception e2) {
            Log.e("PrmSDK", "Error in Smart Wall response: ", e2);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.d
    public void runAppWall() {
        try {
            Log.i("PrmSDK", "Initialising AppWall.....");
            if (!isIntegrationIssue && checkSmartWallActivity()) {
                if (activity == null || !isSDKEnabled(activity)) {
                    Log.i("PrmSDK", "Prm is disabled Please enable to recive ads.");
                    sendAdError("Prm is disabled Please enable to recive ads.");
                    return;
                }
                if (n.c(activity) > System.currentTimeMillis()) {
                    Log.i("PrmSDK", "AppWall called within 10 secs. Ignoring request");
                    sendAdError("AppWall called within 10 secs. Ignoring request.");
                    return;
                }
                if (MainActivity.a()) {
                    Log.i("PrmSDK", "Another ad is showing on screen.");
                    sendAdError("Another ad is showing on screen.");
                    return;
                }
                if (cA == null) {
                    cA = new b(activity);
                }
                if (cA.e(AdListener.AdType.appwall)) {
                    Log.i("PrmSDK", "AppWall Ad already available in cache. Request ignored.");
                    sendAdError("AppWall Ad already available in cache. Request Ignored.");
                    return;
                }
                n.b(activity);
                a<String> aVar = new a<String>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.Prm.2
                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a(String str) {
                        Log.i("PrmSDK", "AppWall Json: " + str);
                        if (str != null) {
                            try {
                                if (Prm.enableCaching) {
                                    JSONObject jSONObject = new JSONObject(str);
                                    int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                    String string = jSONObject.isNull("message") ? e.INVALID : jSONObject.getString("message");
                                    if (i == 200 && string.equalsIgnoreCase("Success")) {
                                        Prm.cA.a(AdListener.AdType.appwall, str);
                                        m.sendAdCached(AdListener.AdType.appwall);
                                        return;
                                    } else {
                                        Prm.validateStatusCode(i, string);
                                        return;
                                    }
                                }
                                Prm.this.parseAppWallJson(str);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a() {
                        try {
                            new Thread(new j(Prm.activity, this, new ArrayList(), e.URL_APP_WALL, 0L, true), "AppWall").start();
                        } catch (NullPointerException e) {
                            e.printStackTrace();
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                };
                if (Util.p(activity)) {
                    aVar.a();
                }
            }
        } catch (Exception e) {
            Log.e("PrmSDK", "Error occurred in appwall ", e);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.m
    void parseAppWallJson(String json) {
        try {
            JSONObject jSONObject = new JSONObject(json);
            int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
            String string = jSONObject.isNull("message") ? "" : jSONObject.getString("message");
            if (i == 200 && string.equals("Success")) {
                String string2 = jSONObject.getString(PlusShare.KEY_CALL_TO_ACTION_URL);
                if (string2 != null && !string2.equals("")) {
                    n.b(activity);
                    Intent intent = new Intent(activity, (Class<?>) MainActivity.class);
                    intent.setFlags(DriveFile.MODE_READ_ONLY);
                    intent.addFlags(DriveFile.MODE_WRITE_ONLY);
                    intent.addFlags(8388608);
                    intent.setAction("appwallad");
                    intent.putExtra("adtype", e.AD_TYPE_AW);
                    intent.putExtra(PlusShare.KEY_CALL_TO_ACTION_URL, string2);
                    try {
                        activity.startActivity(intent);
                        return;
                    } catch (ActivityNotFoundException e) {
                        Log.e("PrmSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                        return;
                    }
                }
                return;
            }
            validateStatusCode(i, string);
        } catch (JSONException e2) {
            Log.e("PrmSDK", "Error in AppWall json: ", e2);
        } catch (Exception e3) {
            Log.e("PrmSDK", "Error in AppWall response: ", e3);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.d
    public void runRichMediaInterstitialAd() {
        try {
            Log.i("PrmSDK", "Initialising Rich Media Interstitial Ad.....");
            if (!isIntegrationIssue && checkSmartWallintegration()) {
                if (activity == null || !isSDKEnabled(activity)) {
                    Log.i("PrmSDK", "Prm is disabled Please enable to recive ads.");
                    sendAdError("Prm is disabled Please enable to recive ads.");
                    return;
                }
                if (n.c(activity) > System.currentTimeMillis()) {
                    Log.i("PrmSDK", "Rich Media Interstitial Ad called within 10 secs. Ignoring request");
                    sendAdError("Rich Media Interstitial Ad called within 10 secs. Ignoring request");
                    return;
                }
                if (MainActivity.a()) {
                    Log.i("PrmSDK", "Another ad is showing on screen.");
                    sendAdError("Another ad is showing on screen.");
                    return;
                }
                if (cA == null) {
                    cA = new b(activity);
                }
                if (cA.e(AdListener.AdType.interstitial)) {
                    Log.i("PrmSDK", "Rich media interstitial Ad already available in cache. Request ignored.");
                    sendAdError("Rich media interstitial Ad already available in cache. Request Ignored.");
                    return;
                }
                n.b(activity);
                a<String> aVar = new a<String>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.Prm.3
                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a(String str) {
                        Log.i("PrmSDK", "Rich Media Ad Json: " + str);
                        if (str != null) {
                            try {
                                JSONObject jSONObject = new JSONObject(str);
                                int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                String string = jSONObject.isNull("message") ? e.INVALID : jSONObject.getString("message");
                                String string2 = jSONObject.isNull("adtype") ? null : jSONObject.getString("adtype");
                                if (i == 200 && string.equalsIgnoreCase("Success")) {
                                    if (string2 == null || !string2.equals(e.AD_TYPE_MFP)) {
                                        Log.w("PrmSDK", "Invalid adtype: " + string2);
                                        return;
                                    } else if (Prm.enableCaching) {
                                        Prm.cA.a(AdListener.AdType.interstitial, str);
                                        m.sendAdCached(AdListener.AdType.interstitial);
                                        return;
                                    } else {
                                        Prm.this.parseRichMediaInterstitialJson(jSONObject);
                                        return;
                                    }
                                }
                                Prm.validateStatusCode(i, string);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a() {
                        try {
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(new BasicNameValuePair("banner_type", "rich_media"));
                            arrayList.add(new BasicNameValuePair("supports", "" + Util.t(Prm.activity)));
                            arrayList.add(new BasicNameValuePair("placement_type", "fullpage"));
                            new Thread(new j(Prm.activity, this, arrayList, e.URL_MRAID_API, 0L, true), "AdView").start();
                        } catch (Exception e) {
                        }
                    }
                };
                if (Util.p(activity)) {
                    aVar.a();
                }
            }
        } catch (Exception e) {
            Log.e("PrmSDK", "Error occurred in Rich Media interstital ad: ", e);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.m
    void parseRichMediaInterstitialJson(JSONObject jsonObject) {
        try {
            parseMraidJson = new JP.ParseMraidJson(activity, jsonObject);
            String s = Util.s(activity);
            if (s != null && !s.equals("")) {
                n.b(activity);
                Intent intent = new Intent(activity, (Class<?>) MainActivity.class);
                intent.setAction("mfpad");
                intent.setFlags(DriveFile.MODE_READ_ONLY);
                intent.addFlags(8388608);
                intent.addFlags(DriveFile.MODE_WRITE_ONLY);
                intent.putExtra("adtype", e.AD_TYPE_MFP);
                activity.startActivity(intent);
            } else {
                a<Boolean> aVar = new a<Boolean>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.Prm.4
                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a(Boolean bool) {
                        if (bool.booleanValue()) {
                            n.b(Prm.activity);
                            Intent intent2 = new Intent(Prm.activity, (Class<?>) MainActivity.class);
                            intent2.setAction("mfpad");
                            intent2.setFlags(DriveFile.MODE_READ_ONLY);
                            intent2.addFlags(8388608);
                            intent2.addFlags(DriveFile.MODE_WRITE_ONLY);
                            intent2.putExtra("adtype", e.AD_TYPE_MFP);
                            Prm.activity.startActivity(intent2);
                            return;
                        }
                        Log.e("PrmSDK", "Not able to get doc.");
                    }

                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a() {
                        new Thread(new Util.NativeMraid(Prm.activity, this), "native").start();
                    }
                };
                if (Util.p(activity)) {
                    aVar.a();
                }
            }
        } catch (IOException e) {
            Log.i("PrmSDK", "Rich Media Full Page: " + e.getMessage());
        } catch (JSONException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static final void validateStatusCode(int status, String message) {
        if (message != null && !message.equals("")) {
            switch (status) {
                case 100:
                    sendIntegrationError(message);
                    return;
                case 120:
                    sendIntegrationError(message);
                    return;
                case 130:
                    sendIntegrationError(message);
                    return;
                case 150:
                    sendNoAdMessage();
                    return;
                case 204:
                    sendNoAdMessage();
                    return;
                default:
                    return;
            }
        }
    }

    static boolean checkRequiredDetails(Context mContext) {
        boolean z = true;
        if (mContext == null) {
            try {
                Log.e("PrmSDK", "Context is null.");
                sendIntegrationError("Context is null");
                z = false;
            } catch (Exception e) {
                Log.e("PrmSDK", "Error occurred while checking required details: ", e);
                return false;
            }
        }
        if (!getDataFromManifest(mContext)) {
            z = false;
        }
        if (!checkRequiredPermission(mContext)) {
            z = false;
        }
        if (!new o(mContext).b()) {
            z = false;
        }
        new n(mContext).a();
        return z;
    }

    private boolean checkSmartWallintegration() {
        try {
            boolean checkSmartWallActivity = checkSmartWallActivity();
            if (Util.a(activity, (Class<?>) BrowserActivity.class)) {
                return checkSmartWallActivity;
            }
            Log.e("PrmSDK", "Required BrowserActivity not found in Manifest. Please add.");
            sendIntegrationError("Required BrowserActivity not found in Manifest. Please add.");
            new l(activity, LocationRequest.PRIORITY_LOW_POWER);
            return false;
        } catch (Exception e) {
            Log.e("PrmSDK", "Error occurred while validating SmartWall: ", e);
            return false;
        }
    }

    private boolean checkSmartWallActivity() throws NullPointerException, Exception {
        if (Util.a(activity, (Class<?>) MainActivity.class)) {
            return true;
        }
        Log.e("PrmSDK", "Required MainActivity not found in Manifest. Please add.");
        sendIntegrationError("Required MainActivity not found in Manifest. Please add.");
        new l(activity, 103);
        return false;
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.d
    public void runVideoAd() {
        try {
            if (Build.VERSION.SDK_INT < 8) {
                Log.e("PrmSDK", "Video ad supported on Android 2.2 and later devices.");
                sendAdError("Video ad supported on Android 2.2 and later devices.");
                return;
            }
            Log.i("PrmSDK", "Initialising video ad.....");
            if (!isIntegrationIssue && p.a((Context) activity)) {
                if (!Util.a(activity, (Class<?>) VDActivity.class)) {
                    Log.e("PrmSDK", "Required VDActivity not found in Manifest. Please add");
                    sendIntegrationError("Required VDActivity not found in Manifest. Please add");
                    new l(activity, LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
                    return;
                }
                if (isSDKEnabled(activity)) {
                    String externalStorageState = Environment.getExternalStorageState();
                    if (externalStorageState != null && externalStorageState.equalsIgnoreCase("mounted")) {
                        if (MainActivity.a()) {
                            Log.w("PrmSDK", "Another ad is already showing on screen.");
                            sendAdError("Another ad is already showing on screen.");
                            return;
                        }
                        if (System.currentTimeMillis() < n.e(activity)) {
                            Log.w("PrmSDK", "Video ad is called before 30 secs. Ignoring request.");
                            sendAdError("Video ad is called before 30 secs. Ignoring request.");
                            return;
                        }
                        if (cA == null) {
                            cA = new b(activity);
                        }
                        if (cA.e(AdListener.AdType.video)) {
                            Log.i("PrmSDK", "Video Ad already available in cache. Request ignored.");
                            sendAdError("Video Ad already available in cache. Request Ignored.");
                            return;
                        } else {
                            p pVar = new p(activity);
                            if (Util.p(activity)) {
                                pVar.a();
                                return;
                            }
                            return;
                        }
                    }
                    Log.w("PrmSDK", "Can't call video ad at this time. SD card not mounted.");
                    sendAdError("Can't call video ad at this time. SD card not mounted.");
                    return;
                }
                Log.e("PrmSDK", "Prm is disabled please enable to receive ads.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.d
    public void runOverlayAd() {
        try {
            Log.i("PrmSDK", "Initialising Overlay AD.....");
            if (!isIntegrationIssue && checkSmartWallActivity()) {
                if (!isSDKEnabled(activity)) {
                    Log.i("PrmSDK", "Prm SDK is disabled Please enable to recive ads.");
                    sendAdError("Prm SDK is disabled Please enable to recive ads.");
                    return;
                }
                if (n.c(activity) > System.currentTimeMillis()) {
                    Log.i("PrmSDK", "Overlay Ad called within 10 secs. Ignoring request");
                    sendAdError("Overlay Ad called within 10 secs. Ignoring request");
                    return;
                }
                if (MainActivity.a()) {
                    Log.i("PrmSDK", "Another ad is showing on screen.");
                    sendAdError("Another ad is showing on screen.");
                    return;
                }
                if (cA == null) {
                    cA = new b(activity);
                }
                if (cA.e(AdListener.AdType.overlay)) {
                    Log.i("PrmSDK", "Overlay Ad already available in cache. Request ignored.");
                    sendAdError("Overlay Ad already available in cache. Request Ignored.");
                    return;
                }
                n.b(activity);
                a<String> aVar = new a<String>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.Prm.5
                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a(String str) {
                        Log.i("PrmSDK", "Overlay Json: " + str);
                        if (str != null) {
                            try {
                                if (!Prm.enableCaching) {
                                    Prm.this.showOverlayAd(str);
                                    return;
                                }
                                JSONObject jSONObject = new JSONObject(str);
                                int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                String string = jSONObject.isNull("message") ? e.INVALID : jSONObject.getString("message");
                                if (i == 200 && string.equalsIgnoreCase("Success")) {
                                    Prm.cA.a(AdListener.AdType.overlay, str);
                                    m.sendAdCached(AdListener.AdType.overlay);
                                } else {
                                    Prm.validateStatusCode(i, string);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a() {
                        try {
                            new Thread(new j(Prm.activity, this, new ArrayList(), e.OVERLAY_AD_URL, 0L, true), "overlay").start();
                        } catch (Exception e) {
                            Log.e("PrmSDK", "Error occurred in while requesting: ", e);
                        }
                    }
                };
                if (Util.p(activity)) {
                    aVar.a();
                }
            }
        } catch (Exception e) {
            Log.e("PrmSDK", "Error occurred in Overlay ad: ", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showOverlayAd(String result) {
        try {
            JSONObject jSONObject = new JSONObject(result);
            int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
            String string = jSONObject.isNull("message") ? e.INVALID : jSONObject.getString("message");
            final String string2 = jSONObject.isNull("adtype") ? "" : jSONObject.getString("adtype");
            boolean z = jSONObject.isNull(IM.EVENT_ERROR) ? false : jSONObject.getBoolean(IM.EVENT_ERROR);
            if (i == 200 && string.equalsIgnoreCase("Success")) {
                String string3 = jSONObject.isNull("data") ? "nodata" : jSONObject.getString("data");
                if (!string3.equals("nodata")) {
                    JSONObject jSONObject2 = new JSONObject(string3);
                    String string4 = jSONObject2.getString("tag");
                    int i2 = jSONObject2.getInt("height");
                    int i3 = jSONObject2.getInt("width");
                    String string5 = jSONObject2.getString("api_url");
                    k.d(string2);
                    k.c(string5);
                    k.a(z);
                    k.b(i3);
                    k.a(i2);
                    k.b(string4);
                    if (string2.equals("OLAU") || string2.equals(e.AD_TYPE_DAU) || string2.equals(e.AD_TYPE_DCC) || string2.equals(e.AD_TYPE_DCM)) {
                        new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.Prm.6
                            @Override // java.lang.Runnable
                            public void run() {
                                Intent intent = new Intent(Prm.activity, (Class<?>) MainActivity.class);
                                intent.setFlags(DriveFile.MODE_READ_ONLY);
                                intent.addFlags(8388608);
                                intent.setAction("overlayad");
                                intent.putExtra("adtype", string2);
                                Prm.activity.startActivity(intent);
                            }
                        }, "overlay_showing").start();
                        return;
                    } else {
                        Log.w("PrmSDK", "Invalid adtype delivered in overylay ad " + string2);
                        return;
                    }
                }
                return;
            }
            validateStatusCode(i, string);
        } catch (Exception e) {
            Log.e("PrmSDK", "Error occurred in overlay ad", e);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.d
    public void runCachedAd(Activity activity2, AdListener.AdType adType) throws Exception {
        try {
            if (activity2 == null || adType == null) {
                Log.e("PrmSDK", "Activity or Adtype is null.");
                throw new IllegalStateException("Activity or Adtype is null.");
            }
            activity = activity2;
            if (!isSDKEnabled(activity2)) {
                throw new IllegalStateException("Standard SDK is disabled can not show ad.");
            }
            if (MainActivity.a()) {
                throw new IllegalStateException("Another ad is showing on screen.");
            }
            if (!Util.p(activity2)) {
                throw new IllegalStateException("Internet connection not available.");
            }
            if (cA == null) {
                cA = new b(activity2);
            }
            switch (adType) {
                case smartwall:
                    String a = cA.a(AdListener.AdType.smartwall);
                    if (a != null && !a.equals("")) {
                        if (a.contains("<VAST") && Build.VERSION.SDK_INT > 7) {
                            String[] b = cA.b(AdListener.AdType.video);
                            String str = b[0];
                            String str2 = b[1];
                            if (str != null && !str.equals("") && str2 != null && !str2.equals("")) {
                                new p(activity2).a(str, str2);
                                return;
                            } else {
                                cA.c(adType);
                                Log.e("PrmSDK", "SmartWall video was not cached");
                                throw new IOException("SmartWall ad is not available in cache");
                            }
                        }
                        parseSmartwallJson(a);
                        return;
                    }
                    throw new IOException("SmartWall ad is not available in cache");
                case appwall:
                    String a2 = cA.a(AdListener.AdType.appwall);
                    if (a2 != null && !a2.equals("")) {
                        parseAppWallJson(a2);
                        return;
                    } else {
                        cA.c(adType);
                        throw new IOException("Appwall ad is not available in cache");
                    }
                case interstitial:
                    String a3 = cA.a(AdListener.AdType.interstitial);
                    if (a3 != null && !a3.equals("")) {
                        parseRichMediaInterstitialJson(new JSONObject(a3));
                        return;
                    } else {
                        cA.c(adType);
                        throw new IOException("Interstitial ad is not available in cache");
                    }
                case video:
                    String[] b2 = cA.b(AdListener.AdType.video);
                    String str3 = b2[0];
                    String str4 = b2[1];
                    if (str3 != null && !str3.equals("") && str4 != null && !str4.equals("")) {
                        new p(activity2).a(str3, str4);
                        return;
                    } else {
                        cA.c(adType);
                        throw new IOException("Video ad is not available in cache");
                    }
                case overlay:
                    String a4 = cA.a(AdListener.AdType.overlay);
                    if (a4 != null && !a4.equals("")) {
                        showOverlayAd(a4);
                        return;
                    } else {
                        cA.c(adType);
                        throw new IOException("Overlay ad is not available in cache");
                    }
                default:
                    throw new IOException("Invalid AdType.");
            }
        } catch (Exception e) {
            Log.e("PrmSDK", "Error occurred while showing Cached ad: " + e.getMessage());
            throw new Exception(e.getMessage());
        }
    }
}
