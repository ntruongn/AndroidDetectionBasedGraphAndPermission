package com.cguvuuqvlp.zaliiliwdx185920;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import com.cguvuuqvlp.zaliiliwdx185920.AdListener;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.plus.PlusShare;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class MainActivity extends Activity {
    static final String INTENT_ACTION_APPWALL_AD = "appwallad";
    static final String INTENT_ACTION_LANDING_PAGE_AD = "lpad";
    static final String INTENT_ACTION_OVERLAY_AD = "overlayad";
    static final String INTENT_ACTION_RICH_MEDIA_FULL_PAGE_AD = "mfpad";
    private static WebView d;
    Dialog a;
    Handler b = new Handler() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MainActivity.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case -4:
                    try {
                        if (MainActivity.this.a != null) {
                            MainActivity.this.a.dismiss();
                        }
                        MainActivity.this.finish();
                        if (Prm.adListener != null) {
                            Prm.adListener.onAdError("Error occurred while loading ad.");
                            return;
                        }
                        return;
                    } catch (Exception e) {
                        return;
                    }
                case -3:
                    try {
                        if (MainActivity.this.a != null) {
                            MainActivity.this.a.dismiss();
                        }
                        MainActivity.this.finish();
                        return;
                    } catch (Exception e2) {
                        MainActivity.this.finish();
                        return;
                    }
                case -2:
                case -1:
                default:
                    return;
                case 0:
                    try {
                        MainActivity.this.a.show();
                        MainActivity.this.a.getWindow().setFlags(1024, 1024);
                        if (Prm.adListener != null) {
                            Prm.adListener.onSmartWallAdShowing();
                            return;
                        }
                        return;
                    } catch (Exception e3) {
                        MainActivity.this.finish();
                        return;
                    }
            }
        }
    };
    private String e;
    private Intent f;
    private MV g;
    private AppWall h;
    private ProgressDialog j;
    private k k;
    private AdListener.AdType l;
    private static String c = e.TAG;
    private static boolean i = false;

    @Override // android.app.Activity
    @SuppressLint({"InlinedApi"})
    protected void onCreate(Bundle savedInstanceState) {
        String action;
        super.onCreate(savedInstanceState);
        try {
            requestWindowFeature(1);
            i = true;
            this.f = getIntent();
            action = this.f.getAction();
            this.e = this.f.getStringExtra("adtype");
        } catch (Exception e) {
        }
        if (action.equals(INTENT_ACTION_RICH_MEDIA_FULL_PAGE_AD) && this.e.equalsIgnoreCase(e.AD_TYPE_MFP)) {
            this.l = AdListener.AdType.interstitial;
            this.a = new Dialog(this, 16973841);
            this.a.requestWindowFeature(1);
            this.a.getWindow().setLayout(-1, -1);
            this.g = new MV(this, Prm.parseMraidJson, this.b);
            this.a.setContentView(this.g);
            this.a.setCanceledOnTouchOutside(false);
            this.a.setCancelable(false);
            this.a.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MainActivity.2
                @Override // android.content.DialogInterface.OnCancelListener
                public void onCancel(DialogInterface dialog) {
                    dialog.dismiss();
                    MainActivity.this.finish();
                }
            });
            return;
        }
        if (action.equals(INTENT_ACTION_APPWALL_AD) && this.e.equalsIgnoreCase(e.AD_TYPE_AW)) {
            this.l = AdListener.AdType.appwall;
            String stringExtra = this.f.getStringExtra(PlusShare.KEY_CALL_TO_ACTION_URL);
            if (stringExtra != null && !stringExtra.equals("") && Util.p(this)) {
                try {
                    if (Build.VERSION.SDK_INT >= 11) {
                        getWindow().setFlags(16777216, 16777216);
                    }
                } catch (Throwable th) {
                }
                this.j = ProgressDialog.show(this, null, "Loading....");
                this.h = new AppWall(this, stringExtra);
                if (Prm.adListener != null) {
                    Prm.adListener.onSmartWallAdShowing();
                    return;
                }
                return;
            }
        } else if (this.e.equals("OLAU") || this.e.equals(e.AD_TYPE_DAU) || this.e.equals(e.AD_TYPE_DCC) || this.e.equals(e.AD_TYPE_DCM)) {
            this.l = AdListener.AdType.overlay;
            if (this.k == null) {
                this.k = new k(this);
                return;
            }
            return;
        }
        finish();
    }

    @Override // android.app.Activity
    protected void onUserLeaveHint() {
        try {
            if (this.e != null && (this.e.equals("OLAU") || this.e.equals(e.AD_TYPE_DAU) || this.e.equals(e.AD_TYPE_DCC) || this.e.equals(e.AD_TYPE_DCM))) {
                if (this.k != null) {
                    this.k.dismiss();
                }
                finish();
            }
        } catch (Exception e) {
            finish();
        }
        super.onUserLeaveHint();
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    private class AppWall extends Dialog implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
        public AppWall(Context context, String url) {
            super(context);
            requestWindowFeature(1);
            getWindow().setBackgroundDrawable(new ColorDrawable(0));
            setCancelable(true);
            setCanceledOnTouchOutside(false);
            setOnCancelListener(this);
            setOnDismissListener(this);
            int i = (int) (MainActivity.this.getResources().getDisplayMetrics().density * 7.0f);
            RelativeLayout relativeLayout = new RelativeLayout(context);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -2);
            layoutParams.setMargins(i, i, i, i);
            layoutParams.addRule(15, -1);
            layoutParams.addRule(14, -1);
            relativeLayout.setLayoutParams(layoutParams);
            WebView unused = MainActivity.d = new WebView(context);
            MainActivity.d.getSettings().setCacheMode(-1);
            MainActivity.d.getSettings().setJavaScriptEnabled(true);
            MainActivity.d.addJavascriptInterface(new JavaScriptInterface(), "Appwall");
            MainActivity.d.setWebChromeClient(new WebChromeClient());
            MainActivity.d.setWebViewClient(new WebViewClient() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MainActivity.AppWall.1
                @Override // android.webkit.WebViewClient
                public void onPageFinished(WebView view, String url2) {
                    super.onPageFinished(view, url2);
                    try {
                        if (MainActivity.this.j != null) {
                            MainActivity.this.j.dismiss();
                        }
                        if (MainActivity.this.h != null && !MainActivity.this.h.isShowing()) {
                            AppWall.this.show();
                        }
                    } catch (Exception e) {
                        MainActivity.this.finish();
                    }
                }

                @Override // android.webkit.WebViewClient
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    try {
                        if (MainActivity.this.j != null) {
                            MainActivity.this.j.dismiss();
                        }
                        if (MainActivity.this.h != null) {
                            MainActivity.this.h.dismiss();
                        }
                        String str = "Error occurred while loading AppWall: code " + errorCode + ", desc: " + description;
                        Log.e(MainActivity.c, str);
                        if (Prm.adListener != null) {
                            Prm.adListener.onAdError(str);
                        }
                    } catch (Throwable th) {
                        Log.e(MainActivity.c, "Error occurred while loading AppWall: code " + errorCode + ", desc: " + description);
                    }
                    MainActivity.this.finish();
                }

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView view, String url2) {
                    try {
                        Util.a("SmartWall Url: " + url2);
                        AppWall.this.a();
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url2));
                        intent.addFlags(DriveFile.MODE_READ_ONLY);
                        intent.addFlags(8388608);
                        MainActivity.this.startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return false;
                    }
                }
            });
            MainActivity.d.setVerticalScrollBarEnabled(false);
            MainActivity.d.setHorizontalScrollBarEnabled(false);
            MainActivity.d.setScrollBarStyle(33554432);
            MainActivity.d.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
            MainActivity.d.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
            relativeLayout.addView(MainActivity.d);
            setContentView(relativeLayout);
            MainActivity.d.loadUrl(url);
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialog) {
            a();
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialog) {
            a();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void a() {
            try {
                if (MainActivity.this.h != null) {
                    MainActivity.this.h.dismiss();
                }
                MainActivity.this.h = null;
            } catch (Exception e) {
            }
            MainActivity.this.finish();
        }

        /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
        public class JavaScriptInterface {
            public JavaScriptInterface() {
            }

            @JavascriptInterface
            public void closewin() {
                AppWall.this.a();
            }

            @JavascriptInterface
            public void triggerEvent(String event) {
            }
        }
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        try {
            if (this.j != null) {
                this.j.dismiss();
            }
        } catch (Exception e) {
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        try {
            if (this.e == null || (!this.e.equals("OLAU") && !this.e.equals(e.AD_TYPE_DAU) && !this.e.equals(e.AD_TYPE_DCC) && !this.e.equals(e.AD_TYPE_DCM))) {
                if (this.e != null && this.e.equals(e.AD_TYPE_AW)) {
                    if (this.j != null) {
                        this.j.dismiss();
                    }
                    if (this.h != null) {
                        this.h.dismiss();
                    }
                    finish();
                    return;
                }
                if (this.e != null && this.e.equals(e.AD_TYPE_MFP)) {
                    if (this.a != null) {
                        this.a.dismiss();
                    }
                    finish();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        try {
            i = false;
            if (Prm.adListener != null && this.e != null) {
                Prm.adListener.onSmartWallAdClosed();
            }
            b bVar = new b(this);
            if (bVar.a()) {
                bVar.c(AdListener.AdType.smartwall);
                bVar.a(false);
            } else {
                bVar.c(this.l);
            }
            if (d != null) {
                d.stopLoading();
                d.removeAllViews();
                d.destroy();
            }
        } catch (Exception e) {
        } catch (Throwable th) {
        }
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a() {
        return i;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(boolean z) {
        i = z;
    }
}
