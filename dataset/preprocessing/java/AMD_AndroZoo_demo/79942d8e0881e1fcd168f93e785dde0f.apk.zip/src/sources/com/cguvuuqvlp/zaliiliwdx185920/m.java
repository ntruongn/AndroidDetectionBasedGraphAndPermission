package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import com.cguvuuqvlp.zaliiliwdx185920.AdListener;
import java.util.StringTokenizer;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
abstract class m implements d {
    private static final String TAG = "PrmSDK";
    private static boolean isSent = false;

    abstract void parseAppWallJson(String str);

    abstract void parseRichMediaInterstitialJson(JSONObject jSONObject);

    public static boolean isSDKEnabled(Context context) {
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences(e.SDK_PREFERENCE, 0);
            if (sharedPreferences == null || sharedPreferences.equals(null) || !sharedPreferences.contains(e.SDK_ENABLED)) {
                return false;
            }
            return sharedPreferences.getBoolean(e.SDK_ENABLED, false);
        } catch (Exception e) {
            Log.i("PrmSDK", "" + e.getMessage());
            return false;
        }
    }

    public static void enableSDK(Context context, boolean enable) {
        try {
            SharedPreferences.Editor edit = context.getSharedPreferences(e.SDK_PREFERENCE, 0).edit();
            edit.putBoolean(e.SDK_ENABLED, enable);
            edit.commit();
            Log.i("PrmSDK", "SDK enabled: " + enable);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean getDataFromManifest(Context mContext) {
        String str;
        try {
            try {
                Bundle bundle = mContext.getPackageManager().getApplicationInfo(mContext.getPackageName(), 128).metaData;
                String obj = bundle.get(e.APPID_MANIFEST).toString();
                if (obj != null && !obj.equals("") && !obj.equals("0")) {
                    Util.e(obj);
                }
                String str2 = "";
                try {
                    str = bundle.get(e.APIKEY_MANIFEST).toString();
                } catch (Exception e) {
                    e = e;
                }
                if (str != null) {
                    try {
                    } catch (Exception e2) {
                        str2 = str;
                        e = e2;
                        Log.e("PrmSDK", "Problem with fetching apiKey. Please chcek your APIKEY declaration in Manifest. It should be same as given in SDK doc.", e);
                        new l(mContext, 101);
                        Util.d("airplay");
                        sendIntegrationError("Please check your APIKEY declaration in Manifest. It must be same as given in doc.");
                        str = str2;
                        Util.a("AppId: " + obj + " ApiKey=" + str);
                        return true;
                    }
                    if (!str.equals("") && !str.equals("0")) {
                        StringTokenizer stringTokenizer = new StringTokenizer(str, "*");
                        stringTokenizer.nextToken();
                        str = stringTokenizer.nextToken();
                        Util.d(str);
                        Util.a("AppId: " + obj + " ApiKey=" + str);
                        return true;
                    }
                }
                Util.d("airplay");
                Util.a("AppId: " + obj + " ApiKey=" + str);
                return true;
            } catch (PackageManager.NameNotFoundException e3) {
                Log.e("PrmSDK", "AppId or ApiKey not found in Manifest. Please add.", e3);
                sendIntegrationError("AppId or ApiKey not found in Manifest. Please add.");
                return false;
            }
        } catch (Exception e4) {
            Log.e("PrmSDK", "Please check your SDK declarations in Manifest. This errors comes when SDK unable to fetch APPID or APIKEY from Manifest. SDK Package Name: ", e4);
            sendIntegrationError("Please check your SDK declarations in Manifest. This error comes when SDK unable to fetch APPID or APIKEY from Manifest.");
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean checkRequiredPermission(Context mContext) {
        boolean z;
        boolean z2 = false;
        boolean z3 = mContext.checkCallingOrSelfPermission("android.permission.INTERNET") == 0;
        boolean z4 = mContext.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") == 0;
        boolean z5 = mContext.checkCallingOrSelfPermission("android.permission.READ_PHONE_STATE") == 0;
        if (z3) {
            z = true;
        } else {
            Log.e("PrmSDK", "Required INTERNET permission not found in manifest.");
            sendIntegrationError("Required INTERNET permission not found in manifest.");
            z = false;
        }
        if (!z4) {
            Log.e("PrmSDK", "Required ACCESS_NETWORK_STATE permission not found in manifest.");
            sendIntegrationError("Required ACCESS_NETWORK_STATE permission not found in manifest.");
            z = false;
        }
        if (z5) {
            z2 = z;
        } else {
            Log.e("PrmSDK", "Required READ_PHONE_STATE permission not found in manifest.");
            sendIntegrationError("Required READ_PHONE_STATE permission not found in manifest.");
        }
        if (!z2 && !isSent) {
            new l(mContext, 100);
            isSent = true;
        }
        return z2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void sendIntegrationError(final String message) {
        try {
            if (Prm.adListener != null) {
                Prm.handler.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.m.1
                    @Override // java.lang.Runnable
                    public void run() {
                        Prm.adListener.onSDKIntegrationError(message);
                    }
                });
            }
        } catch (Exception e) {
            try {
                Prm.adListener.onSDKIntegrationError(message);
            } catch (Exception e2) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void sendAdError(final String message) {
        try {
            if (Prm.adListener != null) {
                Prm.handler.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.m.2
                    @Override // java.lang.Runnable
                    public void run() {
                        Prm.adListener.onAdError(message);
                    }
                });
            }
        } catch (Exception e) {
            try {
                Prm.adListener.onAdError(message);
            } catch (Exception e2) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void sendNoAdMessage() {
        try {
            if (Prm.adListener != null) {
                Prm.handler.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.m.3
                    @Override // java.lang.Runnable
                    public void run() {
                        Prm.adListener.noAdAvailableListener();
                    }
                });
            }
        } catch (Exception e) {
            try {
                Prm.adListener.noAdAvailableListener();
            } catch (Exception e2) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void sendAdCached(final AdListener.AdType adType) {
        try {
            if (Prm.adListener != null) {
                Prm.handler.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.m.4
                    @Override // java.lang.Runnable
                    public void run() {
                        Prm.adListener.onAdCached(AdListener.AdType.this);
                        Log.i("PrmSDK", "Ad cached: " + AdListener.AdType.this);
                    }
                });
            }
        } catch (Exception e) {
            try {
                Prm.adListener.onAdCached(adType);
            } catch (Exception e2) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean validate(Context context) {
        try {
            String obj = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData.get("com.google.android.gms.version").toString();
            if (obj != null && !obj.equals("")) {
                if (!obj.equals("0")) {
                    return true;
                }
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("PrmSDK", "com.google.android.gms.version is not added in Manifest, Please add", e);
            sendIntegrationError("com.google.android.gms.version is not added in Manifest, Please add.");
        } catch (Exception e2) {
            Log.e("PrmSDK", "com.google.android.gms.version is not added in Manifest, Please add", e2);
            sendIntegrationError("com.google.android.gms.version is not added in Manifest, Please add");
        }
        return false;
    }
}
