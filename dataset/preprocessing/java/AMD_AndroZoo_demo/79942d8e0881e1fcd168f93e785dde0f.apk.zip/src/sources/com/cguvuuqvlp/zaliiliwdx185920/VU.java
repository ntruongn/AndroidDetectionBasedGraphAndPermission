package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Environment;
import android.util.Log;
import java.io.File;
import java.util.StringTokenizer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
abstract class VU {
    VU() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long a(String str) throws NullPointerException, NumberFormatException, Exception {
        if (str == null || str.equals("")) {
            throw new NullPointerException("Time value is null.");
        }
        StringTokenizer stringTokenizer = new StringTokenizer(str, ":");
        String nextToken = stringTokenizer.nextToken();
        String nextToken2 = stringTokenizer.nextToken();
        String nextToken3 = stringTokenizer.nextToken();
        System.out.println(nextToken + "mm " + nextToken2 + "ss" + nextToken3);
        String str2 = "0";
        if (nextToken3.contains(".")) {
            StringTokenizer stringTokenizer2 = new StringTokenizer(nextToken3, ".");
            nextToken3 = stringTokenizer2.nextToken();
            str2 = stringTokenizer2.nextToken();
        }
        long longValue = Long.valueOf(nextToken).longValue() * 3600 * 1000;
        return Long.valueOf(str2).longValue() + (Long.valueOf(nextToken2).longValue() * 60 * 1000) + longValue + (Long.valueOf(nextToken3).longValue() * 1000);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String a(long j) {
        String num = Integer.toString((int) (j % 60));
        String num2 = Integer.toString((int) ((j % 3600) / 60));
        String num3 = Integer.toString((int) (j / 3600));
        String str = num;
        for (int i = 0; i < 2; i++) {
            if (str.length() < 2) {
                str = "0" + str;
            }
            if (num2.length() < 2) {
                num2 = "0" + num2;
            }
            if (num3.length() < 2) {
                num3 = "0" + num3;
            }
        }
        if (!num3.equals("00")) {
            return num3 + ":" + num2 + ":" + str;
        }
        if (num3.equals("00") && !num2.equals("00")) {
            return num2 + ":" + str;
        }
        return str + "s";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(File file) {
        if (file.isDirectory()) {
            for (File file2 : file.listFiles()) {
                a(file2);
            }
        }
        file.delete();
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public static class NetworkUtil {
        private Context a;
        private BroadcastReceiver b;
        private boolean c = false;

        public NetworkUtil(Context context) {
            this.a = context;
        }

        public boolean isNetworkAvailable() {
            return this.c;
        }

        void a() {
            try {
                this.c = ((ConnectivityManager) this.a.getSystemService("connectivity")).getActiveNetworkInfo().isConnected();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        void b() {
            this.b = new BroadcastReceiver() { // from class: com.cguvuuqvlp.zaliiliwdx185920.VU.NetworkUtil.1
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    Log.i("test", "Storage: " + intent.getData());
                    NetworkUtil.this.a();
                }
            };
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
            intentFilter.addAction("android.net.wifi.STATE_CHANGE");
            this.a.registerReceiver(this.b, intentFilter);
            a();
        }

        void c() {
            this.a.unregisterReceiver(this.b);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public static class FileUtil {
        Context a;
        private BroadcastReceiver b;
        private boolean c = false;
        private boolean d = false;

        public FileUtil(Context context) {
            this.a = context;
            b();
        }

        public boolean ismExternalStorageAvailable() {
            return this.c;
        }

        public boolean ismExternalStorageWriteable() {
            return this.d;
        }

        void a() {
            String externalStorageState = Environment.getExternalStorageState();
            if ("mounted".equals(externalStorageState)) {
                this.d = true;
                this.c = true;
            } else if ("mounted_ro".equals(externalStorageState)) {
                this.c = true;
                this.d = false;
            } else {
                this.d = false;
                this.c = false;
            }
        }

        void b() {
            this.b = new BroadcastReceiver() { // from class: com.cguvuuqvlp.zaliiliwdx185920.VU.FileUtil.1
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    Log.i("test", "Storage: " + intent.getData());
                    FileUtil.this.a();
                }
            };
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.MEDIA_MOUNTED");
            intentFilter.addAction("android.intent.action.MEDIA_REMOVED");
            this.a.registerReceiver(this.b, intentFilter);
            a();
        }

        void c() {
            this.a.unregisterReceiver(this.b);
        }
    }
}
