package com.google.android.gms.ads.mediation.admob;

import android.os.Bundle;
import com.google.ads.mediation.NetworkExtras;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class AdMobExtras implements NetworkExtras {
    private final Bundle jh;

    public AdMobExtras(Bundle extras) {
        this.jh = extras != null ? new Bundle(extras) : null;
    }

    public Bundle getExtras() {
        return this.jh;
    }
}
