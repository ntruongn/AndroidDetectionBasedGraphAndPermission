package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.Context;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.util.List;
import java.util.zip.GZIPInputStream;
import javax.net.ssl.SSLPeerUnverifiedException;
import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponse;
import org.apache.http.HttpResponseInterceptor;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.HttpEntityWrapper;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
final class j implements Runnable {
    private static final String ENCODING_GZIP = "gzip";
    private static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
    final Context a;
    final com.cguvuuqvlp.zaliiliwdx185920.a<String> b;
    final List<NameValuePair> c;
    final String d;
    final long e;
    final boolean f;

    public j(Context context, com.cguvuuqvlp.zaliiliwdx185920.a<String> aVar, List<NameValuePair> list, String str, long j, boolean z) {
        this.a = context;
        this.b = aVar;
        this.c = list;
        this.d = Base64.decodeString(str);
        Util.a("Url: " + this.d);
        this.e = j;
        this.f = z;
    }

    @Override // java.lang.Runnable
    public void run() {
        synchronized (this) {
            if (this.e != 0) {
                try {
                    Util.a("Thread is waiting for " + this.e + " ms.");
                    wait(this.e);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (Util.p(this.a)) {
                try {
                    try {
                        try {
                            try {
                                try {
                                    if (this.f) {
                                        this.c.addAll(n.a(this.a));
                                    }
                                    HttpPost httpPost = new HttpPost(this.d);
                                    Util.a("Values: " + this.c);
                                    httpPost.setEntity(new UrlEncodedFormEntity(this.c));
                                    BasicHttpParams basicHttpParams = new BasicHttpParams();
                                    HttpConnectionParams.setConnectionTimeout(basicHttpParams, 7000);
                                    HttpConnectionParams.setSoTimeout(basicHttpParams, 7000);
                                    DefaultHttpClient defaultHttpClient = new DefaultHttpClient(basicHttpParams);
                                    defaultHttpClient.addRequestInterceptor(new HttpRequestInterceptor() { // from class: com.cguvuuqvlp.zaliiliwdx185920.j.1
                                        @Override // org.apache.http.HttpRequestInterceptor
                                        public void process(HttpRequest request, HttpContext context) {
                                            if (!request.containsHeader(j.HEADER_ACCEPT_ENCODING)) {
                                                request.addHeader(j.HEADER_ACCEPT_ENCODING, j.ENCODING_GZIP);
                                            }
                                        }
                                    });
                                    defaultHttpClient.addResponseInterceptor(new HttpResponseInterceptor() { // from class: com.cguvuuqvlp.zaliiliwdx185920.j.2
                                        @Override // org.apache.http.HttpResponseInterceptor
                                        public void process(HttpResponse response, HttpContext context) {
                                            Header contentEncoding = response.getEntity().getContentEncoding();
                                            if (contentEncoding != null) {
                                                HeaderElement[] elements = contentEncoding.getElements();
                                                for (HeaderElement headerElement : elements) {
                                                    if (headerElement.getName().equalsIgnoreCase(j.ENCODING_GZIP)) {
                                                        response.setEntity(new a(response.getEntity()));
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                    });
                                    BasicHttpResponse basicHttpResponse = (BasicHttpResponse) defaultHttpClient.execute(httpPost);
                                    int statusCode = basicHttpResponse.getStatusLine().getStatusCode();
                                    Log.i(e.TAG, "Status Code: " + statusCode);
                                    if (statusCode == 200) {
                                        String entityUtils = EntityUtils.toString(basicHttpResponse.getEntity());
                                        if (entityUtils != null && !entityUtils.equals("")) {
                                            this.b.a(entityUtils);
                                            return;
                                        }
                                    } else {
                                        Log.i(e.TAG, "HTTP response reason: " + basicHttpResponse.getStatusLine().getReasonPhrase());
                                    }
                                } catch (SocketTimeoutException e2) {
                                    Log.d(e.TAG, "SocketTimeoutException Thrown: " + e2.toString());
                                }
                            } catch (SSLPeerUnverifiedException e3) {
                                Log.d(e.TAG, "SSL Exception: " + e3.getMessage());
                            }
                        } catch (IOException e4) {
                            Log.d(e.TAG, "IOException Thrown: " + e4.toString());
                        }
                    } catch (ClientProtocolException e5) {
                        Log.d(e.TAG, "ClientProtocolException Thrown: " + e5.toString());
                    } catch (Throwable th) {
                    }
                } catch (MalformedURLException e6) {
                    Log.d(e.TAG, "MalformedURLException Thrown: " + e6.toString());
                } catch (Exception e7) {
                    Log.d(e.TAG, "Exception Thrown: " + e7.getMessage());
                }
            }
            this.b.a(null);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    private static class a extends HttpEntityWrapper {
        public a(HttpEntity httpEntity) {
            super(httpEntity);
        }

        @Override // org.apache.http.entity.HttpEntityWrapper, org.apache.http.HttpEntity
        public InputStream getContent() throws IOException {
            return new GZIPInputStream(this.wrappedEntity.getContent());
        }

        @Override // org.apache.http.entity.HttpEntityWrapper, org.apache.http.HttpEntity
        public long getContentLength() {
            return -1L;
        }
    }
}
