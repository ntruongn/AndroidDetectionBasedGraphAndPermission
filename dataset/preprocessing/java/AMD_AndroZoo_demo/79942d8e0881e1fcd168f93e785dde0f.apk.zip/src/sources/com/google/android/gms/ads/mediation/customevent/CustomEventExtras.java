package com.google.android.gms.ads.mediation.customevent;

import com.google.ads.mediation.NetworkExtras;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class CustomEventExtras implements NetworkExtras {
    private final HashMap<String, Object> ji = new HashMap<>();

    public Object getExtra(String label) {
        return this.ji.get(label);
    }

    public void setExtra(String label, Object value) {
        this.ji.put(label, value);
    }
}
