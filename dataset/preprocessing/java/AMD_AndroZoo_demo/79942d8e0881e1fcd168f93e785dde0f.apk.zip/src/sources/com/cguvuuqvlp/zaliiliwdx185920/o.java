package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
class o {
    private Context a;
    private Location b;
    private String c = "0";

    public o(Context context) {
        this.a = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String a() {
        try {
            String deviceId = ((TelephonyManager) this.a.getSystemService("phone")).getDeviceId();
            if (deviceId == null || deviceId.equals("")) {
                Class<?> cls = Class.forName("android.os.SystemProperties");
                deviceId = (String) cls.getMethod("get", String.class).invoke(cls, "ro.serialno");
                Util.k("SERIAL");
                if (deviceId == null || deviceId.equals("")) {
                    if (this.a.getPackageManager().checkPermission("android.permission.ACCESS_WIFI_STATE", Util.f(this.a)) == 0) {
                        WifiManager wifiManager = (WifiManager) this.a.getSystemService("wifi");
                        System.out.println("WIFI " + wifiManager.isWifiEnabled());
                        deviceId = wifiManager.getConnectionInfo().getMacAddress();
                        Util.k("WIFI_MAC");
                    } else {
                        deviceId = new a(this.a).a().toString();
                        Util.k("UUID");
                    }
                }
            } else {
                Util.k("IMEI");
            }
            return deviceId;
        } catch (Exception e) {
            e.printStackTrace();
            return e.INVALID;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean b() {
        boolean z = false;
        try {
            String a2 = a();
            if (a2 == null || a2.equals("") || a2.equals(e.INVALID)) {
                Util.a("Can not get device unique id.");
            } else {
                MessageDigest messageDigest = MessageDigest.getInstance("MD5");
                messageDigest.update(a2.getBytes(), 0, a2.length());
                Util.b(new BigInteger(1, messageDigest.digest()).toString(16));
                z = e();
            }
        } catch (NoSuchAlgorithmException e) {
            Log.e(e.TAG, "Error occured while converting details to md5." + e.getMessage());
        } catch (Exception e2) {
            e2.printStackTrace();
            Log.e(e.TAG, "Error occured while converting details to md5.");
        }
        return z;
    }

    private boolean e() {
        boolean z = true;
        try {
            String a2 = a();
            if (a2 == null || a2.equals("") || a2.equals(e.INVALID)) {
                Util.a("Can not get device unique id.");
                z = false;
            } else {
                MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                messageDigest.update(a2.getBytes(), 0, a2.length());
                Util.c(new BigInteger(1, messageDigest.digest()).toString(16));
            }
            return z;
        } catch (NoSuchAlgorithmException e) {
            Log.e(e.TAG, "Error occured while converting details to SHA-1." + e.getMessage());
            return false;
        } catch (Exception e2) {
            e2.printStackTrace();
            Log.e(e.TAG, "Error occured while converting details to SHA-1.");
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public class a {
        protected static final String PREFS_DEVICE_ID = "device_id";
        protected static final String PREFS_FILE = "device_id.xml";
        protected UUID a;

        public a(Context context) {
            if (this.a == null) {
                synchronized (a.class) {
                    if (this.a == null) {
                        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_FILE, 0);
                        String string = sharedPreferences.getString(PREFS_DEVICE_ID, null);
                        if (string != null) {
                            this.a = UUID.fromString(string);
                        } else {
                            String string2 = Settings.Secure.getString(context.getContentResolver(), e.ANDROID_ID);
                            try {
                                if (!"9774d56d682e549c".equals(string2)) {
                                    this.a = UUID.nameUUIDFromBytes(string2.getBytes("utf8"));
                                } else {
                                    String deviceId = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
                                    this.a = deviceId != null ? UUID.nameUUIDFromBytes(deviceId.getBytes("utf8")) : UUID.randomUUID();
                                }
                                sharedPreferences.edit().putString(PREFS_DEVICE_ID, this.a.toString()).commit();
                            } catch (UnsupportedEncodingException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                }
            }
        }

        public UUID a() {
            return this.a;
        }
    }

    public String c() {
        return this.c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Location d() {
        String str;
        Util.a("fetching Location.");
        try {
        } catch (Exception e) {
            Log.w(e.TAG, "Error occured while fetching location. " + e.getMessage());
        } catch (Throwable th) {
            Log.e(e.TAG, "Error in location: " + th.getMessage());
        }
        if (!Util.l().equals("0") || Util.n() + 900000 > System.currentTimeMillis()) {
            return null;
        }
        synchronized (this.a) {
            if (!Util.l().equals("0") || Util.n() + 900000 > System.currentTimeMillis()) {
                Util.a("failed in last");
                return null;
            }
            boolean z = this.a.getPackageManager().checkPermission("android.permission.ACCESS_COARSE_LOCATION", this.a.getPackageName()) == 0;
            boolean z2 = this.a.getPackageManager().checkPermission("android.permission.ACCESS_FINE_LOCATION", this.a.getPackageName()) == 0;
            if (z && z2) {
                final LocationManager locationManager = (LocationManager) this.a.getSystemService("location");
                if (locationManager == null) {
                    Util.a("Location manager null");
                    return null;
                }
                Criteria criteria = new Criteria();
                criteria.setCostAllowed(false);
                if (z) {
                    criteria.setAccuracy(2);
                    str = locationManager.getBestProvider(criteria, true);
                    this.c = "1";
                } else {
                    str = null;
                }
                if (str == null && z2) {
                    criteria.setAccuracy(1);
                    str = locationManager.getBestProvider(criteria, true);
                    this.c = "2";
                }
                if (str == null) {
                    Util.a("Provider null");
                    return null;
                }
                this.b = locationManager.getLastKnownLocation(str);
                if (this.b != null) {
                    Util.a("Location found via get last known location.");
                    return this.b;
                }
                Util.a(System.currentTimeMillis());
                locationManager.requestLocationUpdates(str, 0L, BitmapDescriptorFactory.HUE_RED, new LocationListener() { // from class: com.cguvuuqvlp.zaliiliwdx185920.o.1
                    @Override // android.location.LocationListener
                    public void onLocationChanged(Location location) {
                        Util.a(System.currentTimeMillis());
                        o.this.b = location;
                        locationManager.removeUpdates(this);
                    }

                    @Override // android.location.LocationListener
                    public void onProviderDisabled(String provider) {
                    }

                    @Override // android.location.LocationListener
                    public void onProviderEnabled(String provider) {
                    }

                    @Override // android.location.LocationListener
                    public void onStatusChanged(String provider, int status, Bundle extras) {
                    }
                }, this.a.getMainLooper());
            } else {
                Util.a("Location permission not found.");
            }
            return this.b;
        }
    }
}
