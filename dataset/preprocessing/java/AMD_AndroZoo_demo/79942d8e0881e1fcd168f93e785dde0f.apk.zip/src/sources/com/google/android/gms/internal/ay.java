package com.google.android.gms.internal;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class ay {
    public final int ga;
    public final at gb;
    public final bc gc;
    public final String gd;
    public final aw ge;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public interface a {
        void f(int i);
    }

    public ay(int i) {
        this(null, null, null, null, i);
    }

    public ay(at atVar, bc bcVar, String str, aw awVar, int i) {
        this.gb = atVar;
        this.gc = bcVar;
        this.gd = str;
        this.ge = awVar;
        this.ga = i;
    }
}
