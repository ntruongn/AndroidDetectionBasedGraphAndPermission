package com.google.android.gms.drive.query;

import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.CollectionMetadataField;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.OrderedMetadataField;
import com.google.android.gms.internal.fh;
import com.google.android.gms.internal.fi;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class SearchableField {
    public static final MetadataField<String> TITLE = fh.TITLE;
    public static final MetadataField<String> MIME_TYPE = fh.MIME_TYPE;
    public static final MetadataField<Boolean> TRASHED = fh.TRASHED;
    public static final CollectionMetadataField<DriveId> PARENTS = fh.PARENTS;
    public static final OrderedMetadataField<Date> rM = fi.rM;
    public static final MetadataField<Boolean> STARRED = fh.STARRED;
    public static final OrderedMetadataField<Date> MODIFIED_DATE = fi.rJ;
}
