package com.cguvuuqvlp.zaliiliwdx185920;

import android.util.Log;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class XmlParser implements h {
    private String a = null;
    private String b;
    private String c;
    private String d;
    private String e;
    private String f;
    private String g;
    private List<HashMap<String, String>> h;
    private String i;
    private String j;
    private String k;
    private String l;
    private HashMap<String, String> m;
    private String n;
    private List<Creative> o;

    void a(CharSequence charSequence) {
    }

    public XmlParser(Reader reader) throws VastException, InvalidVastXML, XmlPullParserException, Exception, Throwable {
        Log.i(h.TAG, "Parsing vast Xml>>>>>>>..");
        this.o = new ArrayList();
        XmlPullParserFactory newInstance = XmlPullParserFactory.newInstance();
        newInstance.setNamespaceAware(true);
        XmlPullParser newPullParser = newInstance.newPullParser();
        newPullParser.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", false);
        newPullParser.setInput(reader);
        newPullParser.nextTag();
        newPullParser.require(2, this.a, h.VAST);
        this.c = newPullParser.getAttributeValue(this.a, "version");
        Log.i(h.TAG, "Vast version: " + this.c);
        newPullParser.nextTag();
        String name = newPullParser.getName();
        if (name.equals(h.ERROR)) {
            String attributeValue = newPullParser.getAttributeValue(this.a, "status");
            String a = a(newPullParser);
            a("Status: " + attributeValue + " Error: " + a);
            throw new VastException(a, attributeValue);
        }
        if (name.equals(h.AD)) {
            a("Inside ad tag");
            this.b = newPullParser.getAttributeValue(this.a, h.ID);
            while (newPullParser.next() != 3) {
                if (newPullParser.getEventType() == 2) {
                    String name2 = newPullParser.getName();
                    if (newPullParser.isEmptyElementTag()) {
                        a("Empty Tag: " + name2);
                        newPullParser.nextTag();
                    } else if (name2.equals(h.ERROR)) {
                        this.l = a(newPullParser);
                        a("Ad Error: " + this.l);
                    } else if (name2.equals(h.AD_SYSTEM)) {
                        this.e = newPullParser.getAttributeValue(this.a, "version");
                        this.d = a(newPullParser);
                        a("AdSytem version: " + this.e + ", name: " + this.d);
                    } else if (name2.equals(h.AD_TITLE)) {
                        this.f = a(newPullParser);
                        a("Ad title: " + this.f);
                    } else if (name2.equals(h.DESCRIPTION)) {
                        this.i = a(newPullParser);
                        a("Desc :" + this.i);
                    } else if (name2.equals(h.ADVERTISER)) {
                        this.j = a(newPullParser);
                        a("Advertise name: " + this.j);
                    } else if (name2.equals(h.SURVEY)) {
                        this.k = a(newPullParser);
                        a("Survey URI: " + this.k);
                    } else if (name2.equals(h.PRICING)) {
                        this.m = new HashMap<>();
                        String attributeValue2 = newPullParser.getAttributeValue(this.a, "model");
                        String attributeValue3 = newPullParser.getAttributeValue(this.a, h.PRICING_CURRENCY);
                        String a2 = a(newPullParser);
                        this.m.put("model", attributeValue2);
                        this.m.put(h.PRICING_CURRENCY, attributeValue3);
                        this.m.put(h.PRICING, a2);
                        a("model: " + attributeValue2 + ", cur: " + attributeValue3 + ", price: " + a2);
                    } else if (name2.equals(h.IMPRESSION)) {
                        if (this.h == null) {
                            this.h = new ArrayList();
                        }
                        HashMap<String, String> hashMap = new HashMap<>();
                        String attributeValue4 = newPullParser.getAttributeValue(this.a, h.ID);
                        String a3 = a(newPullParser);
                        hashMap.put(h.ID, attributeValue4);
                        hashMap.put(h.IMPRESSION, a3);
                        this.h.add(hashMap);
                        a("Impression Id: " + attributeValue4 + ", uri: " + a3);
                    } else if (name2.equals(h.CREATIVE)) {
                        this.o.add(new Creative(newPullParser));
                    }
                }
            }
            return;
        }
        throw new InvalidVastXML("Invalid vast XMl");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String a(XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        String nextText;
        synchronized (xmlPullParser) {
            nextText = xmlPullParser.nextText();
            if (xmlPullParser.getEventType() != 3) {
                xmlPullParser.nextTag();
            }
        }
        return nextText;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public class Creative {
        private boolean b;
        private String c;
        private String d;
        private String e;
        private String f;
        private String g;
        private List<HashMap<String, Object>> h;
        private HashMap<String, String> i;
        private String j;
        private String k;
        private List<HashMap<String, String>> l;
        private List<HashMap<String, String>> m;
        private List<HashMap<String, Object>> n;

        public Creative(XmlPullParser parser) throws XmlPullParserException, Exception, Throwable {
            XmlParser.this.a("Parsing Creative data");
            parser.require(2, XmlParser.this.a, h.CREATIVE);
            this.d = parser.getAttributeValue(XmlParser.this.a, h.ID);
            this.e = parser.getAttributeValue(XmlParser.this.a, h.SEQUENCE);
            this.f = parser.getAttributeValue(XmlParser.this.a, h.AD_ID);
            while (parser.next() != 3) {
                if (parser.getEventType() == 2) {
                    String name = parser.getName();
                    XmlParser.this.a("Creative Name: " + name);
                    if (parser.isEmptyElementTag()) {
                        XmlParser.this.a("Empty tag in creative: " + name);
                        parser.nextTag();
                    } else if (parser.getName().equals(h.LINEAR)) {
                        String attributeValue = parser.getAttributeValue(XmlParser.this.a, h.SKIP_OFF_SET);
                        if (attributeValue == null) {
                            this.b = false;
                            XmlParser.this.a("AdSkipable: " + this.b);
                        } else {
                            this.b = true;
                            this.c = attributeValue;
                            XmlParser.this.a("AdSkipable: " + this.b + ", Skip offset: " + this.c);
                        }
                    } else if (name.equals(h.ICON)) {
                        if (this.h == null) {
                            this.h = new ArrayList();
                        }
                        HashMap<String, Object> hashMap = new HashMap<>();
                        int a = a(parser.getAttributeValue(XmlParser.this.a, "width"));
                        int a2 = a(parser.getAttributeValue(XmlParser.this.a, "height"));
                        String attributeValue2 = parser.getAttributeValue(XmlParser.this.a, h.PROGRAM);
                        String attributeValue3 = parser.getAttributeValue(XmlParser.this.a, h.X_POSITION);
                        String attributeValue4 = parser.getAttributeValue(XmlParser.this.a, h.Y_POSITION);
                        String attributeValue5 = parser.getAttributeValue(XmlParser.this.a, h.DURATION);
                        String attributeValue6 = parser.getAttributeValue(XmlParser.this.a, "apiFramework");
                        String attributeValue7 = parser.getAttributeValue(XmlParser.this.a, h.OFFSET);
                        XmlParser.this.a("ICON: width: " + a + ", height: " + a2 + ", program: " + attributeValue2 + ", xPosition: " + attributeValue3 + ", duration:" + attributeValue5 + ", apiFramework:" + attributeValue6 + ", offset:" + attributeValue7);
                        hashMap.put("width", Integer.valueOf(a));
                        hashMap.put("height", Integer.valueOf(a2));
                        hashMap.put(h.PROGRAM, attributeValue2);
                        hashMap.put(h.X_POSITION, attributeValue3);
                        hashMap.put(h.Y_POSITION, attributeValue4);
                        hashMap.put("apiFramework", attributeValue6);
                        hashMap.put(h.DURATION, attributeValue5);
                        hashMap.put(h.OFFSET, attributeValue7);
                        while (parser.next() != 3) {
                            if (parser.getEventType() == 2) {
                                String name2 = parser.getName();
                                XmlParser.this.a("Icon Name: " + name);
                                if (parser.isEmptyElementTag()) {
                                    XmlParser.this.a("Empty tag in creative: " + name);
                                    parser.nextTag();
                                } else if (name2.equals(h.STATIC_RESOURCE)) {
                                    String attributeValue8 = parser.getAttributeValue(XmlParser.this.a, h.CREATIVE_TYPE);
                                    String a3 = XmlParser.this.a(parser);
                                    hashMap.put(h.CREATIVE_TYPE, attributeValue8);
                                    hashMap.put(h.STATIC_RESOURCE, a3);
                                    XmlParser.this.a("Creative type:" + attributeValue8 + ", Static res: " + a3);
                                } else if (name2.equals(h.ICON_CLICK_THROUGH)) {
                                    String a4 = XmlParser.this.a(parser);
                                    hashMap.put(h.ICON_CLICK_THROUGH, a4);
                                    XmlParser.this.a("Icon click through: " + a4);
                                    parser.nextTag();
                                } else if (name2.equals(h.ICON_CLICK_TRACKING)) {
                                    String a5 = XmlParser.this.a(parser);
                                    hashMap.put(h.ICON_CLICK_TRACKING, a5);
                                    XmlParser.this.a("IconClickTracking: " + a5);
                                } else if (name2.equals(h.ICON_VIEW_TRACKING)) {
                                    String a6 = XmlParser.this.a(parser);
                                    hashMap.put(h.ICON_VIEW_TRACKING, a6);
                                    XmlParser.this.a("IconViewTracking: " + a6);
                                }
                            }
                        }
                        this.h.add(hashMap);
                        parser.nextTag();
                    } else if (name.equals(h.DURATION)) {
                        this.g = XmlParser.this.a(parser);
                        XmlParser.this.a("Duration: " + this.g);
                    } else if (name.equals(h.TRACKING_EVENTS)) {
                        XmlParser.this.a("inside tracking event.");
                        while (parser.next() != 3) {
                            if (parser.getEventType() == 2) {
                                String name3 = parser.getName();
                                if (parser.isEmptyElementTag()) {
                                    XmlParser.this.a("Empty tag in tracking: " + name3);
                                    parser.nextTag();
                                } else if (name3.equals(h.TRACKING)) {
                                    if (this.i == null) {
                                        this.i = new HashMap<>();
                                    }
                                    String attributeValue9 = parser.getAttributeValue(XmlParser.this.a, "event");
                                    String a7 = XmlParser.this.a(parser);
                                    this.i.put(attributeValue9, a7);
                                    XmlParser.this.a("Tracking event: " + attributeValue9 + ", url: " + a7);
                                }
                            }
                        }
                    } else if (name.equals(h.AD_PARAMETERS)) {
                        this.j = XmlParser.this.a(parser);
                        XmlParser.this.a("AdParameters: " + this.j);
                    } else if (name.equals(h.VIDEO_CLICKS)) {
                        while (parser.next() != 3) {
                            if (parser.getEventType() == 2) {
                                String name4 = parser.getName();
                                if (parser.isEmptyElementTag()) {
                                    XmlParser.this.a("Empty tag in creative: " + name4);
                                    parser.nextTag();
                                } else if (name4.equals(h.CLICK_THROUGH)) {
                                    this.k = XmlParser.this.a(parser);
                                    XmlParser.this.a("Video click through url: " + this.k);
                                } else if (name4.equals(h.CLICK_TRACKING)) {
                                    HashMap<String, String> hashMap2 = new HashMap<>();
                                    String attributeValue10 = parser.getAttributeValue(XmlParser.this.a, h.ID);
                                    String a8 = XmlParser.this.a(parser);
                                    hashMap2.put(h.ID, attributeValue10);
                                    hashMap2.put(h.CLICK_TRACKING, a8);
                                    if (this.l == null) {
                                        this.l = new ArrayList();
                                    }
                                    this.l.add(hashMap2);
                                    XmlParser.this.a("Video click tracking ID: " + attributeValue10 + ", url: " + a8);
                                } else if (name4.equals(h.CUSTOM_CLICK)) {
                                    HashMap<String, String> hashMap3 = new HashMap<>();
                                    String attributeValue11 = parser.getAttributeValue(XmlParser.this.a, h.ID);
                                    String a9 = XmlParser.this.a(parser);
                                    hashMap3.put(h.ID, attributeValue11);
                                    hashMap3.put(h.CUSTOM_CLICK, a9);
                                    if (this.m == null) {
                                        this.m = new ArrayList();
                                    }
                                    this.m.add(hashMap3);
                                    XmlParser.this.a("Video Custom click tracking ID: " + attributeValue11 + ", url: " + a9);
                                }
                            }
                        }
                    } else if (name.equals(h.MEDIA_FILES)) {
                        while (parser.next() != 3) {
                            if (parser.getEventType() == 2) {
                                String name5 = parser.getName();
                                if (parser.isEmptyElementTag()) {
                                    XmlParser.this.a("Empty tag in media: " + name5);
                                    parser.nextTag();
                                } else if (name5.equals(h.MEDIA_FILE)) {
                                    String attributeValue12 = parser.getAttributeValue(XmlParser.this.a, h.ID);
                                    String attributeValue13 = parser.getAttributeValue(XmlParser.this.a, h.MEDIA_FILE_DELIVERY);
                                    String attributeValue14 = parser.getAttributeValue(XmlParser.this.a, "type");
                                    int a10 = a(parser.getAttributeValue(XmlParser.this.a, h.MEDIA_FILE_BIT_RATE));
                                    int a11 = a(parser.getAttributeValue(XmlParser.this.a, "width"));
                                    int a12 = a(parser.getAttributeValue(XmlParser.this.a, "height"));
                                    boolean parseBoolean = Boolean.parseBoolean(parser.getAttributeValue(XmlParser.this.a, h.MEDIA_FILE_SCALABLE));
                                    boolean parseBoolean2 = Boolean.parseBoolean(parser.getAttributeValue(XmlParser.this.a, h.MEDIA_FILE_MAINTAIN_ASPECT_RATIO));
                                    String attributeValue15 = parser.getAttributeValue(XmlParser.this.a, "apiFramework");
                                    String attributeValue16 = parser.getAttributeValue(XmlParser.this.a, h.MEDIA_FILE_CODEC);
                                    int a13 = a(parser.getAttributeValue(XmlParser.this.a, h.MEDIA_FILE_MAX_BITRATE));
                                    int a14 = a(parser.getAttributeValue(XmlParser.this.a, h.MEDIA_FILE_MIN_BITRATE));
                                    String a15 = XmlParser.this.a(parser);
                                    XmlParser.this.a("Media id: " + attributeValue12 + ", delivery: " + attributeValue13 + ", type: " + attributeValue14 + ", bitrate: " + a10 + ", width: " + a11 + ", height: " + a12 + ", scalable: " + parseBoolean + ", aspect ratio: " + parseBoolean2 + ", apiFrameowrk: " + attributeValue15 + ", codec: " + attributeValue16 + ", maxBitrate: " + a13 + ", minBitrate: " + a14 + ", URI: " + a15);
                                    HashMap<String, Object> hashMap4 = new HashMap<>();
                                    hashMap4.put(h.ID, attributeValue12);
                                    hashMap4.put(h.MEDIA_FILE_DELIVERY, attributeValue13);
                                    hashMap4.put("type", attributeValue14);
                                    hashMap4.put(h.MEDIA_FILE_BIT_RATE, Integer.valueOf(a10));
                                    hashMap4.put("width", Integer.valueOf(a11));
                                    hashMap4.put("height", Integer.valueOf(a12));
                                    hashMap4.put(h.MEDIA_FILE_SCALABLE, Boolean.valueOf(parseBoolean));
                                    hashMap4.put(h.MEDIA_FILE_MAINTAIN_ASPECT_RATIO, Boolean.valueOf(parseBoolean2));
                                    hashMap4.put("apiFramework", attributeValue15);
                                    hashMap4.put(h.MEDIA_FILE_CODEC, attributeValue16);
                                    hashMap4.put(h.MEDIA_FILE_MAX_BITRATE, Integer.valueOf(a13));
                                    hashMap4.put(h.MEDIA_FILE_MIN_BITRATE, Integer.valueOf(a14));
                                    hashMap4.put(h.MEDIA_FILE, a15);
                                    if (this.n == null) {
                                        this.n = new ArrayList();
                                    }
                                    this.n.add(hashMap4);
                                }
                            }
                        }
                    }
                }
            }
        }

        public boolean isAdLinearSkipable() {
            return this.b;
        }

        public String getSkipOffSet() {
            return this.c;
        }

        public String getId() {
            return this.d;
        }

        public String getSequence() {
            return this.e;
        }

        public String getCreativeAdId() {
            return this.f;
        }

        public String getDuration() {
            return this.g;
        }

        public List<HashMap<String, Object>> getIcons() {
            return this.h;
        }

        public HashMap<String, String> getTrackingEventMap() {
            return this.i;
        }

        public String getAdParams() {
            return this.j;
        }

        public String getVideoClickThrough() {
            return this.k;
        }

        public List<HashMap<String, String>> getVideoClickTracking() {
            return this.l;
        }

        public List<HashMap<String, String>> getVideoCustomClickTracking() {
            return this.m;
        }

        public List<HashMap<String, Object>> getMediaFiles() {
            return this.n;
        }

        private int a(String str) {
            try {
                return Integer.parseInt(str);
            } catch (NumberFormatException | Exception e) {
                return 0;
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public static class VastException extends IOException {
        private static final long serialVersionUID = 1;
        private int a;

        public VastException(String message, String code) {
            super(message);
            try {
                this.a = Integer.parseInt(code);
            } catch (NumberFormatException e) {
            }
        }

        public int getCode() {
            return this.a;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public static class InvalidVastXML extends IOException {
        private static final long serialVersionUID = 1;

        public InvalidVastXML(String message) {
            super(message);
        }
    }

    public String a() {
        return this.c;
    }

    public String b() {
        return this.d;
    }

    public String c() {
        return this.e;
    }

    public String d() {
        return this.g;
    }

    public String e() {
        return this.f;
    }

    public List<HashMap<String, String>> f() {
        return this.h;
    }

    public String g() {
        return this.i;
    }

    public String h() {
        return this.j;
    }

    public String i() {
        return this.k;
    }

    public String j() {
        return this.l;
    }

    public HashMap<String, String> k() {
        return this.m;
    }

    public String l() {
        return this.n;
    }

    public List<Creative> m() {
        return this.o;
    }

    public String n() {
        return this.b;
    }

    public String o() {
        return this.k;
    }
}
