package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class at {
    public final String adJson;
    public final String fD;
    public final List<String> fE;
    public final String fF;
    public final List<String> fG;
    public final String fH;

    public at(JSONObject jSONObject) throws JSONException {
        this.fD = jSONObject.getString(com.cguvuuqvlp.zaliiliwdx185920.h.ID);
        JSONArray jSONArray = jSONObject.getJSONArray("adapters");
        ArrayList arrayList = new ArrayList(jSONArray.length());
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(jSONArray.getString(i));
        }
        this.fE = Collections.unmodifiableList(arrayList);
        this.fF = jSONObject.optString("allocation_id", null);
        this.fG = az.a(jSONObject, "imp_urls");
        JSONObject optJSONObject = jSONObject.optJSONObject("ad");
        this.adJson = optJSONObject != null ? optJSONObject.toString() : null;
        JSONObject optJSONObject2 = jSONObject.optJSONObject("data");
        this.fH = optJSONObject2 != null ? optJSONObject2.toString() : null;
    }
}
