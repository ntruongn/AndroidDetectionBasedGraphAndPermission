package com.cguvuuqvlp.zaliiliwdx185920;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.VideoView;
import com.cguvuuqvlp.zaliiliwdx185920.AdListener;
import com.cguvuuqvlp.zaliiliwdx185920.AdView;
import com.cguvuuqvlp.zaliiliwdx185920.JP;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.plus.PlusShare;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class MV extends WebView implements IM {
    static MV a;
    boolean b;
    ValueCallback<String> c;
    private AdView d;
    private AdListener.BannerAdListener e;
    private Handler f;
    private String g;
    private DisplayMetrics h;
    private int i;
    private int j;
    private int k;
    private int l;
    private a m;
    private String n;
    private boolean o;
    private float p;
    private FrameLayout q;
    private ViewGroup r;
    private int s;
    private VideoView t;
    private MraidAdUtil u;
    private String v;
    private boolean w;
    private JP.ParseMraidJson x;
    private AdView.a y;

    @SuppressLint({"InlinedApi"})
    public MV(Context context, JP.ParseMraidJson parseMraidJson, Handler handler) {
        super(context);
        this.b = false;
        this.c = new ValueCallback<String>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.5
            @Override // android.webkit.ValueCallback
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public void onReceiveValue(String str) {
                Util.a("Value received: " + str);
            }
        };
        try {
            try {
                if (Build.VERSION.SDK_INT >= 11 && (context instanceof Activity)) {
                    ((Activity) context).getWindow().setFlags(16777216, 16777216);
                }
            } catch (Throwable th) {
            }
            this.v = parseMraidJson.getAd_url();
            this.f = handler;
            this.u = new MraidAdUtil();
            this.h = context.getResources().getDisplayMetrics();
            this.p = this.h.density;
            this.m = new a();
            this.x = parseMraidJson;
            h();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint({"InlinedApi"})
    public MV(Context context, AdView adView, AdListener.BannerAdListener adListener, Handler handler, AdView.a animationDrawListener) {
        super(context);
        this.b = false;
        this.c = new ValueCallback<String>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.5
            @Override // android.webkit.ValueCallback
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public void onReceiveValue(String str) {
                Util.a("Value received: " + str);
            }
        };
        try {
            if (Build.VERSION.SDK_INT >= 11 && (getContext() instanceof Activity)) {
                ((Activity) getContext()).getWindow().setFlags(16777216, 16777216);
            }
        } catch (Throwable th) {
        }
        this.y = animationDrawListener;
        a = this;
        this.x = adView.e;
        this.d = adView;
        this.e = adListener;
        this.f = handler;
        this.v = this.x.getAd_url();
        this.b = adView.a();
        this.u = new MraidAdUtil();
        this.g = adView.getPlacementType();
        this.h = context.getResources().getDisplayMetrics();
        this.p = this.h.density;
        this.i = this.h.widthPixels;
        this.j = this.h.heightPixels;
        try {
            this.k = (int) Util.b(this.i, getContext());
            this.l = (int) Util.b(this.j, getContext());
        } catch (Exception e) {
            e.printStackTrace();
        }
        Util.a("Device Width:" + this.i + ", Device Height:" + this.j);
        this.m = new a();
        setLayoutParams(new FrameLayout.LayoutParams(adView.getadWidth(), adView.getadHeight()));
        h();
        this.m.a();
    }

    @SuppressLint({"SetJavaScriptEnabled", "InlinedApi"})
    private void h() {
        setHorizontalScrollBarEnabled(false);
        setVerticalScrollBarEnabled(false);
        setScrollBarStyle(33554432);
        setBackgroundColor(0);
        setWebChromeClient(new b());
        WebSettings settings = getSettings();
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        settings.setCacheMode(2);
        settings.setLoadWithOverviewMode(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(false);
        settings.setJavaScriptEnabled(true);
        addJavascriptInterface(new JavaScriptInterface(), Base64.decodeString("YWlycHVzaF9tcmFpZA=="));
        if (Build.VERSION.SDK_INT >= 8) {
            settings.setPluginState(WebSettings.PluginState.ON);
        }
        setWebViewClient(new c());
        c(this.v);
        if (this.e != null) {
            this.e.onAdLoadingListener();
        }
    }

    void c(String str) {
        a(Util.s(getContext()));
        if (str != null && str.endsWith(".js")) {
            int lastIndexOf = str.lastIndexOf("/");
            loadDataWithBaseURL(str.substring(0, lastIndexOf - 1), "<html><head><script type=\"text/javascript\" src=\"" + str.substring(lastIndexOf, str.length() - 1) + "\"/></head><body></body></html>", "text/html", "utf-8", null);
            return;
        }
        if (this.x.isInlineScript()) {
            if (this.x.getTag() != null && !this.x.getTag().equals("")) {
                loadDataWithBaseURL(null, "<style>* {margin:0;padding:0;;}</style>\n" + this.x.getTag(), "text/html", "utf-8", null);
                return;
            }
            Log.e(IM.TAG, "Tag data is null");
            return;
        }
        if (this.x.isJsAd()) {
            if (this.x.getTag() != null && !this.x.getTag().equals("")) {
                loadDataWithBaseURL(null, "<html><head>\n" + this.x.getTag() + "\n<style>* {margin:0;padding:0;}</style></head><body></body></html>", "text/html", "UTF-8", null);
                return;
            }
            Log.e(IM.TAG, "Tag data is null");
            return;
        }
        if (this.x.isHtmlAd()) {
            if (this.x.getTag() != null && !this.x.getTag().equals("")) {
                loadDataWithBaseURL(null, "<html><head><style>* {margin:0;padding:0;;}</style></head><body>\n" + this.x.getTag() + "\n</body></html>", "text/html", "UTF-8", null);
                return;
            }
            Log.e(IM.TAG, "tag data is null");
            return;
        }
        if (str != null && !str.equals("")) {
            loadUrl(str);
        } else {
            Log.e(IM.TAG, "Invalid url: " + str);
        }
    }

    void g() {
        a("mraid.setPlacementType('" + this.g + "');");
        Util.a("SDK LOG: display Ad called.");
        a("mraid.setExpandProperties(" + this.m.a() + ");");
        i();
        setState(IM.STATE_DEFAULT);
        b(IM.EVENT_READY);
        if (this.f != null) {
            this.f.sendEmptyMessage(0);
            onAnimationEnd();
        }
        b();
        Log.i(IM.TAG, "Sending impression data:>");
        d(IM.MRAID_EVENT_IMPRESSION);
    }

    private void i() {
        boolean z;
        if (this.o && getVisibility() == 0) {
            z = true;
        } else {
            z = false;
        }
        if (z != this.w && this.n == IM.STATE_DEFAULT) {
            this.w = z;
            setViewable(this.w);
        }
    }

    @Override // android.webkit.WebView, android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.o = true;
        i();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.o = false;
        i();
    }

    @Override // android.view.View
    public void setVisibility(int visibility) {
        super.setVisibility(visibility);
        i();
    }

    @Override // android.webkit.WebView
    public void loadUrl(String url) {
        Util.a("Loading url: " + url);
        super.loadUrl(url);
    }

    @Override // android.webkit.WebView
    public void loadDataWithBaseURL(String baseUrl, String data, String mimeType, String encoding, String historyUrl) {
        super.loadDataWithBaseURL(baseUrl, data, mimeType, encoding, historyUrl);
        if (this.e != null) {
            this.e.onAdLoadingListener();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void j() {
        d();
        c();
        e();
        a();
    }

    @Override // android.view.View
    protected void onAnimationEnd() {
        super.onAnimationEnd();
        if (this.y != null) {
            Util.a("Animation end.");
            this.y.a();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.f
    public void expand(String url) {
        try {
            clearView();
            FrameLayout frameLayout = (FrameLayout) getRootView().findViewById(16908290);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
            View view = new View(getContext());
            view.setLayoutParams(getLayoutParams());
            this.q = new FrameLayout(getContext());
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-1, -1);
            layoutParams2.gravity = 17;
            this.q.setLayoutParams(layoutParams2);
            this.r = (ViewGroup) getParent();
            if (this.r != null) {
                int childCount = this.r.getChildCount();
                int i = 0;
                while (i < childCount && this.r.getChildAt(i) != this) {
                    i++;
                }
                this.s = i;
                setLayoutParams(layoutParams);
                this.r.removeView(this);
                this.q.addView(this);
                if (!this.m.a) {
                    Button a2 = a(5);
                    a2.setId(111);
                    FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(((int) this.p) * 50, ((int) this.p) * 50);
                    layoutParams3.gravity = 53;
                    a2.setLayoutParams(layoutParams3);
                    this.q.addView(a2);
                }
                frameLayout.addView(this.q);
                this.r.addView(view, this.s);
                this.r.setVisibility(8);
                setState(IM.STATE_EXPANDED);
                if (url != null && !url.equals("")) {
                    loadUrl(url);
                }
            }
            if (this.e != null) {
                this.e.onAdExpandedListner();
            }
            if (this.d != null) {
                this.d.d = false;
            }
            d(IM.MRAID_EVENT_EXPAND);
        } catch (Exception e) {
            d(IM.MRAID_EVENT_ERROR);
            e.printStackTrace();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.f
    public void resize() {
        int i;
        int i2;
        int i3;
        boolean z;
        int i4;
        int i5;
        int i6;
        int i7;
        int a2;
        int a3;
        int i8 = this.h.widthPixels;
        int i9 = this.h.heightPixels;
        try {
            clearView();
            if (this.u == null || this.u.getResizeProperties().equals("")) {
                i = 0;
                i2 = 0;
                i3 = i9;
                z = true;
                i4 = i8;
                i5 = 53;
            } else {
                try {
                    JSONObject jSONObject = new JSONObject(this.u.getResizeProperties());
                    if (jSONObject.isNull("width")) {
                        a2 = this.h.widthPixels;
                    } else {
                        a2 = (int) Util.a(jSONObject.getInt("width"), getContext());
                    }
                    if (jSONObject.isNull("height")) {
                        a3 = this.h.heightPixels;
                    } else {
                        a3 = (int) Util.a(jSONObject.getInt("height"), getContext());
                    }
                    String string = jSONObject.isNull(IM.CUSTOM_CLOSE_POSITION) ? IM.CUSTOM_CLOSE_POSITION_TOP_RIGHT : jSONObject.getString(IM.CUSTOM_CLOSE_POSITION);
                    int i10 = jSONObject.isNull(IM.OFF_SET_X) ? 0 : jSONObject.getInt(IM.OFF_SET_X);
                    int i11 = jSONObject.isNull(IM.OFF_SET_Y) ? 0 : jSONObject.getInt(IM.OFF_SET_Y);
                    boolean z2 = jSONObject.isNull(IM.ALLOW_OFF_SCREEN) ? true : jSONObject.getBoolean(IM.ALLOW_OFF_SCREEN);
                    int gravity = this.u.getGravity(string);
                    i3 = a3;
                    i = i11;
                    z = z2;
                    i4 = a2;
                    i2 = i10;
                    i5 = gravity;
                } catch (Exception e) {
                    if (this.e != null) {
                        this.e.onErrorListener(e.getMessage());
                    }
                    a("resize", "Error occured while parsing resizeProperties data.");
                    return;
                }
            }
            if (z) {
                i6 = i4;
                i7 = i3;
            } else {
                int[] a4 = a(i4, i3);
                i6 = a4[0];
                i7 = a4[1];
            }
            FrameLayout frameLayout = (FrameLayout) getRootView().findViewById(16908290);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(i6, i7);
            View view = new View(getContext());
            view.setLayoutParams(getLayoutParams());
            this.q = new FrameLayout(getContext());
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(i6, i7);
            layoutParams2.leftMargin = i2;
            layoutParams2.topMargin = i;
            this.q.setLayoutParams(layoutParams2);
            this.r = (ViewGroup) getParent();
            if (this.r != null) {
                int childCount = this.r.getChildCount();
                int i12 = 0;
                while (i12 < childCount && this.r.getChildAt(i12) != this) {
                    i12++;
                }
                this.s = i12;
                setLayoutParams(layoutParams);
                this.r.removeView(this);
                this.q.addView(this);
                try {
                    LinearLayout linearLayout = new LinearLayout(getContext());
                    FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams((int) (this.p * 50.0f), (int) (this.p * 50.0f));
                    layoutParams3.gravity = i5;
                    linearLayout.setLayoutParams(layoutParams3);
                    linearLayout.setGravity(i5);
                    this.q.addView(linearLayout);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
                frameLayout.addView(this.q);
                this.r.addView(view, this.s);
                this.r.setVisibility(8);
                setState(IM.STATE_RESIZED);
                b(IM.EVENT_SIZE_CHANGE);
            }
            if (this.e != null) {
                this.e.onAdExpandedListner();
            }
            if (this.d != null) {
                this.d.d = false;
            }
            d(IM.MRAID_EVENT_RESIZE);
        } catch (Exception e3) {
            d(IM.MRAID_EVENT_ERROR);
            e3.printStackTrace();
        }
    }

    private int[] a(int i, int i2) {
        if (i > this.i || i2 > this.j) {
            float f = i2 / i;
            if (((int) ((i - this.i) * f)) > ((int) ((i2 - this.j) * f))) {
                i = this.i;
                i2 = (int) (f * i);
            } else {
                i2 = this.i;
                i = (int) (i2 / f);
            }
        }
        return new int[]{i, i2};
    }

    private void setButtonBackground(Button button) {
        if (button != null) {
            try {
                Class<?> cls = Class.forName("com.android.internal.R$drawable");
                button.setBackgroundResource(cls.getField("ic_menu_close_clear_cancel").getInt(cls));
            } catch (Exception e) {
                button.setText("Close");
                button.setTypeface(null, 1);
                button.setBackgroundColor(0);
            }
        }
    }

    Button a(int i) {
        Button button = new Button(getContext());
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams((int) (this.p * 50.0f), (int) (this.p * 50.0f));
        button.setGravity(i);
        button.setLayoutParams(layoutParams);
        setButtonBackground(button);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                MV.this.close();
            }
        });
        return button;
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.f
    public void close() {
        try {
            if (this.d != null) {
                this.d.d = true;
            }
            if (this.n.equals(IM.STATE_EXPANDED)) {
                if (this.q != null && this.r != null) {
                    ((ViewGroup) this.q.getParent()).removeView(this.q);
                    this.q.removeView(this);
                    setLayoutParams(this.r.getChildAt(this.s).getLayoutParams());
                    this.r.removeViewAt(this.s);
                    this.r.setVisibility(0);
                }
                setState(IM.STATE_DEFAULT);
                if (this.d != null) {
                    this.d.getAd();
                }
            } else if (this.n.equals(IM.STATE_DEFAULT)) {
                ((ViewGroup) getParent()).setVisibility(8);
                setState(IM.STATE_HIDDEN);
                if (this.f != null) {
                    this.f.sendEmptyMessage(-3);
                }
            } else if (this.n.equals(IM.STATE_RESIZED)) {
                if (this.q != null && this.r != null) {
                    ((ViewGroup) this.q.getParent()).removeView(this.q);
                    this.q.removeView(this);
                    setLayoutParams(this.r.getChildAt(this.s).getLayoutParams());
                    this.r.removeViewAt(this.s);
                    this.r.setVisibility(0);
                }
                setState(IM.STATE_DEFAULT);
                if (this.d != null) {
                    this.d.getAd();
                }
            } else {
                ((ViewGroup) getParent()).setVisibility(8);
                setState(IM.STATE_HIDDEN);
                if (this.f != null) {
                    this.f.sendEmptyMessage(-3);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (this.e != null) {
            this.e.onCloseListener();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.f
    public void createCalendarEvent(String jsonString) {
        a(false);
        Util.a("SDK LOG: inside createCalendarEvent: " + jsonString);
        if (this.e != null) {
            this.e.onAdClickListener();
        }
        if (jsonString != null) {
            try {
                if (!jsonString.equals("")) {
                    Intent intent = new Intent(getContext(), (Class<?>) BrowserActivity.class);
                    intent.setAction("newCalendarEvent");
                    intent.addFlags(DriveFile.MODE_READ_ONLY);
                    intent.addFlags(8388608);
                    intent.putExtra("json", jsonString);
                    getContext().startActivity(intent);
                }
            } catch (Exception e) {
                e.printStackTrace();
                d(IM.MRAID_EVENT_ERROR);
                a("createCalendarEvent", "Error occured in createCalenderEvent.");
                Log.e(IM.TAG, "Error occured in createCalenderEvent.");
                return;
            }
        }
        a("createCalendarEvent", "Calender method called with empty json.");
        Log.e(IM.TAG, "Error occured while creating calendar event.");
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.f
    public void playVideo(String url) {
        a(false);
        try {
            if (this.e != null) {
                this.e.onAdClickListener();
            }
            Intent intent = new Intent(getContext(), (Class<?>) BrowserActivity.class);
            intent.setAction("playVideo");
            intent.putExtra(PlusShare.KEY_CALL_TO_ACTION_URL, url);
            intent.addFlags(8388608);
            intent.addFlags(DriveFile.MODE_READ_ONLY);
            getContext().startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            d(IM.MRAID_EVENT_ERROR);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.f
    public void storePicture(String imageURL, String fileNameWithExt) {
        a(false);
        try {
            if (this.e != null) {
                this.e.onAdClickListener();
            }
            if (imageURL == null || imageURL.equals("")) {
                a("storePicture", "Image url is null.");
                return;
            }
            if (fileNameWithExt == null || fileNameWithExt.equals("")) {
                a("storePicture", "File name is null.");
                return;
            }
            if (getContext() instanceof Activity) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setMessage("This image will be added in gallery. Please confirm ?");
                builder.setPositiveButton("Yes", new AnonymousClass2(imageURL, fileNameWithExt));
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.3
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        MV.this.a("storePicture", "User has canceled.");
                        if (MV.this.e != null) {
                            MV.this.e.onCloseListener();
                        }
                        MV.this.a(true);
                    }
                });
                builder.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.4
                    @Override // android.content.DialogInterface.OnCancelListener
                    public void onCancel(DialogInterface dialog) {
                        dialog.dismiss();
                        MV.this.a("storePicture", "User has canceled.");
                        if (MV.this.e != null) {
                            MV.this.e.onCloseListener();
                        }
                        MV.this.a(true);
                    }
                });
                builder.setCancelable(false);
                builder.show();
            }
        } catch (Exception e) {
            a("storePicture", "Error occured while storing picture.");
            d(IM.EVENT_ERROR);
            if (this.e != null) {
                this.e.onCloseListener();
            }
            a(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.cguvuuqvlp.zaliiliwdx185920.MV$2, reason: invalid class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public class AnonymousClass2 implements DialogInterface.OnClickListener {
        final /* synthetic */ String a;
        final /* synthetic */ String b;

        AnonymousClass2(String str, String str2) {
            this.a = str;
            this.b = str2;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.2.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(AnonymousClass2.this.a).openConnection();
                        httpURLConnection.setDoInput(true);
                        httpURLConnection.connect();
                        Bitmap decodeStream = BitmapFactory.decodeStream(httpURLConnection.getInputStream());
                        File file = new File(MV.this.getContext().getApplicationInfo().dataDir, AnonymousClass2.this.b);
                        Log.i("TAG", "file: " + file.getAbsolutePath());
                        FileOutputStream fileOutputStream = new FileOutputStream(file);
                        decodeStream.compress(Bitmap.CompressFormat.JPEG, 85, fileOutputStream);
                        fileOutputStream.flush();
                        fileOutputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        MediaStore.Images.Media.insertImage(MV.this.getContext().getContentResolver(), MV.this.getContext().getApplicationInfo().dataDir + "/" + AnonymousClass2.this.b, "My Image", AnonymousClass2.this.b);
                        MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.2.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                MV.this.d(IM.MRAID_EVENT_STORE_PICTURE);
                                Log.i(IM.TAG, "Ad image is saved in Gallery.");
                                MV.this.a(true);
                            }
                        });
                    } catch (FileNotFoundException e2) {
                        MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.2.1.2
                            @Override // java.lang.Runnable
                            public void run() {
                                MV.this.a("storePicture", "Url does not exist.");
                                MV.this.a(true);
                            }
                        });
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.2.1.3
                            @Override // java.lang.Runnable
                            public void run() {
                                MV.this.a("storePicture", "Unknown error occured: " + e3.getMessage());
                                if (MV.this.e != null) {
                                    MV.this.e.onCloseListener();
                                }
                                MV.this.a(true);
                            }
                        });
                        e3.printStackTrace();
                    }
                }
            }).start();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void b(String str) {
        a("mraid.triggerEvent('" + str + "');");
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void a(String str, String str2) {
        a("mraid.triggerErrorEvent(" + str + ",'" + str2 + "');");
        if (!this.b) {
            d(IM.EVENT_ERROR);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void a() {
        try {
            int b2 = (int) Util.b(getWidth(), getContext());
            int b3 = (int) Util.b(getHeight(), getContext());
            int x = Build.VERSION.SDK_INT > 10 ? (int) getX() : getLeft();
            int top = getTop();
            if (Build.VERSION.SDK_INT > 10) {
                top = (int) getY();
            }
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("x", x);
            jSONObject.put("y", top);
            jSONObject.put("width", b2);
            jSONObject.put("height", b3);
            a("mraid.setCurrentPosition(" + jSONObject + ");");
        } catch (Exception e) {
            a("setCurrentPosition", "Error occured while setting current position.");
            e.printStackTrace();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void b() {
        try {
            int b2 = (int) Util.b(getWidth(), getContext());
            int b3 = (int) Util.b(getHeight(), getContext());
            int x = Build.VERSION.SDK_INT > 10 ? (int) getX() : getLeft();
            int top = getTop();
            if (Build.VERSION.SDK_INT > 10) {
                top = (int) getY();
            }
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("x", x);
            jSONObject.put("y", top);
            jSONObject.put("width", b2);
            jSONObject.put("height", b3);
            a("mraid.setDefaultPosition(" + jSONObject + ");");
        } catch (Exception e) {
            a("setDefaultPosition", "Error occured while setting default position.");
            e.printStackTrace();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void c() {
        try {
            int i = this.k;
            int b2 = (int) Util.b(this.h.heightPixels - getTokenSize(), getContext());
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("width", i);
            jSONObject.put("height", b2);
            a("mraid.setMaxSize(" + jSONObject + ");");
        } catch (Exception e) {
            a("setMaxSize", "Error occured while setting max size.");
            e.printStackTrace();
        }
    }

    private int getTokenSize() {
        Rect rect = new Rect();
        Window window = ((Activity) getContext()).getWindow();
        window.getDecorView().getWindowVisibleDisplayFrame(rect);
        int i = rect.top;
        int top = window.findViewById(16908290).getTop() - i;
        Util.a("StatusBar Height= " + i + " , TitleBar Height = " + top);
        return top + i;
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void d() {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("width", this.k);
            jSONObject.put("height", this.l);
            a("mraid.setScreenSize(" + jSONObject + ");");
        } catch (Exception e) {
            a("setScreenSize", "Error occured while setting screen size.");
            e.printStackTrace();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void f() {
        try {
            Activity activity = (Activity) getContext();
            String forceOrientation = this.u.getForceOrientation();
            Configuration configuration = getResources().getConfiguration();
            boolean isOrientationChange = this.u.isOrientationChange();
            if (forceOrientation != null && forceOrientation.equals(IM.ORIENTATION_LANDSCAPE)) {
                activity.setRequestedOrientation(0);
                configuration.orientation = 2;
                activity.onConfigurationChanged(configuration);
                Util.a("Orientation cahnged to landscape.");
            } else if (forceOrientation != null && forceOrientation.equals(IM.ORIENTATION_PORTRAIT)) {
                activity.setRequestedOrientation(1);
                Util.a("Orientation changed to protrait.");
            } else if (forceOrientation != null && forceOrientation.equals("none")) {
                activity.setRequestedOrientation(-1);
                Util.a("Orientation changed to none.");
            }
            if (!isOrientationChange) {
                activity.setRequestedOrientation(activity.getRequestedOrientation());
                activity.onConfigurationChanged(configuration);
                Util.a("Orientation changed to false.");
            }
            Util.a("Orientation saved.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void e() {
        JSONObject t = Util.t(getContext());
        if (t != null) {
            a("mraid.setSupportedFeatures(" + t + ");");
        } else {
            a("supports", "Error occured in supports.");
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void a(final String str) {
        post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.6
            @Override // java.lang.Runnable
            public void run() {
                if (Build.VERSION.SDK_INT > 18) {
                    MV.this.evaluateJavascript(str, MV.this.c);
                } else {
                    MV.this.loadUrl("javascript:" + str);
                }
            }
        });
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void setState(String state) {
        this.n = state;
        a("mraid.setState('" + state + "');");
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.IM
    public void setViewable(boolean isViewable) {
        a("mraid.setViewable(" + isViewable + ");");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public class a {
        boolean a = false;

        a() {
        }

        String a() {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("width", MV.this.k);
                jSONObject.put("height", MV.this.l);
                jSONObject.put(IM.USE_CUSTOM_CLOSE, this.a);
                jSONObject.put(IM.IS_MODAL, true);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return jSONObject.toString();
        }

        void a(String str) {
            int i;
            int i2;
            try {
                JSONObject jSONObject = new JSONObject(str);
                MV mv = MV.this;
                if (jSONObject.isNull("width")) {
                    i = MV.this.k;
                } else {
                    i = jSONObject.getInt("width");
                }
                mv.i = i;
                MV mv2 = MV.this;
                if (jSONObject.isNull("height")) {
                    i2 = MV.this.l;
                } else {
                    i2 = jSONObject.getInt("height");
                }
                mv2.j = i2;
                this.a = jSONObject.isNull(IM.USE_CUSTOM_CLOSE) ? false : jSONObject.getBoolean(IM.USE_CUSTOM_CLOSE);
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e2) {
                MV.this.a("setExpandProperties", "An error occured while parsing expand properties json;");
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public class JavaScriptInterface extends i {
        public JavaScriptInterface() {
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.i
        @JavascriptInterface
        public void printJSLog(String log) {
            Log.i(IM.TAG, "JS Log: " + log);
        }

        @JavascriptInterface
        public void expand() {
            expand("");
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.f
        @JavascriptInterface
        public void expand(final String url) {
            MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.JavaScriptInterface.1
                @Override // java.lang.Runnable
                public void run() {
                    MV.this.expand(url);
                }
            });
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.f
        @JavascriptInterface
        public void close() {
            MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.JavaScriptInterface.2
                @Override // java.lang.Runnable
                public void run() {
                    MV.this.close();
                }
            });
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.i
        @JavascriptInterface
        public void open(String url) {
            if (MV.this.e != null) {
                MV.this.e.onAdClickListener();
            }
            Intent intent = new Intent(MV.this.getContext(), (Class<?>) BrowserActivity.class);
            intent.setAction("browser");
            intent.addFlags(DriveFile.MODE_READ_ONLY);
            intent.addFlags(8388608);
            intent.putExtra(PlusShare.KEY_CALL_TO_ACTION_URL, url);
            try {
                MV.this.getContext().startActivity(intent);
                MV.this.d(IM.MRAID_EVENT_OPEN);
            } catch (ActivityNotFoundException e) {
                Log.e(IM.TAG, "Required BrowserActivty is not added in manifest please add.");
                if (MV.this.e != null) {
                    MV.this.e.onErrorListener("Required BrowserActivty is not added in manifest please add.");
                }
                MV.this.d(IM.MRAID_EVENT_ERROR);
            }
            MV.this.a(true);
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.i
        @JavascriptInterface
        public void setExpandProperties(String json) {
            Util.a("Expand Json: " + json);
            if (MV.this.m != null) {
                MV.this.m.a(json);
                return;
            }
            MV.this.m = new a();
            MV.this.m.a(json);
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.i
        @JavascriptInterface
        public void setResizeProperties(String properties) {
            if (MV.this.u != null) {
                MV.this.u.setResizeProperties(properties);
            }
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.f
        @JavascriptInterface
        public void resize() {
            MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.JavaScriptInterface.3
                @Override // java.lang.Runnable
                public void run() {
                    MV.this.resize();
                }
            });
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.f
        @JavascriptInterface
        public void playVideo(final String url) {
            MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.JavaScriptInterface.4
                @Override // java.lang.Runnable
                public void run() {
                    MV.this.playVideo(url);
                }
            });
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.f
        @JavascriptInterface
        public void storePicture(final String url, final String fileName) {
            MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.JavaScriptInterface.5
                @Override // java.lang.Runnable
                public void run() {
                    MV.this.storePicture(url, fileName);
                }
            });
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.f
        @JavascriptInterface
        public void createCalendarEvent(final String json) {
            MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.JavaScriptInterface.6
                @Override // java.lang.Runnable
                public void run() {
                    MV.this.createCalendarEvent(json);
                }
            });
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.i
        @JavascriptInterface
        public void setOrientationProperties(String json) {
            Util.a("Orientation json: " + json);
            try {
                JSONObject jSONObject = new JSONObject(json);
                boolean z = jSONObject.isNull(IM.ALLOW_ORIENTATION_CHANGE) ? true : jSONObject.getBoolean(IM.ALLOW_ORIENTATION_CHANGE);
                MV.this.u.setForceOrientation(jSONObject.isNull(IM.FORCE_ORIENTATION) ? "none" : jSONObject.getString(IM.FORCE_ORIENTATION));
                MV.this.u.setOrientationChange(z);
                MV.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.JavaScriptInterface.7
                    @Override // java.lang.Runnable
                    public void run() {
                        MV.this.f();
                    }
                });
            } catch (Exception e) {
                MV.this.a("setOrientationProperties", "Error occured in while parsing orientation json.");
            }
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.i
        @JavascriptInterface
        public void showDialer(String phoneNumber) {
            Log.i(IM.TAG, "Showing dialer.....");
            try {
                if (MV.this.e != null) {
                    MV.this.e.onAdClickListener();
                }
            } catch (ActivityNotFoundException e) {
                MV.this.a("showDialer", "Error occurred while dialing number.");
                Log.e(IM.TAG, "Error whlie displaying push ad......: " + e.getMessage());
                MV.this.d(IM.MRAID_EVENT_ERROR);
            }
            if (phoneNumber == null || phoneNumber.equals("")) {
                MV.this.a("showDialer", "Phone numer is null.");
                return;
            }
            Intent intent = new Intent("android.intent.action.DIAL", Uri.parse("tel:" + phoneNumber));
            intent.addFlags(DriveFile.MODE_READ_ONLY);
            intent.addFlags(8388608);
            MV.this.getContext().startActivity(intent);
            MV.this.d(IM.MRAID_EVENT_TEL);
            MV.this.a(true);
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.i
        @JavascriptInterface
        public void sendSms(String number, String sms_text) {
            Log.i(IM.TAG, "Sending SMS.....");
            try {
                if (MV.this.e != null) {
                    MV.this.e.onAdClickListener();
                }
            } catch (Exception e) {
                Log.e(IM.TAG, "Error whlie displaying push ad......: " + e.getMessage());
                MV.this.a("sendSms", "Error occurred while sending message");
                MV.this.d(IM.EVENT_ERROR);
            }
            if (number == null || number.equals("")) {
                MV.this.a("sendSms", "Numer is null.");
                return;
            }
            if (sms_text == null || sms_text.equals("")) {
                MV.this.a("sendSms", "SMS text is null.");
                return;
            }
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.addFlags(DriveFile.MODE_READ_ONLY);
            intent.setType("vnd.android-dir/mms-sms");
            intent.putExtra("address", number);
            intent.putExtra("sms_body", sms_text);
            MV.this.getContext().startActivity(intent);
            MV.this.d(IM.MRAID_EVENT_SMS);
            MV.this.a(true);
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.i
        @JavascriptInterface
        public void downloadApp(String url) {
            try {
                if (MV.this.e != null) {
                    MV.this.e.onAdClickListener();
                }
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                intent.setFlags(DriveFile.MODE_READ_ONLY);
                intent.addFlags(8388608);
                MV.this.getContext().startActivity(intent);
                MV.this.d(IM.MRAID_EVENT_DOWNLOAD_APP);
            } catch (Exception e) {
                Log.e(IM.TAG, "Error whlie displaying App......: " + e.getMessage());
                MV.this.a("downloadApp", "Error occurred while redirecting to market.");
                MV.this.d(IM.EVENT_ERROR);
            }
            MV.this.a(true);
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.i
        @JavascriptInterface
        public void showLocation(String latitude, String longitude) {
            try {
                if (MV.this.e != null) {
                    MV.this.e.onAdClickListener();
                }
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(String.format(Locale.ENGLISH, "geo:%f,%f", latitude, longitude)));
                intent.setFlags(DriveFile.MODE_READ_ONLY);
                intent.addFlags(8388608);
                MV.this.getContext().startActivity(intent);
                MV.this.d(IM.MRAID_EVENT_SHOW_LOCATION);
            } catch (Exception e) {
                Log.e(IM.TAG, "Error occurred whlie displaying Location......: " + e.getMessage());
                MV.this.a("showLoaction", "Error occurred while showing location.");
                MV.this.d(IM.EVENT_ERROR);
            }
            MV.this.a(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public class c extends WebViewClient {
        boolean a = false;

        c() {
        }

        @Override // android.webkit.WebViewClient
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (!this.a) {
                if (MV.this.n == null || (MV.this.n != IM.STATE_EXPANDED && MV.this.n != IM.STATE_RESIZED)) {
                    MV.this.g();
                }
                if (MV.this.e != null) {
                    MV.this.e.onAdLoadedListener();
                }
                MV.this.j();
            }
        }

        @Override // android.webkit.WebViewClient
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            this.a = true;
            super.onReceivedError(view, errorCode, description, failingUrl);
            if (MV.this.e != null) {
                MV.this.e.onErrorListener(description);
            }
            if (MV.this.f != null) {
                MV.this.f.sendEmptyMessage(-4);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public class b extends WebChromeClient {
        private b() {
        }

        @Override // android.webkit.WebChromeClient
        public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
            super.onShowCustomView(view, callback);
            if (view instanceof FrameLayout) {
                FrameLayout frameLayout = (FrameLayout) view;
                if (frameLayout.getFocusedChild() instanceof VideoView) {
                    MV.this.t = (VideoView) ((FrameLayout) view).getFocusedChild();
                    frameLayout.removeView(MV.this.t);
                    ((ViewGroup) MV.this.getParent()).addView(MV.this.t);
                    MV.this.t.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.b.1
                        @Override // android.media.MediaPlayer.OnCompletionListener
                        public void onCompletion(MediaPlayer player) {
                            try {
                                player.stop();
                                MV.this.d(IM.MRAID_EVENT_INLINE_VIDEO);
                                MV.this.a(true);
                            } catch (Exception e) {
                            }
                        }
                    });
                    MV.this.t.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.b.2
                        @Override // android.media.MediaPlayer.OnErrorListener
                        public boolean onError(MediaPlayer mp, int what, int extra) {
                            MV.this.d(IM.MRAID_EVENT_ERROR);
                            MV.this.a(true);
                            return false;
                        }
                    });
                    MV.this.t.start();
                    MV.this.a(false);
                }
            }
        }

        @Override // android.webkit.WebChromeClient
        public void onHideCustomView() {
            if (MV.this.t != null) {
                ((ViewGroup) MV.this.getParent()).removeView(MV.this.t);
                if (MV.this.t.isPlaying()) {
                    MV.this.t.stopPlayback();
                }
            }
            MV.this.a(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void d(final String str) {
        synchronized (str) {
            if (this.b) {
                Util.a("Ad in test mode. Sending ignored.");
            } else if (Util.p(getContext())) {
                new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.MV.7
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            Log.i(IM.TAG, "Sending event: ");
                            if (MV.this.x.isErrorReporting() || !str.equals(IM.MRAID_EVENT_ERROR)) {
                                String impression_url = MV.this.x.getImpression_url();
                                if (impression_url.contains("%event%")) {
                                    impression_url = impression_url.replace("%event%", str);
                                }
                                Util.a("URL: " + impression_url);
                                DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
                                HttpPost httpPost = new HttpPost(impression_url);
                                BasicHttpParams basicHttpParams = new BasicHttpParams();
                                httpPost.setParams(basicHttpParams);
                                HttpConnectionParams.setConnectionTimeout(basicHttpParams, 15000);
                                HttpConnectionParams.setSoTimeout(basicHttpParams, 10000);
                                HttpResponse execute = defaultHttpClient.execute(httpPost);
                                int statusCode = execute == null ? 0 : execute.getStatusLine().getStatusCode();
                                Log.i(IM.TAG, "Status code: " + statusCode);
                                if (statusCode == 200) {
                                    Log.i(IM.TAG, "MRAID Data: " + EntityUtils.toString(execute.getEntity()));
                                    return;
                                }
                                return;
                            }
                            Util.a("Error reporting is off.");
                        } catch (Exception e) {
                            Log.e(IM.TAG, "Exception: " + e.getMessage());
                            e.printStackTrace();
                        }
                    }
                }, "mraid_event").start();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(boolean z) {
        if (this.d != null) {
            if (z && this.n != null && (!this.n.equalsIgnoreCase(IM.STATE_EXPANDED) || !this.n.equalsIgnoreCase(IM.STATE_RESIZED))) {
                this.d.d = true;
                if (this.g != null && this.g.equals("inline") && this.d != null) {
                    this.d.getAd();
                    return;
                }
                return;
            }
            this.d.d = false;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public static class MraidAdUtil {
        private String b;
        private String c;
        private boolean e;
        private String a = "";
        private boolean d = false;

        public String getResizeProperties() {
            return this.a;
        }

        public void setResizeProperties(String resizeProperties) {
            this.a = resizeProperties;
        }

        public String getExpandProperties() {
            return this.b;
        }

        public void setExpandProperties(String expandProperties) {
            this.b = expandProperties;
        }

        public String getForceOrientation() {
            return this.c;
        }

        public void setForceOrientation(String forceOrientation) {
            this.c = forceOrientation;
        }

        public void setOrientationChange(boolean orientationChange) {
            this.e = orientationChange;
        }

        public boolean isOrientationChange() {
            return this.e;
        }

        public void setUseCustomClose(boolean useCustomClose) {
            this.d = useCustomClose;
        }

        public boolean isUseCustomClose() {
            return this.d;
        }

        public int getGravity(String position) {
            if (position.equals(IM.CUSTOM_CLOSE_POSITION_TOP_RIGHT)) {
                return 53;
            }
            if (position.equals(IM.CUSTOM_CLOSE_POSITION_BOTTOM_CENTER)) {
                return 81;
            }
            if (position.equals(IM.CUSTOM_CLOSE_POSITION_BOTTOM_LEFT)) {
                return 83;
            }
            if (position.equals(IM.CUSTOM_CLOSE_POSITION_BOTTOM_RIGHT)) {
                return 85;
            }
            if (position.equals(IM.CUSTOM_CLOSE_POSITION_CENTER)) {
                return 17;
            }
            if (position.equals(IM.CUSTOM_CLOSE_POSITION_TOP_CENTER)) {
                return 49;
            }
            return position.equals(IM.CUSTOM_CLOSE_POSITION_TOP_LEFT) ? 51 : 53;
        }
    }
}
