package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.Context;
import android.content.SharedPreferences;
import com.cguvuuqvlp.zaliiliwdx185920.AdListener;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class b {
    private final String a = "ad_cache";
    private SharedPreferences b;
    private SharedPreferences.Editor c;

    public b(Context context) throws NullPointerException {
        this.b = context.getSharedPreferences("ad_cache", 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean a(AdListener.AdType adType, String str) throws Exception {
        this.c = this.b.edit();
        this.c.putString("" + adType, str);
        return this.c.commit();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean a(AdListener.AdType adType, String str, String str2) throws Exception {
        this.c = this.b.edit();
        this.c.putString("" + adType, str);
        this.c.putString("video_url", str2);
        return this.c.commit();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String a(AdListener.AdType adType) throws NullPointerException {
        return this.b.getString(adType.toString(), null);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String[] b(AdListener.AdType adType) throws Exception {
        return new String[]{this.b.getString(adType.toString(), null), this.b.getString("video_url", null)};
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(AdListener.AdType adType) throws Exception {
        this.c = this.b.edit();
        this.c.remove("" + adType);
        this.c.commit();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(AdListener.AdType adType) throws Exception {
        this.c = this.b.edit();
        this.c.remove(adType.toString());
        this.c.remove("video_url");
        this.c.commit();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(boolean z) {
        this.c = this.b.edit();
        this.c.putBoolean("thisSmartWall", z);
        this.c.commit();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean a() {
        return this.b.getBoolean("thisSmartWall", false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean e(AdListener.AdType adType) {
        String string;
        return (!Prm.enableCaching || (string = this.b.getString(adType.toString(), null)) == null || string.equals("")) ? false : true;
    }
}
