package com.google.android.gms.appstate;

import com.google.android.gms.internal.ee;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class a implements AppState {
    private final int jI;
    private final String jJ;
    private final byte[] jK;
    private final boolean jL;
    private final String jM;
    private final byte[] jN;

    public a(AppState appState) {
        this.jI = appState.getKey();
        this.jJ = appState.getLocalVersion();
        this.jK = appState.getLocalData();
        this.jL = appState.hasConflict();
        this.jM = appState.getConflictVersion();
        this.jN = appState.getConflictData();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int a(AppState appState) {
        return ee.hashCode(Integer.valueOf(appState.getKey()), appState.getLocalVersion(), appState.getLocalData(), Boolean.valueOf(appState.hasConflict()), appState.getConflictVersion(), appState.getConflictData());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a(AppState appState, Object obj) {
        if (!(obj instanceof AppState)) {
            return false;
        }
        if (appState == obj) {
            return true;
        }
        AppState appState2 = (AppState) obj;
        return ee.equal(Integer.valueOf(appState2.getKey()), Integer.valueOf(appState.getKey())) && ee.equal(appState2.getLocalVersion(), appState.getLocalVersion()) && ee.equal(appState2.getLocalData(), appState.getLocalData()) && ee.equal(Boolean.valueOf(appState2.hasConflict()), Boolean.valueOf(appState.hasConflict())) && ee.equal(appState2.getConflictVersion(), appState.getConflictVersion()) && ee.equal(appState2.getConflictData(), appState.getConflictData());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String b(AppState appState) {
        return ee.e(appState).a("Key", Integer.valueOf(appState.getKey())).a("LocalVersion", appState.getLocalVersion()).a("LocalData", appState.getLocalData()).a("HasConflict", Boolean.valueOf(appState.hasConflict())).a("ConflictVersion", appState.getConflictVersion()).a("ConflictData", appState.getConflictData()).toString();
    }

    @Override // com.google.android.gms.common.data.Freezable
    /* renamed from: aK, reason: merged with bridge method [inline-methods] */
    public AppState freeze() {
        return this;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    @Override // com.google.android.gms.appstate.AppState
    public byte[] getConflictData() {
        return this.jN;
    }

    @Override // com.google.android.gms.appstate.AppState
    public String getConflictVersion() {
        return this.jM;
    }

    @Override // com.google.android.gms.appstate.AppState
    public int getKey() {
        return this.jI;
    }

    @Override // com.google.android.gms.appstate.AppState
    public byte[] getLocalData() {
        return this.jK;
    }

    @Override // com.google.android.gms.appstate.AppState
    public String getLocalVersion() {
        return this.jJ;
    }

    @Override // com.google.android.gms.appstate.AppState
    public boolean hasConflict() {
        return this.jL;
    }

    public int hashCode() {
        return a(this);
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        return b(this);
    }
}
