package com.google.android.gms.drive.metadata;

import java.lang.Comparable;
import java.util.Collection;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public abstract class OrderedMetadataField<T extends Comparable<T>> extends MetadataField<T> {
    /* JADX INFO: Access modifiers changed from: protected */
    public OrderedMetadataField(String fieldName) {
        super(fieldName);
    }

    protected OrderedMetadataField(String fieldName, Collection<String> dataHolderFieldNames) {
        super(fieldName, dataHolderFieldNames);
    }
}
