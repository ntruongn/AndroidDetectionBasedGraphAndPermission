package com.cguvuuqvlp.zaliiliwdx185920;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import com.cguvuuqvlp.zaliiliwdx185920.AdListener;
import com.cguvuuqvlp.zaliiliwdx185920.JP;
import com.cguvuuqvlp.zaliiliwdx185920.Util;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class AdView extends FrameLayout {
    static final String AD_TYPE_BACC = "BACC";
    static final String AD_TYPE_BACM = "BACM";
    static final String AD_TYPE_BAU = "BAU";
    public static final String ANIMATION_TYPE_FADE = "fade";
    public static final String ANIMATION_TYPE_LEFT_TO_RIGHT = "left_to_right";
    public static final String ANIMATION_TYPE_TOP_DOWN = "top_down";
    static final int BACKGROUND_COLOR_DEFAULT = 0;
    static final int BANNER_HEIGHT_MOBILE = 50;
    static final int BANNER_HEIGHT_TABLET = 90;
    static final int BANNER_MEDIUM_RECTANGLE_HEIGHT = 250;
    static final int BANNER_MEDIUM_RECTANGLE_WIDTH = 300;
    public static final String BANNER_TYPE_IMAGE = "image";
    public static final String BANNER_TYPE_IN_APP_AD = "inappad";
    public static final String BANNER_TYPE_MEDIUM_RECTANGLE = "medium_rectangle";
    public static final String BANNER_TYPE_RICH_MEDIA = "rich_media";
    static final String BANNER_TYPE_TEXT = "text";
    static final int BANNER_WIDTH_MOBILE = 320;
    static final int BANNER_WIDTH_TABLET = 728;
    public static final String PLACEMENT_TYPE_INLINE = "inline";
    public static final String PLACEMENT_TYPE_INTERSTITIAL = "interstitial";
    static final int REFRESH_AD = 45;
    static final int TEXT_COLOR_DEFAULT = -1;
    static AdListener.BannerAdListener b;
    boolean a;
    long c;
    boolean d;
    JP.ParseMraidJson e;
    Handler f;
    com.cguvuuqvlp.zaliiliwdx185920.a<Boolean> g;
    private final String h;
    private boolean i;
    private boolean j;
    private int k;
    private String l;
    private boolean m;
    private Timer n;
    private Thread o;
    private JP.ParseBannerAd p;
    private int q;
    private int r;
    private int s;
    private int t;
    private List<View> u;
    private String v;
    private String w;
    private Drawable x;
    private boolean y;
    private a z;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public interface a {
        void a();
    }

    public AdView(Activity activity, String banner_type, String placementType, boolean isTestMode, boolean canShowMRInAPP, String animationForBanner) {
        super(activity);
        this.h = IM.TAG;
        this.a = false;
        this.i = false;
        this.j = false;
        this.k = REFRESH_AD;
        this.m = false;
        this.c = 0L;
        this.d = true;
        this.q = BANNER_WIDTH_MOBILE;
        this.r = 50;
        this.u = new ArrayList();
        this.v = "fade";
        this.w = BANNER_TYPE_IN_APP_AD;
        this.y = false;
        this.z = new a() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.1
            @Override // com.cguvuuqvlp.zaliiliwdx185920.AdView.a
            public void a() {
                AdView.this.f.sendEmptyMessage(2);
            }
        };
        this.f = new Handler() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.6
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 0:
                        AdView.this.setVisibility(0);
                        return;
                    case 1:
                    case 3:
                    case 5:
                    case 6:
                    case 7:
                    default:
                        return;
                    case 2:
                        AdView.this.f();
                        return;
                    case 4:
                        AdView.this.setVisibility(4);
                        return;
                    case 8:
                        AdView.this.setVisibility(8);
                        return;
                }
            }
        };
        this.g = new com.cguvuuqvlp.zaliiliwdx185920.a<Boolean>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.3
            @Override // com.cguvuuqvlp.zaliiliwdx185920.a
            public void a(final Boolean bool) {
                try {
                    AdView.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (bool.booleanValue()) {
                                AdView.this.c();
                            } else {
                                Log.e(IM.TAG, "Not able to get mraid.");
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override // com.cguvuuqvlp.zaliiliwdx185920.a
            public void a() {
                new Thread(new Util.NativeMraid(AdView.this.getContext(), this), "native_mraid").start();
            }
        };
        Log.i(IM.TAG, "Initializing AdView");
        this.j = isTestMode;
        Log.i(IM.TAG, "isTestMode: " + isTestMode);
        if (banner_type != null && (banner_type.equals(BANNER_TYPE_IMAGE) || banner_type.equals("rich_media") || banner_type.equals(BANNER_TYPE_MEDIUM_RECTANGLE) || banner_type.equals(BANNER_TYPE_IN_APP_AD))) {
            this.w = banner_type;
            Log.i(IM.TAG, "Banner Type: " + banner_type);
        } else {
            this.w = BANNER_TYPE_IN_APP_AD;
            Log.e(IM.TAG, "Invalid banner type. Setting to default: inappad");
        }
        if (this.w != null && this.w.equals("rich_media")) {
            if (placementType != null && (placementType.equals("inline") || placementType.equals("interstitial"))) {
                this.l = placementType;
            } else {
                this.l = "inline";
                Log.e(IM.TAG, "Invalid placement type. Setting to default: inline");
            }
        }
        this.k = REFRESH_AD;
        this.y = canShowMRInAPP;
        if (animationForBanner != null) {
            this.v = animationForBanner;
        } else {
            this.v = "fade";
        }
        if (!Prm.getDataFromManifest(activity) || !Prm.checkRequiredPermission(activity)) {
            this.i = true;
            return;
        }
        try {
            if (!Util.a(activity, (Class<?>) BrowserActivity.class)) {
                Log.e(IM.TAG, "Required BrowserActivty not found in Manifest please add.");
                if (b != null) {
                    b.onErrorListener("Required BrowserActivty not found in Manifest please add.");
                }
                this.i = true;
                return;
            }
        } catch (Exception e) {
        }
        setVisibility(8);
        if (!new o(activity).b()) {
            if (b != null) {
                b.onErrorListener("Can not serve ad on this device. Device details not found.");
            }
            this.i = true;
            return;
        }
        new n(activity).a();
        if (Prm.validate(activity)) {
            Util.a(activity);
        }
        this.x = getBackground();
        setClickable(true);
        setFocusable(true);
        setDescendantFocusability(AccessibilityEventCompat.TYPE_VIEW_TEXT_TRAVERSED_AT_MOVEMENT_GRANULARITY);
        b();
        if (this.o == null || !this.o.isAlive()) {
            getAd();
        }
    }

    public AdView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.h = IM.TAG;
        this.a = false;
        this.i = false;
        this.j = false;
        this.k = REFRESH_AD;
        this.m = false;
        this.c = 0L;
        this.d = true;
        this.q = BANNER_WIDTH_MOBILE;
        this.r = 50;
        this.u = new ArrayList();
        this.v = "fade";
        this.w = BANNER_TYPE_IN_APP_AD;
        this.y = false;
        this.z = new a() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.1
            @Override // com.cguvuuqvlp.zaliiliwdx185920.AdView.a
            public void a() {
                AdView.this.f.sendEmptyMessage(2);
            }
        };
        this.f = new Handler() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.6
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 0:
                        AdView.this.setVisibility(0);
                        return;
                    case 1:
                    case 3:
                    case 5:
                    case 6:
                    case 7:
                    default:
                        return;
                    case 2:
                        AdView.this.f();
                        return;
                    case 4:
                        AdView.this.setVisibility(4);
                        return;
                    case 8:
                        AdView.this.setVisibility(8);
                        return;
                }
            }
        };
        this.g = new com.cguvuuqvlp.zaliiliwdx185920.a<Boolean>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.3
            @Override // com.cguvuuqvlp.zaliiliwdx185920.a
            public void a(final Boolean bool) {
                try {
                    AdView.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (bool.booleanValue()) {
                                AdView.this.c();
                            } else {
                                Log.e(IM.TAG, "Not able to get mraid.");
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override // com.cguvuuqvlp.zaliiliwdx185920.a
            public void a() {
                new Thread(new Util.NativeMraid(AdView.this.getContext(), this), "native_mraid").start();
            }
        };
        Log.i(IM.TAG, "Initializing AdView from xml");
        if (attributeSet == null) {
            if (b != null) {
                b.onErrorListener("AttributeSet can not be null. If you are creating layout from dynamic code then use the other consturctor.");
            }
            Log.e(IM.TAG, "AttributeSet can not be null. If you are creating layout from dynamic code then use the other consturctor.");
            this.i = true;
            return;
        }
        if (!Prm.getDataFromManifest(context) || !Prm.checkRequiredPermission(context)) {
            this.i = true;
            return;
        }
        if (Prm.validate(context)) {
            Util.a(context);
        }
        setVisibility(8);
        try {
            if (!Util.a(context, (Class<?>) BrowserActivity.class)) {
                Log.e(IM.TAG, "Required BrowserActivty not found in Manifest please add.");
                if (b != null) {
                    b.onErrorListener("Required BrowserActivty not found in Manifest please add.");
                }
                this.i = true;
                return;
            }
        } catch (Exception e) {
        }
        if (!new o(context).b()) {
            if (b != null) {
                b.onErrorListener("Can not serve ad on this device. Device details not found.");
            }
            this.i = true;
            return;
        }
        new n(context).a();
        this.x = getBackground();
        setClickable(true);
        setFocusable(true);
        setDescendantFocusability(AccessibilityEventCompat.TYPE_VIEW_TEXT_TRAVERSED_AT_MOVEMENT_GRANULARITY);
        a(attributeSet);
        b();
        if (this.o == null || !this.o.isAlive()) {
            getAd();
        }
    }

    private void b() {
        SharedPreferences sharedPreferences = getContext().getSharedPreferences(e.SDK_PREFERENCE, 0);
        if (sharedPreferences == null || !sharedPreferences.contains(e.SDK_ENABLED)) {
            Prm.enableSDK(getContext(), true);
        }
    }

    private void a(AttributeSet attributeSet) {
        try {
            if (attributeSet != null) {
                this.j = attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res-auto", "test_mode", false);
                Log.i(IM.TAG, "isTestMode: " + this.j);
                this.k = REFRESH_AD;
                String attributeValue = attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "banner_type");
                if (attributeValue != null && (attributeValue.equals(BANNER_TYPE_IMAGE) || attributeValue.equals("rich_media") || attributeValue.equals(BANNER_TYPE_MEDIUM_RECTANGLE) || attributeValue.equals(BANNER_TYPE_IN_APP_AD))) {
                    Log.i(IM.TAG, "Banner Type: " + attributeValue);
                    this.w = attributeValue;
                } else {
                    this.w = BANNER_TYPE_IN_APP_AD;
                    Log.w(IM.TAG, "Invalid banner type. Setting to default: inappad");
                }
                if (attributeValue != null && attributeValue.equals("rich_media")) {
                    if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", IM.PLACEMENT_TYPE) != null) {
                        this.l = attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", IM.PLACEMENT_TYPE);
                    } else {
                        Log.w(IM.TAG, "Invalid placement type. Setting to default placementType: inline.");
                        this.l = "inline";
                    }
                }
                if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "animation") != null) {
                    this.v = attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "animation");
                } else {
                    this.v = "fade";
                }
                this.y = attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res-auto", "canShowMR", false);
                return;
            }
            Util.a("AttributeSet is null. Using default parameters");
            this.w = BANNER_TYPE_IN_APP_AD;
            this.y = false;
            this.v = "fade";
            this.k = REFRESH_AD;
            this.l = "inline";
            this.j = false;
        } catch (Exception e) {
            Log.e(IM.TAG, "Error occurred: ", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c() {
        try {
            g();
            if (this.e != null) {
                if (this.e.isHtmlAd() || this.e.isInlineScript() || this.e.isJsAd()) {
                    if (this.e.getTag() == null || this.e.equals("")) {
                        Log.i(IM.TAG, "Tag data is null");
                        return;
                    }
                } else if (this.e.getAd_url() == null || this.e.equals("")) {
                    Log.i(IM.TAG, "Ad url is null");
                    return;
                }
                Log.i(IM.TAG, "Loading Mraid ad..");
                MV mv = new MV(getContext(), this, b, this.f, this.z);
                int childCount = getChildCount();
                if (childCount > 0) {
                    for (int i = 0; i < childCount; i++) {
                        if (getChildAt(i) != null) {
                            this.u.add(getChildAt(i));
                        }
                    }
                }
                addView(mv);
                return;
            }
            removeAllViews();
            setVisibility(8);
            Log.i(IM.TAG, "Ad not loaded. Mraid data is null.");
            post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.7
                @Override // java.lang.Runnable
                public void run() {
                    if (AdView.b != null) {
                        AdView.b.onErrorListener("Ad not loaded. Url is null.");
                    }
                }
            });
        } catch (Exception e) {
            Log.w(IM.TAG, "Error occurred while loading rich media banner ad", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d() {
        try {
            g();
            if (this.p != null) {
                if (this.p.isHtmlAd() || this.p.a() || this.p.isJsAd() || this.p.b()) {
                    if (this.p.getTag().equals("")) {
                        Log.i(IM.TAG, "Tag data is null");
                        return;
                    }
                } else if (this.p.getAdimage() == null || this.p.getAdimage().equals("")) {
                    Log.i(IM.TAG, "image url is null");
                    return;
                }
                Log.i(IM.TAG, "Loading banner ad");
                IB ib = new IB(getContext(), this.s, this.t, this.f, this.p, this.z, this.j, this);
                e();
                addView(ib);
                Animation a2 = a(false);
                if (a2 != null) {
                    ib.startAnimation(a2);
                }
                Log.i(IM.TAG, "Ad loaded successfully");
                if (b != null) {
                    b.onAdLoadedListener();
                    return;
                }
                return;
            }
            removeAllViews();
            Log.w(IM.TAG, "Ad not loaded. Banner data is null.");
            setVisibility(8);
        } catch (Exception e) {
            Log.w(IM.TAG, "Error occurred while loading banner ad", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized void getAd() {
        if (!this.d || this.a) {
            Util.a("Ad request is disabled.");
        } else if (!Prm.isSDKEnabled(getContext())) {
            if (b != null) {
                post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.8
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.b.onErrorListener("SDK is diabled please enable to received ad.");
                    }
                });
            }
        } else if (this.m) {
            Log.i(IM.TAG, "Ad request is already in progress.");
            if (b != null) {
                post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.9
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.b.onErrorListener("Another ad request is already in progress. Please wait...");
                    }
                });
            }
        } else if (System.currentTimeMillis() - this.c < this.k) {
            Log.i(IM.TAG, "Ad requested beforing refresh time. Aborting request... ");
            if (b != null) {
                post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.10
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.b.onErrorListener("Ad requested beforing refresh time. Aborting request... ");
                    }
                });
            }
        } else {
            synchronized (this) {
                com.cguvuuqvlp.zaliiliwdx185920.a<String> aVar = new com.cguvuuqvlp.zaliiliwdx185920.a<String>() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.11
                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a() {
                        String str;
                        AdView.this.m = true;
                        if (AdView.this.w == null || !AdView.this.w.equals("rich_media")) {
                            if (AdView.this.w != null && AdView.this.w.equals(AdView.BANNER_TYPE_IN_APP_AD)) {
                                str = e.URL_IN_APP_AD_API;
                                if (AdView.this.j) {
                                    str = "aHR0cHM6Ly9hcGkuYWlycHVzaC5jb20vaW5hcHBhZHMvdGVzdGluYXBwYWRjYWxsLnBocA==";
                                }
                            } else {
                                str = e.URL_BANNER_API;
                                if (AdView.this.j) {
                                    str = e.URL_BANNER_TEST_API;
                                }
                            }
                        } else {
                            str = e.URL_MRAID_API;
                            if (AdView.this.j) {
                                str = e.URL_MRAID_TEST_API;
                            }
                        }
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(new BasicNameValuePair("banner_type", AdView.this.w));
                        arrayList.add(new BasicNameValuePair("supports", "" + Util.t(AdView.this.getContext())));
                        arrayList.add(new BasicNameValuePair("placement_type", "" + AdView.this.l));
                        arrayList.add(new BasicNameValuePair("canShowMR", String.valueOf(AdView.this.y)));
                        AdView.this.o = new Thread(new j(AdView.this.getContext(), this, arrayList, str, 0L, true), "AdView");
                        AdView.this.o.start();
                    }

                    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
                    public void a(String str) {
                        try {
                            Log.i(IM.TAG, "Ad json:" + str);
                            AdView.this.c = System.currentTimeMillis();
                            if (str != null && !str.equals("")) {
                                JSONObject jSONObject = new JSONObject(str);
                                String string = jSONObject.isNull("banner_type") ? "" : jSONObject.getString("banner_type");
                                if (string == null || string.equals("")) {
                                    Log.i(IM.TAG, "No banner type present in response.");
                                    final int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                    final String string2 = jSONObject.isNull("message") ? "" : jSONObject.getString("message");
                                    AdView.this.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.11.1
                                        @Override // java.lang.Runnable
                                        public void run() {
                                            AdView.this.a(i, string2);
                                        }
                                    });
                                    return;
                                }
                                if (AdView.this.w.equals(AdView.BANNER_TYPE_IN_APP_AD)) {
                                    if (string.equals("rich_media")) {
                                        String string3 = jSONObject.getString("adtype");
                                        if (string3.equals("MIT")) {
                                            AdView.this.l = "interstitial";
                                        } else {
                                            if (!string3.equals("MIN")) {
                                                Log.i(IM.TAG, "Invalid placement type for rich media.");
                                                return;
                                            }
                                            AdView.this.l = "inline";
                                        }
                                        AdView.this.a(AdView.this.getContext(), jSONObject);
                                    } else if (string.equals(AdView.BANNER_TYPE_IMAGE) || string.equals(AdView.BANNER_TYPE_TEXT)) {
                                        AdView.this.a(jSONObject);
                                    } else if (!string.equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE)) {
                                        Log.i(IM.TAG, "Invalid banner type in inappad json: " + string);
                                    } else if (AdView.this.y) {
                                        AdView.this.a(jSONObject);
                                    } else {
                                        Log.w(IM.TAG, "Can not show this ad.");
                                    }
                                } else if (AdView.this.w.equals("rich_media") && string.equals("rich_media")) {
                                    AdView.this.a(AdView.this.getContext(), jSONObject);
                                } else if (AdView.this.w.equals(AdView.BANNER_TYPE_IMAGE) && (string.equals(AdView.BANNER_TYPE_IMAGE) || string.equals(AdView.BANNER_TYPE_TEXT))) {
                                    AdView.this.a(jSONObject);
                                } else if (AdView.this.w.equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE) && string.equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE)) {
                                    AdView.this.a(jSONObject);
                                } else {
                                    Log.i(IM.TAG, "Invalid banner type in json: " + string);
                                }
                            }
                        } catch (Exception e) {
                            Log.w(IM.TAG, "error occurred while parsing banner", e);
                        } finally {
                            AdView.this.m = false;
                        }
                    }
                };
                if (Util.p(getContext())) {
                    aVar.a();
                } else {
                    post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.12
                        @Override // java.lang.Runnable
                        public void run() {
                            if (AdView.b != null) {
                                AdView.b.onErrorListener("Ad request failed. Internet connection not found.");
                            }
                        }
                    });
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(Context context, JSONObject jSONObject) {
        try {
            this.e = new JP.ParseMraidJson(getContext(), jSONObject);
            a("rich_media", this.e.getWidth(), this.e.getHeight());
            int refreshTime = this.e.getRefreshTime();
            if (refreshTime > 0 && this.k != refreshTime) {
                this.k = refreshTime;
                a(true, true);
            }
            String s = Util.s(context);
            if (s != null && !s.equals("")) {
                this.f.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.13
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.this.c();
                    }
                });
            } else if (Util.p(getContext())) {
                this.g.a();
            }
        } catch (IOException e) {
            Log.w(IM.TAG, "" + e.getMessage());
        } catch (JSONException e2) {
            Log.e(IM.TAG, "JSONExection occured while parsing MRAID json: " + e2.getMessage());
        } catch (Exception e3) {
            Log.w(IM.TAG, "Error occurred while parsing rich media json", e3);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(JSONObject jSONObject) {
        try {
            this.p = new JP.ParseBannerAd();
            if (this.p.a(getContext(), jSONObject, this.w)) {
                a(this.p.f(), this.p.getWidth(), this.p.getHeight());
                this.f.post(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.2
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.this.d();
                    }
                });
                int refreshTime = this.p.getRefreshTime();
                if (refreshTime > 0 && this.k != refreshTime) {
                    this.k = refreshTime;
                    a(true, true);
                }
            }
        } catch (JSONException e) {
            Log.e(IM.TAG, "JSONExection occured while parsing Banner ad json: " + e.getMessage());
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @Override // android.view.View
    public void setVisibility(int visibility) {
        if (super.getVisibility() != visibility) {
            synchronized (this) {
                int childCount = getChildCount();
                for (int i = 0; i < childCount; i++) {
                    getChildAt(i).setVisibility(visibility);
                }
                super.setVisibility(visibility);
            }
        }
    }

    @Override // android.view.View
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        a(hasWindowFocus, false);
        super.onWindowFocusChanged(hasWindowFocus);
        getParent();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        a(false, false);
        super.onAttachedToWindow();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        a(false, false);
        super.onDetachedFromWindow();
    }

    private void a(boolean z, boolean z2) {
        synchronized (this) {
            try {
            } catch (Exception e) {
                Log.e(IM.TAG, "Error in refresh timer", e);
            }
            if (!this.i) {
                if (z && !z2) {
                    if (this.n == null) {
                        this.n = new Timer();
                        this.n.scheduleAtFixedRate(new TimerTask() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.4
                            @Override // java.util.TimerTask, java.lang.Runnable
                            public void run() {
                                Util.a("Getting new ad....");
                                AdView.this.getAd();
                            }
                        }, this.k * 1000, this.k * 1000);
                    }
                } else if (z && z2) {
                    if (this.n != null) {
                        this.n.cancel();
                        this.n = null;
                        this.d = true;
                        this.n = new Timer();
                        this.n.scheduleAtFixedRate(new TimerTask() { // from class: com.cguvuuqvlp.zaliiliwdx185920.AdView.5
                            @Override // java.util.TimerTask, java.lang.Runnable
                            public void run() {
                                Util.a("Getting new ad....");
                                AdView.this.getAd();
                            }
                        }, this.k * 1000, this.k * 1000);
                        Log.i(IM.TAG, "Refresh time changed.> " + this.k);
                    }
                } else if (this.n != null) {
                    this.n.cancel();
                    this.n = null;
                    Log.i(IM.TAG, "Lost foucus. Removing thread>>>");
                    this.d = true;
                    if (this.o != null && this.o.isAlive()) {
                        this.o.interrupt();
                    }
                }
            }
        }
    }

    private void e() {
        int childCount = getChildCount();
        if (childCount > 0) {
            Animation a2 = a(true);
            for (int i = 0; i < childCount; i++) {
                if (a2 != null && getChildAt(i) != null) {
                    getChildAt(i).setAnimation(a2);
                    this.u.add(getChildAt(i));
                }
            }
        }
    }

    private Animation a(boolean z) {
        if (z) {
            if (this.v != null && this.v.equals("fade")) {
                AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, (float) BitmapDescriptorFactory.HUE_RED);
                alphaAnimation.setDuration(700L);
                return alphaAnimation;
            }
            if (this.v != null && this.v.equals("left_to_right")) {
                TranslateAnimation translateAnimation = new TranslateAnimation(2, BitmapDescriptorFactory.HUE_RED, 2, 1.0f, 2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED);
                translateAnimation.setDuration(900L);
                translateAnimation.setInterpolator(new AccelerateInterpolator());
                return translateAnimation;
            }
            if (this.v == null || !this.v.equals("top_down")) {
                return null;
            }
            TranslateAnimation translateAnimation2 = new TranslateAnimation(2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED, 2, 1.0f);
            translateAnimation2.setDuration(900L);
            translateAnimation2.setInterpolator(new AccelerateInterpolator());
            return translateAnimation2;
        }
        if (this.v != null && this.v.equals("fade")) {
            AlphaAnimation alphaAnimation2 = new AlphaAnimation((float) BitmapDescriptorFactory.HUE_RED, 1.0f);
            alphaAnimation2.setDuration(1200L);
            return alphaAnimation2;
        }
        if (this.v != null && this.v.equals("left_to_right")) {
            TranslateAnimation translateAnimation3 = new TranslateAnimation(2, -1.0f, 2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED);
            translateAnimation3.setDuration(900L);
            translateAnimation3.setInterpolator(new AccelerateInterpolator());
            return translateAnimation3;
        }
        if (this.v == null || !this.v.equals("top_down")) {
            return null;
        }
        TranslateAnimation translateAnimation4 = new TranslateAnimation(2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED, 2, -1.0f, 2, BitmapDescriptorFactory.HUE_RED);
        translateAnimation4.setDuration(900L);
        translateAnimation4.setInterpolator(new AccelerateInterpolator());
        return translateAnimation4;
    }

    @Override // android.widget.FrameLayout, android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(this.q, 1073741824), View.MeasureSpec.makeMeasureSpec(this.r, 1073741824));
        setMeasuredDimension(this.q, this.r);
    }

    private void a(String str, int i, int i2) {
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        float f = displayMetrics.density;
        if (i < BANNER_WIDTH_MOBILE) {
            i = BANNER_WIDTH_MOBILE;
        }
        if (i2 < 50) {
            i2 = 50;
        }
        this.r = (int) ((i2 * f) + 0.5f);
        this.t = i2;
        this.q = (int) ((i * f) + 0.5f);
        this.s = i;
        int i3 = this.r;
        int i4 = this.q;
        if (displayMetrics.heightPixels < this.r) {
            i3 = displayMetrics.heightPixels;
        }
        if (displayMetrics.widthPixels < this.q) {
            i4 = displayMetrics.widthPixels;
        }
        float f2 = this.r / i3;
        float f3 = this.q / i4;
        if (f2 > f3) {
            this.q = (int) (this.q / f2);
            this.r = i3;
            this.s = (int) (this.q / f);
            this.t = (int) (i3 / f);
            Util.a("if: " + f2 + " " + f3 + " " + this.q + " " + this.r + " " + this.s + " " + this.t);
            return;
        }
        this.q = i4;
        this.r = (int) (this.r / f3);
        this.s = (int) (i4 / f);
        this.t = (int) (this.r / f);
        Util.a("else: " + f2 + " " + f3 + " " + this.q + " " + this.r + " " + this.s + " " + this.t);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void f() {
        Iterator<View> it = this.u.iterator();
        while (it.hasNext()) {
            removeView(it.next());
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration newConfig) {
        if (Build.VERSION.SDK_INT >= 8) {
            super.onConfigurationChanged(newConfig);
        }
        if (this.p != null) {
            String f = this.p.f();
            if (f.equals(BANNER_TYPE_IMAGE) || f.equals(BANNER_TYPE_TEXT) || f.equals(BANNER_TYPE_MEDIUM_RECTANGLE)) {
                this.f.sendEmptyMessage(2);
                a(f, this.p.getWidth(), this.p.getHeight());
                d();
                return;
            }
            return;
        }
        if (this.e != null) {
            this.f.sendEmptyMessage(2);
            a("rich_media", this.e.getWidth(), this.e.getHeight());
            c();
        }
    }

    private void g() {
        try {
            if (Build.VERSION.SDK_INT >= 16) {
                setBackground(this.x);
            } else {
                setBackgroundDrawable(this.x);
            }
        } catch (Exception e) {
        }
    }

    public void setAdListener(AdListener.BannerAdListener adListener) {
        b = adListener;
    }

    public AdListener.BannerAdListener getAdListener() {
        return b;
    }

    String getBanner_type() {
        return this.w;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean a() {
        return this.j;
    }

    int getAdRefreshTime() {
        return this.k;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String getPlacementType() {
        return this.l;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getadWidth() {
        return this.q;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getadHeight() {
        return this.r;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(int i, String str) {
        if (str != null && !str.equals("")) {
            switch (i) {
                case 100:
                    if (b != null) {
                        b.onErrorListener(str);
                        return;
                    } else {
                        Log.e(IM.TAG, str);
                        return;
                    }
                case 120:
                    if (b != null) {
                        b.onErrorListener(str);
                        return;
                    } else {
                        Log.e(IM.TAG, str);
                        return;
                    }
                case 130:
                    if (b != null) {
                        b.onErrorListener(str);
                        return;
                    } else {
                        Log.e(IM.TAG, str);
                        return;
                    }
                case 204:
                    if (b != null) {
                        b.noAdAvailableListener();
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }
}
