package com.google.ads.mediation.customevent;

import com.cguvuuqvlp.zaliiliwdx185920.e;
import com.google.ads.mediation.MediationServerParameters;
import com.google.android.gms.plus.PlusShare;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class CustomEventServerParameters extends MediationServerParameters {

    @MediationServerParameters.Parameter(name = "class_name", required = true)
    public String className;

    @MediationServerParameters.Parameter(name = PlusShare.KEY_CALL_TO_ACTION_LABEL, required = true)
    public String label;

    @MediationServerParameters.Parameter(name = "parameter", required = e.isDebugMode)
    public String parameter = null;
}
