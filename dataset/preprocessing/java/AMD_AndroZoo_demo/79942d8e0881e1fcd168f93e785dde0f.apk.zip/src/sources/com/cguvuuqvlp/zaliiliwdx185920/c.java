package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.google.android.gms.drive.DriveFile;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
final class c {
    c() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(Context context, String str) throws Exception {
        try {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.setFlags(DriveFile.MODE_READ_ONLY);
            intent.addFlags(8388608);
            intent.addCategory("android.intent.category.LAUNCHER");
            intent.setClassName("com.android.browser", "com.android.browser.BrowserActivity");
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            System.out.println("Browser not found.");
            Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent2.setFlags(DriveFile.MODE_READ_ONLY);
            intent2.addFlags(8388608);
            context.startActivity(intent2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void b(Context context, String str) throws Exception {
        Intent intent = new Intent("android.intent.action.DIAL", Uri.parse("tel:" + str));
        intent.addFlags(DriveFile.MODE_READ_ONLY);
        context.startActivity(intent);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(Context context, String str, String str2) throws Exception {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(DriveFile.MODE_READ_ONLY);
        intent.setType("vnd.android-dir/mms-sms");
        intent.putExtra("address", str2);
        intent.putExtra("sms_body", str);
        context.startActivity(intent);
    }
}
