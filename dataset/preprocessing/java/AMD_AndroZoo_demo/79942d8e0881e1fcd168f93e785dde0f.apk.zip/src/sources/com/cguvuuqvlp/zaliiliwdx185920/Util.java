package com.cguvuuqvlp.zaliiliwdx185920;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class Util {
    private static final int NETWORK_TYPE_EHRPD = 14;
    private static final int NETWORK_TYPE_EVDO_B = 12;
    private static final int NETWORK_TYPE_HSDPA = 8;
    private static final int NETWORK_TYPE_HSPA = 10;
    private static final int NETWORK_TYPE_HSPAP = 15;
    private static final int NETWORK_TYPE_HSUPA = 9;
    private static final int NETWORK_TYPE_IDEN = 11;
    private static final int NETWORK_TYPE_LTE = 13;
    private static final String TAG = "PrmSDK";
    private static String a;
    private static boolean b;
    private static String c;
    private static String d;
    private static String f;
    private static String i;
    private static String j;
    private static float k;
    private static int l;
    private static Context m;
    private static String n;
    private static String o;
    private static String e = "airplay";
    private static String g = "0";
    private static String h = "0";
    private static long p = 0;
    private static String q = "0";

    Util(Context context) {
        m = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String a() {
        return "6.31";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(String str) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(String str, Throwable th) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean b() {
        return b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String c() {
        return a;
    }

    public static void a(final Context context) {
        try {
            new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.Util.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        AdvertisingIdClient.Info advertisingIdInfo = AdvertisingIdClient.getAdvertisingIdInfo(context);
                        String unused = Util.a = advertisingIdInfo.getId();
                        boolean unused2 = Util.b = advertisingIdInfo.isLimitAdTrackingEnabled();
                        Util.a("Advertisment id: " + Util.a);
                        Util.a("Ad opt out enabled : " + Util.b);
                    } catch (GooglePlayServicesNotAvailableException e2) {
                        Log.e("PrmSDK", "GooglePlayServicesNotAvailableException", e2);
                    } catch (GooglePlayServicesRepairableException e3) {
                        Log.e("PrmSDK", "GooglePlayServicesRepairableException", e3);
                    } catch (IOException e4) {
                        Log.e("PrmSDK", "IOException", e4);
                    } catch (IllegalStateException e5) {
                        Log.e("PrmSDK", "IllegalStateException", e5);
                    } catch (Exception e6) {
                        Log.e("PrmSDK", "Exception", e6);
                    }
                }
            }, "ad_id").start();
        } catch (Exception e2) {
            Log.e("PrmSDK", "Exception", e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void d() {
        try {
            q = l(f + r());
        } catch (Exception e2) {
            Log.e("PrmSDK", "Error occured while generating session id.");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String e() {
        return q;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean b(Context context) {
        DisplayMetrics displayMetrics = context.getApplicationContext().getResources().getDisplayMetrics();
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        int width = defaultDisplay.getWidth();
        int height = defaultDisplay.getHeight();
        float f2 = displayMetrics.density;
        if (width / f2 >= 600.0f && height / f2 >= 600.0f) {
            return true;
        }
        return false;
    }

    static Context f() {
        return m;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void c(Context context) {
        m = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String g() {
        return c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void b(String str) {
        c = str;
    }

    public static String h() {
        return d;
    }

    public static void c(String str) {
        d = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String i() {
        return e;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void d(String str) {
        e = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String j() {
        return f;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void e(String str) {
        f = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void f(String str) {
        n = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String k() {
        return n;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String l() {
        return h;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void g(String str) {
        h = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String m() {
        return g;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void h(String str) {
        g = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(long j2) {
        p = j2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long n() {
        return p;
    }

    public static String o() {
        return i;
    }

    public static void i(String str) {
        i = str;
    }

    public static float p() {
        return k;
    }

    public static void a(float f2) {
        k = f2;
    }

    public static void j(String str) {
        j = str;
    }

    public static String q() {
        return j;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String r() {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return "" + simpleDateFormat.format(new Date()) + "_" + simpleDateFormat.getTimeZone().getDisplayName() + "_" + simpleDateFormat.getTimeZone().getID() + "_" + simpleDateFormat.getTimeZone().getDisplayName(false, 0);
        } catch (Exception e2) {
            return "00";
        }
    }

    static String b(long j2) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return "" + simpleDateFormat.format(new Date(j2)) + "_" + simpleDateFormat.getTimeZone().getDisplayName() + "_" + simpleDateFormat.getTimeZone().getID() + "_" + simpleDateFormat.getTimeZone().getDisplayName(false, 0);
        } catch (Exception e2) {
            return "00";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String s() {
        return Build.MODEL;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String t() {
        return "" + Build.VERSION.SDK_INT;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String d(Context context) {
        if (context == null) {
            return "";
        }
        try {
            String string = Settings.Secure.getString(context.getApplicationContext().getContentResolver(), e.ANDROID_ID);
            a("Android ID: " + string);
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(string.getBytes(), 0, string.length());
            return new BigInteger(1, messageDigest.digest()).toString(16);
        } catch (NullPointerException e2) {
            Log.e("PrmSDK", "Android Id not found.");
            return "NOT FOUND";
        } catch (NoSuchAlgorithmException e3) {
            e3.printStackTrace();
            return "NOT FOUND";
        } catch (Exception e4) {
            e4.printStackTrace();
            return "NOT FOUND";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String e(Context context) {
        if (context == null) {
            return "";
        }
        try {
            String string = Settings.Secure.getString(context.getApplicationContext().getContentResolver(), e.ANDROID_ID);
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
            messageDigest.update(string.getBytes(), 0, string.length());
            return new BigInteger(1, messageDigest.digest()).toString(16);
        } catch (NullPointerException e2) {
            Log.e("PrmSDK", "Android Id not found.");
            return "NOT FOUND";
        } catch (NoSuchAlgorithmException e3) {
            e3.printStackTrace();
            return "NOT FOUND";
        } catch (Exception e4) {
            e4.printStackTrace();
            return "NOT FOUND";
        }
    }

    static void a(int i2) {
        l = i2;
    }

    static int u() {
        return l;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String f(Context context) {
        try {
            return context.getPackageName();
        } catch (Exception e2) {
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String g(Context context) {
        TelephonyManager telephonyManager;
        if (context != null && (telephonyManager = (TelephonyManager) context.getSystemService("phone")) != null && telephonyManager.getSimState() == 5) {
            return telephonyManager.getSimOperatorName();
        }
        return "";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String h(Context context) {
        TelephonyManager telephonyManager;
        if (context != null && (telephonyManager = (TelephonyManager) context.getSystemService("phone")) != null && telephonyManager.getPhoneType() == 1) {
            return telephonyManager.getNetworkOperatorName();
        }
        return "";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String v() {
        return Build.MANUFACTURER;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int i(Context context) {
        if (context == null) {
            return 0;
        }
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        return (activeNetworkInfo != null && activeNetworkInfo.isConnected() && activeNetworkInfo.getTypeName().equals("WIFI")) ? 1 : 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String j(Context context) {
        NetworkInfo activeNetworkInfo;
        return (context == null || (activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo()) == null || !activeNetworkInfo.isConnected() || activeNetworkInfo.getTypeName().equals("WIFI")) ? "" : activeNetworkInfo.getSubtypeName();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:36:0x005a -> B:14:0x0005). Please submit an issue!!! */
    public static boolean k(Context context) {
        boolean z;
        NetworkInfo activeNetworkInfo;
        if (context == null) {
            return false;
        }
        try {
            activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        if (activeNetworkInfo == null || !activeNetworkInfo.isConnected()) {
            z = false;
        } else {
            int type = activeNetworkInfo.getType();
            if (type == 1) {
                System.out.println("CONNECTED VIA WIFI");
                z = true;
            } else {
                if (type == 0) {
                    switch (activeNetworkInfo.getSubtype()) {
                        case 0:
                            z = false;
                            break;
                        case 1:
                            z = false;
                            break;
                        case 2:
                            z = false;
                            break;
                        case 3:
                            z = true;
                            break;
                        case 4:
                            z = false;
                            break;
                        case 5:
                            z = true;
                            break;
                        case 6:
                            z = true;
                            break;
                        case 7:
                            z = false;
                            break;
                        case 8:
                            z = true;
                            break;
                        case 9:
                            z = true;
                            break;
                        case 10:
                            z = true;
                            break;
                        case 11:
                            z = false;
                            break;
                        case 12:
                            z = true;
                            break;
                        case 13:
                            z = true;
                            break;
                        case 14:
                            z = true;
                            break;
                        case 15:
                            z = true;
                            break;
                        default:
                            z = false;
                            break;
                    }
                }
                z = false;
            }
        }
        return z;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String w() {
        return o;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void k(String str) {
        o = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String l(Context context) {
        if (context == null) {
            return "";
        }
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        if (Build.VERSION.SDK_INT >= 13) {
            Point point = new Point();
            defaultDisplay.getSize(point);
            return point.x + "_" + point.y;
        }
        return "" + defaultDisplay.getWidth() + "_" + defaultDisplay.getHeight();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String[] m(Context context) {
        Geocoder geocoder;
        String[] strArr = {"", ""};
        try {
            geocoder = new Geocoder(context);
        } catch (IOException e2) {
        } catch (Exception e3) {
        } catch (Throwable th) {
            th.printStackTrace();
        }
        if (h == null || h.equals(e.INVALID) || g == null || g.equals(e.INVALID)) {
            return strArr;
        }
        List<Address> fromLocation = geocoder.getFromLocation(Double.parseDouble(h), Double.parseDouble(g), 1);
        if (!fromLocation.isEmpty()) {
            strArr[0] = fromLocation.get(0).getCountryName();
            strArr[1] = fromLocation.get(0).getPostalCode();
            a("Postal Code: " + strArr[1] + " Country Code: " + fromLocation.get(0).getCountryCode());
        }
        return strArr;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String x() {
        return Locale.getDefault().getDisplayLanguage();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String n(Context context) {
        return "" + context.getResources().getDisplayMetrics().density;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String o(Context context) {
        return "" + context.getResources().getDisplayMetrics().densityDpi;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean p(Context context) {
        try {
            NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                return true;
            }
            Log.e("PrmSDK", "Internet connection not found.");
            Prm.sendAdError("Internet connection not found.");
            return false;
        } catch (Exception e2) {
            e2.printStackTrace();
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String q(Context context) {
        ApplicationInfo applicationInfo;
        try {
            PackageManager packageManager = context.getPackageManager();
            try {
                applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 0);
            } catch (PackageManager.NameNotFoundException e2) {
                applicationInfo = null;
            }
            return (String) (applicationInfo != null ? packageManager.getApplicationLabel(applicationInfo) : "(unknown)");
        } catch (Exception e3) {
            e3.printStackTrace();
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @SuppressLint({"InlinedApi"})
    public static String r(Context context) {
        String string;
        try {
            if (Build.VERSION.SDK_INT >= 17) {
                string = Settings.Global.getString(context.getContentResolver(), "install_non_market_apps");
            } else {
                string = Settings.Secure.getString(context.getContentResolver(), "install_non_market_apps");
            }
            return string;
        } catch (Exception e2) {
            return "0";
        }
    }

    static final String l(String str) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(str.getBytes(), 0, str.length());
            return new BigInteger(1, messageDigest.digest()).toString(16);
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
            return "";
        } catch (Exception e3) {
            e3.printStackTrace();
            return "";
        }
    }

    static final String m(String str) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
            messageDigest.update(str.getBytes(), 0, str.length());
            return new BigInteger(1, messageDigest.digest()).toString(16);
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
            return "";
        } catch (Exception e3) {
            e3.printStackTrace();
            return "";
        }
    }

    static boolean a(Context context, String str) throws NullPointerException, Exception {
        return context.getPackageManager().queryIntentActivities(new Intent(str), 65536).size() > 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a(Context context, Class<?> cls) throws NullPointerException, Exception {
        return context.getPackageManager().queryIntentActivities(new Intent(context, cls), 65536).size() > 0;
    }

    public static String s(Context context) {
        try {
            return context.getSharedPreferences("mraid", 0).getString("mr", null);
        } catch (Exception e2) {
            return null;
        }
    }

    public static JSONObject t(Context context) {
        boolean z;
        boolean z2;
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            if (telephonyManager == null || telephonyManager.getSimState() != 5) {
                z = false;
                z2 = false;
            } else {
                z = true;
                z2 = true;
            }
            boolean a2 = Build.VERSION.SDK_INT > 7 ? a(context, "android.intent.action.EDIT") : false;
            boolean z3 = (context.checkCallingOrSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0) && Environment.getExternalStorageState().equals("mounted");
            boolean z4 = Build.VERSION.SDK_INT > 10;
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("sms", z2);
            jSONObject.put("tel", z);
            jSONObject.put("calendar", a2);
            jSONObject.put("storePictures", z3);
            jSONObject.put("inlineVideo", z4);
            return jSONObject;
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public static float a(float f2, Context context) throws Exception {
        return (context.getResources().getDisplayMetrics().densityDpi / 160.0f) * f2;
    }

    public static float b(float f2, Context context) throws Exception {
        return f2 / (context.getResources().getDisplayMetrics().densityDpi / 160.0f);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public static final class NativeMraid implements Runnable {
        a<Boolean> a;
        private Context b;

        public NativeMraid(Context context, a<Boolean> asyncTaskCompleteListener) {
            this.b = context;
            this.a = asyncTaskCompleteListener;
        }

        @Override // java.lang.Runnable
        public void run() {
            HttpURLConnection httpURLConnection;
            HttpURLConnection httpURLConnection2 = null;
            try {
                try {
                    if (Util.p(this.b)) {
                        Log.i(IM.TAG, "Getting mraid>>>>");
                        httpURLConnection = (HttpURLConnection) new URL(Base64.decodeString(e.MRAID_URL)).openConnection();
                        try {
                            httpURLConnection.setRequestMethod("GET");
                            httpURLConnection.setConnectTimeout(15000);
                            httpURLConnection.setReadTimeout(15000);
                            httpURLConnection.setUseCaches(true);
                            httpURLConnection.setDefaultUseCaches(true);
                            httpURLConnection.connect();
                            if (httpURLConnection.getResponseCode() == 200) {
                                InputStream inputStream = httpURLConnection.getInputStream();
                                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                                StringBuilder sb = new StringBuilder();
                                while (true) {
                                    String readLine = bufferedReader.readLine();
                                    if (readLine == null) {
                                        break;
                                    }
                                    sb.append(readLine);
                                    sb.append("\n");
                                }
                                bufferedReader.close();
                                inputStream.close();
                                String sb2 = sb.toString();
                                if (sb2 != null && !sb2.equals("") && sb2.contains("mraid")) {
                                    SharedPreferences.Editor edit = this.b.getSharedPreferences("mraid", 0).edit();
                                    edit.putString("mr", sb.toString());
                                    this.a.a(Boolean.valueOf(edit.commit()));
                                    if (httpURLConnection != null) {
                                        httpURLConnection.disconnect();
                                        return;
                                    }
                                    return;
                                }
                                Log.w("PrmSDK", "Invalid js file.");
                            } else {
                                Log.i(IM.TAG, "Status Code: " + httpURLConnection.getResponseCode());
                                Log.i(IM.TAG, "HTTP Reason: " + httpURLConnection.getResponseMessage());
                            }
                        } catch (Exception e) {
                            httpURLConnection2 = httpURLConnection;
                            e = e;
                            Log.w(IM.TAG, "Error in native mraid: " + e.getMessage());
                            if (httpURLConnection2 != null) {
                                httpURLConnection2.disconnect();
                            }
                            this.a.a(false);
                        } catch (Throwable th) {
                            httpURLConnection2 = httpURLConnection;
                            th = th;
                            if (httpURLConnection2 != null) {
                                httpURLConnection2.disconnect();
                            }
                            throw th;
                        }
                    } else {
                        httpURLConnection = null;
                    }
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                } catch (Exception e2) {
                    e = e2;
                }
                this.a.a(false);
            } catch (Throwable th2) {
                th = th2;
            }
        }
    }
}
