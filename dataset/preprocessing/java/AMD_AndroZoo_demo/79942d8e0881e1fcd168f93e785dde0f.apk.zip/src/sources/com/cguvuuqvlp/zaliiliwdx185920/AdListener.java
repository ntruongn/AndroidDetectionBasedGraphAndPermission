package com.cguvuuqvlp.zaliiliwdx185920;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public interface AdListener {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public enum AdType {
        smartwall,
        overlay,
        video,
        appwall,
        interstitial
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public interface BannerAdListener {
        void noAdAvailableListener();

        void onAdClickListener();

        void onAdExpandedListner();

        void onAdLoadedListener();

        void onAdLoadingListener();

        void onCloseListener();

        void onErrorListener(String str);
    }

    void noAdAvailableListener();

    void onAdCached(AdType adType);

    void onAdError(String str);

    void onSDKIntegrationError(String str);

    void onSmartWallAdClosed();

    void onSmartWallAdShowing();
}
