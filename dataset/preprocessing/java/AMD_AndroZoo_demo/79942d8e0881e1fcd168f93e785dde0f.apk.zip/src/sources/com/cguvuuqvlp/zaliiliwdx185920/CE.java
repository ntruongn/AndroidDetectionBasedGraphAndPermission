package com.cguvuuqvlp.zaliiliwdx185920;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import com.google.android.gms.plus.PlusShare;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
abstract class CE {
    static final String EVENT_RECURRENCE = "rrule";
    static final String EVENT_REMINDER = "reminder";
    static final String EVENT_TRANSPARENCY = "transparency";
    final String a = h.ID;
    final String b = "summary";
    final String c = "location";
    final String d = PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION;
    final String e = h.EVENT_START;
    final String f = "end";
    final String g = "status";
    final String h = EVENT_TRANSPARENCY;
    final String i = "recurrence";
    final String j = EVENT_REMINDER;

    CE() {
    }

    @TargetApi(14)
    public static void a(Activity activity, String str) throws ActivityNotFoundException, Exception {
        JSONObject jSONObject = new JSONObject(str);
        String string = jSONObject.isNull(h.ID) ? "" : jSONObject.getString(h.ID);
        String string2 = jSONObject.isNull("summary") ? "" : jSONObject.getString("summary");
        String string3 = jSONObject.isNull("location") ? "" : jSONObject.getString("location");
        String string4 = jSONObject.isNull(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION) ? "" : jSONObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
        String string5 = jSONObject.isNull(h.EVENT_START) ? "" : jSONObject.getString(h.EVENT_START);
        String string6 = jSONObject.isNull("end") ? "" : jSONObject.getString("end");
        String string7 = jSONObject.isNull("status") ? "" : jSONObject.getString("status");
        String string8 = jSONObject.isNull(EVENT_TRANSPARENCY) ? "" : jSONObject.getString(EVENT_TRANSPARENCY);
        String string9 = jSONObject.isNull(EVENT_REMINDER) ? "" : jSONObject.getString(EVENT_REMINDER);
        Recurrence recurrence = new Recurrence(jSONObject.isNull("recurrence") ? "" : jSONObject.getString("recurrence"));
        Intent intent = new Intent("android.intent.action.INSERT");
        intent.setAction("android.intent.action.EDIT");
        intent.setType("vnd.android.cursor.item/event");
        intent.putExtra("calendar_id", string);
        intent.putExtra(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, string2);
        intent.putExtra("eventLocation", string3);
        intent.putExtra(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, string4);
        intent.putExtra("beginTime", a(string5));
        intent.putExtra("endTime", a(string6));
        intent.putExtra("eventStatus", string7);
        intent.putExtra(EVENT_TRANSPARENCY, string8);
        intent.putExtra(EVENT_RECURRENCE, recurrence.getRrule());
        intent.putExtra("exdate", recurrence.a());
        if (string9 != null) {
            try {
                if (!string9.equals("")) {
                    intent.putExtra("event_id", string);
                    intent.putExtra("method", 0);
                    if (string9.startsWith("-")) {
                        intent.putExtra("minutes", string9);
                    } else {
                        intent.putExtra("minutes", a(string9));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        activity.startActivityForResult(intent, 7);
    }

    static long a(String str) throws Exception {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date parse = simpleDateFormat.parse(str);
        System.out.println(parse);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat();
        simpleDateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        return DateFormat.getInstance().parse(simpleDateFormat2.format(parse)).getTime();
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public static class Recurrence {
        String[] a = {"SU", "MO", "TU", "WE", "TH", "FR", "SA"};
        final String b = "frequency";
        final String c = "interval";
        final String d = "expires";
        final String e = "exceptionDates";
        final String f = "daysInWeek";
        final String g = "daysInMonth";
        final String h = "daysInYear";
        final String i = "weeksInMonth";
        final String j = "monthsInYear";
        String k;
        short l;
        String m;
        String[] n;
        short[] o;
        short[] p;
        short[] q;
        short[] r;
        short[] s;
        final JSONObject t;

        public Recurrence(String jsonString) throws NullPointerException, JSONException {
            this.t = new JSONObject(jsonString);
            this.k = this.t.isNull("frequency") ? "" : this.t.getString("frequency");
            this.l = this.t.isNull("interval") ? (short) 0 : Short.parseShort(this.t.getString("interval"));
            this.m = this.t.isNull("expires") ? "" : this.t.getString("expires");
            JSONArray jSONArray = this.t.isNull("exceptionDates") ? null : this.t.getJSONArray("exceptionDates");
            if (jSONArray != null) {
                this.n = new String[jSONArray.length()];
                for (int i = 0; i < this.n.length; i++) {
                    this.n[i] = jSONArray.getString(i);
                }
            }
            this.o = a("daysInWeek");
            this.p = a("daysInMonth");
            this.q = a("daysInYear");
            this.r = a("weeksInMonth");
            this.s = a("monthsInYear");
        }

        final short[] a(String str) throws NullPointerException, JSONException {
            JSONArray jSONArray = this.t.isNull(str) ? null : this.t.getJSONArray(str);
            if (jSONArray == null) {
                return null;
            }
            short[] sArr = new short[jSONArray.length()];
            for (int i = 0; i < sArr.length; i++) {
                sArr[i] = (short) jSONArray.getInt(i);
            }
            return sArr;
        }

        public String getDate(short[] any) {
            String str = "";
            for (int i = 0; i < any.length; i++) {
                if (i == 0) {
                    str = "" + this.a[any[i]];
                } else {
                    str = str + "," + this.a[any[i]];
                }
            }
            return str;
        }

        public String getDate(String[] any) throws Exception {
            String str = "";
            for (int i = 0; i < any.length; i++) {
                if (i == 0) {
                    Date parse = new SimpleDateFormat("yyyy-MM-dd").parse(any[i]);
                    System.out.println("dt: " + parse);
                    str = "" + new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'").format(parse);
                } else {
                    Date parse2 = new SimpleDateFormat("yyyy-MM-dd").parse(any[i]);
                    System.out.println("dt: " + parse2);
                    str = str + "," + new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'").format(parse2);
                }
            }
            return str;
        }

        public String getDate(String any) throws Exception {
            Date parse = new SimpleDateFormat("yyyy-MM-dd").parse(any);
            System.out.println("dt: " + parse);
            return new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'").format(parse);
        }

        String a() throws Exception {
            return this.n != null ? getDate(this.n) : "";
        }

        public String getRrule() {
            StringBuilder sb = new StringBuilder();
            try {
                if (this.k != null && !this.k.equals("")) {
                    sb.append("FREQ=" + this.k + ";");
                }
                if (this.l != 0) {
                    sb.append("INTERVAL=" + ((int) this.l) + ";");
                }
                if (this.m != null && !this.m.equals("")) {
                    sb.append("UNTIL=" + getDate(this.m) + ";");
                }
                if (this.o != null) {
                    sb.append("BYDAY=" + getDate(this.o) + ";");
                }
                if (this.p != null) {
                    sb.append("BYMONTHDAY=" + this.p + ";");
                }
                if (this.q != null) {
                    sb.append("BYYEARDAY=" + this.q + ";");
                }
                if (this.r != null) {
                    sb.append("BYWEEKNO=" + this.r + ";");
                }
                if (this.s != null) {
                    sb.append("BYMONTH=" + this.s + ";");
                }
                Util.a("Rrule: " + sb.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return sb.toString();
        }
    }
}
