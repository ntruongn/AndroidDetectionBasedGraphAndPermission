package com.cguvuuqvlp.zaliiliwdx185920;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import com.cguvuuqvlp.zaliiliwdx185920.AdListener;
import com.cguvuuqvlp.zaliiliwdx185920.XmlParser;
import com.google.android.gms.drive.DriveFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class p implements a<String> {
    private static final String TAG = "PrmVast";
    private static XmlParser a;
    private Context b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public static XmlParser b() {
        return a;
    }

    public p(Context context) {
        this.b = context;
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
    public void a() {
        try {
            new Thread(new j(this.b, this, new ArrayList(), e.VIDEO_AD_URL, 0L, true), "vast").start();
        } catch (NullPointerException e) {
            Log.e("PrmVast", "Video ad", e);
        } catch (Exception e2) {
            Log.e("PrmVast", "Error occurred while fetching Video ad", e2);
        }
    }

    @Override // com.cguvuuqvlp.zaliiliwdx185920.a
    public void a(String str) {
        Log.i("PrmVast", "Video Ad: " + str);
        if (str == null || str.equals("")) {
            Log.w("PrmVast", "Video ad response is null");
        } else {
            a(str, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(String str, boolean z) {
        try {
            n.d(this.b);
            a = new XmlParser(new StringReader(str));
            HashMap<String, Object> hashMap = a.m().get(0).getMediaFiles().get(0);
            String obj = hashMap.get(h.MEDIA_FILE).toString();
            String obj2 = hashMap.get(h.MEDIA_FILE_DELIVERY).toString();
            if (obj != null && !obj.equals("")) {
                if (obj2 != null && obj2.equals("progressive")) {
                    a(str, obj, z);
                } else if (Prm.enableCaching) {
                    b bVar = new b(this.b);
                    if (bVar.a(AdListener.AdType.video, str, obj)) {
                        if (z) {
                            bVar.a(AdListener.AdType.smartwall, str);
                            Prm.sendAdCached(AdListener.AdType.smartwall);
                            bVar.a(true);
                        } else {
                            Prm.sendAdCached(AdListener.AdType.video);
                        }
                    }
                } else {
                    Log.e("PrmVast", "deleviery type streaming " + obj);
                    Intent intent = new Intent(this.b, (Class<?>) VDActivity.class);
                    intent.setAction("play_video");
                    intent.setFlags(DriveFile.MODE_READ_ONLY);
                    intent.addFlags(8388608);
                    intent.addFlags(DriveFile.MODE_WRITE_ONLY);
                    intent.setData(Uri.parse(obj));
                    this.b.startActivity(intent);
                    n.d(this.b);
                }
            } else {
                Log.e("PrmVast", "Ad url is invalid: " + obj);
            }
        } catch (XmlParser.InvalidVastXML e) {
        } catch (XmlParser.VastException e2) {
            Log.e("PrmVast", e2.getMessage());
            Prm.validateStatusCode(e2.getCode(), e2.getMessage());
        } catch (XmlPullParserException e3) {
            e3.printStackTrace();
        } catch (Exception e4) {
            e4.printStackTrace();
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    private void a(String str, String str2, boolean z) {
        try {
            String externalStorageState = Environment.getExternalStorageState();
            if (!Boolean.valueOf(externalStorageState.equals("mounted") && !externalStorageState.equals("mounted_ro")).booleanValue()) {
                String str3 = "SD Card  is not available for caching video. SD Card storage state: " + externalStorageState;
                Log.e("PrmVast", str3);
                Prm.sendAdError(str3);
            } else {
                AnonymousClass1 anonymousClass1 = new AnonymousClass1(str, z, str2);
                if (Util.p(this.b)) {
                    anonymousClass1.a();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.cguvuuqvlp.zaliiliwdx185920.p$1, reason: invalid class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public class AnonymousClass1 implements a<String> {
        String a = "";
        final /* synthetic */ String b;
        final /* synthetic */ boolean c;
        final /* synthetic */ String d;

        AnonymousClass1(String str, boolean z, String str2) {
            this.b = str;
            this.c = z;
            this.d = str2;
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.a
        public void a(String str) {
            Util.a("Video file: " + str);
            if (str != null) {
                try {
                    if (!str.equals("")) {
                        if (Prm.enableCaching) {
                            b bVar = new b(p.this.b);
                            if (bVar.a(AdListener.AdType.video, this.b, str)) {
                                if (this.c) {
                                    bVar.a(AdListener.AdType.smartwall, this.b);
                                    Prm.sendAdCached(AdListener.AdType.smartwall);
                                    bVar.a(true);
                                } else {
                                    Prm.sendAdCached(AdListener.AdType.video);
                                }
                            } else if (Prm.adListener != null) {
                                Prm.sendAdError("Video ad not cached.");
                            }
                        } else {
                            Intent intent = new Intent(p.this.b, (Class<?>) VDActivity.class);
                            intent.setAction("play_video");
                            intent.setFlags(DriveFile.MODE_READ_ONLY);
                            intent.addFlags(8388608);
                            intent.addFlags(DriveFile.MODE_WRITE_ONLY);
                            intent.setData(Uri.parse(str));
                            p.this.b.startActivity(intent);
                            n.d(p.this.b);
                        }
                    }
                } catch (Exception e) {
                    Log.e("PrmVast", "Error occured while download video", e);
                    return;
                }
            }
            Log.e("PrmVast", "Not able to download video");
        }

        @Override // com.cguvuuqvlp.zaliiliwdx185920.a
        public void a() {
            try {
                File file = new File(Environment.getExternalStorageDirectory(), "ap_video");
                if (file.exists() && file.isDirectory()) {
                    VU.a(file);
                    file.mkdirs();
                    this.a = file.getAbsolutePath();
                } else if (file.mkdirs()) {
                    this.a = file.getAbsolutePath();
                }
                new Thread(new Runnable() { // from class: com.cguvuuqvlp.zaliiliwdx185920.p.1.1
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            try {
                                URLConnection openConnection = new URL(AnonymousClass1.this.d).openConnection();
                                openConnection.setConnectTimeout(7000);
                                openConnection.setReadTimeout(7000);
                                openConnection.connect();
                                Log.i("PrmVast", "Content-length: " + openConnection.getContentLength());
                                InputStream inputStream = openConnection.getInputStream();
                                File file2 = new File(AnonymousClass1.this.a, "ad_video.mp4");
                                try {
                                    if (file2.exists()) {
                                        file2.delete();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                                byte[] bArr = new byte[1024];
                                while (true) {
                                    int read = inputStream.read(bArr);
                                    if (read > 0) {
                                        fileOutputStream.write(bArr, 0, read);
                                    } else {
                                        fileOutputStream.close();
                                        AnonymousClass1.this.a(file2.getAbsolutePath());
                                        return;
                                    }
                                }
                            } catch (MalformedURLException e2) {
                                e2.printStackTrace();
                                AnonymousClass1.this.a((String) null);
                            }
                        } catch (SocketTimeoutException e3) {
                            e3.printStackTrace();
                            AnonymousClass1.this.a((String) null);
                        } catch (IOException e4) {
                            e4.printStackTrace();
                            AnonymousClass1.this.a((String) null);
                        }
                    }
                }, "dwn_video").start();
            } catch (Exception e) {
                e.printStackTrace();
            } catch (Throwable th) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a(Context context) {
        boolean z = true;
        try {
            if (!(context.checkCallingOrSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0)) {
                Log.e(e.TAG, "Required permission WRITE_EXTERNAL_STORAGE not found in Manifest. Please add.");
                Prm.sendIntegrationError("Required permission WRITE_EXTERNAL_STORAGE not found in Manifest. Please add.");
                z = false;
            }
            if (!z) {
                new l(context, 110);
                return z;
            }
            return z;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(String str, String str2) {
        try {
            a = new XmlParser(new StringReader(str));
            Log.i("PrmVast", "Showing ad from caching; " + str2);
            Intent intent = new Intent(this.b, (Class<?>) VDActivity.class);
            intent.setAction("play_video");
            intent.setFlags(DriveFile.MODE_READ_ONLY);
            intent.addFlags(8388608);
            intent.addFlags(DriveFile.MODE_WRITE_ONLY);
            intent.setData(Uri.parse(str2));
            this.b.startActivity(intent);
            n.d(this.b);
        } catch (Throwable th) {
            Log.e("PrmVast", "Error occurred while showing video from cache", th);
        }
    }
}
