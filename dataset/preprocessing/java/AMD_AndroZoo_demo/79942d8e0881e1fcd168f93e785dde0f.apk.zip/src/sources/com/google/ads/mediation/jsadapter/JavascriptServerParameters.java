package com.google.ads.mediation.jsadapter;

import com.cguvuuqvlp.zaliiliwdx185920.e;
import com.google.ads.mediation.MediationServerParameters;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public class JavascriptServerParameters extends MediationServerParameters {

    @MediationServerParameters.Parameter(name = "adxtym_height", required = e.isDebugMode)
    public Integer height;

    @MediationServerParameters.Parameter(name = "adxtym_html", required = true)
    public String htmlScript;

    @MediationServerParameters.Parameter(name = "adxtym_passback_url", required = e.isDebugMode)
    public String passBackUrl;

    @MediationServerParameters.Parameter(name = "adxtym_width", required = e.isDebugMode)
    public Integer width;
}
