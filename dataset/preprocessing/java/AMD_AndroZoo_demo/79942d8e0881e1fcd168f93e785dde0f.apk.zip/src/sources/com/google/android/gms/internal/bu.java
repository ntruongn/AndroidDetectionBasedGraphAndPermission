package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.bz;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class bu {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
    public interface a {
        void a(cj cjVar);
    }

    public static cm a(Context context, bz.a aVar, h hVar, cw cwVar, bb bbVar, a aVar2) {
        bv bvVar = new bv(context, aVar, hVar, cwVar, bbVar, aVar2);
        bvVar.start();
        return bvVar;
    }
}
