package com.google.android.gms.common;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class Scopes {
    public static final String APP_STATE = "https://www.googleapis.com/auth/appstate";
    public static final String DRIVE_FILE = "https://www.googleapis.com/auth/drive.file";
    public static final String GAMES = "https://www.googleapis.com/auth/games";
    public static final String PLUS_LOGIN = "https://www.googleapis.com/auth/plus.login";
    public static final String PLUS_ME = "https://www.googleapis.com/auth/plus.me";
    public static final String PROFILE = "profile";

    private Scopes() {
    }
}
