package com.google.android.gms.common.data;

import android.os.Bundle;
import com.google.android.gms.internal.ds;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public abstract class FilteredDataBuffer<T> extends DataBuffer<T> {
    protected final DataBuffer<T> mDataBuffer;

    public FilteredDataBuffer(DataBuffer<T> dataBuffer) {
        super(null);
        ds.d(dataBuffer);
        ds.a(!(dataBuffer instanceof FilteredDataBuffer), "Not possible to have nested FilteredDataBuffers.");
        this.mDataBuffer = dataBuffer;
    }

    @Override // com.google.android.gms.common.data.DataBuffer
    public void close() {
        this.mDataBuffer.close();
    }

    protected abstract int computeRealPosition(int i);

    @Override // com.google.android.gms.common.data.DataBuffer
    public T get(int position) {
        return this.mDataBuffer.get(computeRealPosition(position));
    }

    @Override // com.google.android.gms.common.data.DataBuffer
    public Bundle getMetadata() {
        return this.mDataBuffer.getMetadata();
    }

    @Override // com.google.android.gms.common.data.DataBuffer
    public boolean isClosed() {
        return this.mDataBuffer.isClosed();
    }
}
