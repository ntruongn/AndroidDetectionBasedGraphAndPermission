package com.google.android.gms.internal;

import android.location.Location;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class ar implements aq {
    @Override // com.google.android.gms.internal.aq
    public Location a(long j) {
        return null;
    }

    @Override // com.google.android.gms.internal.aq
    public void init() {
    }
}
