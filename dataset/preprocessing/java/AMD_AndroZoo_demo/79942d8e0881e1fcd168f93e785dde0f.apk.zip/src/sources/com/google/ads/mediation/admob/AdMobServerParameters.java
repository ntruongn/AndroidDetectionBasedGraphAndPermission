package com.google.ads.mediation.admob;

import com.cguvuuqvlp.zaliiliwdx185920.e;
import com.google.ads.mediation.MediationServerParameters;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/79942d8e0881e1fcd168f93e785dde0f.apk/classes.dex */
public final class AdMobServerParameters extends MediationServerParameters {
    public String adJson;

    @MediationServerParameters.Parameter(name = "pubid")
    public String adUnitId;

    @MediationServerParameters.Parameter(name = "mad_hac", required = e.isDebugMode)
    public String allowHouseAds = null;
    public int tagForChildDirectedTreatment = -1;
}
