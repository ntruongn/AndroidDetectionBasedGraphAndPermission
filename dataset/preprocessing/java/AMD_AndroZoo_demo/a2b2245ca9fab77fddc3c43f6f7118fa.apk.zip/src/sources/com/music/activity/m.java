package com.music.activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import com.music.service.MusicService;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class m implements DialogInterface.OnClickListener {
    final /* synthetic */ ListMusicsActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public m(ListMusicsActivity listMusicsActivity) {
        this.a = listMusicsActivity;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        int i2;
        int i3;
        int i4;
        if (i != 0) {
            if (i != 1) {
                if (i == 2) {
                    com.music.c.j.a(this.a, Integer.valueOf((int) R.drawable.warning), "系统提示", "确定要删除?", "确定", "取消", new n(this), null, true);
                    return;
                }
                return;
            }
            this.a.j = false;
            if (this.a.h == null) {
                this.a.h = ProgressDialog.show(this.a, "", "搜索分享软件中，请稍后...", false, true);
            } else {
                this.a.h.setMessage("搜索分享软件中，请稍后...");
                this.a.h.show();
            }
            new Thread(new s(this.a, true)).start();
            new Thread(new o(this.a)).start();
            return;
        }
        i2 = this.a.n;
        if (i2 < ListMusicsActivity.c.size()) {
            i3 = this.a.n;
            com.music.c.a.d = i3;
            this.a.a();
            com.music.c.a.e = false;
            ArrayList arrayList = ListMusicsActivity.c;
            i4 = this.a.n;
            String obj = ((HashMap) arrayList.get(i4)).get("musicPath").toString();
            Intent intent = new Intent("R.id.imgPlay");
            intent.putExtra("musicPath", obj);
            intent.putExtra("isInitMediaPlayer", 1);
            intent.setClass(this.a, MusicService.class);
            this.a.startService(intent);
            ((TabHostActivity) this.a.getParent()).a(0);
        }
    }
}
