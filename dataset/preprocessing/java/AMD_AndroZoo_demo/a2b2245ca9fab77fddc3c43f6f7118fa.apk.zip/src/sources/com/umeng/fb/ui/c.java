package com.umeng.fb.ui;

import android.app.Activity;
import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class c implements View.OnClickListener {
    final /* synthetic */ SendFeedback a;

    private c(SendFeedback sendFeedback) {
        this.a = sendFeedback;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ c(SendFeedback sendFeedback, c cVar) {
        this(sendFeedback);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        this.a.finish();
        if (com.umeng.fb.c.a.b != null) {
            ((Activity) com.umeng.fb.c.a.b).finish();
        }
    }
}
