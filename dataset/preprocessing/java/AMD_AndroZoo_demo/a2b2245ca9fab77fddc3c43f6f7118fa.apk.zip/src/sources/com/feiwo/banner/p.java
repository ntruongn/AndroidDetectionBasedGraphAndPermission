package com.feiwo.banner;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class p implements Runnable {
    private final /* synthetic */ AdBanner a;
    private final /* synthetic */ com.feiwo.banner.c.a b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(m mVar, AdBanner adBanner, com.feiwo.banner.c.a aVar) {
        this.a = adBanner;
        this.b = aVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.a.a(this.b);
    }
}
