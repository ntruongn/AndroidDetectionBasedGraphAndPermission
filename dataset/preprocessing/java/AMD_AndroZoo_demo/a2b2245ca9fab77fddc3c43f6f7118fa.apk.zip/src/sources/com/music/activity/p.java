package com.music.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.ListView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class p extends BroadcastReceiver {
    final /* synthetic */ ListMusicsActivity a;

    private p(ListMusicsActivity listMusicsActivity) {
        this.a = listMusicsActivity;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ p(ListMusicsActivity listMusicsActivity, p pVar) {
        this(listMusicsActivity);
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        ListView listView;
        if (intent.getAction().equals("musicPlayFinish")) {
            System.out.println("播放完，收到了广播了");
            this.a.a();
            this.a.b.notifyDataSetChanged();
            listView = this.a.g;
            listView.setSelection(com.music.c.a.d);
        }
    }
}
