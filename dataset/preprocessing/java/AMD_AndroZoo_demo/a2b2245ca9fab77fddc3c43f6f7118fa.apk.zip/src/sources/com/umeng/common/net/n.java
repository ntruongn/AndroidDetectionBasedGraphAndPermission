package com.umeng.common.net;

import android.util.Log;
import java.io.IOException;
import java.util.Map;
import java.util.Random;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class n implements Runnable {
    private final /* synthetic */ String[] a;
    private final /* synthetic */ boolean b;
    private final /* synthetic */ Map c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public n(String[] strArr, boolean z, Map map) {
        this.a = strArr;
        this.b = z;
        this.c = map;
    }

    @Override // java.lang.Runnable
    public void run() {
        String str;
        String str2;
        String str3;
        HttpResponse execute;
        String str4;
        String str5;
        int nextInt = new Random().nextInt(1000);
        if (this.a == null) {
            str5 = DownloadingService.c;
            Log.i(str5, String.valueOf(nextInt) + "service report: urls is null");
            return;
        }
        for (String str6 : this.a) {
            String a = com.umeng.common.b.b.a();
            String str7 = a.split(" ")[0];
            String str8 = a.split(" ")[1];
            long currentTimeMillis = System.currentTimeMillis();
            StringBuilder sb = new StringBuilder(str6);
            sb.append("&data=" + str7);
            sb.append("&time=" + str8);
            sb.append("&ts=" + currentTimeMillis);
            if (this.b) {
                sb.append("&action_type=1");
            } else {
                sb.append("&action_type=-2");
            }
            if (this.c != null) {
                for (String str9 : this.c.keySet()) {
                    sb.append("&" + str9 + "=" + ((String) this.c.get(str9)));
                }
            }
            try {
                str3 = DownloadingService.c;
                Log.i(str3, String.valueOf(nextInt) + ": service report:\tget: " + sb.toString());
                HttpGet httpGet = new HttpGet(sb.toString());
                BasicHttpParams basicHttpParams = new BasicHttpParams();
                HttpConnectionParams.setConnectionTimeout(basicHttpParams, 10000);
                HttpConnectionParams.setSoTimeout(basicHttpParams, 20000);
                execute = new DefaultHttpClient(basicHttpParams).execute(httpGet);
                str4 = DownloadingService.c;
                Log.i(str4, String.valueOf(nextInt) + ": service report:status code:  " + execute.getStatusLine().getStatusCode());
            } catch (ClientProtocolException e) {
                str2 = DownloadingService.c;
                Log.d(str2, String.valueOf(nextInt) + ": service report:\tClientProtocolException,Failed to send message." + str6, e);
            } catch (IOException e2) {
                str = DownloadingService.c;
                Log.d(str, String.valueOf(nextInt) + ": service report:\tIOException,Failed to send message." + str6, e2);
            }
            if (execute.getStatusLine().getStatusCode() == 200) {
                return;
            }
        }
    }
}
