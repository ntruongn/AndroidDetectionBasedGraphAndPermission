package com.umeng.common.net;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class j extends Handler {
    final /* synthetic */ DownloadingService a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(DownloadingService downloadingService) {
        this.a = downloadingService;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        String str;
        NotificationManager notificationManager;
        String str2;
        Context context;
        Context context2;
        NotificationManager notificationManager2;
        String str3;
        Context context3;
        boolean b;
        String str4;
        String str5;
        NotificationManager notificationManager3;
        Context context4;
        f fVar = (f) message.obj;
        int i = message.arg2;
        try {
            String string = message.getData().getString("filename");
            str2 = DownloadingService.c;
            com.umeng.common.a.c(str2, "Cancel old notification....");
            Notification notification = new Notification(17301634, "下载完成，请点击安装", System.currentTimeMillis());
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.addFlags(268435456);
            intent.setDataAndType(Uri.fromFile(new File(string)), "application/vnd.android.package-archive");
            context = this.a.e;
            PendingIntent activity = PendingIntent.getActivity(context, 0, intent, 134217728);
            context2 = this.a.e;
            notification.setLatestEventInfo(context2, fVar.b, "下载完成，请点击安装", activity);
            notification.flags = 16;
            this.a.d = (NotificationManager) this.a.getSystemService("notification");
            notificationManager2 = this.a.d;
            notificationManager2.notify(i + 1, notification);
            str3 = DownloadingService.c;
            com.umeng.common.a.c(str3, "Show new  notification....");
            context3 = this.a.e;
            b = DownloadingService.b(context3);
            str4 = DownloadingService.c;
            com.umeng.common.a.c(str4, String.format("isAppOnForeground = %1$B", Boolean.valueOf(b)));
            if (b) {
                notificationManager3 = this.a.d;
                notificationManager3.cancel(i + 1);
                context4 = this.a.e;
                context4.startActivity(intent);
            }
            str5 = DownloadingService.c;
            com.umeng.common.a.a(str5, String.format("%1$10s downloaded. Saved to: %2$s", fVar.b, string));
        } catch (Exception e) {
            str = DownloadingService.c;
            com.umeng.common.a.b(str, "can not install. " + e.getMessage());
            notificationManager = this.a.d;
            notificationManager.cancel(i + 1);
        }
    }
}
