package com.umeng.common.net;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.widget.RemoteViews;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class k implements a {
    final /* synthetic */ DownloadingService a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(DownloadingService downloadingService) {
        this.a = downloadingService;
    }

    @Override // com.umeng.common.net.a
    public void a(int i) {
        Map map;
        Map map2;
        Notification a;
        NotificationManager notificationManager;
        int i2 = 0;
        map = DownloadingService.i;
        if (map.containsKey(Integer.valueOf(i))) {
            map2 = DownloadingService.i;
            d dVar = (d) map2.get(Integer.valueOf(i));
            long[] jArr = dVar.f;
            if (jArr != null && jArr[1] > 0 && (i2 = (int) ((((float) jArr[0]) / ((float) jArr[1])) * 100.0f)) > 100) {
                i2 = 99;
            }
            a = this.a.a(dVar.e, i, i2);
            dVar.b = a;
            notificationManager = this.a.d;
            notificationManager.notify(i, a);
        }
    }

    @Override // com.umeng.common.net.a
    public void a(int i, int i2) {
        Map map;
        Map map2;
        Context context;
        Context context2;
        NotificationManager notificationManager;
        String str;
        map = DownloadingService.i;
        if (map.containsKey(Integer.valueOf(i))) {
            map2 = DownloadingService.i;
            d dVar = (d) map2.get(Integer.valueOf(i));
            f fVar = dVar.e;
            Notification notification = dVar.b;
            RemoteViews remoteViews = notification.contentView;
            context = this.a.e;
            remoteViews.setProgressBar(com.umeng.common.a.a.c(context), 100, i2, false);
            RemoteViews remoteViews2 = notification.contentView;
            context2 = this.a.e;
            remoteViews2.setTextViewText(com.umeng.common.a.a.b(context2), String.valueOf(String.valueOf(i2)) + "%");
            notificationManager = this.a.d;
            notificationManager.notify(i, notification);
            str = DownloadingService.c;
            com.umeng.common.a.c(str, String.format("%3$10s Notification: mNotificationId = %1$15s\t|\tprogress = %2$15s", Integer.valueOf(i), Integer.valueOf(i2), fVar.b));
        }
    }

    @Override // com.umeng.common.net.a
    public void a(int i, Exception exc) {
        Map map;
        Map map2;
        Context context;
        NotificationManager notificationManager;
        map = DownloadingService.i;
        if (map.containsKey(Integer.valueOf(i))) {
            map2 = DownloadingService.i;
            d dVar = (d) map2.get(Integer.valueOf(i));
            f fVar = dVar.e;
            Notification notification = dVar.b;
            RemoteViews remoteViews = notification.contentView;
            context = this.a.e;
            remoteViews.setTextViewText(com.umeng.common.a.a.d(context), String.valueOf(fVar.b) + " 下载失败，请检查网络。");
            notificationManager = this.a.d;
            notificationManager.notify(i, notification);
            this.a.a(i);
        }
    }

    @Override // com.umeng.common.net.a
    public void a(int i, String str) {
        Map map;
        Map map2;
        Context context;
        Context context2;
        Handler handler;
        Map map3;
        Map map4;
        map = DownloadingService.i;
        if (map.containsKey(Integer.valueOf(i))) {
            map2 = DownloadingService.i;
            d dVar = (d) map2.get(Integer.valueOf(i));
            if (dVar != null) {
                f fVar = dVar.e;
                RemoteViews remoteViews = dVar.b.contentView;
                context = this.a.e;
                remoteViews.setTextViewText(com.umeng.common.a.a.b(context), String.valueOf(String.valueOf(100)) + "%");
                context2 = this.a.e;
                g.a(context2).a(fVar.a, fVar.c, 100);
                Bundle bundle = new Bundle();
                bundle.putString("filename", str);
                Message obtain = Message.obtain();
                obtain.what = 5;
                obtain.arg1 = 1;
                obtain.obj = fVar;
                obtain.arg2 = i;
                obtain.setData(bundle);
                handler = this.a.f;
                handler.sendMessage(obtain);
                Message obtain2 = Message.obtain();
                obtain2.what = 5;
                obtain2.arg1 = 1;
                obtain2.setData(bundle);
                try {
                    map3 = DownloadingService.h;
                    if (map3.get(fVar) != null) {
                        map4 = DownloadingService.h;
                        ((Messenger) map4.get(fVar)).send(obtain2);
                    }
                    this.a.a(i);
                } catch (RemoteException e) {
                    this.a.a(i);
                }
            }
        }
    }
}
