package com.umeng.common;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class c {
    private static c b;
    private Context c;
    private static final String a = c.class.getName();
    private static Class d = null;
    private static Class e = null;
    private static Class f = null;
    private static Class g = null;
    private static Class h = null;
    private static Class i = null;
    private static Class j = null;

    private c(Context context) {
        this.c = context.getApplicationContext();
        try {
            e = Class.forName(String.valueOf(this.c.getPackageName()) + ".R$drawable");
        } catch (ClassNotFoundException e2) {
            a.b(a, e2.getMessage());
        }
        try {
            f = Class.forName(String.valueOf(this.c.getPackageName()) + ".R$layout");
        } catch (ClassNotFoundException e3) {
            a.b(a, e3.getMessage());
        }
        try {
            d = Class.forName(String.valueOf(this.c.getPackageName()) + ".R$id");
        } catch (ClassNotFoundException e4) {
            a.b(a, e4.getMessage());
        }
        try {
            g = Class.forName(String.valueOf(this.c.getPackageName()) + ".R$anim");
        } catch (ClassNotFoundException e5) {
            a.b(a, e5.getMessage());
        }
        try {
            h = Class.forName(String.valueOf(this.c.getPackageName()) + ".R$style");
        } catch (ClassNotFoundException e6) {
            a.b(a, e6.getMessage());
        }
        try {
            i = Class.forName(String.valueOf(this.c.getPackageName()) + ".R$string");
        } catch (ClassNotFoundException e7) {
            a.b(a, e7.getMessage());
        }
        try {
            j = Class.forName(String.valueOf(this.c.getPackageName()) + ".R$array");
        } catch (ClassNotFoundException e8) {
            a.b(a, e8.getMessage());
        }
    }

    private int a(Class cls, String str) {
        if (cls == null) {
            a.b(a, "getRes(null," + str + ")");
            throw new IllegalArgumentException("ResClass is not initialized.");
        }
        try {
            return cls.getField(str).getInt(str);
        } catch (Exception e2) {
            a.b(a, "getRes(" + cls.getName() + ", " + str + ")");
            a.b(a, "Error getting resource. Make sure you have copied all resources (res/) from SDK to your project. ");
            a.b(a, e2.getMessage());
            return -1;
        }
    }

    public static c a(Context context) {
        if (b == null) {
            b = new c(context);
        }
        return b;
    }

    public int a(String str) {
        return a(d, str);
    }

    public int b(String str) {
        return a(e, str);
    }

    public int c(String str) {
        return a(f, str);
    }

    public int d(String str) {
        return a(i, str);
    }

    public int e(String str) {
        return a(j, str);
    }
}
