package com.umeng.fb.b;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class b {
    public static int a(Context context) {
        return com.umeng.common.c.a(context).b("umeng_fb_point_new");
    }

    public static int b(Context context) {
        return com.umeng.common.c.a(context).b("umeng_fb_dev_bubble");
    }

    public static int c(Context context) {
        return com.umeng.common.c.a(context).b("umeng_fb_user_bubble");
    }
}
