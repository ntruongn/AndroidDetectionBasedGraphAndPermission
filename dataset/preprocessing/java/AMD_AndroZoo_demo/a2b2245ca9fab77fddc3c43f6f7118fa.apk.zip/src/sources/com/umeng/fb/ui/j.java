package com.umeng.fb.ui;

import android.widget.ImageView;
import android.widget.TextView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class j {
    ImageView a;
    TextView b;
    TextView c;
    TextView d;
    final /* synthetic */ i e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(i iVar) {
        this.e = iVar;
    }
}
