package com.feiwothree.coverscreen.a;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class n extends Thread {
    Queue a;
    C0001a b;
    String c;
    private /* synthetic */ C0009i h;
    private long e = 0;
    private long f = 0;
    private int g = 0;
    long d = 0;

    /* JADX INFO: Access modifiers changed from: package-private */
    public n(C0009i c0009i, C0001a c0001a, m mVar) {
        this.h = c0009i;
        this.b = c0001a;
        r.a();
        this.c = r.a(c0009i.d, l.b, c0001a.d());
        this.a = new ConcurrentLinkedQueue();
        a(mVar);
    }

    private void a(int i) {
        new StringBuilder("[DownloadCallback] doProgress, progress: ").append(i);
        this.h.e.post(new q(this, i));
        Iterator it = new ArrayList(this.a).iterator();
        while (it.hasNext()) {
            it.next();
            C0001a c0001a = this.b;
            String str = this.c;
        }
    }

    private void a(boolean z) {
        new StringBuilder("[DownloadCallback] doComplete, success: ").append(z).append(", url: ").append(this.b.d());
        this.h.e.post(new p(this, z));
        Iterator it = new ArrayList(this.a).iterator();
        while (it.hasNext()) {
            ((m) it.next()).a(this.b, this.c, z);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(m mVar) {
        if (mVar != null) {
            this.a.add(mVar);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:90:0x01df A[Catch: Exception -> 0x013b, TRY_ENTER, TryCatch #18 {Exception -> 0x013b, blocks: (B:3:0x000b, B:4:0x002e, B:8:0x0034, B:28:0x010d, B:38:0x0137, B:56:0x016a, B:61:0x016f, B:59:0x0174, B:81:0x01a9, B:77:0x01ae, B:75:0x01b3, B:98:0x01d5, B:94:0x01da, B:90:0x01df, B:91:0x01e2, B:115:0x01c1, B:111:0x01c6, B:109:0x01cb, B:6:0x0118), top: B:2:0x000b }] */
    /* JADX WARN: Removed duplicated region for block: B:92:? A[Catch: Exception -> 0x013b, SYNTHETIC, TRY_LEAVE, TryCatch #18 {Exception -> 0x013b, blocks: (B:3:0x000b, B:4:0x002e, B:8:0x0034, B:28:0x010d, B:38:0x0137, B:56:0x016a, B:61:0x016f, B:59:0x0174, B:81:0x01a9, B:77:0x01ae, B:75:0x01b3, B:98:0x01d5, B:94:0x01da, B:90:0x01df, B:91:0x01e2, B:115:0x01c1, B:111:0x01c6, B:109:0x01cb, B:6:0x0118), top: B:2:0x000b }] */
    /* JADX WARN: Removed duplicated region for block: B:93:0x01da A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:97:0x01d5 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    @Override // java.lang.Thread, java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 564
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.feiwothree.coverscreen.a.n.run():void");
    }
}
