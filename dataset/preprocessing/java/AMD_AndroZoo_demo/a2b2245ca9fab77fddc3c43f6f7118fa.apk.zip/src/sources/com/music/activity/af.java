package com.music.activity;

import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import com.feiwothree.coverscreen.AdComponent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class af extends Handler {
    final /* synthetic */ ShowOneBanddangListActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public af(ShowOneBanddangListActivity showOneBanddangListActivity) {
        this.a = showOneBanddangListActivity;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        TextView textView;
        TextView textView2;
        String str;
        String str2;
        switch (message.what) {
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                this.a.h = true;
                String str3 = (String) message.obj;
                if (str3 != null) {
                    str = this.a.j;
                    if (str != null) {
                        ShowOneBanddangListActivity showOneBanddangListActivity = this.a;
                        str2 = this.a.j;
                        com.music.c.j.a(showOneBanddangListActivity, false, 0, R.drawable.f032, String.valueOf(str2) + "信息获取失败，" + str3);
                    } else {
                        com.music.c.j.a(this.a, false, 0, R.drawable.f032, "信息获取失败，" + str3);
                    }
                } else {
                    com.music.c.j.a(this.a, false, 0, R.drawable.f032, "榜单信息获取失败，请稍后再试。");
                }
                textView2 = this.a.e;
                textView2.setVisibility(0);
                return;
            case AdComponent.FAIL_SHOW_AD /* 5 */:
            case 6:
            default:
                return;
            case 7:
                this.a.b();
                return;
            case 8:
                textView = this.a.e;
                textView.setVisibility(0);
                return;
        }
    }
}
