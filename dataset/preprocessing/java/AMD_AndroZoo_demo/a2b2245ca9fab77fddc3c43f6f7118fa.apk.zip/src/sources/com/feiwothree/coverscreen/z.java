package com.feiwothree.coverscreen;

import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;
import com.feiwothree.coverscreen.a.C0010j;
import com.feiwothree.coverscreen.a.G;
import java.util.List;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class z extends r implements GestureDetector.OnGestureListener {
    GestureDetector c;
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;
    private int i;
    private int j;
    private int k;
    private int l;
    private int m;
    private int n;
    private int o;
    private int p;
    private int q;
    private LinearLayout r;
    private ViewFlipper s;
    private int t;

    public z(SA sa, List list, int i) {
        super(sa, list);
        this.d = 1;
        this.e = 32;
        this.f = this.e / 2;
        this.g = 275;
        this.h = 180;
        this.i = 5;
        this.j = 50;
        this.k = 50;
        this.l = 14;
        this.m = 96;
        this.n = 36;
        this.o = this.g + this.e + (this.d << 1);
        this.p = this.h + this.e + (this.d << 1) + this.i + this.k;
        this.q = 12;
        this.t = 0;
        this.t = i;
        this.c = new GestureDetector(sa, this);
        a();
    }

    @Override // com.feiwothree.coverscreen.r
    public final int a(View view, C0010j c0010j) {
        this.s.removeView(view);
        this.t = super.a(view, c0010j);
        return this.t;
    }

    @Override // com.feiwothree.coverscreen.r
    protected final void b() {
        this.d = G.a(getContext(), this.d);
        this.e = G.a(getContext(), this.e);
        this.o = G.a(getContext(), this.o);
        this.p = G.a(getContext(), this.p);
        this.f = G.a(getContext(), this.f);
        this.g = G.a(getContext(), this.g);
        this.h = G.a(getContext(), this.h);
        this.i = G.a(getContext(), this.i);
        this.j = G.a(getContext(), this.j);
        this.k = G.a(getContext(), this.k);
        this.n = G.a(getContext(), this.n);
        this.m = G.a(getContext(), this.m);
        this.q = G.a(getContext(), this.q);
        Rect rect = new Rect();
        this.a.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        new StringBuilder("initParam: [imageWidth: ").append(this.g).append(",imageHeight: ").append(this.h).append(",outContainerWidth: ").append(this.o).append(",outContainerHeight: ").append(this.p).append("]").append(rect);
        int width = rect.width() - this.o;
        new StringBuilder("extraWidth: ").append(width).append(",frame.width: ").append(rect.width()).append(",outContainerWidth: ").append(this.o);
        if (width < 0 || Math.abs(width) > 10) {
            double height = ((double) (rect.height() - 10)) / this.p;
            double width2 = ((double) (rect.width() - 10)) / this.o;
            if (height <= width2) {
                width2 = height;
            }
            double d = width2 <= 1.5d ? width2 : 1.5d;
            this.d = (int) (this.d * d);
            this.e = (int) (this.e * d);
            this.o = (int) (this.o * d);
            this.p = (int) (this.p * d);
            this.f = (int) (this.f * d);
            this.g = (int) (this.g * d);
            this.h = (int) (this.h * d);
            this.i = (int) (this.i * d);
            this.j = (int) (this.j * d);
            this.k = (int) (this.k * d);
            this.n = (int) (this.n * d);
            this.m = (int) (this.m * d);
            this.l = (int) (this.l * d);
            this.q = (int) (this.q * d);
            new StringBuilder("initParam: [rate: ").append(d).append(",imageWidth: ").append(this.g).append(",imageHeight: ").append(this.h).append(",outContainerWidth: ").append(this.o).append(",outContainerHeight: ").append(this.p).append("]");
        }
    }

    @Override // com.feiwothree.coverscreen.r
    protected final void c() {
        float a = G.a(getContext(), 5.0f);
        ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(new float[]{a, a, a, a, a, a, a, a}, null, null));
        shapeDrawable.setPadding(this.d, this.d, this.d, this.d);
        shapeDrawable.getPaint().setColor(-1);
        RelativeLayout relativeLayout = new RelativeLayout(getContext());
        relativeLayout.setLayoutParams(new LinearLayout.LayoutParams(this.o, this.p));
        addView(relativeLayout);
        LinearLayout linearLayout = new LinearLayout(getContext());
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.setMargins(this.f, this.f, this.f, this.f);
        layoutParams.addRule(13, -1);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundDrawable(shapeDrawable);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        relativeLayout.addView(linearLayout);
        ImageView imageView = new ImageView(getContext());
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(10, -1);
        layoutParams2.addRule(11, -1);
        int i = this.e;
        layoutParams2.width = i;
        layoutParams2.height = i;
        imageView.setLayoutParams(layoutParams2);
        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        getContext();
        imageView.setImageDrawable(G.a(com.feiwothree.coverscreen.a.l.c));
        relativeLayout.addView(imageView);
        imageView.setOnClickListener(new s(this));
        this.s = new ViewFlipper(getContext());
        this.s.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        for (C0010j c0010j : this.b) {
            LinearLayout linearLayout2 = new LinearLayout(getContext());
            linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            linearLayout2.setOrientation(1);
            ImageView imageView2 = new ImageView(getContext());
            imageView2.setLayoutParams(new LinearLayout.LayoutParams(this.g, this.h));
            imageView2.setScaleType(ImageView.ScaleType.FIT_XY);
            a(imageView2, c0010j.b(), true);
            linearLayout2.addView(imageView2);
            LinearLayout linearLayout3 = new LinearLayout(getContext());
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams3.topMargin = this.i;
            linearLayout3.setLayoutParams(layoutParams3);
            linearLayout3.setOrientation(0);
            linearLayout2.addView(linearLayout3);
            ImageView imageView3 = new ImageView(getContext());
            imageView3.setLayoutParams(new LinearLayout.LayoutParams(this.j, this.k));
            imageView3.setScaleType(ImageView.ScaleType.FIT_XY);
            a(imageView3, c0010j.j(), false);
            linearLayout3.addView(imageView3);
            LinearLayout linearLayout4 = new LinearLayout(getContext());
            LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(0, -1);
            layoutParams4.leftMargin = G.a(getContext(), 4.0f);
            layoutParams4.weight = 1.0f;
            linearLayout4.setLayoutParams(layoutParams4);
            linearLayout4.setGravity(16);
            linearLayout4.setOrientation(1);
            linearLayout3.addView(linearLayout4);
            TextView textView = new TextView(getContext());
            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-2, -2);
            if ("download".equals(c0010j.h())) {
                textView.setText(c0010j.d());
            } else {
                textView.setText(c0010j.c());
            }
            textView.setTextColor(-16777216);
            textView.setTextSize(this.l);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            textView.setLayoutParams(layoutParams5);
            linearLayout4.addView(textView);
            if ("download".equals(c0010j.h())) {
                TextView textView2 = new TextView(getContext());
                LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, -2);
                layoutParams6.topMargin = G.a(getContext(), 2.0f);
                textView2.setText(c0010j.l());
                textView2.setTextColor(-16777216);
                textView2.setTextSize((float) (this.l - 2));
                textView2.setLayoutParams(layoutParams6);
                linearLayout4.addView(textView2);
            }
            ImageView imageView4 = new ImageView(getContext());
            LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(this.m, this.n);
            layoutParams7.gravity = 16;
            imageView4.setLayoutParams(layoutParams7);
            imageView4.setScaleType(ImageView.ScaleType.FIT_XY);
            if ("download".equals(c0010j.h())) {
                getContext();
                imageView4.setImageDrawable(G.a(com.feiwothree.coverscreen.a.l.d));
            } else {
                getContext();
                imageView4.setImageDrawable(G.a(com.feiwothree.coverscreen.a.l.e));
            }
            linearLayout3.addView(imageView4);
            this.s.addView(linearLayout2);
        }
        linearLayout.addView(this.s);
        this.r = new LinearLayout(getContext());
        RelativeLayout.LayoutParams layoutParams8 = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams8.addRule(12, -1);
        layoutParams8.addRule(14, -1);
        layoutParams8.bottomMargin = this.e;
        this.r.setVisibility(8);
        this.r.setLayoutParams(layoutParams8);
        this.r.setGravity(1);
        relativeLayout.addView(this.r);
        if (this.t < 0 || this.t >= this.b.size()) {
            this.t = 0;
        }
        this.s.setDisplayedChild(this.t);
        CoverAdComponent.getInstance().a(this.t + 1);
        a(this.t);
        A a2 = new A(this, linearLayout);
        Animation scaleAnimation = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setDuration(1000L);
        scaleAnimation.setAnimationListener(new w(this, a2, relativeLayout));
        relativeLayout.startAnimation(scaleAnimation);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.feiwothree.coverscreen.r
    public final void e() {
        TranslateAnimation translateAnimation = new TranslateAnimation(1, 1.0f, 1, 0.0f, 1, 0.0f, 1, 0.0f);
        translateAnimation.setDuration(500L);
        TranslateAnimation translateAnimation2 = new TranslateAnimation(1, 0.0f, 1, -1.0f, 1, 0.0f, 1, 0.0f);
        translateAnimation2.setDuration(500L);
        this.s.setInAnimation(translateAnimation);
        this.s.setOutAnimation(translateAnimation2);
        this.s.showNext();
        this.t++;
        if (this.t >= this.b.size()) {
            this.t = 0;
        }
        CoverAdComponent.getInstance().a(this.t + 1);
        a(this.t);
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public final boolean onDown(MotionEvent motionEvent) {
        f();
        return false;
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public final boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
        if (this.b.size() <= 1) {
            return true;
        }
        if (motionEvent2.getX() - motionEvent.getX() > 120.0f) {
            TranslateAnimation translateAnimation = new TranslateAnimation(1, -1.0f, 1, 0.0f, 1, 0.0f, 1, 0.0f);
            translateAnimation.setDuration(500L);
            TranslateAnimation translateAnimation2 = new TranslateAnimation(1, 0.0f, 1, 1.0f, 1, 0.0f, 1, 0.0f);
            translateAnimation2.setDuration(500L);
            this.s.setInAnimation(translateAnimation);
            this.s.setOutAnimation(translateAnimation2);
            this.s.showPrevious();
            this.t--;
            if (this.t < 0) {
                this.t = this.b.size() - 1;
            }
            CoverAdComponent.getInstance().a(this.t + 1);
            a(this.t);
        } else if (motionEvent2.getX() - motionEvent.getX() < -120.0f) {
            e();
        }
        f();
        return true;
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public final void onLongPress(MotionEvent motionEvent) {
        f();
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public final boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
        f();
        return false;
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public final void onShowPress(MotionEvent motionEvent) {
        f();
    }

    @Override // android.view.GestureDetector.OnGestureListener
    public final boolean onSingleTapUp(MotionEvent motionEvent) {
        f();
        if (this.t >= this.b.size()) {
            e();
        } else {
            b(this.s.getChildAt(this.t), (C0010j) this.b.get(this.t));
        }
        return true;
    }
}
