package com.umeng.common.a;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class a {
    public static int a(Context context) {
        return com.umeng.common.c.a(context).a("umeng_common_description");
    }

    public static int b(Context context) {
        return com.umeng.common.c.a(context).a("umeng_common_progress_text");
    }

    public static int c(Context context) {
        return com.umeng.common.c.a(context).a("umeng_common_progress_bar");
    }

    public static int d(Context context) {
        return com.umeng.common.c.a(context).a("umeng_common_title");
    }

    public static int e(Context context) {
        return com.umeng.common.c.a(context).a("umeng_common_appIcon");
    }

    public static int f(Context context) {
        return com.umeng.common.c.a(context).a("umeng_common_rich_notification_continue");
    }

    public static int g(Context context) {
        return com.umeng.common.c.a(context).a("umeng_common_rich_notification_cancel");
    }
}
