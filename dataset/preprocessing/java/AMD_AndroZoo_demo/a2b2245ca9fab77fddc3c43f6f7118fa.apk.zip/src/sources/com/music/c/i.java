package com.music.c;

import android.content.Context;
import android.media.MediaScannerConnection;
import android.net.Uri;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class i implements MediaScannerConnection.MediaScannerConnectionClient {
    private MediaScannerConnection a;
    private String b = null;
    private String c = null;
    private String[] d = null;

    public i(Context context) {
        this.a = null;
        if (this.a == null) {
            this.a = new MediaScannerConnection(context, this);
        }
    }

    public void a(String str, String str2) {
        this.b = str;
        this.c = str2;
        this.a.connect();
    }

    @Override // android.media.MediaScannerConnection.MediaScannerConnectionClient
    public void onMediaScannerConnected() {
        System.out.println("连接了...");
        if (this.b != null) {
            this.a.scanFile(this.b, this.c);
        }
        if (this.d != null) {
            for (String str : this.d) {
                this.a.scanFile(str, this.c);
            }
        }
        this.b = null;
        this.c = null;
        this.d = null;
        System.out.println("扫描完毕...");
    }

    @Override // android.media.MediaScannerConnection.OnScanCompletedListener
    public void onScanCompleted(String str, Uri uri) {
        this.a.disconnect();
        System.out.println("断开连接...");
    }
}
