package com.umeng.common.net;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class b extends Thread {
    final /* synthetic */ DownloadingService a;
    private Context b;
    private String c;
    private int d;
    private long e;
    private long f;
    private int g = -1;
    private int h;
    private a i;
    private f j;

    public b(DownloadingService downloadingService, Context context, f fVar, int i, int i2, a aVar) {
        String str;
        Map map;
        Map map2;
        this.a = downloadingService;
        this.d = 0;
        this.e = -1L;
        this.f = -1L;
        try {
            this.b = context;
            this.j = fVar;
            this.d = i2;
            map = DownloadingService.i;
            if (map.containsKey(Integer.valueOf(i))) {
                map2 = DownloadingService.i;
                long[] jArr = ((d) map2.get(Integer.valueOf(i))).f;
                if (jArr != null && jArr.length > 1) {
                    this.e = jArr[0];
                    this.f = jArr[1];
                }
            }
            this.i = aVar;
            this.h = i;
            if (com.umeng.common.b.b()) {
                this.c = Environment.getExternalStorageDirectory().getCanonicalPath();
                new File(this.c).mkdirs();
            } else {
                this.c = this.b.getFilesDir().getAbsolutePath();
            }
            this.c = String.valueOf(this.c) + "/download/.um/apk";
            new File(this.c).mkdirs();
        } catch (Exception e) {
            str = DownloadingService.c;
            com.umeng.common.a.c(str, e.getMessage(), e);
            this.i.a(this.h, e);
        }
    }

    private void a(Exception exc) {
        String str;
        str = DownloadingService.c;
        com.umeng.common.a.b(str, "can not install. " + exc.getMessage());
        if (this.i != null) {
            this.i.a(this.h, exc);
        }
        this.a.a(this.j, this.e, this.f, this.d);
    }

    /* JADX WARN: Removed duplicated region for block: B:112:0x042f A[Catch: all -> 0x03e9, InterruptedException -> 0x0442, TryCatch #28 {InterruptedException -> 0x0442, blocks: (B:110:0x0429, B:112:0x042f, B:114:0x043c, B:116:0x0450, B:117:0x0455), top: B:109:0x0429, outer: #32 }] */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0455 A[Catch: all -> 0x03e9, InterruptedException -> 0x0442, TRY_LEAVE, TryCatch #28 {InterruptedException -> 0x0442, blocks: (B:110:0x0429, B:112:0x042f, B:114:0x043c, B:116:0x0450, B:117:0x0455), top: B:109:0x0429, outer: #32 }] */
    /* JADX WARN: Removed duplicated region for block: B:124:0x03f3 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:129:0x03ee A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x04eb A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:30:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x04e6 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0269 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:74:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0264 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:80:0x0443 -> B:59:0x0262). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void a(boolean r14) {
        /*
            Method dump skipped, instructions count: 1413
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.umeng.common.net.b.a(boolean):void");
    }

    public void a(int i) {
        this.g = i;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        Map map;
        this.d = 0;
        try {
            if (this.i != null) {
                this.i.a(this.h);
            }
            a(this.e > 0);
            map = DownloadingService.h;
            if (map.size() <= 0) {
                this.a.stopSelf();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
