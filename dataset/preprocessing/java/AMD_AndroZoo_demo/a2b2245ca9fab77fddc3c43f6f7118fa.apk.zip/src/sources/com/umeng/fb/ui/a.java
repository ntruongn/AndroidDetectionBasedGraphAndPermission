package com.umeng.fb.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class a extends BroadcastReceiver {
    final /* synthetic */ FeedbackConversation a;

    private a(FeedbackConversation feedbackConversation) {
        this.a = feedbackConversation;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ a(FeedbackConversation feedbackConversation, a aVar) {
        this(feedbackConversation);
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        com.umeng.fb.e eVar;
        com.umeng.fb.e eVar2;
        EditText editText;
        Button button;
        EditText editText2;
        Button button2;
        f fVar;
        com.umeng.fb.e eVar3;
        f fVar2;
        String stringExtra = intent.getStringExtra("feedback_id");
        eVar = this.a.f;
        if (eVar.c.equalsIgnoreCase(stringExtra)) {
            this.a.f = com.umeng.fb.c.e.b(this.a, stringExtra);
            fVar = this.a.g;
            eVar3 = this.a.f;
            fVar.a(eVar3);
            fVar2 = this.a.g;
            fVar2.notifyDataSetChanged();
        }
        eVar2 = this.a.f;
        if (eVar2.b != com.umeng.fb.f.Normal) {
            editText2 = this.a.i;
            editText2.setEnabled(false);
            button2 = this.a.j;
            button2.setEnabled(false);
            return;
        }
        editText = this.a.i;
        editText.setEnabled(true);
        button = this.a.j;
        button.setEnabled(true);
    }
}
