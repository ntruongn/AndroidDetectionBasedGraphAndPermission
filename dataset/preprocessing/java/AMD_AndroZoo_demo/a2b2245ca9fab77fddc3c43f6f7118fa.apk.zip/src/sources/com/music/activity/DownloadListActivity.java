package com.music.activity;

import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.LinkedHashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class DownloadListActivity extends BaseActivity implements View.OnClickListener {
    public static com.music.b.b.a b;
    public static LinkedHashMap c = new LinkedHashMap();
    public static Handler d = new f();
    private static ListView e;
    private static g f;
    private static TextView h;
    private static Context k;
    private TextView g;
    private String[] i = {"下载", "删除下载"};
    private String[] j = {"暂停下载", "删除下载"};
    private String l = "";
    private String m = "onRunning";
    private String n = "onPause";
    private com.a.a.a o;

    private void e() {
        this.g = (TextView) findViewById(R.id.title);
        this.g.setText("音乐下载列表");
        e = (ListView) findViewById(R.id.goods_list);
        h = (TextView) findViewById(R.id.category_list_nodata);
    }

    private void f() {
        if (com.music.c.m.a.size() > 0) {
            e.setVisibility(0);
            if (f == null) {
                f = new g(this, this);
                e.setAdapter((ListAdapter) f);
            }
            f.notifyDataSetChanged();
        } else {
            h.setVisibility(0);
            h.setText("下载列表中无音乐");
            e.setVisibility(8);
        }
        System.out.println("下载列表中共有：" + com.music.c.m.a.size() + "首歌");
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.music_down);
        f = null;
        h = null;
        b = new com.music.b.b.a(this);
        k = this;
        this.l = String.valueOf(Environment.getExternalStorageDirectory().getPath()) + "/" + com.music.c.m.c + "/";
        e();
        if (c != null) {
            c.clear();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        e.setVisibility(0);
        h.setVisibility(8);
        if (com.music.c.m.a.size() == 0) {
            b.a();
        }
        f();
    }
}
