package com.umeng.fb.a;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class e extends Thread {
    static final String a = e.class.getSimpleName();
    Context b;
    String d;
    String e;
    Handler g;
    String c = "http://feedback.whalecloud.com/feedback/reply";
    int f = 0;

    public e(Context context) {
        this.b = context;
        this.d = com.umeng.common.b.k(context);
        this.e = com.umeng.common.b.d(context);
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        String str;
        JSONArray jSONArray;
        String str2 = "";
        Iterator<String> it = this.b.getSharedPreferences("feedback", 0).getAll().keySet().iterator();
        while (true) {
            str = str2;
            if (!it.hasNext()) {
                break;
            }
            str2 = it.next();
            if (str.length() != 0) {
                str2 = String.valueOf(str) + "," + str2;
            }
        }
        String string = this.b.getSharedPreferences("UmengFb_Nums", 0).getString("maxReplyID", "RP0");
        if (com.umeng.common.b.b.c(str)) {
            return;
        }
        this.c = String.valueOf(this.c) + "?appkey=" + this.d + "&feedback_id=" + str;
        if (!string.equals("RP0")) {
            this.c = String.valueOf(this.c) + "&startkey=" + string;
        }
        Log.d(a, this.c);
        String a2 = com.umeng.fb.c.c.a(this.c);
        Intent intent = new Intent();
        intent.setAction("RetrieveReplyBroadcast");
        if (a2 != null) {
            try {
                jSONArray = new JSONArray(a2);
            } catch (JSONException e) {
                e.printStackTrace();
                jSONArray = null;
            }
            String a3 = com.umeng.fb.c.e.a(this.b, jSONArray);
            Log.d(a, "newReplyIds :" + a3);
            if (a3.length() == 0 || a3.split(",").length == 0) {
                intent.putExtra("RetrieveReplyBroadcast", 0);
            } else {
                intent.putExtra("RetrieveReplyBroadcast", 1);
                if (this.g != null) {
                    com.umeng.fb.b bVar = com.umeng.fb.c.e.b(this.b, a3.split(",")[r0.length - 1]).e;
                    Message message = new Message();
                    Bundle bundle = new Bundle();
                    bundle.putString("newReplyContent", bVar.a());
                    message.setData(bundle);
                    this.g.sendMessage(message);
                }
            }
        } else {
            intent.putExtra("RetrieveReplyBroadcast", -1);
        }
        this.b.sendBroadcast(intent);
    }
}
