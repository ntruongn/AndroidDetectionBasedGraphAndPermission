package com.feiwo.banner;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class i implements com.feiwo.banner.e.i {
    private /* synthetic */ d a;
    private final /* synthetic */ com.feiwo.banner.c.a b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public i(d dVar, com.feiwo.banner.c.a aVar) {
        this.a = dVar;
        this.b = aVar;
    }

    @Override // com.feiwo.banner.e.i
    public final void a(int i) {
        Context context;
        Intent intent = new Intent();
        context = this.a.g;
        com.feiwo.banner.e.f.a(context).a(this.b.i(), null, this.b.b(), "已经完成下载" + (i + 1) + "%", intent, 16);
    }

    @Override // com.feiwo.banner.e.i
    public final void a(String str) {
        Handler handler;
        Handler handler2;
        Context context = this.a.getContext();
        String str2 = String.valueOf(this.b.o()) + "_time";
        context.getSharedPreferences("ADFEIWO", 0).edit().putLong(com.feiwo.banner.f.f.a(str2, "12345678", true), System.currentTimeMillis()).commit();
        Bundle bundle = new Bundle();
        bundle.putString("path", str);
        bundle.putString("iconurl", this.b.d());
        bundle.putString("pushstr", this.b.b());
        bundle.putBoolean("notifiKeep", this.b.p());
        handler = this.a.q;
        handler2 = this.a.q;
        handler.sendMessage(handler2.obtainMessage(100, this.b.i(), 0, bundle));
    }
}
