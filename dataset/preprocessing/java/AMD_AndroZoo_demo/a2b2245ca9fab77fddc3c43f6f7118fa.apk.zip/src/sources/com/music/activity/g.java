package com.music.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.music.domain.MusicNetWorkInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class g extends BaseAdapter {
    final /* synthetic */ DownloadListActivity a;
    private Context b;

    public g(DownloadListActivity downloadListActivity, Context context) {
        this.a = downloadListActivity;
        this.b = context;
    }

    private com.music.b.c.b a(String str) {
        int i = 0;
        List b = DownloadListActivity.b.b(str);
        if (b == null || b.size() <= 0) {
            return null;
        }
        Iterator it = b.iterator();
        int i2 = 0;
        while (true) {
            int i3 = i;
            if (!it.hasNext()) {
                return new com.music.b.c.b(i3, i2, str);
            }
            com.music.b.c.a aVar = (com.music.b.c.a) it.next();
            i2 += aVar.d();
            i = (aVar.c() - aVar.b()) + 1 + i3;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(TextView textView, String[] strArr, ArrayList arrayList, boolean z) {
        Object obj = arrayList.get(0);
        if (obj instanceof MusicNetWorkInfo) {
            MusicNetWorkInfo musicNetWorkInfo = (MusicNetWorkInfo) obj;
            new AlertDialog.Builder(this.b).setTitle(musicNetWorkInfo.musicName).setItems(strArr, new i(this, z, musicNetWorkInfo, textView, arrayList)).show();
        }
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (com.music.c.m.a == null || com.music.c.m.a.size() <= 0) {
            return 0;
        }
        return com.music.c.m.a.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        j jVar;
        String str;
        String str2;
        String str3;
        if (view == null) {
            view = LayoutInflater.from(this.b).inflate(R.layout.music_item, (ViewGroup) null);
            jVar = new j(this);
            jVar.b = (TextView) view.findViewById(R.id.music_name);
            jVar.a = (TextView) view.findViewById(R.id.music_singer);
            jVar.c = (TextView) view.findViewById(R.id.music_time);
            jVar.c.setVisibility(0);
            TextView textView = jVar.c;
            str3 = this.a.n;
            textView.setTag(str3);
            jVar.f = (ProgressBar) view.findViewById(R.id.download_progress);
            jVar.f.setVisibility(0);
            jVar.d = (ImageView) view.findViewById(R.id.music_pic);
            jVar.e = (ImageView) view.findViewById(R.id.item_right_pic);
            jVar.e.setVisibility(8);
            view.setTag(jVar);
        } else {
            jVar = (j) view.getTag();
        }
        TextView textView2 = jVar.c;
        str = this.a.n;
        textView2.setTag(str);
        if (com.music.c.m.a != null && i < com.music.c.m.a.size()) {
            MusicNetWorkInfo musicNetWorkInfo = (MusicNetWorkInfo) com.music.c.m.a.get(i);
            jVar.b.setText(musicNetWorkInfo.musicName);
            jVar.a.setText(musicNetWorkInfo.musicSinger);
            DownloadListActivity.c.put(Integer.valueOf(i), view);
            com.music.b.c.b a = a(musicNetWorkInfo.musicUrl);
            if (a != null) {
                int b = a.b();
                int a2 = a.a();
                jVar.f.setMax(a2);
                jVar.f.setProgress(b);
                str2 = this.a.m;
                if (str2.equals(jVar.c.getTag().toString())) {
                    jVar.c.setText(String.valueOf((b * 100) / a2) + "%");
                } else {
                    jVar.c.setText("暂停");
                }
            }
            view.setOnClickListener(new h(this, jVar, musicNetWorkInfo));
        }
        return view;
    }
}
