package com.feiwo.banner.f;

import android.content.Context;
import java.io.UnsupportedEncodingException;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class e {
    public static int a(Context context, String str, String str2, String str3, int i) {
        return b(context, str, str2).optInt(str3, 0);
    }

    public static String a(Context context, String str, String str2, String str3, String str4) {
        String string = context.getSharedPreferences(str, 0).getString(f.a(str2, str4, true), str3);
        return string.equals(str3) ? str3 : f.a(string, "12345678");
    }

    public static void a(Context context, String str, String str2) {
        context.getSharedPreferences("ADFEIWO", 0).edit().remove(f.a(str, str2, true)).commit();
    }

    public static void a(Context context, String str, String str2, boolean z, String str3) {
        context.getSharedPreferences(str, 0).edit().putBoolean(f.a(str2, str3, true), z).commit();
    }

    public static JSONObject b(Context context, String str, String str2) {
        try {
            return new JSONObject(a(context, str, str2, "{}", "12345678"));
        } catch (UnsupportedEncodingException e) {
            JSONObject jSONObject = new JSONObject();
            a(context, str2, "12345678");
            return jSONObject;
        } catch (JSONException e2) {
            JSONObject jSONObject2 = new JSONObject();
            a(context, str2, "12345678");
            return jSONObject2;
        }
    }

    public static void b(Context context, String str, String str2, String str3, String str4) {
        context.getSharedPreferences(str, 0).edit().putString(f.a(str2, str4, true), f.a(str3, str4, true)).commit();
    }
}
