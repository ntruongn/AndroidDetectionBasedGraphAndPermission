package com.music.activity;

import android.view.View;
import android.widget.AdapterView;
import com.music.domain.ObjectInfo;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class w implements AdapterView.OnItemClickListener {
    final /* synthetic */ MusicSearchActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public w(MusicSearchActivity musicSearchActivity) {
        this.a = musicSearchActivity;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        if (MusicSearchActivity.d != 0) {
            if (MusicSearchActivity.d == 1) {
                this.a.a(String.valueOf(MusicSearchActivity.b) + "-" + MusicSearchActivity.c);
                return;
            }
            return;
        }
        Object obj = MusicSearchActivity.e.get(i);
        if (obj == null || !(obj instanceof ObjectInfo)) {
            return;
        }
        ObjectInfo objectInfo = (ObjectInfo) obj;
        if (objectInfo.name != null) {
            this.a.q = "http://box.zhangmen.baidu.com/x?op=12&count=1&title=" + objectInfo.name;
            String[] split = objectInfo.name.replace("$$", ",").replace("$$$$", ",").split(",");
            if (split != null && split.length > 1) {
                MusicSearchActivity.b = split[0];
                MusicSearchActivity.c = split[1];
            }
            this.a.a(String.valueOf(MusicSearchActivity.b) + "-" + MusicSearchActivity.c);
        }
    }
}
