package com.umeng.fb.ui;

import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class k implements View.OnClickListener {
    final /* synthetic */ SendFeedback a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(SendFeedback sendFeedback) {
        this.a = sendFeedback;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        EditText editText;
        com.umeng.fb.c.a.b(this.a);
        this.a.finish();
        InputMethodManager inputMethodManager = (InputMethodManager) this.a.getSystemService("input_method");
        editText = this.a.f;
        inputMethodManager.hideSoftInputFromWindow(editText.getWindowToken(), 0);
    }
}
