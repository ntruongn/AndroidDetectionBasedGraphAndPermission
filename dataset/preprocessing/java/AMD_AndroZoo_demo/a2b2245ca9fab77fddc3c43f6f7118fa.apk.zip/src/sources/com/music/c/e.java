package com.music.c;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class e {
    public static Cursor a(Context context) {
        return context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, new String[]{"title", "duration", "artist", "_id", "_size", "_display_name", "_data"}, null, null, null);
    }

    public static void a(Context context, String str) {
        if (str != null) {
            context.getContentResolver().delete(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "_data = '" + str + "'", null);
        } else {
            context.getContentResolver().delete(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null);
        }
    }

    public static boolean a(Context context, String str, String str2, String str3) {
        String a;
        if (str == null || "".equals(str) || (a = com.music.service.a.a(context, str, "gb2312")) == null || !a.contains("[00:")) {
            return false;
        }
        int lastIndexOf = str.lastIndexOf(".");
        if (lastIndexOf == -1) {
            System.out.println(String.valueOf(str3) + " 的歌词地址不可访问");
            return false;
        }
        String substring = str.substring(lastIndexOf);
        File file = new File(str2);
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, String.valueOf(str3) + substring);
        if (file2.exists()) {
            System.out.println(String.valueOf(file2.getName()) + "已经存在了。");
            return true;
        }
        try {
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        } catch (IOException e3) {
            e3.printStackTrace();
        }
        if (!file2.createNewFile()) {
            return false;
        }
        FileOutputStream fileOutputStream = new FileOutputStream(file2);
        fileOutputStream.write(a.getBytes("gb2312"));
        fileOutputStream.close();
        return true;
    }

    public static ArrayList b(Context context) {
        Cursor a = a(context);
        ArrayList arrayList = new ArrayList();
        if (a != null && a.getCount() != 0) {
            while (a.moveToNext()) {
                HashMap hashMap = new HashMap();
                hashMap.put("_id", Integer.valueOf(a.getInt(a.getColumnIndex("_id"))));
                hashMap.put("title", a.getString(a.getColumnIndex("title")));
                hashMap.put("duration", q.a().a(a.getInt(a.getColumnIndex("duration"))));
                hashMap.put("musicPath", a.getString(a.getColumnIndex("_data")));
                hashMap.put("musicArtist", a.getString(a.getColumnIndex("artist")));
                arrayList.add(hashMap);
            }
            a.close();
        }
        return arrayList;
    }
}
