package com.music.a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.music.activity.R;
import com.music.domain.ObjectInfo;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class a extends BaseAdapter {
    private ArrayList a;
    private Context b;

    public a(ArrayList arrayList, Context context) {
        this.a = new ArrayList();
        this.a = arrayList;
        this.b = context;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.a == null || this.a.size() <= 0) {
            return 0;
        }
        return this.a.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        b bVar;
        TextView textView;
        TextView textView2;
        if (view == null) {
            bVar = new b(this);
            view = LayoutInflater.from(this.b).inflate(R.layout.gridview_item, (ViewGroup) null);
            bVar.b = (TextView) view.findViewById(R.id.bangdan_name);
            view.setTag(bVar);
        } else {
            bVar = (b) view.getTag();
        }
        if (this.a == null || i >= this.a.size()) {
            textView = bVar.b;
            textView.setText("新歌  " + i);
        } else {
            Object obj = this.a.get(i);
            if (obj != null && (obj instanceof ObjectInfo)) {
                textView2 = bVar.b;
                textView2.setText(((ObjectInfo) obj).name);
            }
        }
        return view;
    }
}
