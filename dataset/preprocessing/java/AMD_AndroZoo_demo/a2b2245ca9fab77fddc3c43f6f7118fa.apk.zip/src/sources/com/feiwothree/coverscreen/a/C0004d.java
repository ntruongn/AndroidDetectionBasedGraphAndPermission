package com.feiwothree.coverscreen.a;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* renamed from: com.feiwothree.coverscreen.a.d, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class C0004d {
    private static C0004d a = null;
    private ExecutorService b;
    private Map c = new HashMap();
    private int d = 0;
    private int e = 0;

    private C0004d() {
        this.b = null;
        this.b = Executors.newFixedThreadPool(5);
    }

    public static C0004d a() {
        if (a == null) {
            a = new C0004d();
        }
        return a;
    }

    public static void a(String str, String str2) {
        HttpURLConnection httpURLConnection;
        HttpURLConnection httpURLConnection2;
        FileOutputStream fileOutputStream;
        InputStream inputStream;
        FileOutputStream fileOutputStream2;
        FileOutputStream fileOutputStream3 = null;
        r2 = null;
        fileOutputStream3 = null;
        HttpURLConnection httpURLConnection3 = null;
        FileOutputStream fileOutputStream4 = null;
        File file = new File(String.valueOf(str2) + "." + System.currentTimeMillis() + ".temp");
        File file2 = new File(str2);
        if (file2.exists()) {
            return;
        }
        try {
            httpURLConnection2 = (HttpURLConnection) new URL(str).openConnection();
            try {
                httpURLConnection2.setConnectTimeout(20000);
                httpURLConnection2.setReadTimeout(20000);
                httpURLConnection2.setRequestMethod("GET");
                httpURLConnection2.connect();
                inputStream = httpURLConnection2.getInputStream();
                fileOutputStream2 = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                httpURLConnection3 = httpURLConnection2;
                fileOutputStream = null;
            } catch (IOException e2) {
            } catch (Throwable th) {
                httpURLConnection = httpURLConnection2;
                th = th;
            }
            try {
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = inputStream.read(bArr);
                    if (read == -1) {
                        break;
                    } else {
                        fileOutputStream2.write(bArr, 0, read);
                    }
                }
                fileOutputStream2.flush();
                fileOutputStream2.close();
                file.renameTo(file2);
                try {
                    fileOutputStream2.close();
                    if (httpURLConnection2 != null) {
                        httpURLConnection2.disconnect();
                    }
                } catch (IOException e3) {
                }
            } catch (FileNotFoundException e4) {
                httpURLConnection3 = httpURLConnection2;
                fileOutputStream = fileOutputStream2;
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e5) {
                        return;
                    }
                }
                if (httpURLConnection3 != null) {
                    httpURLConnection3.disconnect();
                }
            } catch (IOException e6) {
                fileOutputStream4 = fileOutputStream2;
                if (fileOutputStream4 != null) {
                    try {
                        fileOutputStream4.close();
                    } catch (IOException e7) {
                        return;
                    }
                }
                if (httpURLConnection2 != null) {
                    httpURLConnection2.disconnect();
                }
            } catch (Throwable th2) {
                fileOutputStream3 = fileOutputStream2;
                httpURLConnection = httpURLConnection2;
                th = th2;
                if (fileOutputStream3 != null) {
                    try {
                        fileOutputStream3.close();
                    } catch (IOException e8) {
                        throw th;
                    }
                }
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                throw th;
            }
        } catch (FileNotFoundException e9) {
            fileOutputStream = null;
        } catch (IOException e10) {
            httpURLConnection2 = null;
        } catch (Throwable th3) {
            th = th3;
            httpURLConnection = null;
        }
    }

    public final Bitmap a(Context context, String str) {
        int i;
        Bitmap bitmap;
        int i2;
        if (!new File(str).exists()) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        int i3 = options.outWidth;
        int i4 = options.outHeight;
        int i5 = i3;
        int i6 = 1;
        while (true) {
            int i7 = i4;
            int i8 = i5 / 2;
            if (this.d > 0) {
                i = this.d;
            } else {
                DisplayMetrics displayMetrics = new DisplayMetrics();
                ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
                this.d = displayMetrics.widthPixels;
                i = displayMetrics.widthPixels;
            }
            if (i8 <= i) {
                break;
            }
            int i9 = i7 / 2;
            if (this.e > 0) {
                i2 = this.e;
            } else {
                DisplayMetrics displayMetrics2 = new DisplayMetrics();
                ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics2);
                this.e = displayMetrics2.heightPixels;
                i2 = this.e;
            }
            if (i9 <= i2) {
                break;
            }
            i5 /= 2;
            i4 = i7 / 2;
            i6 <<= 1;
        }
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inSampleSize = i6;
        options.inJustDecodeBounds = false;
        File file = new File(str);
        if (file.exists()) {
            bitmap = BitmapFactory.decodeFile(str, options);
            if (bitmap == null) {
                file.delete();
            }
        } else {
            bitmap = null;
        }
        return bitmap;
    }

    public final Drawable a(Context context, String str, String str2) {
        if (str == null || str.equals("")) {
            return null;
        }
        File file = new File(str2);
        if (!file.exists()) {
            return null;
        }
        try {
            file.setLastModified(System.currentTimeMillis());
            return new BitmapDrawable(a(context, str2));
        } catch (Exception e) {
            return null;
        } catch (OutOfMemoryError e2) {
            return null;
        }
    }

    public final Drawable a(Context context, String str, String str2, InterfaceC0007g interfaceC0007g) {
        if (this.c.containsKey(str)) {
            SoftReference softReference = (SoftReference) this.c.get(str);
            if (softReference.get() != null) {
                if (0 != 0) {
                    softReference.get();
                }
                return (Drawable) softReference.get();
            }
        }
        this.b.submit(new RunnableC0006f(this, context, str, str2, true, new HandlerC0005e(this, null, str)));
        return null;
    }
}
