package com.feiwo.banner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import java.io.UnsupportedEncodingException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class AdReceiver extends BroadcastReceiver {
    Handler a = new Handler();

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.PACKAGE_ADDED")) {
            String str = "";
            try {
                str = com.feiwo.banner.f.e.a(context, "ADFEIWO", "APPKEY", "", "12345678");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            String schemeSpecificPart = intent.getData().getSchemeSpecificPart();
            int i = context.getSharedPreferences("ADFEIWO", 0).getInt(com.feiwo.banner.f.f.a(schemeSpecificPart, "12345678", true), 0);
            long j = context.getSharedPreferences("ADFEIWO", 0).getLong(com.feiwo.banner.f.f.a(String.valueOf(schemeSpecificPart) + "_time", "12345678", true), 0L);
            if (i > 0) {
                com.feiwo.banner.e.f.a(context).a(i);
                PackageManager packageManager = context.getPackageManager();
                new Intent();
                Intent launchIntentForPackage = packageManager.getLaunchIntentForPackage(schemeSpecificPart);
                launchIntentForPackage.addFlags(268435456);
                context.startActivity(launchIntentForPackage);
            }
            if (System.currentTimeMillis() - j > 120000) {
                i = 0;
            }
            JSONObject b = com.feiwo.banner.f.e.b(context, "ADFEIWO", "list_install");
            JSONArray jSONArray = b.optJSONArray("installCount") == null ? new JSONArray() : b.optJSONArray("installCount");
            com.feiwo.banner.f.i.a();
            if (com.feiwo.banner.f.i.a(context, schemeSpecificPart)) {
                boolean z = false;
                for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                    if (jSONArray.optJSONObject(i2).optInt("adid") == i) {
                        z = true;
                    }
                }
                if (!z) {
                    try {
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put("adid", i);
                        jSONObject.put("packageName", schemeSpecificPart);
                        jSONArray.put(jSONObject);
                    } catch (JSONException e2) {
                    }
                }
            }
            try {
                b.put("installCount", jSONArray);
                b.put("appkey", str);
                b.put("adsdkversion", "2.4");
                b.put("sdktype", "BANNER");
                b.put("devid", com.feiwo.banner.f.k.a(context));
            } catch (JSONException e3) {
            }
            this.a.postDelayed(new r(this, context, schemeSpecificPart, str, b), i <= 0 ? 5000 : 0);
        }
    }
}
