package com.umeng.a;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.text.TextUtils;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class e implements k {
    private String i;
    private final Handler j;
    private final d f = new d();
    private final h g = new h();
    private final b h = new b();
    String a = null;
    String b = null;
    private final int k = 0;
    private final int l = 1;
    private final int m = 2;
    private final int n = 3;
    private final int o = 4;
    private final int p = 5;
    private final int q = 6;
    c c = null;
    String d = "";
    String e = "";
    private final String r = "type";
    private final String s = "error";
    private final String t = "event";
    private final String u = "ekv";
    private final String v = "launch";
    private final String w = "flush";
    private final String x = "terminate";
    private final String y = "online_config";
    private final String z = "cmd_cache_buffer";
    private final String A = "appkey";
    private final String B = "body";
    private final String C = "session_id";
    private final String D = "date";
    private final String E = "time";
    private final String F = "start_millis";
    private final String G = "end_millis";
    private final String H = "duration";
    private final String I = "activities";
    private final String J = "header";
    private final String K = "uptr";
    private final String L = "dntr";
    private final String M = "acc";
    private final String N = "tag";
    private final String O = "label";
    private final String P = "id";
    private final String Q = "ts";
    private final String R = "du";
    private final String S = "context";
    private final String T = "last_config_time";
    private final String U = "report_policy";
    private final String V = "online_params";
    private final String W = "report_interval";

    /* JADX INFO: Access modifiers changed from: package-private */
    public e() {
        HandlerThread handlerThread = new HandlerThread("MobclickAgent");
        handlerThread.start();
        this.j = new Handler(handlerThread.getLooper());
    }

    private String a(Context context, String str, long j) {
        StringBuilder sb = new StringBuilder();
        sb.append(j).append(str).append(com.umeng.common.b.b.b(com.umeng.common.b.c(context)));
        return com.umeng.common.b.b.a(sb.toString());
    }

    private String a(Context context, String str, SharedPreferences sharedPreferences) {
        d(context, sharedPreferences);
        long currentTimeMillis = System.currentTimeMillis();
        String a = a(context, str, currentTimeMillis);
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putString("appkey", str);
        edit.putString("session_id", a);
        edit.putLong("start_millis", currentTimeMillis);
        edit.putLong("end_millis", -1L);
        edit.putLong("duration", 0L);
        edit.putString("activities", "");
        edit.remove("last_terminate_location_time");
        edit.commit();
        c(context, sharedPreferences);
        return a;
    }

    private String a(Context context, JSONObject jSONObject, String str, boolean z, String str2) {
        HttpPost httpPost = new HttpPost(str);
        BasicHttpParams basicHttpParams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(basicHttpParams, 10000);
        HttpConnectionParams.setSoTimeout(basicHttpParams, 30000);
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient(basicHttpParams);
        httpPost.addHeader("X-Umeng-Sdk", k(context));
        try {
            String a = j.a(context);
            if (a != null) {
                defaultHttpClient.getParams().setParameter("http.route.default-proxy", new HttpHost(a, 80));
            }
            String jSONObject2 = jSONObject.toString();
            com.umeng.common.a.a("MobclickAgent", jSONObject2);
            if (!i.i || z) {
                ArrayList arrayList = new ArrayList(1);
                arrayList.add(new BasicNameValuePair("content", jSONObject2));
                httpPost.setEntity(new UrlEncodedFormEntity(arrayList, "UTF-8"));
            } else {
                byte[] a2 = com.umeng.common.b.a.a("content=" + jSONObject2, "utf-8");
                httpPost.addHeader("Content-Encoding", "deflate");
                httpPost.setEntity(new InputStreamEntity(new ByteArrayInputStream(a2), com.umeng.common.b.a.a));
            }
            SharedPreferences.Editor edit = l.c(context).edit();
            Date date = new Date();
            HttpResponse execute = defaultHttpClient.execute(httpPost);
            long time = new Date().getTime() - date.getTime();
            if (execute.getStatusLine().getStatusCode() != 200) {
                edit.putLong("req_time", -1L);
                return null;
            }
            com.umeng.common.a.a("MobclickAgent", "Sent message to " + str);
            edit.putLong("req_time", time);
            edit.commit();
            HttpEntity entity = execute.getEntity();
            if (entity != null) {
                return a(entity.getContent());
            }
            return null;
        } catch (ClientProtocolException e) {
            com.umeng.common.a.a("MobclickAgent", "ClientProtocolException,Failed to send message.", e);
            return null;
        } catch (IOException e2) {
            com.umeng.common.a.a("MobclickAgent", "IOException,Failed to send message.", e2);
            return null;
        }
    }

    private String a(InputStream inputStream) {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream), 8192);
        StringBuilder sb = new StringBuilder();
        while (true) {
            try {
                try {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        try {
                            inputStream.close();
                            return sb.toString();
                        } catch (IOException e) {
                            com.umeng.common.a.b("MobclickAgent", "Caught IOException in convertStreamToString()", e);
                            return null;
                        }
                    }
                    sb.append(String.valueOf(readLine) + "\n");
                } catch (IOException e2) {
                    com.umeng.common.a.b("MobclickAgent", "Caught IOException in convertStreamToString()", e2);
                    try {
                        inputStream.close();
                        return null;
                    } catch (IOException e3) {
                        com.umeng.common.a.b("MobclickAgent", "Caught IOException in convertStreamToString()", e3);
                        return null;
                    }
                }
            } catch (Throwable th) {
                try {
                    inputStream.close();
                    throw th;
                } catch (IOException e4) {
                    com.umeng.common.a.b("MobclickAgent", "Caught IOException in convertStreamToString()", e4);
                    return null;
                }
            }
        }
    }

    private JSONArray a(JSONObject jSONObject, JSONArray jSONArray) {
        if (jSONArray != null && jSONObject != null) {
            try {
                String next = jSONObject.keys().next();
                int length = jSONArray.length() - 1;
                while (true) {
                    if (length < 0) {
                        jSONArray.put(jSONObject);
                        break;
                    }
                    JSONObject jSONObject2 = (JSONObject) jSONArray.get(length);
                    if (jSONObject2.has(next)) {
                        jSONObject2.getJSONArray(next).put((JSONObject) jSONObject.getJSONArray(next).get(0));
                        break;
                    }
                    length--;
                }
            } catch (Exception e) {
                com.umeng.common.a.a("MobclickAgent", "custom log merge error in tryToSendMessage", e);
            }
        }
        return jSONArray;
    }

    private void a(Context context, SharedPreferences sharedPreferences) {
        Location g;
        long currentTimeMillis = System.currentTimeMillis();
        if (!i.b || currentTimeMillis - sharedPreferences.getLong("last_terminate_location_time", 0L) <= 10000 || (g = com.umeng.common.b.g(context)) == null) {
            return;
        }
        if (g.getTime() != sharedPreferences.getLong("gps_time", 0L)) {
            sharedPreferences.edit().putFloat("lng", (float) g.getLongitude()).putFloat("lat", (float) g.getLatitude()).putFloat("alt", (float) g.getAltitude()).putLong("gps_time", g.getTime()).putLong("last_terminate_location_time", currentTimeMillis).commit();
        }
    }

    private void a(Context context, SharedPreferences sharedPreferences, String str, String str2, long j, int i) {
        String string = sharedPreferences.getString("session_id", "");
        String a = com.umeng.common.b.b.a();
        String str3 = a.split(" ")[0];
        String str4 = a.split(" ")[1];
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", "event");
            jSONObject.put("session_id", string);
            jSONObject.put("date", str3);
            jSONObject.put("time", str4);
            jSONObject.put("tag", str);
            if (!TextUtils.isEmpty(str2)) {
                jSONObject.put("label", str2);
            }
            if (j > 0) {
                jSONObject.put("du", j);
            }
            jSONObject.put("acc", i);
            this.j.post(new g(this, this, context, jSONObject));
        } catch (JSONException e) {
            com.umeng.common.a.a("MobclickAgent", "json error in emitCustomLogReport", e);
        }
    }

    private void a(Context context, SharedPreferences sharedPreferences, String str, JSONObject jSONObject) {
        String string = sharedPreferences.getString("session_id", "");
        JSONObject jSONObject2 = new JSONObject();
        JSONArray jSONArray = new JSONArray();
        try {
            jSONObject.put("id", str);
            jSONObject.put("ts", System.currentTimeMillis() / 1000);
            jSONArray.put(jSONObject);
            jSONObject2.put("type", "ekv");
            jSONObject2.put(string, jSONArray);
            this.j.post(new g(this, this, context, jSONObject2));
        } catch (JSONException e) {
            com.umeng.common.a.a("MobclickAgent", "json error in emitCustomLogReport", e);
            e.printStackTrace();
        }
    }

    private void a(Context context, String str) {
        SharedPreferences b = l.b(context);
        try {
            JSONObject jSONObject = new JSONObject(str);
            try {
                if (jSONObject.has("last_config_time")) {
                    b.edit().putString("umeng_last_config_time", jSONObject.getString("last_config_time")).commit();
                }
            } catch (Exception e) {
                com.umeng.common.a.a("MobclickAgent", "save online config time", e);
            }
            long j = -1;
            try {
                if (jSONObject.has("report_interval")) {
                    j = jSONObject.getInt("report_interval") * 1000;
                }
            } catch (Exception e2) {
            }
            try {
                if (jSONObject.has("report_policy")) {
                    this.h.a(context, jSONObject.getInt("report_policy"), j);
                }
            } catch (Exception e3) {
                com.umeng.common.a.a("MobclickAgent", "save online config policy", e3);
            }
            JSONObject jSONObject2 = null;
            try {
                if (jSONObject.has("online_params")) {
                    JSONObject jSONObject3 = new JSONObject(jSONObject.getString("online_params"));
                    Iterator<String> keys = jSONObject3.keys();
                    SharedPreferences.Editor edit = b.edit();
                    while (keys.hasNext()) {
                        String next = keys.next();
                        edit.putString(next, jSONObject3.getString(next));
                    }
                    edit.commit();
                    com.umeng.common.a.a("MobclickAgent", "get online setting params: " + jSONObject3);
                    jSONObject2 = jSONObject3;
                }
                if (this.c != null) {
                    this.c.a(jSONObject2);
                }
            } catch (Exception e4) {
                com.umeng.common.a.a("MobclickAgent", "save online config params", e4);
            }
        } catch (Exception e5) {
            com.umeng.common.a.a("MobclickAgent", "not json string");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void a(Context context, String str, String str2) {
        SharedPreferences e = l.e(context);
        if (e != null) {
            try {
                int c = c(context, "_kvts" + str + str2);
                if (c < 0) {
                    a("event duration less than 0 in ekvEvnetEnd");
                } else {
                    JSONObject jSONObject = new JSONObject(e.getString("_kvvl" + str + str2, null));
                    jSONObject.put("du", c);
                    a(context, e, str, jSONObject);
                }
            } catch (Exception e2) {
                a("exception in onLogDurationInternalEnd");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void a(Context context, String str, String str2, long j, int i) {
        SharedPreferences e = l.e(context);
        if (e != null) {
            a(context, e, str, str2, j, i);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void a(Context context, String str, Map map, long j) {
        SharedPreferences e = l.e(context);
        if (e != null) {
            try {
                JSONObject jSONObject = new JSONObject();
                Iterator it = map.entrySet().iterator();
                int i = 0;
                while (it.hasNext() && i < 10) {
                    int i2 = i + 1;
                    Map.Entry entry = (Map.Entry) it.next();
                    jSONObject.put((String) entry.getKey(), (String) entry.getValue());
                    i = i2;
                }
                if (j > 0) {
                    jSONObject.put("du", j);
                }
                a(context, e, str, jSONObject);
            } catch (Exception e2) {
                com.umeng.common.a.a("MobclickAgent", "exception when convert map to json");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void a(Context context, String str, Map map, String str2) {
        SharedPreferences e = l.e(context);
        if (e != null) {
            try {
                b(context, "_kvts" + str + str2);
                JSONObject jSONObject = new JSONObject();
                Iterator it = map.entrySet().iterator();
                int i = 0;
                while (it.hasNext() && i < 10) {
                    int i2 = i + 1;
                    Map.Entry entry = (Map.Entry) it.next();
                    jSONObject.put((String) entry.getKey(), (String) entry.getValue());
                    i = i2;
                }
                e.edit().putString("_kvvl" + str + str2, jSONObject.toString()).commit();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    private void a(Context context, JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                if (jSONObject != null && jSONObject.has("date") && jSONObject.has("time") && jSONObject.has("context")) {
                    if (jSONObject.has("version")) {
                        if (jSONObject.getString("version") != null && jSONObject.getString("version").equals(com.umeng.common.b.a(context))) {
                            jSONObject.remove("version");
                        }
                    }
                    this.j.post(new g(this, this, context, jSONObject));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void a(String str) {
        com.umeng.common.a.a("MobclickAgent", str);
    }

    private boolean a(SharedPreferences sharedPreferences) {
        return System.currentTimeMillis() - sharedPreferences.getLong("end_millis", -1L) > i.a;
    }

    private boolean a(JSONObject jSONObject, JSONObject jSONObject2) {
        try {
            String str = (String) jSONObject.remove("cache_version");
            String string = jSONObject2.getString("version_code");
            if (str != null) {
                if (str.equals(string)) {
                    return false;
                }
            }
        } catch (Exception e) {
            com.umeng.common.a.a("MobclickAgent", "Fail to filter message", e);
        }
        return true;
    }

    private String b(Context context, SharedPreferences sharedPreferences) {
        Long valueOf = Long.valueOf(System.currentTimeMillis());
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putLong("start_millis", valueOf.longValue());
        edit.putLong("end_millis", -1L);
        edit.commit();
        return sharedPreferences.getString("session_id", null);
    }

    private void b(Context context, String str) {
        try {
            if (i.f) {
                this.g.a(str);
            } else {
                m a = m.a(context, str);
                a.a(Long.valueOf(System.currentTimeMillis()));
                a.a(context);
            }
        } catch (Exception e) {
            com.umeng.common.a.a("MobclickAgent", "exception in save event begin info");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b(Context context, JSONObject jSONObject) {
        com.umeng.common.a.a("MobclickAgent", "start to check onlineConfig info ...");
        String a = a(context, jSONObject, "http://oc.umeng.com/check_config_update", true, "online_config");
        if (a == null) {
            a = a(context, jSONObject, "http://oc.umeng.co/check_config_update", true, "online_config");
        }
        if (a != null) {
            com.umeng.common.a.a("MobclickAgent", "get onlineConfig info succeed !");
            a(context, a);
        } else {
            if (this.c != null) {
                this.c.a(null);
            }
            com.umeng.common.a.a("MobclickAgent", "get onlineConfig info failed !");
        }
    }

    private int c(Context context, String str) {
        int i = -1;
        try {
            long b = i.f ? this.g.b(str) : m.a(context, str).a().longValue();
            if (b <= 0) {
                return -1;
            }
            i = (int) (System.currentTimeMillis() - b);
            return i;
        } catch (Exception e) {
            com.umeng.common.a.a("MobclickAgent", "exception in get event duration", e);
            return i;
        }
    }

    private void c(Context context, SharedPreferences sharedPreferences) {
        Location g;
        String string = sharedPreferences.getString("session_id", null);
        if (string == null) {
            com.umeng.common.a.a("MobclickAgent", "Missing session_id, ignore message");
            return;
        }
        String a = com.umeng.common.b.b.a();
        String str = a.split(" ")[0];
        String str2 = a.split(" ")[1];
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", "launch");
            jSONObject.put("session_id", string);
            jSONObject.put("date", str);
            jSONObject.put("time", str2);
            if (i.b && (g = com.umeng.common.b.g(context)) != null) {
                double longitude = g.getLongitude();
                double latitude = g.getLatitude();
                double altitude = g.getAltitude();
                long time = g.getTime();
                if (time != sharedPreferences.getLong("gps_time", 0L)) {
                    jSONObject.put("lng", longitude);
                    jSONObject.put("lat", latitude);
                    jSONObject.put("alt", altitude);
                    jSONObject.put("gps_time", time);
                    sharedPreferences.edit().putLong("gps_time", time).commit();
                }
            }
            this.j.post(new g(this, this, context, jSONObject));
        } catch (JSONException e) {
            com.umeng.common.a.b("MobclickAgent", "json error in emitNewSessionReport", e);
        }
    }

    private void d(Context context, SharedPreferences sharedPreferences) {
        String string = sharedPreferences.getString("session_id", null);
        if (string == null) {
            a("Missing session_id, ignore message in emitLastEndSessionReport");
            return;
        }
        Long valueOf = Long.valueOf(sharedPreferences.getLong("duration", -1L));
        if (valueOf.longValue() <= 0) {
            valueOf = 0L;
        }
        String a = com.umeng.common.b.b.a();
        String str = a.split(" ")[0];
        String str2 = a.split(" ")[1];
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", "terminate");
            jSONObject.put("session_id", string);
            jSONObject.put("date", str);
            jSONObject.put("time", str2);
            jSONObject.put("duration", String.valueOf(valueOf.longValue() / 1000));
            if (i.c) {
                String string2 = sharedPreferences.getString("activities", "");
                if (!"".equals(string2)) {
                    String[] split = string2.split(";");
                    JSONArray jSONArray = new JSONArray();
                    for (String str3 : split) {
                        jSONArray.put(new JSONArray(str3));
                    }
                    jSONObject.put("activities", jSONArray);
                }
            }
            long[] e = e(context, sharedPreferences);
            if (e != null) {
                jSONObject.put("uptr", e[1]);
                jSONObject.put("dntr", e[0]);
            }
            if (i.b && sharedPreferences.contains("last_terminate_location_time")) {
                jSONObject.put("lat", sharedPreferences.getFloat("lat", 0.0f));
                jSONObject.put("lng", sharedPreferences.getFloat("lng", 0.0f));
                jSONObject.put("alt", sharedPreferences.getFloat("alt", 0.0f));
                jSONObject.put("gps_time", sharedPreferences.getLong("gps_time", 0L));
            }
            this.j.post(new g(this, this, context, jSONObject));
        } catch (JSONException e2) {
            com.umeng.common.a.b("MobclickAgent", "json error in emitLastEndSessionReport", e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void e(Context context) {
        this.h.c(context);
        SharedPreferences e = l.e(context);
        if (e != null) {
            if (a(e)) {
                com.umeng.common.a.a("MobclickAgent", "Start new session: " + a(context, f(context), e));
            } else {
                com.umeng.common.a.a("MobclickAgent", "Extend current session: " + b(context, e));
            }
        }
    }

    private long[] e(Context context, SharedPreferences sharedPreferences) {
        try {
            Class<?> cls = Class.forName("android.net.TrafficStats");
            Method method = cls.getMethod("getUidRxBytes", Integer.TYPE);
            Method method2 = cls.getMethod("getUidTxBytes", Integer.TYPE);
            int i = context.getApplicationInfo().uid;
            if (i == -1) {
                return null;
            }
            long[] jArr = {((Long) method.invoke(null, Integer.valueOf(i))).longValue(), ((Long) method2.invoke(null, Integer.valueOf(i))).longValue()};
            if (jArr[0] <= 0 || jArr[1] <= 0) {
                return null;
            }
            long j = sharedPreferences.getLong("traffics_up", -1L);
            long j2 = sharedPreferences.getLong("traffics_down", -1L);
            sharedPreferences.edit().putLong("traffics_up", jArr[1]).putLong("traffics_down", jArr[0]).commit();
            if (j <= 0 || j2 <= 0) {
                return null;
            }
            jArr[0] = jArr[0] - j2;
            jArr[1] = jArr[1] - j;
            if (jArr[0] > 0) {
                if (jArr[1] > 0) {
                    return jArr;
                }
            }
            return null;
        } catch (Exception e) {
            a("sdk less than 2.2 has get no traffic");
            return null;
        }
    }

    private String f(Context context) {
        return this.b == null ? com.umeng.common.b.k(context) : this.b;
    }

    private String g(Context context) {
        return this.a == null ? com.umeng.common.b.o(context) : this.a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void h(Context context) {
        SharedPreferences e = l.e(context);
        if (e != null) {
            long j = e.getLong("start_millis", -1L);
            if (j == -1) {
                com.umeng.common.a.b("MobclickAgent", "onEndSession called before onStartSession");
            } else {
                long currentTimeMillis = System.currentTimeMillis();
                long j2 = currentTimeMillis - j;
                long j3 = e.getLong("duration", 0L);
                SharedPreferences.Editor edit = e.edit();
                if (i.c) {
                    String string = e.getString("activities", "");
                    String str = this.i;
                    if (!"".equals(string)) {
                        string = String.valueOf(string) + ";";
                    }
                    String str2 = String.valueOf(string) + "[" + str + "," + (j2 / 1000) + "]";
                    edit.remove("activities");
                    edit.putString("activities", str2);
                }
                edit.putLong("start_millis", -1L);
                edit.putLong("end_millis", currentTimeMillis);
                edit.putLong("duration", j2 + j3);
                edit.commit();
            }
            a(context, e);
            if (this.g.a() > 0) {
                i(context);
            }
        }
    }

    private void i(Context context) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", "cmd_cache_buffer");
            this.j.post(new g(this, this, context, jSONObject));
        } catch (JSONException e) {
            com.umeng.common.a.b("MobclickAgent", "json error in emitCache");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void j(Context context) {
        JSONArray b;
        if (this.f != null && (b = this.f.b(context)) != null && b.length() != 0) {
            a(context, b);
        }
    }

    private String k(Context context) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("Android");
        stringBuffer.append("/");
        stringBuffer.append("4.5");
        stringBuffer.append(" ");
        try {
            StringBuffer stringBuffer2 = new StringBuffer();
            stringBuffer2.append(context.getPackageManager().getApplicationLabel(context.getApplicationInfo()).toString());
            stringBuffer2.append("/");
            stringBuffer2.append(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName);
            stringBuffer2.append(" ");
            stringBuffer2.append(Build.MODEL);
            stringBuffer2.append("/");
            stringBuffer2.append(Build.VERSION.RELEASE);
            stringBuffer2.append(" ");
            stringBuffer2.append(com.umeng.common.b.b.b(com.umeng.common.b.c(context)));
            stringBuffer.append(URLEncoder.encode(stringBuffer2.toString()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stringBuffer.toString();
    }

    private JSONObject l(Context context) {
        JSONObject h;
        JSONObject jSONObject = new JSONObject();
        try {
            String c = com.umeng.common.b.c(context);
            if (c == null || c.equals("")) {
                com.umeng.common.a.b("MobclickAgent", "No device id");
                return null;
            }
            String f = f(context);
            if (f == null) {
                com.umeng.common.a.b("MobclickAgent", "No appkey");
                return null;
            }
            jSONObject.put("device_id", c);
            jSONObject.put("idmd5", com.umeng.common.b.b.b(c));
            jSONObject.put("mc", com.umeng.common.b.l(context));
            jSONObject.put("device_model", Build.MODEL);
            jSONObject.put("appkey", f);
            jSONObject.put("channel", g(context));
            jSONObject.put("app_version", com.umeng.common.b.b(context));
            jSONObject.put("version_code", com.umeng.common.b.a(context));
            jSONObject.put("sdk_type", "Android");
            jSONObject.put("sdk_version", "4.5");
            jSONObject.put("os", "Android");
            jSONObject.put("os_version", Build.VERSION.RELEASE);
            jSONObject.put("timezone", com.umeng.common.b.i(context));
            String[] j = com.umeng.common.b.j(context);
            if (j != null) {
                jSONObject.put("country", j[0]);
                jSONObject.put("language", j[1]);
            }
            jSONObject.put("resolution", com.umeng.common.b.m(context));
            String[] e = com.umeng.common.b.e(context);
            if (e != null && e[0].equals("2G/3G")) {
                jSONObject.put("access", e[0]);
                jSONObject.put("access_subtype", e[1]);
            } else if (e != null) {
                jSONObject.put("access", e[0]);
            } else {
                jSONObject.put("access", "Unknown");
            }
            jSONObject.put("carrier", com.umeng.common.b.n(context));
            jSONObject.put("cpu", com.umeng.common.b.a());
            if (!this.d.equals("")) {
                jSONObject.put("gpu_vender", this.d);
            }
            if (!this.e.equals("")) {
                jSONObject.put("gpu_renderer", this.e);
            }
            if (i.d && (h = l.h(context)) != null) {
                jSONObject.put("uinfo", h);
            }
            jSONObject.put("package", com.umeng.common.b.p(context));
            return jSONObject;
        } catch (Exception e2) {
            com.umeng.common.a.b("MobclickAgent", "getMessageHeader error", e2);
            return null;
        }
    }

    JSONObject a(Context context, JSONObject jSONObject, JSONObject jSONObject2, JSONObject jSONObject3, String str) {
        SharedPreferences c = l.c(context);
        long j = c.getLong("req_time", 0L);
        if (j != 0) {
            try {
                jSONObject2.put("req_time", j);
            } catch (JSONException e) {
                com.umeng.common.a.a("MobclickAgent", "json error in tryToSendMessage", e);
            }
        }
        c.edit().putString("header", jSONObject2.toString()).commit();
        JSONObject jSONObject4 = new JSONObject();
        if (str == null) {
            return null;
        }
        try {
            if ("flush".equals(str) && jSONObject == null) {
                com.umeng.common.a.d("MobclickAgent", "No cache message to flush in constructMessage");
                return null;
            }
            if (jSONObject != null && a(jSONObject, jSONObject2)) {
                jSONObject.remove("error");
            }
            if (!"flush".equals(str)) {
                if (jSONObject == null) {
                    jSONObject = new JSONObject();
                }
                if (jSONObject.isNull(str)) {
                    JSONArray jSONArray = new JSONArray();
                    jSONArray.put(jSONObject3);
                    jSONObject.put(str, jSONArray);
                } else {
                    JSONArray jSONArray2 = jSONObject.getJSONArray(str);
                    if ("ekv".equals(str)) {
                        a(jSONObject3, jSONArray2);
                    } else {
                        jSONArray2.put(jSONObject3);
                    }
                }
            }
            jSONObject4.put("header", jSONObject2);
            jSONObject4.put("body", jSONObject);
            return jSONObject4;
        } catch (JSONException e2) {
            com.umeng.common.a.b("MobclickAgent", "Fail to construct json message in tryToSendMessage.", e2);
            l.j(context);
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(Context context) {
        try {
            if (context == null) {
                com.umeng.common.a.b("MobclickAgent", "unexpected null context in onPause");
            } else if (context.getClass().getName().equals(this.i)) {
                new f(this, context, 0).start();
            } else {
                com.umeng.common.a.b("MobclickAgent", "onPause() called without context from corresponding onResume()");
            }
        } catch (Exception e) {
            com.umeng.common.a.b("MobclickAgent", "Exception occurred in Mobclick.onRause(). ", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a(Context context, JSONObject jSONObject) {
        String str;
        String str2 = (String) jSONObject.remove("type");
        JSONObject a = a(context, l.i(context), l(context), jSONObject, str2);
        if (a == null || a.isNull("body")) {
            return;
        }
        if (!this.h.a(str2, context)) {
            l.b(context, a);
            return;
        }
        String str3 = null;
        int i = 0;
        while (true) {
            if (i < i.h.length) {
                str = a(context, a, i.h[i], false, str2);
                if (str != null) {
                    break;
                }
                i++;
                str3 = str;
            } else {
                str = str3;
                break;
            }
        }
        if (str == null) {
            l.b(context, a);
            com.umeng.common.a.a("MobclickAgent", "send applog failed");
        } else {
            com.umeng.common.a.a("MobclickAgent", "send applog succeed :" + str);
            l.j(context);
            this.h.a(context);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(Context context) {
        try {
            String f = f(context);
            if (f == null || f.length() == 0) {
                com.umeng.common.a.b("MobclickAgent", "unexpected empty appkey in onError");
                return;
            }
            if (context == null) {
                com.umeng.common.a.b("MobclickAgent", "unexpected null context in onError");
                return;
            }
            if (this.f != null) {
                this.f.a(context);
                this.f.a(this);
            }
            new f(this, context, 2).start();
        } catch (Exception e) {
            com.umeng.common.a.b("MobclickAgent", "Exception occurred in Mobclick.onError()", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(Context context) {
        try {
            if (context == null) {
                com.umeng.common.a.b("MobclickAgent", "unexpected null context in onResume");
            } else {
                this.i = context.getClass().getName();
                new f(this, context, 1).start();
            }
        } catch (Exception e) {
            com.umeng.common.a.b("MobclickAgent", "Exception occurred in Mobclick.onResume(). ", e);
        }
    }

    @Override // com.umeng.a.k
    public void d(Context context) {
        try {
            this.g.a(context);
            h(context);
        } catch (Exception e) {
            com.umeng.common.a.a("MobclickAgent", "Exception in onAppCrash", e);
        }
    }
}
