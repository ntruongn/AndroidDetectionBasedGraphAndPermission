package com.umeng.fb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class g {
    public static long a = 30000;
    public static boolean b = true;
    public static boolean c = false;
    public static boolean d = true;
    public static boolean e = true;
    public static boolean f = true;
    public static boolean g = true;
    public static String h = null;
    public static String i = "last_send_time";
    public static final Object j = new Object();
    public static final String[] k = {"http://www.umeng.com/app_logs", "http://www.umeng.co/app_logs"};
    public static final String[] l = {"http://www.umeng.com/api/check_app_update", "http://www.umeng.co/api/check_app_update"};
    public static boolean m = false;
}
