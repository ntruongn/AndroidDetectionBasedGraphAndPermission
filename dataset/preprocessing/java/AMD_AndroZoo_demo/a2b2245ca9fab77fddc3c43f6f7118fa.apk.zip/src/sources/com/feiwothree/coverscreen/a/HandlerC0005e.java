package com.feiwothree.coverscreen.a;

import android.os.Handler;
import android.os.Message;

/* renamed from: com.feiwothree.coverscreen.a.e, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class HandlerC0005e extends Handler {
    private final /* synthetic */ InterfaceC0007g a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public HandlerC0005e(C0004d c0004d, InterfaceC0007g interfaceC0007g, String str) {
        this.a = interfaceC0007g;
        this.b = str;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        if (message.obj == null || this.a == null) {
            return;
        }
        InterfaceC0007g interfaceC0007g = this.a;
        Object obj = message.obj;
        String str = this.b;
    }
}
