package com.music.activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class ListMusicsActivity extends BaseActivity implements AdapterView.OnItemClickListener {
    public static ArrayList c = new ArrayList();
    public static ArrayList d = new ArrayList();
    public q b;
    private TextView e;
    private TextView f;
    private ListView g;
    private ProgressDialog h;
    private p i;
    private String l;
    private String m;
    private int n;
    private ScanSdReceiver o;
    private boolean j = false;
    private String[] k = {"播放", "分享", "删除"};
    private Handler p = new l(this);

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
    public class ScanSdReceiver extends BroadcastReceiver {
        public ScanSdReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (!"android.intent.action.MEDIA_SCANNER_STARTED".equals(action)) {
                if ("android.intent.action.MEDIA_SCANNER_FINISHED".equals(action)) {
                    new Thread(new s(ListMusicsActivity.this)).start();
                    new Thread(new o(ListMusicsActivity.this)).start();
                    return;
                }
                return;
            }
            if (ListMusicsActivity.this.h != null) {
                ListMusicsActivity.this.h.setMessage("正在扫描存储卡....");
            } else {
                ListMusicsActivity.this.h = ProgressDialog.show(context, "", "正在扫描存储卡....", false, true);
            }
        }
    }

    private void b() {
        this.e = (TextView) findViewById(R.id.title);
        this.e.setText("本地音乐");
        this.f = (TextView) findViewById(R.id.category_list_nodata);
        this.f.setText("本地媒体库中无音乐");
        this.g = (ListView) findViewById(R.id.goods_list);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("musicPlayFinish");
        this.i = new p(this, null);
        registerReceiver(this.i, intentFilter);
    }

    private void c() {
        new AlertDialog.Builder(this).setTitle("操作").setItems(this.k, new m(this)).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", "share");
        intent.putExtra("android.intent.extra.TEXT", "我最近百度音乐中搜到一首好听的音乐。\n ( 歌曲名称：" + this.l + " 演唱者：" + this.m + ")，希望你也和我一样，喜欢这首歌曲。");
        startActivity(Intent.createChooser(intent, getTitle()));
        this.j = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e() {
        c.clear();
        d.clear();
        c = com.music.c.e.b(this);
        if (c == null || c.size() == 0) {
            Message obtainMessage = this.p.obtainMessage();
            obtainMessage.what = 4;
            this.p.sendMessage(obtainMessage);
        } else if (c.size() > 0) {
            for (int i = 0; i < c.size(); i++) {
                d.add(false);
            }
            Message obtainMessage2 = this.p.obtainMessage();
            obtainMessage2.what = 7;
            this.p.sendMessage(obtainMessage2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void f() {
        if (this.b == null) {
            this.b = new q(this, this);
            this.g.setAdapter((ListAdapter) this.b);
        } else {
            this.b.notifyDataSetChanged();
        }
        this.g.setSelection(com.music.c.a.d);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a() {
        for (int i = 0; i < d.size(); i++) {
            d.set(i, false);
        }
        d.set(com.music.c.a.d, true);
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.music_down);
        b();
        this.g.setOnItemClickListener(this);
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        if (this.i != null) {
            unregisterReceiver(this.i);
        }
        if (this.o != null) {
            unregisterReceiver(this.o);
        }
        System.out.println("ListMusicsActivity destroy ");
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        Object obj = ((HashMap) c.get(i)).get("title");
        this.l = obj == null ? "" : obj.toString();
        Object obj2 = ((HashMap) c.get(i)).get("musicArtist");
        this.m = obj2 == null ? "" : obj2.toString();
        this.n = i;
        c();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        this.j = false;
        this.f.setVisibility(8);
        this.g.setVisibility(0);
        this.g.setSelection(com.music.c.a.d);
        if (this.o == null) {
            IntentFilter intentFilter = new IntentFilter("android.intent.action.MEDIA_SCANNER_STARTED");
            intentFilter.addAction("android.intent.action.MEDIA_SCANNER_FINISHED");
            intentFilter.addDataScheme("file");
            this.o = new ScanSdReceiver();
            registerReceiver(this.o, intentFilter);
        }
        if (c.size() != 0 && !com.music.c.a.f) {
            a();
            f();
        } else {
            com.music.c.a.f = false;
            this.h = ProgressDialog.show(this, "", "音乐获取中....", false, true);
            new Thread(new s(this)).start();
            new Thread(new o(this)).start();
        }
    }
}
