package com.music.activity;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.music.domain.MusicNetWorkInfo;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class f extends Handler {
    private int a(String str) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= com.music.c.m.a.size()) {
                return -1;
            }
            if (((MusicNetWorkInfo) com.music.c.m.a.get(i2)).musicUrl.equals(str)) {
                return i2;
            }
            i = i2 + 1;
        }
    }

    @Override // android.os.Handler
    public synchronized void handleMessage(Message message) {
        g gVar;
        TextView textView;
        TextView textView2;
        TextView textView3;
        g gVar2;
        Context context;
        View view;
        Context context2;
        g gVar3;
        Context context3;
        TextView textView4;
        TextView textView5;
        TextView textView6;
        ListView listView;
        g gVar4;
        g gVar5;
        g gVar6;
        TextView textView7;
        TextView textView8;
        ListView listView2;
        if (message.what == 1) {
            String str = (String) message.obj;
            int a = a(str);
            int i = message.arg1;
            int i2 = message.arg2;
            if (a != -1) {
                View view2 = (View) DownloadListActivity.c.get(Integer.valueOf(a));
                if (view2 != null) {
                    TextView textView9 = (TextView) view2.findViewById(R.id.music_time);
                    textView9.setVisibility(0);
                    ProgressBar progressBar = (ProgressBar) view2.findViewById(R.id.download_progress);
                    if (progressBar != null) {
                        if (i == i2) {
                            MusicNetWorkInfo musicNetWorkInfo = (MusicNetWorkInfo) com.music.c.m.a.get(a);
                            System.out.println("fileSize = " + i2);
                            if (DownloadListActivity.b != null) {
                                DownloadListActivity.b.d(str);
                                DownloadListActivity.b.c(str);
                            }
                            com.music.c.m.b.remove(str);
                            com.music.c.m.a.remove(a);
                            if (com.music.c.m.a.size() == 0) {
                                textView7 = DownloadListActivity.h;
                                textView7.setVisibility(0);
                                textView8 = DownloadListActivity.h;
                                textView8.setText("下载列表中无音乐");
                                listView2 = DownloadListActivity.e;
                                listView2.setVisibility(8);
                            } else {
                                gVar5 = DownloadListActivity.f;
                                if (gVar5 != null) {
                                    gVar6 = DownloadListActivity.f;
                                    gVar6.notifyDataSetChanged();
                                }
                            }
                            if (i2 == 0) {
                                com.music.c.j.a(com.music.c.a.g, false, 0, R.drawable.f032, String.valueOf(musicNetWorkInfo.musicName) + "  无法下载，请先检查网络是否正常 。");
                            } else {
                                new u(musicNetWorkInfo).start();
                            }
                        } else {
                            progressBar.setVisibility(0);
                            progressBar.setMax(i2);
                            progressBar.setProgress(i);
                            textView9.setText(String.valueOf((i * 100) / i2) + "%");
                            textView9.setTag("onRunning");
                        }
                    }
                } else if (i == i2) {
                    MusicNetWorkInfo musicNetWorkInfo2 = (MusicNetWorkInfo) com.music.c.m.a.get(a);
                    System.out.println("位置" + a + "中的音乐在没进入下载列表前已经被下载完了。");
                    System.out.println("fileSize = " + i2);
                    if (DownloadListActivity.b != null) {
                        DownloadListActivity.b.d(str);
                        DownloadListActivity.b.c(str);
                    }
                    com.music.c.m.b.remove(str);
                    com.music.c.m.a.remove(a);
                    gVar3 = DownloadListActivity.f;
                    if (gVar3 != null) {
                        gVar4 = DownloadListActivity.f;
                        gVar4.notifyDataSetChanged();
                    }
                    if (com.music.c.m.a.size() == 0) {
                        textView4 = DownloadListActivity.h;
                        if (textView4 != null) {
                            textView5 = DownloadListActivity.h;
                            textView5.setVisibility(0);
                            textView6 = DownloadListActivity.h;
                            textView6.setText("下载列表中无音乐");
                            listView = DownloadListActivity.e;
                            listView.setVisibility(8);
                        }
                    }
                    if (i2 == 0) {
                        context3 = DownloadListActivity.k;
                        com.music.c.j.a(context3, false, 0, R.drawable.f032, String.valueOf(musicNetWorkInfo2.musicName) + "  无法下载，请先检查网络是否正常 。");
                    } else {
                        new u(musicNetWorkInfo2).start();
                    }
                }
            }
        } else if (message.what == 2) {
            String str2 = (String) message.obj;
            System.out.println("暂停 url" + str2);
            int a2 = a(str2);
            System.out.println("(点击暂停  msg.what == 2  positon = " + a2);
            TextView textView10 = (TextView) ((View) DownloadListActivity.c.get(Integer.valueOf(a2))).findViewById(R.id.music_time);
            textView10.setText("暂停");
            textView10.setTag("onPause");
        } else if (message.what == 3) {
            String str3 = (String) message.obj;
            context = DownloadListActivity.k;
            if (context != null) {
                context2 = DownloadListActivity.k;
                com.music.c.j.a(context2, false, 0, R.drawable.f032, "下载出异常了");
            }
            int a3 = a(str3);
            System.out.println("(下载处异常了   msg.what == 3  positon = " + a3);
            if (a3 != -1 && (view = (View) DownloadListActivity.c.get(Integer.valueOf(a3))) != null) {
                TextView textView11 = (TextView) view.findViewById(R.id.music_time);
                textView11.setText("暂停");
                textView11.setTag("onPause");
            }
        } else if (message.what == 4) {
            System.out.println("下载的进度比文件还大");
            String str4 = (String) message.obj;
            int a4 = a(str4);
            System.out.println("(下载进度超过了文件大小     msg.what == 4  positon = " + a4);
            if (DownloadListActivity.b != null) {
                DownloadListActivity.b.d(str4);
                DownloadListActivity.b.c(str4);
            }
            com.music.c.m.b.remove(str4);
            com.music.c.m.a.remove(a4);
            gVar = DownloadListActivity.f;
            if (gVar != null) {
                gVar2 = DownloadListActivity.f;
                gVar2.notifyDataSetChanged();
            }
            if (com.music.c.m.a.size() == 0) {
                textView = DownloadListActivity.h;
                if (textView != null) {
                    textView2 = DownloadListActivity.h;
                    textView2.setVisibility(0);
                    textView3 = DownloadListActivity.h;
                    textView3.setText("下载列表中无音乐");
                }
            }
        }
    }
}
