package com.music.a;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.music.activity.R;
import com.music.c.m;
import com.music.c.n;
import com.music.domain.MusicNetWorkInfo;
import com.music.domain.ObjectInfo;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class c extends BaseAdapter {
    private Context a;
    private ProgressDialog d;
    private Handler e;
    private ArrayList b = new ArrayList();
    private ArrayList c = new ArrayList();
    private final int f = -1;
    private final int g = -2;
    private final int h = 2;
    private final int i = -3;
    private final int j = -4;
    private final int k = -5;
    private Handler l = new d(this);
    private String[] m = {"下载"};
    private String n = "";
    private String o = "";
    private String p = "";
    private String q = "";
    private String r = " ";
    private String s = "";

    public c(Context context, Handler handler, ArrayList arrayList) {
        this.a = context;
        this.e = handler;
        if (arrayList != null) {
            this.b.clear();
            this.b.addAll(arrayList);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void a(View view, String str) {
        new AlertDialog.Builder(this.a).setTitle(str).setItems(this.m, new f(this, view, str)).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean a(ArrayList arrayList) {
        for (int i = 0; i < arrayList.size(); i++) {
            String str = ((MusicNetWorkInfo) arrayList.get(i)).musicUrl;
            if (m.a.size() == 0) {
                new com.music.b.b.a(this.a).a();
            }
            Iterator it = m.a.iterator();
            while (it.hasNext()) {
                if (((MusicNetWorkInfo) it.next()).musicUrl.equals(str)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void a() {
        this.c.clear();
        this.s = com.music.service.a.a(this.a, this.n, "gb2312");
        if (TextUtils.isEmpty(this.s) || this.s.contains("error：")) {
            this.l.sendEmptyMessage(-3);
            return;
        }
        if (this.s.contains("<count>0</count>")) {
            this.l.sendEmptyMessage(-5);
            return;
        }
        this.c = n.a(this.a, this.s, MusicNetWorkInfo.class, "url", new String[]{"encode", "decode", "lrcid"}, false);
        if (this.c == null || this.c.size() <= 0) {
            return;
        }
        for (int i = 0; i < this.c.size(); i++) {
            String str = ((MusicNetWorkInfo) this.c.get(i)).encode;
            String str2 = ((MusicNetWorkInfo) this.c.get(i)).decode;
            String str3 = ((MusicNetWorkInfo) this.c.get(i)).lrcid;
            if (str3.length() > 2) {
                this.p = "http://box.zhangmen.baidu.com/bdlrc/" + str3.substring(0, str3.length() - 2) + "/" + str3 + ".lrc";
            } else {
                this.p = "http://box.zhangmen.baidu.com/bdlrc/0/" + str3 + ".lrc";
            }
            int lastIndexOf = str.lastIndexOf("/");
            if (lastIndexOf != -1) {
                this.o = String.valueOf(str.substring(0, lastIndexOf + 1)) + str2;
            }
            ((MusicNetWorkInfo) this.c.get(i)).musicUrl = this.o;
            ((MusicNetWorkInfo) this.c.get(i)).lrcUrl = this.p;
            ((MusicNetWorkInfo) this.c.get(i)).musicName = this.q;
            ((MusicNetWorkInfo) this.c.get(i)).musicSinger = this.r;
        }
    }

    public void a(View view) {
        com.a.a.a aVar = (com.a.a.a) m.b.get(this.o);
        if (aVar == null) {
            aVar = new com.a.a.a();
        }
        aVar.a(this.o, this.p, String.valueOf(this.q) + "-" + this.r, 1, this.a, this.e, this.c);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.b == null || this.b.size() <= 0) {
            return 0;
        }
        return this.b.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        g gVar;
        Object obj;
        if (view == null) {
            view = LayoutInflater.from(this.a).inflate(R.layout.music_item, (ViewGroup) null);
            gVar = new g();
            gVar.b = (TextView) view.findViewById(R.id.music_name);
            gVar.a = (TextView) view.findViewById(R.id.music_singer);
            gVar.c = (TextView) view.findViewById(R.id.music_time);
            gVar.e = (ProgressBar) view.findViewById(R.id.download_progress);
            gVar.d = (ImageView) view.findViewById(R.id.music_pic);
            gVar.c.setVisibility(8);
            gVar.e.setVisibility(8);
            view.setTag(gVar);
        } else {
            gVar = (g) view.getTag();
        }
        if (this.b != null && i < this.b.size() && (obj = this.b.get(i)) != null && (obj instanceof ObjectInfo)) {
            ObjectInfo objectInfo = (ObjectInfo) obj;
            if (!TextUtils.isEmpty(objectInfo.name)) {
                String replace = objectInfo.name.replace("$$", ",").replace("$$$$", ",");
                if (!TextUtils.isEmpty(replace)) {
                    String[] split = replace.split(",");
                    String str = "";
                    String str2 = "";
                    if (split != null) {
                        if (split.length > 1) {
                            str = split[0];
                            str2 = split[1];
                        } else if (split.length == 1) {
                            str = split[0];
                        }
                        gVar.b.setText(str);
                        gVar.a.setText(str2);
                    }
                    view.setOnClickListener(new e(this, objectInfo, gVar));
                }
            }
        }
        return view;
    }
}
