package com.music.activity;

import android.os.Handler;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class s implements Runnable {
    final /* synthetic */ ListMusicsActivity a;
    private boolean b;

    public s(ListMusicsActivity listMusicsActivity) {
        this.a = listMusicsActivity;
        this.b = false;
    }

    public s(ListMusicsActivity listMusicsActivity, boolean z) {
        this.a = listMusicsActivity;
        this.b = false;
        this.b = z;
    }

    @Override // java.lang.Runnable
    public void run() {
        Handler handler;
        if (!this.b) {
            this.a.e();
            return;
        }
        this.a.d();
        handler = this.a.p;
        handler.sendEmptyMessage(1);
    }
}
