package com.music.domain;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class ObjectInfo {
    public String id;
    public String musicUrl = "";
    public String name;

    public String toString() {
        return "ObjectInfo [id=" + this.id + ", name=" + this.name + "]";
    }
}
