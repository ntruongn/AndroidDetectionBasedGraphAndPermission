package com.umeng.common.net;

import android.app.Notification;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class d {
    b a;
    Notification b;
    int c;
    int d;
    f e;
    long[] f = new long[3];

    public d(f fVar, int i) {
        this.c = i;
        this.e = fVar;
    }

    public void a() {
        Map map;
        map = DownloadingService.i;
        map.put(Integer.valueOf(this.c), this);
    }

    public void b() {
        Map map;
        Map map2;
        map = DownloadingService.i;
        if (map.containsKey(Integer.valueOf(this.c))) {
            map2 = DownloadingService.i;
            map2.remove(Integer.valueOf(this.c));
        }
    }
}
