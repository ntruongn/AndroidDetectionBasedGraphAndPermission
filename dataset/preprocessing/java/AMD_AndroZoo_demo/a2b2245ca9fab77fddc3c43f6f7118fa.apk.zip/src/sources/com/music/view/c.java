package com.music.view;

import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class c implements View.OnClickListener {
    final /* synthetic */ a a;
    private final /* synthetic */ a b;
    private final /* synthetic */ d c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(a aVar, a aVar2, d dVar) {
        this.a = aVar;
        this.b = aVar2;
        this.c = dVar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        this.b.dismiss();
        if (this.c != null) {
            this.c.a();
        }
    }
}
