package com.music.b.b;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.music.c.m;
import com.music.domain.MusicNetWorkInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class a {
    private com.music.b.a.a a;
    private int b = 3;
    private String c = "download.db";
    private SQLiteDatabase d = null;

    public a(Context context) {
        this.a = new com.music.b.a.a(context, this.c, null, this.b);
    }

    public synchronized void a() {
        this.d = this.a.getWritableDatabase();
        Cursor rawQuery = this.d.rawQuery("select encode,decode,lrcid,musicName,musicSinger,musicUrl, lrcUrl from download_music_list ", null);
        while (rawQuery.moveToNext()) {
            m.a.add(new MusicNetWorkInfo(rawQuery.getString(0), rawQuery.getString(1), rawQuery.getString(2), rawQuery.getString(3), rawQuery.getString(4), rawQuery.getString(5), rawQuery.getString(6)));
        }
        rawQuery.close();
        this.d.close();
    }

    public synchronized void a(int i, int i2, String str) {
        this.d = this.a.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("compelete_size", Integer.valueOf(i2));
        System.out.println("更新download_info数据影响的行数：" + this.d.update("download_info", contentValues, "thread_id=? and url=?", new String[]{new StringBuilder(String.valueOf(i)).toString(), str}));
        this.d.close();
    }

    public synchronized void a(MusicNetWorkInfo musicNetWorkInfo) {
        this.d = this.a.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("encode", musicNetWorkInfo.encode);
        contentValues.put("decode", musicNetWorkInfo.decode);
        contentValues.put("lrcid", musicNetWorkInfo.lrcid);
        contentValues.put("musicName", musicNetWorkInfo.musicName);
        contentValues.put("musicSinger", musicNetWorkInfo.musicSinger);
        contentValues.put("musicUrl", musicNetWorkInfo.musicUrl);
        contentValues.put("lrcUrl", musicNetWorkInfo.lrcUrl);
        this.d.insert("download_music_list", null, contentValues);
        this.d.close();
    }

    public synchronized void a(List list) {
        this.d = this.a.getWritableDatabase();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            com.music.b.c.a aVar = (com.music.b.c.a) it.next();
            this.d.execSQL("insert into download_info(thread_id,start_pos, end_pos,compelete_size,url) values (?,?,?,?,?)", new Object[]{Integer.valueOf(aVar.a()), Integer.valueOf(aVar.b()), Integer.valueOf(aVar.c()), Integer.valueOf(aVar.d()), aVar.e()});
        }
        this.d.close();
    }

    public synchronized boolean a(String str) {
        boolean z;
        synchronized (this) {
            this.d = this.a.getWritableDatabase();
            Cursor rawQuery = this.d.rawQuery("select count(*)  from download_info where url=?", new String[]{str});
            rawQuery.moveToFirst();
            int i = rawQuery.getInt(0);
            rawQuery.close();
            this.d.close();
            z = i == 0;
        }
        return z;
    }

    public synchronized List b(String str) {
        ArrayList arrayList;
        arrayList = new ArrayList();
        this.d = this.a.getWritableDatabase();
        Cursor rawQuery = this.d.rawQuery("select thread_id, start_pos, end_pos,compelete_size,url from download_info where url=?", new String[]{str});
        while (rawQuery.moveToNext()) {
            arrayList.add(new com.music.b.c.a(rawQuery.getInt(0), rawQuery.getInt(1), rawQuery.getInt(2), rawQuery.getInt(3), rawQuery.getString(4)));
        }
        rawQuery.close();
        this.d.close();
        return arrayList;
    }

    public synchronized void c(String str) {
        this.d = this.a.getWritableDatabase();
        System.out.println("删除download_info数据影响的行数：" + this.d.delete("download_info", "url=?", new String[]{str}));
        this.d.close();
    }

    public synchronized void d(String str) {
        this.d = this.a.getWritableDatabase();
        System.out.println("删除download_music_list数据影响的行数：" + this.d.delete("download_music_list", "musicUrl=?", new String[]{str}));
        this.d.close();
    }
}
