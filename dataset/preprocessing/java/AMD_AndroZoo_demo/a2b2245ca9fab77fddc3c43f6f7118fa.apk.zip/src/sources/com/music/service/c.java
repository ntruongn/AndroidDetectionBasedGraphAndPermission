package com.music.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class c extends BroadcastReceiver {
    final /* synthetic */ MusicService a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(MusicService musicService) {
        this.a = musicService;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        MediaPlayer mediaPlayer;
        MediaPlayer mediaPlayer2;
        if (intent.getAction().equals("checkMusic")) {
            int i = intent.getExtras().getInt("length");
            mediaPlayer = this.a.h;
            if (mediaPlayer != null) {
                mediaPlayer2 = this.a.h;
                mediaPlayer2.seekTo(i);
            }
        }
    }
}
