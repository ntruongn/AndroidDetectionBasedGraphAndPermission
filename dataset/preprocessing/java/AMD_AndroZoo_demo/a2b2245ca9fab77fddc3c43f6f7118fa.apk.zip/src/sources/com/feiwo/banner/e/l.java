package com.feiwo.banner.e;

import android.content.Context;
import android.text.TextUtils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class l implements Runnable {
    private URL a = null;
    private k b;
    private String c;
    private String d;
    private Context e;

    public final void a(Context context, String str, String str2, String str3) {
        this.e = context;
        this.c = str2;
        this.d = str3;
        try {
            this.a = new URL(str);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    public final void a(k kVar) {
        this.b = kVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        HttpURLConnection httpURLConnection;
        if (this.a == null) {
            throw new IllegalArgumentException("URL must be init!");
        }
        try {
            if (e.a(this.e) == 12) {
                httpURLConnection = (HttpURLConnection) this.a.openConnection(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(android.net.Proxy.getDefaultHost(), android.net.Proxy.getDefaultPort())));
            } else {
                httpURLConnection = (HttpURLConnection) this.a.openConnection();
            }
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setRequestProperty("content-type", "application/x-www-form-urlencoded");
            httpURLConnection.addRequestProperty("appkey", this.c);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setConnectTimeout(20000);
            httpURLConnection.setReadTimeout(10000);
            new StringBuilder("json > ").append(this.d);
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(httpURLConnection.getOutputStream()));
            bufferedWriter.write(com.feiwo.banner.f.f.a(this.d, com.feiwo.banner.f.f.a(this.c), false));
            bufferedWriter.close();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                } else {
                    sb.append(readLine);
                }
            }
            bufferedReader.close();
            if (TextUtils.isEmpty(sb.toString())) {
                this.b.a(false, null);
            } else {
                new StringBuilder("result > ").append(sb.toString());
                this.b.a(true, com.feiwo.banner.f.f.a(sb.toString(), com.feiwo.banner.f.f.a(this.c)));
            }
        } catch (SocketException e) {
            e.printStackTrace();
            this.b.a(false, "SocketTimeoutException");
        } catch (SocketTimeoutException e2) {
            e2.printStackTrace();
            this.b.a(false, "SocketTimeoutException");
        } catch (Exception e3) {
            e3.printStackTrace();
            this.b.a(false, "Exception");
        }
    }
}
