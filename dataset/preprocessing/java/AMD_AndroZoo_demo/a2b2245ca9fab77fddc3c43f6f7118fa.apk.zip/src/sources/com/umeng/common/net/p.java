package com.umeng.common.net;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class p {
    public static PendingIntent a(Context context, String str) {
        Intent intent = new Intent(context, (Class<?>) DownloadingService.class);
        intent.putExtra("com.umeng.broadcast.download.msg", str);
        return PendingIntent.getService(context, str.hashCode(), intent, 134217728);
    }

    public static String a(int i, String str) {
        if (i == 0) {
            return null;
        }
        return new StringBuilder(String.valueOf(i)).toString() + ":" + str;
    }
}
