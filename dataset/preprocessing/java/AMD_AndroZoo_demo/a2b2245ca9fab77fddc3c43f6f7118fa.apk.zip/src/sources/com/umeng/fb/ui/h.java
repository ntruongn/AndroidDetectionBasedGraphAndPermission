package com.umeng.fb.ui;

import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class h implements View.OnClickListener {
    final /* synthetic */ FeedbackConversations a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h(FeedbackConversations feedbackConversations) {
        this.a = feedbackConversations;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        com.umeng.fb.c.a.a(this.a);
    }
}
