package com.feiwo.banner.e;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.os.Environment;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class e {
    private static e b;
    private Context a;

    public e() {
    }

    public e(Context context) {
        this.a = context;
    }

    public static int a(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivityManager == null) {
            return 0;
        }
        NetworkInfo[] allNetworkInfo = connectivityManager.getAllNetworkInfo();
        if (allNetworkInfo != null) {
            int length = allNetworkInfo.length;
            for (int i = 0; i < length; i++) {
                if (allNetworkInfo[i].getState() == NetworkInfo.State.CONNECTED) {
                    if (allNetworkInfo[i].getTypeName().equalsIgnoreCase("MOBILE")) {
                        return (Proxy.getDefaultHost() == null || Proxy.getDefaultHost().equals("")) ? 11 : 12;
                    }
                    return 10;
                }
            }
        }
        return 0;
    }

    public static e b(Context context) {
        if (b == null) {
            b = new e(context);
        }
        return b;
    }

    public static boolean b() {
        return Environment.getExternalStorageState().equals("mounted");
    }

    public static String c(String str) {
        return str.replace(":", "_").replace("/", "_");
    }

    public static boolean d(String str) {
        return new File(str).exists();
    }

    public String a() {
        String absolutePath = this.a.getCacheDir().getAbsolutePath();
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        return absolutePath;
    }

    public String a(Context context, String str) {
        if (b()) {
            return a(str);
        }
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(context.getFilesDir().getAbsolutePath());
        if (!str.startsWith("/")) {
            stringBuffer.append("/");
        }
        stringBuffer.append(str);
        File file = new File(stringBuffer.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        return stringBuffer.toString();
    }

    public String a(String str) {
        if (!b()) {
            return a();
        }
        String str2 = Environment.getExternalStorageDirectory() + str;
        File file = new File(str2);
        if (file.exists()) {
            return str2;
        }
        file.mkdirs();
        return str2;
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x00a3 A[Catch: IOException -> 0x00a7, TRY_LEAVE, TryCatch #3 {IOException -> 0x00a7, blocks: (B:52:0x009e, B:46:0x00a3), top: B:51:0x009e }] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x009e A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean a(java.lang.String r9, java.lang.String r10) {
        /*
            Method dump skipped, instructions count: 213
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.feiwo.banner.e.e.a(java.lang.String, java.lang.String):boolean");
    }

    public InputStream b(String str, String str2) {
        FileInputStream fileInputStream;
        String str3 = String.valueOf(b(str)) + c(str2);
        if (d(str3)) {
            try {
                fileInputStream = new FileInputStream(new File(str3));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                return null;
            }
        } else {
            fileInputStream = null;
        }
        return fileInputStream;
    }

    public String b(String str) {
        return a(str) != null ? a(str) : a();
    }
}
