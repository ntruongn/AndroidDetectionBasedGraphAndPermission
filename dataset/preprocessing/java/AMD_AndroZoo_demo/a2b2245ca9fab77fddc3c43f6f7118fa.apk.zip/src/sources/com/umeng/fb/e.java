package com.umeng.fb;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class e implements Comparable {
    public f b;
    public String c;
    public b d;
    public b e;
    public String a = e.class.getSimpleName();
    public List f = new ArrayList();

    public e(JSONArray jSONArray) {
        this.b = f.Normal;
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                b bVar = new b(jSONArray.getJSONObject(i));
                if (bVar.f == c.Fail) {
                    this.b = f.HasFail;
                }
                this.f.add(bVar);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        if (this.f.isEmpty()) {
            return;
        }
        this.d = (b) this.f.get(0);
        this.e = (b) this.f.get(this.f.size() - 1);
        this.c = this.d.c;
        if (this.f.size() == 1) {
            if (((b) this.f.get(0)).f == c.Fail) {
                this.b = f.PureFail;
            } else if (((b) this.f.get(0)).f == c.Sending) {
                this.b = f.PureSending;
            }
        }
    }

    @Override // java.lang.Comparable
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public int compareTo(e eVar) {
        Date date = this.e.d;
        Date date2 = eVar.e.d;
        if (date2 == null || date == null || date.equals(date2)) {
            return 0;
        }
        return date.after(date2) ? -1 : 1;
    }

    public b a(int i) {
        if (i < 0 || i > this.f.size() - 1) {
            return null;
        }
        return (b) this.f.get(i);
    }

    public void b(int i) {
        if (i < 0 || i > this.f.size() - 1) {
            return;
        }
        this.f.remove(i);
    }
}
