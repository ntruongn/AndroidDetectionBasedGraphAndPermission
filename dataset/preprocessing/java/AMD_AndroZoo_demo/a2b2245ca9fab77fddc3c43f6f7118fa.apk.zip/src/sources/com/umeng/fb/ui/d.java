package com.umeng.fb.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.Map;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class d implements View.OnClickListener {
    final /* synthetic */ SendFeedback a;

    private d(SendFeedback sendFeedback) {
        this.a = sendFeedback;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ d(SendFeedback sendFeedback, d dVar) {
        this(sendFeedback);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        EditText editText;
        String str;
        Spinner spinner;
        int i;
        Spinner spinner2;
        com.umeng.fb.c.b bVar;
        JSONObject jSONObject;
        JSONObject jSONObject2;
        JSONObject jSONObject3;
        EditText editText2;
        com.umeng.fb.c.b bVar2;
        Map map;
        JSONObject jSONObject4;
        Map map2;
        JSONObject jSONObject5;
        JSONObject jSONObject6;
        Map map3;
        Map map4;
        Spinner spinner3;
        Spinner spinner4;
        EditText editText3;
        int i2 = -1;
        editText = this.a.f;
        if (editText != null) {
            editText3 = this.a.f;
            str = editText3.getText().toString();
        } else {
            str = null;
        }
        if (com.umeng.common.b.b.c(str)) {
            Toast.makeText(this.a, this.a.getString(com.umeng.fb.b.e.a(this.a)), 0).show();
            return;
        }
        if (str.length() > 140) {
            Toast.makeText(this.a, this.a.getString(com.umeng.fb.b.e.b(this.a)), 0).show();
            return;
        }
        spinner = this.a.d;
        if (spinner != null) {
            spinner4 = this.a.d;
            i = spinner4.getSelectedItemPosition();
        } else {
            i = -1;
        }
        spinner2 = this.a.e;
        if (spinner2 != null) {
            spinner3 = this.a.e;
            i2 = spinner3.getSelectedItemPosition();
        }
        bVar = this.a.j;
        if (bVar != null) {
            bVar2 = this.a.j;
            bVar2.a(this.a);
            this.a.k = com.umeng.fb.c.a.c;
            this.a.l = com.umeng.fb.c.a.d;
            JSONObject jSONObject7 = new JSONObject();
            JSONObject jSONObject8 = new JSONObject();
            map = this.a.k;
            if (map != null) {
                map4 = this.a.k;
                jSONObject4 = SendFeedback.a(map4);
            } else {
                jSONObject4 = null;
            }
            map2 = this.a.l;
            if (map2 != null) {
                map3 = this.a.l;
                jSONObject5 = SendFeedback.a(map3);
            } else {
                jSONObject5 = null;
            }
            if (jSONObject4 != null) {
                try {
                    jSONObject7.put("Json_OtherAttrContact", jSONObject4);
                } catch (Exception e) {
                }
            }
            if (jSONObject5 != null) {
                jSONObject8.put("Json_OtherAttrRemark", jSONObject5);
            }
            SharedPreferences.Editor edit = this.a.getSharedPreferences("UmengFb_Nums", 0).edit();
            edit.putInt("ageGroup", i);
            edit.putInt("sex", i2);
            if (jSONObject7 != null && jSONObject7.length() > 0) {
                edit.putString("OtherAttrContext", jSONObject7.toString());
            }
            if (jSONObject8 != null && jSONObject8.length() > 0) {
                edit.putString("OtherAttrRemark", jSONObject8.toString());
            }
            edit.commit();
            try {
                this.a.m = com.umeng.fb.c.d.a(this.a, str, i, i2, jSONObject4, jSONObject5);
            } catch (Exception e2) {
                if (com.umeng.fb.g.c) {
                    e2.printStackTrace();
                }
                SendFeedback sendFeedback = this.a;
                jSONObject6 = this.a.m;
                com.umeng.fb.c.e.d(sendFeedback, jSONObject6);
                return;
            }
        } else {
            SharedPreferences.Editor edit2 = this.a.getSharedPreferences("UmengFb_Nums", 0).edit();
            edit2.putInt("ageGroup", i);
            edit2.putInt("sex", i2);
            edit2.commit();
            try {
                this.a.m = com.umeng.fb.c.d.a(this.a, str, i, i2, null, null);
            } catch (Exception e3) {
                if (com.umeng.fb.g.c) {
                    e3.printStackTrace();
                }
                SendFeedback sendFeedback2 = this.a;
                jSONObject = this.a.m;
                com.umeng.fb.c.e.d(sendFeedback2, jSONObject);
                return;
            }
        }
        SendFeedback sendFeedback3 = this.a;
        jSONObject2 = this.a.m;
        com.umeng.fb.c.e.c(sendFeedback3, jSONObject2);
        jSONObject3 = this.a.m;
        SendFeedback.b.submit(new com.umeng.fb.a.f(jSONObject3, this.a));
        this.a.startActivity(new Intent(this.a, (Class<?>) FeedbackConversations.class).setFlags(131072));
        InputMethodManager inputMethodManager = (InputMethodManager) this.a.getSystemService("input_method");
        editText2 = this.a.f;
        inputMethodManager.hideSoftInputFromWindow(editText2.getWindowToken(), 0);
        this.a.finish();
    }
}
