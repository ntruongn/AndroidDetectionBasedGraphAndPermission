package com.feiwothree.coverscreen;

import android.content.Context;
import android.content.Intent;
import com.feiwothree.coverscreen.a.C0001a;
import com.feiwothree.coverscreen.a.C0002b;
import com.feiwothree.coverscreen.a.C0009i;
import com.feiwothree.coverscreen.a.C0010j;
import com.feiwothree.coverscreen.a.I;
import com.feiwothree.coverscreen.a.J;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class CoverAdComponent extends AdComponent {
    private static CoverAdComponent h;
    private List c;
    private Date d;
    private int e;
    private boolean f;
    private long g;

    private CoverAdComponent(Context context, String str) {
        super(context, str);
        this.d = null;
        this.e = 0;
        this.f = false;
    }

    private int a(Context context) {
        if (context == null || !C0009i.a(context)) {
            this.g = new Date().getTime();
            this.f = true;
            return 2;
        }
        if (this.c == null || this.c.size() == 0) {
            this.g = new Date().getTime();
            this.f = true;
            a(true);
            return 2;
        }
        if (this.e >= this.c.size()) {
            this.e = 0;
        }
        if (!a(this.c, this.e)) {
            return 4;
        }
        a(true);
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static List b(JSONArray jSONArray) {
        if (jSONArray == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                C0010j a = C0010j.a(jSONArray.getJSONObject(i));
                if (a != null && a.a() > 0) {
                    arrayList.add(a);
                }
            } catch (Exception e) {
                return null;
            }
        }
        return arrayList;
    }

    public static void close(Context context) {
        context.sendBroadcast(new Intent("broadcast.route.control.close"));
    }

    public static void destory(Context context) {
        if (h == null || context == null) {
            return;
        }
        close(context);
        h.a();
    }

    public static CoverAdComponent getInstance() {
        return h;
    }

    public static CoverAdComponent init(Context context, String str) {
        if (h != null) {
            return h;
        }
        if (context == null) {
            throw new IllegalArgumentException("context is null");
        }
        if (str == null || str.trim().length() < 8) {
            throw new IllegalArgumentException("appkey is error");
        }
        CoverAdComponent coverAdComponent = new CoverAdComponent(context, str);
        h = coverAdComponent;
        return coverAdComponent;
    }

    public static void setShowAtScreenOn(boolean z) {
        if (h != null) {
            a = z;
            I.a(h.e(), "DP_FEIWO", "showatscreenonuser", z);
        }
    }

    public static int showAd(Context context) {
        if (h == null) {
            return 1;
        }
        try {
            return h.a(context);
        } catch (Exception e) {
            return 5;
        }
    }

    @Override // com.feiwothree.coverscreen.AdComponent
    protected final void a() {
        super.a();
        h = null;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(int i) {
        this.e = i;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(String str) {
        if (J.a(str) || this.c == null) {
            return;
        }
        Iterator it = this.c.iterator();
        while (it.hasNext()) {
            if (str.equals(((C0010j) it.next()).e())) {
                it.remove();
            }
        }
    }

    @Override // com.feiwothree.coverscreen.AdComponent
    protected final void b() {
        if (this.b) {
            e();
            return;
        }
        if (this.d != null && this.d.getTime() > new Date().getTime() && this.c != null && this.c.size() > 0) {
            e();
            return;
        }
        this.b = true;
        JSONObject a = C0001a.a(e(), "1.9");
        com.feiwothree.coverscreen.a.u uVar = new com.feiwothree.coverscreen.a.u();
        uVar.a(e(), C0002b.e(), d(), a.toString());
        uVar.a(new h(this));
        e();
        com.feiwothree.coverscreen.a.s.a().a(uVar);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.feiwothree.coverscreen.AdComponent
    public final void c() {
        super.c();
        if (this.f) {
            this.f = false;
            if (new Date().getTime() - this.g <= 10000) {
                a(e());
            }
        }
    }
}
