package com.feiwothree.coverscreen.a;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* renamed from: com.feiwothree.coverscreen.a.f, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class RunnableC0006f implements Runnable {
    private /* synthetic */ C0004d a;
    private final /* synthetic */ Context b;
    private final /* synthetic */ String c;
    private final /* synthetic */ String d;
    private final /* synthetic */ boolean e;
    private final /* synthetic */ Handler f;

    /* JADX INFO: Access modifiers changed from: package-private */
    public RunnableC0006f(C0004d c0004d, Context context, String str, String str2, boolean z, Handler handler) {
        this.a = c0004d;
        this.b = context;
        this.c = str;
        this.d = str2;
        this.e = z;
        this.f = handler;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Map map;
        Drawable a = this.a.a(this.b, this.c, this.d);
        new StringBuilder("loadDrawable from method: getDrawableFromCache, drawable: ").append(a).append(", url: ").append(this.c);
        if (a == null) {
            try {
                new StringBuilder("save to file start: ").append(this.d).append(", url: ").append(this.c);
                C0004d c0004d = this.a;
                Context context = this.b;
                C0004d.a(this.c, this.d);
                a = this.a.a(this.b, this.c, this.d);
            } catch (IOException e) {
                a = null;
                new StringBuilder("save to file failed: ").append(this.d).append(", url: ").append(this.c);
            }
        }
        if (this.e && a != null) {
            map = this.a.c;
            map.put(this.c, new SoftReference(a));
        }
        this.f.sendMessage(this.f.obtainMessage(0, a));
    }
}
