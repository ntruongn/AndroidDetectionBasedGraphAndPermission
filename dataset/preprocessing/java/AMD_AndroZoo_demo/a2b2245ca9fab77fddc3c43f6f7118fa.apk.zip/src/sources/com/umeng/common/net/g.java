package com.umeng.common.net;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import java.text.SimpleDateFormat;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class g {
    private static final String a = g.class.getName();
    private static Context b;
    private h c;

    private g() {
        this.c = new h(this, b);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ g(g gVar) {
        this();
    }

    public static g a(Context context) {
        if (b == null && context == null) {
            throw new NullPointerException();
        }
        if (b == null) {
            b = context;
        }
        return i.a;
    }

    public void a(int i) {
        try {
            Date date = new Date(new Date().getTime() - (i * 1000));
            this.c.getWritableDatabase().execSQL(" DELETE FROM umeng_download_task_list WHERE strftime('yyyy-MM-dd HH:mm:ss', last_modified)<=strftime('yyyy-MM-dd HH:mm:ss', '" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date) + "')");
            com.umeng.common.a.c(a, "clearOverdueTasks(" + i + ") remove all tasks before " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date));
        } catch (Exception e) {
            com.umeng.common.a.b(a, e.getMessage());
        }
    }

    public void a(String str, String str2, int i) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("progress", Integer.valueOf(i));
        contentValues.put("last_modified", com.umeng.common.b.b.a());
        this.c.getWritableDatabase().update("umeng_download_task_list", contentValues, "cp=? and url=?", new String[]{str, str2});
        com.umeng.common.a.c(a, "updateProgress(" + str + ", " + str2 + ", " + i + ")");
    }

    public boolean a(String str, String str2) {
        Exception e;
        boolean z;
        ContentValues contentValues = new ContentValues();
        contentValues.put("cp", str);
        contentValues.put("url", str2);
        contentValues.put("progress", (Integer) 0);
        contentValues.put("last_modified", com.umeng.common.b.b.a());
        try {
            Cursor query = this.c.getReadableDatabase().query("umeng_download_task_list", new String[]{"progress"}, "cp=? and url=?", new String[]{str, str2}, null, null, null, "1");
            if (query.getCount() > 0) {
                com.umeng.common.a.c(a, "insert(" + str + ", " + str2 + "):  already exists in the db. Insert is cancelled.");
                z = false;
            } else {
                long insert = this.c.getWritableDatabase().insert("umeng_download_task_list", null, contentValues);
                boolean z2 = insert != -1;
                try {
                    com.umeng.common.a.c(a, "insert(" + str + ", " + str2 + "): rowid=" + insert);
                    z = z2;
                } catch (Exception e2) {
                    z = z2;
                    e = e2;
                    com.umeng.common.a.c(a, "insert(" + str + ", " + str2 + "): " + e.getMessage(), e);
                    return z;
                }
            }
            try {
                query.close();
            } catch (Exception e3) {
                e = e3;
                com.umeng.common.a.c(a, "insert(" + str + ", " + str2 + "): " + e.getMessage(), e);
                return z;
            }
        } catch (Exception e4) {
            e = e4;
            z = false;
        }
        return z;
    }

    public void finalize() {
        this.c.close();
    }
}
