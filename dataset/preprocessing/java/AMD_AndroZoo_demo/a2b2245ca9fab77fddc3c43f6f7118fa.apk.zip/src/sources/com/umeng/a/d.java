package com.umeng.a;

import android.content.Context;
import android.text.TextUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class d implements Thread.UncaughtExceptionHandler {
    private Thread.UncaughtExceptionHandler a;
    private k b;
    private Context c;

    private void a(Throwable th) {
        if (th == null) {
            com.umeng.common.a.d("MobclickAgent", "Exception is null in handleException");
        } else {
            this.b.d(this.c);
            a(this.c, th);
        }
    }

    public void a(Context context) {
        if (Thread.getDefaultUncaughtExceptionHandler() == this) {
            com.umeng.common.a.a("MobclickAgent", "can't call onError more than once!");
            return;
        }
        this.c = context.getApplicationContext();
        this.a = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    void a(Context context, String str) {
        if (context == null || TextUtils.isEmpty(str)) {
            return;
        }
        try {
            String a = com.umeng.common.b.b.a();
            String str2 = a.split(" ")[0];
            String str3 = a.split(" ")[1];
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("date", str2);
            jSONObject.put("time", str3);
            jSONObject.put("context", str);
            jSONObject.put("type", "error");
            jSONObject.put("version", com.umeng.common.b.a(context));
            JSONArray b = b(context);
            if (b == null) {
                b = new JSONArray();
            }
            b.put(jSONObject);
            FileOutputStream openFileOutput = context.openFileOutput("com_umeng__crash.cache", 0);
            openFileOutput.write(b.toString().getBytes());
            openFileOutput.flush();
            openFileOutput.close();
        } catch (Exception e) {
            com.umeng.common.a.b("MobclickAgent", "an error occured while writing report file...", e);
            e.printStackTrace();
        }
    }

    void a(Context context, Throwable th) {
        if (context == null || th == null) {
            return;
        }
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        th.printStackTrace(printWriter);
        for (Throwable cause = th.getCause(); cause != null; cause = cause.getCause()) {
            cause.printStackTrace(printWriter);
        }
        String obj = stringWriter.toString();
        printWriter.close();
        a(context, obj);
    }

    public void a(k kVar) {
        this.b = kVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public JSONArray b(Context context) {
        JSONArray jSONArray = null;
        if (context != null) {
            File file = new File(context.getFilesDir(), "com_umeng__crash.cache");
            try {
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (file.exists()) {
                FileInputStream openFileInput = context.openFileInput("com_umeng__crash.cache");
                StringBuffer stringBuffer = new StringBuffer();
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = openFileInput.read(bArr);
                    if (read == -1) {
                        break;
                    }
                    stringBuffer.append(new String(bArr, 0, read));
                }
                openFileInput.close();
                if (stringBuffer.length() != 0) {
                    jSONArray = new JSONArray(stringBuffer.toString());
                }
                try {
                    file.delete();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
        return jSONArray;
    }

    @Override // java.lang.Thread.UncaughtExceptionHandler
    public void uncaughtException(Thread thread, Throwable th) {
        a(th);
        if (this.a != null) {
            this.a.uncaughtException(thread, th);
        }
    }
}
