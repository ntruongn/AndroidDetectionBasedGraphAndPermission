package com.feiwo.banner.e;

import android.content.Context;
import android.graphics.drawable.Drawable;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class a {
    private static a a = null;
    private ExecutorService b;
    private e c;
    private Map d = new HashMap();

    private a() {
        this.b = null;
        this.b = Executors.newFixedThreadPool(5);
        new ConcurrentLinkedQueue();
    }

    public static a a() {
        if (a == null) {
            a = new a();
        }
        return a;
    }

    public final Drawable a(Context context, String str, d dVar) {
        if (this.c == null) {
            this.c = e.b(context);
        }
        if (this.d.containsKey(str)) {
            SoftReference softReference = (SoftReference) this.d.get(str);
            if (softReference.get() != null) {
                dVar.a((Drawable) softReference.get());
                return (Drawable) softReference.get();
            }
        }
        this.b.submit(new c(this, context, str, new b(this, dVar, str)));
        return null;
    }
}
