package com.feiwo.banner.e;

import android.content.Context;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class g {
    private static g b = null;
    private static e c;
    private ExecutorService a;

    private g(Context context) {
        this.a = null;
        if (this.a == null) {
            this.a = Executors.newFixedThreadPool(5);
        }
        if (c == null) {
            c = e.b(context);
        }
    }

    public static g a(Context context) {
        if (b == null) {
            b = new g(context);
        }
        return b;
    }

    public final void a(h hVar) {
        this.a.submit(hVar);
    }
}
