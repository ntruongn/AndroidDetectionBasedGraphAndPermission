package com.music.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.SeekBar;
import android.widget.TextView;
import com.music.view.MarqueeTextView;
import java.util.HashMap;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class ad extends BroadcastReceiver {
    final /* synthetic */ PlayerActivity a;

    private ad(PlayerActivity playerActivity) {
        this.a = playerActivity;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ ad(PlayerActivity playerActivity, ad adVar) {
        this(playerActivity);
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        TextView textView;
        TextView textView2;
        TextView textView3;
        SeekBar seekBar;
        SeekBar seekBar2;
        TextView textView4;
        TextView textView5;
        TextView textView6;
        TextView textView7;
        SeekBar seekBar3;
        MarqueeTextView marqueeTextView;
        TextView textView8;
        String action = intent.getAction();
        if (action.equals("onCompletion")) {
            if (PlayerActivity.b != null || PlayerActivity.b.size() > 0) {
                if (ListMusicsActivity.c == null || ListMusicsActivity.c.size() <= 0) {
                    PlayerActivity.b = com.music.c.e.b(this.a);
                } else {
                    PlayerActivity.b = ListMusicsActivity.c;
                }
            }
            PlayerActivity.c = 0;
            textView5 = this.a.q;
            textView5.setText("");
            textView6 = this.a.n;
            textView6.setText("00:00");
            textView7 = this.a.m;
            textView7.setText("00:00");
            seekBar3 = this.a.r;
            seekBar3.setProgress(0);
            if (PlayerActivity.b.get(com.music.c.a.d) != null && PlayerActivity.b.size() > 0) {
                marqueeTextView = this.a.p;
                marqueeTextView.setText(((HashMap) PlayerActivity.b.get(com.music.c.a.d)).get("title").toString());
                textView8 = this.a.o;
                textView8.setText(String.valueOf(com.music.c.a.d + 1) + "/" + PlayerActivity.b.size());
            }
        }
        if (action.equals("com.run") && action.equals("com.run")) {
            int i = intent.getExtras().getInt("sumTime");
            String a = com.music.c.q.a().a(i);
            this.a.d = intent.getExtras().getInt("newTime");
            if (com.music.c.f.a == null || com.music.c.f.a.size() <= 0) {
                textView = this.a.q;
                textView.setText("无歌词");
            } else {
                for (int b = ((com.music.c.h) com.music.c.f.a.get(PlayerActivity.c)).b(); this.a.d + 500 >= b && PlayerActivity.c < com.music.c.f.a.size() - 1; b = ((com.music.c.h) com.music.c.f.a.get(PlayerActivity.c)).b()) {
                    if (PlayerActivity.c < com.music.c.f.a.size() - 1) {
                        textView4 = this.a.q;
                        textView4.setText(((com.music.c.h) com.music.c.f.a.get(PlayerActivity.c)).a());
                        PlayerActivity.c++;
                    }
                }
            }
            String a2 = com.music.c.q.a().a(this.a.d);
            textView2 = this.a.n;
            textView2.setText(a);
            textView3 = this.a.m;
            textView3.setText(a2);
            seekBar = this.a.r;
            seekBar.setMax(i);
            seekBar2 = this.a.r;
            seekBar2.setProgress(this.a.d);
        }
    }
}
