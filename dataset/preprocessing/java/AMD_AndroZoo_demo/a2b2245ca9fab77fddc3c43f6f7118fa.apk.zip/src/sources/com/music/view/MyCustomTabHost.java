package com.music.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TabHost;
import com.music.activity.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class MyCustomTabHost extends TabHost {
    private Animation a;
    private Animation b;
    private Animation c;
    private Animation d;
    private int e;

    public MyCustomTabHost(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = AnimationUtils.loadAnimation(context, R.anim.slide_left_in);
        this.b = AnimationUtils.loadAnimation(context, R.anim.slide_left_out);
        this.c = AnimationUtils.loadAnimation(context, R.anim.slide_right_in);
        this.d = AnimationUtils.loadAnimation(context, R.anim.slide_right_out);
    }

    @Override // android.widget.TabHost
    public void addTab(TabHost.TabSpec tabSpec) {
        this.e++;
        super.addTab(tabSpec);
    }

    public int getTabCount() {
        return this.e;
    }

    @Override // android.widget.TabHost
    public void setCurrentTab(int i) {
        int currentTab = getCurrentTab();
        View currentView = getCurrentView();
        if (currentView != null) {
            if (i > currentTab) {
                currentView.startAnimation(this.b);
            } else if (i < currentTab) {
                currentView.startAnimation(this.d);
            }
        }
        super.setCurrentTab(i);
        if (i > currentTab) {
            getCurrentView().startAnimation(this.c);
        } else if (i < currentTab) {
            getCurrentView().startAnimation(this.a);
        }
    }
}
