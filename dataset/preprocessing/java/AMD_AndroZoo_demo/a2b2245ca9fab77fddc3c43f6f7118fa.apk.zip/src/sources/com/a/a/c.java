package com.a.a;

import android.content.Context;
import android.os.Environment;
import com.music.c.e;
import com.music.c.m;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class c implements Runnable {
    final /* synthetic */ a a;
    private final /* synthetic */ Context b;
    private final /* synthetic */ String c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(a aVar, Context context, String str) {
        this.a = aVar;
        this.b = context;
        this.c = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        String str;
        String str2 = String.valueOf(Environment.getExternalStorageDirectory().getPath()) + "/" + m.c + "/";
        Context context = this.b;
        String str3 = this.c;
        str = this.a.d;
        e.a(context, str3, str2, str);
    }
}
