package com.music.activity;

import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;
import com.feiwo.banner.AdBanner;
import com.feiwothree.coverscreen.AdComponent;
import com.feiwothree.coverscreen.CoverAdComponent;
import com.music.view.MyCustomTabHost;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class TabHostActivity extends TabActivity implements TabHost.OnTabChangeListener {
    private MyCustomTabHost c;
    private TabWidget d;
    private RelativeLayout e;
    private AdBanner g;
    private int a = 0;
    private int b = -1;
    private String f = "MLCkS32n8VvNUuJl2tktjn78";

    private void b(int i) {
        int tabCount = this.c.getTabCount();
        if (i >= tabCount || this.b == i) {
            return;
        }
        if (this.b != -1) {
            View childAt = this.d.getChildAt(this.b);
            ((TextView) childAt.findViewById(16908310)).setTextColor(getResources().getColorStateList(R.color.graydeep));
            ImageView imageView = (ImageView) childAt.findViewById(16908294);
            switch (this.b) {
                case 0:
                    imageView.setImageDrawable(getResources().getDrawable(R.drawable.myplayer_im));
                    break;
                case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
                    imageView.setImageDrawable(getResources().getDrawable(R.drawable.mymusics_im));
                    break;
                case AdComponent.FAIL_NO_AD /* 2 */:
                    imageView.setImageDrawable(getResources().getDrawable(R.drawable.music_list_im));
                    break;
                case AdComponent.FAIL_IN_PREPARATION /* 3 */:
                    imageView.setImageDrawable(getResources().getDrawable(R.drawable.search_im));
                    break;
                case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                    imageView.setImageDrawable(getResources().getDrawable(R.drawable.music_down_list));
                    break;
            }
        } else {
            for (int i2 = 0; i2 < tabCount; i2++) {
                ((TextView) this.d.getChildAt(i2).findViewById(16908310)).setTextColor(getResources().getColorStateList(R.color.graydeep));
            }
        }
        View childAt2 = this.d.getChildAt(i);
        TextView textView = (TextView) childAt2.findViewById(16908310);
        ImageView imageView2 = (ImageView) childAt2.findViewById(16908294);
        textView.setTextColor(getResources().getColorStateList(R.color.green));
        switch (i) {
            case 0:
                imageView2.setImageDrawable(getResources().getDrawable(R.drawable.myplayer_im_pressed));
                break;
            case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
                imageView2.setImageDrawable(getResources().getDrawable(R.drawable.mymusics_im_pressed));
                break;
            case AdComponent.FAIL_NO_AD /* 2 */:
                imageView2.setImageDrawable(getResources().getDrawable(R.drawable.music_list_im_pressed));
                break;
            case AdComponent.FAIL_IN_PREPARATION /* 3 */:
                imageView2.setImageDrawable(getResources().getDrawable(R.drawable.search_im_pressed));
                break;
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                imageView2.setImageDrawable(getResources().getDrawable(R.drawable.music_down_list_pressed));
                break;
        }
        this.b = i;
    }

    private void c() {
        CoverAdComponent.init(getApplicationContext(), "MLCkS32n8VvNUuJl2tktjn78");
        CoverAdComponent.showAd(this);
        this.e = (RelativeLayout) findViewById(R.id.adonContainerView);
        this.g = new AdBanner(this);
        this.e.addView(this.g);
        this.g.setAppKey(this.f);
        this.g.setRecevieAdListener(new ai(this));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d() {
        DownloadListActivity.b = null;
        DownloadListActivity.c.clear();
        com.music.c.m.a.clear();
        com.music.c.m.b.clear();
    }

    public void a() {
        this.c.setup(getLocalActivityManager());
        this.c.setPadding(this.c.getPaddingLeft(), this.c.getPaddingTop(), this.c.getPaddingRight(), this.c.getPaddingBottom() - 5);
        TabHost.TabSpec newTabSpec = this.c.newTabSpec("0");
        newTabSpec.setIndicator("播放器", getResources().getDrawable(R.drawable.myplayer_im));
        newTabSpec.setContent(new Intent(this, (Class<?>) PlayerActivity.class));
        this.c.addTab(newTabSpec);
        TabHost.TabSpec newTabSpec2 = this.c.newTabSpec("1");
        newTabSpec2.setIndicator("本地歌曲", getResources().getDrawable(R.drawable.mymusics_im));
        newTabSpec2.setContent(new Intent(this, (Class<?>) ListMusicsActivity.class));
        this.c.addTab(newTabSpec2);
        TabHost.TabSpec newTabSpec3 = this.c.newTabSpec("2");
        newTabSpec3.setIndicator("歌曲榜单", getResources().getDrawable(R.drawable.music_list_im));
        newTabSpec3.setContent(new Intent(this, (Class<?>) BangdangListActivity.class));
        this.c.addTab(newTabSpec3);
        TabHost.TabSpec newTabSpec4 = this.c.newTabSpec("3");
        newTabSpec4.setIndicator("歌曲搜索", getResources().getDrawable(R.drawable.search_im));
        newTabSpec4.setContent(new Intent(this, (Class<?>) MusicSearchActivity.class));
        this.c.addTab(newTabSpec4);
        TabHost.TabSpec newTabSpec5 = this.c.newTabSpec("4");
        newTabSpec5.setIndicator("下载列表", getResources().getDrawable(R.drawable.music_down_list));
        newTabSpec5.setContent(new Intent(this, (Class<?>) DownloadListActivity.class));
        this.c.addTab(newTabSpec5);
        this.d.getChildAt(0).setBackgroundDrawable(null);
        this.d.getChildAt(1).setBackgroundDrawable(null);
        this.d.getChildAt(2).setBackgroundDrawable(null);
        this.d.getChildAt(3).setBackgroundDrawable(null);
        this.d.getChildAt(4).setBackgroundDrawable(null);
        a(this.a);
    }

    public void a(int i) {
        this.c.setCurrentTab(i);
        b(i);
    }

    public void b() {
        com.music.c.j.a(this, null, "退出应用", "退出后，音乐不会在后台播放! \n确定退出应用程序?", "确定", "取消", new aj(this), null, true);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() != 4 || keyEvent.getAction() != 0) {
            return super.dispatchKeyEvent(keyEvent);
        }
        b();
        return true;
    }

    @Override // android.app.ActivityGroup, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.tab_main);
        com.music.c.a.g = this;
        c();
        this.c = (MyCustomTabHost) findViewById(16908306);
        this.d = (TabWidget) findViewById(16908307);
        a();
        this.c.setOnTabChangedListener(this);
        com.umeng.a.a.c(this);
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(1, 1, 1, "帮助").setIcon(R.drawable.help);
        return true;
    }

    @Override // android.app.ActivityGroup, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        System.out.println("TabHostActivity销毁了");
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        super.onOptionsItemSelected(menuItem);
        switch (menuItem.getItemId()) {
            case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
                StringBuffer stringBuffer = new StringBuffer();
                stringBuffer.append("1.下载的歌曲保存在/sdcard/music目录下面  。\n");
                stringBuffer.append("2.下载完后，如果在'本地歌曲'中看不到刚下载的歌曲,请先打开USB存储设备,然后再关闭USB存储设备,重新加载内存卡音乐到媒体库中。  \n");
                stringBuffer.append("3.按Home键，让音乐能在后台播放。  \n");
                stringBuffer.append("4.如您对本产品有比较好的意见，请把您的想法发送到邮箱1986190884@qq.com  \n 谢谢！\n");
                new AlertDialog.Builder(this).setTitle("帮助").setMessage(stringBuffer.toString()).setNeutralButton("确定", new ak(this)).create().show();
                return true;
            default:
                return true;
        }
    }

    @Override // android.app.ActivityGroup, android.app.Activity
    protected void onPause() {
        super.onPause();
        try {
            com.umeng.a.a.a(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // android.app.ActivityGroup, android.app.Activity
    protected void onResume() {
        super.onResume();
        com.umeng.a.a.b(this);
    }

    @Override // android.widget.TabHost.OnTabChangeListener
    public void onTabChanged(String str) {
        this.a = Integer.parseInt(str);
        b(this.a);
    }
}
