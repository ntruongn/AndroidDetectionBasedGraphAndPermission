package com.music.activity;

import android.os.Environment;
import android.os.Handler;
import java.io.File;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class aa implements Runnable {
    final /* synthetic */ MusicSearchActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public aa(MusicSearchActivity musicSearchActivity) {
        this.a = musicSearchActivity;
    }

    @Override // java.lang.Runnable
    public void run() {
        boolean a;
        Handler handler;
        Handler handler2;
        ArrayList arrayList;
        ArrayList arrayList2;
        boolean a2;
        Handler handler3;
        Handler handler4;
        Handler handler5;
        Handler handler6;
        if (!Environment.getExternalStorageState().equals("mounted")) {
            handler6 = this.a.B;
            handler6.sendEmptyMessage(-4);
            return;
        }
        File file = new File(String.valueOf(Environment.getExternalStorageDirectory().getPath()) + "/" + com.music.c.m.c + "/");
        if (file.exists()) {
            for (File file2 : file.listFiles()) {
                if (file2.getName().startsWith(String.valueOf(MusicSearchActivity.b) + "-" + MusicSearchActivity.c)) {
                    handler5 = this.a.B;
                    handler5.sendEmptyMessage(-1);
                    return;
                }
            }
        }
        if (MusicSearchActivity.d != 0) {
            if (MusicSearchActivity.d == 1) {
                a = this.a.a(MusicSearchActivity.e);
                if (a) {
                    handler = this.a.B;
                    handler.sendEmptyMessage(-2);
                    return;
                } else {
                    handler2 = this.a.B;
                    handler2.sendEmptyMessage(2);
                    this.a.a();
                    return;
                }
            }
            return;
        }
        this.a.b();
        arrayList = this.a.p;
        if (arrayList.size() > 0) {
            MusicSearchActivity musicSearchActivity = this.a;
            arrayList2 = this.a.p;
            a2 = musicSearchActivity.a(arrayList2);
            if (a2) {
                handler3 = this.a.B;
                handler3.sendEmptyMessage(-2);
            } else {
                handler4 = this.a.B;
                handler4.sendEmptyMessage(2);
                this.a.a();
            }
        }
    }
}
