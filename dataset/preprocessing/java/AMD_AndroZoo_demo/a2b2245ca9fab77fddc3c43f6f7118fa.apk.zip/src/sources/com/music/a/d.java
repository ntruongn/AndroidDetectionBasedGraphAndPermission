package com.music.a;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import com.feiwothree.coverscreen.AdComponent;
import com.music.activity.R;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class d extends Handler {
    final /* synthetic */ c a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(c cVar) {
        this.a = cVar;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        ProgressDialog progressDialog;
        Context context;
        String str;
        Context context2;
        Context context3;
        String str2;
        Context context4;
        Context context5;
        String str3;
        Context context6;
        String str4;
        ProgressDialog progressDialog2;
        progressDialog = this.a.d;
        if (progressDialog != null) {
            progressDialog2 = this.a.d;
            progressDialog2.dismiss();
            this.a.d = null;
        }
        switch (message.what) {
            case -5:
                context = this.a.a;
                str = this.a.q;
                com.music.c.j.a(context, false, 0, R.drawable.f032, String.valueOf(str) + " 没有找到下载资源。");
                return;
            case -4:
                context2 = this.a.a;
                com.music.c.j.a(context2, false, 0, R.drawable.f032, "无内存卡");
                return;
            case -3:
                context4 = this.a.a;
                com.music.c.j.a(context4, false, 0, R.drawable.f032, "您的网络不是很好，请稍后再试！");
                return;
            case -2:
                context5 = this.a.a;
                str3 = this.a.q;
                com.music.c.j.a(context5, false, 0, R.drawable.f032, String.valueOf(str3) + "  已在下载队列中，请不要重复添加");
                return;
            case -1:
                context6 = this.a.a;
                str4 = this.a.q;
                com.music.c.j.a(context6, false, 0, R.drawable.f032, String.valueOf(str4) + "  已下载过了！");
                return;
            case 0:
            case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
            default:
                return;
            case AdComponent.FAIL_NO_AD /* 2 */:
                context3 = this.a.a;
                str2 = this.a.q;
                com.music.c.j.a(context3, false, 0, R.drawable.f023, String.valueOf(str2) + "  添加到下载队列了");
                return;
        }
    }
}
