package com.umeng.fb.b;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class e {
    public static int a(Context context) {
        return com.umeng.common.c.a(context).d("UMEmptyFbNotAllowed");
    }

    public static int b(Context context) {
        return com.umeng.common.c.a(context).d("UMContentTooLong");
    }

    public static int c(Context context) {
        return com.umeng.common.c.a(context).d("UMFeedbackContent");
    }

    public static int d(Context context) {
        return com.umeng.common.c.a(context).d("UMFeedbackSummit");
    }

    public static int e(Context context) {
        return com.umeng.common.c.a(context).d("UMFeedbackGoBack");
    }

    public static int f(Context context) {
        return com.umeng.common.c.a(context).d("UMFbList_ListItem_State_Sending");
    }

    public static int g(Context context) {
        return com.umeng.common.c.a(context).d("UMFbList_ListItem_State_Fail");
    }

    public static int h(Context context) {
        return com.umeng.common.c.a(context).d("UMFbList_ListItem_State_Resending");
    }

    public static int i(Context context) {
        return com.umeng.common.c.a(context).d("UMFbList_ListItem_State_ReSend");
    }

    public static int j(Context context) {
        return com.umeng.common.c.a(context).d("UMViewThread");
    }

    public static int k(Context context) {
        return com.umeng.common.c.a(context).d("UMDeleteThread");
    }

    public static int l(Context context) {
        return com.umeng.common.c.a(context).d("UMViewFeedback");
    }

    public static int m(Context context) {
        return com.umeng.common.c.a(context).d("UMDeleteFeedback");
    }

    public static int n(Context context) {
        return com.umeng.common.c.a(context).d("UMResendFeedback");
    }

    public static int o(Context context) {
        return com.umeng.common.c.a(context).d("UMContentTooLong");
    }

    public static int p(Context context) {
        return com.umeng.common.c.a(context).d("UMFeedbackConversationTitle");
    }

    public static int q(Context context) {
        return com.umeng.common.c.a(context).d("UMFeedbackSummit");
    }

    public static int r(Context context) {
        return com.umeng.common.c.a(context).d("UMFb_Atom_State_Sending");
    }

    public static int s(Context context) {
        return com.umeng.common.c.a(context).d("UMFb_Atom_State_Fail");
    }

    public static int t(Context context) {
        return com.umeng.common.c.a(context).d("UMFb_Atom_State_Resending");
    }
}
