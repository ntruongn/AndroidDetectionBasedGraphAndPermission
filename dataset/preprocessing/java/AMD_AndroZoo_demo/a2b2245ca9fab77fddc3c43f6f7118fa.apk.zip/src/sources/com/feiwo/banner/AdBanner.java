package com.feiwo.banner;

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import com.feiwothree.coverscreen.AdComponent;
import java.util.Random;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class AdBanner extends RelativeLayout {
    private boolean a;
    private boolean b;
    private Context c;
    private Handler d;
    private com.feiwo.banner.c.a e;
    private a f;
    private d g;
    private boolean h;
    private Handler i;
    private String j;
    private int k;
    private Runnable l;

    public AdBanner(Context context) {
        this(context, null, 0);
    }

    public AdBanner(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AdBanner(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.a = false;
        this.b = true;
        this.e = null;
        this.h = false;
        this.k = 60;
        this.l = new c(this);
        this.e = null;
        this.c = context;
        this.d = new Handler();
        com.feiwo.banner.f.d.a(context, 3);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(int i, String str) {
        m.a(this.c).a(this, 0, this.e, str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(com.feiwo.banner.c.a aVar) {
        if (aVar == null) {
            if (this.f != null) {
                this.f.b(this);
                return;
            }
            return;
        }
        this.e = aVar;
        try {
            if (this.g != null) {
                removeView(this.g);
                this.g.clearFocus();
            }
            if (this.c == null) {
                if (this.f != null) {
                    this.f.b(this);
                    return;
                }
                return;
            }
            this.g = d.a(this.c);
            this.g.a(this, aVar);
            addView(this.g);
            switch (new Random().nextInt(3)) {
                case 0:
                    com.feiwo.banner.a.a.c(this);
                    break;
                case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
                    com.feiwo.banner.a.a.a(this);
                    break;
                case AdComponent.FAIL_NO_AD /* 2 */:
                    com.feiwo.banner.a.a.b(this);
                    break;
                default:
                    com.feiwo.banner.a.a.b(this);
                    break;
            }
            if (this.f != null) {
                this.f.a(this);
            }
        } catch (IllegalStateException e) {
            removeAllViews();
            this.g.a();
            this.g = null;
        }
    }

    public final String getAppKey() {
        return this.j;
    }

    public final boolean getShowNotification() {
        return this.b;
    }

    @Override // android.view.View
    protected final void onWindowVisibilityChanged(int i) {
        switch (i) {
            case 0:
                this.a = true;
                return;
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                this.a = false;
                removeAllViews();
                this.g = null;
                return;
            case 8:
                this.a = false;
                removeAllViews();
                this.g = null;
                return;
            default:
                return;
        }
    }

    public final void setAppKey(String str) {
        this.h = true;
        this.j = str;
        m.a(this.c).a(this, this.d);
        if (this.i == null) {
            this.i = new Handler();
            this.i.post(this.l);
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((WindowManager) this.c.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
        com.feiwo.banner.b.a.a = displayMetrics.widthPixels;
    }

    public final void setRecevieAdListener(a aVar) {
        this.f = aVar;
    }

    public final void setShowNotification(boolean z) {
        this.b = z;
    }
}
