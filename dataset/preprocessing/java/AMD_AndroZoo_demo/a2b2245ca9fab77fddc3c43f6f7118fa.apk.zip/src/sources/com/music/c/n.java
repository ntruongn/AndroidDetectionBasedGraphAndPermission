package com.music.c;

import java.util.ArrayList;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class n {
    private static SAXParserFactory a = SAXParserFactory.newInstance();
    private static XMLReader b;
    private static ArrayList c;

    static {
        try {
            b = a.newSAXParser().getXMLReader();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0057 A[Catch: IOException -> 0x005b, all -> 0x0060, TRY_LEAVE, TryCatch #16 {IOException -> 0x005b, blocks: (B:36:0x0052, B:31:0x0057), top: B:35:0x0052, outer: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0052 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x006f A[Catch: all -> 0x0060, IOException -> 0x0073, TRY_LEAVE, TryCatch #4 {IOException -> 0x0073, blocks: (B:46:0x006a, B:41:0x006f), top: B:45:0x006a, outer: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x006a A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0084 A[Catch: all -> 0x0060, IOException -> 0x0088, TRY_LEAVE, TryCatch #12 {IOException -> 0x0088, blocks: (B:56:0x007f, B:51:0x0084), top: B:55:0x007f, outer: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x007f A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r1v0 */
    /* JADX WARN: Type inference failed for: r1v1 */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15, types: [java.io.StringReader] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v2 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r1v5, types: [java.io.StringReader] */
    /* JADX WARN: Type inference failed for: r1v7, types: [java.io.StringReader] */
    /* JADX WARN: Type inference failed for: r1v8, types: [java.io.StringReader] */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.io.StringReader] */
    /* JADX WARN: Type inference failed for: r2v0, types: [org.xml.sax.XMLReader] */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v5, types: [java.io.FileInputStream] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static synchronized java.util.ArrayList a(android.content.Context r6, java.lang.String r7, java.lang.Class r8, java.lang.String r9, java.lang.String[] r10, boolean r11) {
        /*
            Method dump skipped, instructions count: 192
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.music.c.n.a(android.content.Context, java.lang.String, java.lang.Class, java.lang.String, java.lang.String[], boolean):java.util.ArrayList");
    }
}
