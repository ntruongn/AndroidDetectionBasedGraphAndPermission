package com.music.activity;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class R {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
    public final class anim {
        public static final int loading = 0x7f040000;
        public static final int slide_left_in = 0x7f040001;
        public static final int slide_left_out = 0x7f040002;
        public static final int slide_right_in = 0x7f040003;
        public static final int slide_right_out = 0x7f040004;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
    public final class attr {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
    public final class color {
        public static final int black = 0x7f050003;
        public static final int blue = 0x7f050005;
        public static final int btn_text_dialog = 0x7f050011;
        public static final int btn_text_pressed = 0x7f05000f;
        public static final int dark_red = 0x7f050006;
        public static final int dialog_head_blue = 0x7f05000e;
        public static final int font_gray = 0x7f05000a;
        public static final int font_red = 0x7f050009;
        public static final int gray = 0x7f050002;
        public static final int gray_disable = 0x7f050010;
        public static final int graydeep = 0x7f05000d;
        public static final int green = 0x7f05000c;
        public static final int grey = 0x7f050012;
        public static final int light_gray = 0x7f050007;
        public static final int little_blue = 0x7f05000b;
        public static final int orange_line = 0x7f050008;
        public static final int red = 0x7f050000;
        public static final int white = 0x7f050004;
        public static final int yellow = 0x7f050001;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
    public final class drawable {
        public static final int back_button_normal = 0x7f020000;
        public static final int back_button_selector = 0x7f020001;
        public static final int backbutton_pressed = 0x7f020002;
        public static final int bg = 0x7f020003;
        public static final int btn_disabled = 0x7f020004;
        public static final int btn_gray_normal = 0x7f020005;
        public static final int btn_green_normal = 0x7f020006;
        public static final int btn_green_pressed = 0x7f020007;
        public static final int btn_list = 0x7f020008;
        public static final int default_pic = 0x7f020009;
        public static final int dialog_bg = 0x7f02000a;
        public static final int dialog_body_bg = 0x7f02000b;
        public static final int dialog_head_bg = 0x7f02000c;
        public static final int editext_bg = 0x7f02000d;
        public static final int editext_focuses = 0x7f02000e;
        public static final int editext_normal = 0x7f02000f;
        public static final int f023 = 0x7f020010;
        public static final int f032 = 0x7f020011;
        public static final int forward_selecor = 0x7f020012;
        public static final int head_layout_bg = 0x7f020013;
        public static final int help = 0x7f020014;
        public static final int ic_launcher = 0x7f020015;
        public static final int item_right = 0x7f020016;
        public static final int item_right_playing = 0x7f020017;
        public static final int items_separator_view = 0x7f020018;
        public static final int list_background = 0x7f02004c;
        public static final int list_divider_color = 0x7f02004a;
        public static final int list_divider_line = 0x7f020019;
        public static final int listivew_selector = 0x7f02001a;
        public static final int listview_bg = 0x7f02001b;
        public static final int listview_item_bg = 0x7f02001c;
        public static final int listview_selector = 0x7f02001d;
        public static final int loadingsmall = 0x7f02001e;
        public static final int main_navigation_background = 0x7f02001f;
        public static final int main_navigation_highlight_bg = 0x7f020020;
        public static final int main_navigation_highlight_bg_x = 0x7f020021;
        public static final int media_music = 0x7f020022;
        public static final int media_player_progress_bg = 0x7f020023;
        public static final int media_player_progress_button = 0x7f020024;
        public static final int menu_list_background_color = 0x7f020049;
        public static final int menu_search_normal = 0x7f020025;
        public static final int menu_search_press = 0x7f020026;
        public static final int mode_repateone = 0x7f020027;
        public static final int mode_repeaterandom = 0x7f020028;
        public static final int mode_sequence = 0x7f020029;
        public static final int music_down_list = 0x7f02002a;
        public static final int music_down_list_pressed = 0x7f02002b;
        public static final int music_im = 0x7f02002c;
        public static final int music_list_im = 0x7f02002d;
        public static final int music_list_im_pressed = 0x7f02002e;
        public static final int mymusics_im = 0x7f02002f;
        public static final int mymusics_im_pressed = 0x7f020030;
        public static final int myplayer_im = 0x7f020031;
        public static final int myplayer_im_pressed = 0x7f020032;
        public static final int next_selecor = 0x7f020033;
        public static final int nextbutton = 0x7f020034;
        public static final int nextbuttonpressed = 0x7f020035;
        public static final int pause_selecor = 0x7f020036;
        public static final int pausebutton = 0x7f020037;
        public static final int pausebuttonpressed = 0x7f020038;
        public static final int play_selecor = 0x7f020039;
        public static final int playbutton = 0x7f02003a;
        public static final int playbuttonpressed = 0x7f02003b;
        public static final int previousbutton = 0x7f02003c;
        public static final int previousbuttonpressed = 0x7f02003d;
        public static final int search_im = 0x7f02003e;
        public static final int search_im_pressed = 0x7f02003f;
        public static final int search_imageview_selecor = 0x7f020040;
        public static final int selector_btn_gray = 0x7f020041;
        public static final int selector_btn_gray_text = 0x7f020042;
        public static final int selector_btn_green = 0x7f020043;
        public static final int selector_btn_text = 0x7f020044;
        public static final int tab_bg9 = 0x7f020045;
        public static final int toastview_corner_round = 0x7f020046;
        public static final int translate = 0x7f020047;
        public static final int transparent = 0x7f02004d;
        public static final int warning = 0x7f020048;
        public static final int white = 0x7f02004b;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
    public final class id {
        public static final int adonContainerView = 0x7f080026;
        public static final int alert_dialog_head_layout = 0x7f080020;
        public static final int alertdialog_message_tv = 0x7f080023;
        public static final int alertdialog_title_image = 0x7f080021;
        public static final int alertdialog_title_tv = 0x7f080022;
        public static final int bangdan_name = 0x7f080006;
        public static final int bangdan_pic = 0x7f080005;
        public static final int body = 0x7f08002d;
        public static final int bottomlist = 0x7f08002c;
        public static final int category_list_nodata = 0x7f080016;
        public static final int category_list_nodata_layout = 0x7f080001;
        public static final int dialog_button_cancel = 0x7f080025;
        public static final int dialog_button_ok = 0x7f080024;
        public static final int domobAdXML = 0x7f08002e;
        public static final int down_lists = 0x7f080033;
        public static final int download_progress = 0x7f08001b;
        public static final int goods_list = 0x7f080015;
        public static final int gridview = 0x7f080000;
        public static final int id_tv_loadingmsg = 0x7f080004;
        public static final int imgFront = 0x7f080009;
        public static final int imgNext = 0x7f08000c;
        public static final int imgPlaying = 0x7f08000a;
        public static final int imgStop = 0x7f08000b;
        public static final int item_right_pic = 0x7f08001c;
        public static final int lineraLayout1id = 0x7f080007;
        public static final int loading = 0x7f080003;
        public static final int loadingImageView = 0x7f080002;
        public static final int music_imageview_layout = 0x7f080010;
        public static final int music_name = 0x7f080019;
        public static final int music_pic = 0x7f080017;
        public static final int music_singer = 0x7f080018;
        public static final int music_time = 0x7f08001a;
        public static final int musiclrc = 0x7f080011;
        public static final int musictitle = 0x7f080013;
        public static final int mylist = 0x7f080031;
        public static final int mymusic = 0x7f080030;
        public static final int myplayer_linearlayout = 0x7f08002f;
        public static final int online_search = 0x7f080032;
        public static final int parent = 0x7f08002b;
        public static final int play_mode_im = 0x7f08000e;
        public static final int player_head_layout = 0x7f080012;
        public static final int seekBar = 0x7f08000f;
        public static final int song_name = 0x7f08001d;
        public static final int song_singer = 0x7f08001f;
        public static final int songer_search = 0x7f08001e;
        public static final int tag = 0x7f080014;
        public static final int title = 0x7f080029;
        public static final int titleLeftButton = 0x7f08002a;
        public static final int toast_imageview = 0x7f080027;
        public static final int toast_textview = 0x7f080028;
        public static final int tvNowTime = 0x7f080008;
        public static final int tvSumTime = 0x7f08000d;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
    public final class layout {
        public static final int bangdan = 0x7f030000;
        public static final int customprogressdialog = 0x7f030001;
        public static final int gridview_item = 0x7f030002;
        public static final int main = 0x7f030003;
        public static final int music_down = 0x7f030004;
        public static final int music_item = 0x7f030005;
        public static final int music_search = 0x7f030006;
        public static final int my_alert_dialog = 0x7f030007;
        public static final int tab_main = 0x7f030008;
        public static final int toast_layout = 0x7f030009;
        public static final int top = 0x7f03000a;
        public static final int view_main = 0x7f03000b;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
    public final class string {
        public static final int app_name = 0x7f060001;
        public static final int hello = 0x7f060000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
    public final class style {
        public static final int MyAlertDialog = 0x7f070003;
        public static final int MyDialogStyle = 0x7f070004;
        public static final int btn_gray = 0x7f070000;
        public static final int btn_gray_no_margin = 0x7f070001;
        public static final int btn_green = 0x7f070002;
    }
}
