package com.music.activity;

import android.content.DialogInterface;
import android.view.KeyEvent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class y implements DialogInterface.OnKeyListener {
    final /* synthetic */ MusicSearchActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public y(MusicSearchActivity musicSearchActivity) {
        this.a = musicSearchActivity;
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        if (i != 4) {
            return false;
        }
        dialogInterface.dismiss();
        return true;
    }
}
