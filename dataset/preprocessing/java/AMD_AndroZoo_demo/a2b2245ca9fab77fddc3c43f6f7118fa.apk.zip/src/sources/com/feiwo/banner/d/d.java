package com.feiwo.banner.d;

import android.os.Handler;
import android.os.Message;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class d extends Handler {
    private /* synthetic */ c a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(c cVar) {
        this.a = cVar;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        this.a.invalidate();
    }
}
