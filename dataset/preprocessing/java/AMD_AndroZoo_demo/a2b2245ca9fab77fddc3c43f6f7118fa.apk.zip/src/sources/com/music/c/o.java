package com.music.c;

import android.content.Context;
import java.lang.reflect.Field;
import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class o extends DefaultHandler {
    private static int d = 0;
    private String a = "";
    private Class b;
    private String[] c;
    private Object e;
    private String f;
    private Context g;

    public o(Context context, Class cls, String str, String[] strArr) {
        this.f = "";
        this.b = cls;
        this.f = str;
        this.c = strArr;
        this.g = context;
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void characters(char[] cArr, int i, int i2) {
        this.a = String.valueOf(this.a) + new String(cArr, i, i2).trim();
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void endDocument() {
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void endElement(String str, String str2, String str3) {
        ArrayList arrayList;
        if (str2.trim().equals(this.f) && this.e != null) {
            arrayList = n.c;
            arrayList.add(this.e);
            d = 0;
        } else if (d < this.c.length) {
            String trim = this.c[d].trim();
            if (this.e != null && str2.equals(trim)) {
                try {
                    Field declaredField = this.b.getDeclaredField(trim);
                    declaredField.setAccessible(true);
                    declaredField.set(this.e, this.a);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (IllegalArgumentException e2) {
                    e2.printStackTrace();
                } catch (NoSuchFieldException e3) {
                    e3.printStackTrace();
                } catch (SecurityException e4) {
                    e4.printStackTrace();
                }
                d++;
            }
        }
        this.a = "";
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void startDocument() {
        ArrayList arrayList;
        arrayList = n.c;
        arrayList.clear();
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void startElement(String str, String str2, String str3, Attributes attributes) {
        if (str2.trim().equals(this.f)) {
            try {
                this.e = this.b.newInstance();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InstantiationException e2) {
                e2.printStackTrace();
            }
        }
    }
}
