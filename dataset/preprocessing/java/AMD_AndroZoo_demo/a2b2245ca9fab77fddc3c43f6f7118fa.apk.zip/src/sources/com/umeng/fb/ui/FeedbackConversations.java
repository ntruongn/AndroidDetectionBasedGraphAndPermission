package com.umeng.fb.ui;

import android.app.ListActivity;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import com.feiwothree.coverscreen.AdComponent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class FeedbackConversations extends ListActivity {
    private static /* synthetic */ int[] c;
    b a;
    ImageButton b;

    static /* synthetic */ int[] a() {
        int[] iArr = c;
        if (iArr == null) {
            iArr = new int[com.umeng.fb.f.valuesCustom().length];
            try {
                iArr[com.umeng.fb.f.HasFail.ordinal()] = 3;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[com.umeng.fb.f.Normal.ordinal()] = 4;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[com.umeng.fb.f.PureFail.ordinal()] = 2;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[com.umeng.fb.f.PureSending.ordinal()] = 1;
            } catch (NoSuchFieldError e4) {
            }
            c = iArr;
        }
        return iArr;
    }

    private void b() {
        i iVar = (i) getListAdapter();
        iVar.a(com.umeng.fb.c.e.a(this));
        iVar.notifyDataSetChanged();
    }

    @Override // android.app.Activity
    public boolean onContextItemSelected(MenuItem menuItem) {
        com.umeng.fb.e a = ((i) getListAdapter()).a(((AdapterView.AdapterContextMenuInfo) menuItem.getMenuInfo()).position);
        switch (menuItem.getItemId()) {
            case 0:
            case AdComponent.FAIL_NO_AD /* 2 */:
                com.umeng.fb.c.e.a(this, a.c);
                com.umeng.fb.c.a.b(this, a);
                break;
            case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
                com.umeng.fb.c.e.c(this, a.c);
                b();
                break;
            case AdComponent.FAIL_IN_PREPARATION /* 3 */:
                com.umeng.fb.c.a.a(this, a);
                break;
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                com.umeng.fb.c.e.c(this, a.c);
                b();
                break;
        }
        return super.onContextItemSelected(menuItem);
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(com.umeng.fb.b.d.c(this));
        this.b = (ImageButton) findViewById(com.umeng.fb.b.c.k(this));
        if (this.b != null) {
            this.b.setOnClickListener(new h(this));
        }
        if (!com.umeng.fb.a.a()) {
            new com.umeng.fb.a.e(this).start();
            new com.umeng.fb.a.d(this).start();
        }
        registerForContextMenu(getListView());
        setListAdapter(new i(this, com.umeng.fb.c.e.a(this)));
    }

    @Override // android.app.Activity, android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        super.onCreateContextMenu(contextMenu, view, contextMenuInfo);
        com.umeng.fb.f fVar = ((i) getListAdapter()).a(((AdapterView.AdapterContextMenuInfo) contextMenuInfo).position).b;
        if (fVar == com.umeng.fb.f.Normal) {
            contextMenu.add(0, 0, 0, getString(com.umeng.fb.b.e.j(this)));
            contextMenu.add(0, 1, 0, getString(com.umeng.fb.b.e.k(this)));
        } else if (fVar == com.umeng.fb.f.PureSending) {
            contextMenu.add(0, 2, 0, getString(com.umeng.fb.b.e.l(this)));
            contextMenu.add(0, 4, 0, getString(com.umeng.fb.b.e.m(this)));
        } else if (fVar == com.umeng.fb.f.PureFail) {
            contextMenu.add(0, 3, 0, getString(com.umeng.fb.b.e.n(this)));
            contextMenu.add(0, 4, 0, getString(com.umeng.fb.b.e.m(this)));
        }
    }

    @Override // android.app.ListActivity
    protected void onListItemClick(ListView listView, View view, int i, long j) {
        super.onListItemClick(listView, view, i, j);
        synchronized (((i) getListAdapter()).a(i)) {
            com.umeng.fb.e a = ((i) getListAdapter()).a(i);
            com.umeng.fb.f fVar = a.b;
            com.umeng.fb.c.e.a(this, a.c);
            switch (a()[fVar.ordinal()]) {
                case AdComponent.FAIL_NO_AD /* 2 */:
                    com.umeng.fb.c.a.a(this, a);
                    break;
                default:
                    com.umeng.fb.c.a.b(this, a);
                    break;
            }
        }
    }

    @Override // android.app.Activity
    protected void onRestart() {
        super.onRestart();
        b();
    }

    @Override // android.app.Activity
    protected void onStart() {
        super.onStart();
        this.a = new b(this, (i) getListAdapter());
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("postFeedbackFinished");
        intentFilter.addAction("RetrieveReplyBroadcast");
        registerReceiver(this.a, intentFilter);
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        unregisterReceiver(this.a);
    }
}
