package com.feiwo.banner;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class e extends Handler {
    private /* synthetic */ d a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(d dVar) {
        this.a = dVar;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        Context context;
        Context context2;
        Context context3;
        TextView textView;
        com.feiwo.banner.c.a aVar;
        com.feiwo.banner.c.a aVar2;
        com.feiwo.banner.c.a aVar3;
        TextView textView2;
        com.feiwo.banner.c.a aVar4;
        int i;
        com.feiwo.banner.c.a aVar5;
        int i2;
        if (message.what == 0) {
            textView = this.a.e;
            if (textView != null) {
                aVar = this.a.h;
                if (aVar != null) {
                    aVar2 = this.a.h;
                    if (aVar2.e() != null) {
                        aVar3 = this.a.h;
                        if (aVar3.e().size() > 0) {
                            textView2 = this.a.e;
                            aVar4 = this.a.h;
                            ArrayList e = aVar4.e();
                            i = this.a.o;
                            aVar5 = this.a.h;
                            textView2.setText((CharSequence) e.get(i % aVar5.e().size()));
                            d dVar = this.a;
                            i2 = dVar.o;
                            dVar.o = i2 + 1;
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            }
            return;
        }
        if (message.what == 1) {
            if (d.d(this.a) != null) {
                d.d(this.a).a();
                return;
            }
            return;
        }
        if (message.what == 100) {
            Bundle bundle = (Bundle) message.obj;
            Uri parse = Uri.parse(bundle.getString("path"));
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setData(parse);
            intent.addFlags(1);
            intent.setClassName("com.android.packageinstaller", "com.android.packageinstaller.PackageInstallerActivity");
            if (bundle.getBoolean("notifiKeep")) {
                context3 = this.a.g;
                com.feiwo.banner.e.f.a(context3).a(message.arg1, null, bundle.getString("pushstr"), "下载完成，点击安装", intent, 32);
            } else {
                context = this.a.g;
                com.feiwo.banner.e.f.a(context).a(message.arg1, null, bundle.getString("pushstr"), "下载完成，点击安装", intent, 16);
            }
            context2 = this.a.g;
            context2.startActivity(intent);
        }
    }
}
