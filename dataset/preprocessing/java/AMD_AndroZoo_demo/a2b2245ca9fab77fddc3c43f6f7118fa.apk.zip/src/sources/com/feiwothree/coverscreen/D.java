package com.feiwothree.coverscreen;

import android.webkit.WebChromeClient;
import android.webkit.WebView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class D extends WebChromeClient {
    private /* synthetic */ WA a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public D(WA wa) {
        this.a = wa;
    }

    @Override // android.webkit.WebChromeClient
    public final void onProgressChanged(WebView webView, int i) {
        this.a.setProgress(i * 100);
        WA.a(this.a, "已加载 >> " + i + "%");
        if (i >= 100) {
            WA.a(this.a, null);
        }
    }
}
