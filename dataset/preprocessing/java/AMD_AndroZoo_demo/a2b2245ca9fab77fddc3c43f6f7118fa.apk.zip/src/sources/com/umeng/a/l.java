package com.umeng.a;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class l {
    static SharedPreferences a(Context context) {
        return context.getSharedPreferences("mobclick_agent_user_" + context.getPackageName(), 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(Context context, JSONObject jSONObject) {
        if (jSONObject == null) {
            return;
        }
        String g = g(context);
        try {
            jSONObject.put("cache_version", com.umeng.common.b.a(context));
            FileOutputStream openFileOutput = context.openFileOutput(g, 0);
            openFileOutput.write(jSONObject.toString().getBytes());
            openFileOutput.flush();
            openFileOutput.close();
        } catch (FileNotFoundException e) {
            com.umeng.common.a.b("MobclickAgent", "cache message error", e);
        } catch (IOException e2) {
            com.umeng.common.a.b("MobclickAgent", "cache message error", e2);
        } catch (Exception e3) {
            com.umeng.common.a.b("MobclickAgent", "message is null", e3);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static SharedPreferences b(Context context) {
        return context.getSharedPreferences("mobclick_agent_online_setting_" + context.getPackageName(), 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void b(Context context, JSONObject jSONObject) {
        if (jSONObject == null) {
            return;
        }
        JSONObject jSONObject2 = null;
        try {
            jSONObject2 = jSONObject.optJSONObject("body");
        } catch (Exception e) {
            e.printStackTrace();
        }
        a(context, jSONObject2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static SharedPreferences c(Context context) {
        return context.getSharedPreferences("mobclick_agent_header_" + context.getPackageName(), 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static SharedPreferences d(Context context) {
        return context.getSharedPreferences("mobclick_agent_update_" + context.getPackageName(), 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static SharedPreferences e(Context context) {
        return context.getSharedPreferences("mobclick_agent_state_" + context.getPackageName(), 0);
    }

    static String f(Context context) {
        return "mobclick_agent_header_" + context.getPackageName();
    }

    static String g(Context context) {
        return "mobclick_agent_cached_" + context.getPackageName();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static JSONObject h(Context context) {
        JSONObject jSONObject = new JSONObject();
        SharedPreferences a = a(context);
        try {
            if (a.getInt("gender", -1) != -1) {
                jSONObject.put("sex", a.getInt("gender", -1));
            }
            if (a.getInt("age", -1) != -1) {
                jSONObject.put("age", a.getInt("age", -1));
            }
            if (!"".equals(a.getString("user_id", ""))) {
                jSONObject.put("id", a.getString("user_id", ""));
            }
            if (!"".equals(a.getString("id_source", ""))) {
                jSONObject.put("url", URLEncoder.encode(a.getString("id_source", "")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (jSONObject.length() > 0) {
            return jSONObject;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static JSONObject i(Context context) {
        String str;
        try {
            FileInputStream openFileInput = context.openFileInput(g(context));
            String str2 = "";
            byte[] bArr = new byte[1024];
            while (true) {
                str = str2;
                int read = openFileInput.read(bArr);
                if (read == -1) {
                    break;
                }
                str2 = String.valueOf(str) + new String(bArr, 0, read);
            }
            openFileInput.close();
            if (str.length() == 0) {
                return null;
            }
            try {
                return new JSONObject(str);
            } catch (JSONException e) {
                j(context);
                e.printStackTrace();
                return null;
            }
        } catch (FileNotFoundException e2) {
            return null;
        } catch (IOException e3) {
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void j(Context context) {
        context.deleteFile(f(context));
        context.deleteFile(g(context));
    }
}
