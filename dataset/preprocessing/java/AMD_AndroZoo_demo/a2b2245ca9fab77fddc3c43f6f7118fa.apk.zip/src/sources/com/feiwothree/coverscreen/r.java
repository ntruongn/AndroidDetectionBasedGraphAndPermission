package com.feiwothree.coverscreen;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.feiwothree.coverscreen.a.C0009i;
import com.feiwothree.coverscreen.a.C0010j;
import com.feiwothree.coverscreen.a.I;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class r extends LinearLayout {
    SA a;
    List b;
    private Map c;
    private Timer d;
    private TimerTask e;
    private int f;

    public r(SA sa, List list) {
        super(sa);
        new Handler();
        this.c = new HashMap();
        setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        setGravity(17);
        this.a = sa;
        this.b = list;
        this.f = I.a(sa, "DP_FEIWO", "dpswitchdelay", 5);
    }

    private void c(View view, C0010j c0010j) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setCancelable(false);
        builder.setTitle("提示");
        builder.setMessage("确定下载 " + c0010j.d() + " ？");
        builder.setPositiveButton("确定", new t(this, view, c0010j));
        builder.setNegativeButton("取消", new u(this));
        builder.show();
        h();
    }

    public int a(View view, C0010j c0010j) {
        int indexOf = this.b.indexOf(c0010j);
        this.b.remove(c0010j);
        if (indexOf < 0) {
            return 0;
        }
        if (indexOf >= this.b.size()) {
            a(indexOf - 1);
            return indexOf - 1;
        }
        a(indexOf);
        return indexOf;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a() {
        b();
        c();
        g();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(int i) {
        if (this.b.isEmpty()) {
            return;
        }
        this.a.b((C0010j) this.b.get(i));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(ImageView imageView, String str, boolean z) {
        imageView.setTag(str);
        SoftReference softReference = (SoftReference) this.c.get(str);
        Bitmap bitmap = softReference != null ? (Bitmap) softReference.get() : null;
        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
        } else {
            com.feiwothree.coverscreen.a.C.a().a(getContext(), str, new v(this, imageView, str, z));
        }
    }

    protected void b() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void b(View view, C0010j c0010j) {
        int b = C0009i.b(getContext());
        if ("download".equals(c0010j.h())) {
            if (b == 4) {
                if ("false".equals(c0010j.n())) {
                    c(view, c0010j);
                    return;
                }
            } else if ("false".equals(c0010j.p())) {
                c(view, c0010j);
                return;
            }
        }
        a(view, c0010j);
        this.a.a(c0010j);
    }

    protected void c() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void d() {
        this.a.finish();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void e() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void f() {
        System.out.println("[AutoSlide] resetAutoSlideDelay");
        h();
        g();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void g() {
        System.out.println("[AutoSlide] startAutoSlide");
        if (this.e == null || this.e.cancel()) {
            if (this.d == null) {
                this.d = new Timer();
            }
            this.e = new x(this);
            this.d.schedule(this.e, this.f, this.f);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void h() {
        System.out.println("[AutoSlide] stopAutoSlide");
        if (this.e == null) {
            return;
        }
        this.e.cancel();
        this.e = null;
    }
}
