package com.music.a;

import android.view.View;
import com.music.domain.ObjectInfo;
import java.io.PrintStream;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class e implements View.OnClickListener {
    final /* synthetic */ c a;
    private final /* synthetic */ ObjectInfo b;
    private final /* synthetic */ g c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(c cVar, ObjectInfo objectInfo, g gVar) {
        this.a = cVar;
        this.b = objectInfo;
        this.c = gVar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        String str;
        String str2;
        this.a.n = "http://box.zhangmen.baidu.com/x?op=12&count=1&title=" + this.b.name;
        PrintStream printStream = System.out;
        StringBuilder sb = new StringBuilder("获取歌曲地址 请求url：");
        str = this.a.n;
        printStream.println(sb.append(str).toString());
        this.a.q = this.c.b.getText().toString();
        if (this.c.a.getText() != null && !this.c.a.getText().toString().equals("")) {
            this.a.r = this.c.a.getText().toString();
        }
        c cVar = this.a;
        StringBuilder append = new StringBuilder(String.valueOf(this.c.b.getText().toString())).append("-");
        str2 = this.a.r;
        cVar.a(view, append.append(str2).toString());
    }
}
