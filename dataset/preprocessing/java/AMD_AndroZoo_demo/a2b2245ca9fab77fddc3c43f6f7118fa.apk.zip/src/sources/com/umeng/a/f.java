package com.umeng.a;

import android.content.Context;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class f extends Thread {
    final /* synthetic */ e a;
    private final Object b = new Object();
    private Context c;
    private int d;
    private String e;
    private String f;
    private int g;
    private long h;
    private Map i;
    private String j;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(e eVar, Context context, int i) {
        this.a = eVar;
        this.c = context.getApplicationContext();
        this.d = i;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        try {
            synchronized (this.b) {
                if (this.d == 0) {
                    try {
                        if (this.c == null) {
                            com.umeng.common.a.b("MobclickAgent", "unexpected null context in invokehander flag=0");
                            return;
                        }
                        this.a.h(this.c);
                    } catch (Exception e) {
                        com.umeng.common.a.b("MobclickAgent", "unexpected null context in invokehander flag=0", e);
                    }
                } else if (this.d == 1) {
                    this.a.e(this.c);
                } else if (this.d == 2) {
                    this.a.j(this.c);
                } else if (this.d == 3) {
                    this.a.a(this.c, this.e, this.f, this.h, this.g);
                } else if (this.d == 4) {
                    this.a.a(this.c, this.e, this.i, this.h);
                } else if (this.d == 5) {
                    this.a.a(this.c, this.e, this.i, this.j);
                } else if (this.d == 6) {
                    this.a.a(this.c, this.e, this.j);
                }
            }
        } catch (Exception e2) {
            com.umeng.common.a.b("MobclickAgent", "Exception occurred in invokehander.", e2);
        }
    }
}
