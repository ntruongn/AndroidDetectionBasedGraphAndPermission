package com.feiwothree.coverscreen;

import com.feiwothree.coverscreen.a.I;
import java.util.Date;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class h implements com.feiwothree.coverscreen.a.t {
    private /* synthetic */ CoverAdComponent a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h(CoverAdComponent coverAdComponent) {
        this.a = coverAdComponent;
    }

    @Override // com.feiwothree.coverscreen.a.t
    public final void a(boolean z, String str) {
        List b;
        this.a.e();
        new StringBuilder("获取广告的网络请求得到返回结果：").append(str);
        if (z) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                int optInt = jSONObject.optInt("errorcode", 1);
                String optString = jSONObject.optString("errormessage");
                if (optInt != 0) {
                    this.a.e();
                    new StringBuilder("request failed: ").append(optString);
                } else {
                    int optInt2 = jSONObject.optInt("screenOnNum", -1);
                    int optInt3 = jSONObject.optInt("screenOnShowRate", -1);
                    jSONObject.optInt("coverScreenRefreshTime", 60);
                    int optInt4 = optInt2 == -1 ? jSONObject.optInt("screenNoNum", 3) : optInt2;
                    int optInt5 = optInt3 == -1 ? jSONObject.optInt("screenNoShowRate", 10) : optInt3;
                    int optInt6 = jSONObject.optInt("screenOnSwitchDelay", 10);
                    boolean optBoolean = jSONObject.optBoolean("screenOnShow", true);
                    boolean optBoolean2 = jSONObject.optBoolean("coverDownloadConfirm", false);
                    JSONArray optJSONArray = jSONObject.optJSONArray("ads");
                    int i = optInt6 > 0 ? optInt6 : 10;
                    if (optJSONArray != null) {
                        this.a.a(optJSONArray);
                    }
                    this.a.e = 0;
                    CoverAdComponent coverAdComponent = this.a;
                    CoverAdComponent coverAdComponent2 = this.a;
                    b = CoverAdComponent.b(optJSONArray);
                    coverAdComponent.c = b;
                    this.a.d = new Date(new Date().getTime() + 60000);
                    I.b(this.a.e(), "DP_FEIWO", "dpnum", optInt4);
                    I.b(this.a.e(), "DP_FEIWO", "dprate", optInt5);
                    I.b(this.a.e(), "DP_FEIWO", "dpswitchdelay", i * 1000);
                    I.a(this.a.e(), "DP_FEIWO", "showatscreenonplatform", optBoolean);
                    I.a(this.a.e(), "DP_FEIWO", "download_confirm", optBoolean2);
                    new StringBuilder("setContent, screenOnNum: ").append(optInt4).append(", screenOnShowRate: ").append(optInt5).append(", screenOnSwitchDelay: ").append(i * 1000).append(", enableScreenOnShow: ").append(optBoolean).append(", downloadConfirm: ").append(optBoolean2).append(", coverScreenRefreshTime: ").append(1);
                }
            } catch (JSONException e) {
                this.a.e();
                new StringBuilder("error result: ").append(e);
            }
        }
        this.a.c();
        this.a.e();
        this.a.a(false);
    }
}
