package com.music.activity;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import com.music.domain.ObjectInfo;
import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class c implements AdapterView.OnItemClickListener {
    final /* synthetic */ BangdangListActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(BangdangListActivity bangdangListActivity) {
        this.a = bangdangListActivity;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        ArrayList arrayList;
        ArrayList arrayList2;
        ArrayList arrayList3;
        arrayList = this.a.i;
        if (arrayList != null) {
            arrayList2 = this.a.i;
            if (i < arrayList2.size()) {
                arrayList3 = this.a.i;
                ObjectInfo objectInfo = (ObjectInfo) arrayList3.get(i);
                String str = objectInfo.name;
                String str2 = objectInfo.id;
                Intent intent = new Intent(this.a, (Class<?>) ShowOneBanddangListActivity.class);
                intent.putExtra("bangdanName", str);
                intent.putExtra("id", str2);
                this.a.startActivity(intent);
            }
        }
    }
}
