package com.music.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class BaseActivity extends Activity {
    public InputMethodManager a;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        System.out.println("BaseActivity" + getClass().getSimpleName() + " onCreate() invoked!!");
        requestWindowFeature(1);
        this.a = (InputMethodManager) getSystemService("input_method");
        com.umeng.a.a.c(this);
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        System.out.println("BaseActivity" + getClass().getSimpleName() + " onDestroy() invoked!!");
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        System.out.println("BaseActivity" + getClass().getSimpleName() + " onPause() invoked!!");
        try {
            com.umeng.a.a.a(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // android.app.Activity
    protected void onRestart() {
        System.out.println("BaseActivity" + getClass().getSimpleName() + " onRestart() invoked!!");
        super.onRestart();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        System.out.println("BaseActivity" + getClass().getSimpleName() + " onResume() invoked!!");
        com.umeng.a.a.b(this);
    }

    @Override // android.app.Activity
    protected void onStart() {
        System.out.println("BaseActivity" + getClass().getSimpleName() + " onStart() invoked!!");
        super.onStart();
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        System.out.println("BaseActivity" + getClass().getSimpleName() + " onStop() invoked!!");
    }
}
