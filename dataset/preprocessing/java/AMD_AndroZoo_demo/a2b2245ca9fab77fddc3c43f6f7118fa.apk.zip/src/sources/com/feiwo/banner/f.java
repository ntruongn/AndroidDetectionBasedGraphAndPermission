package com.feiwo.banner;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class f implements View.OnClickListener {
    final /* synthetic */ d a;
    private final /* synthetic */ Intent b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(d dVar, Intent intent) {
        this.a = dVar;
        this.b = intent;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        com.feiwo.banner.c.a aVar;
        com.feiwo.banner.c.a aVar2;
        String str;
        String str2;
        Context context;
        String str3;
        Context context2;
        com.feiwo.banner.c.a aVar3;
        Context context3;
        Context context4;
        Context context5;
        Context context6;
        Context context7;
        com.feiwo.banner.c.a aVar4;
        com.feiwo.banner.c.a aVar5;
        RelativeLayout relativeLayout;
        RelativeLayout relativeLayout2;
        RelativeLayout relativeLayout3;
        ImageView imageView;
        ImageView imageView2;
        com.feiwo.banner.c.a aVar6;
        RelativeLayout relativeLayout4;
        RelativeLayout relativeLayout5;
        RelativeLayout relativeLayout6;
        ImageView imageView3;
        ImageView imageView4;
        Context context8;
        com.feiwo.banner.c.a aVar7;
        String str4;
        com.feiwo.banner.c.a aVar8;
        Context context9;
        AdBanner adBanner;
        String str5;
        com.feiwo.banner.c.a unused;
        aVar = this.a.h;
        switch (aVar.g()) {
            case 1001:
            case 1005:
            case 1006:
                context7 = this.a.g;
                context7.startActivity(this.b);
                break;
            case 1002:
                context5 = this.a.g;
                context5.startActivity(this.b);
                break;
            case 1003:
                context6 = this.a.g;
                context6.startActivity(this.b);
                break;
            case 1004:
                context4 = this.a.g;
                context4.startActivity(Intent.createChooser(this.b, "选择邮件客户端"));
                break;
            case 1007:
                d dVar = this.a;
                aVar2 = this.a.h;
                if (aVar2.h().get(0) != null) {
                    aVar3 = this.a.h;
                    str = (String) aVar3.h().get(0);
                } else {
                    str = "";
                }
                dVar.n = str;
                try {
                    Intent intent = new Intent();
                    intent.setClassName("com.tencent.mm", "com.tencent.mm.ui.qrcode.GetQRCodeInfoUI");
                    str3 = this.a.n;
                    intent.setData(Uri.parse(str3));
                    context2 = this.a.g;
                    context2.startActivity(intent);
                    break;
                } catch (ActivityNotFoundException e) {
                    Intent intent2 = new Intent();
                    intent2.setAction("android.intent.action.VIEW");
                    str2 = this.a.n;
                    intent2.setData(Uri.parse(str2));
                    context = this.a.g;
                    context.startActivity(intent2);
                    break;
                }
            case 2002:
                aVar4 = this.a.h;
                if (aVar4.c() == null) {
                    if (com.feiwo.banner.e.e.a(this.a.getContext()) != 10) {
                        if (com.feiwo.banner.e.e.a(this.a.getContext()) == 11 || com.feiwo.banner.e.e.a(this.a.getContext()) == 12) {
                            aVar5 = this.a.h;
                            if (!aVar5.q()) {
                                relativeLayout = this.a.b;
                                if (relativeLayout.getVisibility() != 8) {
                                    relativeLayout2 = this.a.b;
                                    relativeLayout2.setVisibility(8);
                                    break;
                                } else {
                                    relativeLayout3 = this.a.b;
                                    relativeLayout3.setVisibility(0);
                                    imageView = this.a.c;
                                    if (imageView != null) {
                                        imageView2 = this.a.c;
                                        imageView2.setOnClickListener(new h(this, this.b, aVar4));
                                        break;
                                    }
                                }
                            } else {
                                d.a(this.a, this.b, aVar4);
                                break;
                            }
                        }
                    } else {
                        aVar6 = this.a.h;
                        if (!aVar6.a().booleanValue()) {
                            d.a(this.a, this.b, aVar4);
                            break;
                        } else {
                            relativeLayout4 = this.a.b;
                            if (relativeLayout4.getVisibility() != 8) {
                                relativeLayout5 = this.a.b;
                                relativeLayout5.setVisibility(8);
                                break;
                            } else {
                                relativeLayout6 = this.a.b;
                                relativeLayout6.setVisibility(0);
                                imageView3 = this.a.c;
                                if (imageView3 != null) {
                                    imageView4 = this.a.c;
                                    imageView4.setOnClickListener(new g(this, this.b, aVar4));
                                    break;
                                }
                            }
                        }
                    }
                } else {
                    context8 = this.a.g;
                    Intent intent3 = new Intent(context8, (Class<?>) WebViewActivity.class);
                    Bundle bundle = new Bundle();
                    d dVar2 = this.a;
                    aVar7 = this.a.h;
                    dVar2.n = aVar7.c();
                    str4 = this.a.n;
                    bundle.putString("url", str4);
                    aVar8 = this.a.h;
                    bundle.putSerializable("ad", aVar8);
                    intent3.putExtras(bundle);
                    context9 = this.a.g;
                    context9.startActivity(intent3);
                    break;
                }
                break;
            case 2003:
                context3 = this.a.g;
                context3.startActivity(this.b);
                break;
        }
        adBanner = this.a.i;
        unused = this.a.h;
        str5 = this.a.n;
        adBanner.a(0, str5);
    }
}
