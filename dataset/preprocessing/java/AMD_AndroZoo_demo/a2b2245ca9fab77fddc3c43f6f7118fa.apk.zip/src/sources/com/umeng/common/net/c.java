package com.umeng.common.net;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;
import com.feiwothree.coverscreen.AdComponent;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class c extends Handler {
    final /* synthetic */ DownloadingService a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(DownloadingService downloadingService) {
        this.a = downloadingService;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        String str;
        String str2;
        boolean d;
        Map map;
        String str3;
        Context context;
        Context context2;
        str = DownloadingService.c;
        com.umeng.common.a.c(str, "IncomingHandler(msg.what:" + message.what + " msg.arg1:" + message.arg1 + " msg.arg2:" + message.arg2 + " msg.replyTo:" + message.replyTo);
        switch (message.what) {
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                Bundle data = message.getData();
                str2 = DownloadingService.c;
                com.umeng.common.a.c(str2, "IncomingHandler(msg.getData():" + data);
                f a = f.a(data);
                d = DownloadingService.d(a);
                if (!d) {
                    map = DownloadingService.h;
                    map.put(a, message.replyTo);
                    this.a.c(a);
                    return;
                } else {
                    str3 = DownloadingService.c;
                    com.umeng.common.a.a(str3, String.valueOf(a.b) + " is already in downloading list. ");
                    context = this.a.e;
                    context2 = this.a.e;
                    Toast.makeText(context, com.umeng.common.c.a(context2).d("umeng_common_action_info_exist"), 0).show();
                    return;
                }
            default:
                super.handleMessage(message);
                return;
        }
    }
}
