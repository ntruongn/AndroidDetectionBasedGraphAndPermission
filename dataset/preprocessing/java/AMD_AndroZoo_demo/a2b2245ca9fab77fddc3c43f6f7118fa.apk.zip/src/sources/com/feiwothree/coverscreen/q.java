package com.feiwothree.coverscreen;

import android.content.Context;
import com.feiwothree.coverscreen.a.I;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class q implements com.feiwothree.coverscreen.a.t {
    private final /* synthetic */ Context a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public q(SR sr, Context context, String str) {
        this.a = context;
        this.b = str;
    }

    @Override // com.feiwothree.coverscreen.a.t
    public final void a(boolean z, String str) {
        new StringBuilder("服务器返回（sendAppInstall from ScreenReceiver）：").append(str);
        if (z) {
            return;
        }
        new StringBuilder("上传安装信息失败：").append(str);
        String a = I.a(this.a, "DP_FEIWO", "packnames", (String) null);
        if (a != null) {
            new StringBuilder(String.valueOf(a)).append(",").append(this.b);
        } else {
            String str2 = this.b;
        }
        I.b(this.a, "DP_FEIWO", "packnames", this.b);
    }
}
