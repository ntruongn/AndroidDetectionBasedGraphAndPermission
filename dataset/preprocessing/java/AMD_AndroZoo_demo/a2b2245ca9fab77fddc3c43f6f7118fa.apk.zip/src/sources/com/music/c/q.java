package com.music.c;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class q {
    private static final q a = new q();
    private String b;
    private String c;

    private q() {
    }

    public static q a() {
        return a;
    }

    public String a(int i) {
        int i2 = i / 1000;
        int i3 = i2 / 60;
        int i4 = i2 % 60;
        if (i3 < 10) {
            this.b = "0" + i3;
        } else {
            this.b = new StringBuilder(String.valueOf(i3)).toString();
        }
        if (i4 < 10) {
            this.c = "0" + i4;
        } else {
            this.c = new StringBuilder(String.valueOf(i4)).toString();
        }
        return String.valueOf(this.b) + ":" + this.c;
    }
}
