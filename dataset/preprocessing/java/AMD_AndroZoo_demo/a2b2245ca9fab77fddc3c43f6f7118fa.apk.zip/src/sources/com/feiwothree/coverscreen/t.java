package com.feiwothree.coverscreen;

import android.content.DialogInterface;
import android.view.View;
import com.feiwothree.coverscreen.a.C0010j;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class t implements DialogInterface.OnClickListener {
    private /* synthetic */ r a;
    private final /* synthetic */ View b;
    private final /* synthetic */ C0010j c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public t(r rVar, View view, C0010j c0010j) {
        this.a = rVar;
        this.b = view;
        this.c = c0010j;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        this.a.a(this.b, this.c);
        this.a.a.a(this.c);
        this.a.g();
    }
}
