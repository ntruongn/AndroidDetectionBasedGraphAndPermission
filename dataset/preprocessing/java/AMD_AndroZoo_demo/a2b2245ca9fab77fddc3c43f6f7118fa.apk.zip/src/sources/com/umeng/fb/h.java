package com.umeng.fb;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class h {
    public static Date a(String str) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(str);
        } catch (Exception e) {
            return null;
        }
    }

    public static JSONObject a(Context context) {
        JSONObject jSONObject = new JSONObject();
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            String d = com.umeng.common.b.d(context);
            if (d == null || d.equals("")) {
                if (g.c) {
                    Log.e("MobclickAgent", "No device id");
                }
                return null;
            }
            jSONObject.put("device_id", com.umeng.common.b.c(context));
            jSONObject.put("idmd5", d);
            jSONObject.put("device_model", Build.MODEL);
            String k = com.umeng.common.b.k(context);
            if (k == null) {
                if (g.c) {
                    Log.e("MobclickAgent", "No appkey");
                }
                return null;
            }
            jSONObject.put("appkey", k);
            jSONObject.put("channel", g.h != null ? g.h : com.umeng.common.b.o(context));
            try {
                PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                String str = packageInfo.versionName;
                int i = packageInfo.versionCode;
                jSONObject.put("app_version", str);
                jSONObject.put("version_code", i);
            } catch (PackageManager.NameNotFoundException e) {
                if (g.c) {
                    Log.i("MobclickAgent", "read version fail");
                    e.printStackTrace();
                }
                jSONObject.put("app_version", "unknown");
                jSONObject.put("version_code", "unknown");
            }
            jSONObject.put("sdk_type", "Android");
            jSONObject.put("sdk_version", "4.1.0.20120709");
            jSONObject.put("os", "Android");
            jSONObject.put("os_version", Build.VERSION.RELEASE);
            Configuration configuration = new Configuration();
            Settings.System.getConfiguration(context.getContentResolver(), configuration);
            if (configuration == null || configuration.locale == null) {
                Locale locale = Locale.getDefault();
                if (!g.g || locale == null) {
                    jSONObject.put("country", "Unknown");
                    jSONObject.put("language", "Unknown");
                    jSONObject.put("timezone", 8);
                } else {
                    String country = locale.getCountry();
                    if (TextUtils.isEmpty(country)) {
                        jSONObject.put("country", "Unknown");
                    } else {
                        jSONObject.put("country", country);
                    }
                    String language = locale.getLanguage();
                    if (TextUtils.isEmpty(language)) {
                        jSONObject.put("language", "Unknown");
                    } else {
                        jSONObject.put("language", language);
                    }
                    Calendar calendar = Calendar.getInstance(locale);
                    if (calendar != null) {
                        TimeZone timeZone = calendar.getTimeZone();
                        if (timeZone != null) {
                            jSONObject.put("timezone", timeZone.getRawOffset() / 3600000);
                        } else {
                            jSONObject.put("timezone", 8);
                        }
                    } else {
                        jSONObject.put("timezone", 8);
                    }
                }
            } else {
                jSONObject.put("country", configuration.locale.getCountry());
                jSONObject.put("language", configuration.locale.toString());
                Calendar calendar2 = Calendar.getInstance(configuration.locale);
                if (calendar2 != null) {
                    TimeZone timeZone2 = calendar2.getTimeZone();
                    if (timeZone2 != null) {
                        jSONObject.put("timezone", timeZone2.getRawOffset() / 3600000);
                    } else {
                        jSONObject.put("timezone", 8);
                    }
                } else {
                    jSONObject.put("timezone", 8);
                }
            }
            try {
                DisplayMetrics displayMetrics = new DisplayMetrics();
                ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
                jSONObject.put("resolution", String.valueOf(String.valueOf(displayMetrics.heightPixels)) + "*" + String.valueOf(displayMetrics.widthPixels));
            } catch (Exception e2) {
                if (g.c) {
                    Log.e("MobclickAgent", "read resolution fail");
                    e2.printStackTrace();
                }
                jSONObject.put("resolution", "Unknown");
            }
            try {
                String[] e3 = com.umeng.common.b.e(context);
                jSONObject.put("access", e3[0]);
                if (e3[0].equals("2G/3G")) {
                    jSONObject.put("access_subtype", e3[1]);
                }
            } catch (Exception e4) {
                if (g.c) {
                    Log.i("MobclickAgent", "read access fail");
                    e4.printStackTrace();
                }
                jSONObject.put("access", "Unknown");
            }
            try {
                jSONObject.put("carrier", telephonyManager.getNetworkOperatorName());
            } catch (Exception e5) {
                if (g.c) {
                    Log.i("MobclickAgent", "read carrier fail");
                    e5.printStackTrace();
                }
                jSONObject.put("carrier", "Unknown");
            }
            jSONObject.put("cpu", com.umeng.common.b.a());
            jSONObject.put("package", context.getPackageName());
            return jSONObject;
        } catch (Exception e6) {
            if (g.c) {
                Log.e("MobclickAgent", "getMessageHeader error");
                e6.printStackTrace();
            }
            return null;
        }
    }
}
