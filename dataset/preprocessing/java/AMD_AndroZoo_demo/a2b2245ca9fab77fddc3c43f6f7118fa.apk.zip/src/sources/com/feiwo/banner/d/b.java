package com.feiwo.banner.d;

import android.graphics.Bitmap;
import java.io.InputStream;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class b extends Thread {
    private int H;
    private short[] I;
    private byte[] J;
    private byte[] K;
    private byte[] L;
    private com.feiwo.banner.a.a M;
    private int N;
    private a O;
    public int a;
    public int b;
    private InputStream c;
    private int d;
    private boolean e;
    private int f;
    private int[] g;
    private int[] h;
    private int[] i;
    private int j;
    private int k;
    private int l;
    private boolean m;
    private boolean n;
    private int o;
    private int p;
    private int q;
    private int r;
    private int s;
    private int t;
    private int u;
    private int v;
    private int w;
    private Bitmap x;
    private Bitmap y;
    private com.feiwo.banner.a.a z = null;
    private boolean A = false;
    private byte[] B = new byte[256];
    private int C = 0;
    private int D = 0;
    private int E = 0;
    private boolean F = false;
    private int G = 0;
    private byte[] P = null;

    public b(InputStream inputStream, a aVar) {
        this.O = null;
        this.c = inputStream;
        this.O = aVar;
    }

    private Bitmap a(int i) {
        com.feiwo.banner.a.a aVar = this.M;
        int i2 = 0;
        while (true) {
            if (aVar != null) {
                if (i2 == i) {
                    break;
                }
                i2++;
                aVar = aVar.c;
            } else {
                aVar = null;
                break;
            }
        }
        if (aVar == null) {
            return null;
        }
        return aVar.a;
    }

    private int[] b(int i) {
        int i2;
        int i3 = 0;
        int i4 = i * 3;
        int[] iArr = null;
        byte[] bArr = new byte[i4];
        try {
            i2 = this.c.read(bArr);
        } catch (Exception e) {
            i2 = 0;
        }
        if (i2 < i4) {
            this.d = 1;
        } else {
            iArr = new int[256];
            for (int i5 = 0; i5 < i; i5++) {
                int i6 = i3 + 1;
                int i7 = i6 + 1;
                i3 = i7 + 1;
                iArr[i5] = ((bArr[i3] & 255) << 16) | (-16777216) | ((bArr[i6] & 255) << 8) | (bArr[i7] & 255);
            }
        }
        return iArr;
    }

    private int e() {
        this.d = 0;
        this.N = 0;
        this.M = null;
        this.g = null;
        this.h = null;
        if (this.c != null) {
            String str = "";
            for (int i = 0; i < 6; i++) {
                str = String.valueOf(str) + ((char) g());
            }
            if (str.startsWith("GIF")) {
                this.a = k();
                this.b = k();
                int g = g();
                this.e = (g & 128) != 0;
                this.f = 2 << (g & 7);
                this.j = g();
                g();
                if (this.e && !f()) {
                    this.g = b(this.f);
                    this.k = this.g[this.j];
                }
            } else {
                this.d = 1;
            }
            if (!f()) {
                i();
                if (this.N < 0) {
                    this.d = 1;
                    this.O.a(false, -1);
                } else {
                    this.d = -1;
                    this.O.a(true, -1);
                }
            }
            try {
                this.c.close();
            } catch (Exception e) {
            }
        } else {
            this.d = 2;
            this.O.a(false, -1);
        }
        return this.d;
    }

    private boolean f() {
        return this.d != 0;
    }

    private int g() {
        try {
            return this.c.read();
        } catch (Exception e) {
            this.d = 1;
            return 0;
        }
    }

    private int h() {
        this.C = g();
        int i = 0;
        if (this.C > 0) {
            while (i < this.C) {
                try {
                    int read = this.c.read(this.B, i, this.C - i);
                    if (read == -1) {
                        break;
                    }
                    i += read;
                } catch (Exception e) {
                }
            }
            if (i < this.C) {
                this.d = 1;
            }
        }
        return i;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:160:0x0003 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:86:0x034d A[LOOP:4: B:84:0x0111->B:86:0x034d, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:90:0x011e A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r6v23 */
    /* JADX WARN: Type inference failed for: r6v24 */
    /* JADX WARN: Type inference failed for: r6v25 */
    /* JADX WARN: Type inference failed for: r6v28, types: [short] */
    /* JADX WARN: Type inference failed for: r6v30 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void i() {
        /*
            Method dump skipped, instructions count: 1218
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.feiwo.banner.d.b.i():void");
    }

    private void j() {
        do {
            h();
            if (this.B[0] == 1) {
                byte[] bArr = this.B;
                byte[] bArr2 = this.B;
            }
            if (this.C <= 0) {
                return;
            }
        } while (!f());
    }

    private int k() {
        return g() | (g() << 8);
    }

    private void l() {
        do {
            h();
            if (this.C <= 0) {
                return;
            }
        } while (!f());
    }

    public final void a() {
        com.feiwo.banner.a.a aVar = this.M;
        while (aVar != null) {
            aVar.a = null;
            this.M = this.M.c;
            aVar = this.M;
        }
        if (this.c != null) {
            try {
                this.c.close();
            } catch (Exception e) {
            }
            this.c = null;
        }
        this.P = null;
    }

    public final int b() {
        return this.N;
    }

    public final Bitmap c() {
        return a(0);
    }

    public final com.feiwo.banner.a.a d() {
        if (!this.A) {
            this.A = true;
            return this.M;
        }
        if (this.d != 0) {
            this.z = this.z.c;
            if (this.z == null) {
                this.z = this.M;
            }
        } else if (this.z.c != null) {
            this.z = this.z.c;
        }
        return this.z;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        if (this.c != null) {
            e();
        }
    }
}
