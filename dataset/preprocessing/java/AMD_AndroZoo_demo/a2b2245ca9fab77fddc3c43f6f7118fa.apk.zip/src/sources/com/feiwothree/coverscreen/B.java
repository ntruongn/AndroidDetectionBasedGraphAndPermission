package com.feiwothree.coverscreen;

import android.view.MotionEvent;
import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class B implements View.OnTouchListener {
    private /* synthetic */ A a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public B(A a) {
        this.a = a;
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        z zVar;
        zVar = this.a.a;
        zVar.c.onTouchEvent(motionEvent);
        return true;
    }
}
