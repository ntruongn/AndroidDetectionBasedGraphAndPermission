package com.umeng.fb.c;

import android.content.Context;
import com.feiwothree.coverscreen.AdComponent;
import com.umeng.fb.h;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class d {
    public static synchronized JSONObject a(Context context, String str, int i, int i2, JSONObject jSONObject, JSONObject jSONObject2) {
        JSONObject a;
        synchronized (d.class) {
            a = h.a(context);
            try {
                a.put("user_id", a.getString("idmd5"));
                a.put("thread", str);
                a.put("content", "Not supported on client yet");
                a.put("datetime", com.umeng.common.b.b.a());
                a.put("feedback_id", c.a("FB", a.getString("appkey"), a.getString("user_id")));
                a.put("type", "new_feedback");
                JSONObject jSONObject3 = new JSONObject();
                jSONObject3.put("age_group", i);
                switch (i2) {
                    case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
                        jSONObject3.put("gender", "male");
                        break;
                    case AdComponent.FAIL_NO_AD /* 2 */:
                        jSONObject3.put("gender", "female");
                        break;
                }
                jSONObject3.put("contact", jSONObject);
                jSONObject3.put("remark", jSONObject2);
                a.put("userinfo", jSONObject3);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return a;
    }

    public static synchronized JSONObject a(Context context, String str, String str2) {
        JSONObject jSONObject;
        synchronized (d.class) {
            String k = com.umeng.common.b.k(context);
            String d = com.umeng.common.b.d(context);
            jSONObject = new JSONObject();
            try {
                jSONObject.put("type", "user_reply");
                jSONObject.put("appkey", k);
                jSONObject.put("content", str);
                jSONObject.put("user_id", d);
                jSONObject.put("datetime", com.umeng.common.b.b.a());
                jSONObject.put("feedback_id", str2);
                jSONObject.put("reply_id", c.a());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return jSONObject;
    }

    public static boolean a(JSONObject jSONObject) {
        if (jSONObject == null) {
            return false;
        }
        try {
            if (jSONObject.has("state")) {
                return "ok".equals(jSONObject.getString("state"));
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static synchronized boolean a(JSONObject jSONObject, String str, String str2) {
        boolean z;
        synchronized (d.class) {
            try {
                jSONObject.put(str, str2);
                z = true;
            } catch (JSONException e) {
                e.printStackTrace();
                z = false;
            }
        }
        return z;
    }

    public static synchronized boolean b(JSONObject jSONObject) {
        boolean a;
        synchronized (d.class) {
            a = a(jSONObject, "state", "fail");
        }
        return a;
    }

    public static synchronized boolean c(JSONObject jSONObject) {
        boolean a;
        synchronized (d.class) {
            a = a(jSONObject, "state", "sending");
        }
        return a;
    }

    public static synchronized boolean d(JSONObject jSONObject) {
        boolean a;
        synchronized (d.class) {
            a = a(jSONObject, "state", "ok");
        }
        return a;
    }
}
