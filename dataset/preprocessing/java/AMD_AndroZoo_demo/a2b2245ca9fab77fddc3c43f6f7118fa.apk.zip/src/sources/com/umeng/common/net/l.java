package com.umeng.common.net;

import android.content.Context;
import android.widget.Toast;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class l implements Runnable {
    final /* synthetic */ DownloadingService a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(DownloadingService downloadingService, String str) {
        this.a = downloadingService;
        this.b = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        Context context;
        context = this.a.e;
        Toast.makeText(context, this.b, 0).show();
    }
}
