package com.music.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.widget.Toast;
import com.music.activity.ListMusicsActivity;
import com.music.activity.PlayerActivity;
import com.music.c.f;
import com.music.c.p;
import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class MusicService extends Service implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, Runnable {
    public static ArrayList a = new ArrayList();
    public static String b;
    public static String c;
    public String d;
    private BroadcastReceiver f;
    private Uri g;
    private MediaPlayer h;
    private int i = 0;
    Intent e = new Intent("com.run");

    private void a(String str) {
        if (this.h == null) {
            System.out.println("mediaPlayer 是空");
            this.g = Uri.parse(str);
            System.out.println("即将播放的音乐uri：" + this.g);
            this.h = MediaPlayer.create(this, this.g);
            PlayerActivity.c = 0;
            if (this.h == null) {
                return;
            }
            System.out.println("初始化后 mediaPlayer 不为空");
            this.h.start();
            com.music.c.a.e = true;
        } else if (this.i == 1) {
            PlayerActivity.c = 0;
            this.h.stop();
            this.g = Uri.parse(str);
            this.h = MediaPlayer.create(this, this.g);
            if (this.h == null) {
                return;
            }
            this.h.start();
            com.music.c.a.e = true;
        } else {
            System.out.println("暂停结束，又开始播放了");
            if (this.h == null) {
                return;
            }
            this.h.start();
            com.music.c.a.e = true;
        }
        new Thread(this).start();
        this.h.setOnCompletionListener(this);
        this.h.setOnErrorListener(this);
    }

    private void b() {
        a = ListMusicsActivity.c;
        if (this.h != null) {
            this.h.release();
            this.h = null;
        }
        PlayerActivity.c = 0;
        String str = new String[]{"顺序播放", "单曲循环", "随机播放"}[new p(getApplication()).a("Mode", "selectedMode")];
        System.out.println("服务 ：播放模式=" + str);
        if (str.trim().equals("")) {
            str = "顺序播放";
        }
        if (str.equals("随机播放")) {
            com.music.c.a.d = (int) (Math.random() * a.size());
            f.a.clear();
            f fVar = new f();
            this.d = ((HashMap) a.get(com.music.c.a.d)).get("musicPath").toString().replace(".mp3", ".LRC");
            fVar.a(this.d);
        } else if (str.equals("顺序播放")) {
            if (com.music.c.a.d < a.size() - 1) {
                com.music.c.a.d++;
            } else {
                com.music.c.a.d = 0;
            }
        }
        b = ((HashMap) a.get(com.music.c.a.d)).get("musicPath").toString();
        this.d = b.replace(".mp3", ".LRC");
        a();
        a(b);
        sendBroadcast(new Intent("onCompletion"));
        sendBroadcast(new Intent("musicPlayFinish"));
    }

    public void a() {
        if (b.equals(c)) {
            if (f.a == null || f.a.size() == 0) {
                new f().a(this.d);
                return;
            }
            return;
        }
        c = b;
        if (f.a != null && f.a.size() > 0) {
            f.a.clear();
        }
        new f().a(this.d);
        if (f.a == null || f.a.size() <= 0) {
            return;
        }
        System.out.println("重新解析的歌词：" + f.a.toString());
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.media.MediaPlayer.OnCompletionListener
    public void onCompletion(MediaPlayer mediaPlayer) {
        b();
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        IntentFilter intentFilter = new IntentFilter("checkMusic");
        this.f = new c(this);
        registerReceiver(this.f, intentFilter);
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        if (this.f != null) {
            unregisterReceiver(this.f);
        }
        Thread.interrupted();
    }

    @Override // android.media.MediaPlayer.OnErrorListener
    public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
        try {
            this.h.release();
            this.h = null;
        } catch (Exception e) {
            Toast.makeText(this, "播放出现异常,错误信息" + e.getMessage(), 0).show();
            b();
        }
        return false;
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        com.music.c.a.e = false;
        this.d = "";
        if (intent == null) {
            if (this.h != null && this.h.isPlaying()) {
                this.h.stop();
                this.h.release();
                this.h = null;
            }
            stopSelf();
            return super.onStartCommand(intent, i, i2);
        }
        String action = intent.getAction();
        if (action != null) {
            if (action.equals("exit")) {
                com.music.c.a.e = false;
                if (this.h != null && this.h.isPlaying()) {
                    this.h.stop();
                    this.h.release();
                    this.h = null;
                }
                stopSelf();
            } else if (action.equals("R.id.imgPause")) {
                if (this.h != null) {
                    this.h.pause();
                    com.music.c.a.e = false;
                }
            } else if (action.equals("R.id.imgStop") && this.h != null) {
                this.h.stop();
                com.music.c.a.e = false;
                this.h = null;
            }
            b = intent.getStringExtra("musicPath");
            if (b == null || "".equals(b.trim())) {
                if (this.h != null && this.h.isPlaying()) {
                    this.h.stop();
                    this.h.release();
                    this.h = null;
                }
                stopSelf();
                return super.onStartCommand(intent, i, i2);
            }
            this.d = b.replace(".mp3", ".LRC");
            a();
            this.i = intent.getIntExtra("isInitMediaPlayer", 0);
            if (action.equals("R.id.imgPlay")) {
                a(b);
            } else if (action.equals("R.id.imgNext")) {
                com.music.c.a.e = false;
                if (this.h != null) {
                    this.h.release();
                    this.h = null;
                }
                a(b);
            } else if (action.equals("R.id.imgFront")) {
                com.music.c.a.e = false;
                if (this.h != null) {
                    this.h.release();
                    this.h = null;
                }
                a(b);
            }
        }
        return super.onStartCommand(intent, i, i2);
    }

    @Override // java.lang.Runnable
    public void run() {
        while (com.music.c.a.e && this.h != null) {
            try {
                this.e.putExtra("newTime", this.h.getCurrentPosition());
                this.e.putExtra("sumTime", this.h.getDuration());
                sendBroadcast(this.e);
                Thread.sleep(1000L);
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("出错啦：" + e.toString());
                if (this.h != null) {
                    this.h.release();
                    this.h = null;
                }
            }
        }
        System.out.println("停止发送播放信息");
    }
}
