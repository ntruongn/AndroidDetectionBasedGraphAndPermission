package com.feiwothree.coverscreen;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;
import com.feiwothree.coverscreen.a.C0001a;
import com.feiwothree.coverscreen.a.C0002b;
import com.feiwothree.coverscreen.a.C0004d;
import com.feiwothree.coverscreen.a.C0009i;
import com.feiwothree.coverscreen.a.C0010j;
import com.feiwothree.coverscreen.a.I;
import com.feiwothree.coverscreen.a.J;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class SA extends Activity {
    Context b;
    private r c;
    private List d;
    Handler a = new Handler();
    private List e = new ArrayList();
    private BroadcastReceiver f = new i(this);

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(SA sa) {
        if (CoverAdComponent.getInstance() == null) {
            sa.finish();
            return;
        }
        int intExtra = sa.getIntent().getIntExtra("index", 0);
        List list = (List) sa.getIntent().getSerializableExtra("ads");
        if (list == null || list.isEmpty()) {
            sa.finish();
            return;
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        sa.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int i = displayMetrics.widthPixels;
        int i2 = displayMetrics.heightPixels;
        I.a(sa, "DP_FEIWO", "dpswitchdelay", 10000);
        sa.d = list;
        if (sa.d.isEmpty()) {
            sa.finish();
        } else {
            sa.c = new z(sa, sa.d, intExtra);
            sa.setContentView(sa.c, new ViewGroup.LayoutParams(-1, -1));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(C0010j c0010j) {
        if (c0010j == null) {
            return;
        }
        new StringBuilder("点击类型：").append(c0010j.h());
        if (!C0009i.a(getContext())) {
            Log.w("LOG", "NO NETWORK");
            return;
        }
        if (!J.a(c0010j.e())) {
            Intent intent = new Intent("broadcast.route.control");
            intent.putExtra("type", 1);
            intent.putExtra("packageName", c0010j.e());
            sendBroadcast(intent);
        }
        JSONObject a = C0001a.a(getContext(), 0.0d, 0.0d, CoverAdComponent.getInstance().d(), 0, new StringBuilder().append(c0010j.m()).toString(), "");
        com.feiwothree.coverscreen.a.u uVar = new com.feiwothree.coverscreen.a.u();
        uVar.a(getContext(), C0002b.a(), CoverAdComponent.getInstance().d(), a.toString());
        uVar.a(new n(this));
        com.feiwothree.coverscreen.a.s.a().a(uVar);
        if ("download".equals(c0010j.h())) {
            if (C0009i.a().a(c0010j.f())) {
                Toast.makeText(getApplicationContext(), "已在下载中", 0).show();
            } else {
                Toast.makeText(getApplicationContext(), "正在下载  " + c0010j.d() + " 可到通知栏查看", 0).show();
                com.feiwothree.coverscreen.a.r.a();
                C0004d.a().a(getContext(), c0010j.k(), com.feiwothree.coverscreen.a.r.a(getContext(), com.feiwothree.coverscreen.a.l.a, c0010j.k()), null);
                C0009i.a().a(new C0001a(c0010j.a(), c0010j.d(), c0010j.k(), c0010j.e(), c0010j.f()), new l(this, c0010j));
            }
            if (this.d.isEmpty()) {
                finish();
                return;
            }
            return;
        }
        if (!"weixin".equals(c0010j.h())) {
            if ("weburl".equals(c0010j.h())) {
                Intent intent2 = new Intent(this, (Class<?>) WA.class);
                intent2.putExtra("url", c0010j.i());
                startActivity(intent2);
                if (this.d.isEmpty()) {
                    finish();
                    return;
                }
                return;
            }
            return;
        }
        new StringBuilder("打开微信关注：").append(c0010j.g());
        Intent intent3 = new Intent();
        intent3.setFlags(335544320);
        try {
            intent3.setClassName("com.tencent.mm", "com.tencent.mm.ui.qrcode.GetQRCodeInfoUI");
            intent3.setData(Uri.parse(c0010j.g()));
            startActivity(intent3);
        } catch (ActivityNotFoundException e) {
            new StringBuilder("打开微信关注失败（weixin）：").append(e);
            intent3.setAction("android.intent.action.VIEW");
            intent3.setData(Uri.parse(c0010j.g()));
            startActivity(intent3);
        }
        if (this.d.isEmpty()) {
            finish();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void b(C0010j c0010j) {
        if (c0010j == null || this.e.contains(Integer.valueOf(c0010j.a()))) {
            return;
        }
        this.e.add(Integer.valueOf(c0010j.a()));
        JSONObject a = C0001a.a(getContext(), c0010j.m());
        com.feiwothree.coverscreen.a.u uVar = new com.feiwothree.coverscreen.a.u();
        uVar.a(getContext(), C0002b.b(), CoverAdComponent.getInstance().d(), a.toString());
        uVar.a(new o(this));
        com.feiwothree.coverscreen.a.s.a().a(uVar);
    }

    public final Context getContext() {
        if (this.b == null) {
            this.b = getApplicationContext();
        }
        return this.b;
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        CoverAdComponent.close(this);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        setContentView(frameLayout);
        registerReceiver(this.f, new IntentFilter("broadcast.route.control.close"));
        this.a.postDelayed(new j(this), 50L);
    }

    @Override // android.app.Activity
    protected final void onDestroy() {
        super.onDestroy();
        if (this.f != null) {
            unregisterReceiver(this.f);
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i, KeyEvent keyEvent) {
        new StringBuilder("Ad Activity onKeyDown: ").append(i);
        return true;
    }

    @Override // android.app.Activity
    protected final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.a.postDelayed(new k(this), 50L);
    }

    @Override // android.app.Activity
    protected final void onResume() {
        super.onResume();
        if (this.c != null) {
            this.c.g();
        }
    }

    @Override // android.app.Activity
    protected final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }

    @Override // android.app.Activity
    protected final void onStop() {
        super.onStop();
        if (this.c != null) {
            this.c.h();
        }
    }
}
