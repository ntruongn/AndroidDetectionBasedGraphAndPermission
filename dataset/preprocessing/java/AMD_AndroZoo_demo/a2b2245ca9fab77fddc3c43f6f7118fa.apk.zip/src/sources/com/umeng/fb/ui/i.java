package com.umeng.fb.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Collections;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class i extends BaseAdapter {
    LayoutInflater a;
    Context b;
    List c;
    String d = "";
    String e = "FeedbackListAdapter";

    public i(Context context, List list) {
        this.b = context;
        this.a = LayoutInflater.from(context);
        Collections.sort(list);
        this.c = list;
    }

    private String a(com.umeng.fb.e eVar) {
        return eVar.d.a();
    }

    private String b(com.umeng.fb.e eVar) {
        if (eVar.b == com.umeng.fb.f.Normal) {
            for (int size = eVar.f.size() - 1; size >= 0; size--) {
                com.umeng.fb.c cVar = eVar.a(size).f;
                if (cVar == com.umeng.fb.c.Sending) {
                    return this.b.getString(com.umeng.fb.b.e.f(this.b));
                }
                if (cVar == com.umeng.fb.c.Fail) {
                    return this.b.getString(com.umeng.fb.b.e.g(this.b));
                }
                if (cVar == com.umeng.fb.c.Resending) {
                    return this.b.getString(com.umeng.fb.b.e.h(this.b));
                }
            }
        } else {
            if (eVar.b == com.umeng.fb.f.PureFail) {
                return this.b.getString(com.umeng.fb.b.e.i(this.b));
            }
            if (eVar.b == com.umeng.fb.f.PureSending) {
                return this.b.getString(com.umeng.fb.b.e.f(this.b));
            }
        }
        return "";
    }

    private String c(com.umeng.fb.e eVar) {
        if (eVar.f.size() == 1 || eVar.e.e != com.umeng.fb.d.DevReply) {
            return null;
        }
        return eVar.e.a();
    }

    private String d(com.umeng.fb.e eVar) {
        return com.umeng.fb.c.c.a(eVar.e.d, this.b);
    }

    public com.umeng.fb.e a(int i) {
        return (com.umeng.fb.e) this.c.get(i);
    }

    public void a(List list) {
        Collections.sort(list);
        this.c = list;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.c.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        j jVar;
        if (view == null || view.getTag() == null) {
            view = this.a.inflate(com.umeng.fb.b.d.b(this.b), (ViewGroup) null);
            jVar = new j(this);
            jVar.a = (ImageView) view.findViewById(com.umeng.fb.b.c.g(this.b));
            jVar.b = (TextView) view.findViewById(com.umeng.fb.b.c.h(this.b));
            jVar.c = (TextView) view.findViewById(com.umeng.fb.b.c.i(this.b));
            jVar.d = (TextView) view.findViewById(com.umeng.fb.b.c.j(this.b));
            view.setTag(jVar);
        } else {
            jVar = (j) view.getTag();
        }
        com.umeng.fb.e eVar = (com.umeng.fb.e) this.c.get(i);
        String a = a(eVar);
        String c = c(eVar);
        String b = b(eVar);
        String d = d(eVar);
        jVar.b.setText(a);
        if (c == null) {
            jVar.c.setVisibility(8);
        } else {
            jVar.c.setVisibility(0);
            jVar.c.setText(c);
        }
        if (com.umeng.common.b.b.c(b)) {
            jVar.d.setText(d);
        } else {
            jVar.d.setText(b);
        }
        if (com.umeng.fb.c.e.a(this.b, eVar)) {
            jVar.a.setVisibility(0);
            jVar.a.setBackgroundResource(com.umeng.fb.b.b.a(this.b));
        } else {
            jVar.a.setVisibility(4);
        }
        return view;
    }
}
