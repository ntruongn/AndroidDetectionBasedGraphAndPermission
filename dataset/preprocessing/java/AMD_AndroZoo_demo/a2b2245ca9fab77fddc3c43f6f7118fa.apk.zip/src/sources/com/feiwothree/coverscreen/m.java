package com.feiwothree.coverscreen;

import android.content.Intent;
import android.net.Uri;
import com.feiwothree.coverscreen.a.C0001a;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class m implements Runnable {
    private /* synthetic */ l a;
    private final /* synthetic */ String b;
    private final /* synthetic */ C0001a c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public m(l lVar, String str, C0001a c0001a) {
        this.a = lVar;
        this.b = str;
        this.c = c0001a;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(268435456);
        intent.setDataAndType(Uri.fromFile(new File(this.b)), "application/vnd.android.package-archive");
        com.feiwothree.coverscreen.a.x.a(this.a.a.b).a(this.c.e() + 12345, 17301586, this.c.a(), this.c.a(), "下载完成，点击安装", intent, 34, this.c.b(), System.currentTimeMillis());
    }
}
