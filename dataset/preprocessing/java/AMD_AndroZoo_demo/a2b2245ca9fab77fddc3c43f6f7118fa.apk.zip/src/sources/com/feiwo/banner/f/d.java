package com.feiwo.banner.f;

import android.content.Context;
import java.io.File;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class d {
    private static String a = "ClearCacheUtil";

    private static int a(File file, int i) {
        Exception e;
        int i2;
        if (file == null || !file.isDirectory()) {
            return 0;
        }
        try {
            i2 = 0;
            for (File file2 : file.listFiles()) {
                try {
                    if (file2.isDirectory()) {
                        i2 += a(file2, i);
                    }
                    if (file2.lastModified() < new Date().getTime() - (i * 86400000) && file2.delete()) {
                        i2++;
                    }
                } catch (Exception e2) {
                    e = e2;
                    String str = a;
                    String.format("Failed to clean the cache, error %s", e.getMessage());
                    return i2;
                }
            }
            return i2;
        } catch (Exception e3) {
            e = e3;
            i2 = 0;
        }
    }

    public static void a(Context context, int i) {
        String str = a;
        String.format("Starting cache prune, deleting files older than %d days", 3);
        int a2 = a(context.getCacheDir(), 3);
        String str2 = a;
        String.format("Cache pruning completed, %d files deleted", Integer.valueOf(a2));
    }
}
