package com.umeng.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class i {
    static long a = 30000;
    static boolean b = true;
    static boolean c = true;
    static boolean d = true;
    static boolean e = true;
    static boolean f = true;
    static final Object g = new Object();
    static final String[] h = {"http://alog.umeng.com/app_logs", "http://alog.umeng.co/app_logs"};
    static boolean i = true;
}
