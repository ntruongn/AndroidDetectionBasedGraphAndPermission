package com.music.activity;

import android.content.Intent;
import android.widget.SeekBar;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class ac implements SeekBar.OnSeekBarChangeListener {
    final /* synthetic */ PlayerActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ac(PlayerActivity playerActivity) {
        this.a = playerActivity;
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        if (z) {
            int progress = seekBar.getProgress();
            Intent intent = new Intent("checkMusic");
            intent.putExtra("length", progress);
            PlayerActivity.c = this.a.a(progress);
            if (PlayerActivity.c == -1) {
                PlayerActivity.c = 0;
            }
            this.a.sendBroadcast(intent);
        }
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
