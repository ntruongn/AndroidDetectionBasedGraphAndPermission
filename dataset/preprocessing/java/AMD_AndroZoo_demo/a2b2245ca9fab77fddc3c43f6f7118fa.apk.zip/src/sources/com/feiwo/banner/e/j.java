package com.feiwo.banner.e;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class j {
    private static j a = null;
    private ExecutorService b;

    private j() {
        this.b = null;
        this.b = Executors.newFixedThreadPool(5);
    }

    public static j a() {
        if (a == null) {
            a = new j();
        }
        return a;
    }

    public final void a(l lVar) {
        this.b.submit(lVar);
    }
}
