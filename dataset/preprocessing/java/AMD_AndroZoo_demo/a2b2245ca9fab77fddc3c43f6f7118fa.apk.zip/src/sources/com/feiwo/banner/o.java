package com.feiwo.banner;

import android.content.Context;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class o implements com.feiwo.banner.e.k {
    private /* synthetic */ m a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(m mVar) {
        this.a = mVar;
    }

    @Override // com.feiwo.banner.e.k
    public final void a(boolean z, String str) {
        Context context;
        Context context2;
        if (str == null || !z) {
            context = this.a.b;
            com.feiwo.banner.f.e.a(context, "ADFEIWO", "FIRST_USER", true, "12345678");
        } else {
            context2 = this.a.b;
            com.feiwo.banner.f.e.a(context2, "ADFEIWO", "FIRST_USER", false, "12345678");
        }
    }
}
