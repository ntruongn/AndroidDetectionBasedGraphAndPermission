package com.music.activity;

import android.content.DialogInterface;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class x implements DialogInterface.OnClickListener {
    final /* synthetic */ MusicSearchActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public x(MusicSearchActivity musicSearchActivity) {
        this.a = musicSearchActivity;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        if (i == 0) {
            dialogInterface.dismiss();
            new Thread(new aa(this.a)).start();
        }
    }
}
