package com.umeng.a;

import android.content.Context;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class h {
    private ArrayList a = new ArrayList();
    private ArrayList b = new ArrayList();
    private HashMap c = new HashMap();
    private HashMap d = new HashMap();
    private int e = 10;

    private synchronized JSONObject a(JSONObject jSONObject, String str) {
        JSONArray jSONArray;
        boolean z;
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        if (this.a.size() > 0) {
            try {
                if (jSONObject.isNull("event")) {
                    JSONArray jSONArray2 = new JSONArray();
                    jSONObject.put("event", jSONArray2);
                    jSONArray = jSONArray2;
                } else {
                    jSONArray = jSONObject.getJSONArray("event");
                }
                Iterator it = this.a.iterator();
                while (it.hasNext()) {
                    JSONObject jSONObject2 = (JSONObject) it.next();
                    jSONObject2.put("session_id", str);
                    jSONArray.put(jSONObject2);
                }
                this.a.clear();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (this.b.size() > 0) {
            try {
                if (jSONObject.isNull("ekv")) {
                    JSONArray jSONArray3 = new JSONArray();
                    JSONObject jSONObject3 = new JSONObject();
                    b(jSONObject3, str);
                    jSONArray3.put(jSONObject3);
                    jSONObject.put("ekv", jSONArray3);
                } else {
                    JSONArray jSONArray4 = jSONObject.getJSONArray("ekv");
                    int length = jSONArray4.length() - 1;
                    while (true) {
                        if (length < 0) {
                            z = false;
                            break;
                        }
                        if (b((JSONObject) jSONArray4.get(length), str)) {
                            z = true;
                            break;
                        }
                        length--;
                    }
                    if (!z) {
                        JSONObject jSONObject4 = new JSONObject();
                        b(jSONObject4, str);
                        jSONArray4.put(jSONObject4);
                    }
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return jSONObject;
    }

    private boolean b(JSONObject jSONObject, String str) {
        JSONArray jSONArray;
        boolean z;
        if (jSONObject.has(str)) {
            jSONArray = jSONObject.getJSONArray(str);
            z = true;
        } else {
            jSONArray = new JSONArray();
            z = false;
        }
        Iterator it = this.b.iterator();
        while (it.hasNext()) {
            jSONArray.put((JSONObject) it.next());
        }
        this.b.clear();
        jSONObject.put(str, jSONArray);
        return z;
    }

    public int a() {
        return this.a.size() + this.b.size();
    }

    public void a(Context context) {
        String string;
        if (a() > 0 && (string = l.e(context).getString("session_id", null)) != null) {
            l.a(context, a(l.i(context), string));
        }
    }

    public void a(String str) {
        if (this.c.containsKey(str)) {
            ((m) this.c.get(str)).a(Long.valueOf(System.currentTimeMillis()));
            return;
        }
        m mVar = new m(str);
        mVar.a(Long.valueOf(System.currentTimeMillis()));
        this.c.put(str, mVar);
    }

    public long b(String str) {
        if (this.c.containsKey(str)) {
            return ((m) this.c.get(str)).a().longValue();
        }
        return -1L;
    }
}
