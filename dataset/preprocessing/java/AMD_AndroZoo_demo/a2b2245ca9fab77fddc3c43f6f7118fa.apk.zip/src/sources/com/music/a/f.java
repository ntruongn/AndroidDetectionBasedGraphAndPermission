package com.music.a;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class f implements DialogInterface.OnClickListener {
    final /* synthetic */ c a;
    private final /* synthetic */ View b;
    private final /* synthetic */ String c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(c cVar, View view, String str) {
        this.a = cVar;
        this.b = view;
        this.c = str;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        Context context;
        if (i != 0) {
            if (i == 1) {
                dialogInterface.dismiss();
                this.a.a();
                return;
            }
            return;
        }
        dialogInterface.dismiss();
        c cVar = this.a;
        context = this.a.a;
        cVar.d = ProgressDialog.show(context, "下载提示", "信息获取中，请稍后...");
        new Thread(new h(this.a, this.b, this.c)).start();
    }
}
