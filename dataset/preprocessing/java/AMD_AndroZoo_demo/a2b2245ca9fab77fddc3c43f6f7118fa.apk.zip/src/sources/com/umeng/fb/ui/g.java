package com.umeng.fb.ui;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class g {
    LinearLayout a;
    RelativeLayout b;
    TextView c;
    TextView d;
    View e;
    View f;
    final /* synthetic */ f g;

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(f fVar) {
        this.g = fVar;
    }
}
