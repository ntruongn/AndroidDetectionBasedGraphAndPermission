package com.music.c;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.music.activity.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class j {
    public static void a(Context context, Integer num, String str, String str2, String str3, String str4, com.music.view.d dVar, com.music.view.d dVar2, boolean z) {
        com.music.view.a aVar = new com.music.view.a(context, R.style.MyAlertDialog);
        if (z) {
            aVar.setCanceledOnTouchOutside(true);
        }
        if (num != null && num.intValue() > 0) {
            try {
                aVar.a(num.intValue());
            } catch (Exception e) {
                System.out.println("设置自定义dialog顶部图片资源不存在");
            }
        }
        if (TextUtils.isEmpty(str)) {
            str = "温馨提示";
        }
        com.music.view.a a = aVar.a(str);
        if (TextUtils.isEmpty(str2)) {
            str2 = "确定操作?";
        }
        com.music.view.a b = a.b(str2);
        if (TextUtils.isEmpty(str3)) {
            str3 = "确定";
        }
        com.music.view.a a2 = b.a(str3, dVar);
        if (TextUtils.isEmpty(str4)) {
            str4 = "取消";
        }
        a2.b(str4, dVar2).show();
    }

    public static void a(Context context, boolean z, int i, int i2, String str) {
        View inflate = LayoutInflater.from(context).inflate(R.layout.toast_layout, (ViewGroup) null);
        TextView textView = (TextView) inflate.findViewById(R.id.toast_textview);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.toast_imageview);
        try {
            imageView.setImageResource(i2);
        } catch (Exception e) {
            imageView.setImageResource(R.drawable.f023);
        }
        if (str != null) {
            textView.setText(str);
        }
        Toast toast = new Toast(context);
        toast.setDuration(i);
        toast.setView(inflate);
        if (z) {
            toast.setGravity(17, 0, 0);
        }
        toast.show();
    }
}
