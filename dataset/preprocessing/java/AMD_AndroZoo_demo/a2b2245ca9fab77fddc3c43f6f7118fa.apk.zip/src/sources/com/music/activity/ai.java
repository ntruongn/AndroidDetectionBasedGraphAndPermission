package com.music.activity;

import android.widget.RelativeLayout;
import com.feiwo.banner.AdBanner;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class ai implements com.feiwo.banner.a {
    final /* synthetic */ TabHostActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ai(TabHostActivity tabHostActivity) {
        this.a = tabHostActivity;
    }

    @Override // com.feiwo.banner.a
    public void a(AdBanner adBanner) {
        RelativeLayout relativeLayout;
        relativeLayout = this.a.e;
        relativeLayout.setVisibility(0);
    }

    @Override // com.feiwo.banner.a
    public void b(AdBanner adBanner) {
        RelativeLayout relativeLayout;
        relativeLayout = this.a.e;
        relativeLayout.setVisibility(8);
    }
}
