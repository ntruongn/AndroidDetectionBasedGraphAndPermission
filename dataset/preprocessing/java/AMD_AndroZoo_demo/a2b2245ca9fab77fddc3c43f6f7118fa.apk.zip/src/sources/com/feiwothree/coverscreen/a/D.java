package com.feiwothree.coverscreen.a;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.Message;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class D extends Handler {
    private /* synthetic */ C a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public D(C c) {
        this.a = c;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        ConcurrentHashMap concurrentHashMap;
        ConcurrentHashMap concurrentHashMap2;
        if (message.obj == null) {
            return;
        }
        Object[] objArr = (Object[]) message.obj;
        String str = (String) objArr[0];
        Bitmap bitmap = (Bitmap) objArr[1];
        BitmapDrawable bitmapDrawable = null;
        if (bitmap != null) {
            concurrentHashMap2 = this.a.e;
            concurrentHashMap2.put(str, new WeakReference(bitmap));
            bitmapDrawable = new BitmapDrawable(bitmap);
        }
        concurrentHashMap = this.a.c;
        Queue queue = (Queue) concurrentHashMap.remove(str);
        if (queue != null) {
            Iterator it = queue.iterator();
            while (it.hasNext()) {
                ((F) it.next()).a(bitmapDrawable);
            }
        }
    }
}
