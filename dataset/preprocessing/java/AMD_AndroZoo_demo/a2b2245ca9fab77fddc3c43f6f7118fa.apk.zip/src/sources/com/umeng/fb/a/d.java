package com.umeng.fb.a;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class d extends Thread {
    private static ExecutorService b = Executors.newFixedThreadPool(3);
    private Context a;

    public d(Context context) {
        this.a = context;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        boolean z = false;
        ArrayList<com.umeng.fb.e> arrayList = new ArrayList();
        SharedPreferences sharedPreferences = this.a.getSharedPreferences("feedback", 0);
        Iterator<String> it = sharedPreferences.getAll().keySet().iterator();
        while (it.hasNext()) {
            String string = sharedPreferences.getString(it.next(), null);
            if (!com.umeng.common.b.b.c(string) && string.indexOf("fail") != -1) {
                try {
                    arrayList.add(new com.umeng.fb.e(new JSONArray(string)));
                } catch (Exception e) {
                }
            }
        }
        for (com.umeng.fb.e eVar : arrayList) {
            if (eVar.b != com.umeng.fb.f.Normal && eVar.b != com.umeng.fb.f.PureSending) {
                boolean z2 = z;
                int i = -1;
                for (com.umeng.fb.b bVar : eVar.f) {
                    i++;
                    if (bVar.f == com.umeng.fb.c.Fail) {
                        try {
                            JSONArray jSONArray = new JSONArray(sharedPreferences.getString(eVar.c, null));
                            jSONArray.put(i, bVar.g.put("state", com.umeng.fb.c.Resending));
                            sharedPreferences.edit().putString(eVar.c, jSONArray.toString()).commit();
                            f fVar = new f(bVar.g, this.a);
                            if (fVar != null) {
                                b.submit(fVar);
                                z2 = true;
                            }
                        } catch (JSONException e2) {
                        }
                    }
                }
                z = z2;
            }
        }
        if (z) {
            this.a.sendBroadcast(new Intent().setAction("postFeedbackFinished"));
        }
    }
}
