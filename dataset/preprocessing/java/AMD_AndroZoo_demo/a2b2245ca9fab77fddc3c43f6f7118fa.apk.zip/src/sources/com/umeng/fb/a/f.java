package com.umeng.fb.a;

import android.content.Context;
import android.content.Intent;
import java.util.concurrent.Callable;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class f implements Callable {
    static String a = "MsgWorker";
    JSONObject b;
    Context c;

    public f(JSONObject jSONObject, Context context) {
        this.b = jSONObject;
        this.c = context;
    }

    @Override // java.util.concurrent.Callable
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public Boolean call() {
        String str;
        String str2;
        String str3;
        JSONObject jSONObject;
        String optString = this.b.optString("type");
        String optString2 = this.b.optString("feedback_id");
        if ("user_reply".equals(optString)) {
            str = "user_reply";
            str2 = "http://feedback.whalecloud.com/feedback/reply";
            str3 = "reply";
        } else {
            str = "new_feedback";
            str2 = "http://feedback.whalecloud.com/feedback/feedbacks";
            str3 = "feedback";
        }
        try {
            jSONObject = com.umeng.fb.c.c.a(str2, str3, this.b).a();
        } catch (Exception e) {
            e.printStackTrace();
            jSONObject = null;
        }
        Intent putExtra = new Intent().setAction("postFeedbackFinished").putExtra("type", str).putExtra("feedback_id", optString2);
        if (com.umeng.fb.c.d.a(jSONObject)) {
            com.umeng.fb.c.d.d(this.b);
            putExtra.putExtra("PostFeedbackBroadcast", "succeed");
        } else {
            com.umeng.fb.c.d.b(this.b);
            putExtra.putExtra("PostFeedbackBroadcast", "fail");
        }
        if ("user_reply".equals(optString)) {
            com.umeng.fb.c.e.b(this.c, this.b);
        } else {
            com.umeng.fb.c.e.a(this.c, "feedback", optString2);
            com.umeng.fb.c.e.a(this.c, this.b);
        }
        this.c.sendBroadcast(putExtra);
        return null;
    }
}
