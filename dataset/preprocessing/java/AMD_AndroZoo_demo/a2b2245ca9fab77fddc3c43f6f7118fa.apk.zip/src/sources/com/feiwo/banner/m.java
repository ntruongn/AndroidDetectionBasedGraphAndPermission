package com.feiwo.banner;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import org.apache.http.ParseException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class m implements LocationListener {
    private static m a;
    private Context b;
    private double c;
    private double d;

    private m(Context context) {
        this.b = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static m a(Context context) {
        if (a == null) {
            a = new m(context);
        }
        return a;
    }

    private void a(AdBanner adBanner, Handler handler, com.feiwo.banner.c.a aVar) {
        handler.post(new p(this, adBanner, aVar));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(m mVar, AdBanner adBanner, int i, com.feiwo.banner.c.a aVar, String str) {
        try {
            Context context = mVar.b;
            double d = mVar.c;
            double d2 = mVar.d;
            String appKey = adBanner.getAppKey();
            String a2 = com.feiwo.banner.f.k.a(context);
            String c = com.feiwo.banner.f.a.a(context).c();
            String d3 = com.feiwo.banner.f.a.a(context).d();
            String b = com.feiwo.banner.f.a.a(context).b();
            String a3 = com.feiwo.banner.f.a.a(context).a();
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("devid", a2);
            jSONObject.put("adid", aVar.i());
            jSONObject.put("appkey", appKey);
            jSONObject.put("type", i);
            jSONObject.put("lat", d);
            jSONObject.put("lon", d2);
            jSONObject.put("cellid", c);
            jSONObject.put("lac", d3);
            jSONObject.put("mcc", a3);
            jSONObject.put("mnc", b);
            jSONObject.put("url", str);
            jSONObject.put("adsdkversion", "2.4");
            jSONObject.put("sdktype", "BANNER");
            new StringBuilder("click json ").append(jSONObject.toString());
            com.feiwo.banner.f.h.a().a(mVar.b, jSONObject.toString(), com.feiwo.banner.f.b.b(), adBanner.getAppKey());
        } catch (ParseException e) {
        } catch (JSONException e2) {
        } catch (Exception e3) {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(m mVar, AdBanner adBanner, Handler handler) {
        JSONArray jSONArray;
        com.feiwo.banner.f.e.b(mVar.b, "ADFEIWO", "APPKEY", adBanner.getAppKey(), "12345678");
        try {
            Context context = mVar.b;
            double d = mVar.c;
            double d2 = mVar.d;
            String appKey = adBanner.getAppKey();
            String a2 = com.feiwo.banner.f.k.a(context);
            String b = com.feiwo.banner.f.k.b(context);
            String c = com.feiwo.banner.f.k.c(context);
            String a3 = com.feiwo.banner.f.k.a();
            String b2 = com.feiwo.banner.f.k.b();
            int i = com.feiwo.banner.b.a.b;
            int i2 = com.feiwo.banner.b.a.c;
            if (i <= 0 || i2 <= 0) {
                com.feiwo.banner.c.b d3 = com.feiwo.banner.f.k.d(context);
                i = d3.a();
                i2 = d3.b();
            }
            String c2 = com.feiwo.banner.f.a.a(context).c();
            String d4 = com.feiwo.banner.f.a.a(context).d();
            String b3 = com.feiwo.banner.f.a.a(context).b();
            String a4 = com.feiwo.banner.f.a.a(context).a();
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("os", "Android");
            jSONObject.put("devid", a2);
            jSONObject.put("appkey", appKey);
            jSONObject.put("lat", d);
            jSONObject.put("lon", d2);
            jSONObject.put("wifi", b);
            jSONObject.put("ip", c);
            jSONObject.put("direction", "");
            jSONObject.put("sound", "");
            jSONObject.put("keyword", "");
            jSONObject.put("width", String.valueOf(i));
            jSONObject.put("height", String.valueOf(i2));
            jSONObject.put("deviceosversion", b2);
            jSONObject.put("mcc", a4);
            jSONObject.put("mnc", b3);
            jSONObject.put("version", "2.4");
            jSONObject.put("adsdkversion", "2.4");
            jSONObject.put("devicename", a3);
            jSONObject.put("sdkname", "Android");
            jSONObject.put("cellid", c2);
            jSONObject.put("lac", d4);
            com.feiwo.banner.f.i.a();
            jSONObject.put("weixinflag", com.feiwo.banner.f.i.a(context, "com.tencent.mm"));
            jSONObject.put("adsdk", "4.0");
            jSONObject.put("sdktype", "BANNER");
            new StringBuilder("json ").append(jSONObject.toString());
            jSONArray = new JSONArray(com.feiwo.banner.f.h.a().a(mVar.b, jSONObject.toString(), com.feiwo.banner.f.b.a(), adBanner.getAppKey()));
            new StringBuilder(" return json ").append(jSONArray.toString());
        } catch (IllegalStateException e) {
            mVar.a(adBanner, handler, (com.feiwo.banner.c.a) null);
        } catch (ParseException e2) {
            mVar.a(adBanner, handler, (com.feiwo.banner.c.a) null);
        } catch (JSONException e3) {
            mVar.a(adBanner, handler, (com.feiwo.banner.c.a) null);
        } catch (Exception e4) {
            mVar.a(adBanner, handler, (com.feiwo.banner.c.a) null);
        }
        if (jSONArray.length() > 0) {
            Context context2 = mVar.b;
            com.feiwo.banner.c.a aVar = new com.feiwo.banner.c.a(jSONArray.optJSONObject(0));
            com.feiwo.banner.f.e.a(mVar.b, "ADFEIWO", "list_click", new StringBuilder(String.valueOf(aVar.i())).toString(), 0);
            if (com.feiwo.banner.e.e.b(mVar.b).a("/adfeiwo/image/", aVar.d())) {
                mVar.a(adBanner, handler, aVar);
                return;
            } else {
                mVar.a(adBanner, handler, (com.feiwo.banner.c.a) null);
                return;
            }
        }
        mVar.a(adBanner, handler, (com.feiwo.banner.c.a) null);
        Context context3 = mVar.b;
        if (context3.getSharedPreferences("ADFEIWO", 0).getBoolean(com.feiwo.banner.f.f.a("FIRST_USER", "12345678", true), true)) {
            com.feiwo.banner.e.j a5 = com.feiwo.banner.e.j.a();
            String jSONObject2 = com.feiwo.banner.f.a.a(mVar.b, adBanner.getAppKey(), "2.4").toString();
            com.feiwo.banner.e.l lVar = new com.feiwo.banner.e.l();
            lVar.a(mVar.b, com.feiwo.banner.f.b.c(), adBanner.getAppKey(), jSONObject2);
            lVar.a(new o(mVar));
            a5.a(lVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(AdBanner adBanner, int i, com.feiwo.banner.c.a aVar, String str) {
        new Thread(new q(this, aVar, adBanner, i, str)).start();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(AdBanner adBanner, Handler handler) {
        new Thread(new n(this, adBanner, handler)).start();
    }

    @Override // android.location.LocationListener
    public final void onLocationChanged(Location location) {
        this.c = location.getLatitude();
        this.d = location.getLongitude();
    }

    @Override // android.location.LocationListener
    public final void onProviderDisabled(String str) {
    }

    @Override // android.location.LocationListener
    public final void onProviderEnabled(String str) {
    }

    @Override // android.location.LocationListener
    public final void onStatusChanged(String str, int i, Bundle bundle) {
    }
}
