package com.a.a;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import com.music.c.m;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class a {
    private String b;
    private String c;
    private String d;
    private String e;
    private int f;
    private int g;
    private Handler h;
    private com.music.b.b.a i;
    private List k;
    private Context o;
    private String a = " Downloader ";
    private int j = 0;
    private int l = 1;
    private boolean m = false;
    private ArrayList n = new ArrayList();
    private ExecutorService p = Executors.newFixedThreadPool(3);

    private boolean a(String str) {
        return this.i.a(str);
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x00a2  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0114  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0110  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private boolean e() {
        /*
            Method dump skipped, instructions count: 569
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.a.a.a.e():boolean");
    }

    public void a(String str, String str2, String str3, int i, Context context, Handler handler, ArrayList arrayList) {
        this.b = str;
        this.d = str3;
        this.f = i;
        this.h = handler;
        this.o = context;
        this.i = new com.music.b.b.a(context);
        this.n.clear();
        this.n.addAll(arrayList);
        this.m = false;
        this.c = str2;
        b();
        if (this.j == 0) {
            return;
        }
        if (this.g >= this.j) {
            Message obtainMessage = handler.obtainMessage();
            obtainMessage.what = 1;
            obtainMessage.obj = str;
            obtainMessage.arg1 = this.g;
            obtainMessage.arg2 = this.j;
            handler.sendMessage(obtainMessage);
            return;
        }
        if (this.k == null || this.l == 2) {
            return;
        }
        this.l = 2;
        for (com.music.b.c.a aVar : this.k) {
            this.p.submit(new d(this, aVar.a(), aVar.b(), aVar.c(), aVar.d(), aVar.e()));
        }
        new Thread(new c(this, context, str2)).start();
    }

    public boolean a() {
        return this.l == 2;
    }

    public void b() {
        int i = 0;
        if (!a(this.b)) {
            m.b.put(this.b, this);
            this.k = this.i.b(this.b);
            this.g = 0;
            for (com.music.b.c.a aVar : this.k) {
                i += (aVar.c() - aVar.b()) + 1;
                this.g = aVar.d() + this.g;
            }
            this.j = i;
            return;
        }
        if (e()) {
            int i2 = this.j / this.f;
            this.k = new ArrayList();
            for (int i3 = 0; i3 < this.f - 1; i3++) {
                this.k.add(new com.music.b.c.a(i3, i3 * i2, ((i3 + 1) * i2) - 1, 0, this.b));
            }
            this.k.add(new com.music.b.c.a(this.f - 1, (this.f - 1) * i2, this.j - 1, 0, this.b));
            this.i.a(this.k);
        }
    }

    public void c() {
        this.l = 3;
    }

    public void d() {
        this.l = 1;
    }
}
