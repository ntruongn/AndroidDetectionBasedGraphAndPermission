package com.music.b.c;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class b {
    public int a;
    private int b;
    private String c;

    public b() {
    }

    public b(int i, int i2, String str) {
        this.a = i;
        this.b = i2;
        this.c = str;
    }

    public int a() {
        return this.a;
    }

    public int b() {
        return this.b;
    }

    public String toString() {
        return "LoadInfo [fileSize=" + this.a + ", complete=" + this.b + ", urlstring=" + this.c + "]";
    }
}
