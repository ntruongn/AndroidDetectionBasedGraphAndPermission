package com.feiwo.banner.f;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class k {
    public static String a() {
        try {
            return m.a("") ? Build.MANUFACTURER : "";
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String a(Context context) {
        String str;
        try {
            str = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
        } catch (Exception e) {
            e.printStackTrace();
            str = "";
        }
        return m.a(str) ? b(context) : str;
    }

    public static String b() {
        try {
            return Build.VERSION.SDK;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String b(Context context) {
        try {
            return ((WifiManager) context.getSystemService("wifi")).getConnectionInfo().getMacAddress();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String c(Context context) {
        try {
            return ((WifiManager) context.getSystemService("wifi")).getConnectionInfo().getBSSID();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static com.feiwo.banner.c.b d(Context context) {
        com.feiwo.banner.c.b bVar = new com.feiwo.banner.c.b();
        if (com.feiwo.banner.b.a.b > 0 && com.feiwo.banner.b.a.c > 0) {
            bVar.a(com.feiwo.banner.b.a.b);
            bVar.b(com.feiwo.banner.b.a.c);
            return bVar;
        }
        try {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
            bVar.a(displayMetrics.widthPixels);
            bVar.b(displayMetrics.heightPixels);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bVar;
    }
}
