package com.music.activity;

import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.GridView;
import com.feiwothree.coverscreen.AdComponent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class a extends Handler {
    final /* synthetic */ BangdangListActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(BangdangListActivity bangdangListActivity) {
        this.a = bangdangListActivity;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        View view;
        GridView gridView;
        View view2;
        GridView gridView2;
        switch (message.what) {
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                String str = (String) message.obj;
                if (str != null) {
                    com.music.c.j.a(this.a, false, 0, R.drawable.f032, str);
                } else {
                    com.music.c.j.a(this.a, false, 0, R.drawable.f032, "榜单信息获取失败，请稍后再试。");
                }
                view2 = this.a.c;
                view2.setVisibility(0);
                gridView2 = this.a.d;
                gridView2.setVisibility(8);
                break;
            case 7:
                this.a.c();
                break;
            case 8:
                com.music.c.j.a(this.a, false, 0, R.drawable.f032, "榜单信息获取失败。");
                view = this.a.c;
                view.setVisibility(0);
                gridView = this.a.d;
                gridView.setVisibility(8);
                break;
        }
        this.a.g = true;
    }
}
