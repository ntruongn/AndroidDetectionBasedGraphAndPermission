package com.music.c;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class a {
    public static Context g;
    public static int d = 0;
    public static boolean e = false;
    public static boolean f = false;
    public static final String a = "music";
    public static final String b = "photos";
    public static final String c = "log.txt";
    public static final String h = "music_preference";
    public static final String i = "screen_info_width";
    public static final String j = "screen_info_height";
    public static final String k = "screen_info_density";
    public static final int l = 30000;
    public static final int m = 30000;
}
