package com.music.activity;

import android.content.Context;
import com.music.domain.MusicNetWorkInfo;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class k implements Runnable {
    final /* synthetic */ g a;
    private MusicNetWorkInfo b;
    private ArrayList c;

    public k(g gVar, MusicNetWorkInfo musicNetWorkInfo, ArrayList arrayList) {
        this.a = gVar;
        this.b = musicNetWorkInfo;
        this.c = arrayList;
    }

    @Override // java.lang.Runnable
    public void run() {
        Context context;
        com.a.a.a aVar = (com.a.a.a) com.music.c.m.b.get(this.b.musicUrl);
        if (aVar == null) {
            aVar = new com.a.a.a();
        }
        String str = this.b.musicUrl;
        String str2 = this.b.lrcUrl;
        String str3 = String.valueOf(this.b.musicName) + "-" + this.b.musicSinger;
        context = this.a.b;
        aVar.a(str, str2, str3, 1, context, DownloadListActivity.d, this.c);
    }
}
