package com.umeng.common.net;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
interface a {
    void a(int i);

    void a(int i, int i2);

    void a(int i, Exception exc);

    void a(int i, String str);
}
