package com.umeng.common.net;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Debug;
import android.os.Handler;
import android.os.IBinder;
import android.os.Messenger;
import android.text.TextUtils;
import android.widget.RemoteViews;
import android.widget.Toast;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class DownloadingService extends Service {
    final Messenger b = new Messenger(new c(this));
    private NotificationManager d;
    private Context e;
    private Handler f;
    private a g;
    private BroadcastReceiver j;
    private static final String c = DownloadingService.class.getName();
    public static boolean a = false;
    private static Map h = new HashMap();
    private static Map i = new HashMap();
    private static Boolean k = false;

    public static int a(f fVar) {
        return Math.abs((int) ((fVar.b.hashCode() >> 2) + (fVar.c.hashCode() >> 3) + System.currentTimeMillis()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Notification a(f fVar, int i2, int i3) {
        Context applicationContext = getApplicationContext();
        Notification notification = new Notification(17301633, "正在下载应用", 1L);
        RemoteViews remoteViews = new RemoteViews(applicationContext.getPackageName(), com.umeng.common.a.b.a(applicationContext));
        remoteViews.setProgressBar(com.umeng.common.a.a.c(applicationContext), 100, i3, false);
        remoteViews.setTextViewText(com.umeng.common.a.a.b(applicationContext), String.valueOf(i3) + "%");
        remoteViews.setTextViewText(com.umeng.common.a.a.d(applicationContext), String.valueOf(applicationContext.getResources().getString(com.umeng.common.a.c.d(applicationContext.getApplicationContext()))) + fVar.b);
        remoteViews.setTextViewText(com.umeng.common.a.a.a(applicationContext), "");
        remoteViews.setImageViewResource(com.umeng.common.a.a.e(applicationContext), 17301633);
        notification.contentView = remoteViews;
        notification.contentIntent = PendingIntent.getActivity(applicationContext, 0, new Intent(), 134217728);
        if (fVar.e) {
            notification.flags = 2;
            remoteViews.setOnClickPendingIntent(com.umeng.common.a.a.f(applicationContext), p.a(getApplicationContext(), p.a(i2, "continue")));
            remoteViews.setViewVisibility(com.umeng.common.a.a.f(applicationContext), 0);
            b(notification, i2);
            PendingIntent a2 = p.a(getApplicationContext(), p.a(i2, "cancel"));
            remoteViews.setViewVisibility(com.umeng.common.a.a.g(applicationContext), 0);
            remoteViews.setOnClickPendingIntent(com.umeng.common.a.a.g(applicationContext), a2);
        } else {
            notification.flags = 16;
            remoteViews.setViewVisibility(com.umeng.common.a.a.f(applicationContext), 8);
            remoteViews.setViewVisibility(com.umeng.common.a.a.g(applicationContext), 8);
        }
        return notification;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(int i2) {
        d dVar = (d) i.get(Integer.valueOf(i2));
        com.umeng.common.a.c(c, "download service clear cache " + dVar.e.b);
        if (dVar.a != null) {
            dVar.a.a(2);
        }
        this.d.cancel(dVar.c);
        if (h.containsKey(dVar.e)) {
            h.remove(dVar.e);
        }
        dVar.b();
        d();
    }

    private void a(Notification notification, int i2) {
        int f = com.umeng.common.a.a.f(this.e);
        notification.contentView.setTextViewText(f, this.e.getResources().getString(com.umeng.common.a.c.c(this.e.getApplicationContext())));
        notification.contentView.setInt(f, "setBackgroundResource", com.umeng.common.c.a(this.e).b("umeng_common_gradient_green"));
        this.d.notify(i2, notification);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(f fVar, long j, long j2, long j3) {
        if (fVar.d != null) {
            HashMap hashMap = new HashMap();
            hashMap.put("dsize", String.valueOf(j));
            hashMap.put("dtime", com.umeng.common.b.b.a().split(" ")[1]);
            hashMap.put("dpcent", String.valueOf((int) ((j2 > 0 ? ((float) j) / ((float) j2) : 0.0f) * 100.0f)));
            hashMap.put("ptimes", String.valueOf(j3));
            b(hashMap, false, fVar.d);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean a(Context context, Intent intent) {
        try {
            String[] split = intent.getExtras().getString("com.umeng.broadcast.download.msg").split(":");
            int parseInt = Integer.parseInt(split[0]);
            String trim = split[1].trim();
            if (parseInt != 0 && !TextUtils.isEmpty(trim) && i.containsKey(Integer.valueOf(parseInt))) {
                d dVar = (d) i.get(Integer.valueOf(parseInt));
                b bVar = dVar.a;
                if ("continue".equals(trim)) {
                    if (bVar != null) {
                        com.umeng.common.a.c(c, "Receive action do play click.");
                        bVar.a(1);
                        dVar.a = null;
                        a(dVar.b, parseInt);
                        return true;
                    }
                    com.umeng.common.a.c(c, "Receive action do play click.");
                    if (com.umeng.common.b.a(context, "android.permission.ACCESS_NETWORK_STATE") && !com.umeng.common.b.h(context)) {
                        Toast.makeText(context, context.getResources().getString(com.umeng.common.a.c.a(context.getApplicationContext())), 1).show();
                        return false;
                    }
                    b bVar2 = new b(this, context, dVar.e, parseInt, dVar.d, this.g);
                    dVar.a = bVar2;
                    bVar2.start();
                    b(dVar.b, parseInt);
                    return true;
                }
                if ("cancel".equals(trim)) {
                    com.umeng.common.a.c(c, "Receive action do stop click.");
                    try {
                        if (bVar != null) {
                            bVar.a(2);
                        } else {
                            a(dVar.e, dVar.f[0], dVar.f[1], dVar.f[2]);
                        }
                    } catch (Exception e) {
                    } finally {
                        a(parseInt);
                    }
                    return true;
                }
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return false;
    }

    private void b(Notification notification, int i2) {
        int f = com.umeng.common.a.a.f(this.e);
        notification.contentView.setTextViewText(f, this.e.getResources().getString(com.umeng.common.a.c.b(this.e.getApplicationContext())));
        notification.contentView.setInt(f, "setBackgroundResource", com.umeng.common.c.a(this.e).b("umeng_common_gradient_orange"));
        this.d.notify(i2, notification);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void b(Map map, boolean z, String[] strArr) {
        new Thread(new n(strArr, z, map)).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean b(Context context) {
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = ((ActivityManager) context.getSystemService("activity")).getRunningAppProcesses();
        if (runningAppProcesses == null) {
            return false;
        }
        String packageName = context.getPackageName();
        for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses) {
            if (runningAppProcessInfo.importance == 100 && runningAppProcessInfo.processName.equals(packageName)) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c(f fVar) {
        com.umeng.common.a.c(c, "startDownload([mComponentName:" + fVar.a + " mTitle:" + fVar.b + " mUrl:" + fVar.c + "])");
        int a2 = a(fVar);
        b bVar = new b(this, getApplicationContext(), fVar, a2, 0, this.g);
        d dVar = new d(fVar, a2);
        dVar.a();
        dVar.a = bVar;
        bVar.start();
        d();
        if (a) {
            Iterator it = i.keySet().iterator();
            while (it.hasNext()) {
                com.umeng.common.a.c(c, "Running task " + ((d) i.get((Integer) it.next())).e.b);
            }
        }
    }

    private void d() {
        if (a) {
            int size = h.size();
            int size2 = i.size();
            com.umeng.common.a.a(c, "Client size =" + size + "   cacheSize = " + size2);
            if (size != size2) {
                throw new RuntimeException("Client size =" + size + "   cacheSize = " + size2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean d(f fVar) {
        if (a) {
            int nextInt = new Random().nextInt(1000);
            if (h != null) {
                for (f fVar2 : h.keySet()) {
                    com.umeng.common.a.c(c, "_" + nextInt + " downling  " + fVar2.b + "   " + fVar2.c);
                }
            } else {
                com.umeng.common.a.c(c, "_" + nextInt + "downling  null");
            }
        }
        if (h == null) {
            return false;
        }
        Iterator it = h.keySet().iterator();
        while (it.hasNext()) {
            if (((f) it.next()).c.equals(fVar.c)) {
                return true;
            }
        }
        return false;
    }

    public void a(String str) {
        synchronized (k) {
            if (!k.booleanValue()) {
                com.umeng.common.a.c(c, "show single toast.[" + str + "]");
                k = true;
                this.f.post(new l(this, str));
                this.f.postDelayed(new m(this), 1200L);
            }
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        com.umeng.common.a.c(c, "onBind ");
        return this.b.getBinder();
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        if (a) {
            com.umeng.common.a.a = true;
            Debug.waitForDebugger();
        }
        com.umeng.common.a.c(c, "onCreate ");
        this.d = (NotificationManager) getSystemService("notification");
        this.e = this;
        this.f = new j(this);
        this.g = new k(this);
    }

    @Override // android.app.Service
    public void onDestroy() {
        try {
            g.a(getApplicationContext()).a(259200);
            g.a(getApplicationContext()).finalize();
            if (this.j != null) {
                unregisterReceiver(this.j);
            }
        } catch (Exception e) {
            com.umeng.common.a.b(c, e.getMessage());
        }
        super.onDestroy();
    }

    @Override // android.app.Service
    public void onStart(Intent intent, int i2) {
        com.umeng.common.a.c(c, "onStart ");
        a(getApplicationContext(), intent);
        super.onStart(intent, i2);
    }
}
