package com.feiwothree.coverscreen;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class k implements Runnable {
    private /* synthetic */ SA a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(SA sa) {
        this.a = sa;
    }

    @Override // java.lang.Runnable
    public final void run() {
        SA.a(this.a);
    }
}
