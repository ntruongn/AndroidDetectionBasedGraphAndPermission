package com.umeng.fb.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.feiwothree.coverscreen.AdComponent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class f extends BaseAdapter {
    private static /* synthetic */ int[] e;
    Context a;
    LayoutInflater b;
    String c = "FeedbackAdapter";
    com.umeng.fb.e d;

    public f(Context context, com.umeng.fb.e eVar) {
        this.a = context;
        this.d = eVar;
        this.b = LayoutInflater.from(context);
    }

    private void a(com.umeng.fb.b bVar, TextView textView) {
        switch (a()[bVar.f.ordinal()]) {
            case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
                textView.setText(this.a.getString(com.umeng.fb.b.e.r(this.a)));
                textView.setTextColor(-7829368);
                return;
            case AdComponent.FAIL_NO_AD /* 2 */:
                textView.setText(this.a.getString(com.umeng.fb.b.e.s(this.a)));
                textView.setTextColor(-65536);
                return;
            case AdComponent.FAIL_IN_PREPARATION /* 3 */:
            default:
                String b = com.umeng.fb.c.c.b(bVar.d, this.a);
                if ("".equals(b)) {
                    textView.setText("");
                    return;
                } else {
                    textView.setText(b);
                    textView.setTextColor(-7829368);
                    return;
                }
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                textView.setText(this.a.getString(com.umeng.fb.b.e.t(this.a)));
                textView.setTextColor(-65536);
                return;
        }
    }

    static /* synthetic */ int[] a() {
        int[] iArr = e;
        if (iArr == null) {
            iArr = new int[com.umeng.fb.c.valuesCustom().length];
            try {
                iArr[com.umeng.fb.c.Fail.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[com.umeng.fb.c.OK.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[com.umeng.fb.c.Resending.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[com.umeng.fb.c.Sending.ordinal()] = 1;
            } catch (NoSuchFieldError e5) {
            }
            e = iArr;
        }
        return iArr;
    }

    public void a(com.umeng.fb.e eVar) {
        this.d = eVar;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.d == null) {
            return 0;
        }
        return this.d.f.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        g gVar;
        if (view == null) {
            view = this.b.inflate(com.umeng.fb.b.d.e(this.a), (ViewGroup) null);
            g gVar2 = new g(this);
            gVar2.a = (LinearLayout) view.findViewById(com.umeng.fb.b.c.o(this.a));
            gVar2.b = (RelativeLayout) gVar2.a.findViewById(com.umeng.fb.b.c.p(this.a));
            gVar2.c = (TextView) gVar2.a.findViewById(com.umeng.fb.b.c.q(this.a));
            gVar2.d = (TextView) gVar2.a.findViewById(com.umeng.fb.b.c.r(this.a));
            gVar2.e = view.findViewById(com.umeng.fb.b.c.s(this.a));
            gVar2.f = view.findViewById(com.umeng.fb.b.c.t(this.a));
            view.setTag(gVar2);
            gVar = gVar2;
        } else {
            gVar = (g) view.getTag();
        }
        com.umeng.fb.b a = this.d.a(i);
        a(a, gVar.d);
        gVar.c.setText(a.a());
        if (a.e == com.umeng.fb.d.DevReply) {
            gVar.a.setGravity(5);
            gVar.b.setBackgroundResource(com.umeng.fb.b.b.b(this.a));
            gVar.f.setVisibility(8);
            gVar.e.setVisibility(0);
        } else {
            gVar.a.setGravity(3);
            gVar.b.setBackgroundResource(com.umeng.fb.b.b.c(this.a));
            gVar.f.setVisibility(0);
            gVar.e.setVisibility(8);
        }
        return view;
    }
}
