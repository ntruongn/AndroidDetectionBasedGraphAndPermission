package com.music.activity;

import android.app.ProgressDialog;
import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class b implements View.OnClickListener {
    final /* synthetic */ BangdangListActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(BangdangListActivity bangdangListActivity) {
        this.a = bangdangListActivity;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        View view2;
        this.a.g = false;
        view2 = this.a.c;
        view2.setVisibility(8);
        this.a.f = ProgressDialog.show(this.a, "", "数据获取中....", false, true);
        new Thread(new e(this.a)).start();
        new Thread(new d(this.a)).start();
    }
}
