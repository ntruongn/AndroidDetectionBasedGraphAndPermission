package com.music.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.music.domain.ObjectInfo;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class ShowOneBanddangListActivity extends BaseActivity implements View.OnClickListener {
    private ListView b;
    private com.music.a.c c;
    private TextView d;
    private TextView e;
    private Button f;
    private ProgressDialog g;
    private String i;
    private String j;
    private String k;
    private boolean h = false;
    private ArrayList l = new ArrayList();
    private Handler m = new af(this);

    private void a() {
        this.d = (TextView) findViewById(R.id.title);
        Intent intent = getIntent();
        this.j = intent.getStringExtra("bangdanName");
        this.k = intent.getStringExtra("id");
        if (this.j != null) {
            this.d.setText(this.j);
        }
        this.f = (Button) findViewById(R.id.titleLeftButton);
        this.f.setVisibility(0);
        this.f.setOnClickListener(this);
        this.b = (ListView) findViewById(R.id.goods_list);
        this.e = (TextView) findViewById(R.id.category_list_nodata);
        this.e.setOnClickListener(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b() {
        if (this.c != null) {
            this.c.notifyDataSetChanged();
        } else {
            this.c = new com.music.a.c(this, DownloadListActivity.d, this.l);
            this.b.setAdapter((ListAdapter) this.c);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String c() {
        this.i = "http://box.zhangmen.baidu.com/x?op=22&listid=" + this.k;
        String a = com.music.service.a.a(this, this.i, null, "gb2312");
        System.out.println("访问网络得到的类别结果：" + a);
        if (a.contains("error：")) {
            Message obtainMessage = this.m.obtainMessage();
            obtainMessage.what = 4;
            obtainMessage.obj = a.replace("error：", "");
            this.m.sendMessage(obtainMessage);
            return a.replace("error：", "");
        }
        System.out.println("开始解析" + this.j + " xml文件...");
        this.l = com.music.c.n.a(this, a, ObjectInfo.class, "data", new String[]{"id", "name"}, false);
        System.out.println("解析" + this.j + " xml文件结束");
        this.h = true;
        if (this.l == null || this.l.size() <= 0) {
            Message obtainMessage2 = this.m.obtainMessage();
            obtainMessage2.what = 8;
            this.m.sendMessage(obtainMessage2);
        } else {
            Message obtainMessage3 = this.m.obtainMessage();
            obtainMessage3.what = 7;
            this.m.sendMessage(obtainMessage3);
        }
        return "success";
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.category_list_nodata /* 2131230742 */:
                this.g = ProgressDialog.show(this, this.j, "数据获取中....", false, false);
                if (this.l.size() > 0) {
                    this.l.clear();
                }
                new Thread(new ah(this)).start();
                new Thread(new ag(this)).start();
                return;
            case R.id.titleLeftButton /* 2131230762 */:
                finish();
                return;
            default:
                return;
        }
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.music_down);
        a();
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        System.out.println("ShowOneBanddangListActivity 结束啦");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        if (this.l.size() > 0) {
            this.l.clear();
        }
        this.e.setVisibility(8);
        this.g = ProgressDialog.show(this, this.j, "数据获取中....", false, false);
        new Thread(new ah(this)).start();
        new Thread(new ag(this)).start();
    }
}
