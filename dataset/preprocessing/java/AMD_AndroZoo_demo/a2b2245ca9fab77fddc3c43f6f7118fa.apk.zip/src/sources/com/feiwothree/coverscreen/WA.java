package com.feiwothree.coverscreen;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.feiwothree.coverscreen.a.G;
import com.feiwothree.coverscreen.a.J;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class WA extends Activity {
    WebView a;
    String b;
    boolean c = false;
    private TextView d;

    private void a() {
        this.b = getIntent().getStringExtra("url");
        if (J.a(this.b)) {
            finish();
            return;
        }
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.a = new WebView(this);
        this.a.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        this.a.getSettings().setJavaScriptEnabled(true);
        this.a.getSettings().setUseWideViewPort(true);
        this.a.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        this.a.getSettings().setCacheMode(0);
        this.a.getSettings().setBlockNetworkImage(true);
        this.a.getSettings().setSupportZoom(true);
        this.a.getSettings().setBuiltInZoomControls(true);
        this.a.getSettings().setLightTouchEnabled(true);
        this.a.setHorizontalScrollBarEnabled(false);
        this.a.setVerticalScrollBarEnabled(false);
        this.a.setDownloadListener(new C(this));
        this.a.setWebChromeClient(new D(this));
        this.a.setWebViewClient(new E(this));
        frameLayout.addView(this.a);
        this.d = new TextView(this);
        this.d.setLayoutParams(new FrameLayout.LayoutParams(-1, -2));
        this.d.setPadding(G.a(this, 6.0f), G.a(this, 6.0f), G.a(this, 6.0f), G.a(this, 6.0f));
        this.d.setBackgroundColor(Color.parseColor("#66000000"));
        this.d.setTextColor(-1);
        this.d.setTextSize(16.0f);
        frameLayout.addView(this.d);
        setContentView(frameLayout);
        this.a.loadData("<h3>Loading...</h3>", "text/html", "UTF-8");
        this.a.loadUrl(this.b);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(WA wa, String str) {
        if (str == null) {
            wa.d.setText("");
            wa.d.setVisibility(8);
        } else {
            wa.d.setText(str);
            wa.d.setVisibility(0);
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        if (this.c || this.a == null || !this.a.canGoBack()) {
            super.onBackPressed();
        } else {
            this.a.goBack();
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        a();
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        a();
    }
}
