package com.feiwothree.coverscreen;

import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* renamed from: com.feiwothree.coverscreen.b, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class C0011b extends TimerTask {
    private /* synthetic */ AdComponent a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public C0011b(AdComponent adComponent) {
        this.a = adComponent;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public final void run() {
        this.a.b();
    }
}
