package com.feiwothree.coverscreen;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import com.feiwothree.coverscreen.a.C0001a;
import com.feiwothree.coverscreen.a.C0002b;
import com.feiwothree.coverscreen.a.C0009i;
import com.feiwothree.coverscreen.a.I;
import com.feiwothree.coverscreen.a.J;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public abstract class AdComponent {
    public static final int FAIL_IN_PREPARATION = 3;
    public static final int FAIL_NOT_INITIALIZE = 1;
    public static final int FAIL_NO_AD = 2;
    public static final int FAIL_SHOW_AD = 5;
    public static final int FAIL_START_ACTIVITY = 4;
    public static final int SUCCESS = 0;
    static boolean a = false;
    private String c;
    private Context d;
    private TimerTask g;
    private Handler i;
    boolean b = false;
    private boolean e = false;
    private int f = 10;
    private Timer h = new Timer();

    /* JADX INFO: Access modifiers changed from: protected */
    public AdComponent(Context context, String str) {
        this.i = null;
        this.d = context;
        this.c = str;
        a = false;
        I.b(context, "DP_FEIWO", "appkey", str);
        I.a(context, "DP_FEIWO", "showatscreenonuser", true);
        try {
            this.i = new Handler();
        } catch (Exception e) {
            Log.w("LOG", "AdComponent handler null ");
        }
        try {
            com.feiwothree.coverscreen.a.C.a();
        } catch (Exception e2) {
            Log.w("LOG", "AdComponent QueueImageLoader init null ");
        }
        try {
            C0009i.c(context);
        } catch (Exception e3) {
            Log.w("LOG", "AdComponent DownloadManager init exception ");
        }
        if (!C0009i.a(context)) {
            Log.w("LOG", "NO NETWORK ");
        } else if (C0009i.a(this.d)) {
            if (!this.e) {
                Context context2 = this.d;
                a(true);
            }
            new C0000a(this).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(AdComponent adComponent) {
        JSONObject a2 = C0001a.a(adComponent.d, adComponent.c, "1.9");
        com.feiwothree.coverscreen.a.u uVar = new com.feiwothree.coverscreen.a.u();
        uVar.a(adComponent.d, C0002b.c(), adComponent.c, a2.toString());
        uVar.a(new C0012c(adComponent));
        com.feiwothree.coverscreen.a.s.a().a(uVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void b(AdComponent adComponent) {
        String a2 = I.a(adComponent.d, "DP_FEIWO", "packnames", (String) null);
        if (a2 != null) {
            String[] split = a2.split(",");
            JSONArray jSONArray = new JSONArray();
            for (String str : split) {
                if (!J.a(str)) {
                    JSONObject jSONObject = new JSONObject();
                    try {
                        jSONObject.put("packageName", str);
                    } catch (JSONException e) {
                    }
                    jSONArray.put(jSONObject);
                }
            }
            if (jSONArray.length() != 0) {
                JSONObject a3 = C0001a.a(adComponent.d, "1.9", jSONArray);
                com.feiwothree.coverscreen.a.u uVar = new com.feiwothree.coverscreen.a.u();
                uVar.a(adComponent.d, C0002b.d(), adComponent.c, a3.toString());
                uVar.a(new C0013d(adComponent));
                com.feiwothree.coverscreen.a.s.a().a(uVar);
            }
        }
    }

    public static boolean isShowAtScreenOn() {
        return a;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a() {
        this.e = true;
        if (this.g != null) {
            this.g.cancel();
            this.g = null;
            this.h.cancel();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); i++) {
            String optString = jSONArray.optJSONObject(i).optString("image");
            if (!J.a(optString)) {
                this.i.postDelayed(new RunnableC0014e(this, optString), 10L);
            }
            String optString2 = jSONArray.optJSONObject(i).optString("icon");
            if (!J.a(optString2)) {
                this.i.postDelayed(new f(this, optString2), 10L);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(boolean z) {
        if (z) {
            this.f = 10;
        } else {
            this.f--;
        }
        if (this.f >= 0 && !this.e) {
            if (z) {
                if (this.g != null) {
                    this.g.cancel();
                    Context context = this.d;
                }
                b();
                return;
            }
            if (this.g != null) {
                Context context2 = this.d;
                return;
            }
            this.g = new C0011b(this);
            this.h.schedule(this.g, 360000L);
            Context context3 = this.d;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final boolean a(List list, int i) {
        try {
            Intent intent = new Intent(this.d, (Class<?>) SA.class);
            intent.addFlags(335544320);
            intent.putExtra("ads", (ArrayList) list);
            intent.putExtra("index", i);
            if (this.i != null) {
                this.i.post(new g(this, intent));
            } else {
                this.d.startActivity(intent);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public abstract void b();

    /* JADX INFO: Access modifiers changed from: protected */
    public void c() {
        this.b = false;
        this.g = null;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final String d() {
        return this.c;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final Context e() {
        return this.d;
    }
}
