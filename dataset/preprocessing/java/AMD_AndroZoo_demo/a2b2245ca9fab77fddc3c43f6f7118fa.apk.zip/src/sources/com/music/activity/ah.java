package com.music.activity;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class ah implements Runnable {
    final /* synthetic */ ShowOneBanddangListActivity a;

    public ah(ShowOneBanddangListActivity showOneBanddangListActivity) {
        this.a = showOneBanddangListActivity;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.a.c();
    }
}
