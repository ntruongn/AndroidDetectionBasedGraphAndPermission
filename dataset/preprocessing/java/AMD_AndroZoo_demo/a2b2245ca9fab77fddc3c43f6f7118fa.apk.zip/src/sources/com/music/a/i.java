package com.music.a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.music.activity.MusicSearchActivity;
import com.music.activity.R;
import com.music.domain.MusicNetWorkInfo;
import com.music.domain.ObjectInfo;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class i extends BaseAdapter {
    private Context a;
    private MusicNetWorkInfo b;

    public i(Context context, String str, String str2) {
        this.a = context;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (MusicSearchActivity.e == null || MusicSearchActivity.e.size() <= 0) {
            return 0;
        }
        return MusicSearchActivity.e.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        j jVar;
        if (view == null) {
            view = LayoutInflater.from(this.a).inflate(R.layout.music_item, (ViewGroup) null);
            jVar = new j();
            jVar.b = (TextView) view.findViewById(R.id.music_name);
            jVar.a = (TextView) view.findViewById(R.id.music_singer);
            jVar.c = (TextView) view.findViewById(R.id.music_time);
            jVar.e = (ProgressBar) view.findViewById(R.id.download_progress);
            jVar.d = (ImageView) view.findViewById(R.id.music_pic);
            jVar.c.setVisibility(8);
            jVar.e.setVisibility(8);
            view.setTag(jVar);
        } else {
            jVar = (j) view.getTag();
        }
        if (MusicSearchActivity.e == null || i >= MusicSearchActivity.e.size()) {
            return view;
        }
        Object obj = MusicSearchActivity.e.get(i);
        if (MusicSearchActivity.d != 0) {
            if (obj == null || !(obj instanceof MusicNetWorkInfo)) {
                return view;
            }
            this.b = new MusicNetWorkInfo();
            this.b = (MusicNetWorkInfo) obj;
            this.b.musicName = MusicSearchActivity.b;
            this.b.musicSinger = MusicSearchActivity.c;
            jVar.b.setText(MusicSearchActivity.b);
            jVar.a.setText(MusicSearchActivity.c);
            return view;
        }
        if (obj == null || !(obj instanceof ObjectInfo)) {
            return view;
        }
        ObjectInfo objectInfo = (ObjectInfo) obj;
        if (objectInfo.name == null) {
            return null;
        }
        String[] split = objectInfo.name.replace("$$", ",").replace("$$$$", ",").split(",");
        String str = "";
        String str2 = "";
        if (split == null) {
            return view;
        }
        if (split.length > 1) {
            str = split[0];
            str2 = split[1];
        } else if (split.length == 1) {
            str = split[0];
            str2 = "未知";
        }
        jVar.b.setText(str);
        jVar.a.setText(str2);
        return view;
    }
}
