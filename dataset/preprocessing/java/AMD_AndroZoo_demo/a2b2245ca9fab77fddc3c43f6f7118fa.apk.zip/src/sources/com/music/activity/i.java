package com.music.activity;

import android.content.DialogInterface;
import android.widget.TextView;
import com.music.domain.MusicNetWorkInfo;
import java.io.File;
import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class i implements DialogInterface.OnClickListener {
    final /* synthetic */ g a;
    private final /* synthetic */ boolean b;
    private final /* synthetic */ MusicNetWorkInfo c;
    private final /* synthetic */ TextView d;
    private final /* synthetic */ ArrayList e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public i(g gVar, boolean z, MusicNetWorkInfo musicNetWorkInfo, TextView textView, ArrayList arrayList) {
        this.a = gVar;
        this.b = z;
        this.c = musicNetWorkInfo;
        this.d = textView;
        this.e = arrayList;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        DownloadListActivity downloadListActivity;
        String str;
        g gVar;
        g gVar2;
        TextView textView;
        TextView textView2;
        DownloadListActivity downloadListActivity2;
        String str2;
        DownloadListActivity downloadListActivity3;
        DownloadListActivity downloadListActivity4;
        com.a.a.a aVar;
        DownloadListActivity downloadListActivity5;
        com.a.a.a aVar2;
        DownloadListActivity downloadListActivity6;
        String str3;
        DownloadListActivity downloadListActivity7;
        dialogInterface.dismiss();
        if (i == 0) {
            if (!this.b) {
                TextView textView3 = this.d;
                downloadListActivity2 = this.a.a;
                str2 = downloadListActivity2.m;
                textView3.setTag(str2);
                new Thread(new k(this.a, this.c, this.e)).start();
                return;
            }
            downloadListActivity3 = this.a.a;
            downloadListActivity3.o = (com.a.a.a) com.music.c.m.b.get(this.c.musicUrl);
            downloadListActivity4 = this.a.a;
            aVar = downloadListActivity4.o;
            if (aVar == null) {
                downloadListActivity7 = this.a.a;
                downloadListActivity7.o = new com.a.a.a();
            }
            downloadListActivity5 = this.a.a;
            aVar2 = downloadListActivity5.o;
            aVar2.c();
            this.d.setText("暂停");
            TextView textView4 = this.d;
            downloadListActivity6 = this.a.a;
            str3 = downloadListActivity6.n;
            textView4.setTag(str3);
            return;
        }
        if (i == 1) {
            dialogInterface.dismiss();
            downloadListActivity = this.a.a;
            str = downloadListActivity.l;
            File file = new File(str, String.valueOf(this.c.musicName) + "-" + this.c.musicSinger);
            if (file.exists()) {
                file.delete();
            }
            if (DownloadListActivity.b != null) {
                DownloadListActivity.b.d(this.c.musicUrl);
                DownloadListActivity.b.c(this.c.musicUrl);
            }
            com.music.c.m.a.remove(this.c);
            if (com.music.c.m.a.size() == 0) {
                textView = DownloadListActivity.h;
                textView.setVisibility(0);
                textView2 = DownloadListActivity.h;
                textView2.setText("下载列表中无音乐");
            }
            gVar = DownloadListActivity.f;
            if (gVar != null) {
                gVar2 = DownloadListActivity.f;
                gVar2.notifyDataSetChanged();
            }
        }
    }
}
