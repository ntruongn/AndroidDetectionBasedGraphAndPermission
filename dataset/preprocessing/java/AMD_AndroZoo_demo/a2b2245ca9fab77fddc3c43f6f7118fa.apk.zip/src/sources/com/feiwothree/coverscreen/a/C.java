package com.feiwothree.coverscreen.a;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class C {
    private static C a = null;
    private Handler b = new D(this);
    private ConcurrentHashMap c = new ConcurrentHashMap();
    private ExecutorService d = Executors.newSingleThreadExecutor();
    private ConcurrentHashMap e = new ConcurrentHashMap();

    public static Bitmap a(Context context, String str) {
        Bitmap bitmap;
        if (!new File(str).exists()) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        int i = options.outWidth;
        int i2 = options.outHeight;
        H d = B.d(context);
        int i3 = 1;
        while (i / 2 > d.a && i2 / 2 > d.b) {
            i /= 2;
            i2 /= 2;
            i3 <<= 1;
        }
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inSampleSize = i3;
        options.inJustDecodeBounds = false;
        File file = new File(str);
        if (file.exists()) {
            bitmap = BitmapFactory.decodeFile(str, options);
            if (bitmap == null) {
                file.delete();
            }
        } else {
            bitmap = null;
        }
        return bitmap;
    }

    public static C a() {
        if (a == null) {
            a = new C();
        }
        return a;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(C c, Context context, String str) {
        HttpURLConnection httpURLConnection;
        FileOutputStream fileOutputStream;
        HttpURLConnection httpURLConnection2;
        InputStream inputStream;
        FileOutputStream fileOutputStream2;
        FileOutputStream fileOutputStream3 = null;
        fileOutputStream3 = null;
        HttpURLConnection httpURLConnection3 = null;
        r.a();
        String a2 = r.a(context, l.a, str);
        File file = new File(String.valueOf(a2) + "." + System.currentTimeMillis() + ".temp");
        File file2 = new File(a2);
        if (file2.exists()) {
            return;
        }
        try {
            httpURLConnection2 = (HttpURLConnection) new URL(str).openConnection();
            try {
                httpURLConnection2.setConnectTimeout(5000);
                httpURLConnection2.setReadTimeout(5000);
                httpURLConnection2.setRequestMethod("GET");
                httpURLConnection2.connect();
                inputStream = httpURLConnection2.getInputStream();
                fileOutputStream2 = new FileOutputStream(file);
            } catch (Exception e) {
                httpURLConnection3 = httpURLConnection2;
                fileOutputStream = null;
            } catch (Throwable th) {
                httpURLConnection = httpURLConnection2;
                th = th;
            }
        } catch (Exception e2) {
            fileOutputStream = null;
        } catch (Throwable th2) {
            th = th2;
            httpURLConnection = null;
        }
        try {
            byte[] bArr = new byte[1024];
            while (true) {
                int read = inputStream.read(bArr);
                if (read == -1) {
                    break;
                } else {
                    fileOutputStream2.write(bArr, 0, read);
                }
            }
            fileOutputStream2.flush();
            fileOutputStream2.close();
            file.renameTo(file2);
            try {
                fileOutputStream2.close();
                if (httpURLConnection2 != null) {
                    httpURLConnection2.disconnect();
                }
            } catch (IOException e3) {
            }
        } catch (Exception e4) {
            httpURLConnection3 = httpURLConnection2;
            fileOutputStream = fileOutputStream2;
            if (fileOutputStream != null) {
                try {
                    fileOutputStream.close();
                } catch (IOException e5) {
                    return;
                }
            }
            if (httpURLConnection3 != null) {
                httpURLConnection3.disconnect();
            }
        } catch (Throwable th3) {
            fileOutputStream3 = fileOutputStream2;
            httpURLConnection = httpURLConnection2;
            th = th3;
            if (fileOutputStream3 != null) {
                try {
                    fileOutputStream3.close();
                } catch (IOException e6) {
                    throw th;
                }
            }
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }
            throw th;
        }
    }

    public final Drawable a(Context context, String str, F f) {
        boolean z;
        if (this.c.containsKey(str)) {
            Queue queue = (Queue) this.c.get(str);
            if (f != null) {
                queue.add(f);
            }
            z = true;
        } else {
            ConcurrentLinkedQueue concurrentLinkedQueue = new ConcurrentLinkedQueue();
            this.c.put(str, concurrentLinkedQueue);
            if (f != null) {
                concurrentLinkedQueue.add(f);
            }
            z = false;
        }
        if (!z) {
            this.d.submit(new E(this, context, str));
        }
        return null;
    }
}
