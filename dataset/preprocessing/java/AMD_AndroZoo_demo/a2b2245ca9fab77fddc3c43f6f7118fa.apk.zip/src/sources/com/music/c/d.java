package com.music.c;

import android.text.TextUtils;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class d {
    public static String a(File file) {
        if (file != null) {
            String name = file.getName();
            if (!TextUtils.isEmpty(name)) {
                String lowerCase = name.toLowerCase();
                if (lowerCase.endsWith(".mp3")) {
                    return "audio/mpeg";
                }
                if (lowerCase.endsWith(".m4a")) {
                    return "audio/mp4";
                }
                if (lowerCase.endsWith(".wav")) {
                    return "audio/x-wav";
                }
                if (lowerCase.endsWith(".amr") || lowerCase.endsWith(".rm")) {
                    return "audio/amr";
                }
                if (lowerCase.endsWith(".awb")) {
                    return "audio/amr-wb";
                }
                if (lowerCase.endsWith(".wma")) {
                    return "audio/x-ms-wma";
                }
                if (lowerCase.endsWith(".ogg")) {
                    return "application/ogg";
                }
                if (lowerCase.endsWith(".imy")) {
                    return "audio/imelody";
                }
                if (lowerCase.endsWith(".smf")) {
                    return "audio/sp-midi";
                }
                if (lowerCase.endsWith(".rttl") || lowerCase.endsWith(".xmf") || lowerCase.endsWith(".mid")) {
                    return "audio/midi";
                }
            }
        }
        return null;
    }
}
