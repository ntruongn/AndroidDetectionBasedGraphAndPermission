package com.feiwo.banner;

import android.content.Intent;
import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class h implements View.OnClickListener {
    private /* synthetic */ f a;
    private final /* synthetic */ Intent b;
    private final /* synthetic */ com.feiwo.banner.c.a c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h(f fVar, Intent intent, com.feiwo.banner.c.a aVar) {
        this.a = fVar;
        this.b = intent;
        this.c = aVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        d.a(this.a.a, this.b, this.c);
    }
}
