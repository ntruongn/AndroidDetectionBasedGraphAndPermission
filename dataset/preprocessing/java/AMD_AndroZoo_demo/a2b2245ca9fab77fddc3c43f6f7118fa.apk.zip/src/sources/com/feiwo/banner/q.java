package com.feiwo.banner;

import android.content.Context;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class q implements Runnable {
    private /* synthetic */ m a;
    private final /* synthetic */ com.feiwo.banner.c.a b;
    private final /* synthetic */ AdBanner c;
    private final /* synthetic */ int d;
    private final /* synthetic */ String e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public q(m mVar, com.feiwo.banner.c.a aVar, AdBanner adBanner, int i, String str) {
        this.a = mVar;
        this.b = aVar;
        this.c = adBanner;
        this.d = i;
        this.e = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        m mVar;
        Context context;
        Context context2;
        mVar = m.a;
        synchronized (mVar) {
            context = this.a.b;
            int a = com.feiwo.banner.f.e.a(context, "ADFEIWO", "list_click", new StringBuilder(String.valueOf(this.b.i())).toString(), 0);
            context2 = this.a.b;
            String sb = new StringBuilder().append(this.b.i()).toString();
            String sb2 = new StringBuilder(String.valueOf(a + 1)).toString();
            JSONObject b = com.feiwo.banner.f.e.b(context2, "ADFEIWO", "list_click");
            try {
                b.put(sb, sb2);
            } catch (JSONException e) {
                System.out.println(">> error " + e.getMessage());
            }
            com.feiwo.banner.f.e.b(context2, "ADFEIWO", "list_click", b.toString(), "12345678");
            m.a(this.a, this.c, this.d, this.b, this.e);
        }
    }
}
