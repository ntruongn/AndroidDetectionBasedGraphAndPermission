package com.umeng.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class j {
    /* JADX WARN: Code restructure failed: missing block: B:24:0x005e, code lost:
    
        if (r0.equals("uniwap") != false) goto L21;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String a(android.content.Context r5) {
        /*
            r1 = 0
            android.content.pm.PackageManager r0 = r5.getPackageManager()
            java.lang.String r2 = "android.permission.ACCESS_NETWORK_STATE"
            java.lang.String r3 = r5.getPackageName()
            int r0 = r0.checkPermission(r2, r3)
            if (r0 == 0) goto L13
            r0 = r1
        L12:
            return r0
        L13:
            java.lang.String r0 = "connectivity"
            java.lang.Object r0 = r5.getSystemService(r0)     // Catch: java.lang.Exception -> L63
            android.net.ConnectivityManager r0 = (android.net.ConnectivityManager) r0     // Catch: java.lang.Exception -> L63
            android.net.NetworkInfo r0 = r0.getActiveNetworkInfo()     // Catch: java.lang.Exception -> L63
            if (r0 != 0) goto L23
            r0 = r1
            goto L12
        L23:
            int r2 = r0.getType()     // Catch: java.lang.Exception -> L63
            r3 = 1
            if (r2 != r3) goto L2c
            r0 = r1
            goto L12
        L2c:
            java.lang.String r0 = r0.getExtraInfo()     // Catch: java.lang.Exception -> L63
            java.lang.String r2 = "TAG"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L63
            java.lang.String r4 = "net type:"
            r3.<init>(r4)     // Catch: java.lang.Exception -> L63
            java.lang.StringBuilder r3 = r3.append(r0)     // Catch: java.lang.Exception -> L63
            java.lang.String r3 = r3.toString()     // Catch: java.lang.Exception -> L63
            com.umeng.common.a.a(r2, r3)     // Catch: java.lang.Exception -> L63
            if (r0 != 0) goto L48
            r0 = r1
            goto L12
        L48:
            java.lang.String r2 = "cmwap"
            boolean r2 = r0.equals(r2)     // Catch: java.lang.Exception -> L63
            if (r2 != 0) goto L60
            java.lang.String r2 = "3gwap"
            boolean r2 = r0.equals(r2)     // Catch: java.lang.Exception -> L63
            if (r2 != 0) goto L60
            java.lang.String r2 = "uniwap"
            boolean r0 = r0.equals(r2)     // Catch: java.lang.Exception -> L63
            if (r0 == 0) goto L67
        L60:
            java.lang.String r0 = "10.0.0.172"
            goto L12
        L63:
            r0 = move-exception
            r0.printStackTrace()
        L67:
            r0 = r1
            goto L12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.umeng.a.j.a(android.content.Context):java.lang.String");
    }
}
