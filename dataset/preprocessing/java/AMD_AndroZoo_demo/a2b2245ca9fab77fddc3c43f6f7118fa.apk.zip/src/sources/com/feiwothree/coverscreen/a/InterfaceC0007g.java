package com.feiwothree.coverscreen.a;

/* renamed from: com.feiwothree.coverscreen.a.g, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public interface InterfaceC0007g {
}
