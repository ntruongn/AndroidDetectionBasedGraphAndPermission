package com.music.service;

import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class d {
    public static Uri a = Uri.parse("content://telephony/carriers/preferapn");

    public static e a(Context context) {
        try {
            NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
            if (activeNetworkInfo == null || !activeNetworkInfo.isAvailable()) {
                Log.i("", "=====================>无网络");
                return e.TYPE_OTHER_NET;
            }
            int type = activeNetworkInfo.getType();
            if (type == 1) {
                Log.i("", "=====================>wifi网络");
                return e.TYPE_OTHER_NET;
            }
            if (type == 0) {
                Cursor query = context.getContentResolver().query(a, null, null, null, null);
                if (query != null) {
                    query.moveToFirst();
                    String string = query.getString(query.getColumnIndex("user"));
                    if (!TextUtils.isEmpty(string)) {
                        Log.i("", "=====================>代理：" + query.getString(query.getColumnIndex("proxy")));
                        if (string.startsWith("ctwap")) {
                            Log.i("", "=====================>电信wap网络");
                            return e.TYPE_CT_WAP;
                        }
                    }
                }
                query.close();
                String extraInfo = activeNetworkInfo.getExtraInfo();
                Log.i("", "netMode ================== " + extraInfo);
                if (extraInfo != null) {
                    String lowerCase = extraInfo.toLowerCase();
                    if (lowerCase.equals("cmwap") || lowerCase.equals("3gwap") || lowerCase.equals("uniwap")) {
                        Log.i("", "=====================>移动联通wap网络");
                        return e.TYPE_CM_CU_WAP;
                    }
                }
            }
            return e.TYPE_OTHER_NET;
        } catch (Exception e) {
            e.printStackTrace();
            return e.TYPE_OTHER_NET;
        }
    }
}
