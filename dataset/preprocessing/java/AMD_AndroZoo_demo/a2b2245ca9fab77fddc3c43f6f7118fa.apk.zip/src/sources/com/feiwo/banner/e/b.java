package com.feiwo.banner.e;

import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class b extends Handler {
    private final /* synthetic */ d a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(a aVar, d dVar, String str) {
        this.a = dVar;
        this.b = str;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        if (message.obj != null) {
            d dVar = this.a;
            Drawable drawable = (Drawable) message.obj;
            String str = this.b;
            dVar.a(drawable);
        }
    }
}
