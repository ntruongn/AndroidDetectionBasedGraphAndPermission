package com.music.c;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.os.Process;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import java.text.SimpleDateFormat;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class b implements Thread.UncaughtExceptionHandler {
    private static b b = new b();
    private Thread.UncaughtExceptionHandler a;
    private Context c;
    private StringBuffer d = new StringBuffer();
    private SimpleDateFormat e = new SimpleDateFormat("yyyyMMdd_HH-mm-ss");

    private b() {
    }

    public static b a() {
        return b;
    }

    private String b(Throwable th) {
        String format = this.e.format(new Date());
        this.d.append("Time = ").append(format).append("\r\n");
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        th.printStackTrace(printWriter);
        for (Throwable cause = th.getCause(); cause != null; cause = cause.getCause()) {
            cause.printStackTrace(printWriter);
            printWriter.append("\r\n");
        }
        printWriter.close();
        this.d.append(stringWriter.toString());
        String str = "CrashLog-" + format + ".log";
        if (Environment.getExternalStorageState().equals("mounted")) {
            try {
                File file = new File(Environment.getExternalStorageDirectory() + "/" + a.a + "/errors");
                if (!file.exists()) {
                    file.mkdirs();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(file + "/" + str);
                fileOutputStream.write(this.d.toString().getBytes());
                fileOutputStream.close();
                return str;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        }
        return null;
    }

    public void a(Context context) {
        this.c = context;
        this.a = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    public boolean a(Throwable th) {
        if (th == null) {
            return false;
        }
        new c(this).start();
        b(this.c);
        b(th);
        return true;
    }

    public void b(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 1);
            if (packageInfo != null) {
                String str = packageInfo.versionName == null ? "null" : packageInfo.versionName;
                this.d.append("versionCode = " + new StringBuilder(String.valueOf(packageInfo.versionCode)).toString()).append("\r\n");
                this.d.append("versionName = " + str).append("\r\n");
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        this.d.append("DEVICE = " + Build.DEVICE).append("\r\n");
        this.d.append("MODEL = " + Build.MODEL).append("\r\n");
        this.d.append("FINGERPRINT = " + Build.FINGERPRINT).append("\r\n");
    }

    @Override // java.lang.Thread.UncaughtExceptionHandler
    public void uncaughtException(Thread thread, Throwable th) {
        if (!a(th) && this.a != null) {
            this.a.uncaughtException(thread, th);
            return;
        }
        try {
            Thread.sleep(1000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Process.killProcess(Process.myPid());
        System.exit(1);
    }
}
