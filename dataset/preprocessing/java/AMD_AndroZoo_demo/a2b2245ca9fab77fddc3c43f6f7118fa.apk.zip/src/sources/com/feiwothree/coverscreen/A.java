package com.feiwothree.coverscreen;

import android.view.animation.Animation;
import android.widget.LinearLayout;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class A implements Animation.AnimationListener {
    private /* synthetic */ z a;
    private final /* synthetic */ LinearLayout b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public A(z zVar, LinearLayout linearLayout) {
        this.a = zVar;
        this.b = linearLayout;
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationEnd(Animation animation) {
        this.b.setOnTouchListener(new B(this));
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationRepeat(Animation animation) {
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationStart(Animation animation) {
    }
}
