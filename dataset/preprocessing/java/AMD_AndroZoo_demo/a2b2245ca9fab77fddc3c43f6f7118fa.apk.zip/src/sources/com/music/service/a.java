package com.music.service;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class a {
    private static HttpRequestRetryHandler a = new b();

    public static String a(Context context, String str, String str2) {
        BufferedReader bufferedReader;
        DefaultHttpClient defaultHttpClient = null;
        BufferedReader bufferedReader2 = null;
        BufferedReader bufferedReader3 = null;
        BufferedReader bufferedReader4 = null;
        BufferedReader bufferedReader5 = null;
        BufferedReader bufferedReader6 = null;
        StringBuffer stringBuffer = new StringBuffer();
        System.out.println("当前网络连接的类型为：" + d.a(context));
        if (!a(context)) {
            stringBuffer.append("error：您的网络不是很好，请检查网络后稍后重试。 ");
        } else {
            if (str == null) {
                return "error：网址参数为空。";
            }
            String replace = str.replace(" ", "%20");
            try {
                try {
                    try {
                        BasicHttpParams basicHttpParams = new BasicHttpParams();
                        HttpConnectionParams.setConnectionTimeout(basicHttpParams, 3000);
                        HttpConnectionParams.setSoTimeout(basicHttpParams, 5000);
                        DefaultHttpClient defaultHttpClient2 = new DefaultHttpClient(basicHttpParams);
                        defaultHttpClient2.setHttpRequestRetryHandler(a);
                        HttpGet httpGet = new HttpGet(replace);
                        defaultHttpClient2.getParams().setParameter("http.route.default-proxy", null);
                        defaultHttpClient2.execute(httpGet);
                        HttpResponse execute = defaultHttpClient2.execute(httpGet);
                        if (execute.getStatusLine().getStatusCode() == 200) {
                            bufferedReader = new BufferedReader(new InputStreamReader(execute.getEntity().getContent(), str2));
                            while (true) {
                                try {
                                    String readLine = bufferedReader.readLine();
                                    if (readLine == null) {
                                        break;
                                    }
                                    stringBuffer.append(String.valueOf(readLine) + "\n");
                                } catch (UnsupportedEncodingException e) {
                                    e = e;
                                    bufferedReader3 = bufferedReader;
                                    System.out.println("UnsupportedEncodingException:" + e.getMessage());
                                    String str3 = "error：UnsupportedEncodingException " + e.toString();
                                    if (bufferedReader3 == null) {
                                        return str3;
                                    }
                                    try {
                                        bufferedReader3.close();
                                        return str3;
                                    } catch (IOException e2) {
                                        System.out.println("关闭连接时出现IOException:" + e2.toString());
                                        return str3;
                                    }
                                } catch (IOException e3) {
                                    e = e3;
                                    bufferedReader4 = bufferedReader;
                                    System.out.println("IOException:" + e.getMessage());
                                    String str4 = "error：IOExceptionIOException " + e.toString();
                                    if (bufferedReader4 == null) {
                                        return str4;
                                    }
                                    try {
                                        bufferedReader4.close();
                                        return str4;
                                    } catch (IOException e4) {
                                        System.out.println("关闭连接时出现IOException:" + e4.toString());
                                        return str4;
                                    }
                                } catch (IllegalArgumentException e5) {
                                    bufferedReader5 = bufferedReader;
                                    if (bufferedReader5 != null) {
                                        try {
                                            bufferedReader5.close();
                                        } catch (IOException e6) {
                                            System.out.println("关闭连接时出现IOException:" + e6.toString());
                                        }
                                    }
                                    return "error：输入的查询信息不正确";
                                } catch (IllegalStateException e7) {
                                    e = e7;
                                    bufferedReader6 = bufferedReader;
                                    System.out.println("IllegalStateException:" + e.getMessage());
                                    String str5 = "error：IllegalStateException " + e.toString();
                                    if (bufferedReader6 == null) {
                                        return str5;
                                    }
                                    try {
                                        bufferedReader6.close();
                                        return str5;
                                    } catch (IOException e8) {
                                        System.out.println("关闭连接时出现IOException:" + e8.toString());
                                        return str5;
                                    }
                                } catch (ClientProtocolException e9) {
                                    e = e9;
                                    System.out.println("ClientProtocolException:" + e.getMessage());
                                    String str6 = "error：ClientProtocolException " + e.toString();
                                    if (bufferedReader == null) {
                                        return str6;
                                    }
                                    try {
                                        bufferedReader.close();
                                        return str6;
                                    } catch (IOException e10) {
                                        System.out.println("关闭连接时出现IOException:" + e10.toString());
                                        return str6;
                                    }
                                }
                            }
                        } else {
                            bufferedReader = null;
                        }
                        if (bufferedReader != null) {
                            try {
                                bufferedReader.close();
                                defaultHttpClient = defaultHttpClient2;
                            } catch (IOException e11) {
                                System.out.println("关闭连接时出现IOException:" + e11.toString());
                                defaultHttpClient = defaultHttpClient2;
                            }
                        } else {
                            defaultHttpClient = defaultHttpClient2;
                        }
                    } catch (Throwable th) {
                        th = th;
                        if (bufferedReader2 != null) {
                            try {
                                bufferedReader2.close();
                            } catch (IOException e12) {
                                System.out.println("关闭连接时出现IOException:" + e12.toString());
                            }
                        }
                        throw th;
                    }
                } catch (UnsupportedEncodingException e13) {
                    e = e13;
                } catch (ClientProtocolException e14) {
                    e = e14;
                    bufferedReader = null;
                } catch (IOException e15) {
                    e = e15;
                } catch (IllegalArgumentException e16) {
                } catch (IllegalStateException e17) {
                    e = e17;
                }
            } catch (Throwable th2) {
                th = th2;
                bufferedReader2 = null;
            }
        }
        if (defaultHttpClient != null) {
            defaultHttpClient.getConnectionManager().shutdown();
        }
        return stringBuffer.toString().trim();
    }

    public static String a(Context context, String str, HashMap hashMap, String str2) {
        System.out.print("url=" + str + "?");
        StringBuffer stringBuffer = new StringBuffer();
        if (!a(context)) {
            return "error：无可用网络，请检查网络正常后重试。";
        }
        BasicHttpParams basicHttpParams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(basicHttpParams, com.music.c.a.l);
        HttpConnectionParams.setSoTimeout(basicHttpParams, com.music.c.a.m);
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient(basicHttpParams);
        defaultHttpClient.setHttpRequestRetryHandler(a);
        try {
            if (str == null) {
                if (defaultHttpClient != null) {
                    defaultHttpClient.getConnectionManager().shutdown();
                }
                return "error：url 为空";
            }
            try {
                try {
                    try {
                        try {
                            String replace = str.replace(" ", "%20");
                            System.out.println("ConnectionToService " + replace);
                            HttpPost httpPost = new HttpPost(replace);
                            ArrayList arrayList = new ArrayList();
                            if (hashMap != null) {
                                for (String str3 : hashMap.keySet()) {
                                    String str4 = (String) hashMap.get(str3);
                                    arrayList.add(new BasicNameValuePair(str3, str4));
                                    System.out.print(String.valueOf(str3) + "=" + str4 + "&");
                                }
                            }
                            httpPost.setEntity(new UrlEncodedFormEntity(arrayList, str2));
                            HttpResponse execute = defaultHttpClient.execute(httpPost);
                            if (execute.getStatusLine().getStatusCode() != 200) {
                                if (defaultHttpClient != null) {
                                    defaultHttpClient.getConnectionManager().shutdown();
                                }
                                return "error：服务器响应状态出错啦。";
                            }
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(execute.getEntity().getContent(), str2));
                            while (true) {
                                String readLine = bufferedReader.readLine();
                                if (readLine == null) {
                                    break;
                                }
                                stringBuffer.append(String.valueOf(readLine) + "\n");
                            }
                            String stringBuffer2 = stringBuffer.toString();
                            if (defaultHttpClient == null) {
                                return stringBuffer2;
                            }
                            defaultHttpClient.getConnectionManager().shutdown();
                            return stringBuffer2;
                        } catch (IOException e) {
                            System.out.println("IOException:" + e.toString());
                            String str5 = "error：IOException " + e.toString();
                            if (defaultHttpClient == null) {
                                return str5;
                            }
                            defaultHttpClient.getConnectionManager().shutdown();
                            return str5;
                        }
                    } catch (UnsupportedEncodingException e2) {
                        System.out.println("UnsupportedEncodingException:" + e2.getMessage());
                        String str6 = "error：UnsupportedEncodingException " + e2.toString();
                        if (defaultHttpClient == null) {
                            return str6;
                        }
                        defaultHttpClient.getConnectionManager().shutdown();
                        return str6;
                    }
                } catch (ClientProtocolException e3) {
                    System.out.println("ClientProtocolException:" + e3.toString());
                    String str7 = "error：ClientProtocolException " + e3.toString();
                    if (defaultHttpClient == null) {
                        return str7;
                    }
                    defaultHttpClient.getConnectionManager().shutdown();
                    return str7;
                }
            } catch (IllegalStateException e4) {
                System.out.println("IllegalStateException:" + e4.toString());
                String str8 = "error：IllegalStateException " + e4.toString();
                if (defaultHttpClient == null) {
                    return str8;
                }
                defaultHttpClient.getConnectionManager().shutdown();
                return str8;
            }
        } catch (Throwable th) {
            if (defaultHttpClient != null) {
                defaultHttpClient.getConnectionManager().shutdown();
            }
            throw th;
        }
    }

    public static boolean a(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null ? activeNetworkInfo.isAvailable() : false;
    }
}
