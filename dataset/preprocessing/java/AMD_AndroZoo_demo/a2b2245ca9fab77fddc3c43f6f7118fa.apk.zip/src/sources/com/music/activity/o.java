package com.music.activity;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class o implements Runnable {
    final /* synthetic */ ListMusicsActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(ListMusicsActivity listMusicsActivity) {
        this.a = listMusicsActivity;
    }

    @Override // java.lang.Runnable
    public void run() {
        boolean z;
        while (!Thread.interrupted()) {
            z = this.a.j;
            if (z) {
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (this.a.h != null) {
                    this.a.h.cancel();
                    return;
                }
                return;
            }
            try {
                Thread.sleep(100L);
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
        }
    }
}
