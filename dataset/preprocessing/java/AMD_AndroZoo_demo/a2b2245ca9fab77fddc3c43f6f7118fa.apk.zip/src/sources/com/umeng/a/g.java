package com.umeng.a;

import android.content.Context;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class g implements Runnable {
    final /* synthetic */ e a;
    private final Object b = new Object();
    private Context c;
    private JSONObject d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(e eVar, e eVar2, Context context, JSONObject jSONObject) {
        this.a = eVar;
        this.c = context.getApplicationContext();
        this.d = jSONObject;
    }

    @Override // java.lang.Runnable
    public void run() {
        h hVar;
        h hVar2;
        h hVar3;
        try {
        } catch (Exception e) {
            com.umeng.common.a.b("MobclickAgent", "Exception occurred in ReportMessageHandler");
            e.printStackTrace();
        }
        if (this.d.getString("type").equals("online_config")) {
            this.a.b(this.c, this.d);
            return;
        }
        if (this.d.getString("type").equals("cmd_cache_buffer")) {
            synchronized (this.b) {
                hVar3 = this.a.g;
                hVar3.a(this.c);
            }
            return;
        }
        if (this.d.getString("type").equals("flush")) {
            synchronized (this.b) {
                hVar2 = this.a.g;
                hVar2.a(this.c);
                this.a.a(this.c, this.d);
            }
            return;
        }
        synchronized (this.b) {
            hVar = this.a.g;
            hVar.a(this.c);
            this.a.a(this.c, this.d);
        }
        return;
        com.umeng.common.a.b("MobclickAgent", "Exception occurred in ReportMessageHandler");
        e.printStackTrace();
    }
}
