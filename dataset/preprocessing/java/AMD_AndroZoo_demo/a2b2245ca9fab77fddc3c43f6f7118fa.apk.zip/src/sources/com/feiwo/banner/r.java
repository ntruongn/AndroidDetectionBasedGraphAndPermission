package com.feiwo.banner;

import android.content.Context;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class r implements Runnable {
    private /* synthetic */ AdReceiver a;
    private final /* synthetic */ Context b;
    private final /* synthetic */ String c;
    private final /* synthetic */ String d;
    private final /* synthetic */ JSONObject e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public r(AdReceiver adReceiver, Context context, String str, String str2, JSONObject jSONObject) {
        this.a = adReceiver;
        this.b = context;
        this.c = str;
        this.d = str2;
        this.e = jSONObject;
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.feiwo.banner.f.e.a(this.b, this.c, "12345678");
        com.feiwo.banner.e.j a = com.feiwo.banner.e.j.a();
        com.feiwo.banner.e.l lVar = new com.feiwo.banner.e.l();
        lVar.a(this.b, com.feiwo.banner.f.b.d(), this.d, this.e.toString());
        lVar.a(new s(this, this.b, this.e));
        a.a(lVar);
        this.a.a.removeCallbacks(this);
    }
}
