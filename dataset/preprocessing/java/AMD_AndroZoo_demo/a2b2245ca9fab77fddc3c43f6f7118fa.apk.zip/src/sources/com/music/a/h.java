package com.music.a;

import android.os.Environment;
import android.os.Handler;
import android.view.View;
import com.music.c.m;
import java.io.File;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class h implements Runnable {
    final /* synthetic */ c a;
    private View b;
    private String c;

    public h(c cVar, View view, String str) {
        this.a = cVar;
        this.b = view;
        this.c = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        ArrayList arrayList;
        ArrayList arrayList2;
        boolean a;
        Handler handler;
        Handler handler2;
        Handler handler3;
        Handler handler4;
        if (!Environment.getExternalStorageState().equals("mounted")) {
            handler4 = this.a.l;
            handler4.sendEmptyMessage(-4);
            return;
        }
        File file = new File(String.valueOf(Environment.getExternalStorageDirectory().getPath()) + "/" + m.c + "/");
        if (file.exists()) {
            for (File file2 : file.listFiles()) {
                if (file2.getName().startsWith(this.c)) {
                    handler3 = this.a.l;
                    handler3.sendEmptyMessage(-1);
                    return;
                }
            }
        }
        this.a.a();
        arrayList = this.a.c;
        if (arrayList.size() > 0) {
            c cVar = this.a;
            arrayList2 = this.a.c;
            a = cVar.a(arrayList2);
            if (a) {
                handler = this.a.l;
                handler.sendEmptyMessage(-2);
            } else {
                handler2 = this.a.l;
                handler2.sendEmptyMessage(2);
                this.a.a(this.b);
            }
        }
    }
}
