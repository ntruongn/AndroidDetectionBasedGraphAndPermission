package com.umeng.fb.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class b extends BroadcastReceiver {
    i a;
    final /* synthetic */ FeedbackConversations b;

    public b(FeedbackConversations feedbackConversations, i iVar) {
        this.b = feedbackConversations;
        this.a = iVar;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        this.a.a(com.umeng.fb.c.e.a(this.b));
        this.a.notifyDataSetChanged();
    }
}
