package com.feiwothree.coverscreen;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import com.feiwothree.coverscreen.a.F;
import com.feiwothree.coverscreen.a.G;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class v implements F {
    private /* synthetic */ r a;
    private final /* synthetic */ ImageView b;
    private final /* synthetic */ String c;
    private final /* synthetic */ boolean d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public v(r rVar, ImageView imageView, String str, boolean z) {
        this.a = rVar;
        this.b = imageView;
        this.c = str;
        this.d = z;
    }

    @Override // com.feiwothree.coverscreen.a.F
    public final void a(Drawable drawable) {
        Bitmap createBitmap;
        if (drawable == null || this.b.getTag() == null || !this.b.getTag().equals(this.c)) {
            return;
        }
        if (!this.d) {
            this.b.setImageDrawable(drawable);
            return;
        }
        ImageView imageView = this.b;
        Bitmap copy = ((BitmapDrawable) drawable).getBitmap().copy(Bitmap.Config.ARGB_8888, false);
        float a = G.a(this.a.getContext(), 8.0f);
        if (copy == null) {
            createBitmap = null;
        } else {
            createBitmap = Bitmap.createBitmap(copy.getWidth(), copy.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            Paint paint = new Paint();
            Rect rect = new Rect(0, 0, copy.getWidth(), copy.getHeight());
            RectF rectF = new RectF(rect);
            paint.setAntiAlias(true);
            canvas.drawARGB(0, 0, 0, 0);
            paint.setColor(-12434878);
            canvas.drawRoundRect(rectF, a, a, paint);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            canvas.drawBitmap(copy, rect, rect, paint);
            copy.recycle();
        }
        imageView.setImageBitmap(createBitmap);
    }
}
