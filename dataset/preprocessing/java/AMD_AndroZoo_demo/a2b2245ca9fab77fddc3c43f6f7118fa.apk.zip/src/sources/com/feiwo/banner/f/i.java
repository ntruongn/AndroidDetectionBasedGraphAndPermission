package com.feiwo.banner.f;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class i {
    private static i a;

    private i() {
    }

    public static i a() {
        if (a == null) {
            a = new i();
        }
        return a;
    }

    public static String a(Context context, boolean z) {
        int i = 0;
        StringBuffer stringBuffer = new StringBuffer();
        List<PackageInfo> installedPackages = context.getPackageManager().getInstalledPackages(0);
        while (true) {
            int i2 = i;
            if (i2 >= installedPackages.size()) {
                return stringBuffer.toString().substring(1);
            }
            PackageInfo packageInfo = installedPackages.get(i2);
            if ((packageInfo.applicationInfo.flags & 1) == 0) {
                stringBuffer.append(",");
                stringBuffer.append(packageInfo.packageName);
            }
            i = i2 + 1;
        }
    }

    public static boolean a(Context context, String str) {
        if (l.a(str)) {
            return false;
        }
        try {
            context.getPackageManager().getPackageInfo(str, 1);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
