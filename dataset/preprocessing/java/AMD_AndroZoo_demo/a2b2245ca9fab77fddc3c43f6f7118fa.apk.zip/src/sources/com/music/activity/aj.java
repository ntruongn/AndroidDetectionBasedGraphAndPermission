package com.music.activity;

import android.content.Intent;
import com.music.service.MusicService;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class aj implements com.music.view.d {
    final /* synthetic */ TabHostActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public aj(TabHostActivity tabHostActivity) {
        this.a = tabHostActivity;
    }

    @Override // com.music.view.d
    public void a() {
        Intent intent = new Intent("exit");
        intent.setClass(this.a, MusicService.class);
        this.a.startService(intent);
        if (ListMusicsActivity.c != null) {
            ListMusicsActivity.c.clear();
        }
        if (com.music.c.f.a != null) {
            com.music.c.f.a.clear();
        }
        this.a.d();
        this.a.finish();
    }
}
