package com.feiwo.banner;

import android.webkit.WebView;
import android.webkit.WebViewClient;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class b extends WebViewClient {
    private /* synthetic */ WebViewActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(WebViewActivity webViewActivity) {
        this.a = webViewActivity;
    }

    @Override // android.webkit.WebViewClient
    public void onPageFinished(WebView webView, String str) {
        WebView webView2;
        webView2 = this.a.a;
        webView2.getSettings().setBlockNetworkImage(false);
        super.onPageFinished(webView, str);
    }
}
