package com.umeng.a;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import java.util.Vector;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class m {
    private Vector a = new Vector(4);
    private String b;

    public m(String str) {
        this.b = str;
    }

    public static m a(Context context, String str) {
        return a(str, l.e(context).getString(str, null));
    }

    public static m a(String str, String str2) {
        m mVar = new m(str);
        if (!TextUtils.isEmpty(str2)) {
            for (String str3 : str2.split(",")) {
                String trim = str3.trim();
                if (!TextUtils.isEmpty(trim)) {
                    Long.valueOf(-1L);
                    try {
                        mVar.a(Long.valueOf(Long.parseLong(trim)));
                    } catch (Exception e) {
                    }
                }
            }
        }
        return mVar;
    }

    public Long a() {
        int size = this.a.size();
        if (size <= 0) {
            return -1L;
        }
        return (Long) this.a.remove(size - 1);
    }

    public void a(Context context) {
        String mVar = toString();
        SharedPreferences.Editor edit = l.e(context).edit();
        if (TextUtils.isEmpty(mVar)) {
            edit.remove(this.b).commit();
        } else {
            edit.putString(this.b, mVar).commit();
        }
    }

    public void a(Long l) {
        while (this.a.size() >= 4) {
            this.a.remove(0);
        }
        this.a.add(l);
    }

    public String toString() {
        int size = this.a.size();
        if (size <= 0) {
            return null;
        }
        StringBuffer stringBuffer = new StringBuffer(4);
        for (int i = 0; i < size; i++) {
            stringBuffer.append(this.a.get(i));
            if (i != size - 1) {
                stringBuffer.append(",");
            }
        }
        this.a.clear();
        return stringBuffer.toString();
    }
}
