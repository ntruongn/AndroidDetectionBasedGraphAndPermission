package com.umeng.fb.a;

import com.umeng.common.net.r;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class b extends r {
    public String d;
    public JSONObject e;
    public String f;

    public b(String str, JSONObject jSONObject, String str2) {
        super(str2);
        this.d = str;
        this.e = jSONObject;
        this.f = str2;
    }
}
