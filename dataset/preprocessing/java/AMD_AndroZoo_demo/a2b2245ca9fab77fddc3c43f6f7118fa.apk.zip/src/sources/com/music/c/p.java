package com.music.c;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class p {
    private SharedPreferences a;
    private Context b;

    public p(Context context) {
        this.b = context;
    }

    public int a(String str, String str2) {
        this.a = this.b.getSharedPreferences(str, 1);
        return this.a.getInt(str2, 0);
    }

    public void a(String str, String str2, int i) {
        this.a = this.b.getSharedPreferences(str, 1);
        SharedPreferences.Editor edit = this.a.edit();
        edit.putInt(str2, i);
        edit.commit();
    }
}
