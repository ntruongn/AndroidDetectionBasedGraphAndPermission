package com.music.c;

import android.content.Context;
import android.os.Looper;
import com.music.activity.R;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class c extends Thread {
    final /* synthetic */ b a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(b bVar) {
        this.a = bVar;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        Context context;
        Looper.prepare();
        context = this.a.c;
        j.a(context, false, 0, R.drawable.f032, "很抱歉,程序出现异常,即将退出");
        Looper.loop();
    }
}
