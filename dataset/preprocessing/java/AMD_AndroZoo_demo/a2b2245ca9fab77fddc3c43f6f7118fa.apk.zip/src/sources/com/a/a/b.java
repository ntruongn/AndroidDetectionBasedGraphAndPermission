package com.a.a;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.music.activity.R;
import com.music.c.j;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class b extends Handler {
    final /* synthetic */ a a;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(a aVar, Looper looper) {
        super(looper);
        this.a = aVar;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        String str;
        super.handleMessage(message);
        try {
            Context context = com.music.c.a.g;
            str = this.a.d;
            j.a(context, true, 0, R.drawable.f032, String.valueOf(str) + "  无法下载，请先检查网络是否能下载文件 。");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
