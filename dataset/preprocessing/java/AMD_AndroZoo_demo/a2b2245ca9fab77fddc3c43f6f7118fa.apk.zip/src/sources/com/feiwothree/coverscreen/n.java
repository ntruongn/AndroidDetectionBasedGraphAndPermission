package com.feiwothree.coverscreen;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class n implements com.feiwothree.coverscreen.a.t {
    /* JADX INFO: Access modifiers changed from: package-private */
    public n(SA sa) {
    }

    @Override // com.feiwothree.coverscreen.a.t
    public final void a(boolean z, String str) {
        new StringBuilder("服务器返回（sendClickRequest）：").append(str);
    }
}
