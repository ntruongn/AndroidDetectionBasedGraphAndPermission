package com.feiwo.banner;

import android.os.Handler;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class n implements Runnable {
    private /* synthetic */ m a;
    private final /* synthetic */ AdBanner b;
    private final /* synthetic */ Handler c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public n(m mVar, AdBanner adBanner, Handler handler) {
        this.a = mVar;
        this.b = adBanner;
        this.c = handler;
    }

    @Override // java.lang.Runnable
    public final void run() {
        m mVar;
        mVar = m.a;
        synchronized (mVar) {
            m.a(this.a, this.b, this.c);
        }
    }
}
