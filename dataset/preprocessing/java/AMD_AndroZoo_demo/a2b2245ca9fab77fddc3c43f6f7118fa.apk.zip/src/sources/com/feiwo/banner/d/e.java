package com.feiwo.banner.d;

import android.os.SystemClock;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class e extends Thread {
    private /* synthetic */ c a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ e(c cVar) {
        this(cVar, (byte) 0);
    }

    private e(c cVar, byte b) {
        this.a = cVar;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        if (c.a(this.a) == null) {
            return;
        }
        while (c.b(this.a)) {
            if (c.c(this.a)) {
                SystemClock.sleep(10L);
            } else {
                com.feiwo.banner.a.a d = c.a(this.a).d();
                c.a(this.a, d.a);
                long j = d.b;
                if (c.d(this.a) == null) {
                    return;
                }
                c.d(this.a).sendMessage(c.d(this.a).obtainMessage());
                SystemClock.sleep(j);
            }
        }
    }
}
