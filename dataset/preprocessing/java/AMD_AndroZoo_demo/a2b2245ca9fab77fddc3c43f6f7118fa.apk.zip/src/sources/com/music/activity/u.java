package com.music.activity;

import android.os.Environment;
import android.text.TextUtils;
import com.music.domain.MusicNetWorkInfo;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class u extends Thread implements Runnable {
    private MusicNetWorkInfo a;

    public u(MusicNetWorkInfo musicNetWorkInfo) {
        this.a = musicNetWorkInfo;
    }

    private void a() {
        com.music.c.a.f = true;
        String str = this.a.musicName;
        String str2 = this.a.musicSinger;
        String str3 = this.a.decode;
        if (TextUtils.isEmpty(str3)) {
            return;
        }
        int indexOf = str3.indexOf("?");
        String substring = indexOf != -1 ? str3.substring(str3.indexOf("."), indexOf) : str3.substring(str3.lastIndexOf(".", str3.length() - 1));
        System.out.println("DownloadListActivity 中文件 " + str + "-" + str2 + substring + "下载完毕。");
        com.music.c.i iVar = new com.music.c.i(com.music.c.a.g);
        String str4 = String.valueOf(Environment.getExternalStorageDirectory().getPath()) + "/" + com.music.c.m.c + "/" + str + "-" + str2 + substring;
        File file = new File(str4);
        if (file.exists()) {
            System.out.println(String.valueOf(file.getName()) + "存在，准备添加到媒体库中。");
            iVar.a(str4, com.music.c.d.a(file));
        }
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        if (this.a != null) {
            a();
        }
    }
}
