package com.umeng.fb.ui;

import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class e implements View.OnClickListener {
    final /* synthetic */ FeedbackConversation a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(FeedbackConversation feedbackConversation) {
        this.a = feedbackConversation;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        EditText editText;
        JSONObject jSONObject;
        EditText editText2;
        EditText editText3;
        com.umeng.fb.e eVar;
        f fVar;
        com.umeng.fb.e eVar2;
        f fVar2;
        f fVar3;
        com.umeng.fb.e eVar3;
        editText = this.a.i;
        String editable = editText.getText().toString();
        if (editable == null || editable.trim().length() == 0) {
            return;
        }
        if (editable.length() > 140) {
            Toast.makeText(this.a, this.a.getString(com.umeng.fb.b.e.o(this.a)), 0).show();
            return;
        }
        try {
            FeedbackConversation feedbackConversation = this.a;
            eVar3 = this.a.f;
            jSONObject = com.umeng.fb.c.d.a(feedbackConversation, editable, eVar3.c);
        } catch (Exception e) {
            Toast.makeText(this.a, e.getMessage(), 0).show();
            com.umeng.fb.c.e.d(this.a, (JSONObject) null);
            Log.d(FeedbackConversation.c, e.getMessage());
            jSONObject = null;
        }
        editText2 = this.a.i;
        editText2.setText("");
        InputMethodManager inputMethodManager = (InputMethodManager) this.a.getSystemService("input_method");
        editText3 = this.a.i;
        inputMethodManager.hideSoftInputFromWindow(editText3.getWindowToken(), 0);
        com.umeng.fb.c.e.c(this.a, jSONObject);
        FeedbackConversation feedbackConversation2 = this.a;
        FeedbackConversation feedbackConversation3 = this.a;
        eVar = this.a.f;
        feedbackConversation2.f = com.umeng.fb.c.e.b(feedbackConversation3, eVar.c);
        fVar = this.a.g;
        eVar2 = this.a.f;
        fVar.a(eVar2);
        fVar2 = this.a.g;
        fVar2.notifyDataSetChanged();
        FeedbackConversation feedbackConversation4 = this.a;
        fVar3 = this.a.g;
        feedbackConversation4.setSelection(fVar3.getCount() - 1);
        FeedbackConversation.e.submit(new com.umeng.fb.a.f(jSONObject, this.a));
    }
}
