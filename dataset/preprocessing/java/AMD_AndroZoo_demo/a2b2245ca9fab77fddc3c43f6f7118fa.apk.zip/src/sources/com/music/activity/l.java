package com.music.activity;

import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import com.feiwothree.coverscreen.AdComponent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class l extends Handler {
    final /* synthetic */ ListMusicsActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(ListMusicsActivity listMusicsActivity) {
        this.a = listMusicsActivity;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        TextView textView;
        switch (message.what) {
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                textView = this.a.f;
                textView.setVisibility(0);
                break;
            case 7:
                this.a.f();
                break;
        }
        this.a.j = true;
    }
}
