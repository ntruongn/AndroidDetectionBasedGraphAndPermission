package com.music.activity;

import android.app.ProgressDialog;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class z implements Runnable {
    final /* synthetic */ MusicSearchActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public z(MusicSearchActivity musicSearchActivity) {
        this.a = musicSearchActivity;
    }

    @Override // java.lang.Runnable
    public void run() {
        boolean z;
        ProgressDialog progressDialog;
        ProgressDialog progressDialog2;
        while (!Thread.interrupted()) {
            z = this.a.n;
            if (z) {
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                progressDialog = this.a.m;
                if (progressDialog != null) {
                    progressDialog2 = this.a.m;
                    progressDialog2.cancel();
                    return;
                }
                return;
            }
            try {
                Thread.sleep(100L);
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
        }
    }
}
