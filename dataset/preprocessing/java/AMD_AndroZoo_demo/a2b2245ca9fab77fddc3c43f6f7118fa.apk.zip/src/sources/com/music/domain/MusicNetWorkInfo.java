package com.music.domain;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class MusicNetWorkInfo {
    public String decode;
    public String encode;
    public String lrcUrl;
    public String lrcid;
    public String musicName;
    public String musicSinger;
    public String musicUrl;

    public MusicNetWorkInfo() {
        this.encode = "";
        this.decode = "";
        this.lrcid = "";
        this.musicName = "";
        this.musicSinger = "";
        this.musicUrl = "";
        this.lrcUrl = "";
    }

    public MusicNetWorkInfo(String str, String str2, String str3, String str4) {
        this.encode = "";
        this.decode = "";
        this.lrcid = "";
        this.musicName = "";
        this.musicSinger = "";
        this.musicUrl = "";
        this.lrcUrl = "";
        this.musicName = str;
        this.musicSinger = str2;
        this.musicUrl = str3;
        this.lrcUrl = str4;
    }

    public MusicNetWorkInfo(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.encode = "";
        this.decode = "";
        this.lrcid = "";
        this.musicName = "";
        this.musicSinger = "";
        this.musicUrl = "";
        this.lrcUrl = "";
        this.encode = str;
        this.decode = str2;
        this.lrcid = str3;
        this.musicName = str4;
        this.musicSinger = str5;
        this.musicUrl = str6;
        this.lrcUrl = str7;
    }

    public String toString() {
        return " musicName=[" + this.musicName + "] decode=[" + this.decode + "]";
    }
}
