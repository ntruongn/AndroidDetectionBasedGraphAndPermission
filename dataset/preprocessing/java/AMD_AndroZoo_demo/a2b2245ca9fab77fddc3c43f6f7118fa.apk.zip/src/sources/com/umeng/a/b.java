package com.umeng.a;

import android.content.Context;
import android.content.SharedPreferences;
import com.feiwothree.coverscreen.AdComponent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class b {
    private static long a = 10000;
    private int b = -1;
    private long c = -1;
    private long d = -1;

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(Context context) {
        if (this.b == 4) {
            SharedPreferences.Editor edit = l.d(context).edit();
            edit.putString(com.umeng.common.b.c(), "true");
            edit.commit();
        } else if (this.b == 6) {
            this.c = System.currentTimeMillis();
            l.b(context).edit().putLong("last_report_time", this.c).commit();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(Context context, int i, long j) {
        if (i < 0 || i > 6) {
            com.umeng.common.a.b("MobclickAgent", "Illegal value of report policy");
            return;
        }
        this.b = i;
        this.d = j;
        SharedPreferences.Editor putInt = l.b(context).edit().putInt("umeng_net_report_policy", i);
        if (j < a) {
            j = a;
        }
        putInt.putLong("report_interval", j).commit();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean a(String str, Context context) {
        if (!com.umeng.common.b.a(context, "android.permission.ACCESS_NETWORK_STATE") || !com.umeng.common.b.h(context)) {
            return false;
        }
        if ("flush".equals(str) || "error".equals(str)) {
            return true;
        }
        switch (this.b) {
            case 0:
                return true;
            case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
                if (str == "launch") {
                    return true;
                }
                break;
            case AdComponent.FAIL_NO_AD /* 2 */:
                if (str == "terminate") {
                    return true;
                }
                break;
            case AdComponent.FAIL_IN_PREPARATION /* 3 */:
            default:
                this.b = b(context);
                return true;
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                return !l.d(context).getString(com.umeng.common.b.c(), "false").equals("true") && str.equals("launch");
            case AdComponent.FAIL_SHOW_AD /* 5 */:
                return com.umeng.common.b.f(context);
            case 6:
                if (System.currentTimeMillis() - this.c > this.d) {
                    return true;
                }
                break;
        }
        return false;
    }

    int b(Context context) {
        SharedPreferences b = l.b(context);
        return b.getInt("umeng_net_report_policy", -1) != -1 ? b.getInt("umeng_net_report_policy", 1) : b.getInt("umeng_local_report_policy", 1);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(Context context) {
        if (this.b == -1) {
            this.b = b(context);
        }
        if (this.b == 6 && this.d == -1) {
            SharedPreferences b = l.b(context);
            this.d = b.getLong("report_interval", a);
            this.c = b.getLong("last_report_time", -1L);
        }
    }
}
