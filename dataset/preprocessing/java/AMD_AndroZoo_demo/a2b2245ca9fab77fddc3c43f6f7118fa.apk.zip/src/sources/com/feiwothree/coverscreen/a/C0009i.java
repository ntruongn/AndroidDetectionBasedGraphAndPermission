package com.feiwothree.coverscreen.a;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.os.Handler;
import android.telephony.TelephonyManager;
import com.feiwothree.coverscreen.AdComponent;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/* renamed from: com.feiwothree.coverscreen.a.i, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class C0009i {
    static C0009i a;
    ConcurrentLinkedQueue b;
    Map c;
    Context d;
    Handler e;

    public C0009i() {
    }

    private C0009i(Context context) {
        this.b = new ConcurrentLinkedQueue();
        this.c = new ConcurrentHashMap();
        this.d = context;
        this.e = new Handler();
    }

    public static C0009i a() {
        if (a == null) {
            throw new RuntimeException("DownloadManager is not yet initialize");
        }
        return a;
    }

    public static boolean a(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static int b(Context context) {
        boolean z = true;
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        if (activeNetworkInfo == null || !activeNetworkInfo.isConnected()) {
            return 0;
        }
        String typeName = activeNetworkInfo.getTypeName();
        if (typeName.equalsIgnoreCase("WIFI")) {
            return 4;
        }
        if (!typeName.equalsIgnoreCase("MOBILE")) {
            return 0;
        }
        if (!J.a(Proxy.getDefaultHost())) {
            return 1;
        }
        switch (((TelephonyManager) context.getSystemService("phone")).getNetworkType()) {
            case AdComponent.FAIL_NOT_INITIALIZE /* 1 */:
                z = false;
                break;
            case AdComponent.FAIL_NO_AD /* 2 */:
                z = false;
                break;
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                z = false;
                break;
            case 7:
                z = false;
                break;
            case 11:
                z = false;
                break;
        }
        return z ? 3 : 2;
    }

    public static void c(Context context) {
        a = new C0009i(context);
    }

    public void a(C0001a c0001a) {
        new StringBuilder("[DownloadManager] removeTask: ").append(c0001a.a()).append(",").append(c0001a.d());
        this.c.remove(c0001a.d());
    }

    public void a(C0001a c0001a, m mVar) {
        new StringBuilder("[DownloadManager] addTask: ").append(c0001a.a()).append(",").append(c0001a.d());
        n nVar = (n) this.c.get(c0001a.d());
        if (nVar != null) {
            nVar.a(mVar);
            return;
        }
        n nVar2 = new n(this, c0001a, mVar);
        this.c.put(c0001a.d(), nVar2);
        nVar2.start();
    }

    public boolean a(String str) {
        return this.c.containsKey(str);
    }

    public void b() {
        n nVar = (n) this.b.poll();
        while (nVar != null) {
            a(nVar.b, (m) nVar.a.poll());
            nVar = (n) this.b.poll();
        }
    }
}
