package com.feiwo.banner.a;

import android.graphics.Bitmap;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class a {
    public Bitmap a;
    public int b;
    public a c;

    public a() {
    }

    public a(Bitmap bitmap, int i) {
        this.c = null;
        this.a = bitmap;
        this.b = i;
    }

    public static void a(View view) {
        AnimationSet animationSet = new AnimationSet(true);
        animationSet.addAnimation(new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, 0.5f, 0.5f));
        animationSet.setDuration(2000L);
        animationSet.setFillEnabled(false);
        animationSet.setAnimationListener(new b());
        view.startAnimation(animationSet);
    }

    public static void b(View view) {
        AnimationSet animationSet = new AnimationSet(true);
        animationSet.addAnimation(new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, 1, 0.5f, 1, 0.5f));
        animationSet.addAnimation(new AlphaAnimation(0.0f, 1.0f));
        animationSet.setInterpolator(new AccelerateDecelerateInterpolator());
        animationSet.setDuration(2000L);
        view.startAnimation(animationSet);
    }

    public static void c(View view) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(2000L);
        alphaAnimation.setFillEnabled(true);
        alphaAnimation.setAnimationListener(new c());
        view.startAnimation(alphaAnimation);
    }
}
