package com.music.c;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class f {
    public static Vector a = new Vector();

    private void a(InputStream inputStream) {
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "GBK");
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine == null) {
                break;
            } else {
                c(readLine);
            }
        }
        bufferedReader.close();
        inputStreamReader.close();
        if (inputStream != null) {
            inputStream.close();
        }
    }

    private InputStream b(String str) {
        return new FileInputStream(new File(str));
    }

    private void c(String str) {
        Pattern compile = Pattern.compile("\\[(\\d{2}:\\d{2}\\.\\d{2})\\]");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()) {
            h hVar = new h();
            int groupCount = matcher.groupCount();
            for (int i = 0; i <= groupCount; i++) {
                String group = matcher.group(i);
                if (i == 1) {
                    hVar.b = Long.valueOf(d(group)).intValue();
                }
            }
            String[] split = compile.split(str);
            for (int i2 = 0; i2 < split.length; i2++) {
                if (i2 == split.length - 1) {
                    hVar.a = split[i2];
                }
            }
            a.add(hVar);
        }
    }

    private long d(String str) {
        try {
            String[] split = str.split(":");
            int parseInt = Integer.parseInt(split[0]);
            int parseInt2 = Integer.parseInt(split[1].substring(0, split[1].indexOf(".")));
            return (Integer.parseInt(split[1].substring(r2 + 1)) * 10) + (parseInt * 60 * 1000) + (parseInt2 * 1000);
        } catch (Exception e) {
            return -1L;
        }
    }

    public void a(String str) {
        a.clear();
        try {
            InputStream b = b(str);
            if (b != null) {
                a(b);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        if (a != null && a.size() > 0) {
            Collections.sort(a, new g(this));
        }
        System.out.println("排序后的歌词为：" + a.toString());
    }
}
