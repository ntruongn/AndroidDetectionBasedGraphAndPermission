package com.umeng.common.net;

import android.os.Bundle;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class f {
    public String a;
    public String b;
    public String c;
    public String[] d = null;
    public boolean e = false;

    public f(String str, String str2, String str3) {
        this.a = str;
        this.b = str2;
        this.c = str3;
    }

    public static f a(Bundle bundle) {
        f fVar = new f(bundle.getString("mComponentName"), bundle.getString("mTitle"), bundle.getString("mUrl"));
        fVar.d = bundle.getStringArray("reporturls");
        fVar.e = bundle.getBoolean("rich_notification");
        return fVar;
    }
}
