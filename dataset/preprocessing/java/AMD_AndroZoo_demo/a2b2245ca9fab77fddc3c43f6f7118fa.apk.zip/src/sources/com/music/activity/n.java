package com.music.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class n implements com.music.view.d {
    final /* synthetic */ m a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public n(m mVar) {
        this.a = mVar;
    }

    @Override // com.music.view.d
    public void a() {
        ListMusicsActivity listMusicsActivity;
        int i;
        ListMusicsActivity listMusicsActivity2;
        int i2;
        ListMusicsActivity listMusicsActivity3;
        ListMusicsActivity listMusicsActivity4;
        int i3;
        ListMusicsActivity listMusicsActivity5;
        int i4;
        ListMusicsActivity listMusicsActivity6;
        ListMusicsActivity listMusicsActivity7;
        ListMusicsActivity listMusicsActivity8;
        int i5 = com.music.c.a.d;
        listMusicsActivity = this.a.a;
        i = listMusicsActivity.n;
        if (i5 == i) {
            listMusicsActivity8 = this.a.a;
            com.music.c.j.a(listMusicsActivity8, false, 0, R.drawable.f032, "正在播放此音乐，请稍后再删除。");
            return;
        }
        ArrayList arrayList = ListMusicsActivity.c;
        listMusicsActivity2 = this.a.a;
        i2 = listMusicsActivity2.n;
        String obj = ((HashMap) arrayList.get(i2)).get("musicPath").toString();
        listMusicsActivity3 = this.a.a;
        com.music.c.e.a(listMusicsActivity3, obj);
        if (new File(obj).delete()) {
            ArrayList arrayList2 = ListMusicsActivity.c;
            listMusicsActivity4 = this.a.a;
            i3 = listMusicsActivity4.n;
            arrayList2.remove(i3);
            ArrayList arrayList3 = ListMusicsActivity.d;
            listMusicsActivity5 = this.a.a;
            i4 = listMusicsActivity5.n;
            arrayList3.remove(i4);
            listMusicsActivity6 = this.a.a;
            com.music.c.j.a(listMusicsActivity6, false, 0, R.drawable.f023, "删除成功！");
            listMusicsActivity7 = this.a.a;
            listMusicsActivity7.b.notifyDataSetChanged();
        }
    }
}
