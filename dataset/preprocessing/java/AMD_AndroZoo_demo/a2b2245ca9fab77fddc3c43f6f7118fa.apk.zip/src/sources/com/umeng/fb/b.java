package com.umeng.fb;

import java.util.Date;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class b implements Comparable {
    String a;
    String b;
    public String c;
    public Date d;
    public d e;
    public c f;
    public JSONObject g;

    public b(JSONObject jSONObject) {
        this.f = c.OK;
        if (jSONObject == null) {
            throw new Exception("invalid atom");
        }
        this.g = jSONObject;
        String optString = jSONObject.optString("type");
        if ("new_feedback".equals(optString)) {
            this.e = d.Starting;
        } else if ("dev_reply".equals(optString)) {
            this.e = d.DevReply;
        } else if ("user_reply".equals(optString)) {
            this.e = d.UserReply;
        }
        String optString2 = jSONObject.optString("state");
        if ("sending".equalsIgnoreCase(optString2)) {
            this.f = c.Sending;
        } else if ("fail".equalsIgnoreCase(optString2)) {
            this.f = c.Fail;
        } else if ("ok".equalsIgnoreCase(optString2)) {
            this.f = c.OK;
        } else if ("ReSending".equalsIgnoreCase(optString2)) {
            this.f = c.Resending;
        }
        if (this.e == d.Starting) {
            this.a = jSONObject.optString("thread");
        }
        this.b = jSONObject.optString("thread");
        if (com.umeng.common.b.b.c(this.b)) {
            this.b = jSONObject.optString("content");
        }
        this.c = jSONObject.optString("feedback_id");
        this.d = h.a(jSONObject.optString("datetime"));
    }

    @Override // java.lang.Comparable
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public int compareTo(b bVar) {
        Date date = bVar.d;
        if (this.d == null || date == null || date.equals(this.d)) {
            return 0;
        }
        return date.after(this.d) ? -1 : 1;
    }

    public String a() {
        return this.e == d.Starting ? this.a : this.b;
    }
}
