package com.feiwothree.coverscreen;

import com.feiwothree.coverscreen.a.C0001a;
import com.feiwothree.coverscreen.a.C0010j;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class l extends com.feiwothree.coverscreen.a.m {
    final /* synthetic */ SA a;
    private final /* synthetic */ C0010j b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(SA sa, C0010j c0010j) {
        this.a = sa;
        this.b = c0010j;
    }

    @Override // com.feiwothree.coverscreen.a.m
    public final void a(C0001a c0001a, String str, boolean z) {
        super.a(c0001a, str, z);
        if ("true".equals(this.b.o()) && z) {
            this.a.a.post(new m(this, str, c0001a));
        }
    }
}
