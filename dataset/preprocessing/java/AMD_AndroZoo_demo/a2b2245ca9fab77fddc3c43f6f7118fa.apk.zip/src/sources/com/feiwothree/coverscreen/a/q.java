package com.feiwothree.coverscreen.a;

import android.content.Intent;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class q implements Runnable {
    private /* synthetic */ n a;
    private final /* synthetic */ int b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public q(n nVar, int i) {
        this.a = nVar;
        this.b = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        C0009i c0009i;
        c0009i = this.a.h;
        x.a(c0009i.d).a(this.a.b.e() + 12345, 17301586, this.a.b.a(), this.a.b.a(), "已下载 " + this.b + "%", new Intent(), 18, this.a.b.b(), this.a.d);
    }
}
