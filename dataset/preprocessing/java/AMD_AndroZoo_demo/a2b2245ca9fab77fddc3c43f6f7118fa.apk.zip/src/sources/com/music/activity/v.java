package com.music.activity;

import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import com.feiwothree.coverscreen.AdComponent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class v extends Handler {
    final /* synthetic */ MusicSearchActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public v(MusicSearchActivity musicSearchActivity) {
        this.a = musicSearchActivity;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        TextView textView;
        TextView textView2;
        switch (message.what) {
            case -5:
                com.music.c.j.a(this.a, false, 0, R.drawable.f032, String.valueOf(MusicSearchActivity.b) + "-" + MusicSearchActivity.c + " 没有找到下载资源。");
                break;
            case -4:
                com.music.c.j.a(this.a, false, 0, R.drawable.f032, "无内存卡");
                break;
            case -3:
                com.music.c.j.a(this.a, false, 0, R.drawable.f032, "您的网络不是很好，请稍后再试！");
                break;
            case -2:
                com.music.c.j.a(this.a, false, 0, R.drawable.f023, String.valueOf(MusicSearchActivity.b) + "  已添加到下载队列中");
                break;
            case -1:
                com.music.c.j.a(this.a, false, 0, R.drawable.f032, String.valueOf(MusicSearchActivity.b) + "  已下载过了！");
                break;
            case AdComponent.FAIL_NO_AD /* 2 */:
                com.music.c.j.a(this.a, false, 0, R.drawable.f023, String.valueOf(MusicSearchActivity.b) + "  已添加到下载队列中");
                break;
            case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                String str = (String) message.obj;
                if (str != null) {
                    com.music.c.j.a(this.a, false, 0, R.drawable.f032, str);
                } else {
                    com.music.c.j.a(this.a, false, 0, R.drawable.f032, "榜单信息获取失败，请稍后再试。");
                }
                textView2 = this.a.l;
                textView2.setVisibility(0);
                break;
            case 7:
                this.a.d();
                break;
            case 8:
                textView = this.a.l;
                textView.setVisibility(0);
                break;
        }
        this.a.n = true;
    }
}
