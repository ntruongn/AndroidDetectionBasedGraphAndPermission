package com.music.activity;

import android.app.Application;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class CrashApplication extends Application {
    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        com.music.c.b.a().a(this);
    }
}
