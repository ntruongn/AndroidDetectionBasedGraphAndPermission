package com.music.activity;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class ae extends GestureDetector.SimpleOnGestureListener {
    int a = 100;
    int b = 200;
    final /* synthetic */ PlayerActivity c;

    public ae(PlayerActivity playerActivity, Context context) {
        this.c = playerActivity;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public boolean onDown(MotionEvent motionEvent) {
        return true;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
        if (PlayerActivity.b == null || PlayerActivity.b.size() <= 0) {
            return true;
        }
        if (motionEvent.getX() - motionEvent2.getX() > this.a && Math.abs(f) > this.b) {
            this.c.d();
            return true;
        }
        if (motionEvent2.getX() - motionEvent.getX() <= this.a || Math.abs(f) <= this.b || PlayerActivity.b.get(com.music.c.a.d) == null || PlayerActivity.b.size() <= 0) {
            return true;
        }
        this.c.e();
        return true;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public void onLongPress(MotionEvent motionEvent) {
        super.onLongPress(motionEvent);
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
        return true;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public void onShowPress(MotionEvent motionEvent) {
        super.onShowPress(motionEvent);
    }
}
