package com.feiwo.banner;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class k implements com.feiwo.banner.e.d {
    private /* synthetic */ d a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(d dVar) {
        this.a = dVar;
    }

    @Override // com.feiwo.banner.e.d
    public final void a(Drawable drawable) {
        ImageView imageView;
        imageView = this.a.d;
        imageView.setBackgroundDrawable(drawable);
    }
}
