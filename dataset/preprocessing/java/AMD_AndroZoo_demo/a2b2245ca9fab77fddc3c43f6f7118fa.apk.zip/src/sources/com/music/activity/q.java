package com.music.activity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.util.HashMap;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class q extends BaseAdapter {
    final /* synthetic */ ListMusicsActivity a;
    private Context b;

    public q(ListMusicsActivity listMusicsActivity, Context context) {
        this.a = listMusicsActivity;
        this.b = context;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (ListMusicsActivity.c != null) {
            return ListMusicsActivity.c.size();
        }
        return 0;
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        if (ListMusicsActivity.c != null) {
            return ListMusicsActivity.c.get(i);
        }
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        t tVar;
        if (view == null) {
            view = LayoutInflater.from(this.b).inflate(R.layout.music_item, (ViewGroup) null);
            tVar = new t(this.a);
            tVar.b = (TextView) view.findViewById(R.id.music_singer);
            tVar.a = (TextView) view.findViewById(R.id.music_name);
            tVar.c = (TextView) view.findViewById(R.id.music_time);
            tVar.e = (ProgressBar) view.findViewById(R.id.download_progress);
            tVar.d = (ImageView) view.findViewById(R.id.item_right_pic);
            tVar.e.setVisibility(8);
            view.setTag(tVar);
        } else {
            tVar = (t) view.getTag();
        }
        if (ListMusicsActivity.c != null && ListMusicsActivity.c.size() > 0 && i < ListMusicsActivity.c.size()) {
            tVar.b.setText(new StringBuilder().append(i + 1).toString());
            Object obj = ((HashMap) ListMusicsActivity.c.get(i)).get("title");
            String obj2 = obj == null ? "" : obj.toString();
            String str = obj2.length() > 10 ? String.valueOf(obj2.substring(0, 8)) + ".." : obj2;
            Object obj3 = ((HashMap) ListMusicsActivity.c.get(i)).get("musicArtist");
            String obj4 = obj3 == null ? "" : obj3.toString();
            Object obj5 = ((HashMap) ListMusicsActivity.c.get(i)).get("duration");
            String obj6 = obj5 == null ? "" : obj5.toString();
            tVar.a.setText(str);
            tVar.b.setText(obj4);
            tVar.c.setText(obj6);
            if (ListMusicsActivity.d == null || i >= ListMusicsActivity.d.size() || !((Boolean) ListMusicsActivity.d.get(i)).booleanValue()) {
                tVar.d.setImageResource(R.drawable.item_right);
            } else {
                tVar.d.setImageResource(R.drawable.item_right_playing);
            }
        }
        return view;
    }
}
