package com.umeng.common.net;

import android.content.Context;
import android.widget.Toast;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class o implements Runnable {
    final /* synthetic */ b a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(b bVar) {
        this.a = bVar;
    }

    @Override // java.lang.Runnable
    public void run() {
        DownloadingService downloadingService;
        Context context;
        downloadingService = this.a.a;
        context = this.a.b;
        Toast.makeText(downloadingService, com.umeng.common.a.c.e(context), 0).show();
    }
}
