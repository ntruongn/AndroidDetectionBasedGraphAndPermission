package com.umeng.fb.ui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class SendFeedback extends Activity {
    private Spinner d;
    private Spinner e;
    private EditText f;
    private TextView g;
    private TextView h;
    private ImageButton i;
    private com.umeng.fb.c.b j;
    private Map k;
    private Map l;
    private JSONObject m;
    private static final String c = SendFeedback.class.getName();
    static boolean a = true;
    public static ExecutorService b = Executors.newFixedThreadPool(3);

    public static Map a(JSONObject jSONObject) {
        try {
            Iterator<String> keys = jSONObject.keys();
            HashMap hashMap = new HashMap();
            while (keys.hasNext()) {
                String next = keys.next();
                hashMap.put(next, jSONObject.get(next).toString());
            }
            return hashMap;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static JSONObject a(Map map) {
        JSONObject jSONObject = new JSONObject();
        for (Map.Entry entry : map.entrySet()) {
            try {
                jSONObject.put((String) entry.getKey(), entry.getValue().toString());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        return jSONObject;
    }

    private void a() {
        this.d = (Spinner) findViewById(com.umeng.fb.b.c.a(this));
        this.e = (Spinner) findViewById(com.umeng.fb.b.c.b(this));
        this.g = (TextView) findViewById(com.umeng.fb.b.c.c(this));
        if (com.umeng.fb.c.a.e) {
            this.h = (TextView) findViewById(com.umeng.fb.b.c.d(this));
            this.h.setVisibility(0);
        } else {
            this.h = (TextView) findViewById(com.umeng.fb.b.c.d(this));
            this.h.setVisibility(4);
        }
        this.f = (EditText) findViewById(com.umeng.fb.b.c.e(this));
        this.i = (ImageButton) findViewById(com.umeng.fb.b.c.f(this));
        if (this.d != null) {
            ArrayAdapter arrayAdapter = new ArrayAdapter(this, 17367048, getResources().getStringArray(com.umeng.fb.b.a.a(this)));
            arrayAdapter.setDropDownViewResource(17367049);
            this.d.setAdapter((SpinnerAdapter) arrayAdapter);
        }
        if (this.e != null) {
            ArrayAdapter arrayAdapter2 = new ArrayAdapter(this, 17367048, getResources().getStringArray(com.umeng.fb.b.a.b(this)));
            arrayAdapter2.setDropDownViewResource(17367049);
            this.e.setAdapter((SpinnerAdapter) arrayAdapter2);
        }
        if (this.i != null) {
            this.i.setOnClickListener(new k(this));
        }
        b();
        c();
    }

    private void b() {
        if (this.f != null) {
            this.f.setHint(getString(com.umeng.fb.b.e.c(this)));
        }
        if (this.g != null) {
            this.g.setText(getString(com.umeng.fb.b.e.d(this)));
        }
        if (this.h != null) {
            this.h.setText(getString(com.umeng.fb.b.e.e(this)));
        }
    }

    private void c() {
        int e;
        int d;
        String stringExtra = getIntent().getStringExtra("feedback_id");
        if (stringExtra != null && this.f != null) {
            String string = getSharedPreferences("feedback", 0).getString(stringExtra, null);
            if (!com.umeng.common.b.b.c(string)) {
                try {
                    this.f.setText(new com.umeng.fb.b(new JSONArray(string).getJSONObject(0)).a());
                    com.umeng.fb.c.e.a(this, "feedback", stringExtra);
                } catch (Exception e2) {
                    if (com.umeng.fb.g.c) {
                        e2.printStackTrace();
                    }
                }
            }
        }
        if (this.d != null && (d = d()) != -1) {
            this.d.setSelection(d);
        }
        if (this.e != null && (e = e()) != -1) {
            this.e.setSelection(e);
        }
        f();
    }

    private int d() {
        return getSharedPreferences("UmengFb_Nums", 0).getInt("ageGroup", -1);
    }

    private int e() {
        return getSharedPreferences("UmengFb_Nums", 0).getInt("sex", -1);
    }

    private void f() {
        try {
            SharedPreferences sharedPreferences = getSharedPreferences("UmengFb_Nums", 0);
            String string = sharedPreferences.getString("OtherAttrContext", "");
            String string2 = sharedPreferences.getString("OtherAttrRemark", "");
            if (string == null || string.length() <= 0) {
                this.k = null;
            } else {
                this.k = a(new JSONObject(string).getJSONObject("Json_OtherAttrContact"));
            }
            if (string2 == null || string2.length() <= 0) {
                this.l = null;
            } else {
                this.l = a(new JSONObject(string2).getJSONObject("Json_OtherAttrRemark"));
            }
            if (this.j != null) {
                this.j.a(this, this.k, this.l);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void a(com.umeng.fb.c.b bVar) {
        this.j = bVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        d dVar = null;
        Object[] objArr = 0;
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(com.umeng.fb.b.d.a(this));
        a(com.umeng.fb.a.a);
        a();
        if (this.g != null) {
            this.g.setOnClickListener(new d(this, dVar));
            if (this.f != null) {
                ((InputMethodManager) getSystemService("input_method")).toggleSoftInput(2, 0);
            }
        }
        if (this.h != null) {
            this.h.setOnClickListener(new c(this, objArr == true ? 1 : 0));
            ((InputMethodManager) getSystemService("input_method")).toggleSoftInput(2, 0);
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        try {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.f.getWindowToken(), 0);
        } catch (Exception e) {
            Log.e(c, e.getMessage());
        }
        super.onPause();
    }
}
