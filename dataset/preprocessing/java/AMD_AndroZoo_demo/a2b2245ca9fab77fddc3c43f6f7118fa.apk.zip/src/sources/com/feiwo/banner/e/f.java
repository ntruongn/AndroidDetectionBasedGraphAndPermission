package com.feiwo.banner.e;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class f {
    private static f b;
    private NotificationManager a;
    private Notification c;
    private Context d;
    private boolean e;

    public f() {
    }

    public f(Context context) {
        this.a = null;
        this.c = null;
        this.e = false;
        this.d = context;
        if (this.a == null) {
            this.a = (NotificationManager) context.getSystemService("notification");
        }
    }

    /* JADX WARN: Not initialized variable reg: 3, insn: 0x013d: MOVE (r1 I:??[OBJECT, ARRAY]) = (r3 I:??[OBJECT, ARRAY]), block:B:138:0x013d */
    public static Drawable a(Context context, String str) {
        HttpURLConnection httpURLConnection;
        InputStream inputStream;
        ByteArrayOutputStream byteArrayOutputStream;
        BufferedInputStream bufferedInputStream;
        ByteArrayOutputStream byteArrayOutputStream2;
        BufferedInputStream bufferedInputStream2;
        Drawable drawable;
        BufferedInputStream bufferedInputStream3 = null;
        try {
            try {
                URL url = new URL(str);
                httpURLConnection = e.a(context) == 12 ? (HttpURLConnection) url.openConnection(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(android.net.Proxy.getDefaultHost(), android.net.Proxy.getDefaultPort()))) : (HttpURLConnection) url.openConnection();
                try {
                    httpURLConnection.setConnectTimeout(10000);
                    httpURLConnection.setReadTimeout(10000);
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    inputStream = httpURLConnection.getInputStream();
                } catch (Exception e) {
                    e = e;
                    bufferedInputStream = null;
                    inputStream = null;
                    byteArrayOutputStream2 = null;
                } catch (OutOfMemoryError e2) {
                    bufferedInputStream = null;
                    inputStream = null;
                    byteArrayOutputStream2 = null;
                } catch (Throwable th) {
                    th = th;
                    inputStream = null;
                    byteArrayOutputStream = null;
                }
            } catch (Throwable th2) {
                th = th2;
                bufferedInputStream3 = bufferedInputStream2;
            }
        } catch (Exception e3) {
            e = e3;
            httpURLConnection = null;
            bufferedInputStream = null;
            inputStream = null;
            byteArrayOutputStream2 = null;
        } catch (OutOfMemoryError e4) {
            httpURLConnection = null;
            bufferedInputStream = null;
            inputStream = null;
            byteArrayOutputStream2 = null;
        } catch (Throwable th3) {
            th = th3;
            httpURLConnection = null;
            inputStream = null;
            byteArrayOutputStream = null;
        }
        if (inputStream == null) {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e5) {
                    e5.printStackTrace();
                }
            }
            httpURLConnection.disconnect();
            return null;
        }
        try {
            bufferedInputStream = new BufferedInputStream(inputStream, 16384);
            try {
                byteArrayOutputStream2 = new ByteArrayOutputStream(16384);
                try {
                    byte[] bArr = new byte[16384];
                    for (int read = bufferedInputStream.read(bArr); read != -1; read = bufferedInputStream.read(bArr)) {
                        byteArrayOutputStream2.write(bArr, 0, read);
                    }
                    drawable = Drawable.createFromStream(new ByteArrayInputStream(byteArrayOutputStream2.toByteArray()), "src");
                    try {
                        byteArrayOutputStream2.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                    try {
                        bufferedInputStream.close();
                    } catch (IOException e7) {
                        e7.printStackTrace();
                    }
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e8) {
                            e8.printStackTrace();
                        }
                    }
                    httpURLConnection.disconnect();
                } catch (Exception e9) {
                    e = e9;
                    e.printStackTrace();
                    new StringBuilder("error > ").append(e.getMessage());
                    if (byteArrayOutputStream2 != null) {
                        try {
                            byteArrayOutputStream2.close();
                        } catch (IOException e10) {
                            e10.printStackTrace();
                        }
                    }
                    if (bufferedInputStream != null) {
                        try {
                            bufferedInputStream.close();
                        } catch (IOException e11) {
                            e11.printStackTrace();
                        }
                    }
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e12) {
                            e12.printStackTrace();
                        }
                    }
                    httpURLConnection.disconnect();
                    drawable = null;
                    return drawable;
                } catch (OutOfMemoryError e13) {
                    if (byteArrayOutputStream2 != null) {
                        try {
                            byteArrayOutputStream2.close();
                        } catch (IOException e14) {
                            e14.printStackTrace();
                        }
                    }
                    if (bufferedInputStream != null) {
                        try {
                            bufferedInputStream.close();
                        } catch (IOException e15) {
                            e15.printStackTrace();
                        }
                    }
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e16) {
                            e16.printStackTrace();
                        }
                    }
                    httpURLConnection.disconnect();
                    drawable = null;
                    return drawable;
                }
            } catch (Exception e17) {
                e = e17;
                byteArrayOutputStream2 = null;
            } catch (OutOfMemoryError e18) {
                byteArrayOutputStream2 = null;
            } catch (Throwable th4) {
                th = th4;
                byteArrayOutputStream = null;
                bufferedInputStream3 = bufferedInputStream;
                if (byteArrayOutputStream != null) {
                    try {
                        byteArrayOutputStream.close();
                    } catch (IOException e19) {
                        e19.printStackTrace();
                    }
                }
                if (bufferedInputStream3 != null) {
                    try {
                        bufferedInputStream3.close();
                    } catch (IOException e20) {
                        e20.printStackTrace();
                    }
                }
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e21) {
                        e21.printStackTrace();
                    }
                }
                httpURLConnection.disconnect();
                throw th;
            }
        } catch (Exception e22) {
            e = e22;
            bufferedInputStream = null;
            byteArrayOutputStream2 = null;
        } catch (OutOfMemoryError e23) {
            bufferedInputStream = null;
            byteArrayOutputStream2 = null;
        } catch (Throwable th5) {
            th = th5;
            byteArrayOutputStream = null;
        }
        return drawable;
    }

    public static f a(Context context) {
        if (b == null) {
            b = new f(context);
        }
        return b;
    }

    public void a(int i) {
        this.a.cancel(i);
    }

    public void a(int i, String str, String str2, String str3, Intent intent, int i2) {
        if (this.c == null) {
            this.c = new Notification();
        }
        this.c.icon = 17301586;
        this.c.tickerText = "正在为您下载";
        this.c.flags = i2;
        this.c.setLatestEventInfo(this.d, str2, str3, PendingIntent.getActivity(this.d, 0, intent, 67108864));
        this.a.notify(i, this.c);
    }
}
