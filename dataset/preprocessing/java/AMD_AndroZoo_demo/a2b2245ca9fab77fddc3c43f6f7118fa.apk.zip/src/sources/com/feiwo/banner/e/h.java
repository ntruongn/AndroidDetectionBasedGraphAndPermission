package com.feiwo.banner.e;

import android.content.Context;
import java.net.MalformedURLException;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class h implements Runnable {
    private int a = 0;
    private int b = -1;
    private int c = 0;
    private int d = 0;
    private String e = null;
    private String f = null;
    private Context g = null;
    private URL h = null;
    private i i;

    public final void a(Context context, String str, String str2) {
        this.g = context;
        this.e = str;
        this.f = str2;
        try {
            this.h = new URL(str);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    public final void a(i iVar) {
        this.i = iVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:103:0x0176 A[Catch: IOException -> 0x017f, TryCatch #18 {IOException -> 0x017f, blocks: (B:111:0x0171, B:103:0x0176, B:105:0x017b), top: B:110:0x0171 }] */
    /* JADX WARN: Removed duplicated region for block: B:105:0x017b A[Catch: IOException -> 0x017f, TRY_LEAVE, TryCatch #18 {IOException -> 0x017f, blocks: (B:111:0x0171, B:103:0x0176, B:105:0x017b), top: B:110:0x0171 }] */
    /* JADX WARN: Removed duplicated region for block: B:110:0x0171 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r2v14, types: [java.io.FileOutputStream] */
    /* JADX WARN: Type inference failed for: r2v18 */
    /* JADX WARN: Type inference failed for: r2v19 */
    /* JADX WARN: Type inference failed for: r2v22 */
    /* JADX WARN: Type inference failed for: r2v23 */
    /* JADX WARN: Type inference failed for: r2v24 */
    /* JADX WARN: Type inference failed for: r2v25 */
    /* JADX WARN: Type inference failed for: r2v26 */
    /* JADX WARN: Type inference failed for: r2v27 */
    /* JADX WARN: Type inference failed for: r2v28 */
    /* JADX WARN: Type inference failed for: r2v29 */
    /* JADX WARN: Type inference failed for: r2v30 */
    /* JADX WARN: Type inference failed for: r2v31 */
    /* JADX WARN: Type inference failed for: r2v4 */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v8 */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 452
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.feiwo.banner.e.h.run():void");
    }
}
