package com.feiwo.banner;

import android.content.Context;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class s implements com.feiwo.banner.e.k {
    private final /* synthetic */ Context a;
    private final /* synthetic */ JSONObject b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public s(r rVar, Context context, JSONObject jSONObject) {
        this.a = context;
        this.b = jSONObject;
    }

    @Override // com.feiwo.banner.e.k
    public final void a(boolean z, String str) {
        if (str == null || !z) {
            com.feiwo.banner.f.e.b(this.a, "ADFEIWO", "list_install", this.b.toString(), "12345678");
        } else {
            com.feiwo.banner.f.e.b(this.a, "ADFEIWO", "list_install", new JSONObject().toString(), "12345678");
        }
    }
}
