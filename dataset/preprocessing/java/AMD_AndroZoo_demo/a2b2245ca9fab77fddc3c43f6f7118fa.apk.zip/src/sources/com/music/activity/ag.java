package com.music.activity;

import android.app.ProgressDialog;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class ag implements Runnable {
    final /* synthetic */ ShowOneBanddangListActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ag(ShowOneBanddangListActivity showOneBanddangListActivity) {
        this.a = showOneBanddangListActivity;
    }

    @Override // java.lang.Runnable
    public void run() {
        boolean z;
        ProgressDialog progressDialog;
        while (!Thread.interrupted()) {
            z = this.a.h;
            if (z) {
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                progressDialog = this.a.g;
                progressDialog.cancel();
                return;
            }
            try {
                Thread.sleep(100L);
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
        }
    }
}
