package com.feiwothree.coverscreen;

import android.content.Context;
import com.feiwothree.coverscreen.a.I;

/* JADX INFO: Access modifiers changed from: package-private */
/* renamed from: com.feiwothree.coverscreen.d, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class C0013d implements com.feiwothree.coverscreen.a.t {
    private /* synthetic */ AdComponent a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public C0013d(AdComponent adComponent) {
        this.a = adComponent;
    }

    @Override // com.feiwothree.coverscreen.a.t
    public final void a(boolean z, String str) {
        Context context;
        new StringBuilder("服务器返回（sendAppInstall）：").append(str);
        if (z) {
            context = this.a.d;
            I.b(context, "DP_FEIWO", "packnames", (String) null);
        }
    }
}
