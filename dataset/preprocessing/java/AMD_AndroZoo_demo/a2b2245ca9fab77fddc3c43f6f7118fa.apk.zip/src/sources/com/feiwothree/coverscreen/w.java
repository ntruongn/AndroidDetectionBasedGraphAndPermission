package com.feiwothree.coverscreen;

import android.view.View;
import android.view.animation.Animation;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
final class w implements Animation.AnimationListener {
    private final /* synthetic */ Animation.AnimationListener a;
    private final /* synthetic */ View b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public w(r rVar, Animation.AnimationListener animationListener, View view) {
        this.a = animationListener;
        this.b = view;
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationEnd(Animation animation) {
        this.a.onAnimationEnd(animation);
        this.b.setVisibility(0);
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationRepeat(Animation animation) {
        this.a.onAnimationRepeat(animation);
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationStart(Animation animation) {
        this.a.onAnimationStart(animation);
    }
}
