package com.music.activity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.music.service.MusicService;
import com.music.view.MarqueeTextView;
import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class PlayerActivity extends BaseActivity implements View.OnClickListener {
    public static ArrayList b = new ArrayList();
    public static int c = 0;
    public int d;
    private ImageView h;
    private ImageView i;
    private ImageView j;
    private ImageView k;
    private ImageView l;
    private TextView m;
    private TextView n;
    private TextView o;
    private MarqueeTextView p;
    private TextView q;
    private SeekBar r;
    private IntentFilter s;
    private ad t;
    private Intent v;
    private String u = "顺序播放";
    private int w = 0;
    public boolean e = false;
    public GestureDetector f = null;
    public com.music.c.p g = new com.music.c.p(this);

    private void c() {
        this.h = (ImageView) findViewById(R.id.play_mode_im);
        this.i = (ImageView) findViewById(R.id.imgFront);
        this.j = (ImageView) findViewById(R.id.imgPlaying);
        this.k = (ImageView) findViewById(R.id.imgStop);
        this.l = (ImageView) findViewById(R.id.imgNext);
        this.n = (TextView) findViewById(R.id.tvSumTime);
        this.m = (TextView) findViewById(R.id.tvNowTime);
        this.p = (MarqueeTextView) findViewById(R.id.musictitle);
        this.r = (SeekBar) findViewById(R.id.seekBar);
        this.q = (TextView) findViewById(R.id.musiclrc);
        this.o = (TextView) findViewById(R.id.tag);
        this.f = new GestureDetector(this, new ae(this, this));
        this.i.setOnClickListener(this);
        this.j.setOnClickListener(this);
        this.k.setOnClickListener(this);
        this.l.setOnClickListener(this);
        this.r.setOnSeekBarChangeListener(new ac(this));
        int a = this.g.a("Mode", "selectedMode");
        this.w = a;
        if (a == 1) {
            this.h.setImageResource(R.drawable.mode_repateone);
            this.u = "单曲循环";
        } else if (a == 2) {
            this.h.setImageResource(R.drawable.mode_repeaterandom);
            this.u = "随机播放";
        } else {
            this.h.setImageResource(R.drawable.mode_sequence);
            this.u = "顺序播放";
        }
        this.h.setOnClickListener(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d() {
        com.music.c.a.e = false;
        if (com.music.c.a.d < b.size() - 1) {
            com.music.c.a.d++;
            this.p.setText(((HashMap) b.get(com.music.c.a.d)).get("title").toString());
            this.q.setText("");
            this.v = new Intent("R.id.imgNext");
            this.v.putExtra("musicPath", ((HashMap) b.get(com.music.c.a.d)).get("musicPath").toString());
            this.v.setClass(this, MusicService.class);
            startService(this.v);
        } else {
            com.music.c.k.a(this, "提示", "已经到最后一首歌了！").show();
        }
        this.o.setText(String.valueOf(com.music.c.a.d + 1) + "/" + b.size());
        c = 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e() {
        com.music.c.a.e = false;
        if (com.music.c.a.d > 0) {
            com.music.c.a.d--;
            this.p.setText(((HashMap) b.get(com.music.c.a.d)).get("title").toString());
            this.q.setText("");
            this.v = new Intent("R.id.imgFront");
            this.v.putExtra("musicPath", ((HashMap) b.get(com.music.c.a.d)).get("musicPath").toString());
            this.v.setClass(this, MusicService.class);
            startService(this.v);
        } else {
            com.music.c.k.a(this, "提示", "已经到第一首歌了！").show();
        }
        this.o.setText(String.valueOf(com.music.c.a.d + 1) + "/" + b.size());
        c = 0;
    }

    private void f() {
        if (!com.music.c.a.e) {
            b();
            return;
        }
        com.music.c.a.e = false;
        c = 0;
        this.v = new Intent("R.id.imgStop");
        this.v.putExtra("musicPath", ((HashMap) b.get(com.music.c.a.d)).get("musicPath").toString());
        this.v.setClass(this, MusicService.class);
        startService(this.v);
        this.q.setText("");
        this.m.setText("00:00");
        this.r.setProgress(0);
    }

    public int a(int i) {
        if (com.music.c.f.a == null || com.music.c.f.a.size() <= 0) {
            return -1;
        }
        int i2 = -1;
        for (int i3 = 0; i3 < com.music.c.f.a.size(); i3++) {
            if (i3 == 0) {
                if (((com.music.c.h) com.music.c.f.a.get(0)).b() > i) {
                    i2 = 0;
                }
            } else if (i3 == com.music.c.f.a.size() - 1) {
                if (((com.music.c.h) com.music.c.f.a.get(com.music.c.f.a.size() - 1)).b() <= i) {
                    i2 = com.music.c.f.a.size() - 1;
                }
            } else if (((com.music.c.h) com.music.c.f.a.get(i3)).b() <= i && ((com.music.c.h) com.music.c.f.a.get(i3 + 1)).b() > i) {
                i2 = i3;
            }
        }
        return i2;
    }

    public void a() {
        this.s = new IntentFilter();
        this.s.addAction("onCompletion");
        this.s.addAction("com.run");
        this.s.addAction("getSetDialog");
        this.t = new ad(this, null);
        registerReceiver(this.t, this.s);
    }

    public void b() {
        if (com.music.c.a.e) {
            this.v = new Intent("R.id.imgPause");
        } else {
            this.v = new Intent("R.id.imgPlay");
        }
        this.p.setText(((HashMap) b.get(com.music.c.a.d)).get("title").toString());
        this.o.setText(String.valueOf(com.music.c.a.d + 1) + "/" + b.size());
        this.v.putExtra("musicPath", ((HashMap) b.get(com.music.c.a.d)).get("musicPath").toString());
        this.v.setClass(this, MusicService.class);
        startService(this.v);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imgFront /* 2131230729 */:
                if (b == null || b.size() <= 0) {
                    return;
                }
                e();
                return;
            case R.id.imgPlaying /* 2131230730 */:
                if (b == null || b.size() <= 0) {
                    return;
                }
                b();
                return;
            case R.id.imgStop /* 2131230731 */:
                if (b == null || b.size() <= 0) {
                    return;
                }
                f();
                return;
            case R.id.imgNext /* 2131230732 */:
                if (b == null || b.size() <= 0) {
                    return;
                }
                d();
                return;
            case R.id.tvSumTime /* 2131230733 */:
            default:
                return;
            case R.id.play_mode_im /* 2131230734 */:
                this.w++;
                int length = this.w % new String[]{"顺序播放", "单曲循环", "随机播放"}.length;
                if (length == 1) {
                    this.h.setImageResource(R.drawable.mode_repateone);
                    this.g.a("Mode", "selectedMode", length);
                    this.u = "单曲循环";
                } else if (length == 2) {
                    this.h.setImageResource(R.drawable.mode_repeaterandom);
                    this.g.a("Mode", "selectedMode", length);
                    this.u = "随机播放";
                } else {
                    this.h.setImageResource(R.drawable.mode_sequence);
                    this.g.a("Mode", "selectedMode", length);
                    this.u = "顺序播放";
                }
                Toast.makeText(this, this.u, 0).show();
                return;
        }
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.main);
        c();
        a();
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        if (b != null) {
            b.clear();
            b = null;
        }
        if (this.t != null) {
            unregisterReceiver(this.t);
        }
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        if (ListMusicsActivity.c == null || ListMusicsActivity.c.size() <= 0) {
            b = com.music.c.e.b(this);
            ListMusicsActivity.c.addAll(b);
            for (int i = 0; i < ListMusicsActivity.c.size(); i++) {
                ListMusicsActivity.d.add(false);
            }
        } else {
            b = ListMusicsActivity.c;
        }
        if (b == null || b.size() <= 0 || com.music.c.a.d >= b.size()) {
            this.i.setClickable(false);
            this.j.setClickable(false);
            this.k.setClickable(false);
            this.l.setClickable(false);
            this.r.setClickable(false);
            this.p.setText("内存卡中还没有没有歌曲");
            this.q.setText("");
            this.o.setText("");
            return;
        }
        this.i.setClickable(true);
        this.j.setClickable(true);
        this.k.setClickable(true);
        this.l.setClickable(true);
        this.r.setClickable(true);
        c = 0;
        this.p.setText(((HashMap) b.get(com.music.c.a.d)).get("title").toString());
        this.o.setText(String.valueOf(com.music.c.a.d + 1) + "/" + b.size());
        this.q.setText("");
    }

    @Override // android.app.Activity
    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return this.f.onTouchEvent(motionEvent);
    }
}
