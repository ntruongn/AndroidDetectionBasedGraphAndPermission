package com.music.activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.music.domain.MusicNetWorkInfo;
import com.music.domain.ObjectInfo;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class MusicSearchActivity extends BaseActivity implements View.OnClickListener {
    public static String b;
    public static String c;
    public static int d = 0;
    public static ArrayList e = new ArrayList();
    private com.a.a.a A;
    private EditText f;
    private EditText g;
    private ListView h;
    private com.music.a.i i;
    private ImageView j;
    private TextView k;
    private TextView l;
    private ProgressDialog m;
    private String o;
    private boolean n = false;
    private ArrayList p = new ArrayList();
    private String q = "";
    private final int r = -1;
    private final int s = -2;
    private final int t = 2;
    private final int u = -3;
    private final int v = -4;
    private final int w = -5;
    private String x = "";
    private String y = "";
    private Handler z = DownloadListActivity.d;
    private Handler B = new v(this);

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void a(String str) {
        new AlertDialog.Builder(this).setTitle(str).setItems(new String[]{"下载"}, new x(this)).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(String str, String str2) {
        if (str2 == null || str2.trim().equals("")) {
            d = 0;
            this.o = "http://box.zhangmen.baidu.com/x?op=7&mode=1&listid=48015&count=1&title=" + str;
            String a = com.music.service.a.a(this, this.o, "gb2312");
            if (a.contains("error：")) {
                Message obtainMessage = this.B.obtainMessage();
                obtainMessage.what = 4;
                obtainMessage.obj = a.replace("error：", "");
                this.B.sendMessage(obtainMessage);
                return;
            }
            if (a.contains("<count>0</count>")) {
                this.B.sendEmptyMessage(-5);
                return;
            }
            e = com.music.c.n.a(this, a, ObjectInfo.class, "data", new String[]{"name", "id"}, false);
            if (e == null || e.size() <= 0) {
                Message obtainMessage2 = this.B.obtainMessage();
                obtainMessage2.what = 8;
                this.B.sendMessage(obtainMessage2);
                return;
            } else {
                Message obtainMessage3 = this.B.obtainMessage();
                obtainMessage3.what = 7;
                this.B.sendMessage(obtainMessage3);
                return;
            }
        }
        this.o = "http://box.zhangmen.baidu.com/x?op=12&count=1&title=" + str + "$$" + str2;
        d = 1;
        String a2 = com.music.service.a.a(this, this.o, null, "gb2312");
        if (a2.contains("<durl>")) {
            a2 = String.valueOf(a2.substring(0, a2.indexOf("<durl>"))) + "</result>";
        }
        if (a2.contains("error：")) {
            Message obtainMessage4 = this.B.obtainMessage();
            obtainMessage4.what = 4;
            obtainMessage4.obj = a2.replace("error：", "");
            this.B.sendMessage(obtainMessage4);
            return;
        }
        if (a2.contains("<count>0</count>")) {
            this.B.sendEmptyMessage(-5);
            return;
        }
        e.clear();
        e = com.music.c.n.a(this, a2, MusicNetWorkInfo.class, "url", new String[]{"encode", "decode", "lrcid"}, false);
        if (e == null || e.size() <= 0) {
            Message obtainMessage5 = this.B.obtainMessage();
            obtainMessage5.what = 8;
            this.B.sendMessage(obtainMessage5);
            return;
        }
        for (int i = 0; i < e.size(); i++) {
            String str3 = ((MusicNetWorkInfo) e.get(i)).encode;
            String str4 = ((MusicNetWorkInfo) e.get(i)).decode;
            String str5 = ((MusicNetWorkInfo) e.get(i)).lrcid;
            if (str5.length() > 2) {
                this.x = "http://box.zhangmen.baidu.com/bdlrc/" + str5.substring(0, str5.length() - 2) + "/" + str5 + ".lrc";
            } else {
                this.x = "http://box.zhangmen.baidu.com/bdlrc/" + str5 + "/" + str5 + ".lrc";
            }
            int lastIndexOf = str3.lastIndexOf("/");
            if (lastIndexOf != -1) {
                this.y = String.valueOf(str3.substring(0, lastIndexOf + 1)) + str4;
            }
            ((MusicNetWorkInfo) e.get(i)).musicUrl = this.y;
            ((MusicNetWorkInfo) e.get(i)).lrcUrl = this.x;
            ((MusicNetWorkInfo) e.get(i)).musicName = str;
            ((MusicNetWorkInfo) e.get(i)).musicSinger = str2;
        }
        Message obtainMessage6 = this.B.obtainMessage();
        obtainMessage6.what = 7;
        this.B.sendMessage(obtainMessage6);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean a(ArrayList arrayList) {
        for (int i = 0; i < arrayList.size(); i++) {
            String str = ((MusicNetWorkInfo) arrayList.get(i)).musicUrl;
            com.music.b.b.a aVar = new com.music.b.b.a(this);
            if (com.music.c.m.a.size() == 0) {
                aVar.a();
            }
            Iterator it = com.music.c.m.a.iterator();
            while (it.hasNext()) {
                if (((MusicNetWorkInfo) it.next()).musicUrl.equals(str)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void c() {
        this.k = (TextView) findViewById(R.id.title);
        this.k.setText("音乐搜索");
        this.h = (ListView) findViewById(R.id.goods_list);
        this.h.setOnItemClickListener(new w(this));
        this.f = (EditText) findViewById(R.id.song_name);
        this.g = (EditText) findViewById(R.id.song_singer);
        this.l = (TextView) findViewById(R.id.category_list_nodata);
        this.l.setOnClickListener(this);
        this.j = (ImageView) findViewById(R.id.songer_search);
        this.j.setOnClickListener(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d() {
        if (e == null || e.size() <= 0) {
            this.l.setVisibility(0);
        } else if (this.i != null) {
            this.i.notifyDataSetChanged();
        } else {
            this.i = new com.music.a.i(this, b, c);
            this.h.setAdapter((ListAdapter) this.i);
        }
    }

    public void a() {
        if (this.A == null) {
            this.A = new com.a.a.a();
        }
        if (d == 0) {
            this.A.a(this.y, this.x, String.valueOf(b) + "-" + c, 1, this, this.z, this.p);
        } else if (d == 1) {
            this.A.a(this.y, this.x, String.valueOf(b) + "-" + c, 1, this, this.z, e);
        }
    }

    public void b() {
        String a = com.music.service.a.a(this, this.q, "gb2312");
        if (a.contains("error：") || a.equals("")) {
            this.B.sendEmptyMessage(-3);
            return;
        }
        if (a.contains("<count>0</count>")) {
            this.B.sendEmptyMessage(-5);
            return;
        }
        this.p.clear();
        this.p = com.music.c.n.a(this, a, MusicNetWorkInfo.class, "url", new String[]{"encode", "decode", "lrcid"}, false);
        if (this.p == null || this.p.size() <= 0) {
            Message obtainMessage = this.B.obtainMessage();
            obtainMessage.what = 8;
            this.B.sendMessage(obtainMessage);
            return;
        }
        for (int i = 0; i < this.p.size(); i++) {
            String str = ((MusicNetWorkInfo) this.p.get(i)).encode;
            String str2 = ((MusicNetWorkInfo) this.p.get(i)).decode;
            String str3 = ((MusicNetWorkInfo) this.p.get(i)).lrcid;
            if (str3.length() > 2) {
                this.x = "http://box.zhangmen.baidu.com/bdlrc/" + str3.substring(0, str3.length() - 2) + "/" + str3 + ".lrc";
            } else {
                this.x = "http://box.zhangmen.baidu.com/bdlrc/" + str3 + "/" + str3 + ".lrc";
            }
            int lastIndexOf = str.lastIndexOf("/");
            if (lastIndexOf != -1) {
                this.y = String.valueOf(str.substring(0, lastIndexOf + 1)) + str2;
            }
            ((MusicNetWorkInfo) this.p.get(i)).musicUrl = this.y;
            ((MusicNetWorkInfo) this.p.get(i)).lrcUrl = this.x;
            ((MusicNetWorkInfo) this.p.get(i)).musicName = b;
            ((MusicNetWorkInfo) this.p.get(i)).musicSinger = c;
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        this.n = false;
        switch (view.getId()) {
            case R.id.category_list_nodata /* 2131230742 */:
            case R.id.songer_search /* 2131230750 */:
                c = this.g.getText().toString();
                b = this.f.getText().toString();
                if (b == null || b.equals("")) {
                    com.music.c.j.a(this, false, 0, R.drawable.f032, "歌曲名不能为空！");
                    return;
                }
                e.clear();
                this.l.setVisibility(8);
                this.m = new ProgressDialog(this);
                this.m.setOnKeyListener(new y(this));
                this.m.setMessage("数据获取中....");
                this.m.show();
                new Thread(new ab(this, b, c)).start();
                new Thread(new z(this)).start();
                this.a.hideSoftInputFromWindow(view.getWindowToken(), 2);
                return;
            default:
                return;
        }
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.music_search);
        c();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        d = 0;
    }
}
