package com.music.view;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.music.activity.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class a extends Dialog {
    private Context a;
    private TextView b;
    private TextView c;
    private ImageView d;
    private Button e;
    private Button f;
    private View g;

    public a(Context context, int i) {
        super(context, i);
        a(context);
    }

    private void a(Context context) {
        this.a = context;
        this.g = LayoutInflater.from(context).inflate(R.layout.my_alert_dialog, (ViewGroup) null);
        setContentView(this.g);
        this.b = (TextView) this.g.findViewById(R.id.alertdialog_title_tv);
        this.c = (TextView) this.g.findViewById(R.id.alertdialog_message_tv);
        this.d = (ImageView) this.g.findViewById(R.id.alertdialog_title_image);
        this.e = (Button) this.g.findViewById(R.id.dialog_button_ok);
        this.f = (Button) this.g.findViewById(R.id.dialog_button_cancel);
        getWindow().setBackgroundDrawableResource(17170445);
    }

    public a a(int i) {
        this.d.setBackgroundResource(i);
        return this;
    }

    public a a(String str) {
        if (!TextUtils.isEmpty(str)) {
            this.b.setText(str);
        }
        return this;
    }

    public a a(String str, d dVar) {
        if (!TextUtils.isEmpty(str)) {
            this.e.setText(str);
        }
        this.e.setOnClickListener(new b(this, this, dVar));
        return this;
    }

    public a b(String str) {
        if (!TextUtils.isEmpty(str)) {
            this.c.setText(str);
        }
        return this;
    }

    public a b(String str, d dVar) {
        if (!TextUtils.isEmpty(str)) {
            this.f.setText(str);
        }
        this.f.setOnClickListener(new c(this, this, dVar));
        return this;
    }

    @Override // android.app.Dialog
    public void show() {
        super.show();
        Activity activity = (Activity) this.a;
        if (activity == null) {
            return;
        }
        Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.width = (int) (0.85d * defaultDisplay.getWidth());
        attributes.height = -2;
        getWindow().setAttributes(attributes);
    }
}
