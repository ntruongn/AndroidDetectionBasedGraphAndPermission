package com.music.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.TextView;
import com.music.domain.ObjectInfo;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class BangdangListActivity extends BaseActivity {
    private TextView b;
    private View c;
    private GridView d;
    private com.music.a.a e;
    private ProgressDialog f;
    private boolean g = false;
    private String h = "http://box.zhangmen.baidu.com/x?op=3&list_cat=1";
    private ArrayList i = new ArrayList();
    private Handler j = new a(this);

    private void a() {
        this.b = (TextView) findViewById(R.id.title);
        this.b.setText("音乐榜单");
        this.c = findViewById(R.id.category_list_nodata_layout);
        this.c.setOnClickListener(new b(this));
        this.d = (GridView) findViewById(R.id.gridview);
        this.d.setOnItemClickListener(new c(this));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b() {
        String a = com.music.service.a.a(this, this.h, null, "gb2312");
        if (a.startsWith("error：")) {
            Message obtainMessage = this.j.obtainMessage();
            obtainMessage.what = 4;
            obtainMessage.obj = a.replace("error：", "");
            this.j.sendMessage(obtainMessage);
            return;
        }
        System.out.println("开始解析榜单xml文件...");
        this.i = com.music.c.n.a(this, a, ObjectInfo.class, "data", new String[]{"id", "name"}, false);
        System.out.println("解析榜单xml文件结束");
        if (this.i == null || this.i.size() <= 0) {
            Message obtainMessage2 = this.j.obtainMessage();
            obtainMessage2.what = 8;
            this.j.sendMessage(obtainMessage2);
        } else {
            Message obtainMessage3 = this.j.obtainMessage();
            obtainMessage3.what = 7;
            this.j.sendMessage(obtainMessage3);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c() {
        this.e = new com.music.a.a(this.i, this);
        this.d.setVisibility(0);
        this.d.setAdapter((ListAdapter) this.e);
    }

    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.bangdan);
        a();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.music.activity.BaseActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        if (this.i.size() == 0) {
            this.g = false;
            this.c.setVisibility(8);
            this.f = ProgressDialog.show(this, "", "数据获取中....", false, true);
            new Thread(new e(this)).start();
            new Thread(new d(this)).start();
        }
    }
}
