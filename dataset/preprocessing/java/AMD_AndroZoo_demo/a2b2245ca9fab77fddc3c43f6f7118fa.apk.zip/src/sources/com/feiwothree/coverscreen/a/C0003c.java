package com.feiwothree.coverscreen.a;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;

/* renamed from: com.feiwothree.coverscreen.a.c, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class C0003c {
    private static C0003c a;
    private String b;
    private String c;
    private String d;
    private String e;
    private String f;

    public C0003c() {
    }

    private C0003c(Context context) {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            String networkOperator = telephonyManager.getNetworkOperator();
            this.b = networkOperator.substring(0, 3);
            this.c = networkOperator.substring(3);
            if (telephonyManager.getCellLocation() instanceof CdmaCellLocation) {
                CdmaCellLocation cdmaCellLocation = (CdmaCellLocation) telephonyManager.getCellLocation();
                this.d = String.valueOf(cdmaCellLocation.getBaseStationId());
                this.e = String.valueOf(cdmaCellLocation.getNetworkId());
                this.f = telephonyManager.getLine1Number();
            } else if (telephonyManager.getCellLocation() instanceof GsmCellLocation) {
                GsmCellLocation gsmCellLocation = (GsmCellLocation) telephonyManager.getCellLocation();
                this.d = String.valueOf(gsmCellLocation.getCid());
                this.e = String.valueOf(gsmCellLocation.getLac());
                this.f = telephonyManager.getLine1Number();
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    public static C0003c a(Context context) {
        if (a == null) {
            a = new C0003c(context);
        }
        return a;
    }

    public String a() {
        return this.b;
    }

    public String b() {
        return this.c;
    }

    public String c() {
        return this.d;
    }

    public String d() {
        return this.e;
    }

    public String e() {
        return J.a(this.f) ? "" : this.f;
    }
}
