package com.feiwothree.coverscreen;

import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public final class x extends TimerTask {
    private /* synthetic */ r a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public x(r rVar) {
        this.a = rVar;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public final void run() {
        this.a.a.runOnUiThread(new y(this));
    }
}
