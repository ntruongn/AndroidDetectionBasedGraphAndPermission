package com.music.c;

import java.util.Comparator;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class g implements Comparator {
    final /* synthetic */ f a;

    public g(f fVar) {
        this.a = fVar;
    }

    private int b(h hVar, h hVar2) {
        if (hVar.b() < hVar2.b()) {
            return -1;
        }
        return hVar.b() > hVar2.b() ? 1 : 0;
    }

    @Override // java.util.Comparator
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public int compare(h hVar, h hVar2) {
        return b(hVar, hVar2);
    }
}
