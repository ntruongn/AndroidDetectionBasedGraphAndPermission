package com.umeng.fb.c;

import android.content.Context;
import android.content.Intent;
import com.umeng.fb.f;
import com.umeng.fb.ui.FeedbackConversation;
import com.umeng.fb.ui.FeedbackConversations;
import com.umeng.fb.ui.SendFeedback;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
public class a {
    public static Context a = null;
    public static Context b = null;
    public static Map c = null;
    public static Map d = null;
    public static boolean e = false;

    public static void a(Context context) {
        if (a == null) {
            a = context;
        } else if (context instanceof FeedbackConversations) {
            b = context;
        }
        a(context, null);
    }

    public static void a(Context context, com.umeng.fb.e eVar) {
        Intent intent = new Intent(context, (Class<?>) SendFeedback.class);
        intent.setFlags(131072);
        if (eVar != null && eVar.b == f.PureFail) {
            intent.putExtra("feedback_id", eVar.c);
        }
        context.startActivity(intent);
    }

    public static void b(Context context) {
        if (a == null) {
            a = context;
        }
        Intent intent = new Intent(context, (Class<?>) FeedbackConversations.class);
        intent.setFlags(131072);
        context.startActivity(intent);
    }

    public static void b(Context context, com.umeng.fb.e eVar) {
        if (a == null) {
            a = context;
        }
        FeedbackConversation.a(context);
        Intent intent = new Intent(context, (Class<?>) FeedbackConversation.class);
        intent.setFlags(131072);
        intent.putExtra("feedback_id", eVar.c);
        context.startActivity(intent);
    }
}
