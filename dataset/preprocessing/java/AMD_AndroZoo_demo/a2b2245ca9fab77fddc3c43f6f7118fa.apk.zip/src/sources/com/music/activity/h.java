package com.music.activity;

import android.view.View;
import android.widget.TextView;
import com.music.domain.MusicNetWorkInfo;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a2b2245ca9fab77fddc3c43f6f7118fa.apk/classes.dex */
class h implements View.OnClickListener {
    final /* synthetic */ g a;
    private final /* synthetic */ j b;
    private final /* synthetic */ MusicNetWorkInfo c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h(g gVar, j jVar, MusicNetWorkInfo musicNetWorkInfo) {
        this.a = gVar;
        this.b = jVar;
        this.c = musicNetWorkInfo;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        DownloadListActivity downloadListActivity;
        String str;
        DownloadListActivity downloadListActivity2;
        String str2;
        DownloadListActivity downloadListActivity3;
        String[] strArr;
        DownloadListActivity downloadListActivity4;
        String[] strArr2;
        String obj = this.b.c.getTag().toString();
        ArrayList arrayList = new ArrayList();
        arrayList.add(this.c);
        downloadListActivity = this.a.a;
        str = downloadListActivity.m;
        if (str.equals(obj)) {
            g gVar = this.a;
            TextView textView = this.b.c;
            downloadListActivity4 = this.a.a;
            strArr2 = downloadListActivity4.j;
            gVar.a(textView, strArr2, arrayList, true);
            return;
        }
        downloadListActivity2 = this.a.a;
        str2 = downloadListActivity2.n;
        if (str2.equals(obj)) {
            g gVar2 = this.a;
            TextView textView2 = this.b.c;
            downloadListActivity3 = this.a.a;
            strArr = downloadListActivity3.i;
            gVar2.a(textView2, strArr, arrayList, false);
        }
    }
}
