package com.google.android.gms.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.CollectionMetadataField;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.StringMetadataField;
import com.google.android.gms.plus.PlusShare;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class et {
    public static final MetadataField<DriveId> oU = ev.pb;
    public static final MetadataField<String> TITLE = new StringMetadataField(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE);
    public static final MetadataField<String> MIME_TYPE = new StringMetadataField("mimeType");
    public static final MetadataField<Boolean> STARRED = new com.google.android.gms.drive.metadata.internal.a("starred");
    public static final MetadataField<Boolean> TRASHED = new com.google.android.gms.drive.metadata.internal.a("trashed") { // from class: com.google.android.gms.internal.et.1
        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.drive.metadata.internal.a, com.google.android.gms.drive.metadata.MetadataField
        /* renamed from: e */
        public Boolean b(DataHolder dataHolder, int i, int i2) {
            return Boolean.valueOf(dataHolder.getInteger(getName(), i, i2) != 0);
        }
    };
    public static final MetadataField<Boolean> oV = new com.google.android.gms.drive.metadata.internal.a("isEditable");
    public static final MetadataField<Boolean> oW = new com.google.android.gms.drive.metadata.internal.a("isPinned");
    public static final CollectionMetadataField<DriveId> PARENTS = new com.google.android.gms.drive.metadata.internal.e("parents");
}
