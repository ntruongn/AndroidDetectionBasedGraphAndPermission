package com.google.android.gms.games.multiplayer.turnbased;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.games.GameEntity;
import com.google.android.gms.games.multiplayer.ParticipantEntity;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class TurnBasedMatchEntityCreator implements Parcelable.Creator<TurnBasedMatchEntity> {
    public static final int CONTENT_DESCRIPTION = 0;

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(TurnBasedMatchEntity turnBasedMatchEntity, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 1, (Parcelable) turnBasedMatchEntity.getGame(), i, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, turnBasedMatchEntity.getMatchId(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, turnBasedMatchEntity.getCreatorId(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 4, turnBasedMatchEntity.getCreationTimestamp());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, turnBasedMatchEntity.getLastUpdaterId(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 6, turnBasedMatchEntity.getLastUpdatedTimestamp());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 7, turnBasedMatchEntity.getPendingParticipantId(), false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 8, turnBasedMatchEntity.getStatus());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 10, turnBasedMatchEntity.getVariant());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 11, turnBasedMatchEntity.getVersion());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 12, turnBasedMatchEntity.getData(), false);
        com.google.android.gms.common.internal.safeparcel.b.b(parcel, 13, turnBasedMatchEntity.getParticipants(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 14, turnBasedMatchEntity.getRematchId(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 15, turnBasedMatchEntity.getPreviousMatchData(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 17, turnBasedMatchEntity.getAutoMatchCriteria(), false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 16, turnBasedMatchEntity.getMatchNumber());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1000, turnBasedMatchEntity.getVersionCode());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 19, turnBasedMatchEntity.isLocallyModified());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 18, turnBasedMatchEntity.getTurnStatus());
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // android.os.Parcelable.Creator
    public TurnBasedMatchEntity createFromParcel(Parcel parcel) {
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        GameEntity gameEntity = null;
        String str = null;
        String str2 = null;
        long j = 0;
        String str3 = null;
        long j2 = 0;
        String str4 = null;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        byte[] bArr = null;
        ArrayList arrayList = null;
        String str5 = null;
        byte[] bArr2 = null;
        int i5 = 0;
        Bundle bundle = null;
        int i6 = 0;
        boolean z = false;
        while (parcel.dataPosition() < k) {
            int j3 = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j3)) {
                case 1:
                    gameEntity = (GameEntity) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j3, GameEntity.CREATOR);
                    break;
                case 2:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j3);
                    break;
                case 3:
                    str2 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j3);
                    break;
                case 4:
                    j = com.google.android.gms.common.internal.safeparcel.a.h(parcel, j3);
                    break;
                case 5:
                    str3 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j3);
                    break;
                case 6:
                    j2 = com.google.android.gms.common.internal.safeparcel.a.h(parcel, j3);
                    break;
                case 7:
                    str4 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j3);
                    break;
                case 8:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j3);
                    break;
                case 10:
                    i3 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j3);
                    break;
                case 11:
                    i4 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j3);
                    break;
                case 12:
                    bArr = com.google.android.gms.common.internal.safeparcel.a.p(parcel, j3);
                    break;
                case 13:
                    arrayList = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j3, ParticipantEntity.CREATOR);
                    break;
                case Status.INTERRUPTED /* 14 */:
                    str5 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j3);
                    break;
                case Status.TIMEOUT /* 15 */:
                    bArr2 = com.google.android.gms.common.internal.safeparcel.a.p(parcel, j3);
                    break;
                case 16:
                    i5 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j3);
                    break;
                case 17:
                    bundle = com.google.android.gms.common.internal.safeparcel.a.o(parcel, j3);
                    break;
                case 18:
                    i6 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j3);
                    break;
                case 19:
                    z = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j3);
                    break;
                case 1000:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j3);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j3);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new TurnBasedMatchEntity(i, gameEntity, str, str2, j, str3, j2, str4, i2, i3, i4, bArr, arrayList, str5, bArr2, i5, bundle, i6, z);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // android.os.Parcelable.Creator
    public TurnBasedMatchEntity[] newArray(int size) {
        return new TurnBasedMatchEntity[size];
    }
}
