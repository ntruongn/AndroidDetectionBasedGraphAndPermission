package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.internal.ee;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class ek extends ee implements SafeParcelable {
    public static final el CREATOR = new el();
    private final int kZ;
    private final String mClassName;
    private final eh nF;
    private final Parcel nN;
    private final int nO;
    private int nP;
    private int nQ;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ek(int i, Parcel parcel, eh ehVar) {
        this.kZ = i;
        this.nN = (Parcel) du.f(parcel);
        this.nO = 2;
        this.nF = ehVar;
        if (this.nF == null) {
            this.mClassName = null;
        } else {
            this.mClassName = this.nF.cg();
        }
        this.nP = 2;
    }

    private ek(SafeParcelable safeParcelable, eh ehVar, String str) {
        this.kZ = 1;
        this.nN = Parcel.obtain();
        safeParcelable.writeToParcel(this.nN, 0);
        this.nO = 1;
        this.nF = (eh) du.f(ehVar);
        this.mClassName = (String) du.f(str);
        this.nP = 2;
    }

    public static <T extends ee & SafeParcelable> ek a(T t) {
        String canonicalName = t.getClass().getCanonicalName();
        return new ek(t, b(t), canonicalName);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private static void a(eh ehVar, ee eeVar) {
        Class<?> cls = eeVar.getClass();
        if (ehVar.b((Class<? extends ee>) cls)) {
            return;
        }
        HashMap<String, ee.a<?, ?>> bQ = eeVar.bQ();
        ehVar.a(cls, eeVar.bQ());
        Iterator<String> it = bQ.keySet().iterator();
        while (it.hasNext()) {
            ee.a<?, ?> aVar = bQ.get(it.next());
            Class<? extends ee> bY = aVar.bY();
            if (bY != null) {
                try {
                    a(ehVar, bY.newInstance());
                } catch (IllegalAccessException e) {
                    throw new IllegalStateException("Could not access object of type " + aVar.bY().getCanonicalName(), e);
                } catch (InstantiationException e2) {
                    throw new IllegalStateException("Could not instantiate an object of type " + aVar.bY().getCanonicalName(), e2);
                }
            }
        }
    }

    private void a(StringBuilder sb, int i, Object obj) {
        switch (i) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                sb.append(obj);
                return;
            case 7:
                sb.append("\"").append(eq.O(obj.toString())).append("\"");
                return;
            case 8:
                sb.append("\"").append(en.b((byte[]) obj)).append("\"");
                return;
            case 9:
                sb.append("\"").append(en.c((byte[]) obj));
                sb.append("\"");
                return;
            case 10:
                er.a(sb, (HashMap) obj);
                return;
            case 11:
                throw new IllegalArgumentException("Method does not accept concrete type.");
            default:
                throw new IllegalArgumentException("Unknown type = " + i);
        }
    }

    private void a(StringBuilder sb, ee.a<?, ?> aVar, Parcel parcel, int i) {
        switch (aVar.bP()) {
            case 0:
                b(sb, aVar, a(aVar, Integer.valueOf(com.google.android.gms.common.internal.safeparcel.a.g(parcel, i))));
                return;
            case 1:
                b(sb, aVar, a(aVar, com.google.android.gms.common.internal.safeparcel.a.i(parcel, i)));
                return;
            case 2:
                b(sb, aVar, a(aVar, Long.valueOf(com.google.android.gms.common.internal.safeparcel.a.h(parcel, i))));
                return;
            case 3:
                b(sb, aVar, a(aVar, Float.valueOf(com.google.android.gms.common.internal.safeparcel.a.j(parcel, i))));
                return;
            case 4:
                b(sb, aVar, a(aVar, Double.valueOf(com.google.android.gms.common.internal.safeparcel.a.k(parcel, i))));
                return;
            case 5:
                b(sb, aVar, a(aVar, com.google.android.gms.common.internal.safeparcel.a.l(parcel, i)));
                return;
            case 6:
                b(sb, aVar, a(aVar, Boolean.valueOf(com.google.android.gms.common.internal.safeparcel.a.c(parcel, i))));
                return;
            case 7:
                b(sb, aVar, a(aVar, com.google.android.gms.common.internal.safeparcel.a.m(parcel, i)));
                return;
            case 8:
            case 9:
                b(sb, aVar, a(aVar, com.google.android.gms.common.internal.safeparcel.a.p(parcel, i)));
                return;
            case 10:
                b(sb, aVar, a(aVar, c(com.google.android.gms.common.internal.safeparcel.a.o(parcel, i))));
                return;
            case 11:
                throw new IllegalArgumentException("Method does not accept concrete type.");
            default:
                throw new IllegalArgumentException("Unknown field out type = " + aVar.bP());
        }
    }

    private void a(StringBuilder sb, String str, ee.a<?, ?> aVar, Parcel parcel, int i) {
        sb.append("\"").append(str).append("\":");
        if (aVar.ca()) {
            a(sb, aVar, parcel, i);
        } else {
            b(sb, aVar, parcel, i);
        }
    }

    private void a(StringBuilder sb, HashMap<String, ee.a<?, ?>> hashMap, Parcel parcel) {
        HashMap<Integer, Map.Entry<String, ee.a<?, ?>>> c = c(hashMap);
        sb.append('{');
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        boolean z = false;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            Map.Entry<String, ee.a<?, ?>> entry = c.get(Integer.valueOf(com.google.android.gms.common.internal.safeparcel.a.A(j)));
            if (entry != null) {
                if (z) {
                    sb.append(",");
                }
                a(sb, entry.getKey(), entry.getValue(), parcel, j);
                z = true;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        sb.append('}');
    }

    private static eh b(ee eeVar) {
        eh ehVar = new eh(eeVar.getClass());
        a(ehVar, eeVar);
        ehVar.ce();
        ehVar.cd();
        return ehVar;
    }

    private void b(StringBuilder sb, ee.a<?, ?> aVar, Parcel parcel, int i) {
        if (aVar.bV()) {
            sb.append("[");
            switch (aVar.bP()) {
                case 0:
                    em.a(sb, com.google.android.gms.common.internal.safeparcel.a.r(parcel, i));
                    break;
                case 1:
                    em.a(sb, com.google.android.gms.common.internal.safeparcel.a.t(parcel, i));
                    break;
                case 2:
                    em.a(sb, com.google.android.gms.common.internal.safeparcel.a.s(parcel, i));
                    break;
                case 3:
                    em.a(sb, com.google.android.gms.common.internal.safeparcel.a.u(parcel, i));
                    break;
                case 4:
                    em.a(sb, com.google.android.gms.common.internal.safeparcel.a.v(parcel, i));
                    break;
                case 5:
                    em.a(sb, com.google.android.gms.common.internal.safeparcel.a.w(parcel, i));
                    break;
                case 6:
                    em.a(sb, com.google.android.gms.common.internal.safeparcel.a.q(parcel, i));
                    break;
                case 7:
                    em.a(sb, com.google.android.gms.common.internal.safeparcel.a.x(parcel, i));
                    break;
                case 8:
                case 9:
                case 10:
                    throw new UnsupportedOperationException("List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported");
                case 11:
                    Parcel[] A = com.google.android.gms.common.internal.safeparcel.a.A(parcel, i);
                    int length = A.length;
                    for (int i2 = 0; i2 < length; i2++) {
                        if (i2 > 0) {
                            sb.append(",");
                        }
                        A[i2].setDataPosition(0);
                        a(sb, aVar.cc(), A[i2]);
                    }
                    break;
                default:
                    throw new IllegalStateException("Unknown field type out.");
            }
            sb.append("]");
            return;
        }
        switch (aVar.bP()) {
            case 0:
                sb.append(com.google.android.gms.common.internal.safeparcel.a.g(parcel, i));
                return;
            case 1:
                sb.append(com.google.android.gms.common.internal.safeparcel.a.i(parcel, i));
                return;
            case 2:
                sb.append(com.google.android.gms.common.internal.safeparcel.a.h(parcel, i));
                return;
            case 3:
                sb.append(com.google.android.gms.common.internal.safeparcel.a.j(parcel, i));
                return;
            case 4:
                sb.append(com.google.android.gms.common.internal.safeparcel.a.k(parcel, i));
                return;
            case 5:
                sb.append(com.google.android.gms.common.internal.safeparcel.a.l(parcel, i));
                return;
            case 6:
                sb.append(com.google.android.gms.common.internal.safeparcel.a.c(parcel, i));
                return;
            case 7:
                sb.append("\"").append(eq.O(com.google.android.gms.common.internal.safeparcel.a.m(parcel, i))).append("\"");
                return;
            case 8:
                sb.append("\"").append(en.b(com.google.android.gms.common.internal.safeparcel.a.p(parcel, i))).append("\"");
                return;
            case 9:
                sb.append("\"").append(en.c(com.google.android.gms.common.internal.safeparcel.a.p(parcel, i)));
                sb.append("\"");
                return;
            case 10:
                Bundle o = com.google.android.gms.common.internal.safeparcel.a.o(parcel, i);
                Set<String> keySet = o.keySet();
                keySet.size();
                sb.append("{");
                boolean z = true;
                for (String str : keySet) {
                    if (!z) {
                        sb.append(",");
                    }
                    sb.append("\"").append(str).append("\"");
                    sb.append(":");
                    sb.append("\"").append(eq.O(o.getString(str))).append("\"");
                    z = false;
                }
                sb.append("}");
                return;
            case 11:
                Parcel z2 = com.google.android.gms.common.internal.safeparcel.a.z(parcel, i);
                z2.setDataPosition(0);
                a(sb, aVar.cc(), z2);
                return;
            default:
                throw new IllegalStateException("Unknown field type out");
        }
    }

    private void b(StringBuilder sb, ee.a<?, ?> aVar, Object obj) {
        if (aVar.bU()) {
            b(sb, aVar, (ArrayList<?>) obj);
        } else {
            a(sb, aVar.bO(), obj);
        }
    }

    private void b(StringBuilder sb, ee.a<?, ?> aVar, ArrayList<?> arrayList) {
        sb.append("[");
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (i != 0) {
                sb.append(",");
            }
            a(sb, aVar.bO(), arrayList.get(i));
        }
        sb.append("]");
    }

    public static HashMap<String, String> c(Bundle bundle) {
        HashMap<String, String> hashMap = new HashMap<>();
        for (String str : bundle.keySet()) {
            hashMap.put(str, bundle.getString(str));
        }
        return hashMap;
    }

    private static HashMap<Integer, Map.Entry<String, ee.a<?, ?>>> c(HashMap<String, ee.a<?, ?>> hashMap) {
        HashMap<Integer, Map.Entry<String, ee.a<?, ?>>> hashMap2 = new HashMap<>();
        for (Map.Entry<String, ee.a<?, ?>> entry : hashMap.entrySet()) {
            hashMap2.put(Integer.valueOf(entry.getValue().bX()), entry);
        }
        return hashMap2;
    }

    @Override // com.google.android.gms.internal.ee
    protected Object J(String str) {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    @Override // com.google.android.gms.internal.ee
    protected boolean K(String str) {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    @Override // com.google.android.gms.internal.ee
    public HashMap<String, ee.a<?, ?>> bQ() {
        if (this.nF == null) {
            return null;
        }
        return this.nF.N(this.mClassName);
    }

    public Parcel ci() {
        switch (this.nP) {
            case 0:
                this.nQ = com.google.android.gms.common.internal.safeparcel.b.l(this.nN);
                com.google.android.gms.common.internal.safeparcel.b.D(this.nN, this.nQ);
                this.nP = 2;
                break;
            case 1:
                com.google.android.gms.common.internal.safeparcel.b.D(this.nN, this.nQ);
                this.nP = 2;
                break;
        }
        return this.nN;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public eh cj() {
        switch (this.nO) {
            case 0:
                return null;
            case 1:
                return this.nF;
            case 2:
                return this.nF;
            default:
                throw new IllegalStateException("Invalid creation type: " + this.nO);
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        el elVar = CREATOR;
        return 0;
    }

    public int getVersionCode() {
        return this.kZ;
    }

    @Override // com.google.android.gms.internal.ee
    public String toString() {
        du.c(this.nF, "Cannot convert to JSON on client side.");
        Parcel ci = ci();
        ci.setDataPosition(0);
        StringBuilder sb = new StringBuilder(100);
        a(sb, this.nF.N(this.mClassName), ci);
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        el elVar = CREATOR;
        el.a(this, out, flags);
    }
}
