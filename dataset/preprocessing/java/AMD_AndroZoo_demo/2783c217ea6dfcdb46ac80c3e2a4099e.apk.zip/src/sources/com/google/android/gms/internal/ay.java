package com.google.android.gms.internal;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ay {
    public final int fZ;
    public final at ga;
    public final bc gb;
    public final String gc;
    public final aw gd;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface a {
        void f(int i);
    }

    public ay(int i) {
        this(null, null, null, null, i);
    }

    public ay(at atVar, bc bcVar, String str, aw awVar, int i) {
        this.ga = atVar;
        this.gb = bcVar;
        this.gc = str;
        this.gd = awVar;
        this.fZ = i;
    }
}
