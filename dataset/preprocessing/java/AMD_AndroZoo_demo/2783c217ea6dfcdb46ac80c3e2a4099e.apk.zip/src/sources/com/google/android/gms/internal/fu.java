package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.location.LocationRequest;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class fu implements SafeParcelable {
    public static final fv CREATOR = new fv();
    final int kZ;
    private final LocationRequest ui;
    private final fs uj;

    public fu(int i, LocationRequest locationRequest, fs fsVar) {
        this.kZ = i;
        this.ui = locationRequest;
        this.uj = fsVar;
    }

    public LocationRequest dA() {
        return this.ui;
    }

    public fs dB() {
        return this.uj;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        fv fvVar = CREATOR;
        return 0;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof fu)) {
            return false;
        }
        fu fuVar = (fu) object;
        return this.ui.equals(fuVar.ui) && this.uj.equals(fuVar.uj);
    }

    public int hashCode() {
        return ds.hashCode(this.ui, this.uj);
    }

    public String toString() {
        return ds.e(this).a("locationRequest", this.ui).a("filter", this.uj).toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int flags) {
        fv fvVar = CREATOR;
        fv.a(this, parcel, flags);
    }
}
