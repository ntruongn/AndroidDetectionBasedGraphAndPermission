package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.google.android.gms.ads.AdActivity;
import com.google.android.gms.internal.bs;
import com.google.android.gms.internal.cw;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class bk extends bs.a {
    private RelativeLayout gB;
    private final Activity gr;
    private bm gs;
    private bo gt;
    private cv gu;
    private b gv;
    private bp gw;
    private FrameLayout gx;
    private WebChromeClient.CustomViewCallback gy;
    private boolean gz = false;
    private boolean gA = false;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a extends Exception {
        public a(String str) {
            super(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class b {
        public final ViewGroup.LayoutParams gD;
        public final ViewGroup gE;
        public final int index;

        public b(cv cvVar) throws a {
            this.gD = cvVar.getLayoutParams();
            ViewParent parent = cvVar.getParent();
            if (!(parent instanceof ViewGroup)) {
                throw new a("Could not get the parent of the WebView for an overlay.");
            }
            this.gE = (ViewGroup) parent;
            this.index = this.gE.indexOfChild(cvVar);
            this.gE.removeView(cvVar);
            cvVar.l(true);
        }
    }

    public bk(Activity activity) {
        this.gr = activity;
    }

    private void Z() {
        if (!this.gr.isFinishing() || this.gA) {
            return;
        }
        this.gA = true;
        if (this.gr.isFinishing()) {
            if (this.gu != null) {
                this.gu.ay();
                this.gB.removeView(this.gu);
                if (this.gv != null) {
                    this.gu.l(false);
                    this.gv.gE.addView(this.gu, this.gv.index, this.gv.gD);
                }
            }
            if (this.gs == null || this.gs.gH == null) {
                return;
            }
            this.gs.gH.A();
        }
    }

    private static RelativeLayout.LayoutParams a(int i, int i2, int i3, int i4) {
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i3, i4);
        layoutParams.setMargins(i, i2, 0, 0);
        layoutParams.addRule(10);
        layoutParams.addRule(9);
        return layoutParams;
    }

    public static void a(Context context, bm bmVar) {
        Intent intent = new Intent();
        intent.setClassName(context, AdActivity.CLASS_NAME);
        intent.putExtra("com.google.android.gms.ads.internal.overlay.useClientJar", bmVar.ej.iI);
        bm.a(intent, bmVar);
        intent.addFlags(524288);
        context.startActivity(intent);
    }

    private void h(boolean z) throws a {
        this.gr.requestWindowFeature(1);
        Window window = this.gr.getWindow();
        window.setFlags(1024, 1024);
        setRequestedOrientation(this.gs.orientation);
        if (Build.VERSION.SDK_INT >= 11) {
            cs.r("Enabling hardware acceleration on the AdActivity window.");
            co.a(window);
        }
        this.gB = new RelativeLayout(this.gr);
        this.gB.setBackgroundColor(-16777216);
        this.gr.setContentView(this.gB);
        boolean aI = this.gs.gI.aB().aI();
        if (z) {
            this.gu = cv.a(this.gr, this.gs.gI.y(), true, aI, null, this.gs.ej);
            this.gu.aB().a(null, null, this.gs.gJ, this.gs.gN, true);
            this.gu.aB().a(new cw.a() { // from class: com.google.android.gms.internal.bk.1
                @Override // com.google.android.gms.internal.cw.a
                public void a(cv cvVar) {
                    cvVar.az();
                }
            });
            if (this.gs.gn != null) {
                this.gu.loadUrl(this.gs.gn);
            } else {
                if (this.gs.gM == null) {
                    throw new a("No URL or HTML to display in ad overlay.");
                }
                this.gu.loadDataWithBaseURL(this.gs.gK, this.gs.gM, "text/html", "UTF-8", null);
            }
        } else {
            this.gu = this.gs.gI;
            this.gu.setContext(this.gr);
        }
        this.gu.a(this);
        this.gB.addView(this.gu, -1, -1);
        if (!z) {
            this.gu.az();
        }
        f(aI);
    }

    public bo W() {
        return this.gt;
    }

    public void X() {
        if (this.gs != null) {
            setRequestedOrientation(this.gs.orientation);
        }
        if (this.gx != null) {
            this.gr.setContentView(this.gB);
            this.gx.removeAllViews();
            this.gx = null;
        }
        if (this.gy != null) {
            this.gy.onCustomViewHidden();
            this.gy = null;
        }
    }

    public void Y() {
        this.gB.removeView(this.gw);
        f(true);
    }

    public void a(View view, WebChromeClient.CustomViewCallback customViewCallback) {
        this.gx = new FrameLayout(this.gr);
        this.gx.setBackgroundColor(-16777216);
        this.gx.addView(view, -1, -1);
        this.gr.setContentView(this.gx);
        this.gy = customViewCallback;
    }

    public void b(int i, int i2, int i3, int i4) {
        if (this.gt != null) {
            this.gt.setLayoutParams(a(i, i2, i3, i4));
        }
    }

    public void c(int i, int i2, int i3, int i4) {
        if (this.gt == null) {
            this.gt = new bo(this.gr, this.gu);
            this.gB.addView(this.gt, 0, a(i, i2, i3, i4));
            this.gu.aB().m(false);
        }
    }

    public void close() {
        this.gr.finish();
    }

    public void f(boolean z) {
        this.gw = new bp(this.gr, z ? 50 : 32);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(10);
        layoutParams.addRule(z ? 11 : 9);
        this.gw.g(this.gs.gL);
        this.gB.addView(this.gw, layoutParams);
    }

    public void g(boolean z) {
        if (this.gw != null) {
            this.gw.g(z);
        }
    }

    @Override // com.google.android.gms.internal.bs
    public void onCreate(Bundle savedInstanceState) {
        this.gz = savedInstanceState != null ? savedInstanceState.getBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", false) : false;
        try {
            this.gs = bm.a(this.gr.getIntent());
            if (this.gs == null) {
                throw new a("Could not get info for ad overlay.");
            }
            if (savedInstanceState == null) {
                if (this.gs.gH != null) {
                    this.gs.gH.B();
                }
                if (this.gs.gO != 1 && this.gs.gG != null) {
                    this.gs.gG.w();
                }
            }
            switch (this.gs.gO) {
                case 1:
                    h(false);
                    return;
                case 2:
                    this.gv = new b(this.gs.gI);
                    h(false);
                    return;
                case 3:
                    h(true);
                    return;
                case 4:
                    if (this.gz) {
                        this.gr.finish();
                        return;
                    } else {
                        if (bh.a(this.gr, this.gs.gF, this.gs.gN)) {
                            return;
                        }
                        this.gr.finish();
                        return;
                    }
                default:
                    throw new a("Could not determine ad overlay type.");
            }
        } catch (a e) {
            cs.v(e.getMessage());
            this.gr.finish();
        }
    }

    @Override // com.google.android.gms.internal.bs
    public void onDestroy() {
        if (this.gt != null) {
            this.gt.destroy();
        }
        if (this.gu != null) {
            this.gB.removeView(this.gu);
        }
        Z();
    }

    @Override // com.google.android.gms.internal.bs
    public void onPause() {
        if (this.gt != null) {
            this.gt.pause();
        }
        X();
        if (this.gu != null && (!this.gr.isFinishing() || this.gv == null)) {
            cn.a(this.gu);
        }
        Z();
    }

    @Override // com.google.android.gms.internal.bs
    public void onRestart() {
    }

    @Override // com.google.android.gms.internal.bs
    public void onResume() {
        if (this.gs != null && this.gs.gO == 4) {
            if (this.gz) {
                this.gr.finish();
            } else {
                this.gz = true;
            }
        }
        if (this.gu != null) {
            cn.b(this.gu);
        }
    }

    @Override // com.google.android.gms.internal.bs
    public void onSaveInstanceState(Bundle outBundle) {
        outBundle.putBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", this.gz);
    }

    @Override // com.google.android.gms.internal.bs
    public void onStart() {
    }

    @Override // com.google.android.gms.internal.bs
    public void onStop() {
        Z();
    }

    public void setRequestedOrientation(int requestedOrientation) {
        this.gr.setRequestedOrientation(requestedOrientation);
    }
}
