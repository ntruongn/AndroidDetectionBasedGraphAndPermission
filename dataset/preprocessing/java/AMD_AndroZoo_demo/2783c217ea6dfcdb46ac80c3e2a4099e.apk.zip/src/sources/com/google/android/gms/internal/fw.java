package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.games.GamesClient;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class fw implements SafeParcelable {
    final int kZ;
    final String wF;
    public static final fw uk = ab("accounting");
    public static final fw ul = ab("airport");
    public static final fw um = ab("amusement_park");
    public static final fw un = ab("aquarium");
    public static final fw uo = ab("art_gallery");
    public static final fw up = ab("atm");
    public static final fw uq = ab("bakery");
    public static final fw ur = ab("bank");
    public static final fw us = ab("bar");
    public static final fw ut = ab("beauty_salon");
    public static final fw uu = ab("bicycle_store");
    public static final fw uv = ab("book_store");
    public static final fw uw = ab("bowling_alley");
    public static final fw ux = ab("bus_station");
    public static final fw uy = ab("cafe");
    public static final fw uz = ab("campground");
    public static final fw uA = ab("car_dealer");
    public static final fw uB = ab("car_rental");
    public static final fw uC = ab("car_repair");
    public static final fw uD = ab("car_wash");
    public static final fw uE = ab("casino");
    public static final fw uF = ab("cemetary");
    public static final fw uG = ab("church");
    public static final fw uH = ab("city_hall");
    public static final fw uI = ab("clothing_store");
    public static final fw uJ = ab("convenience_store");
    public static final fw uK = ab("courthouse");
    public static final fw uL = ab("dentist");
    public static final fw uM = ab("department_store");
    public static final fw uN = ab("doctor");
    public static final fw uO = ab("electrician");
    public static final fw uP = ab("electronics_store");
    public static final fw uQ = ab("embassy");
    public static final fw uR = ab("establishment");
    public static final fw uS = ab("finance");
    public static final fw uT = ab("fire_station");
    public static final fw uU = ab("florist");
    public static final fw uV = ab("food");
    public static final fw uW = ab("funeral_home");
    public static final fw uX = ab("furniture_store");
    public static final fw uY = ab("gas_station");
    public static final fw uZ = ab("general_contractor");
    public static final fw va = ab("grocery_or_supermarket");
    public static final fw vb = ab("gym");
    public static final fw vc = ab("hair_care");
    public static final fw vd = ab("hardware_store");
    public static final fw ve = ab("health");
    public static final fw vf = ab("hindu_temple");
    public static final fw vg = ab("home_goods_store");
    public static final fw vh = ab("hospital");
    public static final fw vi = ab("insurance_agency");
    public static final fw vj = ab("jewelry_store");
    public static final fw vk = ab("laundry");
    public static final fw vl = ab("lawyer");
    public static final fw vm = ab("library");
    public static final fw vn = ab("liquor_store");
    public static final fw vo = ab("local_government_office");
    public static final fw vp = ab("locksmith");
    public static final fw vq = ab("lodging");
    public static final fw vr = ab("meal_delivery");
    public static final fw vs = ab("meal_takeaway");
    public static final fw vt = ab("mosque");
    public static final fw vu = ab("movie_rental");
    public static final fw vv = ab("movie_theater");
    public static final fw vw = ab("moving_company");
    public static final fw vx = ab("museum");
    public static final fw vy = ab("night_club");
    public static final fw vz = ab("painter");
    public static final fw vA = ab("park");
    public static final fw vB = ab("parking");
    public static final fw vC = ab("pet_store");
    public static final fw vD = ab("pharmacy");
    public static final fw vE = ab("physiotherapist");
    public static final fw vF = ab("place_of_worship");
    public static final fw vG = ab("plumber");
    public static final fw vH = ab("police");
    public static final fw vI = ab("post_office");
    public static final fw vJ = ab("real_estate_agency");
    public static final fw vK = ab("restaurant");
    public static final fw vL = ab("roofing_contractor");
    public static final fw vM = ab("rv_park");
    public static final fw vN = ab("school");
    public static final fw vO = ab("shoe_store");
    public static final fw vP = ab("shopping_mall");
    public static final fw vQ = ab("spa");
    public static final fw vR = ab("stadium");
    public static final fw vS = ab("storage");
    public static final fw vT = ab("store");
    public static final fw vU = ab("subway_station");
    public static final fw vV = ab("synagogue");
    public static final fw vW = ab("taxi_stand");
    public static final fw vX = ab("train_station");
    public static final fw vY = ab("travel_agency");
    public static final fw vZ = ab("university");
    public static final fw wa = ab("veterinary_care");
    public static final fw wb = ab("zoo");
    public static final fw wc = ab("administrative_area_level_1");
    public static final fw wd = ab("administrative_area_level_2");
    public static final fw we = ab("administrative_area_level_3");
    public static final fw wf = ab("colloquial_area");
    public static final fw wg = ab(com.huprya.wqkqze112375.g.COUNTRY);
    public static final fw wh = ab("floor");
    public static final fw wi = ab("geocode");
    public static final fw wj = ab("intersection");
    public static final fw wk = ab("locality");
    public static final fw wl = ab("natural_feature");
    public static final fw wm = ab("neighborhood");
    public static final fw wn = ab("political");
    public static final fw wo = ab("point_of_interest");
    public static final fw wp = ab("post_box");
    public static final fw wq = ab("postal_code");
    public static final fw wr = ab("postal_code_prefix");
    public static final fw ws = ab("postal_town");
    public static final fw wt = ab("premise");
    public static final fw wu = ab(GamesClient.EXTRA_ROOM);
    public static final fw wv = ab("route");
    public static final fw ww = ab("street_address");
    public static final fw wx = ab("sublocality");
    public static final fw wy = ab("sublocality_level_1");
    public static final fw wz = ab("sublocality_level_2");
    public static final fw wA = ab("sublocality_level_3");
    public static final fw wB = ab("sublocality_level_4");
    public static final fw wC = ab("sublocality_level_5");
    public static final fw wD = ab("subpremise");
    public static final fw wE = ab("transit_station");
    public static final fx CREATOR = new fx();

    /* JADX INFO: Access modifiers changed from: package-private */
    public fw(int i, String str) {
        du.I(str);
        this.kZ = i;
        this.wF = str;
    }

    public static fw ab(String str) {
        return new fw(0, str);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        fx fxVar = CREATOR;
        return 0;
    }

    public boolean equals(Object o) {
        return (o instanceof fw) && this.wF.equals(((fw) o).wF);
    }

    public int hashCode() {
        return this.wF.hashCode();
    }

    public String toString() {
        return this.wF;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int flags) {
        fx fxVar = CREATOR;
        fx.a(this, parcel, flags);
    }
}
