package com.google.android.gms.common.data;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class c<T extends SafeParcelable> extends DataBuffer<T> {
    private static final String[] lf = {"data"};
    private final Parcelable.Creator<T> lg;

    public c(DataHolder dataHolder, Parcelable.Creator<T> creator) {
        super(dataHolder);
        this.lg = creator;
    }

    @Override // com.google.android.gms.common.data.DataBuffer
    /* renamed from: s, reason: merged with bridge method [inline-methods] */
    public T get(int i) {
        byte[] byteArray = this.lb.getByteArray("data", i, 0);
        Parcel obtain = Parcel.obtain();
        obtain.unmarshall(byteArray, 0, byteArray.length);
        obtain.setDataPosition(0);
        T createFromParcel = this.lg.createFromParcel(obtain);
        obtain.recycle();
        return createFromParcel;
    }
}
