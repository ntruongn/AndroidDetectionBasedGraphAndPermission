package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class fo implements Parcelable.Creator<fn> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(fn fnVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 1, fnVar.getRequestId(), false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1000, fnVar.getVersionCode());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, fnVar.getExpirationTime());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, fnVar.ds());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 4, fnVar.getLatitude());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, fnVar.getLongitude());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 6, fnVar.dt());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 7, fnVar.du());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 8, fnVar.getNotificationResponsiveness());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 9, fnVar.dv());
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aG, reason: merged with bridge method [inline-methods] */
    public fn[] newArray(int i) {
        return new fn[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aa, reason: merged with bridge method [inline-methods] */
    public fn createFromParcel(Parcel parcel) {
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        String str = null;
        int i2 = 0;
        short s = 0;
        double d = 0.0d;
        double d2 = 0.0d;
        float f = BitmapDescriptorFactory.HUE_RED;
        long j = 0;
        int i3 = 0;
        int i4 = -1;
        while (parcel.dataPosition() < k) {
            int j2 = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j2)) {
                case 1:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j2);
                    break;
                case 2:
                    j = com.google.android.gms.common.internal.safeparcel.a.h(parcel, j2);
                    break;
                case 3:
                    s = com.google.android.gms.common.internal.safeparcel.a.f(parcel, j2);
                    break;
                case 4:
                    d = com.google.android.gms.common.internal.safeparcel.a.k(parcel, j2);
                    break;
                case 5:
                    d2 = com.google.android.gms.common.internal.safeparcel.a.k(parcel, j2);
                    break;
                case 6:
                    f = com.google.android.gms.common.internal.safeparcel.a.j(parcel, j2);
                    break;
                case 7:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j2);
                    break;
                case 8:
                    i3 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j2);
                    break;
                case 9:
                    i4 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j2);
                    break;
                case 1000:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j2);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j2);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new fn(i, str, i2, s, d, d2, f, j, i3, i4);
    }
}
