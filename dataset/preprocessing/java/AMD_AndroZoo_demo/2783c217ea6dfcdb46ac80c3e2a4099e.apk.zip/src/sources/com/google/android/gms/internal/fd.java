package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.view.Display;
import android.view.View;
import android.view.ViewTreeObserver;
import java.lang.ref.WeakReference;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class fd {
    protected ex qm;
    protected a rG;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a {
        public int bottom;
        public int gravity;
        public int left;
        public IBinder rH;
        public int rI;
        public int right;
        public int top;

        private a(int i, IBinder iBinder) {
            this.rI = -1;
            this.left = 0;
            this.top = 0;
            this.right = 0;
            this.bottom = 0;
            this.gravity = i;
            this.rH = iBinder;
        }

        public Bundle dc() {
            Bundle bundle = new Bundle();
            bundle.putInt("popupLocationInfo.gravity", this.gravity);
            bundle.putInt("popupLocationInfo.displayId", this.rI);
            bundle.putInt("popupLocationInfo.left", this.left);
            bundle.putInt("popupLocationInfo.top", this.top);
            bundle.putInt("popupLocationInfo.right", this.right);
            bundle.putInt("popupLocationInfo.bottom", this.bottom);
            return bundle;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private static final class b extends fd implements View.OnAttachStateChangeListener, ViewTreeObserver.OnGlobalLayoutListener {
        private boolean qR;
        private WeakReference<View> rJ;

        protected b(ex exVar, int i) {
            super(exVar, i);
            this.qR = false;
        }

        private void f(View view) {
            Display display;
            int i = -1;
            if (es.cp() && (display = view.getDisplay()) != null) {
                i = display.getDisplayId();
            }
            IBinder windowToken = view.getWindowToken();
            int[] iArr = new int[2];
            view.getLocationInWindow(iArr);
            int width = view.getWidth();
            int height = view.getHeight();
            this.rG.rI = i;
            this.rG.rH = windowToken;
            this.rG.left = iArr[0];
            this.rG.top = iArr[1];
            this.rG.right = iArr[0] + width;
            this.rG.bottom = iArr[1] + height;
            if (this.qR) {
                cZ();
                this.qR = false;
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // com.google.android.gms.internal.fd
        protected void as(int i) {
            this.rG = new a(i, null);
        }

        @Override // com.google.android.gms.internal.fd
        public void cZ() {
            if (this.rG.rH != null) {
                super.cZ();
            } else {
                this.qR = this.rJ != null;
            }
        }

        @Override // com.google.android.gms.internal.fd
        public void e(View view) {
            this.qm.cN();
            if (this.rJ != null) {
                View view2 = this.rJ.get();
                Context context = this.qm.getContext();
                if (view2 == null && (context instanceof Activity)) {
                    view2 = ((Activity) context).getWindow().getDecorView();
                }
                if (view2 != null) {
                    view2.removeOnAttachStateChangeListener(this);
                    ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
                    if (es.co()) {
                        viewTreeObserver.removeOnGlobalLayoutListener(this);
                    } else {
                        viewTreeObserver.removeGlobalOnLayoutListener(this);
                    }
                }
            }
            this.rJ = null;
            Context context2 = this.qm.getContext();
            if (view == null && (context2 instanceof Activity)) {
                View findViewById = ((Activity) context2).findViewById(16908290);
                if (findViewById == null) {
                    findViewById = ((Activity) context2).getWindow().getDecorView();
                }
                fa.a("PopupManager", "You have not specified a View to use as content view for popups. Falling back to the Activity content view which may not work properly in future versions of the API. Use setViewForPopups() to set your content view.");
                view = findViewById;
            }
            if (view == null) {
                fa.b("PopupManager", "No content view usable to display popups. Popups will not be displayed in response to this client's calls. Use setViewForPopups() to set your content view.");
                return;
            }
            f(view);
            this.rJ = new WeakReference<>(view);
            view.addOnAttachStateChangeListener(this);
            view.getViewTreeObserver().addOnGlobalLayoutListener(this);
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            View view;
            if (this.rJ == null || (view = this.rJ.get()) == null) {
                return;
            }
            f(view);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View v) {
            f(v);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View v) {
            this.qm.cN();
            v.removeOnAttachStateChangeListener(this);
        }
    }

    private fd(ex exVar, int i) {
        this.qm = exVar;
        as(i);
    }

    public static fd a(ex exVar, int i) {
        return es.cl() ? new b(exVar, i) : new fd(exVar, i);
    }

    protected void as(int i) {
        this.rG = new a(i, new Binder());
    }

    public void cZ() {
        this.qm.a(this.rG.rH, this.rG.dc());
    }

    public Bundle da() {
        return this.rG.dc();
    }

    public IBinder db() {
        return this.rG.rH;
    }

    public void e(View view) {
    }

    public void setGravity(int gravity) {
        this.rG.gravity = gravity;
    }
}
