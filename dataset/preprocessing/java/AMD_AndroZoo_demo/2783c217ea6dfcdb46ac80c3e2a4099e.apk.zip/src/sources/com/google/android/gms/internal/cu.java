package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class cu implements Parcelable.Creator<ct> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(ct ctVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, ctVar.versionCode);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, ctVar.iF, false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 3, ctVar.iG);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 4, ctVar.iH);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, ctVar.iI);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: h, reason: merged with bridge method [inline-methods] */
    public ct createFromParcel(Parcel parcel) {
        boolean z = false;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        String str = null;
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i3 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 2:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    break;
                case 3:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 4:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 5:
                    z = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new ct(i3, str, i2, i, z);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: o, reason: merged with bridge method [inline-methods] */
    public ct[] newArray(int i) {
        return new ct[i];
    }
}
