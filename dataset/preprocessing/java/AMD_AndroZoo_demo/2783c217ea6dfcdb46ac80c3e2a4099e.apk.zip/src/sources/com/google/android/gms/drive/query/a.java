package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.query.internal.LogicalFilter;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class a implements Parcelable.Creator<Query> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(Query query, Parcel parcel, int i) {
        int l = b.l(parcel);
        b.c(parcel, 1000, query.kZ);
        b.a(parcel, 1, (Parcelable) query.pc, i, false);
        b.a(parcel, 3, query.pd, false);
        b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: M, reason: merged with bridge method [inline-methods] */
    public Query createFromParcel(Parcel parcel) {
        String m;
        LogicalFilter logicalFilter;
        int i;
        String str = null;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i2 = 0;
        LogicalFilter logicalFilter2 = null;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    LogicalFilter logicalFilter3 = (LogicalFilter) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, LogicalFilter.CREATOR);
                    i = i2;
                    m = str;
                    logicalFilter = logicalFilter3;
                    break;
                case 3:
                    m = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    logicalFilter = logicalFilter2;
                    i = i2;
                    break;
                case 1000:
                    String str2 = str;
                    logicalFilter = logicalFilter2;
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    m = str2;
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    m = str;
                    logicalFilter = logicalFilter2;
                    i = i2;
                    break;
            }
            i2 = i;
            logicalFilter2 = logicalFilter;
            str = m;
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new Query(i2, logicalFilter2, str);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: ad, reason: merged with bridge method [inline-methods] */
    public Query[] newArray(int i) {
        return new Query[i];
    }
}
