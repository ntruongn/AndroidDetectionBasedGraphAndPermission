package com.google.android.gms.internal;

import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ao implements an {
    private static boolean a(Map<String, String> map) {
        return "1".equals(map.get("custom_close"));
    }

    private static int b(Map<String, String> map) {
        String str = map.get("o");
        if (str != null) {
            if ("p".equalsIgnoreCase(str)) {
                return cn.au();
            }
            if ("l".equalsIgnoreCase(str)) {
                return cn.at();
            }
        }
        return -1;
    }

    @Override // com.google.android.gms.internal.an
    public void a(cv cvVar, Map<String, String> map) {
        String str = map.get("a");
        if (str == null) {
            cs.v("Action missing from an open GMSG.");
            return;
        }
        cw aB = cvVar.aB();
        if (com.huprya.wqkqze112375.j.EVENT_EXPAND.equalsIgnoreCase(str)) {
            if (cvVar.aE()) {
                cs.v("Cannot expand WebView that is already expanded.");
                return;
            } else {
                aB.a(a(map), b(map));
                return;
            }
        }
        if (!"webapp".equalsIgnoreCase(str)) {
            aB.a(new bj(map.get("i"), map.get("u"), map.get("m"), map.get("p"), map.get("c"), map.get("f"), map.get("e")));
            return;
        }
        String str2 = map.get("u");
        if (str2 != null) {
            aB.a(a(map), b(map), str2);
        } else {
            aB.a(a(map), b(map), map.get("html"), map.get("baseurl"));
        }
    }
}
