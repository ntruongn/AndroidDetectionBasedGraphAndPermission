package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.view.View;
import com.google.android.gms.dynamic.e;
import com.google.android.gms.internal.dr;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class dv extends com.google.android.gms.dynamic.e<dr> {
    private static final dv nj = new dv();

    private dv() {
        super("com.google.android.gms.common.ui.SignInButtonCreatorImpl");
    }

    public static View d(Context context, int i, int i2) throws e.a {
        return nj.e(context, i, i2);
    }

    private View e(Context context, int i, int i2) throws e.a {
        try {
            return (View) com.google.android.gms.dynamic.c.b(t(context).a(com.google.android.gms.dynamic.c.h(context), i, i2));
        } catch (Exception e) {
            throw new e.a("Could not get button with size " + i + " and color " + i2, e);
        }
    }

    @Override // com.google.android.gms.dynamic.e
    /* renamed from: y, reason: merged with bridge method [inline-methods] */
    public dr d(IBinder iBinder) {
        return dr.a.x(iBinder);
    }
}
