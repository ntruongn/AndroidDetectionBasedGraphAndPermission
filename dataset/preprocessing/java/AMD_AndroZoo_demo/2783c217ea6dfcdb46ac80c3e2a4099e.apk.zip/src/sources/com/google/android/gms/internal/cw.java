package com.google.android.gms.internal;

import android.net.Uri;
import android.net.UrlQuerySanitizer;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class cw extends WebViewClient {
    private al fm;
    protected final cv gu;
    private q iS;
    private bn iT;
    private a iU;
    private boolean iW;
    private bq iX;
    private final HashMap<String, an> iR = new HashMap<>();
    private final Object fx = new Object();
    private boolean iV = false;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface a {
        void a(cv cvVar);
    }

    public cw(cv cvVar, boolean z) {
        this.gu = cvVar;
        this.iW = z;
    }

    private void a(bm bmVar) {
        bk.a(this.gu.getContext(), bmVar);
    }

    private static boolean b(Uri uri) {
        String scheme = uri.getScheme();
        return "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme);
    }

    private void c(Uri uri) {
        String path = uri.getPath();
        an anVar = this.iR.get(path);
        if (anVar == null) {
            cs.v("No GMSG handler found for GMSG: " + uri);
            return;
        }
        HashMap hashMap = new HashMap();
        UrlQuerySanitizer urlQuerySanitizer = new UrlQuerySanitizer();
        urlQuerySanitizer.setAllowUnregisteredParamaters(true);
        urlQuerySanitizer.setUnregisteredParameterValueSanitizer(UrlQuerySanitizer.getAllButNulLegal());
        urlQuerySanitizer.parseUrl(uri.toString());
        for (UrlQuerySanitizer.ParameterValuePair parameterValuePair : urlQuerySanitizer.getParameterList()) {
            hashMap.put(parameterValuePair.mParameter, parameterValuePair.mValue);
        }
        if (cs.n(2)) {
            cs.u("Received GMSG: " + path);
            for (String str : hashMap.keySet()) {
                cs.u("  " + str + ": " + ((String) hashMap.get(str)));
            }
        }
        anVar.a(this.gu, hashMap);
    }

    public final void Y() {
        synchronized (this.fx) {
            this.iV = false;
            this.iW = true;
            final bk aA = this.gu.aA();
            if (aA != null) {
                if (cr.ax()) {
                    aA.Y();
                } else {
                    cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.cw.1
                        @Override // java.lang.Runnable
                        public void run() {
                            aA.Y();
                        }
                    });
                }
            }
        }
    }

    public final void a(bj bjVar) {
        boolean aE = this.gu.aE();
        a(new bm(bjVar, (!aE || this.gu.y().eG) ? this.iS : null, aE ? null : this.iT, this.iX, this.gu.aD()));
    }

    public final void a(a aVar) {
        this.iU = aVar;
    }

    public void a(q qVar, bn bnVar, al alVar, bq bqVar, boolean z) {
        a("/appEvent", new ak(alVar));
        a("/canOpenURLs", am.fn);
        a("/click", am.fo);
        a("/close", am.fp);
        a("/customClose", am.fq);
        a("/httpTrack", am.fr);
        a("/log", am.fs);
        a("/open", am.ft);
        a("/touch", am.fu);
        a("/video", am.fv);
        this.iS = qVar;
        this.iT = bnVar;
        this.fm = alVar;
        this.iX = bqVar;
        m(z);
    }

    public final void a(String str, an anVar) {
        this.iR.put(str, anVar);
    }

    public final void a(boolean z, int i) {
        a(new bm((!this.gu.aE() || this.gu.y().eG) ? this.iS : null, this.iT, this.iX, this.gu, z, i, this.gu.aD()));
    }

    public final void a(boolean z, int i, String str) {
        boolean aE = this.gu.aE();
        a(new bm((!aE || this.gu.y().eG) ? this.iS : null, aE ? null : this.iT, this.fm, this.iX, this.gu, z, i, str, this.gu.aD()));
    }

    public final void a(boolean z, int i, String str, String str2) {
        boolean aE = this.gu.aE();
        a(new bm((!aE || this.gu.y().eG) ? this.iS : null, aE ? null : this.iT, this.fm, this.iX, this.gu, z, i, str, str2, this.gu.aD()));
    }

    public boolean aI() {
        boolean z;
        synchronized (this.fx) {
            z = this.iW;
        }
        return z;
    }

    public final void m(boolean z) {
        this.iV = z;
    }

    @Override // android.webkit.WebViewClient
    public final void onPageFinished(WebView webView, String url) {
        if (this.iU != null) {
            this.iU.a(this.gu);
            this.iU = null;
        }
    }

    public final void reset() {
        synchronized (this.fx) {
            this.iR.clear();
            this.iS = null;
            this.iT = null;
            this.iU = null;
            this.fm = null;
            this.iV = false;
            this.iW = false;
            this.iX = null;
        }
    }

    @Override // android.webkit.WebViewClient
    public final boolean shouldOverrideUrlLoading(WebView webView, String url) {
        Uri uri;
        cs.u("AdWebView shouldOverrideUrlLoading: " + url);
        Uri parse = Uri.parse(url);
        if ("gmsg".equalsIgnoreCase(parse.getScheme()) && "mobileads.google.com".equalsIgnoreCase(parse.getHost())) {
            c(parse);
        } else {
            if (this.iV && webView == this.gu && b(parse)) {
                return super.shouldOverrideUrlLoading(webView, url);
            }
            if (this.gu.willNotDraw()) {
                cs.v("AdWebView unable to handle URL: " + url);
            } else {
                try {
                    h aC = this.gu.aC();
                    if (aC != null && aC.a(parse)) {
                        parse = aC.a(parse, this.gu.getContext());
                    }
                    uri = parse;
                } catch (i e) {
                    cs.v("Unable to append parameter to URL: " + url);
                    uri = parse;
                }
                a(new bj("android.intent.action.VIEW", uri.toString(), null, null, null, null, null));
            }
        }
        return true;
    }
}
