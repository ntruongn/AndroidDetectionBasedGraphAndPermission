package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.appstate.AppStateBuffer;
import com.google.android.gms.appstate.b;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.dd;
import com.google.android.gms.internal.dk;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class db extends dk<dd> {
    private final String jD;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class a extends da {
        private final a.c<b.InterfaceC0000b> jN;

        public a(a.c<b.InterfaceC0000b> cVar) {
            this.jN = (a.c) du.c(cVar, "Result holder must not be null");
        }

        @Override // com.google.android.gms.internal.da, com.google.android.gms.internal.dc
        public void onStateDeleted(int statusCode, int stateKey) {
            db.this.a(new b(this.jN, new Status(statusCode), stateKey));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class b extends dk<dd>.b<a.c<b.InterfaceC0000b>> implements b.InterfaceC0000b {
        private final Status jP;
        private final int jQ;

        public b(a.c<b.InterfaceC0000b> cVar, Status status, int i) {
            super(cVar);
            this.jP = status;
            this.jQ = i;
        }

        @Override // com.google.android.gms.appstate.b.InterfaceC0000b
        public int aK() {
            return this.jQ;
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }

        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void b(a.c<b.InterfaceC0000b> cVar) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class c extends da {
        private final a.c<b.c> jN;

        public c(a.c<b.c> cVar) {
            this.jN = (a.c) du.c(cVar, "Result holder must not be null");
        }

        @Override // com.google.android.gms.internal.da, com.google.android.gms.internal.dc
        public void a(DataHolder dataHolder) {
            db.this.a(new d(this.jN, new Status(dataHolder.getStatusCode()), dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class d extends dk<dd>.c<a.c<b.c>> implements b.c {
        private final Status jP;
        private final AppStateBuffer jR;

        public d(a.c<b.c> cVar, Status status, DataHolder dataHolder) {
            super(cVar, dataHolder);
            this.jP = status;
            this.jR = new AppStateBuffer(dataHolder);
        }

        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<b.c> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.appstate.b.c
        public AppStateBuffer aN() {
            return this.jR;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }

        @Override // com.google.android.gms.common.api.Releasable
        public void release() {
            if (this.jR != null) {
                this.jR.close();
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class e extends da {
        private final a.c<b.e> jN;

        public e(a.c<b.e> cVar) {
            this.jN = (a.c) du.c(cVar, "Result holder must not be null");
        }

        @Override // com.google.android.gms.internal.da, com.google.android.gms.internal.dc
        public void a(int i, DataHolder dataHolder) {
            db.this.a(new f(this.jN, i, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class f extends dk<dd>.c<a.c<b.e>> implements b.a, b.d, b.e {
        private final Status jP;
        private final int jQ;
        private final AppStateBuffer jR;

        public f(a.c<b.e> cVar, int i, DataHolder dataHolder) {
            super(cVar, dataHolder);
            this.jQ = i;
            this.jP = new Status(dataHolder.getStatusCode());
            this.jR = new AppStateBuffer(dataHolder);
        }

        private boolean aR() {
            return this.jP.getStatusCode() == 2000;
        }

        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<b.e> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.appstate.b.a, com.google.android.gms.appstate.b.d
        public int aK() {
            return this.jQ;
        }

        @Override // com.google.android.gms.appstate.b.a
        public String aL() {
            if (this.jR.getCount() == 0) {
                return null;
            }
            return this.jR.get(0).getConflictVersion();
        }

        @Override // com.google.android.gms.appstate.b.a
        public byte[] aM() {
            if (this.jR.getCount() == 0) {
                return null;
            }
            return this.jR.get(0).getConflictData();
        }

        @Override // com.google.android.gms.appstate.b.e
        public b.d aO() {
            if (aR()) {
                return null;
            }
            return this;
        }

        @Override // com.google.android.gms.appstate.b.e
        public b.a aP() {
            if (aR()) {
                return this;
            }
            return null;
        }

        @Override // com.google.android.gms.appstate.b.a, com.google.android.gms.appstate.b.d
        public byte[] getLocalData() {
            if (this.jR.getCount() == 0) {
                return null;
            }
            return this.jR.get(0).getLocalData();
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }

        @Override // com.google.android.gms.common.api.Releasable
        public void release() {
            if (this.jR != null) {
                this.jR.close();
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class g extends da {
        a.c<Status> jN;

        public g(a.c<Status> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.da, com.google.android.gms.internal.dc
        public void onSignOutComplete() {
            db.this.a(new h(this.jN, new Status(0)));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class h extends dk<dd>.b<a.c<Status>> {
        private final Status jP;

        public h(a.c<Status> cVar, Status status) {
            super(cVar);
            this.jP = status;
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }

        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void b(a.c<Status> cVar) {
            cVar.a(this.jP);
        }
    }

    public db(Context context, GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener, String str, String[] strArr) {
        super(context, connectionCallbacks, onConnectionFailedListener, strArr);
        this.jD = (String) du.f(str);
    }

    public void a(a.c<b.c> cVar) {
        try {
            bC().a(new c(cVar));
        } catch (RemoteException e2) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void a(a.c<b.InterfaceC0000b> cVar, int i) {
        try {
            bC().b(new a(cVar), i);
        } catch (RemoteException e2) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void a(a.c<b.e> cVar, int i, String str, byte[] bArr) {
        try {
            bC().a(new e(cVar), i, str, bArr);
        } catch (RemoteException e2) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void a(a.c<b.e> cVar, int i, byte[] bArr) {
        e eVar;
        if (cVar == null) {
            eVar = null;
        } else {
            try {
                eVar = new e(cVar);
            } catch (RemoteException e2) {
                Log.w("AppStateClient", "service died");
                return;
            }
        }
        bC().a(eVar, i, bArr);
    }

    @Override // com.google.android.gms.internal.dk
    protected void a(dq dqVar, dk.d dVar) throws RemoteException {
        dqVar.a(dVar, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.jD, bA());
    }

    @Override // com.google.android.gms.internal.dk
    protected void a(String... strArr) {
        boolean z = false;
        for (String str : strArr) {
            if (str.equals(Scopes.APP_STATE)) {
                z = true;
            }
        }
        du.a(z, String.format("App State APIs requires %s to function.", Scopes.APP_STATE));
    }

    @Override // com.google.android.gms.internal.dk
    protected String am() {
        return "com.google.android.gms.appstate.service.START";
    }

    @Override // com.google.android.gms.internal.dk
    protected String an() {
        return "com.google.android.gms.appstate.internal.IAppStateService";
    }

    public void b(a.c<Status> cVar) {
        try {
            bC().b(new g(cVar));
        } catch (RemoteException e2) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void b(a.c<b.e> cVar, int i) {
        try {
            bC().a(new e(cVar), i);
        } catch (RemoteException e2) {
            Log.w("AppStateClient", "service died");
        }
    }

    public int getMaxNumKeys() {
        try {
            return bC().getMaxNumKeys();
        } catch (RemoteException e2) {
            Log.w("AppStateClient", "service died");
            return 2;
        }
    }

    public int getMaxStateSize() {
        try {
            return bC().getMaxStateSize();
        } catch (RemoteException e2) {
            Log.w("AppStateClient", "service died");
            return 2;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.internal.dk
    /* renamed from: r, reason: merged with bridge method [inline-methods] */
    public dd p(IBinder iBinder) {
        return dd.a.t(iBinder);
    }
}
