package com.google.android.gms.common.data;

import android.content.ContentValues;
import android.database.AbstractWindowedCursor;
import android.database.CharArrayBuffer;
import android.database.CursorIndexOutOfBoundsException;
import android.database.CursorWindow;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.dg;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.du;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class DataHolder implements SafeParcelable {
    public static final DataHolderCreator CREATOR = new DataHolderCreator();
    private static final Builder lp = new Builder(new String[0], null) { // from class: com.google.android.gms.common.data.DataHolder.1
        @Override // com.google.android.gms.common.data.DataHolder.Builder
        public Builder withRow(ContentValues values) {
            throw new UnsupportedOperationException("Cannot add data to empty builder");
        }

        @Override // com.google.android.gms.common.data.DataHolder.Builder
        public Builder withRow(HashMap<String, Object> row) {
            throw new UnsupportedOperationException("Cannot add data to empty builder");
        }
    };
    private final int kZ;
    private final int ka;
    private final String[] lh;
    Bundle li;
    private final CursorWindow[] lj;
    private final Bundle lk;
    int[] ll;
    int lm;
    private Object ln;
    private boolean lo;
    boolean mClosed;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class Builder {
        private final String[] lh;
        private final ArrayList<HashMap<String, Object>> lq;
        private final String lr;
        private final HashMap<Object, Integer> ls;
        private boolean lt;
        private String lu;

        private Builder(String[] columns, String uniqueColumn) {
            this.lh = (String[]) du.f(columns);
            this.lq = new ArrayList<>();
            this.lr = uniqueColumn;
            this.ls = new HashMap<>();
            this.lt = false;
            this.lu = null;
        }

        private void a(HashMap<String, Object> hashMap) {
            Object obj = hashMap.get(this.lr);
            if (obj == null) {
                return;
            }
            Integer remove = this.ls.remove(obj);
            if (remove != null) {
                this.lq.remove(remove.intValue());
            }
            this.ls.put(obj, Integer.valueOf(this.lq.size()));
        }

        private void bk() {
            if (this.lr != null) {
                this.ls.clear();
                int size = this.lq.size();
                for (int i = 0; i < size; i++) {
                    Object obj = this.lq.get(i).get(this.lr);
                    if (obj != null) {
                        this.ls.put(obj, Integer.valueOf(i));
                    }
                }
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public DataHolder build(int i) {
            return new DataHolder(this, i, (Bundle) null);
        }

        public DataHolder build(int statusCode, Bundle metadata) {
            return new DataHolder(this, statusCode, metadata);
        }

        public int getCount() {
            return this.lq.size();
        }

        public Builder removeRowsWithValue(String column, Object value) {
            for (int size = this.lq.size() - 1; size >= 0; size--) {
                if (ds.equal(this.lq.get(size).get(column), value)) {
                    this.lq.remove(size);
                }
            }
            return this;
        }

        public Builder sort(String sortColumn) {
            dg.d(sortColumn);
            if (!this.lt || !sortColumn.equals(this.lu)) {
                Collections.sort(this.lq, new a(sortColumn));
                bk();
                this.lt = true;
                this.lu = sortColumn;
            }
            return this;
        }

        public Builder withRow(ContentValues values) {
            dg.d(values);
            HashMap<String, Object> hashMap = new HashMap<>(values.size());
            for (Map.Entry<String, Object> entry : values.valueSet()) {
                hashMap.put(entry.getKey(), entry.getValue());
            }
            return withRow(hashMap);
        }

        public Builder withRow(HashMap<String, Object> row) {
            dg.d(row);
            if (this.lr != null) {
                a(row);
            }
            this.lq.add(row);
            this.lt = false;
            return this;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private static final class a implements Comparator<HashMap<String, Object>> {
        private final String lv;

        a(String str) {
            this.lv = (String) du.f(str);
        }

        @Override // java.util.Comparator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(HashMap<String, Object> hashMap, HashMap<String, Object> hashMap2) {
            Object f = du.f(hashMap.get(this.lv));
            Object f2 = du.f(hashMap2.get(this.lv));
            if (f.equals(f2)) {
                return 0;
            }
            if (f instanceof Boolean) {
                return ((Boolean) f).compareTo((Boolean) f2);
            }
            if (f instanceof Long) {
                return ((Long) f).compareTo((Long) f2);
            }
            if (f instanceof Integer) {
                return ((Integer) f).compareTo((Integer) f2);
            }
            if (f instanceof String) {
                return ((String) f).compareTo((String) f2);
            }
            throw new IllegalArgumentException("Unknown type for lValue " + f);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public DataHolder(int versionCode, String[] columns, CursorWindow[] windows, int statusCode, Bundle metadata) {
        this.mClosed = false;
        this.lo = true;
        this.kZ = versionCode;
        this.lh = columns;
        this.lj = windows;
        this.ka = statusCode;
        this.lk = metadata;
    }

    public DataHolder(AbstractWindowedCursor cursor, int statusCode, Bundle metadata) {
        this(cursor.getColumnNames(), a(cursor), statusCode, metadata);
    }

    private DataHolder(Builder builder, int statusCode, Bundle metadata) {
        this(builder.lh, a(builder), statusCode, metadata);
    }

    public DataHolder(String[] columns, CursorWindow[] windows, int statusCode, Bundle metadata) {
        this.mClosed = false;
        this.lo = true;
        this.kZ = 1;
        this.lh = (String[]) du.f(columns);
        this.lj = (CursorWindow[]) du.f(windows);
        this.ka = statusCode;
        this.lk = metadata;
        validateContents();
    }

    private void a(String str, int i) {
        if (this.li == null || !this.li.containsKey(str)) {
            throw new IllegalArgumentException("No such column: " + str);
        }
        if (isClosed()) {
            throw new IllegalArgumentException("Buffer is closed.");
        }
        if (i < 0 || i >= this.lm) {
            throw new CursorIndexOutOfBoundsException(i, this.lm);
        }
    }

    private static CursorWindow[] a(AbstractWindowedCursor abstractWindowedCursor) {
        int i;
        ArrayList arrayList = new ArrayList();
        try {
            int count = abstractWindowedCursor.getCount();
            CursorWindow window = abstractWindowedCursor.getWindow();
            if (window == null || window.getStartPosition() != 0) {
                i = 0;
            } else {
                window.acquireReference();
                abstractWindowedCursor.setWindow(null);
                arrayList.add(window);
                i = window.getNumRows();
            }
            while (i < count) {
                if (!abstractWindowedCursor.moveToPosition(i)) {
                    break;
                }
                CursorWindow window2 = abstractWindowedCursor.getWindow();
                if (window2 != null) {
                    window2.acquireReference();
                    abstractWindowedCursor.setWindow(null);
                } else {
                    window2 = new CursorWindow(false);
                    abstractWindowedCursor.fillWindow(i, window2);
                }
                if (window2.getNumRows() == 0) {
                    break;
                }
                arrayList.add(window2);
                i = window2.getNumRows() + window2.getStartPosition();
            }
            abstractWindowedCursor.close();
            return (CursorWindow[]) arrayList.toArray(new CursorWindow[arrayList.size()]);
        } catch (Throwable th) {
            abstractWindowedCursor.close();
            throw th;
        }
    }

    private static CursorWindow[] a(Builder builder) {
        int i;
        int i2;
        int i3;
        CursorWindow cursorWindow;
        if (builder.lh.length == 0) {
            return new CursorWindow[0];
        }
        ArrayList arrayList = builder.lq;
        int size = arrayList.size();
        CursorWindow cursorWindow2 = new CursorWindow(false);
        ArrayList arrayList2 = new ArrayList();
        arrayList2.add(cursorWindow2);
        cursorWindow2.setNumColumns(builder.lh.length);
        int i4 = 0;
        int i5 = 0;
        while (i4 < size) {
            try {
                if (cursorWindow2.allocRow()) {
                    i = i5;
                } else {
                    Log.d("DataHolder", "Allocating additional cursor window for large data set (row " + i4 + ")");
                    cursorWindow2 = new CursorWindow(false);
                    cursorWindow2.setNumColumns(builder.lh.length);
                    arrayList2.add(cursorWindow2);
                    if (!cursorWindow2.allocRow()) {
                        Log.e("DataHolder", "Unable to allocate row to hold data.");
                        arrayList2.remove(cursorWindow2);
                        return (CursorWindow[]) arrayList2.toArray(new CursorWindow[arrayList2.size()]);
                    }
                    i = 0;
                }
                Map map = (Map) arrayList.get(i4);
                boolean z = true;
                for (int i6 = 0; i6 < builder.lh.length && z; i6++) {
                    String str = builder.lh[i6];
                    Object obj = map.get(str);
                    if (obj == null) {
                        z = cursorWindow2.putNull(i, i6);
                    } else if (obj instanceof String) {
                        z = cursorWindow2.putString((String) obj, i, i6);
                    } else if (obj instanceof Long) {
                        z = cursorWindow2.putLong(((Long) obj).longValue(), i, i6);
                    } else if (obj instanceof Integer) {
                        z = cursorWindow2.putLong(((Integer) obj).intValue(), i, i6);
                    } else if (obj instanceof Boolean) {
                        z = cursorWindow2.putLong(((Boolean) obj).booleanValue() ? 1L : 0L, i, i6);
                    } else {
                        if (!(obj instanceof byte[])) {
                            throw new IllegalArgumentException("Unsupported object for column " + str + ": " + obj);
                        }
                        z = cursorWindow2.putBlob((byte[]) obj, i, i6);
                    }
                }
                if (z) {
                    i2 = i + 1;
                    i3 = i4;
                    cursorWindow = cursorWindow2;
                } else {
                    Log.d("DataHolder", "Couldn't populate window data for row " + i4 + " - allocating new window.");
                    cursorWindow2.freeLastRow();
                    CursorWindow cursorWindow3 = new CursorWindow(false);
                    cursorWindow3.setNumColumns(builder.lh.length);
                    arrayList2.add(cursorWindow3);
                    i3 = i4 - 1;
                    cursorWindow = cursorWindow3;
                    i2 = 0;
                }
                cursorWindow2 = cursorWindow;
                i4 = i3 + 1;
                i5 = i2;
            } catch (RuntimeException e) {
                int size2 = arrayList2.size();
                for (int i7 = 0; i7 < size2; i7++) {
                    ((CursorWindow) arrayList2.get(i7)).close();
                }
                throw e;
            }
        }
        return (CursorWindow[]) arrayList2.toArray(new CursorWindow[arrayList2.size()]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static Builder builder(String[] strArr) {
        return new Builder(strArr, null);
    }

    public static Builder builder(String[] columns, String uniqueColumn) {
        du.f(uniqueColumn);
        return new Builder(columns, uniqueColumn);
    }

    public static DataHolder empty(int statusCode) {
        return empty(statusCode, null);
    }

    public static DataHolder empty(int statusCode, Bundle metadata) {
        return new DataHolder(lp, statusCode, metadata);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String[] bi() {
        return this.lh;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public CursorWindow[] bj() {
        return this.lj;
    }

    public void c(Object obj) {
        this.ln = obj;
    }

    public void close() {
        synchronized (this) {
            if (!this.mClosed) {
                this.mClosed = true;
                for (int i = 0; i < this.lj.length; i++) {
                    this.lj[i].close();
                }
            }
        }
    }

    public void copyToBuffer(String column, int row, int windowIndex, CharArrayBuffer dataOut) {
        a(column, row);
        this.lj[windowIndex].copyStringToBuffer(row - this.ll[windowIndex], this.li.getInt(column), dataOut);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    protected void finalize() throws Throwable {
        try {
            if (this.lo && this.lj.length > 0 && !isClosed()) {
                Log.e("DataBuffer", "Internal data leak within a DataBuffer object detected!  Be sure to explicitly call close() on all DataBuffer extending objects when you are done with them. (" + (this.ln == null ? "internal object: " + toString() : this.ln.toString()) + ")");
                close();
            }
        } finally {
            super.finalize();
        }
    }

    public boolean getBoolean(String column, int row, int windowIndex) {
        a(column, row);
        return Long.valueOf(this.lj[windowIndex].getLong(row - this.ll[windowIndex], this.li.getInt(column))).longValue() == 1;
    }

    public byte[] getByteArray(String column, int row, int windowIndex) {
        a(column, row);
        return this.lj[windowIndex].getBlob(row - this.ll[windowIndex], this.li.getInt(column));
    }

    public int getCount() {
        return this.lm;
    }

    public int getInteger(String column, int row, int windowIndex) {
        a(column, row);
        return this.lj[windowIndex].getInt(row - this.ll[windowIndex], this.li.getInt(column));
    }

    public long getLong(String column, int row, int windowIndex) {
        a(column, row);
        return this.lj[windowIndex].getLong(row - this.ll[windowIndex], this.li.getInt(column));
    }

    public Bundle getMetadata() {
        return this.lk;
    }

    public int getStatusCode() {
        return this.ka;
    }

    public String getString(String column, int row, int windowIndex) {
        a(column, row);
        return this.lj[windowIndex].getString(row - this.ll[windowIndex], this.li.getInt(column));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.kZ;
    }

    public boolean hasNull(String column, int row, int windowIndex) {
        a(column, row);
        return this.lj[windowIndex].isNull(row - this.ll[windowIndex], this.li.getInt(column));
    }

    public boolean isClosed() {
        boolean z;
        synchronized (this) {
            z = this.mClosed;
        }
        return z;
    }

    public Uri parseUri(String column, int row, int windowIndex) {
        String string = getString(column, row, windowIndex);
        if (string == null) {
            return null;
        }
        return Uri.parse(string);
    }

    public int t(int i) {
        int i2 = 0;
        du.n(i >= 0 && i < this.lm);
        while (true) {
            if (i2 >= this.ll.length) {
                break;
            }
            if (i < this.ll[i2]) {
                i2--;
                break;
            }
            i2++;
        }
        return i2 == this.ll.length ? i2 - 1 : i2;
    }

    public void validateContents() {
        this.li = new Bundle();
        for (int i = 0; i < this.lh.length; i++) {
            this.li.putInt(this.lh[i], i);
        }
        this.ll = new int[this.lj.length];
        int i2 = 0;
        for (int i3 = 0; i3 < this.lj.length; i3++) {
            this.ll[i3] = i2;
            i2 += this.lj[i3].getNumRows();
        }
        this.lm = i2;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        DataHolderCreator.a(this, dest, flags);
    }
}
