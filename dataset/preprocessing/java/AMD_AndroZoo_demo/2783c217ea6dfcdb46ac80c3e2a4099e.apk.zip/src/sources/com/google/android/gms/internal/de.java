package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class de extends Drawable implements Drawable.Callback {
    private boolean lV;
    private int lX;
    private long lY;
    private int lZ;
    private int ma;
    private int mb;
    private int mc;
    private int md;
    private boolean me;
    private b mf;
    private Drawable mg;
    private Drawable mh;
    private boolean mi;
    private boolean mj;
    private boolean mk;
    private int ml;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private static final class a extends Drawable {
        private static final a mm = new a();
        private static final C0025a mn = new C0025a();

        /* renamed from: com.google.android.gms.internal.de$a$a, reason: collision with other inner class name */
        /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
        private static final class C0025a extends Drawable.ConstantState {
            private C0025a() {
            }

            @Override // android.graphics.drawable.Drawable.ConstantState
            public int getChangingConfigurations() {
                return 0;
            }

            @Override // android.graphics.drawable.Drawable.ConstantState
            public Drawable newDrawable() {
                return a.mm;
            }
        }

        private a() {
        }

        @Override // android.graphics.drawable.Drawable
        public void draw(Canvas canvas) {
        }

        @Override // android.graphics.drawable.Drawable
        public Drawable.ConstantState getConstantState() {
            return mn;
        }

        @Override // android.graphics.drawable.Drawable
        public int getOpacity() {
            return -2;
        }

        @Override // android.graphics.drawable.Drawable
        public void setAlpha(int alpha) {
        }

        @Override // android.graphics.drawable.Drawable
        public void setColorFilter(ColorFilter cf) {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class b extends Drawable.ConstantState {
        int mo;
        int mp;

        b(b bVar) {
            if (bVar != null) {
                this.mo = bVar.mo;
                this.mp = bVar.mp;
            }
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.mo;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            return new de(this);
        }
    }

    public de(Drawable drawable, Drawable drawable2) {
        this(null);
        drawable = drawable == null ? a.mm : drawable;
        this.mg = drawable;
        drawable.setCallback(this);
        this.mf.mp |= drawable.getChangingConfigurations();
        drawable2 = drawable2 == null ? a.mm : drawable2;
        this.mh = drawable2;
        drawable2.setCallback(this);
        this.mf.mp |= drawable2.getChangingConfigurations();
    }

    de(b bVar) {
        this.lX = 0;
        this.mb = 255;
        this.md = 0;
        this.lV = true;
        this.mf = new b(bVar);
    }

    public Drawable bq() {
        return this.mh;
    }

    public boolean canConstantState() {
        if (!this.mi) {
            this.mj = (this.mg.getConstantState() == null || this.mh.getConstantState() == null) ? false : true;
            this.mi = true;
        }
        return this.mj;
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        boolean z = false;
        switch (this.lX) {
            case 1:
                this.lY = SystemClock.uptimeMillis();
                this.lX = 2;
                break;
            case 2:
                if (this.lY >= 0) {
                    float uptimeMillis = ((float) (SystemClock.uptimeMillis() - this.lY)) / this.mc;
                    r1 = uptimeMillis >= 1.0f;
                    if (r1) {
                        this.lX = 0;
                    }
                    this.md = (int) ((Math.min(uptimeMillis, 1.0f) * (this.ma - this.lZ)) + this.lZ);
                }
            default:
                z = r1;
                break;
        }
        int i = this.md;
        boolean z2 = this.lV;
        Drawable drawable = this.mg;
        Drawable drawable2 = this.mh;
        if (z) {
            if (!z2 || i == 0) {
                drawable.draw(canvas);
            }
            if (i == this.mb) {
                drawable2.setAlpha(this.mb);
                drawable2.draw(canvas);
                return;
            }
            return;
        }
        if (z2) {
            drawable.setAlpha(this.mb - i);
        }
        drawable.draw(canvas);
        if (z2) {
            drawable.setAlpha(this.mb);
        }
        if (i > 0) {
            drawable2.setAlpha(i);
            drawable2.draw(canvas);
            drawable2.setAlpha(this.mb);
        }
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        return super.getChangingConfigurations() | this.mf.mo | this.mf.mp;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        if (!canConstantState()) {
            return null;
        }
        this.mf.mo = getChangingConfigurations();
        return this.mf;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        return Math.max(this.mg.getIntrinsicHeight(), this.mh.getIntrinsicHeight());
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        return Math.max(this.mg.getIntrinsicWidth(), this.mh.getIntrinsicWidth());
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        if (!this.mk) {
            this.ml = Drawable.resolveOpacity(this.mg.getOpacity(), this.mh.getOpacity());
            this.mk = true;
        }
        return this.ml;
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void invalidateDrawable(Drawable who) {
        Drawable.Callback callback;
        if (!es.ck() || (callback = getCallback()) == null) {
            return;
        }
        callback.invalidateDrawable(this);
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        if (!this.me && super.mutate() == this) {
            if (!canConstantState()) {
                throw new IllegalStateException("One or more children of this LayerDrawable does not have constant state; this drawable cannot be mutated.");
            }
            this.mg.mutate();
            this.mh.mutate();
            this.me = true;
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect bounds) {
        this.mg.setBounds(bounds);
        this.mh.setBounds(bounds);
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void scheduleDrawable(Drawable who, Runnable what, long when) {
        Drawable.Callback callback;
        if (!es.ck() || (callback = getCallback()) == null) {
            return;
        }
        callback.scheduleDrawable(this, what, when);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int alpha) {
        if (this.md == this.mb) {
            this.md = alpha;
        }
        this.mb = alpha;
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter cf) {
        this.mg.setColorFilter(cf);
        this.mh.setColorFilter(cf);
    }

    public void startTransition(int durationMillis) {
        this.lZ = 0;
        this.ma = this.mb;
        this.md = 0;
        this.mc = durationMillis;
        this.lX = 1;
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void unscheduleDrawable(Drawable who, Runnable what) {
        Drawable.Callback callback;
        if (!es.ck() || (callback = getCallback()) == null) {
            return;
        }
        callback.unscheduleDrawable(this, what);
    }
}
