package com.google.android.gms.games;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a;
import com.google.android.gms.games.achievement.OnAchievementUpdatedListener;
import com.google.android.gms.games.achievement.OnAchievementsLoadedListener;
import com.google.android.gms.games.achievement.b;
import com.google.android.gms.games.c;
import com.google.android.gms.games.f;
import com.google.android.gms.games.leaderboard.LeaderboardScoreBuffer;
import com.google.android.gms.games.leaderboard.OnLeaderboardMetadataLoadedListener;
import com.google.android.gms.games.leaderboard.OnLeaderboardScoresLoadedListener;
import com.google.android.gms.games.leaderboard.OnPlayerLeaderboardScoreLoadedListener;
import com.google.android.gms.games.leaderboard.OnScoreSubmittedListener;
import com.google.android.gms.games.leaderboard.SubmitScoreResult;
import com.google.android.gms.games.leaderboard.h;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;
import com.google.android.gms.games.multiplayer.OnInvitationsLoadedListener;
import com.google.android.gms.games.multiplayer.ParticipantResult;
import com.google.android.gms.games.multiplayer.c;
import com.google.android.gms.games.multiplayer.realtime.RealTimeReliableMessageSentListener;
import com.google.android.gms.games.multiplayer.realtime.RealTimeSocket;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.google.android.gms.games.multiplayer.realtime.RoomUpdateListener;
import com.google.android.gms.games.multiplayer.realtime.a;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchCanceledListener;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchInitiatedListener;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchLeftListener;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchLoadedListener;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchUpdateReceivedListener;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchUpdatedListener;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchesLoadedListener;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatchConfig;
import com.google.android.gms.games.multiplayer.turnbased.b;
import com.google.android.gms.internal.du;
import com.google.android.gms.internal.ex;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class GamesClient implements GooglePlayServicesClient {
    public static final String EXTRA_EXCLUSIVE_BIT_MASK = "exclusive_bit_mask";
    public static final String EXTRA_INVITATION = "invitation";
    public static final String EXTRA_MAX_AUTOMATCH_PLAYERS = "max_automatch_players";
    public static final String EXTRA_MIN_AUTOMATCH_PLAYERS = "min_automatch_players";
    public static final String EXTRA_PLAYERS = "players";
    public static final String EXTRA_PLAYER_SEARCH_RESULTS = "player_search_results";
    public static final String EXTRA_ROOM = "room";
    public static final String EXTRA_TURN_BASED_MATCH = "turn_based_match";
    public static final int MAX_RELIABLE_MESSAGE_LEN = 1400;
    public static final int MAX_UNRELIABLE_MESSAGE_LEN = 1168;
    public static final int NOTIFICATION_TYPES_ALL = -1;
    public static final int NOTIFICATION_TYPES_MULTIPLAYER = 3;
    public static final int NOTIFICATION_TYPE_INVITATION = 1;
    public static final int NOTIFICATION_TYPE_MATCH_UPDATE = 2;
    public static final int STATUS_ACHIEVEMENT_NOT_INCREMENTAL = 3002;
    public static final int STATUS_ACHIEVEMENT_UNKNOWN = 3001;
    public static final int STATUS_ACHIEVEMENT_UNLOCKED = 3003;
    public static final int STATUS_ACHIEVEMENT_UNLOCK_FAILURE = 3000;
    public static final int STATUS_APP_MISCONFIGURED = 8;
    public static final int STATUS_CLIENT_RECONNECT_REQUIRED = 2;
    public static final int STATUS_GAME_NOT_FOUND = 9;
    public static final int STATUS_INTERNAL_ERROR = 1;
    public static final int STATUS_INVALID_REAL_TIME_ROOM_ID = 7002;
    public static final int STATUS_LICENSE_CHECK_FAILED = 7;
    public static final int STATUS_MATCH_ERROR_ALREADY_REMATCHED = 6505;
    public static final int STATUS_MATCH_ERROR_INACTIVE_MATCH = 6501;
    public static final int STATUS_MATCH_ERROR_INVALID_MATCH_RESULTS = 6504;
    public static final int STATUS_MATCH_ERROR_INVALID_MATCH_STATE = 6502;
    public static final int STATUS_MATCH_ERROR_INVALID_PARTICIPANT_STATE = 6500;
    public static final int STATUS_MATCH_ERROR_LOCALLY_MODIFIED = 6507;
    public static final int STATUS_MATCH_ERROR_OUT_OF_DATE_VERSION = 6503;
    public static final int STATUS_MATCH_NOT_FOUND = 6506;
    public static final int STATUS_MULTIPLAYER_DISABLED = 6003;
    public static final int STATUS_MULTIPLAYER_ERROR_CREATION_NOT_ALLOWED = 6000;
    public static final int STATUS_MULTIPLAYER_ERROR_INVALID_MULTIPLAYER_TYPE = 6002;
    public static final int STATUS_MULTIPLAYER_ERROR_INVALID_OPERATION = 6004;
    public static final int STATUS_MULTIPLAYER_ERROR_NOT_TRUSTED_TESTER = 6001;
    public static final int STATUS_NETWORK_ERROR_NO_DATA = 4;
    public static final int STATUS_NETWORK_ERROR_OPERATION_DEFERRED = 5;
    public static final int STATUS_NETWORK_ERROR_OPERATION_FAILED = 6;
    public static final int STATUS_NETWORK_ERROR_STALE_DATA = 3;
    public static final int STATUS_OK = 0;
    public static final int STATUS_OPERATION_IN_FLIGHT = 7007;
    public static final int STATUS_PARTICIPANT_NOT_CONNECTED = 7003;
    public static final int STATUS_REAL_TIME_CONNECTION_FAILED = 7000;
    public static final int STATUS_REAL_TIME_INACTIVE_ROOM = 7005;
    public static final int STATUS_REAL_TIME_MESSAGE_FAILED = -1;
    public static final int STATUS_REAL_TIME_MESSAGE_SEND_FAILED = 7001;
    public static final int STATUS_REAL_TIME_ROOM_NOT_JOINED = 7004;
    private final ex qm;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class Builder {
        private final GooglePlayServicesClient.ConnectionCallbacks jA;
        private final GooglePlayServicesClient.OnConnectionFailedListener jB;
        private final Context mContext;
        private String qF;
        private View qH;
        private String jD = "<<default account>>";
        private String[] jC = {Scopes.GAMES};
        private int qG = 49;
        private boolean qI = true;
        private int qJ = 17;

        public Builder(Context context, GooglePlayServicesClient.ConnectionCallbacks connectedListener, GooglePlayServicesClient.OnConnectionFailedListener connectionFailedListener) {
            this.mContext = context;
            this.qF = context.getPackageName();
            this.jA = connectedListener;
            this.jB = connectionFailedListener;
        }

        public GamesClient create() {
            return new GamesClient(this.mContext, this.qF, this.jD, this.jA, this.jB, this.jC, this.qG, this.qH, this.qI, this.qJ);
        }

        public Builder setAccountName(String accountName) {
            this.jD = (String) du.f(accountName);
            return this;
        }

        public Builder setGravityForPopups(int gravity) {
            this.qG = gravity;
            return this;
        }

        public Builder setScopes(String... scopes) {
            this.jC = scopes;
            return this;
        }

        public Builder setShowConnectingPopup(boolean showConnectingPopup) {
            this.qI = showConnectingPopup;
            this.qJ = 17;
            return this;
        }

        public Builder setShowConnectingPopup(boolean showConnectingPopup, int gravity) {
            this.qI = showConnectingPopup;
            this.qJ = gravity;
            return this;
        }

        public Builder setViewForPopups(View gamesContentView) {
            this.qH = (View) du.f(gamesContentView);
            return this;
        }
    }

    private GamesClient(Context context, String gamePackageName, String accountName, GooglePlayServicesClient.ConnectionCallbacks connectedListener, GooglePlayServicesClient.OnConnectionFailedListener connectionFailedListener, String[] scopes, int gravity, View gamesContentView, boolean showConnectingPopup, int connectingPopupGravity) {
        this.qm = new ex(context, gamePackageName, accountName, connectedListener, connectionFailedListener, scopes, gravity, gamesContentView, false, showConnectingPopup, connectingPopupGravity);
    }

    public void acceptTurnBasedInvitation(final OnTurnBasedMatchInitiatedListener listener, String invitationId) {
        this.qm.e(new a.c<b.InterfaceC0011b>() { // from class: com.google.android.gms.games.GamesClient.18
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.InterfaceC0011b interfaceC0011b) {
                listener.onTurnBasedMatchInitiated(interfaceC0011b.getStatus().getStatusCode(), interfaceC0011b.cT());
            }
        }, invitationId);
    }

    public void cancelTurnBasedMatch(final OnTurnBasedMatchCanceledListener listener, String matchId) {
        this.qm.g(new a.c<b.a>() { // from class: com.google.android.gms.games.GamesClient.27
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.a aVar) {
                listener.onTurnBasedMatchCanceled(aVar.getStatus().getStatusCode(), aVar.getMatchId());
            }
        }, matchId);
    }

    public void cancelTurnBasedMatch(String matchId) {
        this.qm.g(new a.c<b.a>() { // from class: com.google.android.gms.games.GamesClient.28
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.a aVar) {
            }
        }, matchId);
    }

    public void clearAllNotifications() {
        this.qm.clearNotifications(-1);
    }

    public void clearNotifications(int notificationTypes) {
        this.qm.clearNotifications(notificationTypes);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void connect() {
        this.qm.connect();
    }

    public void createRoom(RoomConfig config) {
        this.qm.createRoom(config);
    }

    public void createTurnBasedMatch(final OnTurnBasedMatchInitiatedListener listener, TurnBasedMatchConfig config) {
        this.qm.a(new a.c<b.InterfaceC0011b>() { // from class: com.google.android.gms.games.GamesClient.16
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.InterfaceC0011b interfaceC0011b) {
                listener.onTurnBasedMatchInitiated(interfaceC0011b.getStatus().getStatusCode(), interfaceC0011b.cT());
            }
        }, config);
    }

    public void declineRoomInvitation(String invitationId) {
        this.qm.i(invitationId, 0);
    }

    public void declineTurnBasedInvitation(String invitationId) {
        this.qm.i(invitationId, 1);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void disconnect() {
        this.qm.disconnect();
    }

    public void dismissRoomInvitation(String invitationId) {
        this.qm.h(invitationId, 0);
    }

    public void dismissTurnBasedInvitation(String invitationId) {
        this.qm.h(invitationId, 1);
    }

    public void dismissTurnBasedMatch(String matchId) {
        this.qm.dismissTurnBasedMatch(matchId);
    }

    public void finishTurnBasedMatch(final OnTurnBasedMatchUpdatedListener listener, String matchId) {
        this.qm.a(new a.c<b.f>() { // from class: com.google.android.gms.games.GamesClient.22
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.f fVar) {
                listener.onTurnBasedMatchUpdated(fVar.getStatus().getStatusCode(), fVar.cT());
            }
        }, matchId, (byte[]) null, (ParticipantResult[]) null);
    }

    public void finishTurnBasedMatch(OnTurnBasedMatchUpdatedListener listener, String matchId, byte[] matchData, List<ParticipantResult> results) {
        finishTurnBasedMatch(listener, matchId, matchData, results == null ? null : (ParticipantResult[]) results.toArray(new ParticipantResult[results.size()]));
    }

    public void finishTurnBasedMatch(final OnTurnBasedMatchUpdatedListener listener, String matchId, byte[] matchData, ParticipantResult... results) {
        this.qm.a(new a.c<b.f>() { // from class: com.google.android.gms.games.GamesClient.24
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.f fVar) {
                listener.onTurnBasedMatchUpdated(fVar.getStatus().getStatusCode(), fVar.cT());
            }
        }, matchId, matchData, results);
    }

    public Intent getAchievementsIntent() {
        return this.qm.getAchievementsIntent();
    }

    public Intent getAllLeaderboardsIntent() {
        return this.qm.getAllLeaderboardsIntent();
    }

    public String getAppId() {
        return this.qm.getAppId();
    }

    public String getCurrentAccountName() {
        return this.qm.getCurrentAccountName();
    }

    public Game getCurrentGame() {
        return this.qm.getCurrentGame();
    }

    public Player getCurrentPlayer() {
        return this.qm.getCurrentPlayer();
    }

    public String getCurrentPlayerId() {
        return this.qm.getCurrentPlayerId();
    }

    public Intent getInvitationInboxIntent() {
        return this.qm.getInvitationInboxIntent();
    }

    public Intent getLeaderboardIntent(String leaderboardId) {
        return this.qm.getLeaderboardIntent(leaderboardId);
    }

    public Intent getMatchInboxIntent() {
        return this.qm.getMatchInboxIntent();
    }

    public int getMaxTurnBasedMatchDataSize() {
        return this.qm.getMaxTurnBasedMatchDataSize();
    }

    public Intent getPlayerSearchIntent() {
        return this.qm.getPlayerSearchIntent();
    }

    public RealTimeSocket getRealTimeSocketForParticipant(String roomId, String participantId) {
        return this.qm.getRealTimeSocketForParticipant(roomId, participantId);
    }

    public Intent getRealTimeWaitingRoomIntent(Room room, int minParticipantsToStart) {
        return this.qm.getRealTimeWaitingRoomIntent(room, minParticipantsToStart);
    }

    public Intent getSelectPlayersIntent(int minPlayers, int maxPlayers) {
        return this.qm.getSelectPlayersIntent(minPlayers, maxPlayers, true);
    }

    public Intent getSelectPlayersIntent(int minPlayers, int maxPlayers, boolean allowAutomatch) {
        return this.qm.getSelectPlayersIntent(minPlayers, maxPlayers, allowAutomatch);
    }

    public Intent getSettingsIntent() {
        return this.qm.getSettingsIntent();
    }

    public void getTurnBasedMatch(final OnTurnBasedMatchLoadedListener listener, String matchId) {
        this.qm.h(new a.c<b.d>() { // from class: com.google.android.gms.games.GamesClient.32
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.d dVar) {
                listener.onTurnBasedMatchLoaded(dVar.getStatus().getStatusCode(), dVar.cT());
            }
        }, matchId);
    }

    public void incrementAchievement(String id, int numSteps) {
        this.qm.a((a.c<b.InterfaceC0009b>) null, id, numSteps);
    }

    public void incrementAchievementImmediate(final OnAchievementUpdatedListener listener, String id, int numSteps) {
        this.qm.a(new a.c<b.InterfaceC0009b>() { // from class: com.google.android.gms.games.GamesClient.10
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.InterfaceC0009b interfaceC0009b) {
                listener.onAchievementUpdated(interfaceC0009b.getStatus().getStatusCode(), interfaceC0009b.getAchievementId());
            }
        }, id, numSteps);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnected() {
        return this.qm.isConnected();
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnecting() {
        return this.qm.isConnecting();
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks listener) {
        return this.qm.isConnectionCallbacksRegistered(listener);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        return this.qm.isConnectionFailedListenerRegistered(listener);
    }

    public void joinRoom(RoomConfig config) {
        this.qm.joinRoom(config);
    }

    public void leaveRoom(RoomUpdateListener listener, String roomId) {
        this.qm.leaveRoom(listener, roomId);
    }

    public void leaveTurnBasedMatch(final OnTurnBasedMatchLeftListener listener, String matchId) {
        this.qm.f(new a.c<b.c>() { // from class: com.google.android.gms.games.GamesClient.25
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.c cVar) {
                listener.onTurnBasedMatchLeft(cVar.getStatus().getStatusCode(), cVar.cT());
            }
        }, matchId);
    }

    public void leaveTurnBasedMatchDuringTurn(final OnTurnBasedMatchLeftListener listener, String matchId, String pendingParticipantId) {
        this.qm.a(new a.c<b.c>() { // from class: com.google.android.gms.games.GamesClient.26
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.c cVar) {
                listener.onTurnBasedMatchLeft(cVar.getStatus().getStatusCode(), cVar.cT());
            }
        }, matchId, pendingParticipantId);
    }

    public void loadAchievements(final OnAchievementsLoadedListener listener, boolean forceReload) {
        this.qm.b(new a.c<b.a>() { // from class: com.google.android.gms.games.GamesClient.7
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.a aVar) {
                listener.onAchievementsLoaded(aVar.getStatus().getStatusCode(), aVar.cK());
            }
        }, forceReload);
    }

    public void loadCurrentPlayerLeaderboardScore(final OnPlayerLeaderboardScoreLoadedListener listener, String leaderboardId, int span, int leaderboardCollection) {
        this.qm.a(new a.c<h.b>() { // from class: com.google.android.gms.games.GamesClient.35
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.b bVar) {
                listener.onPlayerLeaderboardScoreLoaded(bVar.getStatus().getStatusCode(), bVar.cR());
            }
        }, (String) null, leaderboardId, span, leaderboardCollection);
    }

    public void loadGame(final OnGamesLoadedListener listener) {
        this.qm.d(new a.c<c.a>() { // from class: com.google.android.gms.games.GamesClient.13
            @Override // com.google.android.gms.common.api.a.c
            public void a(c.a aVar) {
                listener.onGamesLoaded(aVar.getStatus().getStatusCode(), aVar.cI());
            }
        });
    }

    public void loadInvitablePlayers(final OnPlayersLoadedListener listener, int pageSize, boolean forceReload) {
        this.qm.a(new a.c<f.a>() { // from class: com.google.android.gms.games.GamesClient.12
            @Override // com.google.android.gms.common.api.a.c
            public void a(f.a aVar) {
                listener.onPlayersLoaded(aVar.getStatus().getStatusCode(), aVar.cJ());
            }
        }, pageSize, false, forceReload);
    }

    public void loadInvitations(final OnInvitationsLoadedListener listener) {
        this.qm.e(new a.c<c.a>() { // from class: com.google.android.gms.games.GamesClient.30
            @Override // com.google.android.gms.common.api.a.c
            public void a(c.a aVar) {
                listener.onInvitationsLoaded(aVar.getStatus().getStatusCode(), aVar.getInvitations());
            }
        });
    }

    public void loadLeaderboardMetadata(final OnLeaderboardMetadataLoadedListener listener, String leaderboardId, boolean forceReload) {
        this.qm.a(new a.c<h.a>() { // from class: com.google.android.gms.games.GamesClient.34
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.a aVar) {
                listener.onLeaderboardMetadataLoaded(aVar.getStatus().getStatusCode(), aVar.cQ());
            }
        }, leaderboardId, forceReload);
    }

    public void loadLeaderboardMetadata(final OnLeaderboardMetadataLoadedListener listener, boolean forceReload) {
        this.qm.a(new a.c<h.a>() { // from class: com.google.android.gms.games.GamesClient.33
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.a aVar) {
                listener.onLeaderboardMetadataLoaded(aVar.getStatus().getStatusCode(), aVar.cQ());
            }
        }, forceReload);
    }

    public void loadMoreInvitablePlayers(final OnPlayersLoadedListener listener, int pageSize) {
        this.qm.a(new a.c<f.a>() { // from class: com.google.android.gms.games.GamesClient.23
            @Override // com.google.android.gms.common.api.a.c
            public void a(f.a aVar) {
                listener.onPlayersLoaded(aVar.getStatus().getStatusCode(), aVar.cJ());
            }
        }, pageSize, true, false);
    }

    public void loadMoreScores(final OnLeaderboardScoresLoadedListener listener, LeaderboardScoreBuffer buffer, int maxResults, int pageDirection) {
        this.qm.a(new a.c<h.c>() { // from class: com.google.android.gms.games.GamesClient.4
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.c cVar) {
                listener.onLeaderboardScoresLoaded(cVar.getStatus().getStatusCode(), cVar.cO(), cVar.cP());
            }
        }, buffer, maxResults, pageDirection);
    }

    public void loadPlayer(final OnPlayersLoadedListener listener, String playerId) {
        this.qm.a(new a.c<f.a>() { // from class: com.google.android.gms.games.GamesClient.1
            @Override // com.google.android.gms.common.api.a.c
            public void a(f.a aVar) {
                listener.onPlayersLoaded(aVar.getStatus().getStatusCode(), aVar.cJ());
            }
        }, playerId);
    }

    public void loadPlayerCenteredScores(final OnLeaderboardScoresLoadedListener listener, String leaderboardId, int span, int leaderboardCollection, int maxResults) {
        this.qm.b(new a.c<h.c>() { // from class: com.google.android.gms.games.GamesClient.2
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.c cVar) {
                listener.onLeaderboardScoresLoaded(cVar.getStatus().getStatusCode(), cVar.cO(), cVar.cP());
            }
        }, leaderboardId, span, leaderboardCollection, maxResults, false);
    }

    public void loadPlayerCenteredScores(final OnLeaderboardScoresLoadedListener listener, String leaderboardId, int span, int leaderboardCollection, int maxResults, boolean forceReload) {
        this.qm.b(new a.c<h.c>() { // from class: com.google.android.gms.games.GamesClient.3
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.c cVar) {
                listener.onLeaderboardScoresLoaded(cVar.getStatus().getStatusCode(), cVar.cO(), cVar.cP());
            }
        }, leaderboardId, span, leaderboardCollection, maxResults, forceReload);
    }

    public void loadTopScores(final OnLeaderboardScoresLoadedListener listener, String leaderboardId, int span, int leaderboardCollection, int maxResults) {
        this.qm.a(new a.c<h.c>() { // from class: com.google.android.gms.games.GamesClient.36
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.c cVar) {
                listener.onLeaderboardScoresLoaded(cVar.getStatus().getStatusCode(), cVar.cO(), cVar.cP());
            }
        }, leaderboardId, span, leaderboardCollection, maxResults, false);
    }

    public void loadTopScores(final OnLeaderboardScoresLoadedListener listener, String leaderboardId, int span, int leaderboardCollection, int maxResults, boolean forceReload) {
        this.qm.a(new a.c<h.c>() { // from class: com.google.android.gms.games.GamesClient.37
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.c cVar) {
                listener.onLeaderboardScoresLoaded(cVar.getStatus().getStatusCode(), cVar.cO(), cVar.cP());
            }
        }, leaderboardId, span, leaderboardCollection, maxResults, forceReload);
    }

    public void loadTurnBasedMatches(final OnTurnBasedMatchesLoadedListener listener, int... matchTurnStatuses) {
        this.qm.a(new a.c<b.e>() { // from class: com.google.android.gms.games.GamesClient.31
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.e eVar) {
                listener.onTurnBasedMatchesLoaded(eVar.getStatus().getStatusCode(), eVar.cU());
            }
        }, matchTurnStatuses);
    }

    public void reconnect() {
        this.qm.disconnect();
        this.qm.connect();
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        this.qm.registerConnectionCallbacks(listener);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        this.qm.registerConnectionFailedListener(listener);
    }

    public void registerInvitationListener(OnInvitationReceivedListener listener) {
        this.qm.registerInvitationListener(listener);
    }

    public void registerMatchUpdateListener(OnTurnBasedMatchUpdateReceivedListener listener) {
        this.qm.registerMatchUpdateListener(listener);
    }

    public void rematchTurnBasedMatch(final OnTurnBasedMatchInitiatedListener listener, String matchId) {
        this.qm.d(new a.c<b.InterfaceC0011b>() { // from class: com.google.android.gms.games.GamesClient.17
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.InterfaceC0011b interfaceC0011b) {
                listener.onTurnBasedMatchInitiated(interfaceC0011b.getStatus().getStatusCode(), interfaceC0011b.cT());
            }
        }, matchId);
    }

    public void revealAchievement(String id) {
        this.qm.b((a.c<b.InterfaceC0009b>) null, id);
    }

    public void revealAchievementImmediate(final OnAchievementUpdatedListener listener, String id) {
        this.qm.b(new a.c<b.InterfaceC0009b>() { // from class: com.google.android.gms.games.GamesClient.8
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.InterfaceC0009b interfaceC0009b) {
                listener.onAchievementUpdated(interfaceC0009b.getStatus().getStatusCode(), interfaceC0009b.getAchievementId());
            }
        }, id);
    }

    public int sendReliableRealTimeMessage(final RealTimeReliableMessageSentListener listener, byte[] messageData, String roomId, String recipientParticipantId) {
        return this.qm.a(new a.InterfaceC0010a() { // from class: com.google.android.gms.games.GamesClient.29
            @Override // com.google.android.gms.games.multiplayer.realtime.a.InterfaceC0010a
            public void onRealTimeMessageSent(int statusCode, int tokenId, String recipientParticipantId2) {
                listener.onRealTimeMessageSent(statusCode, tokenId, recipientParticipantId2);
            }
        }, messageData, roomId, recipientParticipantId);
    }

    public int sendUnreliableRealTimeMessage(byte[] messageData, String roomId, String recipientParticipantId) {
        return this.qm.a(messageData, roomId, new String[]{recipientParticipantId});
    }

    public int sendUnreliableRealTimeMessage(byte[] messageData, String roomId, List<String> recipientParticipantIds) {
        return this.qm.a(messageData, roomId, (String[]) recipientParticipantIds.toArray(new String[recipientParticipantIds.size()]));
    }

    public int sendUnreliableRealTimeMessageToAll(byte[] messageData, String roomId) {
        return this.qm.sendUnreliableRealTimeMessageToAll(messageData, roomId);
    }

    public void setAchievementSteps(String id, int numSteps) {
        this.qm.b(null, id, numSteps);
    }

    public void setAchievementStepsImmediate(final OnAchievementUpdatedListener listener, String id, int numSteps) {
        this.qm.b(new a.c<b.InterfaceC0009b>() { // from class: com.google.android.gms.games.GamesClient.11
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.InterfaceC0009b interfaceC0009b) {
                listener.onAchievementUpdated(interfaceC0009b.getStatus().getStatusCode(), interfaceC0009b.getAchievementId());
            }
        }, id, numSteps);
    }

    public void setGravityForPopups(int gravity) {
        this.qm.setGravityForPopups(gravity);
    }

    public void setViewForPopups(View gamesContentView) {
        du.f(gamesContentView);
        this.qm.setViewForPopups(gamesContentView);
    }

    public void signOut() {
        this.qm.b(new a.c<Status>() { // from class: com.google.android.gms.games.GamesClient.14
            @Override // com.google.android.gms.common.api.a.c
            public void a(Status status) {
            }
        });
    }

    public void signOut(final OnSignOutCompleteListener listener) {
        this.qm.b(new a.c<Status>() { // from class: com.google.android.gms.games.GamesClient.15
            @Override // com.google.android.gms.common.api.a.c
            public void a(Status status) {
                listener.onSignOutComplete();
            }
        });
    }

    public void submitScore(String leaderboardId, long score) {
        this.qm.a((a.c<h.d>) null, leaderboardId, score, (String) null);
    }

    public void submitScore(String leaderboardId, long score, String scoreTag) {
        this.qm.a((a.c<h.d>) null, leaderboardId, score, scoreTag);
    }

    public void submitScoreImmediate(final OnScoreSubmittedListener listener, String leaderboardId, long score) {
        this.qm.a(new a.c<h.d>() { // from class: com.google.android.gms.games.GamesClient.5
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.d dVar) {
                listener.onScoreSubmitted(dVar.getStatus().getStatusCode(), new SubmitScoreResult(dVar.cS().dl()));
            }
        }, leaderboardId, score, (String) null);
    }

    public void submitScoreImmediate(final OnScoreSubmittedListener listener, String leaderboardId, long score, String scoreTag) {
        this.qm.a(new a.c<h.d>() { // from class: com.google.android.gms.games.GamesClient.6
            @Override // com.google.android.gms.common.api.a.c
            public void a(h.d dVar) {
                listener.onScoreSubmitted(dVar.getStatus().getStatusCode(), new SubmitScoreResult(dVar.cS().dl()));
            }
        }, leaderboardId, score, scoreTag);
    }

    public void takeTurn(final OnTurnBasedMatchUpdatedListener listener, String matchId, byte[] matchData, String pendingParticipantId) {
        this.qm.a(new a.c<b.f>() { // from class: com.google.android.gms.games.GamesClient.19
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.f fVar) {
                listener.onTurnBasedMatchUpdated(fVar.getStatus().getStatusCode(), fVar.cT());
            }
        }, matchId, matchData, pendingParticipantId, (ParticipantResult[]) null);
    }

    public void takeTurn(final OnTurnBasedMatchUpdatedListener listener, String matchId, byte[] matchData, String pendingParticipantId, List<ParticipantResult> results) {
        this.qm.a(new a.c<b.f>() { // from class: com.google.android.gms.games.GamesClient.21
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.f fVar) {
                listener.onTurnBasedMatchUpdated(fVar.getStatus().getStatusCode(), fVar.cT());
            }
        }, matchId, matchData, pendingParticipantId, results == null ? null : (ParticipantResult[]) results.toArray(new ParticipantResult[results.size()]));
    }

    public void takeTurn(final OnTurnBasedMatchUpdatedListener listener, String matchId, byte[] matchData, String pendingParticipantId, ParticipantResult... results) {
        this.qm.a(new a.c<b.f>() { // from class: com.google.android.gms.games.GamesClient.20
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.f fVar) {
                listener.onTurnBasedMatchUpdated(fVar.getStatus().getStatusCode(), fVar.cT());
            }
        }, matchId, matchData, pendingParticipantId, results);
    }

    public void unlockAchievement(String id) {
        this.qm.c(null, id);
    }

    public void unlockAchievementImmediate(final OnAchievementUpdatedListener listener, String id) {
        this.qm.c(new a.c<b.InterfaceC0009b>() { // from class: com.google.android.gms.games.GamesClient.9
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.InterfaceC0009b interfaceC0009b) {
                listener.onAchievementUpdated(interfaceC0009b.getStatus().getStatusCode(), interfaceC0009b.getAchievementId());
            }
        }, id);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        this.qm.unregisterConnectionCallbacks(listener);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        this.qm.unregisterConnectionFailedListener(listener);
    }

    public void unregisterInvitationListener() {
        this.qm.unregisterInvitationListener();
    }

    public void unregisterMatchUpdateListener() {
        this.qm.unregisterMatchUpdateListener();
    }
}
