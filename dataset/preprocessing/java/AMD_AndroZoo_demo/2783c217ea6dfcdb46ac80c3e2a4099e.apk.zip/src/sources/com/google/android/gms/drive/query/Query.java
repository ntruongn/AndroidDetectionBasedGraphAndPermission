package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.internal.LogicalFilter;
import com.google.android.gms.drive.query.internal.Operator;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class Query implements SafeParcelable {
    public static final Parcelable.Creator<Query> CREATOR = new a();
    final int kZ;
    LogicalFilter pc;
    String pd;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class Builder {
        private String pd;
        private final List<Filter> pe = new ArrayList();

        public Builder addFilter(Filter filter) {
            this.pe.add(filter);
            return this;
        }

        public Query build() {
            return new Query(new LogicalFilter(Operator.pw, this.pe), this.pd);
        }

        public Builder setPageToken(String token) {
            this.pd = token;
            return this;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Query(int versionCode, LogicalFilter clause, String pageToken) {
        this.kZ = versionCode;
        this.pc = clause;
        this.pd = pageToken;
    }

    Query(LogicalFilter clause, String pageToken) {
        this(1, clause, pageToken);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public Filter getFilter() {
        return this.pc;
    }

    public String getPageToken() {
        return this.pd;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        a.a(this, out, flags);
    }
}
