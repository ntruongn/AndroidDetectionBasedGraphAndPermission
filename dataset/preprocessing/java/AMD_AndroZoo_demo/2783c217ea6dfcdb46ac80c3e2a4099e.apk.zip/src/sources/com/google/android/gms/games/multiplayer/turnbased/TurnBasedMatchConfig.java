package com.google.android.gms.games.multiplayer.turnbased;

import android.os.Bundle;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.internal.du;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class TurnBasedMatchConfig {
    private final String[] sN;
    private final Bundle sO;
    private final int sv;
    private final int ta;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class Builder {
        Bundle sO;
        ArrayList<String> sR;
        int sv;
        int ta;

        private Builder() {
            this.sv = -1;
            this.sR = new ArrayList<>();
            this.sO = null;
            this.ta = 2;
        }

        public Builder addInvitedPlayer(String playerId) {
            du.f(playerId);
            this.sR.add(playerId);
            return this;
        }

        public Builder addInvitedPlayers(ArrayList<String> playerIds) {
            du.f(playerIds);
            this.sR.addAll(playerIds);
            return this;
        }

        public TurnBasedMatchConfig build() {
            return new TurnBasedMatchConfig(this);
        }

        public Builder setAutoMatchCriteria(Bundle autoMatchCriteria) {
            this.sO = autoMatchCriteria;
            return this;
        }

        public Builder setMinPlayers(int minPlayers) {
            this.ta = minPlayers;
            return this;
        }

        public Builder setVariant(int variant) {
            du.b(variant == -1 || variant > 0, "Variant must be a positive integer or TurnBasedMatch.MATCH_VARIANT_ANY");
            this.sv = variant;
            return this;
        }
    }

    private TurnBasedMatchConfig(Builder builder) {
        this.sv = builder.sv;
        this.ta = builder.ta;
        this.sO = builder.sO;
        this.sN = (String[]) builder.sR.toArray(new String[builder.sR.size()]);
    }

    public static Builder builder() {
        return new Builder();
    }

    public static Bundle createAutoMatchCriteria(int minAutoMatchPlayers, int maxAutoMatchPlayers, long exclusiveBitMask) {
        Bundle bundle = new Bundle();
        bundle.putInt(GamesClient.EXTRA_MIN_AUTOMATCH_PLAYERS, minAutoMatchPlayers);
        bundle.putInt(GamesClient.EXTRA_MAX_AUTOMATCH_PLAYERS, maxAutoMatchPlayers);
        bundle.putLong(GamesClient.EXTRA_EXCLUSIVE_BIT_MASK, exclusiveBitMask);
        return bundle;
    }

    public Bundle getAutoMatchCriteria() {
        return this.sO;
    }

    public String[] getInvitedPlayerIds() {
        return this.sN;
    }

    public int getMinPlayers() {
        return this.ta;
    }

    public int getVariant() {
        return this.sv;
    }
}
