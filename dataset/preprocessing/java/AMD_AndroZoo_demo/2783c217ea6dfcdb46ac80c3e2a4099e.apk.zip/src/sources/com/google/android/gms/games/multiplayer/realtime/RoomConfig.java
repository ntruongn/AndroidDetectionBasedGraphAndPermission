package com.google.android.gms.games.multiplayer.realtime;

import android.os.Bundle;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.internal.du;
import java.util.ArrayList;
import java.util.Arrays;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class RoomConfig {
    private final String rc;
    private final RoomUpdateListener sK;
    private final RoomStatusUpdateListener sL;
    private final RealTimeMessageReceivedListener sM;
    private final String[] sN;
    private final Bundle sO;
    private final boolean sP;
    private final int sv;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class Builder {
        final RoomUpdateListener sK;
        RoomStatusUpdateListener sL;
        RealTimeMessageReceivedListener sM;
        Bundle sO;
        boolean sP;
        String sQ;
        ArrayList<String> sR;
        int sv;

        private Builder(RoomUpdateListener updateListener) {
            this.sQ = null;
            this.sv = -1;
            this.sR = new ArrayList<>();
            this.sP = false;
            this.sK = (RoomUpdateListener) du.c(updateListener, "Must provide a RoomUpdateListener");
        }

        public Builder addPlayersToInvite(ArrayList<String> playerIds) {
            du.f(playerIds);
            this.sR.addAll(playerIds);
            return this;
        }

        public Builder addPlayersToInvite(String... playerIds) {
            du.f(playerIds);
            this.sR.addAll(Arrays.asList(playerIds));
            return this;
        }

        public RoomConfig build() {
            return new RoomConfig(this);
        }

        public Builder setAutoMatchCriteria(Bundle autoMatchCriteria) {
            this.sO = autoMatchCriteria;
            return this;
        }

        public Builder setInvitationIdToAccept(String invitationId) {
            du.f(invitationId);
            this.sQ = invitationId;
            return this;
        }

        public Builder setMessageReceivedListener(RealTimeMessageReceivedListener listener) {
            this.sM = listener;
            return this;
        }

        public Builder setRoomStatusUpdateListener(RoomStatusUpdateListener listener) {
            this.sL = listener;
            return this;
        }

        public Builder setSocketCommunicationEnabled(boolean enableSockets) {
            this.sP = enableSockets;
            return this;
        }

        public Builder setVariant(int variant) {
            du.b(variant == -1 || variant > 0, "Variant must be a positive integer or Room.ROOM_VARIANT_ANY");
            this.sv = variant;
            return this;
        }
    }

    private RoomConfig(Builder builder) {
        this.sK = builder.sK;
        this.sL = builder.sL;
        this.sM = builder.sM;
        this.rc = builder.sQ;
        this.sv = builder.sv;
        this.sO = builder.sO;
        this.sP = builder.sP;
        this.sN = (String[]) builder.sR.toArray(new String[builder.sR.size()]);
        if (this.sM == null) {
            du.a(this.sP, "Must either enable sockets OR specify a message listener");
        }
    }

    public static Builder builder(RoomUpdateListener listener) {
        return new Builder(listener);
    }

    public static Bundle createAutoMatchCriteria(int minAutoMatchPlayers, int maxAutoMatchPlayers, long exclusiveBitMask) {
        Bundle bundle = new Bundle();
        bundle.putInt(GamesClient.EXTRA_MIN_AUTOMATCH_PLAYERS, minAutoMatchPlayers);
        bundle.putInt(GamesClient.EXTRA_MAX_AUTOMATCH_PLAYERS, maxAutoMatchPlayers);
        bundle.putLong(GamesClient.EXTRA_EXCLUSIVE_BIT_MASK, exclusiveBitMask);
        return bundle;
    }

    public Bundle getAutoMatchCriteria() {
        return this.sO;
    }

    public String getInvitationId() {
        return this.rc;
    }

    public String[] getInvitedPlayerIds() {
        return this.sN;
    }

    public RealTimeMessageReceivedListener getMessageReceivedListener() {
        return this.sM;
    }

    public RoomStatusUpdateListener getRoomStatusUpdateListener() {
        return this.sL;
    }

    public RoomUpdateListener getRoomUpdateListener() {
        return this.sK;
    }

    public int getVariant() {
        return this.sv;
    }

    public boolean isSocketEnabled() {
        return this.sP;
    }
}
