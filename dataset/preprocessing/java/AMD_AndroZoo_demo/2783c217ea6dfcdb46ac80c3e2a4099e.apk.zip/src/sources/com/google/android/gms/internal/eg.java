package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.eh;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class eg implements Parcelable.Creator<eh.b> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(eh.b bVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, bVar.versionCode);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, bVar.nL, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, (Parcelable) bVar.nM, i, false);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: F, reason: merged with bridge method [inline-methods] */
    public eh.b[] newArray(int i) {
        return new eh.b[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: q, reason: merged with bridge method [inline-methods] */
    public eh.b createFromParcel(Parcel parcel) {
        ee.a aVar = null;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 2:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    break;
                case 3:
                    aVar = (ee.a) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, ee.a.CREATOR);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new eh.b(i, str, aVar);
    }
}
