package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.dp;
import com.google.android.gms.internal.dq;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class dk<T extends IInterface> implements GooglePlayServicesClient, Api.a, dl.b {
    public static final String[] mG = {"service_esmobile", "service_googleme"};
    private final String[] jC;
    private final dl kB;
    private T mA;
    private dk<T>.e mC;
    private final Context mContext;
    final Handler mHandler;
    private final ArrayList<dk<T>.b<?>> mB = new ArrayList<>();
    boolean mD = false;
    boolean mE = false;
    private final Object mF = new Object();

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class a extends Handler {
        public a(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (msg.what == 1 && !dk.this.isConnecting()) {
                b bVar = (b) msg.obj;
                bVar.aQ();
                bVar.unregister();
                return;
            }
            synchronized (dk.this.mF) {
                dk.this.mE = false;
            }
            if (msg.what == 3) {
                dk.this.kB.a(new ConnectionResult(((Integer) msg.obj).intValue(), null));
                return;
            }
            if (msg.what == 2 && !dk.this.isConnected()) {
                b bVar2 = (b) msg.obj;
                bVar2.aQ();
                bVar2.unregister();
            } else if (msg.what == 2 || msg.what == 1) {
                ((b) msg.obj).bD();
            } else {
                Log.wtf("GmsClient", "Don't know how to handle this message.");
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    protected abstract class b<TListener> {
        private boolean mI = false;
        private TListener mListener;

        public b(TListener tlistener) {
            this.mListener = tlistener;
        }

        protected abstract void aQ();

        protected abstract void b(TListener tlistener);

        public void bD() {
            TListener tlistener;
            synchronized (this) {
                tlistener = this.mListener;
                if (this.mI) {
                    Log.w("GmsClient", "Callback proxy " + this + " being reused. This is not safe.");
                }
            }
            if (tlistener != null) {
                try {
                    b(tlistener);
                } catch (RuntimeException e) {
                    aQ();
                    throw e;
                }
            } else {
                aQ();
            }
            synchronized (this) {
                this.mI = true;
            }
            unregister();
        }

        public void bE() {
            synchronized (this) {
                this.mListener = null;
            }
        }

        public void unregister() {
            bE();
            synchronized (dk.this.mB) {
                dk.this.mB.remove(this);
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public abstract class c<TListener> extends dk<T>.b<TListener> {
        private final DataHolder lb;

        public c(TListener tlistener, DataHolder dataHolder) {
            super(tlistener);
            this.lb = dataHolder;
        }

        protected abstract void a(TListener tlistener, DataHolder dataHolder);

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
            if (this.lb != null) {
                this.lb.close();
            }
        }

        @Override // com.google.android.gms.internal.dk.b
        protected final void b(TListener tlistener) {
            a(tlistener, this.lb);
        }

        @Override // com.google.android.gms.internal.dk.b
        public /* bridge */ /* synthetic */ void bD() {
            super.bD();
        }

        @Override // com.google.android.gms.internal.dk.b
        public /* bridge */ /* synthetic */ void bE() {
            super.bE();
        }

        @Override // com.google.android.gms.internal.dk.b
        public /* bridge */ /* synthetic */ void unregister() {
            super.unregister();
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class d extends dp.a {
        private dk mJ;

        public d(dk dkVar) {
            this.mJ = dkVar;
        }

        @Override // com.google.android.gms.internal.dp
        public void b(int i, IBinder iBinder, Bundle bundle) {
            du.c("onPostInitComplete can be called only once per call to getServiceFromBroker", this.mJ);
            this.mJ.a(i, iBinder, bundle);
            this.mJ = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class e implements ServiceConnection {
        e() {
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName component, IBinder binder) {
            dk.this.u(binder);
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName component) {
            dk.this.mA = null;
            dk.this.kB.bG();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class f extends dk<T>.b<Boolean> {
        public final Bundle mK;
        public final IBinder mL;
        public final int statusCode;

        public f(int i, IBinder iBinder, Bundle bundle) {
            super(true);
            this.statusCode = i;
            this.mL = iBinder;
            this.mK = bundle;
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        public void b(Boolean bool) {
            if (bool == null) {
                return;
            }
            switch (this.statusCode) {
                case 0:
                    try {
                        if (dk.this.an().equals(this.mL.getInterfaceDescriptor())) {
                            dk.this.mA = dk.this.p(this.mL);
                            if (dk.this.mA != null) {
                                dk.this.kB.bF();
                                return;
                            }
                        }
                    } catch (RemoteException e) {
                    }
                    dm.s(dk.this.mContext).b(dk.this.am(), dk.this.mC);
                    dk.this.mC = null;
                    dk.this.mA = null;
                    dk.this.kB.a(new ConnectionResult(8, null));
                    return;
                case 10:
                    throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");
                default:
                    PendingIntent pendingIntent = this.mK != null ? (PendingIntent) this.mK.getParcelable("pendingIntent") : null;
                    if (dk.this.mC != null) {
                        dm.s(dk.this.mContext).b(dk.this.am(), dk.this.mC);
                        dk.this.mC = null;
                    }
                    dk.this.mA = null;
                    dk.this.kB.a(new ConnectionResult(this.statusCode, pendingIntent));
                    return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public dk(Context context, GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener, String... strArr) {
        this.mContext = (Context) du.f(context);
        this.kB = new dl(context, this, null);
        this.mHandler = new a(context.getMainLooper());
        a(strArr);
        this.jC = strArr;
        registerConnectionCallbacks((GooglePlayServicesClient.ConnectionCallbacks) du.f(connectionCallbacks));
        registerConnectionFailedListener((GooglePlayServicesClient.OnConnectionFailedListener) du.f(onConnectionFailedListener));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a(int i, IBinder iBinder, Bundle bundle) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(1, new f(i, iBinder, bundle)));
    }

    public final void a(dk<T>.b<?> bVar) {
        synchronized (this.mB) {
            this.mB.add(bVar);
        }
        this.mHandler.sendMessage(this.mHandler.obtainMessage(2, bVar));
    }

    protected abstract void a(dq dqVar, d dVar) throws RemoteException;

    protected void a(String... strArr) {
    }

    protected abstract String am();

    protected abstract String an();

    public final String[] bA() {
        return this.jC;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void bB() {
        if (!isConnected()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final T bC() {
        bB();
        return this.mA;
    }

    @Override // com.google.android.gms.internal.dl.b
    public boolean bb() {
        return this.mD;
    }

    @Override // com.google.android.gms.internal.dl.b
    public Bundle bc() {
        return null;
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void connect() {
        this.mD = true;
        synchronized (this.mF) {
            this.mE = true;
        }
        int isGooglePlayServicesAvailable = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this.mContext);
        if (isGooglePlayServicesAvailable != 0) {
            this.mHandler.sendMessage(this.mHandler.obtainMessage(3, Integer.valueOf(isGooglePlayServicesAvailable)));
            return;
        }
        if (this.mC != null) {
            Log.e("GmsClient", "Calling connect() while still connected, missing disconnect().");
            this.mA = null;
            dm.s(this.mContext).b(am(), this.mC);
        }
        this.mC = new e();
        if (dm.s(this.mContext).a(am(), this.mC)) {
            return;
        }
        Log.e("GmsClient", "unable to connect to service: " + am());
        this.mHandler.sendMessage(this.mHandler.obtainMessage(3, 9));
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void disconnect() {
        this.mD = false;
        synchronized (this.mF) {
            this.mE = false;
        }
        synchronized (this.mB) {
            int size = this.mB.size();
            for (int i = 0; i < size; i++) {
                this.mB.get(i).bE();
            }
            this.mB.clear();
        }
        this.mA = null;
        if (this.mC != null) {
            dm.s(this.mContext).b(am(), this.mC);
            this.mC = null;
        }
    }

    public final Context getContext() {
        return this.mContext;
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnected() {
        return this.mA != null;
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnecting() {
        boolean z;
        synchronized (this.mF) {
            z = this.mE;
        }
        return z;
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks listener) {
        return this.kB.isConnectionCallbacksRegistered(listener);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        return this.kB.isConnectionFailedListenerRegistered(listener);
    }

    protected abstract T p(IBinder iBinder);

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        this.kB.registerConnectionCallbacks(listener);
    }

    public void registerConnectionCallbacks(GoogleApiClient.ConnectionCallbacks listener) {
        this.kB.registerConnectionCallbacks(listener);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        this.kB.registerConnectionFailedListener(listener);
    }

    public void registerConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener listener) {
        this.kB.registerConnectionFailedListener(listener);
    }

    protected final void u(IBinder iBinder) {
        try {
            a(dq.a.w(iBinder), new d(this));
        } catch (RemoteException e2) {
            Log.w("GmsClient", "service died");
        }
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        this.kB.unregisterConnectionCallbacks(listener);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        this.kB.unregisterConnectionFailedListener(listener);
    }
}
