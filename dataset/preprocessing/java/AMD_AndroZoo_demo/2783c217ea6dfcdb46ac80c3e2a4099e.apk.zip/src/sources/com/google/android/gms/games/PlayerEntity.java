package com.google.android.gms.games;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.dg;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.eo;
import com.google.android.gms.internal.ey;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class PlayerEntity extends ey implements Player {
    public static final Parcelable.Creator<PlayerEntity> CREATOR = new a();
    private final int kZ;
    private final String pW;
    private final String qK;
    private final long qL;
    private final Uri qb;
    private final Uri qc;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    static final class a extends d {
        a() {
        }

        @Override // com.google.android.gms.games.d, android.os.Parcelable.Creator
        /* renamed from: V */
        public PlayerEntity createFromParcel(Parcel parcel) {
            if (PlayerEntity.c(PlayerEntity.cH()) || PlayerEntity.D(PlayerEntity.class.getCanonicalName())) {
                return super.createFromParcel(parcel);
            }
            String readString = parcel.readString();
            String readString2 = parcel.readString();
            String readString3 = parcel.readString();
            String readString4 = parcel.readString();
            return new PlayerEntity(1, readString, readString2, readString3 == null ? null : Uri.parse(readString3), readString4 != null ? Uri.parse(readString4) : null, parcel.readLong());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public PlayerEntity(int versionCode, String playerId, String displayName, Uri iconImageUri, Uri hiResImageUri, long retrievedTimestamp) {
        this.kZ = versionCode;
        this.qK = playerId;
        this.pW = displayName;
        this.qb = iconImageUri;
        this.qc = hiResImageUri;
        this.qL = retrievedTimestamp;
    }

    public PlayerEntity(Player player) {
        this.kZ = 1;
        this.qK = player.getPlayerId();
        this.pW = player.getDisplayName();
        this.qb = player.getIconImageUri();
        this.qc = player.getHiResImageUri();
        this.qL = player.getRetrievedTimestamp();
        dg.d(this.qK);
        dg.d(this.pW);
        dg.n(this.qL > 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int a(Player player) {
        return ds.hashCode(player.getPlayerId(), player.getDisplayName(), player.getIconImageUri(), player.getHiResImageUri(), Long.valueOf(player.getRetrievedTimestamp()));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a(Player player, Object obj) {
        if (!(obj instanceof Player)) {
            return false;
        }
        if (player == obj) {
            return true;
        }
        Player player2 = (Player) obj;
        return ds.equal(player2.getPlayerId(), player.getPlayerId()) && ds.equal(player2.getDisplayName(), player.getDisplayName()) && ds.equal(player2.getIconImageUri(), player.getIconImageUri()) && ds.equal(player2.getHiResImageUri(), player.getHiResImageUri()) && ds.equal(Long.valueOf(player2.getRetrievedTimestamp()), Long.valueOf(player.getRetrievedTimestamp()));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String b(Player player) {
        return ds.e(player).a("PlayerId", player.getPlayerId()).a("DisplayName", player.getDisplayName()).a("IconImageUri", player.getIconImageUri()).a("HiResImageUri", player.getHiResImageUri()).a("RetrievedTimestamp", Long.valueOf(player.getRetrievedTimestamp())).toString();
    }

    static /* synthetic */ Integer cH() {
        return by();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.google.android.gms.common.data.Freezable
    public Player freeze() {
        return this;
    }

    @Override // com.google.android.gms.games.Player
    public String getDisplayName() {
        return this.pW;
    }

    @Override // com.google.android.gms.games.Player
    public void getDisplayName(CharArrayBuffer dataOut) {
        eo.b(this.pW, dataOut);
    }

    @Override // com.google.android.gms.games.Player
    public Uri getHiResImageUri() {
        return this.qc;
    }

    @Override // com.google.android.gms.games.Player
    public Uri getIconImageUri() {
        return this.qb;
    }

    @Override // com.google.android.gms.games.Player
    public String getPlayerId() {
        return this.qK;
    }

    @Override // com.google.android.gms.games.Player
    public long getRetrievedTimestamp() {
        return this.qL;
    }

    public int getVersionCode() {
        return this.kZ;
    }

    @Override // com.google.android.gms.games.Player
    public boolean hasHiResImage() {
        return getHiResImageUri() != null;
    }

    @Override // com.google.android.gms.games.Player
    public boolean hasIconImage() {
        return getIconImageUri() != null;
    }

    public int hashCode() {
        return a(this);
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        return b(this);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        if (!bz()) {
            d.a(this, dest, flags);
            return;
        }
        dest.writeString(this.qK);
        dest.writeString(this.pW);
        dest.writeString(this.qb == null ? null : this.qb.toString());
        dest.writeString(this.qc != null ? this.qc.toString() : null);
        dest.writeLong(this.qL);
    }
}
