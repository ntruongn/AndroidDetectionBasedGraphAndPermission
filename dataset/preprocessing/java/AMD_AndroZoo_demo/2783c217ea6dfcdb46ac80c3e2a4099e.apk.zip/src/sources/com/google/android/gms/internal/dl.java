package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class dl {
    private final Handler mHandler;
    private final b mM;
    private ArrayList<GooglePlayServicesClient.ConnectionCallbacks> mN;
    final ArrayList<GooglePlayServicesClient.ConnectionCallbacks> mO;
    private boolean mP;
    private ArrayList<GooglePlayServicesClient.OnConnectionFailedListener> mQ;
    private boolean mR;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class a extends Handler {
        public a(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (msg.what != 1) {
                Log.wtf("GmsClientEvents", "Don't know how to handle this message.");
                return;
            }
            synchronized (dl.this.mN) {
                if (dl.this.mM.bb() && dl.this.mM.isConnected() && dl.this.mN.contains(msg.obj)) {
                    ((GooglePlayServicesClient.ConnectionCallbacks) msg.obj).onConnected(dl.this.mM.bc());
                }
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface b {
        boolean bb();

        Bundle bc();

        boolean isConnected();
    }

    public dl(Context context, b bVar) {
        this(context, bVar, null);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public dl(Context context, b bVar, Handler handler) {
        this.mO = new ArrayList<>();
        this.mP = false;
        this.mR = false;
        handler = handler == null ? new a(Looper.getMainLooper()) : handler;
        this.mN = new ArrayList<>();
        this.mQ = new ArrayList<>();
        this.mM = bVar;
        this.mHandler = handler;
    }

    public void a(ConnectionResult connectionResult) {
        this.mHandler.removeMessages(1);
        synchronized (this.mQ) {
            this.mR = true;
            ArrayList<GooglePlayServicesClient.OnConnectionFailedListener> arrayList = this.mQ;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                if (!this.mM.bb()) {
                    return;
                }
                if (this.mQ.contains(arrayList.get(i))) {
                    arrayList.get(i).onConnectionFailed(connectionResult);
                }
            }
            this.mR = false;
        }
    }

    public void b(Bundle bundle) {
        synchronized (this.mN) {
            du.n(!this.mP);
            this.mHandler.removeMessages(1);
            this.mP = true;
            du.n(this.mO.size() == 0);
            ArrayList<GooglePlayServicesClient.ConnectionCallbacks> arrayList = this.mN;
            int size = arrayList.size();
            for (int i = 0; i < size && this.mM.bb() && this.mM.isConnected(); i++) {
                this.mO.size();
                if (!this.mO.contains(arrayList.get(i))) {
                    arrayList.get(i).onConnected(bundle);
                }
            }
            this.mO.clear();
            this.mP = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void bF() {
        synchronized (this.mN) {
            b(this.mM.bc());
        }
    }

    public void bG() {
        this.mHandler.removeMessages(1);
        synchronized (this.mN) {
            this.mP = true;
            ArrayList<GooglePlayServicesClient.ConnectionCallbacks> arrayList = this.mN;
            int size = arrayList.size();
            for (int i = 0; i < size && this.mM.bb(); i++) {
                if (this.mN.contains(arrayList.get(i))) {
                    arrayList.get(i).onDisconnected();
                }
            }
            this.mP = false;
        }
    }

    public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks listener) {
        boolean contains;
        du.f(listener);
        synchronized (this.mN) {
            contains = this.mN.contains(listener);
        }
        return contains;
    }

    public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        boolean contains;
        du.f(listener);
        synchronized (this.mQ) {
            contains = this.mQ.contains(listener);
        }
        return contains;
    }

    public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        du.f(listener);
        synchronized (this.mN) {
            if (this.mN.contains(listener)) {
                Log.w("GmsClientEvents", "registerConnectionCallbacks(): listener " + listener + " is already registered");
            } else {
                if (this.mP) {
                    this.mN = new ArrayList<>(this.mN);
                }
                this.mN.add(listener);
            }
        }
        if (this.mM.isConnected()) {
            this.mHandler.sendMessage(this.mHandler.obtainMessage(1, listener));
        }
    }

    public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        du.f(listener);
        synchronized (this.mQ) {
            if (this.mQ.contains(listener)) {
                Log.w("GmsClientEvents", "registerConnectionFailedListener(): listener " + listener + " is already registered");
            } else {
                if (this.mR) {
                    this.mQ = new ArrayList<>(this.mQ);
                }
                this.mQ.add(listener);
            }
        }
    }

    public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        du.f(listener);
        synchronized (this.mN) {
            if (this.mN != null) {
                if (this.mP) {
                    this.mN = new ArrayList<>(this.mN);
                }
                if (!this.mN.remove(listener)) {
                    Log.w("GmsClientEvents", "unregisterConnectionCallbacks(): listener " + listener + " not found");
                } else if (this.mP && !this.mO.contains(listener)) {
                    this.mO.add(listener);
                }
            }
        }
    }

    public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        du.f(listener);
        synchronized (this.mQ) {
            if (this.mQ != null) {
                if (this.mR) {
                    this.mQ = new ArrayList<>(this.mQ);
                }
                if (!this.mQ.remove(listener)) {
                    Log.w("GmsClientEvents", "unregisterConnectionFailedListener(): listener " + listener + " not found");
                }
            }
        }
    }
}
