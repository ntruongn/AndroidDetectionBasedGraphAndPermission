package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class ee {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class a<I, O> implements SafeParcelable {
        public static final ef CREATOR = new ef();
        private final int kZ;
        protected final boolean nA;
        protected final String nB;
        protected final int nC;
        protected final Class<? extends ee> nD;
        protected final String nE;
        private eh nF;
        private b<I, O> nG;
        protected final int nx;
        protected final boolean ny;
        protected final int nz;

        /* JADX INFO: Access modifiers changed from: package-private */
        public a(int i, int i2, boolean z, int i3, boolean z2, String str, int i4, String str2, dz dzVar) {
            this.kZ = i;
            this.nx = i2;
            this.ny = z;
            this.nz = i3;
            this.nA = z2;
            this.nB = str;
            this.nC = i4;
            if (str2 == null) {
                this.nD = null;
                this.nE = null;
            } else {
                this.nD = ek.class;
                this.nE = str2;
            }
            if (dzVar == null) {
                this.nG = null;
            } else {
                this.nG = (b<I, O>) dzVar.bM();
            }
        }

        protected a(int i, boolean z, int i2, boolean z2, String str, int i3, Class<? extends ee> cls, b<I, O> bVar) {
            this.kZ = 1;
            this.nx = i;
            this.ny = z;
            this.nz = i2;
            this.nA = z2;
            this.nB = str;
            this.nC = i3;
            this.nD = cls;
            if (cls == null) {
                this.nE = null;
            } else {
                this.nE = cls.getCanonicalName();
            }
            this.nG = bVar;
        }

        public static a a(String str, int i, b<?, ?> bVar, boolean z) {
            return new a(bVar.bO(), z, bVar.bP(), false, str, i, null, bVar);
        }

        public static <T extends ee> a<T, T> a(String str, int i, Class<T> cls) {
            return new a<>(11, false, 11, false, str, i, cls, null);
        }

        public static <T extends ee> a<ArrayList<T>, ArrayList<T>> b(String str, int i, Class<T> cls) {
            return new a<>(11, true, 11, true, str, i, cls, null);
        }

        public static a<Integer, Integer> c(String str, int i) {
            return new a<>(0, false, 0, false, str, i, null, null);
        }

        public static a<Double, Double> d(String str, int i) {
            return new a<>(4, false, 4, false, str, i, null, null);
        }

        public static a<Boolean, Boolean> e(String str, int i) {
            return new a<>(6, false, 6, false, str, i, null, null);
        }

        public static a<String, String> f(String str, int i) {
            return new a<>(7, false, 7, false, str, i, null, null);
        }

        public static a<ArrayList<String>, ArrayList<String>> g(String str, int i) {
            return new a<>(7, true, 7, true, str, i, null, null);
        }

        public void a(eh ehVar) {
            this.nF = ehVar;
        }

        public int bO() {
            return this.nx;
        }

        public int bP() {
            return this.nz;
        }

        public a<I, O> bT() {
            return new a<>(this.kZ, this.nx, this.ny, this.nz, this.nA, this.nB, this.nC, this.nE, cb());
        }

        public boolean bU() {
            return this.ny;
        }

        public boolean bV() {
            return this.nA;
        }

        public String bW() {
            return this.nB;
        }

        public int bX() {
            return this.nC;
        }

        public Class<? extends ee> bY() {
            return this.nD;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String bZ() {
            if (this.nE == null) {
                return null;
            }
            return this.nE;
        }

        public boolean ca() {
            return this.nG != null;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public dz cb() {
            if (this.nG == null) {
                return null;
            }
            return dz.a(this.nG);
        }

        public HashMap<String, a<?, ?>> cc() {
            du.f(this.nE);
            du.f(this.nF);
            return this.nF.N(this.nE);
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            ef efVar = CREATOR;
            return 0;
        }

        public I g(O o) {
            return this.nG.g(o);
        }

        public int getVersionCode() {
            return this.kZ;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Field\n");
            sb.append("            versionCode=").append(this.kZ).append('\n');
            sb.append("                 typeIn=").append(this.nx).append('\n');
            sb.append("            typeInArray=").append(this.ny).append('\n');
            sb.append("                typeOut=").append(this.nz).append('\n');
            sb.append("           typeOutArray=").append(this.nA).append('\n');
            sb.append("        outputFieldName=").append(this.nB).append('\n');
            sb.append("      safeParcelFieldId=").append(this.nC).append('\n');
            sb.append("       concreteTypeName=").append(bZ()).append('\n');
            if (bY() != null) {
                sb.append("     concreteType.class=").append(bY().getCanonicalName()).append('\n');
            }
            sb.append("          converterName=").append(this.nG == null ? "null" : this.nG.getClass().getCanonicalName()).append('\n');
            return sb.toString();
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            ef efVar = CREATOR;
            ef.a(this, out, flags);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface b<I, O> {
        int bO();

        int bP();

        I g(O o);
    }

    private void a(StringBuilder sb, a aVar, Object obj) {
        if (aVar.bO() == 11) {
            sb.append(aVar.bY().cast(obj).toString());
        } else {
            if (aVar.bO() != 7) {
                sb.append(obj);
                return;
            }
            sb.append("\"");
            sb.append(eq.O((String) obj));
            sb.append("\"");
        }
    }

    private void a(StringBuilder sb, a aVar, ArrayList<Object> arrayList) {
        sb.append("[");
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (i > 0) {
                sb.append(",");
            }
            Object obj = arrayList.get(i);
            if (obj != null) {
                a(sb, aVar, obj);
            }
        }
        sb.append("]");
    }

    protected abstract Object J(String str);

    protected abstract boolean K(String str);

    protected boolean L(String str) {
        throw new UnsupportedOperationException("Concrete types not supported");
    }

    protected boolean M(String str) {
        throw new UnsupportedOperationException("Concrete type arrays not supported");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Multi-variable type inference failed */
    public <O, I> I a(a<I, O> aVar, Object obj) {
        return ((a) aVar).nG != null ? aVar.g(obj) : obj;
    }

    protected boolean a(a aVar) {
        return aVar.bP() == 11 ? aVar.bV() ? M(aVar.bW()) : L(aVar.bW()) : K(aVar.bW());
    }

    protected Object b(a aVar) {
        String bW = aVar.bW();
        if (aVar.bY() == null) {
            return J(aVar.bW());
        }
        du.a(J(aVar.bW()) == null, "Concrete field shouldn't be value object: " + aVar.bW());
        HashMap<String, Object> bS = aVar.bV() ? bS() : bR();
        if (bS != null) {
            return bS.get(bW);
        }
        try {
            return getClass().getMethod("get" + Character.toUpperCase(bW.charAt(0)) + bW.substring(1), new Class[0]).invoke(this, new Object[0]);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public abstract HashMap<String, a<?, ?>> bQ();

    public HashMap<String, Object> bR() {
        return null;
    }

    public HashMap<String, Object> bS() {
        return null;
    }

    public String toString() {
        HashMap<String, a<?, ?>> bQ = bQ();
        StringBuilder sb = new StringBuilder(100);
        for (String str : bQ.keySet()) {
            a<?, ?> aVar = bQ.get(str);
            if (a(aVar)) {
                Object a2 = a(aVar, b(aVar));
                if (sb.length() == 0) {
                    sb.append("{");
                } else {
                    sb.append(",");
                }
                sb.append("\"").append(str).append("\":");
                if (a2 != null) {
                    switch (aVar.bP()) {
                        case 8:
                            sb.append("\"").append(en.b((byte[]) a2)).append("\"");
                            break;
                        case 9:
                            sb.append("\"").append(en.c((byte[]) a2)).append("\"");
                            break;
                        case 10:
                            er.a(sb, (HashMap) a2);
                            break;
                        default:
                            if (aVar.bU()) {
                                a(sb, (a) aVar, (ArrayList<Object>) a2);
                                break;
                            } else {
                                a(sb, aVar, a2);
                                break;
                            }
                    }
                } else {
                    sb.append("null");
                }
            }
        }
        if (sb.length() > 0) {
            sb.append("}");
        } else {
            sb.append("{}");
        }
        return sb.toString();
    }
}
