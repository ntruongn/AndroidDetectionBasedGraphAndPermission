package com.google.android.gms.internal;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class bh {
    public static boolean a(Context context, bj bjVar, bq bqVar) {
        if (bjVar == null) {
            cs.v("No intent data for launcher overlay.");
            return false;
        }
        Intent intent = new Intent();
        if (TextUtils.isEmpty(bjVar.gn)) {
            cs.v("Open GMSG did not contain a URL.");
            return false;
        }
        if (TextUtils.isEmpty(bjVar.mimeType)) {
            intent.setData(Uri.parse(bjVar.gn));
        } else {
            intent.setDataAndType(Uri.parse(bjVar.gn), bjVar.mimeType);
        }
        intent.setAction("android.intent.action.VIEW");
        if (!TextUtils.isEmpty(bjVar.packageName)) {
            intent.setPackage(bjVar.packageName);
        }
        if (!TextUtils.isEmpty(bjVar.go)) {
            String[] split = bjVar.go.split("/", 2);
            if (split.length < 2) {
                cs.v("Could not parse component name from open GMSG: " + bjVar.go);
                return false;
            }
            intent.setClassName(split[0], split[1]);
        }
        try {
            cs.u("Launching an intent: " + intent);
            context.startActivity(intent);
            bqVar.z();
            return true;
        } catch (ActivityNotFoundException e) {
            cs.v(e.getMessage());
            return false;
        }
    }
}
