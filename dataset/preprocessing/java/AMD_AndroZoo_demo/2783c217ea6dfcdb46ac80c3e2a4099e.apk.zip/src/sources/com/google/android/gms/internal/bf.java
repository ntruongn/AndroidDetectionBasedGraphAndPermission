package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.ads.AdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class bf<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> implements MediationBannerListener, MediationInterstitialListener {
    private final bd gh;

    public bf(bd bdVar) {
        this.gh = bdVar;
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onClick(MediationBannerAdapter<?, ?> adapter) {
        cs.r("Adapter called onClick.");
        if (!cr.ax()) {
            cs.v("onClick must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.w();
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdClicked.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.w();
            } catch (RemoteException e) {
                cs.b("Could not call onAdClicked.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onDismissScreen(MediationBannerAdapter<?, ?> adapter) {
        cs.r("Adapter called onDismissScreen.");
        if (!cr.ax()) {
            cs.v("onDismissScreen must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.4
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdClosed();
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdClosed.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdClosed();
            } catch (RemoteException e) {
                cs.b("Could not call onAdClosed.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onDismissScreen(MediationInterstitialAdapter<?, ?> adapter) {
        cs.r("Adapter called onDismissScreen.");
        if (!cr.ax()) {
            cs.v("onDismissScreen must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.9
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdClosed();
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdClosed.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdClosed();
            } catch (RemoteException e) {
                cs.b("Could not call onAdClosed.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onFailedToReceiveAd(MediationBannerAdapter<?, ?> adapter, final AdRequest.ErrorCode errorCode) {
        cs.r("Adapter called onFailedToReceiveAd with error. " + errorCode);
        if (!cr.ax()) {
            cs.v("onFailedToReceiveAd must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.5
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdFailedToLoad(bg.a(errorCode));
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdFailedToLoad.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdFailedToLoad(bg.a(errorCode));
            } catch (RemoteException e) {
                cs.b("Could not call onAdFailedToLoad.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onFailedToReceiveAd(MediationInterstitialAdapter<?, ?> adapter, final AdRequest.ErrorCode errorCode) {
        cs.r("Adapter called onFailedToReceiveAd with error " + errorCode + ".");
        if (!cr.ax()) {
            cs.v("onFailedToReceiveAd must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.10
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdFailedToLoad(bg.a(errorCode));
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdFailedToLoad.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdFailedToLoad(bg.a(errorCode));
            } catch (RemoteException e) {
                cs.b("Could not call onAdFailedToLoad.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onLeaveApplication(MediationBannerAdapter<?, ?> adapter) {
        cs.r("Adapter called onLeaveApplication.");
        if (!cr.ax()) {
            cs.v("onLeaveApplication must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.6
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdLeftApplication();
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdLeftApplication.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdLeftApplication();
            } catch (RemoteException e) {
                cs.b("Could not call onAdLeftApplication.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onLeaveApplication(MediationInterstitialAdapter<?, ?> adapter) {
        cs.r("Adapter called onLeaveApplication.");
        if (!cr.ax()) {
            cs.v("onLeaveApplication must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.11
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdLeftApplication();
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdLeftApplication.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdLeftApplication();
            } catch (RemoteException e) {
                cs.b("Could not call onAdLeftApplication.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onPresentScreen(MediationBannerAdapter<?, ?> adapter) {
        cs.r("Adapter called onPresentScreen.");
        if (!cr.ax()) {
            cs.v("onPresentScreen must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.7
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdOpened();
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdOpened.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdOpened();
            } catch (RemoteException e) {
                cs.b("Could not call onAdOpened.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onPresentScreen(MediationInterstitialAdapter<?, ?> adapter) {
        cs.r("Adapter called onPresentScreen.");
        if (!cr.ax()) {
            cs.v("onPresentScreen must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.2
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdOpened();
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdOpened.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdOpened();
            } catch (RemoteException e) {
                cs.b("Could not call onAdOpened.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onReceivedAd(MediationBannerAdapter<?, ?> adapter) {
        cs.r("Adapter called onReceivedAd.");
        if (!cr.ax()) {
            cs.v("onReceivedAd must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.8
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdLoaded();
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdLoaded.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdLoaded();
            } catch (RemoteException e) {
                cs.b("Could not call onAdLoaded.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onReceivedAd(MediationInterstitialAdapter<?, ?> adapter) {
        cs.r("Adapter called onReceivedAd.");
        if (!cr.ax()) {
            cs.v("onReceivedAd must be called on the main UI thread.");
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bf.3
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gh.onAdLoaded();
                    } catch (RemoteException e) {
                        cs.b("Could not call onAdLoaded.", e);
                    }
                }
            });
        } else {
            try {
                this.gh.onAdLoaded();
            } catch (RemoteException e) {
                cs.b("Could not call onAdLoaded.", e);
            }
        }
    }
}
