package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.query.Filters;
import com.google.android.gms.drive.query.Query;
import com.google.android.gms.drive.query.SearchableField;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class l extends m implements DriveFolder {

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class a extends com.google.android.gms.drive.internal.a {
        private final a.c<DriveFolder.DriveFileResult> jN;

        public a(a.c<DriveFolder.DriveFileResult> cVar) {
            this.jN = cVar;
        }

        @Override // com.google.android.gms.drive.internal.a, com.google.android.gms.drive.internal.p
        public void a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.jN.a(new d(Status.kW, new k(onDriveIdResponse.getDriveId())));
        }

        @Override // com.google.android.gms.drive.internal.a, com.google.android.gms.drive.internal.p
        public void d(Status status) throws RemoteException {
            this.jN.a(new d(status, null));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class b extends com.google.android.gms.drive.internal.a {
        private final a.c<DriveFolder.DriveFolderResult> jN;

        public b(a.c<DriveFolder.DriveFolderResult> cVar) {
            this.jN = cVar;
        }

        @Override // com.google.android.gms.drive.internal.a, com.google.android.gms.drive.internal.p
        public void a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.jN.a(new e(Status.kW, new l(onDriveIdResponse.getDriveId())));
        }

        @Override // com.google.android.gms.drive.internal.a, com.google.android.gms.drive.internal.p
        public void d(Status status) throws RemoteException {
            this.jN.a(new e(status, null));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private abstract class c extends i<DriveFolder.DriveFolderResult, DriveFolder.OnCreateFolderCallback> {
        private c() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.common.api.a.AbstractC0001a
        public void a(DriveFolder.OnCreateFolderCallback onCreateFolderCallback, DriveFolder.DriveFolderResult driveFolderResult) {
            onCreateFolderCallback.onCreateFolder(driveFolderResult);
        }

        @Override // com.google.android.gms.common.api.PendingResult
        /* renamed from: i, reason: merged with bridge method [inline-methods] */
        public DriveFolder.DriveFolderResult b(Status status) {
            return new e(status, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class d implements DriveFolder.DriveFileResult {
        private final Status jP;
        private final DriveFile oB;

        public d(Status status, DriveFile driveFile) {
            this.jP = status;
            this.oB = driveFile;
        }

        @Override // com.google.android.gms.drive.DriveFolder.DriveFileResult
        public DriveFile getDriveFile() {
            return this.oB;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class e implements DriveFolder.DriveFolderResult {
        private final Status jP;
        private final DriveFolder oC;

        public e(Status status, DriveFolder driveFolder) {
            this.jP = status;
            this.oC = driveFolder;
        }

        @Override // com.google.android.gms.drive.DriveFolder.DriveFolderResult
        public DriveFolder getDriveFolder() {
            return this.oC;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }
    }

    public l(DriveId driveId) {
        super(driveId);
    }

    @Override // com.google.android.gms.drive.DriveFolder
    public PendingResult<DriveFolder.DriveFileResult, DriveFolder.OnCreateFileCallback> createFile(GoogleApiClient apiClient, final MetadataChangeSet changeSet, final Contents contents) {
        if (changeSet == null) {
            throw new IllegalArgumentException("MetatadataChangeSet must be provided.");
        }
        if (contents == null) {
            throw new IllegalArgumentException("Contents must be provided.");
        }
        if (DriveFolder.MIME_TYPE.equals(changeSet.getMimeType())) {
            throw new IllegalArgumentException("May not create folders (mimetype: application/vnd.google-apps.folder) using this method. Use DriveFolder.createFolder() instead.");
        }
        return apiClient.b((GoogleApiClient) new i<DriveFolder.DriveFileResult, DriveFolder.OnCreateFileCallback>() { // from class: com.google.android.gms.drive.internal.l.1
            /* JADX INFO: Access modifiers changed from: protected */
            @Override // com.google.android.gms.common.api.a.AbstractC0001a
            public void a(DriveFolder.OnCreateFileCallback onCreateFileCallback, DriveFolder.DriveFileResult driveFileResult) {
                onCreateFileCallback.onCreateFile(driveFileResult);
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // com.google.android.gms.common.api.a.AbstractC0001a
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public void b(j jVar) {
                try {
                    contents.close();
                    jVar.cu().a(new CreateFileRequest(l.this.getDriveId(), changeSet.ct(), contents), new a(this));
                } catch (RemoteException e2) {
                    a((AnonymousClass1) new d(new Status(8, e2.getLocalizedMessage(), null), null));
                }
            }

            @Override // com.google.android.gms.common.api.PendingResult
            /* renamed from: h, reason: merged with bridge method [inline-methods] */
            public DriveFolder.DriveFileResult b(Status status) {
                return new d(status, null);
            }
        });
    }

    @Override // com.google.android.gms.drive.DriveFolder
    public PendingResult<DriveFolder.DriveFolderResult, DriveFolder.OnCreateFolderCallback> createFolder(GoogleApiClient apiClient, final MetadataChangeSet changeSet) {
        if (changeSet == null) {
            throw new IllegalArgumentException("MetatadataChangeSet must be provided.");
        }
        if (changeSet.getMimeType() == null || changeSet.getMimeType().equals(DriveFolder.MIME_TYPE)) {
            return apiClient.b((GoogleApiClient) new c() { // from class: com.google.android.gms.drive.internal.l.2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super();
                }

                /* JADX INFO: Access modifiers changed from: protected */
                @Override // com.google.android.gms.common.api.a.AbstractC0001a
                /* renamed from: a, reason: merged with bridge method [inline-methods] */
                public void b(j jVar) {
                    try {
                        jVar.cu().a(new CreateFolderRequest(l.this.getDriveId(), changeSet.ct()), new b(this));
                    } catch (RemoteException e2) {
                        a((AnonymousClass2) new e(new Status(8, e2.getLocalizedMessage(), null), null));
                    }
                }
            });
        }
        throw new IllegalArgumentException("The mimetype must be of type application/vnd.google-apps.folder");
    }

    @Override // com.google.android.gms.drive.DriveFolder
    public PendingResult<DriveApi.MetadataBufferResult, DriveFolder.OnChildrenRetrievedCallback> listChildren(GoogleApiClient apiClient) {
        return queryChildren(apiClient, null);
    }

    @Override // com.google.android.gms.drive.DriveFolder
    public PendingResult<DriveApi.MetadataBufferResult, DriveFolder.OnChildrenRetrievedCallback> queryChildren(GoogleApiClient apiClient, Query query) {
        Query.Builder addFilter = new Query.Builder().addFilter(Filters.in(SearchableField.PARENTS, getDriveId()));
        if (query != null) {
            if (query.getFilter() != null) {
                addFilter.addFilter(query.getFilter());
            }
            addFilter.setPageToken(query.getPageToken());
        }
        return new h().query(apiClient, addFilter.build());
    }
}
