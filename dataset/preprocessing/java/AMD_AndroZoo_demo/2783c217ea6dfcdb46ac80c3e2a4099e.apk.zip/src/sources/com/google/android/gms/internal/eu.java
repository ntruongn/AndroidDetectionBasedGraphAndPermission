package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.OrderedMetadataField;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class eu {
    public static final OrderedMetadataField<Date> oX = new com.google.android.gms.drive.metadata.internal.b("modified");
    public static final OrderedMetadataField<Date> oY = new com.google.android.gms.drive.metadata.internal.b("modifiedByMe");
    public static final OrderedMetadataField<Date> oZ = new com.google.android.gms.drive.metadata.internal.b("created");
    public static final OrderedMetadataField<Date> pa = new com.google.android.gms.drive.metadata.internal.b("sharedWithMe");
}
