package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a;
import com.google.android.gms.internal.dk;
import com.google.android.gms.internal.gi;
import com.google.android.gms.internal.gj;
import com.google.android.gms.panorama.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class gk extends dk<gj> {

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class a extends dk<gj>.b<a.c<a.InterfaceC0079a>> implements a.InterfaceC0079a {
        public final int type;
        public final Status zf;
        public final Intent zg;

        public a(a.c<a.InterfaceC0079a> cVar, Status status, int i, Intent intent) {
            super(cVar);
            this.zf = status;
            this.type = i;
            this.zg = intent;
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void b(a.c<a.InterfaceC0079a> cVar) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.panorama.a.b
        public Intent eo() {
            return this.zg;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.zf;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class b extends gi.a {
        private final a.c<a.InterfaceC0079a> zi;
        private final a.c<a.b> zj;
        private final Uri zk;

        public b(a.c<a.InterfaceC0079a> cVar, a.c<a.b> cVar2, Uri uri) {
            this.zi = cVar;
            this.zj = cVar2;
            this.zk = uri;
        }

        @Override // com.google.android.gms.internal.gi
        public void a(int i, Bundle bundle, int i2, Intent intent) {
            if (this.zk != null) {
                gk.this.getContext().revokeUriPermission(this.zk, 1);
            }
            Status status = new Status(i, null, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null);
            if (this.zj != null) {
                gk.this.a(new c(this.zj, status, intent));
            } else if (this.zi != null) {
                gk.this.a(new a(this.zi, status, i2, intent));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class c extends dk<gj>.b<a.c<a.b>> implements a.b {
        private final Status zf;
        private final Intent zg;

        public c(a.c<a.b> cVar, Status status, Intent intent) {
            super(cVar);
            this.zf = status;
            this.zg = intent;
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void b(a.c<a.b> cVar) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.panorama.a.b
        public Intent eo() {
            return this.zg;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.zf;
        }
    }

    public gk(Context context, GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener) {
        super(context, connectionCallbacks, onConnectionFailedListener, (String[]) null);
    }

    public void a(a.c<a.b> cVar, Uri uri, boolean z) {
        a(new b(null, cVar, z ? uri : null), uri, null, z);
    }

    @Override // com.google.android.gms.internal.dk
    protected void a(dq dqVar, dk.d dVar) throws RemoteException {
        dqVar.a(dVar, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), new Bundle());
    }

    public void a(b bVar, Uri uri, Bundle bundle, boolean z) {
        bB();
        if (z) {
            getContext().grantUriPermission(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, uri, 1);
        }
        try {
            bC().a(bVar, uri, bundle, z);
        } catch (RemoteException e) {
            bVar.a(8, null, 0, null);
        }
    }

    @Override // com.google.android.gms.internal.dk
    protected String am() {
        return "com.google.android.gms.panorama.service.START";
    }

    @Override // com.google.android.gms.internal.dk
    protected String an() {
        return "com.google.android.gms.panorama.internal.IPanoramaService";
    }

    @Override // com.google.android.gms.internal.dk
    /* renamed from: aq, reason: merged with bridge method [inline-methods] */
    public gj p(IBinder iBinder) {
        return gj.a.ap(iBinder);
    }
}
