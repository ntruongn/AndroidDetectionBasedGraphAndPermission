package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class OnDriveIdResponse implements SafeParcelable {
    public static final Parcelable.Creator<OnDriveIdResponse> CREATOR = new t();
    final int kZ;
    DriveId oF;

    /* JADX INFO: Access modifiers changed from: package-private */
    public OnDriveIdResponse(int versionCode, DriveId driveId) {
        this.kZ = versionCode;
        this.oF = driveId;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public DriveId getDriveId() {
        return this.oF;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        t.a(this, dest, flags);
    }
}
