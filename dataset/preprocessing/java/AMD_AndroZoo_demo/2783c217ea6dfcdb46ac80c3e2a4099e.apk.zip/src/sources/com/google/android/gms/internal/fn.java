package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.util.Locale;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class fn implements SafeParcelable, Geofence {
    public static final fo CREATOR = new fo();
    private final int kZ;
    private final short tB;
    private final double tC;
    private final double tD;
    private final float tE;
    private final int tF;
    private final int tG;
    private final String ty;
    private final int tz;
    private final long ub;

    public fn(int i, String str, int i2, short s, double d, double d2, float f, long j, int i3, int i4) {
        aa(str);
        b(f);
        a(d, d2);
        int aE = aE(i2);
        this.kZ = i;
        this.tB = s;
        this.ty = str;
        this.tC = d;
        this.tD = d2;
        this.tE = f;
        this.ub = j;
        this.tz = aE;
        this.tF = i3;
        this.tG = i4;
    }

    public fn(String str, int i, short s, double d, double d2, float f, long j, int i2, int i3) {
        this(1, str, i, s, d, d2, f, j, i2, i3);
    }

    private static void a(double d, double d2) {
        if (d > 90.0d || d < -90.0d) {
            throw new IllegalArgumentException("invalid latitude: " + d);
        }
        if (d2 > 180.0d || d2 < -180.0d) {
            throw new IllegalArgumentException("invalid longitude: " + d2);
        }
    }

    private static int aE(int i) {
        int i2 = i & 7;
        if (i2 == 0) {
            throw new IllegalArgumentException("No supported transition specified: " + i);
        }
        return i2;
    }

    private static String aF(int i) {
        switch (i) {
            case 1:
                return "CIRCLE";
            default:
                return null;
        }
    }

    private static void aa(String str) {
        if (str == null || str.length() > 100) {
            throw new IllegalArgumentException("requestId is null or too long: " + str);
        }
    }

    private static void b(float f) {
        if (f <= BitmapDescriptorFactory.HUE_RED) {
            throw new IllegalArgumentException("invalid radius: " + f);
        }
    }

    public static fn f(byte[] bArr) {
        Parcel obtain = Parcel.obtain();
        obtain.unmarshall(bArr, 0, bArr.length);
        obtain.setDataPosition(0);
        fn createFromParcel = CREATOR.createFromParcel(obtain);
        obtain.recycle();
        return createFromParcel;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        fo foVar = CREATOR;
        return 0;
    }

    public short ds() {
        return this.tB;
    }

    public float dt() {
        return this.tE;
    }

    public int du() {
        return this.tz;
    }

    public int dv() {
        return this.tG;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && (obj instanceof fn)) {
            fn fnVar = (fn) obj;
            return this.tE == fnVar.tE && this.tC == fnVar.tC && this.tD == fnVar.tD && this.tB == fnVar.tB;
        }
        return false;
    }

    public long getExpirationTime() {
        return this.ub;
    }

    public double getLatitude() {
        return this.tC;
    }

    public double getLongitude() {
        return this.tD;
    }

    public int getNotificationResponsiveness() {
        return this.tF;
    }

    @Override // com.google.android.gms.location.Geofence
    public String getRequestId() {
        return this.ty;
    }

    public int getVersionCode() {
        return this.kZ;
    }

    public int hashCode() {
        long doubleToLongBits = Double.doubleToLongBits(this.tC);
        long doubleToLongBits2 = Double.doubleToLongBits(this.tD);
        return ((((((((((int) (doubleToLongBits ^ (doubleToLongBits >>> 32))) + 31) * 31) + ((int) (doubleToLongBits2 ^ (doubleToLongBits2 >>> 32)))) * 31) + Float.floatToIntBits(this.tE)) * 31) + this.tB) * 31) + this.tz;
    }

    public String toString() {
        return String.format(Locale.US, "Geofence[%s id:%s transitions:%d %.6f, %.6f %.0fm, resp=%ds, dwell=%dms, @%d]", aF(this.tB), this.ty, Integer.valueOf(this.tz), Double.valueOf(this.tC), Double.valueOf(this.tD), Float.valueOf(this.tE), Integer.valueOf(this.tF / 1000), Integer.valueOf(this.tG), Long.valueOf(this.ub));
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int flags) {
        fo foVar = CREATOR;
        fo.a(this, parcel, flags);
    }
}
