package com.google.android.gms.games.leaderboard;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.du;
import com.google.android.gms.internal.fh;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class SubmitScoreResult {
    private static final String[] so = {"leaderboardId", "playerId", "timeSpan", "hasResult", "rawScore", "formattedScore", "newBest", "scoreTag"};
    private int ka;
    private String qK;
    private String rL;
    private HashMap<Integer, Result> sp;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class Result {
        public final String formattedScore;
        public final boolean newBest;
        public final long rawScore;
        public final String scoreTag;

        public Result(long rawScore, String formattedScore, String scoreTag, boolean newBest) {
            this.rawScore = rawScore;
            this.formattedScore = formattedScore;
            this.scoreTag = scoreTag;
            this.newBest = newBest;
        }

        public String toString() {
            return ds.e(this).a("RawScore", Long.valueOf(this.rawScore)).a("FormattedScore", this.formattedScore).a("ScoreTag", this.scoreTag).a("NewBest", Boolean.valueOf(this.newBest)).toString();
        }
    }

    public SubmitScoreResult(int statusCode, String leaderboardId, String playerId) {
        this(statusCode, leaderboardId, playerId, new HashMap());
    }

    public SubmitScoreResult(int statusCode, String leaderboardId, String playerId, HashMap<Integer, Result> results) {
        this.ka = statusCode;
        this.rL = leaderboardId;
        this.qK = playerId;
        this.sp = results;
    }

    public SubmitScoreResult(DataHolder dataHolder) {
        this.ka = dataHolder.getStatusCode();
        this.sp = new HashMap<>();
        int count = dataHolder.getCount();
        du.p(count == 3);
        for (int i = 0; i < count; i++) {
            int t = dataHolder.t(i);
            if (i == 0) {
                this.rL = dataHolder.getString("leaderboardId", i, t);
                this.qK = dataHolder.getString("playerId", i, t);
            }
            if (dataHolder.getBoolean("hasResult", i, t)) {
                a(new Result(dataHolder.getLong("rawScore", i, t), dataHolder.getString("formattedScore", i, t), dataHolder.getString("scoreTag", i, t), dataHolder.getBoolean("newBest", i, t)), dataHolder.getInteger("timeSpan", i, t));
            }
        }
    }

    private void a(Result result, int i) {
        this.sp.put(Integer.valueOf(i), result);
    }

    public String getLeaderboardId() {
        return this.rL;
    }

    public String getPlayerId() {
        return this.qK;
    }

    public Result getScoreResult(int timeSpan) {
        return this.sp.get(Integer.valueOf(timeSpan));
    }

    public int getStatusCode() {
        return this.ka;
    }

    public String toString() {
        ds.a a = ds.e(this).a("PlayerId", this.qK).a("StatusCode", Integer.valueOf(this.ka));
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= 3) {
                return a.toString();
            }
            Result result = this.sp.get(Integer.valueOf(i2));
            a.a("TimesSpan", fh.at(i2));
            a.a("Result", result == null ? "null" : result.toString());
            i = i2 + 1;
        }
    }
}
