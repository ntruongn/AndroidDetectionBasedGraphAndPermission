package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.common.Scopes;
import java.util.ArrayList;
import java.util.Arrays;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class gt {
    private String jD;
    private String[] zI;
    private String zJ;
    private String zK;
    private String zL;
    private ArrayList<String> zN = new ArrayList<>();
    private String[] zO;

    public gt(Context context) {
        this.zK = context.getPackageName();
        this.zJ = context.getPackageName();
        this.zN.add(Scopes.PLUS_LOGIN);
    }

    public gt ak(String str) {
        this.jD = str;
        return this;
    }

    public gt d(String... strArr) {
        this.zN.clear();
        this.zN.addAll(Arrays.asList(strArr));
        return this;
    }

    public gt e(String... strArr) {
        this.zO = strArr;
        return this;
    }

    public gt eD() {
        this.zN.clear();
        return this;
    }

    public gs eE() {
        if (this.jD == null) {
            this.jD = "<<default account>>";
        }
        return new gs(this.jD, (String[]) this.zN.toArray(new String[this.zN.size()]), this.zO, this.zI, this.zJ, this.zK, this.zL);
    }
}
