package com.google.android.gms.internal;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class hp {
    private final byte[] CG = new byte[256];
    private int CH;
    private int CI;

    public hp(byte[] bArr) {
        for (int i = 0; i < 256; i++) {
            this.CG[i] = (byte) i;
        }
        int i2 = 0;
        for (int i3 = 0; i3 < 256; i3++) {
            i2 = (i2 + this.CG[i3] + bArr[i3 % bArr.length]) & 255;
            byte b = this.CG[i3];
            this.CG[i3] = this.CG[i2];
            this.CG[i2] = b;
        }
        this.CH = 0;
        this.CI = 0;
    }

    public void h(byte[] bArr) {
        int i = this.CH;
        int i2 = this.CI;
        for (int i3 = 0; i3 < bArr.length; i3++) {
            i = (i + 1) & 255;
            i2 = (i2 + this.CG[i]) & 255;
            byte b = this.CG[i];
            this.CG[i] = this.CG[i2];
            this.CG[i2] = b;
            bArr[i3] = (byte) (bArr[i3] ^ this.CG[(this.CG[i] + this.CG[i2]) & 255]);
        }
        this.CH = i;
        this.CI = i2;
    }
}
