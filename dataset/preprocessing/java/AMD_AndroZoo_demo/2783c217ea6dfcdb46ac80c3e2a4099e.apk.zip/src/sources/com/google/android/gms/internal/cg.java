package com.google.android.gms.internal;

import com.google.android.gms.plus.PlusShare;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class cg {
    private cv gu;
    private String hI;
    private final Object fx = new Object();
    private int hk = -2;
    public final an hJ = new an() { // from class: com.google.android.gms.internal.cg.1
        @Override // com.google.android.gms.internal.an
        public void a(cv cvVar, Map<String, String> map) {
            synchronized (cg.this.fx) {
                cs.v("Invalid " + map.get("type") + " request error: " + map.get("errors"));
                cg.this.hk = 1;
                cg.this.fx.notify();
            }
        }
    };
    public final an hK = new an() { // from class: com.google.android.gms.internal.cg.2
        @Override // com.google.android.gms.internal.an
        public void a(cv cvVar, Map<String, String> map) {
            synchronized (cg.this.fx) {
                String str = map.get(PlusShare.KEY_CALL_TO_ACTION_URL);
                if (str == null) {
                    cs.v("URL missing in loadAdUrl GMSG.");
                } else {
                    cg.this.hI = str;
                    cg.this.fx.notify();
                }
            }
        }
    };

    public String ap() {
        String str;
        synchronized (this.fx) {
            while (this.hI == null && this.hk == -2) {
                try {
                    this.fx.wait();
                } catch (InterruptedException e) {
                    cs.v("Ad request service was interrupted.");
                    str = null;
                }
            }
            str = this.hI;
        }
        return str;
    }

    public void b(cv cvVar) {
        synchronized (this.fx) {
            this.gu = cvVar;
        }
    }

    public int getErrorCode() {
        int i;
        synchronized (this.fx) {
            i = this.hk;
        }
        return i;
    }
}
