package com.book.zhingoora.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.book.mbpl.thehistoryofjackoi.R;
import com.huprya.wqkqze112375.AdListener;
import com.huprya.wqkqze112375.MA;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class BookActivity extends Activity implements View.OnClickListener, AdListener {
    static MA air = null;

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        air = new MA(this, this, true);
        air.callSmartWallAd();
        air.callVideoAd();
        Button readbtn = (Button) findViewById(R.id.readbtn);
        readbtn.setOnClickListener(this);
        Button exit = (Button) findViewById(R.id.exit);
        exit.setOnClickListener(this);
        TextView t1 = (TextView) findViewById(R.id.textView1);
        Typeface font = Typeface.createFromAsset(getAssets(), "fonts/font1.ttf");
        t1.setTypeface(font);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.readbtn /* 2131034129 */:
                Intent i = new Intent(this, (Class<?>) chapter1.class);
                startActivity(i);
                try {
                    air.showCachedAd(this, AdListener.AdType.smartwall);
                    return;
                } catch (Exception e) {
                    return;
                } finally {
                    finish();
                }
            case R.id.exit /* 2131034130 */:
                try {
                    air.showCachedAd(this, AdListener.AdType.smartwall);
                    try {
                        air.showCachedAd(this, AdListener.AdType.video);
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                    return;
                } catch (Exception e3) {
                    try {
                        air.showCachedAd(this, AdListener.AdType.video);
                    } catch (Exception e4) {
                        e4.printStackTrace();
                    }
                    return;
                } catch (Throwable th) {
                    try {
                        air.showCachedAd(this, AdListener.AdType.video);
                    } catch (Exception e5) {
                        e5.printStackTrace();
                    }
                    throw th;
                }
            default:
                return;
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        try {
            air.showCachedAd(this, AdListener.AdType.smartwall);
            try {
                air.showCachedAd(this, AdListener.AdType.video);
            } catch (Exception e) {
                e.printStackTrace();
            }
            finish();
        } catch (Exception e2) {
            try {
                air.showCachedAd(this, AdListener.AdType.video);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            finish();
        } catch (Throwable th) {
            try {
                air.showCachedAd(this, AdListener.AdType.video);
            } catch (Exception e4) {
                e4.printStackTrace();
            }
            finish();
            throw th;
        }
    }

    @Override // com.huprya.wqkqze112375.AdListener
    public void noAdAvailableListener() {
    }

    @Override // com.huprya.wqkqze112375.AdListener
    public void onAdCached(AdListener.AdType arg0) {
    }

    @Override // com.huprya.wqkqze112375.AdListener
    public void onAdError(String arg0) {
    }

    @Override // com.huprya.wqkqze112375.AdListener
    public void onSDKIntegrationError(String arg0) {
    }

    @Override // com.huprya.wqkqze112375.AdListener
    public void onSmartWallAdClosed() {
    }

    @Override // com.huprya.wqkqze112375.AdListener
    public void onSmartWallAdShowing() {
    }
}
