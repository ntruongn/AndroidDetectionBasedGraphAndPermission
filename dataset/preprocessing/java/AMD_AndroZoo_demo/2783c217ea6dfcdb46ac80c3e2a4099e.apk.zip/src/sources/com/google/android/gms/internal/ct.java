package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ct implements SafeParcelable {
    public static final cu CREATOR = new cu();
    public String iF;
    public int iG;
    public int iH;
    public boolean iI;
    public final int versionCode;

    public ct(int i, int i2, boolean z) {
        this(1, "afma-sdk-a-v" + i + "." + i2 + "." + (z ? "0" : "1"), i, i2, z);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ct(int i, String str, int i2, int i3, boolean z) {
        this.versionCode = i;
        this.iF = str;
        this.iG = i2;
        this.iH = i3;
        this.iI = z;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        cu.a(this, out, flags);
    }
}
