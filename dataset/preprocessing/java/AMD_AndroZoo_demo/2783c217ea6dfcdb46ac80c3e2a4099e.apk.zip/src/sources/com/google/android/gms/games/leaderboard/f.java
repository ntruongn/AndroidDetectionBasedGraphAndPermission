package com.google.android.gms.games.leaderboard;

import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.ff;
import com.google.android.gms.internal.fh;
import com.huprya.wqkqze112375.IM;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class f implements LeaderboardVariant {
    private final int sc;
    private final int sd;
    private final boolean se;
    private final long sf;
    private final String sg;
    private final long sh;
    private final String si;
    private final String sj;
    private final long sk;
    private final String sl;
    private final String sm;
    private final String sn;

    public f(LeaderboardVariant leaderboardVariant) {
        this.sc = leaderboardVariant.getTimeSpan();
        this.sd = leaderboardVariant.getCollection();
        this.se = leaderboardVariant.hasPlayerInfo();
        this.sf = leaderboardVariant.getRawPlayerScore();
        this.sg = leaderboardVariant.getDisplayPlayerScore();
        this.sh = leaderboardVariant.getPlayerRank();
        this.si = leaderboardVariant.getDisplayPlayerRank();
        this.sj = leaderboardVariant.getPlayerScoreTag();
        this.sk = leaderboardVariant.getNumScores();
        this.sl = leaderboardVariant.dh();
        this.sm = leaderboardVariant.di();
        this.sn = leaderboardVariant.dj();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int a(LeaderboardVariant leaderboardVariant) {
        return ds.hashCode(Integer.valueOf(leaderboardVariant.getTimeSpan()), Integer.valueOf(leaderboardVariant.getCollection()), Boolean.valueOf(leaderboardVariant.hasPlayerInfo()), Long.valueOf(leaderboardVariant.getRawPlayerScore()), leaderboardVariant.getDisplayPlayerScore(), Long.valueOf(leaderboardVariant.getPlayerRank()), leaderboardVariant.getDisplayPlayerRank(), Long.valueOf(leaderboardVariant.getNumScores()), leaderboardVariant.dh(), leaderboardVariant.dj(), leaderboardVariant.di());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a(LeaderboardVariant leaderboardVariant, Object obj) {
        if (!(obj instanceof LeaderboardVariant)) {
            return false;
        }
        if (leaderboardVariant == obj) {
            return true;
        }
        LeaderboardVariant leaderboardVariant2 = (LeaderboardVariant) obj;
        return ds.equal(Integer.valueOf(leaderboardVariant2.getTimeSpan()), Integer.valueOf(leaderboardVariant.getTimeSpan())) && ds.equal(Integer.valueOf(leaderboardVariant2.getCollection()), Integer.valueOf(leaderboardVariant.getCollection())) && ds.equal(Boolean.valueOf(leaderboardVariant2.hasPlayerInfo()), Boolean.valueOf(leaderboardVariant.hasPlayerInfo())) && ds.equal(Long.valueOf(leaderboardVariant2.getRawPlayerScore()), Long.valueOf(leaderboardVariant.getRawPlayerScore())) && ds.equal(leaderboardVariant2.getDisplayPlayerScore(), leaderboardVariant.getDisplayPlayerScore()) && ds.equal(Long.valueOf(leaderboardVariant2.getPlayerRank()), Long.valueOf(leaderboardVariant.getPlayerRank())) && ds.equal(leaderboardVariant2.getDisplayPlayerRank(), leaderboardVariant.getDisplayPlayerRank()) && ds.equal(Long.valueOf(leaderboardVariant2.getNumScores()), Long.valueOf(leaderboardVariant.getNumScores())) && ds.equal(leaderboardVariant2.dh(), leaderboardVariant.dh()) && ds.equal(leaderboardVariant2.dj(), leaderboardVariant.dj()) && ds.equal(leaderboardVariant2.di(), leaderboardVariant.di());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String b(LeaderboardVariant leaderboardVariant) {
        return ds.e(leaderboardVariant).a("TimeSpan", fh.at(leaderboardVariant.getTimeSpan())).a("Collection", ff.at(leaderboardVariant.getCollection())).a("RawPlayerScore", leaderboardVariant.hasPlayerInfo() ? Long.valueOf(leaderboardVariant.getRawPlayerScore()) : IM.ORIENTATION_NONE).a("DisplayPlayerScore", leaderboardVariant.hasPlayerInfo() ? leaderboardVariant.getDisplayPlayerScore() : IM.ORIENTATION_NONE).a("PlayerRank", leaderboardVariant.hasPlayerInfo() ? Long.valueOf(leaderboardVariant.getPlayerRank()) : IM.ORIENTATION_NONE).a("DisplayPlayerRank", leaderboardVariant.hasPlayerInfo() ? leaderboardVariant.getDisplayPlayerRank() : IM.ORIENTATION_NONE).a("NumScores", Long.valueOf(leaderboardVariant.getNumScores())).a("TopPageNextToken", leaderboardVariant.dh()).a("WindowPageNextToken", leaderboardVariant.dj()).a("WindowPagePrevToken", leaderboardVariant.di()).toString();
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public String dh() {
        return this.sl;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public String di() {
        return this.sm;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public String dj() {
        return this.sn;
    }

    @Override // com.google.android.gms.common.data.Freezable
    /* renamed from: dk, reason: merged with bridge method [inline-methods] */
    public LeaderboardVariant freeze() {
        return this;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public int getCollection() {
        return this.sd;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public String getDisplayPlayerRank() {
        return this.si;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public String getDisplayPlayerScore() {
        return this.sg;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public long getNumScores() {
        return this.sk;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public long getPlayerRank() {
        return this.sh;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public String getPlayerScoreTag() {
        return this.sj;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public long getRawPlayerScore() {
        return this.sf;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public int getTimeSpan() {
        return this.sc;
    }

    @Override // com.google.android.gms.games.leaderboard.LeaderboardVariant
    public boolean hasPlayerInfo() {
        return this.se;
    }

    public int hashCode() {
        return a(this);
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        return b(this);
    }
}
