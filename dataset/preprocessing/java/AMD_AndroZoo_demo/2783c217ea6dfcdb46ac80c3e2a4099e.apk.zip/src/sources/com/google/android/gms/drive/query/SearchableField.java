package com.google.android.gms.drive.query;

import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.CollectionMetadataField;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.OrderedMetadataField;
import com.google.android.gms.internal.et;
import com.google.android.gms.internal.eu;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class SearchableField {
    public static final MetadataField<String> TITLE = et.TITLE;
    public static final MetadataField<String> MIME_TYPE = et.MIME_TYPE;
    public static final MetadataField<Boolean> TRASHED = et.TRASHED;
    public static final CollectionMetadataField<DriveId> PARENTS = et.PARENTS;
    public static final OrderedMetadataField<Date> pa = eu.pa;
    public static final MetadataField<Boolean> STARRED = et.STARRED;
    public static final OrderedMetadataField<Date> MODIFIED_DATE = eu.oX;
}
