package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class z extends a {
    private final a.c<Status> jN;

    public z(a.c<Status> cVar) {
        this.jN = cVar;
    }

    @Override // com.google.android.gms.drive.internal.a, com.google.android.gms.drive.internal.p
    public void d(Status status) throws RemoteException {
        this.jN.a(status);
    }

    @Override // com.google.android.gms.drive.internal.a, com.google.android.gms.drive.internal.p
    public void onSuccess() throws RemoteException {
        this.jN.a(Status.kW);
    }
}
