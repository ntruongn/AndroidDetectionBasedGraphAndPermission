package com.google.android.gms.drive;

import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.et;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class MetadataChangeSet {
    private final MetadataBundle ok;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class Builder {
        private final MetadataBundle ok = MetadataBundle.cE();

        public MetadataChangeSet build() {
            return new MetadataChangeSet(this.ok);
        }

        public Builder setMimeType(String mimeType) {
            this.ok.b(et.MIME_TYPE, mimeType);
            return this;
        }

        public Builder setStarred(boolean starred) {
            this.ok.b(et.STARRED, Boolean.valueOf(starred));
            return this;
        }

        public Builder setTitle(String title) {
            this.ok.b(et.TITLE, title);
            return this;
        }
    }

    private MetadataChangeSet(MetadataBundle bag) {
        this.ok = MetadataBundle.a(bag);
    }

    public MetadataBundle ct() {
        return this.ok;
    }

    public String getMimeType() {
        return (String) this.ok.a(et.MIME_TYPE);
    }

    public String getTitle() {
        return (String) this.ok.a(et.TITLE);
    }

    public Boolean isStarred() {
        return (Boolean) this.ok.a(et.STARRED);
    }
}
