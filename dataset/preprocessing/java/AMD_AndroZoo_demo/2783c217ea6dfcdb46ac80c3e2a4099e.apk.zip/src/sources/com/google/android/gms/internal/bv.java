package com.google.android.gms.internal;

import android.content.Context;
import android.os.SystemClock;
import android.text.TextUtils;
import com.google.android.gms.internal.bu;
import com.google.android.gms.internal.bw;
import com.google.android.gms.internal.bz;
import com.google.android.gms.internal.cw;
import org.json.JSONException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class bv extends cl implements bw.a, cw.a {
    private final bb ed;
    private au fy;
    private final cv gu;
    private final bu.a ha;
    private final bz.a hb;
    private final h hc;
    private cl hd;
    private cb he;
    private as hg;
    private ay hh;
    private final Context mContext;
    private final Object fx = new Object();
    private boolean hf = false;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a extends Exception {
        private final int hk;

        public a(String str, int i) {
            super(str);
            this.hk = i;
        }

        public int getErrorCode() {
            return this.hk;
        }
    }

    public bv(Context context, bz.a aVar, h hVar, cv cvVar, bb bbVar, bu.a aVar2) {
        this.ed = bbVar;
        this.ha = aVar2;
        this.gu = cvVar;
        this.mContext = context;
        this.hb = aVar;
        this.hc = hVar;
    }

    private x a(bz bzVar) throws a {
        if (this.he.hz == null) {
            throw new a("The ad response must specify one of the supported ad sizes.", 0);
        }
        String[] split = this.he.hz.split("x");
        if (split.length != 2) {
            throw new a("Could not parse the ad size from the ad response: " + this.he.hz, 0);
        }
        try {
            int parseInt = Integer.parseInt(split[0]);
            int parseInt2 = Integer.parseInt(split[1]);
            for (x xVar : bzVar.em.eH) {
                float f = this.mContext.getResources().getDisplayMetrics().density;
                int i = xVar.width == -1 ? (int) (xVar.widthPixels / f) : xVar.width;
                int i2 = xVar.height == -2 ? (int) (xVar.heightPixels / f) : xVar.height;
                if (parseInt == i && parseInt2 == i2) {
                    return new x(xVar, bzVar.em.eH);
                }
            }
            throw new a("The ad size from the ad response was not one of the requested sizes: " + this.he.hz, 0);
        } catch (NumberFormatException e) {
            throw new a("Could not parse the ad size from the ad response: " + this.he.hz, 0);
        }
    }

    private void a(bz bzVar, long j) throws a {
        this.hg = new as(this.mContext, bzVar, this.ed, this.fy);
        this.hh = this.hg.a(j, 60000L);
        switch (this.hh.fZ) {
            case 0:
                return;
            case 1:
                throw new a("No fill from any mediation ad networks.", 3);
            default:
                throw new a("Unexpected mediation result: " + this.hh.fZ, 0);
        }
    }

    private void aj() throws a {
        if (this.he.errorCode == -3) {
            return;
        }
        if (TextUtils.isEmpty(this.he.hu)) {
            throw new a("No fill from ad server.", 3);
        }
        if (this.he.hw) {
            try {
                this.fy = new au(this.he.hu);
            } catch (JSONException e) {
                throw new a("Could not parse mediation config: " + this.he.hu, 0);
            }
        }
    }

    private void b(long j) throws a {
        cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bv.3
            @Override // java.lang.Runnable
            public void run() {
                synchronized (bv.this.fx) {
                    if (bv.this.he.errorCode != -2) {
                        return;
                    }
                    bv.this.gu.aB().a(bv.this);
                    if (bv.this.he.errorCode == -3) {
                        cs.u("Loading URL in WebView: " + bv.this.he.gK);
                        bv.this.gu.loadUrl(bv.this.he.gK);
                    } else {
                        cs.u("Loading HTML in WebView.");
                        bv.this.gu.loadDataWithBaseURL(cn.o(bv.this.he.gK), bv.this.he.hu, "text/html", "UTF-8", null);
                    }
                }
            }
        });
        d(j);
    }

    private void c(long j) throws a {
        while (e(j)) {
            if (this.he != null) {
                this.hd = null;
                if (this.he.errorCode != -2 && this.he.errorCode != -3) {
                    throw new a("There was a problem getting an ad response. ErrorCode: " + this.he.errorCode, this.he.errorCode);
                }
                return;
            }
        }
        throw new a("Timed out waiting for ad response.", 2);
    }

    private void d(long j) throws a {
        while (e(j)) {
            if (this.hf) {
                return;
            }
        }
        throw new a("Timed out waiting for WebView to finish loading.", 2);
    }

    private boolean e(long j) throws a {
        long elapsedRealtime = 60000 - (SystemClock.elapsedRealtime() - j);
        if (elapsedRealtime <= 0) {
            return false;
        }
        try {
            this.fx.wait(elapsedRealtime);
            return true;
        } catch (InterruptedException e) {
            throw new a("Ad request cancelled.", -1);
        }
    }

    @Override // com.google.android.gms.internal.bw.a
    public void a(cb cbVar) {
        synchronized (this.fx) {
            cs.r("Received ad response.");
            this.he = cbVar;
            this.fx.notify();
        }
    }

    @Override // com.google.android.gms.internal.cw.a
    public void a(cv cvVar) {
        synchronized (this.fx) {
            cs.r("WebView finished loading.");
            this.hf = true;
            this.fx.notify();
        }
    }

    @Override // com.google.android.gms.internal.cl
    public void ai() {
        x xVar;
        long elapsedRealtime;
        synchronized (this.fx) {
            cs.r("AdLoaderBackgroundTask started.");
            bz bzVar = new bz(this.hb, this.hc.g().a(this.mContext));
            int i = -2;
            try {
                elapsedRealtime = SystemClock.elapsedRealtime();
                this.hd = bw.a(this.mContext, bzVar, this);
            } catch (a e) {
                i = e.getErrorCode();
                if (i == 3 || i == -1) {
                    cs.t(e.getMessage());
                } else {
                    cs.v(e.getMessage());
                }
                this.he = new cb(i);
                cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bv.1
                    @Override // java.lang.Runnable
                    public void run() {
                        bv.this.onStop();
                    }
                });
                xVar = null;
            }
            if (this.hd == null) {
                throw new a("Could not start the ad request service.", 0);
            }
            c(elapsedRealtime);
            aj();
            x a2 = bzVar.em.eH != null ? a(bzVar) : null;
            if (this.he.hw) {
                a(bzVar, elapsedRealtime);
            } else {
                b(elapsedRealtime);
            }
            xVar = a2;
            final cj cjVar = new cj(bzVar.hp, this.gu, this.he.fK, i, this.he.fL, this.he.hy, this.he.orientation, this.he.fO, bzVar.hs, this.he.hw, this.hh != null ? this.hh.ga : null, this.hh != null ? this.hh.gb : null, this.hh != null ? this.hh.gc : null, this.fy, this.hh != null ? this.hh.gd : null, this.he.hx, xVar, this.he.hv);
            cr.iE.post(new Runnable() { // from class: com.google.android.gms.internal.bv.2
                @Override // java.lang.Runnable
                public void run() {
                    synchronized (bv.this.fx) {
                        bv.this.ha.a(cjVar);
                    }
                }
            });
        }
    }

    @Override // com.google.android.gms.internal.cl
    public void onStop() {
        synchronized (this.fx) {
            if (this.hd != null) {
                this.hd.cancel();
            }
            this.gu.stopLoading();
            cn.a(this.gu);
            if (this.hg != null) {
                this.hg.cancel();
            }
        }
    }
}
