package com.google.android.gms.drive.internal;

import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class g extends Metadata {
    private final MetadataBundle oc;

    public g(MetadataBundle metadataBundle) {
        this.oc = metadataBundle;
    }

    @Override // com.google.android.gms.drive.Metadata
    protected <T> T a(MetadataField<T> metadataField) {
        return (T) this.oc.a(metadataField);
    }

    @Override // com.google.android.gms.common.data.Freezable
    /* renamed from: cr, reason: merged with bridge method [inline-methods] */
    public Metadata freeze() {
        return new g(MetadataBundle.a(this.oc));
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return this.oc != null;
    }

    public String toString() {
        return "Metadata [mImpl=" + this.oc + "]";
    }
}
