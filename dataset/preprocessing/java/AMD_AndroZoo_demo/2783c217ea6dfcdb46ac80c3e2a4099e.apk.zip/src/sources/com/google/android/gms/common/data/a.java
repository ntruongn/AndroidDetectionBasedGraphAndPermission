package com.google.android.gms.common.data;

import com.google.android.gms.internal.du;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class a<T> implements Iterator<T> {
    private int lc = -1;
    private final DataBuffer<T> mDataBuffer;

    public a(DataBuffer<T> dataBuffer) {
        this.mDataBuffer = (DataBuffer) du.f(dataBuffer);
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        return this.lc < this.mDataBuffer.getCount() + (-1);
    }

    @Override // java.util.Iterator
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException("Cannot advance the iterator beyond " + this.lc);
        }
        DataBuffer<T> dataBuffer = this.mDataBuffer;
        int i = this.lc + 1;
        this.lc = i;
        return dataBuffer.get(i);
    }

    @Override // java.util.Iterator
    public void remove() {
        throw new UnsupportedOperationException("Cannot remove elements from a DataBufferIterator");
    }
}
