package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ee;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class eh implements SafeParcelable {
    public static final ei CREATOR = new ei();
    private final int kZ;
    private final HashMap<String, HashMap<String, ee.a<?, ?>>> nH;
    private final ArrayList<a> nI;
    private final String nJ;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class a implements SafeParcelable {
        public static final ej CREATOR = new ej();
        final String className;
        final ArrayList<b> nK;
        final int versionCode;

        /* JADX INFO: Access modifiers changed from: package-private */
        public a(int i, String str, ArrayList<b> arrayList) {
            this.versionCode = i;
            this.className = str;
            this.nK = arrayList;
        }

        a(String str, HashMap<String, ee.a<?, ?>> hashMap) {
            this.versionCode = 1;
            this.className = str;
            this.nK = b(hashMap);
        }

        private static ArrayList<b> b(HashMap<String, ee.a<?, ?>> hashMap) {
            if (hashMap == null) {
                return null;
            }
            ArrayList<b> arrayList = new ArrayList<>();
            for (String str : hashMap.keySet()) {
                arrayList.add(new b(str, hashMap.get(str)));
            }
            return arrayList;
        }

        HashMap<String, ee.a<?, ?>> ch() {
            HashMap<String, ee.a<?, ?>> hashMap = new HashMap<>();
            int size = this.nK.size();
            for (int i = 0; i < size; i++) {
                b bVar = this.nK.get(i);
                hashMap.put(bVar.nL, bVar.nM);
            }
            return hashMap;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            ej ejVar = CREATOR;
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            ej ejVar = CREATOR;
            ej.a(this, out, flags);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class b implements SafeParcelable {
        public static final eg CREATOR = new eg();
        final String nL;
        final ee.a<?, ?> nM;
        final int versionCode;

        /* JADX INFO: Access modifiers changed from: package-private */
        public b(int i, String str, ee.a<?, ?> aVar) {
            this.versionCode = i;
            this.nL = str;
            this.nM = aVar;
        }

        b(String str, ee.a<?, ?> aVar) {
            this.versionCode = 1;
            this.nL = str;
            this.nM = aVar;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            eg egVar = CREATOR;
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            eg egVar = CREATOR;
            eg.a(this, out, flags);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public eh(int i, ArrayList<a> arrayList, String str) {
        this.kZ = i;
        this.nI = null;
        this.nH = b(arrayList);
        this.nJ = (String) du.f(str);
        cd();
    }

    public eh(Class<? extends ee> cls) {
        this.kZ = 1;
        this.nI = null;
        this.nH = new HashMap<>();
        this.nJ = cls.getCanonicalName();
    }

    private static HashMap<String, HashMap<String, ee.a<?, ?>>> b(ArrayList<a> arrayList) {
        HashMap<String, HashMap<String, ee.a<?, ?>>> hashMap = new HashMap<>();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            a aVar = arrayList.get(i);
            hashMap.put(aVar.className, aVar.ch());
        }
        return hashMap;
    }

    public HashMap<String, ee.a<?, ?>> N(String str) {
        return this.nH.get(str);
    }

    public void a(Class<? extends ee> cls, HashMap<String, ee.a<?, ?>> hashMap) {
        this.nH.put(cls.getCanonicalName(), hashMap);
    }

    public boolean b(Class<? extends ee> cls) {
        return this.nH.containsKey(cls.getCanonicalName());
    }

    public void cd() {
        Iterator<String> it = this.nH.keySet().iterator();
        while (it.hasNext()) {
            HashMap<String, ee.a<?, ?>> hashMap = this.nH.get(it.next());
            Iterator<String> it2 = hashMap.keySet().iterator();
            while (it2.hasNext()) {
                hashMap.get(it2.next()).a(this);
            }
        }
    }

    public void ce() {
        for (String str : this.nH.keySet()) {
            HashMap<String, ee.a<?, ?>> hashMap = this.nH.get(str);
            HashMap<String, ee.a<?, ?>> hashMap2 = new HashMap<>();
            for (String str2 : hashMap.keySet()) {
                hashMap2.put(str2, hashMap.get(str2).bT());
            }
            this.nH.put(str, hashMap2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ArrayList<a> cf() {
        ArrayList<a> arrayList = new ArrayList<>();
        for (String str : this.nH.keySet()) {
            arrayList.add(new a(str, this.nH.get(str)));
        }
        return arrayList;
    }

    public String cg() {
        return this.nJ;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        ei eiVar = CREATOR;
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.kZ;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (String str : this.nH.keySet()) {
            sb.append(str).append(":\n");
            HashMap<String, ee.a<?, ?>> hashMap = this.nH.get(str);
            for (String str2 : hashMap.keySet()) {
                sb.append("  ").append(str2).append(": ");
                sb.append(hashMap.get(str2));
            }
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        ei eiVar = CREATOR;
        ei.a(this, out, flags);
    }
}
