package com.google.android.gms.games;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.eo;
import com.google.android.gms.internal.ey;
import com.huprya.wqkqze112375.j;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class GameEntity extends ey implements Game {
    public static final Parcelable.Creator<GameEntity> CREATOR = new a();
    private final int kZ;
    private final String pV;
    private final String pW;
    private final String pX;
    private final String pY;
    private final String pZ;
    private final String qa;
    private final Uri qb;
    private final Uri qc;
    private final Uri qd;
    private final boolean qe;
    private final boolean qf;
    private final String qg;
    private final int qh;
    private final int qi;
    private final int qj;
    private final boolean qk;
    private final boolean ql;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    static final class a extends com.google.android.gms.games.a {
        a() {
        }

        @Override // com.google.android.gms.games.a, android.os.Parcelable.Creator
        /* renamed from: U */
        public GameEntity createFromParcel(Parcel parcel) {
            if (GameEntity.c(GameEntity.cH()) || GameEntity.D(GameEntity.class.getCanonicalName())) {
                return super.createFromParcel(parcel);
            }
            String readString = parcel.readString();
            String readString2 = parcel.readString();
            String readString3 = parcel.readString();
            String readString4 = parcel.readString();
            String readString5 = parcel.readString();
            String readString6 = parcel.readString();
            String readString7 = parcel.readString();
            Uri parse = readString7 == null ? null : Uri.parse(readString7);
            String readString8 = parcel.readString();
            Uri parse2 = readString8 == null ? null : Uri.parse(readString8);
            String readString9 = parcel.readString();
            return new GameEntity(2, readString, readString2, readString3, readString4, readString5, readString6, parse, parse2, readString9 == null ? null : Uri.parse(readString9), parcel.readInt() > 0, parcel.readInt() > 0, parcel.readString(), parcel.readInt(), parcel.readInt(), parcel.readInt(), false, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public GameEntity(int versionCode, String applicationId, String displayName, String primaryCategory, String secondaryCategory, String description, String developerName, Uri iconImageUri, Uri hiResImageUri, Uri featuredImageUri, boolean playEnabledGame, boolean instanceInstalled, String instancePackageName, int gameplayAclStatus, int achievementTotalCount, int leaderboardCount, boolean realTimeEnabled, boolean turnBasedEnabled) {
        this.kZ = versionCode;
        this.pV = applicationId;
        this.pW = displayName;
        this.pX = primaryCategory;
        this.pY = secondaryCategory;
        this.pZ = description;
        this.qa = developerName;
        this.qb = iconImageUri;
        this.qc = hiResImageUri;
        this.qd = featuredImageUri;
        this.qe = playEnabledGame;
        this.qf = instanceInstalled;
        this.qg = instancePackageName;
        this.qh = gameplayAclStatus;
        this.qi = achievementTotalCount;
        this.qj = leaderboardCount;
        this.qk = realTimeEnabled;
        this.ql = turnBasedEnabled;
    }

    public GameEntity(Game game) {
        this.kZ = 2;
        this.pV = game.getApplicationId();
        this.pX = game.getPrimaryCategory();
        this.pY = game.getSecondaryCategory();
        this.pZ = game.getDescription();
        this.qa = game.getDeveloperName();
        this.pW = game.getDisplayName();
        this.qb = game.getIconImageUri();
        this.qc = game.getHiResImageUri();
        this.qd = game.getFeaturedImageUri();
        this.qe = game.isPlayEnabledGame();
        this.qf = game.isInstanceInstalled();
        this.qg = game.getInstancePackageName();
        this.qh = game.getGameplayAclStatus();
        this.qi = game.getAchievementTotalCount();
        this.qj = game.getLeaderboardCount();
        this.qk = game.isRealTimeMultiplayerEnabled();
        this.ql = game.isTurnBasedMultiplayerEnabled();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int a(Game game) {
        return ds.hashCode(game.getApplicationId(), game.getDisplayName(), game.getPrimaryCategory(), game.getSecondaryCategory(), game.getDescription(), game.getDeveloperName(), game.getIconImageUri(), game.getHiResImageUri(), game.getFeaturedImageUri(), Boolean.valueOf(game.isPlayEnabledGame()), Boolean.valueOf(game.isInstanceInstalled()), game.getInstancePackageName(), Integer.valueOf(game.getGameplayAclStatus()), Integer.valueOf(game.getAchievementTotalCount()), Integer.valueOf(game.getLeaderboardCount()), Boolean.valueOf(game.isRealTimeMultiplayerEnabled()), Boolean.valueOf(game.isTurnBasedMultiplayerEnabled()));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a(Game game, Object obj) {
        if (!(obj instanceof Game)) {
            return false;
        }
        if (game == obj) {
            return true;
        }
        Game game2 = (Game) obj;
        return ds.equal(game2.getApplicationId(), game.getApplicationId()) && ds.equal(game2.getDisplayName(), game.getDisplayName()) && ds.equal(game2.getPrimaryCategory(), game.getPrimaryCategory()) && ds.equal(game2.getSecondaryCategory(), game.getSecondaryCategory()) && ds.equal(game2.getDescription(), game.getDescription()) && ds.equal(game2.getDeveloperName(), game.getDeveloperName()) && ds.equal(game2.getIconImageUri(), game.getIconImageUri()) && ds.equal(game2.getHiResImageUri(), game.getHiResImageUri()) && ds.equal(game2.getFeaturedImageUri(), game.getFeaturedImageUri()) && ds.equal(Boolean.valueOf(game2.isPlayEnabledGame()), Boolean.valueOf(game.isPlayEnabledGame())) && ds.equal(Boolean.valueOf(game2.isInstanceInstalled()), Boolean.valueOf(game.isInstanceInstalled())) && ds.equal(game2.getInstancePackageName(), game.getInstancePackageName()) && ds.equal(Integer.valueOf(game2.getGameplayAclStatus()), Integer.valueOf(game.getGameplayAclStatus())) && ds.equal(Integer.valueOf(game2.getAchievementTotalCount()), Integer.valueOf(game.getAchievementTotalCount())) && ds.equal(Integer.valueOf(game2.getLeaderboardCount()), Integer.valueOf(game.getLeaderboardCount())) && ds.equal(Boolean.valueOf(game2.isRealTimeMultiplayerEnabled()), Boolean.valueOf(game.isRealTimeMultiplayerEnabled())) && ds.equal(Boolean.valueOf(game2.isTurnBasedMultiplayerEnabled()), Boolean.valueOf(game.isTurnBasedMultiplayerEnabled()));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String b(Game game) {
        return ds.e(game).a("ApplicationId", game.getApplicationId()).a("DisplayName", game.getDisplayName()).a("PrimaryCategory", game.getPrimaryCategory()).a("SecondaryCategory", game.getSecondaryCategory()).a(j.DESCRIPTION, game.getDescription()).a("DeveloperName", game.getDeveloperName()).a("IconImageUri", game.getIconImageUri()).a("HiResImageUri", game.getHiResImageUri()).a("FeaturedImageUri", game.getFeaturedImageUri()).a("PlayEnabledGame", Boolean.valueOf(game.isPlayEnabledGame())).a("InstanceInstalled", Boolean.valueOf(game.isInstanceInstalled())).a("InstancePackageName", game.getInstancePackageName()).a("GameplayAclStatus", Integer.valueOf(game.getGameplayAclStatus())).a("AchievementTotalCount", Integer.valueOf(game.getAchievementTotalCount())).a("LeaderboardCount", Integer.valueOf(game.getLeaderboardCount())).a("RealTimeMultiplayerEnabled", Boolean.valueOf(game.isRealTimeMultiplayerEnabled())).a("TurnBasedMultiplayerEnabled", Boolean.valueOf(game.isTurnBasedMultiplayerEnabled())).toString();
    }

    static /* synthetic */ Integer cH() {
        return by();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.google.android.gms.common.data.Freezable
    public Game freeze() {
        return this;
    }

    @Override // com.google.android.gms.games.Game
    public int getAchievementTotalCount() {
        return this.qi;
    }

    @Override // com.google.android.gms.games.Game
    public String getApplicationId() {
        return this.pV;
    }

    @Override // com.google.android.gms.games.Game
    public String getDescription() {
        return this.pZ;
    }

    @Override // com.google.android.gms.games.Game
    public void getDescription(CharArrayBuffer dataOut) {
        eo.b(this.pZ, dataOut);
    }

    @Override // com.google.android.gms.games.Game
    public String getDeveloperName() {
        return this.qa;
    }

    @Override // com.google.android.gms.games.Game
    public void getDeveloperName(CharArrayBuffer dataOut) {
        eo.b(this.qa, dataOut);
    }

    @Override // com.google.android.gms.games.Game
    public String getDisplayName() {
        return this.pW;
    }

    @Override // com.google.android.gms.games.Game
    public void getDisplayName(CharArrayBuffer dataOut) {
        eo.b(this.pW, dataOut);
    }

    @Override // com.google.android.gms.games.Game
    public Uri getFeaturedImageUri() {
        return this.qd;
    }

    @Override // com.google.android.gms.games.Game
    public int getGameplayAclStatus() {
        return this.qh;
    }

    @Override // com.google.android.gms.games.Game
    public Uri getHiResImageUri() {
        return this.qc;
    }

    @Override // com.google.android.gms.games.Game
    public Uri getIconImageUri() {
        return this.qb;
    }

    @Override // com.google.android.gms.games.Game
    public String getInstancePackageName() {
        return this.qg;
    }

    @Override // com.google.android.gms.games.Game
    public int getLeaderboardCount() {
        return this.qj;
    }

    @Override // com.google.android.gms.games.Game
    public String getPrimaryCategory() {
        return this.pX;
    }

    @Override // com.google.android.gms.games.Game
    public String getSecondaryCategory() {
        return this.pY;
    }

    public int getVersionCode() {
        return this.kZ;
    }

    public int hashCode() {
        return a(this);
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    @Override // com.google.android.gms.games.Game
    public boolean isInstanceInstalled() {
        return this.qf;
    }

    @Override // com.google.android.gms.games.Game
    public boolean isPlayEnabledGame() {
        return this.qe;
    }

    @Override // com.google.android.gms.games.Game
    public boolean isRealTimeMultiplayerEnabled() {
        return this.qk;
    }

    @Override // com.google.android.gms.games.Game
    public boolean isTurnBasedMultiplayerEnabled() {
        return this.ql;
    }

    public String toString() {
        return b(this);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        if (!bz()) {
            com.google.android.gms.games.a.a(this, dest, flags);
            return;
        }
        dest.writeString(this.pV);
        dest.writeString(this.pW);
        dest.writeString(this.pX);
        dest.writeString(this.pY);
        dest.writeString(this.pZ);
        dest.writeString(this.qa);
        dest.writeString(this.qb == null ? null : this.qb.toString());
        dest.writeString(this.qc == null ? null : this.qc.toString());
        dest.writeString(this.qd != null ? this.qd.toString() : null);
        dest.writeInt(this.qe ? 1 : 0);
        dest.writeInt(this.qf ? 1 : 0);
        dest.writeString(this.qg);
        dest.writeInt(this.qh);
        dest.writeInt(this.qi);
        dest.writeInt(this.qj);
    }
}
