package com.google.android.gms.games.multiplayer.turnbased;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.multiplayer.InvitationBuffer;
import com.google.android.gms.internal.fi;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class LoadMatchesResponse {
    private final InvitationBuffer sV;
    private final TurnBasedMatchBuffer sW;
    private final TurnBasedMatchBuffer sX;
    private final TurnBasedMatchBuffer sY;

    public LoadMatchesResponse(Bundle matchData) {
        DataHolder a = a(matchData, 0);
        if (a != null) {
            this.sV = new InvitationBuffer(a);
        } else {
            this.sV = null;
        }
        DataHolder a2 = a(matchData, 1);
        if (a2 != null) {
            this.sW = new TurnBasedMatchBuffer(a2);
        } else {
            this.sW = null;
        }
        DataHolder a3 = a(matchData, 2);
        if (a3 != null) {
            this.sX = new TurnBasedMatchBuffer(a3);
        } else {
            this.sX = null;
        }
        DataHolder a4 = a(matchData, 3);
        if (a4 != null) {
            this.sY = new TurnBasedMatchBuffer(a4);
        } else {
            this.sY = null;
        }
    }

    private static DataHolder a(Bundle bundle, int i) {
        String at = fi.at(i);
        if (bundle.containsKey(at)) {
            return (DataHolder) bundle.getParcelable(at);
        }
        return null;
    }

    public TurnBasedMatchBuffer getCompletedMatches() {
        return this.sY;
    }

    public InvitationBuffer getInvitations() {
        return this.sV;
    }

    public TurnBasedMatchBuffer getMyTurnMatches() {
        return this.sW;
    }

    public TurnBasedMatchBuffer getTheirTurnMatches() {
        return this.sX;
    }
}
