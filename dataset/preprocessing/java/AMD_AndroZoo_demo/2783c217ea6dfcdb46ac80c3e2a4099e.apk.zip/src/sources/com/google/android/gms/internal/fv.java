package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.location.LocationRequest;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class fv implements Parcelable.Creator<fu> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(fu fuVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 1, (Parcelable) fuVar.dA(), i, false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1000, fuVar.kZ);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, (Parcelable) fuVar.dB(), i, false);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aI, reason: merged with bridge method [inline-methods] */
    public fu[] newArray(int i) {
        return new fu[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: ac, reason: merged with bridge method [inline-methods] */
    public fu createFromParcel(Parcel parcel) {
        fs fsVar;
        LocationRequest locationRequest;
        int i;
        fs fsVar2 = null;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i2 = 0;
        LocationRequest locationRequest2 = null;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    LocationRequest locationRequest3 = (LocationRequest) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, LocationRequest.CREATOR);
                    i = i2;
                    fsVar = fsVar2;
                    locationRequest = locationRequest3;
                    break;
                case 2:
                    fsVar = (fs) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, fs.CREATOR);
                    locationRequest = locationRequest2;
                    i = i2;
                    break;
                case 1000:
                    fs fsVar3 = fsVar2;
                    locationRequest = locationRequest2;
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    fsVar = fsVar3;
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    fsVar = fsVar2;
                    locationRequest = locationRequest2;
                    i = i2;
                    break;
            }
            i2 = i;
            locationRequest2 = locationRequest;
            fsVar2 = fsVar;
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new fu(i2, locationRequest2, fsVar2);
    }
}
