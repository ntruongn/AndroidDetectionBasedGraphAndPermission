package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ee;
import com.google.android.gms.plus.model.moments.ItemScope;
import com.google.android.gms.plus.model.moments.Moment;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class gx extends ee implements SafeParcelable, Moment {
    public static final gy CREATOR = new gy();
    private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
    private String AE;
    private gv AM;
    private gv AN;
    private final int kZ;
    private String wF;
    private String wJ;
    private final Set<Integer> zQ;

    static {
        zP.put(com.huprya.wqkqze112375.j.ID, ee.a.f(com.huprya.wqkqze112375.j.ID, 2));
        zP.put("result", ee.a.a("result", 4, gv.class));
        zP.put("startDate", ee.a.f("startDate", 5));
        zP.put("target", ee.a.a("target", 6, gv.class));
        zP.put("type", ee.a.f("type", 7));
    }

    public gx() {
        this.kZ = 1;
        this.zQ = new HashSet();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gx(Set<Integer> set, int i, String str, gv gvVar, String str2, gv gvVar2, String str3) {
        this.zQ = set;
        this.kZ = i;
        this.wJ = str;
        this.AM = gvVar;
        this.AE = str2;
        this.AN = gvVar2;
        this.wF = str3;
    }

    public gx(Set<Integer> set, String str, gv gvVar, String str2, gv gvVar2, String str3) {
        this.zQ = set;
        this.kZ = 1;
        this.wJ = str;
        this.AM = gvVar;
        this.AE = str2;
        this.AN = gvVar2;
        this.wF = str3;
    }

    @Override // com.google.android.gms.internal.ee
    protected Object J(String str) {
        return null;
    }

    @Override // com.google.android.gms.internal.ee
    protected boolean K(String str) {
        return false;
    }

    @Override // com.google.android.gms.internal.ee
    protected boolean a(ee.a aVar) {
        return this.zQ.contains(Integer.valueOf(aVar.bX()));
    }

    @Override // com.google.android.gms.internal.ee
    protected Object b(ee.a aVar) {
        switch (aVar.bX()) {
            case 2:
                return this.wJ;
            case 3:
            default:
                throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            case 4:
                return this.AM;
            case 5:
                return this.AE;
            case 6:
                return this.AN;
            case 7:
                return this.wF;
        }
    }

    @Override // com.google.android.gms.internal.ee
    public HashMap<String, ee.a<?, ?>> bQ() {
        return zP;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        gy gyVar = CREATOR;
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Set<Integer> eF() {
        return this.zQ;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eW() {
        return this.AM;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eX() {
        return this.AN;
    }

    @Override // com.google.android.gms.common.data.Freezable
    /* renamed from: eY, reason: merged with bridge method [inline-methods] */
    public gx freeze() {
        return this;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof gx)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        gx gxVar = (gx) obj;
        for (ee.a<?, ?> aVar : zP.values()) {
            if (a(aVar)) {
                if (gxVar.a(aVar) && b(aVar).equals(gxVar.b(aVar))) {
                }
                return false;
            }
            if (gxVar.a(aVar)) {
                return false;
            }
        }
        return true;
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public String getId() {
        return this.wJ;
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public ItemScope getResult() {
        return this.AM;
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public String getStartDate() {
        return this.AE;
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public ItemScope getTarget() {
        return this.AN;
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public String getType() {
        return this.wF;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.kZ;
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public boolean hasId() {
        return this.zQ.contains(2);
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public boolean hasResult() {
        return this.zQ.contains(4);
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public boolean hasStartDate() {
        return this.zQ.contains(5);
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public boolean hasTarget() {
        return this.zQ.contains(6);
    }

    @Override // com.google.android.gms.plus.model.moments.Moment
    public boolean hasType() {
        return this.zQ.contains(7);
    }

    public int hashCode() {
        int i = 0;
        Iterator<ee.a<?, ?>> it = zP.values().iterator();
        while (true) {
            int i2 = i;
            if (!it.hasNext()) {
                return i2;
            }
            ee.a<?, ?> next = it.next();
            if (a(next)) {
                i = b(next).hashCode() + i2 + next.bX();
            } else {
                i = i2;
            }
        }
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        gy gyVar = CREATOR;
        gy.a(this, out, flags);
    }
}
