package com.google.android.gms.internal;

import android.app.Activity;
import android.os.RemoteException;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;
import com.google.ads.mediation.admob.AdMobServerParameters;
import com.google.android.gms.internal.bc;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class be<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> extends bc.a {
    private final MediationAdapter<NETWORK_EXTRAS, SERVER_PARAMETERS> gf;
    private final NETWORK_EXTRAS gg;

    public be(MediationAdapter<NETWORK_EXTRAS, SERVER_PARAMETERS> mediationAdapter, NETWORK_EXTRAS network_extras) {
        this.gf = mediationAdapter;
        this.gg = network_extras;
    }

    private SERVER_PARAMETERS a(String str, int i, String str2) throws RemoteException {
        HashMap hashMap;
        try {
            if (str != null) {
                JSONObject jSONObject = new JSONObject(str);
                HashMap hashMap2 = new HashMap(jSONObject.length());
                Iterator<String> keys = jSONObject.keys();
                while (keys.hasNext()) {
                    String next = keys.next();
                    hashMap2.put(next, jSONObject.getString(next));
                }
                hashMap = hashMap2;
            } else {
                hashMap = new HashMap(0);
            }
            Class<SERVER_PARAMETERS> serverParametersType = this.gf.getServerParametersType();
            SERVER_PARAMETERS server_parameters = null;
            if (serverParametersType != null) {
                SERVER_PARAMETERS newInstance = serverParametersType.newInstance();
                newInstance.load(hashMap);
                server_parameters = newInstance;
            }
            if (server_parameters instanceof AdMobServerParameters) {
                AdMobServerParameters adMobServerParameters = (AdMobServerParameters) server_parameters;
                adMobServerParameters.adJson = str2;
                adMobServerParameters.tagForChildDirectedTreatment = i;
            }
            return server_parameters;
        } catch (Throwable th) {
            cs.b("Could not get MediationServerParameters.", th);
            throw new RemoteException();
        }
    }

    @Override // com.google.android.gms.internal.bc
    public void a(com.google.android.gms.dynamic.b bVar, v vVar, String str, bd bdVar) throws RemoteException {
        a(bVar, vVar, str, (String) null, bdVar);
    }

    @Override // com.google.android.gms.internal.bc
    public void a(com.google.android.gms.dynamic.b bVar, v vVar, String str, String str2, bd bdVar) throws RemoteException {
        if (!(this.gf instanceof MediationInterstitialAdapter)) {
            cs.v("MediationAdapter is not a MediationInterstitialAdapter: " + this.gf.getClass().getCanonicalName());
            throw new RemoteException();
        }
        cs.r("Requesting interstitial ad from adapter.");
        try {
            ((MediationInterstitialAdapter) this.gf).requestInterstitialAd(new bf(bdVar), (Activity) com.google.android.gms.dynamic.c.b(bVar), a(str, vVar.tagForChildDirectedTreatment, str2), bg.e(vVar), this.gg);
        } catch (Throwable th) {
            cs.b("Could not request interstitial ad from adapter.", th);
            throw new RemoteException();
        }
    }

    @Override // com.google.android.gms.internal.bc
    public void a(com.google.android.gms.dynamic.b bVar, x xVar, v vVar, String str, bd bdVar) throws RemoteException {
        a(bVar, xVar, vVar, str, null, bdVar);
    }

    @Override // com.google.android.gms.internal.bc
    public void a(com.google.android.gms.dynamic.b bVar, x xVar, v vVar, String str, String str2, bd bdVar) throws RemoteException {
        if (!(this.gf instanceof MediationBannerAdapter)) {
            cs.v("MediationAdapter is not a MediationBannerAdapter: " + this.gf.getClass().getCanonicalName());
            throw new RemoteException();
        }
        cs.r("Requesting banner ad from adapter.");
        try {
            ((MediationBannerAdapter) this.gf).requestBannerAd(new bf(bdVar), (Activity) com.google.android.gms.dynamic.c.b(bVar), a(str, vVar.tagForChildDirectedTreatment, str2), bg.b(xVar), bg.e(vVar), this.gg);
        } catch (Throwable th) {
            cs.b("Could not request banner ad from adapter.", th);
            throw new RemoteException();
        }
    }

    @Override // com.google.android.gms.internal.bc
    public void destroy() throws RemoteException {
        try {
            this.gf.destroy();
        } catch (Throwable th) {
            cs.b("Could not destroy adapter.", th);
            throw new RemoteException();
        }
    }

    @Override // com.google.android.gms.internal.bc
    public com.google.android.gms.dynamic.b getView() throws RemoteException {
        if (!(this.gf instanceof MediationBannerAdapter)) {
            cs.v("MediationAdapter is not a MediationBannerAdapter: " + this.gf.getClass().getCanonicalName());
            throw new RemoteException();
        }
        try {
            return com.google.android.gms.dynamic.c.h(((MediationBannerAdapter) this.gf).getBannerView());
        } catch (Throwable th) {
            cs.b("Could not get banner view from adapter.", th);
            throw new RemoteException();
        }
    }

    @Override // com.google.android.gms.internal.bc
    public void showInterstitial() throws RemoteException {
        if (!(this.gf instanceof MediationInterstitialAdapter)) {
            cs.v("MediationAdapter is not a MediationInterstitialAdapter: " + this.gf.getClass().getCanonicalName());
            throw new RemoteException();
        }
        cs.r("Showing interstitial from adapter.");
        try {
            ((MediationInterstitialAdapter) this.gf).showInterstitial();
        } catch (Throwable th) {
            cs.b("Could not show interstitial from adapter.", th);
            throw new RemoteException();
        }
    }
}
