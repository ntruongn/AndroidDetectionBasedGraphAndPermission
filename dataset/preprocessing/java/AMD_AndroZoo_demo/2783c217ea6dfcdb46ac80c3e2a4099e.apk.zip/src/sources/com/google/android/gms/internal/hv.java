package com.google.android.gms.internal;

import java.io.IOException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class hv {
    static final int CR = g(1, 3);
    static final int CS = g(1, 4);
    static final int CT = g(2, 0);
    static final int CU = g(3, 2);
    public static final int[] CV = new int[0];
    public static final long[] CW = new long[0];
    public static final float[] CX = new float[0];
    public static final double[] CY = new double[0];
    public static final boolean[] CZ = new boolean[0];
    public static final String[] Da = new String[0];
    public static final byte[][] Db = new byte[0];
    public static final byte[] Dc = new byte[0];

    public static boolean a(hq hqVar, int i) throws IOException {
        return hqVar.bq(i);
    }

    public static int bA(int i) {
        return i >>> 3;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int bz(int i) {
        return i & 7;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int g(int i, int i2) {
        return (i << 3) | i2;
    }
}
