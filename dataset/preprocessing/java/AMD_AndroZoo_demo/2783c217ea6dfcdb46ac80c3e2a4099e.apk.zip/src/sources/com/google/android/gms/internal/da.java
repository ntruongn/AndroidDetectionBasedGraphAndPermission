package com.google.android.gms.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.dc;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class da extends dc.a {
    @Override // com.google.android.gms.internal.dc
    public void a(int i, DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.dc
    public void a(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.dc
    public void onSignOutComplete() {
    }

    @Override // com.google.android.gms.internal.dc
    public void onStateDeleted(int statusCode, int stateKey) {
    }

    @Override // com.google.android.gms.internal.dc
    public void p(int i) {
    }
}
