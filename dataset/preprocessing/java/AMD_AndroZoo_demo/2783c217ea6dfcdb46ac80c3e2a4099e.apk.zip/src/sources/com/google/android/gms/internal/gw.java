package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.ads.AdSize;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.a;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class gw implements Parcelable.Creator<gv> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(gv gvVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        Set<Integer> eF = gvVar.eF();
        if (eF.contains(1)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, gvVar.getVersionCode());
        }
        if (eF.contains(2)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, (Parcelable) gvVar.eG(), i, true);
        }
        if (eF.contains(3)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, gvVar.getAdditionalName(), true);
        }
        if (eF.contains(4)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 4, (Parcelable) gvVar.eH(), i, true);
        }
        if (eF.contains(5)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, gvVar.getAddressCountry(), true);
        }
        if (eF.contains(6)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 6, gvVar.getAddressLocality(), true);
        }
        if (eF.contains(7)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 7, gvVar.getAddressRegion(), true);
        }
        if (eF.contains(8)) {
            com.google.android.gms.common.internal.safeparcel.b.b(parcel, 8, gvVar.eI(), true);
        }
        if (eF.contains(9)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 9, gvVar.getAttendeeCount());
        }
        if (eF.contains(10)) {
            com.google.android.gms.common.internal.safeparcel.b.b(parcel, 10, gvVar.eJ(), true);
        }
        if (eF.contains(11)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 11, (Parcelable) gvVar.eK(), i, true);
        }
        if (eF.contains(12)) {
            com.google.android.gms.common.internal.safeparcel.b.b(parcel, 12, gvVar.eL(), true);
        }
        if (eF.contains(13)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 13, gvVar.getBestRating(), true);
        }
        if (eF.contains(14)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 14, gvVar.getBirthDate(), true);
        }
        if (eF.contains(15)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 15, (Parcelable) gvVar.eM(), i, true);
        }
        if (eF.contains(17)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 17, gvVar.getContentSize(), true);
        }
        if (eF.contains(16)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 16, gvVar.getCaption(), true);
        }
        if (eF.contains(19)) {
            com.google.android.gms.common.internal.safeparcel.b.b(parcel, 19, gvVar.eN(), true);
        }
        if (eF.contains(18)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 18, gvVar.getContentUrl(), true);
        }
        if (eF.contains(21)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 21, gvVar.getDateModified(), true);
        }
        if (eF.contains(20)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 20, gvVar.getDateCreated(), true);
        }
        if (eF.contains(23)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 23, gvVar.getDescription(), true);
        }
        if (eF.contains(22)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 22, gvVar.getDatePublished(), true);
        }
        if (eF.contains(25)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 25, gvVar.getEmbedUrl(), true);
        }
        if (eF.contains(24)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 24, gvVar.getDuration(), true);
        }
        if (eF.contains(27)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 27, gvVar.getFamilyName(), true);
        }
        if (eF.contains(26)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 26, gvVar.getEndDate(), true);
        }
        if (eF.contains(29)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 29, (Parcelable) gvVar.eO(), i, true);
        }
        if (eF.contains(28)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 28, gvVar.getGender(), true);
        }
        if (eF.contains(31)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 31, gvVar.getHeight(), true);
        }
        if (eF.contains(30)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 30, gvVar.getGivenName(), true);
        }
        if (eF.contains(34)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 34, (Parcelable) gvVar.eP(), i, true);
        }
        if (eF.contains(32)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 32, gvVar.getId(), true);
        }
        if (eF.contains(33)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 33, gvVar.getImage(), true);
        }
        if (eF.contains(38)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 38, gvVar.getLongitude());
        }
        if (eF.contains(39)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 39, gvVar.getName(), true);
        }
        if (eF.contains(36)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 36, gvVar.getLatitude());
        }
        if (eF.contains(37)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 37, (Parcelable) gvVar.eQ(), i, true);
        }
        if (eF.contains(42)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 42, gvVar.getPlayerType(), true);
        }
        if (eF.contains(43)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 43, gvVar.getPostOfficeBoxNumber(), true);
        }
        if (eF.contains(40)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 40, (Parcelable) gvVar.eR(), i, true);
        }
        if (eF.contains(41)) {
            com.google.android.gms.common.internal.safeparcel.b.b(parcel, 41, gvVar.eS(), true);
        }
        if (eF.contains(46)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 46, (Parcelable) gvVar.eT(), i, true);
        }
        if (eF.contains(47)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 47, gvVar.getStartDate(), true);
        }
        if (eF.contains(44)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 44, gvVar.getPostalCode(), true);
        }
        if (eF.contains(45)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 45, gvVar.getRatingValue(), true);
        }
        if (eF.contains(51)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 51, gvVar.getThumbnailUrl(), true);
        }
        if (eF.contains(50)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 50, (Parcelable) gvVar.eU(), i, true);
        }
        if (eF.contains(49)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 49, gvVar.getText(), true);
        }
        if (eF.contains(48)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 48, gvVar.getStreetAddress(), true);
        }
        if (eF.contains(55)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 55, gvVar.getWidth(), true);
        }
        if (eF.contains(54)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 54, gvVar.getUrl(), true);
        }
        if (eF.contains(53)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 53, gvVar.getType(), true);
        }
        if (eF.contains(52)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 52, gvVar.getTickerSymbol(), true);
        }
        if (eF.contains(56)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 56, gvVar.getWorstRating(), true);
        }
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aR, reason: merged with bridge method [inline-methods] */
    public gv[] newArray(int i) {
        return new gv[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aj, reason: merged with bridge method [inline-methods] */
    public gv createFromParcel(Parcel parcel) {
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        HashSet hashSet = new HashSet();
        int i = 0;
        gv gvVar = null;
        ArrayList<String> arrayList = null;
        gv gvVar2 = null;
        String str = null;
        String str2 = null;
        String str3 = null;
        ArrayList arrayList2 = null;
        int i2 = 0;
        ArrayList arrayList3 = null;
        gv gvVar3 = null;
        ArrayList arrayList4 = null;
        String str4 = null;
        String str5 = null;
        gv gvVar4 = null;
        String str6 = null;
        String str7 = null;
        String str8 = null;
        ArrayList arrayList5 = null;
        String str9 = null;
        String str10 = null;
        String str11 = null;
        String str12 = null;
        String str13 = null;
        String str14 = null;
        String str15 = null;
        String str16 = null;
        String str17 = null;
        gv gvVar5 = null;
        String str18 = null;
        String str19 = null;
        String str20 = null;
        String str21 = null;
        gv gvVar6 = null;
        double d = 0.0d;
        gv gvVar7 = null;
        double d2 = 0.0d;
        String str22 = null;
        gv gvVar8 = null;
        ArrayList arrayList6 = null;
        String str23 = null;
        String str24 = null;
        String str25 = null;
        String str26 = null;
        gv gvVar9 = null;
        String str27 = null;
        String str28 = null;
        String str29 = null;
        gv gvVar10 = null;
        String str30 = null;
        String str31 = null;
        String str32 = null;
        String str33 = null;
        String str34 = null;
        String str35 = null;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(1);
                    break;
                case 2:
                    gv gvVar11 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(2);
                    gvVar = gvVar11;
                    break;
                case 3:
                    arrayList = com.google.android.gms.common.internal.safeparcel.a.y(parcel, j);
                    hashSet.add(3);
                    break;
                case 4:
                    gv gvVar12 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(4);
                    gvVar2 = gvVar12;
                    break;
                case 5:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(5);
                    break;
                case 6:
                    str2 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(6);
                    break;
                case 7:
                    str3 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(7);
                    break;
                case 8:
                    arrayList2 = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j, gv.CREATOR);
                    hashSet.add(8);
                    break;
                case 9:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(9);
                    break;
                case 10:
                    arrayList3 = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j, gv.CREATOR);
                    hashSet.add(10);
                    break;
                case 11:
                    gv gvVar13 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(11);
                    gvVar3 = gvVar13;
                    break;
                case 12:
                    arrayList4 = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j, gv.CREATOR);
                    hashSet.add(12);
                    break;
                case 13:
                    str4 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(13);
                    break;
                case Status.INTERRUPTED /* 14 */:
                    str5 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(14);
                    break;
                case Status.TIMEOUT /* 15 */:
                    gv gvVar14 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(15);
                    gvVar4 = gvVar14;
                    break;
                case 16:
                    str6 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(16);
                    break;
                case 17:
                    str7 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(17);
                    break;
                case 18:
                    str8 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(18);
                    break;
                case 19:
                    arrayList5 = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j, gv.CREATOR);
                    hashSet.add(19);
                    break;
                case 20:
                    str9 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(20);
                    break;
                case 21:
                    str10 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(21);
                    break;
                case 22:
                    str11 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(22);
                    break;
                case 23:
                    str12 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(23);
                    break;
                case 24:
                    str13 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(24);
                    break;
                case 25:
                    str14 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(25);
                    break;
                case 26:
                    str15 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(26);
                    break;
                case 27:
                    str16 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(27);
                    break;
                case 28:
                    str17 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(28);
                    break;
                case 29:
                    gv gvVar15 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(29);
                    gvVar5 = gvVar15;
                    break;
                case 30:
                    str18 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(30);
                    break;
                case 31:
                    str19 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(31);
                    break;
                case AdSize.LANDSCAPE_AD_HEIGHT /* 32 */:
                    str20 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(32);
                    break;
                case 33:
                    str21 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(33);
                    break;
                case 34:
                    gv gvVar16 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(34);
                    gvVar6 = gvVar16;
                    break;
                case 35:
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
                case 36:
                    d = com.google.android.gms.common.internal.safeparcel.a.k(parcel, j);
                    hashSet.add(36);
                    break;
                case 37:
                    gv gvVar17 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(37);
                    gvVar7 = gvVar17;
                    break;
                case 38:
                    d2 = com.google.android.gms.common.internal.safeparcel.a.k(parcel, j);
                    hashSet.add(38);
                    break;
                case 39:
                    str22 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(39);
                    break;
                case 40:
                    gv gvVar18 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(40);
                    gvVar8 = gvVar18;
                    break;
                case 41:
                    arrayList6 = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j, gv.CREATOR);
                    hashSet.add(41);
                    break;
                case 42:
                    str23 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(42);
                    break;
                case 43:
                    str24 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(43);
                    break;
                case 44:
                    str25 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(44);
                    break;
                case 45:
                    str26 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(45);
                    break;
                case 46:
                    gv gvVar19 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(46);
                    gvVar9 = gvVar19;
                    break;
                case 47:
                    str27 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(47);
                    break;
                case 48:
                    str28 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(48);
                    break;
                case 49:
                    str29 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(49);
                    break;
                case AdSize.PORTRAIT_AD_HEIGHT /* 50 */:
                    gv gvVar20 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(50);
                    gvVar10 = gvVar20;
                    break;
                case 51:
                    str30 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(51);
                    break;
                case 52:
                    str31 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(52);
                    break;
                case 53:
                    str32 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(53);
                    break;
                case 54:
                    str33 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(54);
                    break;
                case 55:
                    str34 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(55);
                    break;
                case 56:
                    str35 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(56);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new gv(hashSet, i, gvVar, arrayList, gvVar2, str, str2, str3, arrayList2, i2, arrayList3, gvVar3, arrayList4, str4, str5, gvVar4, str6, str7, str8, arrayList5, str9, str10, str11, str12, str13, str14, str15, str16, str17, gvVar5, str18, str19, str20, str21, gvVar6, d, gvVar7, d2, str22, gvVar8, arrayList6, str23, str24, str25, str26, gvVar9, str27, str28, str29, gvVar10, str30, str31, str32, str33, str34, str35);
    }
}
