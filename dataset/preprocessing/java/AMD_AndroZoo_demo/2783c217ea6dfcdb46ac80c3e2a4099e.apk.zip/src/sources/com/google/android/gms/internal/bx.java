package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.internal.bw;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class bx extends cl {
    private final bz fw;
    private final bw.a hl;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a extends bx {
        private final Context mContext;

        public a(Context context, bz bzVar, bw.a aVar) {
            super(bzVar, aVar);
            this.mContext = context;
        }

        @Override // com.google.android.gms.internal.bx
        public void ak() {
        }

        @Override // com.google.android.gms.internal.bx
        public cd al() {
            return ce.a(this.mContext, new ar());
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class b extends bx implements GooglePlayServicesClient.ConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener {
        private final Object fx;
        private final bw.a hl;
        private final by hm;

        public b(Context context, bz bzVar, bw.a aVar) {
            super(bzVar, aVar);
            this.fx = new Object();
            this.hl = aVar;
            this.hm = new by(context, this, this, bzVar.ej.iH);
            this.hm.connect();
        }

        @Override // com.google.android.gms.internal.bx
        public void ak() {
            synchronized (this.fx) {
                if (this.hm.isConnected() || this.hm.isConnecting()) {
                    this.hm.disconnect();
                }
            }
        }

        @Override // com.google.android.gms.internal.bx
        public cd al() {
            cd cdVar;
            synchronized (this.fx) {
                try {
                    cdVar = this.hm.ao();
                } catch (IllegalStateException e) {
                    cdVar = null;
                }
            }
            return cdVar;
        }

        @Override // com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks
        public void onConnected(Bundle connectionHint) {
            start();
        }

        @Override // com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener
        public void onConnectionFailed(ConnectionResult result) {
            this.hl.a(new cb(0));
        }

        @Override // com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks
        public void onDisconnected() {
            cs.r("Disconnected from remote ad request service.");
        }
    }

    public bx(bz bzVar, bw.a aVar) {
        this.fw = bzVar;
        this.hl = aVar;
    }

    private static cb a(cd cdVar, bz bzVar) {
        try {
            return cdVar.b(bzVar);
        } catch (RemoteException e) {
            cs.b("Could not fetch ad response from ad request service.", e);
            return null;
        }
    }

    @Override // com.google.android.gms.internal.cl
    public final void ai() {
        cb a2;
        try {
            cd al = al();
            if (al == null) {
                a2 = new cb(0);
            } else {
                a2 = a(al, this.fw);
                if (a2 == null) {
                    a2 = new cb(0);
                }
            }
            ak();
            this.hl.a(a2);
        } catch (Throwable th) {
            ak();
            throw th;
        }
    }

    public abstract void ak();

    public abstract cd al();

    @Override // com.google.android.gms.internal.cl
    public final void onStop() {
        ak();
    }
}
