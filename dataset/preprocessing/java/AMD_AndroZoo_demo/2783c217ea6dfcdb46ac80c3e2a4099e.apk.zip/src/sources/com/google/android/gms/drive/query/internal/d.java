package com.google.android.gms.drive.query.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
class d {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static MetadataField<?> b(MetadataBundle metadataBundle) {
        Set<MetadataField<?>> cF = metadataBundle.cF();
        if (cF.size() != 1) {
            throw new IllegalArgumentException("bundle should have exactly 1 populated field");
        }
        return cF.iterator().next();
    }
}
