package com.google.android.gms.internal;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.dynamic.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class bm implements SafeParcelable {
    public static final bl CREATOR = new bl();
    public final ct ej;
    public final bj gF;
    public final q gG;
    public final bn gH;
    public final cv gI;
    public final al gJ;
    public final String gK;
    public final boolean gL;
    public final String gM;
    public final bq gN;
    public final int gO;
    public final String gn;
    public final int orientation;
    public final int versionCode;

    /* JADX INFO: Access modifiers changed from: package-private */
    public bm(int i, bj bjVar, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4, String str, boolean z, String str2, IBinder iBinder5, int i2, int i3, String str3, ct ctVar) {
        this.versionCode = i;
        this.gF = bjVar;
        this.gG = (q) com.google.android.gms.dynamic.c.b(b.a.C(iBinder));
        this.gH = (bn) com.google.android.gms.dynamic.c.b(b.a.C(iBinder2));
        this.gI = (cv) com.google.android.gms.dynamic.c.b(b.a.C(iBinder3));
        this.gJ = (al) com.google.android.gms.dynamic.c.b(b.a.C(iBinder4));
        this.gK = str;
        this.gL = z;
        this.gM = str2;
        this.gN = (bq) com.google.android.gms.dynamic.c.b(b.a.C(iBinder5));
        this.orientation = i2;
        this.gO = i3;
        this.gn = str3;
        this.ej = ctVar;
    }

    public bm(bj bjVar, q qVar, bn bnVar, bq bqVar, ct ctVar) {
        this.versionCode = 1;
        this.gF = bjVar;
        this.gG = qVar;
        this.gH = bnVar;
        this.gI = null;
        this.gJ = null;
        this.gK = null;
        this.gL = false;
        this.gM = null;
        this.gN = bqVar;
        this.orientation = -1;
        this.gO = 4;
        this.gn = null;
        this.ej = ctVar;
    }

    public bm(q qVar, bn bnVar, al alVar, bq bqVar, cv cvVar, boolean z, int i, String str, ct ctVar) {
        this.versionCode = 1;
        this.gF = null;
        this.gG = qVar;
        this.gH = bnVar;
        this.gI = cvVar;
        this.gJ = alVar;
        this.gK = null;
        this.gL = z;
        this.gM = null;
        this.gN = bqVar;
        this.orientation = i;
        this.gO = 3;
        this.gn = str;
        this.ej = ctVar;
    }

    public bm(q qVar, bn bnVar, al alVar, bq bqVar, cv cvVar, boolean z, int i, String str, String str2, ct ctVar) {
        this.versionCode = 1;
        this.gF = null;
        this.gG = qVar;
        this.gH = bnVar;
        this.gI = cvVar;
        this.gJ = alVar;
        this.gK = str2;
        this.gL = z;
        this.gM = str;
        this.gN = bqVar;
        this.orientation = i;
        this.gO = 3;
        this.gn = null;
        this.ej = ctVar;
    }

    public bm(q qVar, bn bnVar, bq bqVar, cv cvVar, int i, ct ctVar) {
        this.versionCode = 1;
        this.gF = null;
        this.gG = qVar;
        this.gH = bnVar;
        this.gI = cvVar;
        this.gJ = null;
        this.gK = null;
        this.gL = false;
        this.gM = null;
        this.gN = bqVar;
        this.orientation = i;
        this.gO = 1;
        this.gn = null;
        this.ej = ctVar;
    }

    public bm(q qVar, bn bnVar, bq bqVar, cv cvVar, boolean z, int i, ct ctVar) {
        this.versionCode = 1;
        this.gF = null;
        this.gG = qVar;
        this.gH = bnVar;
        this.gI = cvVar;
        this.gJ = null;
        this.gK = null;
        this.gL = z;
        this.gM = null;
        this.gN = bqVar;
        this.orientation = i;
        this.gO = 2;
        this.gn = null;
        this.ej = ctVar;
    }

    public static bm a(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
            bundleExtra.setClassLoader(bm.class.getClassLoader());
            return (bm) bundleExtra.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
        } catch (Exception e) {
            return null;
        }
    }

    public static void a(Intent intent, bm bmVar) {
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", bmVar);
        intent.putExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", bundle);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public IBinder aa() {
        return com.google.android.gms.dynamic.c.h(this.gG).asBinder();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public IBinder ab() {
        return com.google.android.gms.dynamic.c.h(this.gH).asBinder();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public IBinder ac() {
        return com.google.android.gms.dynamic.c.h(this.gI).asBinder();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public IBinder ad() {
        return com.google.android.gms.dynamic.c.h(this.gJ).asBinder();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public IBinder ae() {
        return com.google.android.gms.dynamic.c.h(this.gN).asBinder();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        bl.a(this, out, flags);
    }
}
