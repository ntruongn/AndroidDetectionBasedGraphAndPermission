package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class Operator implements SafeParcelable {
    public static final Parcelable.Creator<Operator> CREATOR = new h();
    public static final Operator pr = new Operator("=");
    public static final Operator ps = new Operator("<");
    public static final Operator pt = new Operator("<=");
    public static final Operator pu = new Operator(">");
    public static final Operator pv = new Operator(">=");
    public static final Operator pw = new Operator("and");
    public static final Operator px = new Operator("or");
    public static final Operator py = new Operator("not");
    public static final Operator pz = new Operator("contains");
    final int kZ;
    final String mTag;

    /* JADX INFO: Access modifiers changed from: package-private */
    public Operator(int versionCode, String tag) {
        this.kZ = versionCode;
        this.mTag = tag;
    }

    private Operator(String tag) {
        this(1, tag);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            Operator operator = (Operator) obj;
            return this.mTag == null ? operator.mTag == null : this.mTag.equals(operator.mTag);
        }
        return false;
    }

    public int hashCode() {
        return (this.mTag == null ? 0 : this.mTag.hashCode()) + 31;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        h.a(this, out, flags);
    }
}
