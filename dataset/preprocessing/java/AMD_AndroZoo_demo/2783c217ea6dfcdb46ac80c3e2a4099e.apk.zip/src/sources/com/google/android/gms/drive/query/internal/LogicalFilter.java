package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.Filter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class LogicalFilter implements SafeParcelable, Filter {
    public static final Parcelable.Creator<LogicalFilter> CREATOR = new f();
    final int kZ;
    private List<Filter> pe;
    final Operator pf;
    final List<FilterHolder> pp;

    /* JADX INFO: Access modifiers changed from: package-private */
    public LogicalFilter(int versionCode, Operator operator, List<FilterHolder> filterHolders) {
        this.kZ = versionCode;
        this.pf = operator;
        this.pp = filterHolders;
    }

    public LogicalFilter(Operator operator, Filter filter, Filter... additionalFilters) {
        this.kZ = 1;
        this.pf = operator;
        this.pp = new ArrayList(additionalFilters.length + 1);
        this.pp.add(new FilterHolder(filter));
        this.pe = new ArrayList(additionalFilters.length + 1);
        this.pe.add(filter);
        for (Filter filter2 : additionalFilters) {
            this.pp.add(new FilterHolder(filter2));
            this.pe.add(filter2);
        }
    }

    public LogicalFilter(Operator operator, List<Filter> filters) {
        this.kZ = 1;
        this.pf = operator;
        this.pe = filters;
        this.pp = new ArrayList(filters.size());
        Iterator<Filter> it = filters.iterator();
        while (it.hasNext()) {
            this.pp.add(new FilterHolder(it.next()));
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        f.a(this, out, flags);
    }
}
