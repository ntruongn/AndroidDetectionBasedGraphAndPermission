package com.google.android.gms.internal;

import android.content.Context;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class cq extends cl {
    private final String iC;
    private final String iD;
    private final Context mContext;

    public cq(Context context, String str, String str2) {
        this.mContext = context;
        this.iC = str;
        this.iD = str2;
    }

    @Override // com.google.android.gms.internal.cl
    public void ai() {
        try {
            cs.u("Pinging URL: " + this.iD);
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(this.iD).openConnection();
            try {
                cn.a(this.mContext, this.iC, true, httpURLConnection);
                int responseCode = httpURLConnection.getResponseCode();
                if (responseCode < 200 || responseCode >= 300) {
                    cs.v("Received non-success response code " + responseCode + " from pinging URL: " + this.iD);
                }
            } finally {
                httpURLConnection.disconnect();
            }
        } catch (IOException e) {
            cs.v("Error while pinging URL: " + this.iD + ". " + e.getMessage());
        }
    }

    @Override // com.google.android.gms.internal.cl
    public void onStop() {
    }
}
