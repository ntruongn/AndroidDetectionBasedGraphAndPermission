package com.google.android.gms.internal;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class fa {
    private static final Cdo rF = new Cdo("Games");

    public static void a(String str, String str2) {
        rF.a(str, str2);
    }

    public static void a(String str, String str2, Throwable th) {
        rF.a(str, str2, th);
    }

    public static void b(String str, String str2) {
        rF.b(str, str2);
    }
}
