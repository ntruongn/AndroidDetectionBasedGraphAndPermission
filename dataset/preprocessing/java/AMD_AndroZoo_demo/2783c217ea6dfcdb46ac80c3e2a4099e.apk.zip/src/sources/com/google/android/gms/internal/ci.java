package com.google.android.gms.internal;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import java.util.Locale;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ci {
    public final int hW;
    public final boolean hX;
    public final boolean hY;
    public final String hZ;
    public final String ia;
    public final boolean ib;
    public final boolean ic;
    public final boolean id;
    public final String ie;

    /* renamed from: if, reason: not valid java name */
    public final String f1if;
    public final int ig;
    public final int ih;
    public final int ii;
    public final int ij;
    public final int ik;
    public final int il;
    public final float im;
    public final int in;
    public final int io;

    public ci(Context context) {
        AudioManager audioManager = (AudioManager) context.getSystemService("audio");
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        Locale locale = Locale.getDefault();
        PackageManager packageManager = context.getPackageManager();
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
        this.hW = audioManager.getMode();
        this.hX = a(packageManager, "geo:0,0?q=donuts") != null;
        this.hY = a(packageManager, "http://www.google.com") != null;
        this.hZ = telephonyManager.getNetworkOperator();
        this.ia = locale.getCountry();
        this.ib = cr.aw();
        this.ic = audioManager.isMusicActive();
        this.id = audioManager.isSpeakerphoneOn();
        this.ie = locale.getLanguage();
        this.f1if = a(packageManager);
        this.ig = audioManager.getStreamVolume(3);
        this.ih = a(context, connectivityManager, packageManager);
        this.ii = telephonyManager.getNetworkType();
        this.ij = telephonyManager.getPhoneType();
        this.ik = audioManager.getRingerMode();
        this.il = audioManager.getStreamVolume(2);
        this.im = displayMetrics.density;
        this.in = displayMetrics.widthPixels;
        this.io = displayMetrics.heightPixels;
    }

    private static int a(Context context, ConnectivityManager connectivityManager, PackageManager packageManager) {
        if (!cn.a(packageManager, context.getPackageName(), "android.permission.ACCESS_NETWORK_STATE")) {
            return -2;
        }
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo != null) {
            return activeNetworkInfo.getType();
        }
        return -1;
    }

    private static ResolveInfo a(PackageManager packageManager, String str) {
        return packageManager.resolveActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)), 65536);
    }

    private static String a(PackageManager packageManager) {
        ActivityInfo activityInfo;
        ResolveInfo a = a(packageManager, "market://details?id=com.google.android.gms.ads");
        if (a == null || (activityInfo = a.activityInfo) == null) {
            return null;
        }
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(activityInfo.packageName, 0);
            if (packageInfo != null) {
                return packageInfo.versionCode + "." + activityInfo.packageName;
            }
            return null;
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }
}
