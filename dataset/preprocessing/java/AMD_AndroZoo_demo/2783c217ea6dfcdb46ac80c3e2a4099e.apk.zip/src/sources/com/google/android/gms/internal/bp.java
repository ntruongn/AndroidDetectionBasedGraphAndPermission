package com.google.android.gms.internal;

import android.app.Activity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class bp extends FrameLayout implements View.OnClickListener {
    private final ImageButton gY;
    private final Activity gr;

    public bp(Activity activity, int i) {
        super(activity);
        this.gr = activity;
        setOnClickListener(this);
        this.gY = new ImageButton(activity);
        this.gY.setImageResource(17301527);
        this.gY.setBackgroundColor(0);
        this.gY.setOnClickListener(this);
        this.gY.setPadding(0, 0, 0, 0);
        int a = cr.a(activity, i);
        addView(this.gY, new FrameLayout.LayoutParams(a, a, 17));
    }

    public void g(boolean z) {
        this.gY.setVisibility(z ? 4 : 0);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        this.gr.finish();
    }
}
