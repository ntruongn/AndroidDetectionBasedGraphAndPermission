package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.drive.Contents;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class r implements Parcelable.Creator<OnContentsResponse> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(OnContentsResponse onContentsResponse, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, onContentsResponse.kZ);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, (Parcelable) onContentsResponse.nZ, i, false);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: C, reason: merged with bridge method [inline-methods] */
    public OnContentsResponse createFromParcel(Parcel parcel) {
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        Contents contents = null;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 2:
                    contents = (Contents) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, Contents.CREATOR);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new OnContentsResponse(i, contents);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: T, reason: merged with bridge method [inline-methods] */
    public OnContentsResponse[] newArray(int i) {
        return new OnContentsResponse[i];
    }
}
