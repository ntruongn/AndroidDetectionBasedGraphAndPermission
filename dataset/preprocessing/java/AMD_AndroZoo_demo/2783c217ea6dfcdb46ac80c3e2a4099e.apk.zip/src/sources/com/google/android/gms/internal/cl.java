package com.google.android.gms.internal;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class cl {
    private final Runnable ep = new Runnable() { // from class: com.google.android.gms.internal.cl.1
        @Override // java.lang.Runnable
        public final void run() {
            cl.this.it = Thread.currentThread();
            cl.this.ai();
        }
    };
    private volatile Thread it;

    public abstract void ai();

    public final void cancel() {
        onStop();
        if (this.it != null) {
            this.it.interrupt();
        }
    }

    public abstract void onStop();

    public final void start() {
        cm.execute(this.ep);
    }
}
