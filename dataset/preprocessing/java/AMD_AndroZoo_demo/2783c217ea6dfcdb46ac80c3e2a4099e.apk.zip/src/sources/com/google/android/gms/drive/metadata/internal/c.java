package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.et;
import com.google.android.gms.internal.eu;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class c {
    private static Map<String, MetadataField<?>> oS = new HashMap();

    static {
        b(et.oU);
        b(et.TITLE);
        b(et.MIME_TYPE);
        b(et.STARRED);
        b(et.TRASHED);
        b(et.oV);
        b(et.oW);
        b(et.PARENTS);
        b(eu.oZ);
        b(eu.oX);
        b(eu.oY);
        b(eu.pa);
    }

    public static MetadataField<?> P(String str) {
        return oS.get(str);
    }

    private static void b(MetadataField<?> metadataField) {
        if (oS.containsKey(metadataField.getName())) {
            throw new IllegalArgumentException("Duplicate field name registered: " + metadataField.getName());
        }
        oS.put(metadataField.getName(), metadataField);
    }

    public static Collection<MetadataField<?>> cD() {
        return Collections.unmodifiableCollection(oS.values());
    }
}
