package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.bz;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class bu {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface a {
        void a(cj cjVar);
    }

    public static cl a(Context context, bz.a aVar, h hVar, cv cvVar, bb bbVar, a aVar2) {
        bv bvVar = new bv(context, aVar, hVar, cvVar, bbVar, aVar2);
        bvVar.start();
        return bvVar;
    }
}
