package com.google.android.gms.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessage;
import com.google.android.gms.internal.fb;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class ew extends fb.a {
    @Override // com.google.android.gms.internal.fb
    public void A(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void B(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void C(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void a(int i, Bundle bundle) {
    }

    @Override // com.google.android.gms.internal.fb
    public void a(int i, String str, boolean z) {
    }

    @Override // com.google.android.gms.internal.fb
    public void a(DataHolder dataHolder, DataHolder dataHolder2) {
    }

    @Override // com.google.android.gms.internal.fb
    public void a(DataHolder dataHolder, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.fb
    public void ao(int i) {
    }

    @Override // com.google.android.gms.internal.fb
    public void ap(int i) {
    }

    @Override // com.google.android.gms.internal.fb
    public void aq(int i) {
    }

    @Override // com.google.android.gms.internal.fb
    public void ar(int i) {
    }

    @Override // com.google.android.gms.internal.fb
    public void b(int i, int i2, String str) {
    }

    @Override // com.google.android.gms.internal.fb
    public void b(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void b(DataHolder dataHolder, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.fb
    public void c(int i, String str) {
    }

    @Override // com.google.android.gms.internal.fb
    public void c(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void c(DataHolder dataHolder, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.fb
    public void d(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void d(DataHolder dataHolder, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.fb
    public void e(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void e(DataHolder dataHolder, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.fb
    public void f(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void f(DataHolder dataHolder, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.fb
    public void g(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void h(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void i(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void j(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void k(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void l(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void m(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void n(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void o(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void onAchievementUpdated(int statusCode, String achievementId) {
    }

    @Override // com.google.android.gms.internal.fb
    public void onInvitationRemoved(String invitationId) {
    }

    @Override // com.google.android.gms.internal.fb
    public void onLeftRoom(int statusCode, String roomId) {
    }

    @Override // com.google.android.gms.internal.fb
    public void onP2PConnected(String participantId) {
    }

    @Override // com.google.android.gms.internal.fb
    public void onP2PDisconnected(String participantId) {
    }

    @Override // com.google.android.gms.internal.fb
    public void onRealTimeMessageReceived(RealTimeMessage message) {
    }

    @Override // com.google.android.gms.internal.fb
    public void onSignOutComplete() {
    }

    @Override // com.google.android.gms.internal.fb
    public void onTurnBasedMatchCanceled(int statusCode, String externalMatchId) {
    }

    @Override // com.google.android.gms.internal.fb
    public void onTurnBasedMatchRemoved(String matchId) {
    }

    @Override // com.google.android.gms.internal.fb
    public void p(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void q(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void r(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void s(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void t(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void u(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void v(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void w(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void x(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void y(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.fb
    public void z(DataHolder dataHolder) {
    }
}
