package com.google.android.gms.internal;

import android.content.Context;
import android.content.Intent;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.Game;
import com.google.android.gms.games.GameBuffer;
import com.google.android.gms.games.GameEntity;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerBuffer;
import com.google.android.gms.games.PlayerEntity;
import com.google.android.gms.games.achievement.AchievementBuffer;
import com.google.android.gms.games.achievement.b;
import com.google.android.gms.games.c;
import com.google.android.gms.games.f;
import com.google.android.gms.games.leaderboard.Leaderboard;
import com.google.android.gms.games.leaderboard.LeaderboardBuffer;
import com.google.android.gms.games.leaderboard.LeaderboardScore;
import com.google.android.gms.games.leaderboard.LeaderboardScoreBuffer;
import com.google.android.gms.games.leaderboard.h;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.InvitationBuffer;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;
import com.google.android.gms.games.multiplayer.ParticipantResult;
import com.google.android.gms.games.multiplayer.ParticipantUtils;
import com.google.android.gms.games.multiplayer.c;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessage;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessageReceivedListener;
import com.google.android.gms.games.multiplayer.realtime.RealTimeSocket;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.google.android.gms.games.multiplayer.realtime.RoomStatusUpdateListener;
import com.google.android.gms.games.multiplayer.realtime.RoomUpdateListener;
import com.google.android.gms.games.multiplayer.realtime.a;
import com.google.android.gms.games.multiplayer.turnbased.LoadMatchesResponse;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchUpdateReceivedListener;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatch;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatchBuffer;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatchConfig;
import com.google.android.gms.games.multiplayer.turnbased.b;
import com.google.android.gms.internal.dk;
import com.google.android.gms.internal.fc;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ex extends dk<fc> implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    private final String jD;
    private boolean qI;
    private int qJ;
    private final String qM;
    private final Map<String, fe> qN;
    private PlayerEntity qO;
    private GameEntity qP;
    private final fd qQ;
    private boolean qR;
    private final Binder qS;
    private final long qT;
    private final boolean qU;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    abstract class a extends c {
        private final ArrayList<String> qV;

        a(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            super(roomStatusUpdateListener, dataHolder);
            this.qV = new ArrayList<>();
            for (String str : strArr) {
                this.qV.add(str);
            }
        }

        @Override // com.google.android.gms.internal.ex.c
        protected void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            a(roomStatusUpdateListener, room, this.qV);
        }

        protected abstract void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class aa extends dk<fc>.b<RoomStatusUpdateListener> {
        private final String rm;

        aa(RoomStatusUpdateListener roomStatusUpdateListener, String str) {
            super(roomStatusUpdateListener);
            this.rm = str;
        }

        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(RoomStatusUpdateListener roomStatusUpdateListener) {
            if (roomStatusUpdateListener != null) {
                roomStatusUpdateListener.onP2PConnected(this.rm);
            }
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ab extends dk<fc>.b<RoomStatusUpdateListener> {
        private final String rm;

        ab(RoomStatusUpdateListener roomStatusUpdateListener, String str) {
            super(roomStatusUpdateListener);
            this.rm = str;
        }

        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(RoomStatusUpdateListener roomStatusUpdateListener) {
            if (roomStatusUpdateListener != null) {
                roomStatusUpdateListener.onP2PDisconnected(this.rm);
            }
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ac extends a {
        ac(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            super(roomStatusUpdateListener, dataHolder, strArr);
        }

        @Override // com.google.android.gms.internal.ex.a
        protected void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeersConnected(room, arrayList);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ad extends a {
        ad(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            super(roomStatusUpdateListener, dataHolder, strArr);
        }

        @Override // com.google.android.gms.internal.ex.a
        protected void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeerDeclined(room, arrayList);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ae extends a {
        ae(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            super(roomStatusUpdateListener, dataHolder, strArr);
        }

        @Override // com.google.android.gms.internal.ex.a
        protected void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeersDisconnected(room, arrayList);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class af extends a {
        af(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            super(roomStatusUpdateListener, dataHolder, strArr);
        }

        @Override // com.google.android.gms.internal.ex.a
        protected void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeerInvitedToRoom(room, arrayList);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ag extends a {
        ag(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            super(roomStatusUpdateListener, dataHolder, strArr);
        }

        @Override // com.google.android.gms.internal.ex.a
        protected void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeerJoined(room, arrayList);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ah extends a {
        ah(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            super(roomStatusUpdateListener, dataHolder, strArr);
        }

        @Override // com.google.android.gms.internal.ex.a
        protected void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeerLeft(room, arrayList);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ai extends ew {
        private final a.c<h.b> jN;

        ai(a.c<h.b> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void C(DataHolder dataHolder) {
            ex.this.a(new aj(this.jN, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class aj extends dk<fc>.c<a.c<h.b>> implements h.b {
        private final Status jP;
        private final com.google.android.gms.games.leaderboard.d rn;

        aj(a.c<h.b> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
            this.jP = new Status(dataHolder.getStatusCode());
            LeaderboardScoreBuffer leaderboardScoreBuffer = new LeaderboardScoreBuffer(dataHolder);
            try {
                if (leaderboardScoreBuffer.getCount() > 0) {
                    this.rn = (com.google.android.gms.games.leaderboard.d) leaderboardScoreBuffer.get(0).freeze();
                } else {
                    this.rn = null;
                }
            } finally {
                leaderboardScoreBuffer.close();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<h.b> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.leaderboard.h.b
        public LeaderboardScore cR() {
            return this.rn;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ak extends ew {
        private final a.c<f.a> jN;

        ak(a.c<f.a> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void e(DataHolder dataHolder) {
            ex.this.a(new al(this.jN, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class al extends ao<a.c<f.a>> implements f.a {
        private final PlayerBuffer ro;

        al(a.c<f.a> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
            this.ro = new PlayerBuffer(dataHolder);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<f.a> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.f.a
        public PlayerBuffer cJ() {
            return this.ro;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class am extends dk<fc>.b<a.InterfaceC0010a> {
        private final int ka;
        private final String rp;
        private final int rq;

        am(a.InterfaceC0010a interfaceC0010a, int i, int i2, String str) {
            super(interfaceC0010a);
            this.ka = i;
            this.rq = i2;
            this.rp = str;
        }

        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(a.InterfaceC0010a interfaceC0010a) {
            if (interfaceC0010a != null) {
                interfaceC0010a.onRealTimeMessageSent(this.ka, this.rq, this.rp);
            }
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class an extends ew {
        final a.InterfaceC0010a rr;

        public an(a.InterfaceC0010a interfaceC0010a) {
            this.rr = interfaceC0010a;
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void b(int i, int i2, String str) {
            ex.this.a(new am(this.rr, i, i2, str));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    abstract class ao<R extends a.c<?>> extends dk<fc>.c<R> implements Releasable, Result {
        final Status jP;
        final DataHolder lb;

        public ao(R r, DataHolder dataHolder) {
            super(r, dataHolder);
            this.jP = new Status(dataHolder.getStatusCode());
            this.lb = dataHolder;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }

        @Override // com.google.android.gms.common.api.Releasable
        public void release() {
            if (this.lb != null) {
                this.lb.close();
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ap extends c {
        ap(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            super(roomStatusUpdateListener, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.c
        public void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            roomStatusUpdateListener.onRoomAutoMatching(room);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class aq extends ew {
        private final RoomUpdateListener rs;
        private final RoomStatusUpdateListener rt;
        private final RealTimeMessageReceivedListener ru;

        public aq(RoomUpdateListener roomUpdateListener) {
            this.rs = (RoomUpdateListener) du.c(roomUpdateListener, "Callbacks must not be null");
            this.rt = null;
            this.ru = null;
        }

        public aq(RoomUpdateListener roomUpdateListener, RoomStatusUpdateListener roomStatusUpdateListener, RealTimeMessageReceivedListener realTimeMessageReceivedListener) {
            this.rs = (RoomUpdateListener) du.c(roomUpdateListener, "Callbacks must not be null");
            this.rt = roomStatusUpdateListener;
            this.ru = realTimeMessageReceivedListener;
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void a(DataHolder dataHolder, String[] strArr) {
            ex.this.a(new af(this.rt, dataHolder, strArr));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void b(DataHolder dataHolder, String[] strArr) {
            ex.this.a(new ag(this.rt, dataHolder, strArr));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void c(DataHolder dataHolder, String[] strArr) {
            ex.this.a(new ah(this.rt, dataHolder, strArr));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void d(DataHolder dataHolder, String[] strArr) {
            ex.this.a(new ad(this.rt, dataHolder, strArr));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void e(DataHolder dataHolder, String[] strArr) {
            ex.this.a(new ac(this.rt, dataHolder, strArr));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void f(DataHolder dataHolder, String[] strArr) {
            ex.this.a(new ae(this.rt, dataHolder, strArr));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void onLeftRoom(int statusCode, String externalRoomId) {
            ex.this.a(new v(this.rs, statusCode, externalRoomId));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void onP2PConnected(String participantId) {
            ex.this.a(new aa(this.rt, participantId));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void onP2PDisconnected(String participantId) {
            ex.this.a(new ab(this.rt, participantId));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void onRealTimeMessageReceived(RealTimeMessage message) {
            ex.this.a(new z(this.ru, message));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void s(DataHolder dataHolder) {
            ex.this.a(new at(this.rs, dataHolder));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void t(DataHolder dataHolder) {
            ex.this.a(new q(this.rs, dataHolder));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void u(DataHolder dataHolder) {
            ex.this.a(new as(this.rt, dataHolder));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void v(DataHolder dataHolder) {
            ex.this.a(new ap(this.rt, dataHolder));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void w(DataHolder dataHolder) {
            ex.this.a(new ar(this.rs, dataHolder));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void x(DataHolder dataHolder) {
            ex.this.a(new h(this.rt, dataHolder));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void y(DataHolder dataHolder) {
            ex.this.a(new i(this.rt, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ar extends b {
        ar(RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            super(roomUpdateListener, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.b
        public void a(RoomUpdateListener roomUpdateListener, Room room, int i) {
            roomUpdateListener.onRoomConnected(i, room);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class as extends c {
        as(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            super(roomStatusUpdateListener, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.c
        public void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            roomStatusUpdateListener.onRoomConnecting(room);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class at extends b {
        public at(RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            super(roomUpdateListener, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.b
        public void a(RoomUpdateListener roomUpdateListener, Room room, int i) {
            roomUpdateListener.onRoomCreated(i, room);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class au extends ew {
        private final a.c<Status> jN;

        public au(a.c<Status> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void onSignOutComplete() {
            ex.this.a(new av(this.jN, new Status(0)));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class av extends dk<fc>.b<a.c<Status>> {
        private final Status jP;

        public av(a.c<Status> cVar, Status status) {
            super(cVar);
            this.jP = status;
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }

        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void b(a.c<Status> cVar) {
            cVar.a(this.jP);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class aw extends ew {
        private final a.c<h.d> jN;

        public aw(a.c<h.d> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void d(DataHolder dataHolder) {
            ex.this.a(new ax(this.jN, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ax extends ao<a.c<h.d>> implements h.d {
        private final com.google.android.gms.games.leaderboard.i rv;

        public ax(a.c<h.d> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
            this.rv = new com.google.android.gms.games.leaderboard.i(dataHolder);
        }

        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<h.d> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.leaderboard.h.d
        public com.google.android.gms.games.leaderboard.i cS() {
            return this.rv;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    abstract class ay<T extends a.c<?>> extends ao<T> {
        final TurnBasedMatch rk;

        ay(T t, DataHolder dataHolder) {
            super(t, dataHolder);
            TurnBasedMatchBuffer turnBasedMatchBuffer = new TurnBasedMatchBuffer(dataHolder);
            try {
                if (turnBasedMatchBuffer.getCount() > 0) {
                    this.rk = turnBasedMatchBuffer.get(0).freeze();
                } else {
                    this.rk = null;
                }
            } finally {
                turnBasedMatchBuffer.close();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(T t, DataHolder dataHolder) {
            f(t);
        }

        public TurnBasedMatch cT() {
            return this.rk;
        }

        abstract void f(T t);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class az extends ew {
        private final a.c<b.a> rw;

        public az(a.c<b.a> cVar) {
            this.rw = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void onTurnBasedMatchCanceled(int statusCode, String matchId) {
            ex.this.a(new ba(this.rw, new Status(statusCode), matchId));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    abstract class b extends dk<fc>.c<RoomUpdateListener> {
        b(RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            super(roomUpdateListener, dataHolder);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            a(roomUpdateListener, ex.this.D(dataHolder), dataHolder.getStatusCode());
        }

        protected abstract void a(RoomUpdateListener roomUpdateListener, Room room, int i);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class ba extends dk<fc>.b<a.c<b.a>> implements b.a {
        private final Status jP;
        private final String rx;

        ba(a.c<b.a> cVar, Status status, String str) {
            super(cVar);
            this.jP = status;
            this.rx = str;
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }

        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void b(a.c<b.a> cVar) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.multiplayer.turnbased.b.a
        public String getMatchId() {
            return this.rx;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class bb extends ew {
        private final a.c<b.InterfaceC0011b> ry;

        public bb(a.c<b.InterfaceC0011b> cVar) {
            this.ry = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void m(DataHolder dataHolder) {
            ex.this.a(new bc(this.ry, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class bc extends ay<a.c<b.InterfaceC0011b>> implements b.InterfaceC0011b {
        bc(a.c<b.InterfaceC0011b> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.ay
        protected void f(a.c<b.InterfaceC0011b> cVar) {
            cVar.a(this);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class bd extends ew {
        private final a.c<b.c> rz;

        public bd(a.c<b.c> cVar) {
            this.rz = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void o(DataHolder dataHolder) {
            ex.this.a(new be(this.rz, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class be extends ay<a.c<b.c>> implements b.c {
        be(a.c<b.c> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.ay
        protected void f(a.c<b.c> cVar) {
            cVar.a(this);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class bf extends ew {
        private final a.c<b.d> rA;

        public bf(a.c<b.d> cVar) {
            this.rA = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void l(DataHolder dataHolder) {
            ex.this.a(new bg(this.rA, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class bg extends ay<a.c<b.d>> implements b.d {
        bg(a.c<b.d> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.ay
        protected void f(a.c<b.d> cVar) {
            cVar.a(this);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class bh extends ew {
        private final a.c<b.f> rB;

        public bh(a.c<b.f> cVar) {
            this.rB = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void n(DataHolder dataHolder) {
            ex.this.a(new bi(this.rB, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class bi extends ay<a.c<b.f>> implements b.f {
        bi(a.c<b.f> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.ay
        protected void f(a.c<b.f> cVar) {
            cVar.a(this);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class bj extends ew {
        private final a.c<b.e> rC;

        public bj(a.c<b.e> cVar) {
            this.rC = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void a(int i, Bundle bundle) {
            bundle.setClassLoader(getClass().getClassLoader());
            ex.this.a(new bk(this.rC, new Status(i), bundle));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class bk extends dk<fc>.b<a.c<b.e>> implements b.e {
        private final Status jP;
        private final Bundle rD;
        private final LoadMatchesResponse rE;

        bk(a.c<b.e> cVar, Status status, Bundle bundle) {
            super(cVar);
            this.jP = status;
            this.rD = bundle;
            this.rE = new LoadMatchesResponse(bundle);
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
            release();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void b(a.c<b.e> cVar) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.multiplayer.turnbased.b.e
        public LoadMatchesResponse cU() {
            return this.rE;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }

        @Override // com.google.android.gms.common.api.Releasable
        public void release() {
            Iterator<String> it = this.rD.keySet().iterator();
            while (it.hasNext()) {
                DataHolder dataHolder = (DataHolder) this.rD.getParcelable(it.next());
                if (dataHolder != null) {
                    dataHolder.close();
                }
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    abstract class c extends dk<fc>.c<RoomStatusUpdateListener> {
        c(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            super(roomStatusUpdateListener, dataHolder);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            a(roomStatusUpdateListener, ex.this.D(dataHolder));
        }

        protected abstract void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class d extends ew {
        private final a.c<b.InterfaceC0009b> jN;

        d(a.c<b.InterfaceC0009b> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void onAchievementUpdated(int statusCode, String achievementId) {
            ex.this.a(new e(this.jN, statusCode, achievementId));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class e extends dk<fc>.b<a.c<b.InterfaceC0009b>> implements b.InterfaceC0009b {
        private final Status jP;
        private final String qX;

        e(a.c<b.InterfaceC0009b> cVar, int i, String str) {
            super(cVar);
            this.jP = new Status(i);
            this.qX = str;
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void b(a.c<b.InterfaceC0009b> cVar) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.achievement.b.InterfaceC0009b
        public String getAchievementId() {
            return this.qX;
        }

        @Override // com.google.android.gms.common.api.Result
        public Status getStatus() {
            return this.jP;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class f extends ew {
        private final a.c<b.a> jN;

        f(a.c<b.a> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void b(DataHolder dataHolder) {
            ex.this.a(new g(this.jN, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class g extends ao<a.c<b.a>> implements b.a {
        private final AchievementBuffer qY;

        g(a.c<b.a> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
            this.qY = new AchievementBuffer(dataHolder);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<b.a> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.achievement.b.a
        public AchievementBuffer cK() {
            return this.qY;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class h extends c {
        h(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            super(roomStatusUpdateListener, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.c
        public void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            roomStatusUpdateListener.onConnectedToRoom(room);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class i extends c {
        i(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            super(roomStatusUpdateListener, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.c
        public void a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            roomStatusUpdateListener.onDisconnectedFromRoom(room);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class j extends ew {
        private final a.c<c.a> jN;

        j(a.c<c.a> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void g(DataHolder dataHolder) {
            ex.this.a(new k(this.jN, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class k extends ao<a.c<c.a>> implements c.a {
        private final GameBuffer qZ;

        k(a.c<c.a> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
            this.qZ = new GameBuffer(dataHolder);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<c.a> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.c.a
        public GameBuffer cI() {
            return this.qZ;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class l extends ew {
        private final OnInvitationReceivedListener ra;

        l(OnInvitationReceivedListener onInvitationReceivedListener) {
            this.ra = onInvitationReceivedListener;
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void k(DataHolder dataHolder) {
            InvitationBuffer invitationBuffer = new InvitationBuffer(dataHolder);
            try {
                Invitation freeze = invitationBuffer.getCount() > 0 ? invitationBuffer.get(0).freeze() : null;
                if (freeze != null) {
                    ex.this.a(new m(this.ra, freeze));
                }
            } finally {
                invitationBuffer.close();
            }
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void onInvitationRemoved(String invitationId) {
            ex.this.a(new n(this.ra, invitationId));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class m extends dk<fc>.b<OnInvitationReceivedListener> {
        private final Invitation rb;

        m(OnInvitationReceivedListener onInvitationReceivedListener, Invitation invitation) {
            super(onInvitationReceivedListener);
            this.rb = invitation;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(OnInvitationReceivedListener onInvitationReceivedListener) {
            onInvitationReceivedListener.onInvitationReceived(this.rb);
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class n extends dk<fc>.b<OnInvitationReceivedListener> {
        private final String rc;

        n(OnInvitationReceivedListener onInvitationReceivedListener, String str) {
            super(onInvitationReceivedListener);
            this.rc = str;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(OnInvitationReceivedListener onInvitationReceivedListener) {
            onInvitationReceivedListener.onInvitationRemoved(this.rc);
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class o extends ew {
        private final a.c<c.a> jN;

        o(a.c<c.a> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void j(DataHolder dataHolder) {
            ex.this.a(new p(this.jN, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class p extends ao<a.c<c.a>> implements c.a {
        private final InvitationBuffer rd;

        p(a.c<c.a> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
            this.rd = new InvitationBuffer(dataHolder);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<c.a> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.multiplayer.c.a
        public InvitationBuffer getInvitations() {
            return this.rd;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class q extends b {
        public q(RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            super(roomUpdateListener, dataHolder);
        }

        @Override // com.google.android.gms.internal.ex.b
        public void a(RoomUpdateListener roomUpdateListener, Room room, int i) {
            roomUpdateListener.onJoinedRoom(i, room);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class r extends ew {
        private final a.c<h.c> jN;

        r(a.c<h.c> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void a(DataHolder dataHolder, DataHolder dataHolder2) {
            ex.this.a(new s(this.jN, dataHolder, dataHolder2));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class s extends ao<a.c<h.c>> implements h.c {
        private final com.google.android.gms.games.leaderboard.a re;
        private final LeaderboardScoreBuffer rf;

        s(a.c<h.c> cVar, DataHolder dataHolder, DataHolder dataHolder2) {
            super(cVar, dataHolder2);
            LeaderboardBuffer leaderboardBuffer = new LeaderboardBuffer(dataHolder);
            try {
                if (leaderboardBuffer.getCount() > 0) {
                    this.re = (com.google.android.gms.games.leaderboard.a) leaderboardBuffer.get(0).freeze();
                } else {
                    this.re = null;
                }
                leaderboardBuffer.close();
                this.rf = new LeaderboardScoreBuffer(dataHolder2);
            } catch (Throwable th) {
                leaderboardBuffer.close();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<h.c> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.leaderboard.h.c
        public Leaderboard cO() {
            return this.re;
        }

        @Override // com.google.android.gms.games.leaderboard.h.c
        public LeaderboardScoreBuffer cP() {
            return this.rf;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class t extends ew {
        private final a.c<h.a> jN;

        t(a.c<h.a> cVar) {
            this.jN = (a.c) du.c(cVar, "Holder must not be null");
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void c(DataHolder dataHolder) {
            ex.this.a(new u(this.jN, dataHolder));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class u extends ao<a.c<h.a>> implements h.a {
        private final LeaderboardBuffer rg;

        u(a.c<h.a> cVar, DataHolder dataHolder) {
            super(cVar, dataHolder);
            this.rg = new LeaderboardBuffer(dataHolder);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(a.c<h.a> cVar, DataHolder dataHolder) {
            cVar.a(this);
        }

        @Override // com.google.android.gms.games.leaderboard.h.a
        public LeaderboardBuffer cQ() {
            return this.rg;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class v extends dk<fc>.b<RoomUpdateListener> {
        private final int ka;
        private final String rh;

        v(RoomUpdateListener roomUpdateListener, int i, String str) {
            super(roomUpdateListener);
            this.ka = i;
            this.rh = str;
        }

        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(RoomUpdateListener roomUpdateListener) {
            roomUpdateListener.onLeftRoom(this.ka, this.rh);
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class w extends dk<fc>.b<OnTurnBasedMatchUpdateReceivedListener> {
        private final String ri;

        w(OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener, String str) {
            super(onTurnBasedMatchUpdateReceivedListener);
            this.ri = str;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener) {
            onTurnBasedMatchUpdateReceivedListener.onTurnBasedMatchRemoved(this.ri);
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class x extends ew {
        private final OnTurnBasedMatchUpdateReceivedListener rj;

        x(OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener) {
            this.rj = onTurnBasedMatchUpdateReceivedListener;
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void onTurnBasedMatchRemoved(String matchId) {
            ex.this.a(new w(this.rj, matchId));
        }

        @Override // com.google.android.gms.internal.ew, com.google.android.gms.internal.fb
        public void p(DataHolder dataHolder) {
            TurnBasedMatchBuffer turnBasedMatchBuffer = new TurnBasedMatchBuffer(dataHolder);
            try {
                TurnBasedMatch freeze = turnBasedMatchBuffer.getCount() > 0 ? turnBasedMatchBuffer.get(0).freeze() : null;
                if (freeze != null) {
                    ex.this.a(new y(this.rj, freeze));
                }
            } finally {
                turnBasedMatchBuffer.close();
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class y extends dk<fc>.b<OnTurnBasedMatchUpdateReceivedListener> {
        private final TurnBasedMatch rk;

        y(OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener, TurnBasedMatch turnBasedMatch) {
            super(onTurnBasedMatchUpdateReceivedListener);
            this.rk = turnBasedMatch;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener) {
            onTurnBasedMatchUpdateReceivedListener.onTurnBasedMatchReceived(this.rk);
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class z extends dk<fc>.b<RealTimeMessageReceivedListener> {
        private final RealTimeMessage rl;

        z(RealTimeMessageReceivedListener realTimeMessageReceivedListener, RealTimeMessage realTimeMessage) {
            super(realTimeMessageReceivedListener);
            this.rl = realTimeMessage;
        }

        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(RealTimeMessageReceivedListener realTimeMessageReceivedListener) {
            if (realTimeMessageReceivedListener != null) {
                realTimeMessageReceivedListener.onRealTimeMessageReceived(this.rl);
            }
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    public ex(Context context, String str, String str2, GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener, String[] strArr, int i2, View view, boolean z2, boolean z3, int i3) {
        super(context, connectionCallbacks, onConnectionFailedListener, strArr);
        this.qR = false;
        this.qI = false;
        this.qM = str;
        this.jD = (String) du.f(str2);
        this.qS = new Binder();
        this.qN = new HashMap();
        this.qQ = fd.a(this, i2);
        setViewForPopups(view);
        this.qI = z3;
        this.qJ = i3;
        this.qT = hashCode();
        this.qU = z2;
        registerConnectionCallbacks((GoogleApiClient.ConnectionCallbacks) this);
        registerConnectionFailedListener((GoogleApiClient.OnConnectionFailedListener) this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Room D(DataHolder dataHolder) {
        com.google.android.gms.games.multiplayer.realtime.b bVar = new com.google.android.gms.games.multiplayer.realtime.b(dataHolder);
        try {
            return bVar.getCount() > 0 ? bVar.get(0).freeze() : null;
        } finally {
            bVar.close();
        }
    }

    private fe R(String str) {
        fe feVar;
        try {
            String T = bC().T(str);
            if (T == null) {
                feVar = null;
            } else {
                LocalSocket localSocket = new LocalSocket();
                try {
                    localSocket.connect(new LocalSocketAddress(T));
                    feVar = new fe(localSocket, str);
                    this.qN.put(str, feVar);
                } catch (IOException e2) {
                    fa.b("GamesClientImpl", "connect() call failed on socket: " + e2.getMessage());
                    feVar = null;
                }
            }
            return feVar;
        } catch (RemoteException e3) {
            fa.b("GamesClientImpl", "Unable to create socket. Service died.");
            return null;
        }
    }

    private void cL() {
        this.qO = null;
    }

    private void cM() {
        Iterator<fe> it = this.qN.values().iterator();
        while (it.hasNext()) {
            try {
                it.next().close();
            } catch (IOException e2) {
                fa.a("GamesClientImpl", "IOException:", e2);
            }
        }
        this.qN.clear();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.internal.dk
    /* renamed from: D, reason: merged with bridge method [inline-methods] */
    public fc p(IBinder iBinder) {
        return fc.a.F(iBinder);
    }

    public int a(a.InterfaceC0010a interfaceC0010a, byte[] bArr, String str, String str2) {
        try {
            return bC().a(new an(interfaceC0010a), bArr, str, str2);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
            return -1;
        }
    }

    public int a(byte[] bArr, String str, String[] strArr) {
        du.c(strArr, "Participant IDs must not be null");
        try {
            return bC().b(bArr, str, strArr);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
            return -1;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.internal.dk
    public void a(int i2, IBinder iBinder, Bundle bundle) {
        if (i2 == 0 && bundle != null) {
            this.qR = bundle.getBoolean("show_welcome_popup");
        }
        super.a(i2, iBinder, bundle);
    }

    public void a(IBinder iBinder, Bundle bundle) {
        if (isConnected()) {
            try {
                bC().a(iBinder, bundle);
            } catch (RemoteException e2) {
                fa.a("GamesClientImpl", "service died");
            }
        }
    }

    public void a(a.c<f.a> cVar, int i2, boolean z2, boolean z3) {
        try {
            bC().a(new ak(cVar), i2, z2, z3);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<h.c> cVar, LeaderboardScoreBuffer leaderboardScoreBuffer, int i2, int i3) {
        try {
            bC().a(new r(cVar), leaderboardScoreBuffer.de().df(), i2, i3);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<b.InterfaceC0011b> cVar, TurnBasedMatchConfig turnBasedMatchConfig) {
        try {
            bC().a(new bb(cVar), turnBasedMatchConfig.getVariant(), turnBasedMatchConfig.getMinPlayers(), turnBasedMatchConfig.getInvitedPlayerIds(), turnBasedMatchConfig.getAutoMatchCriteria());
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<f.a> cVar, String str) {
        try {
            bC().c(new ak(cVar), str);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<b.InterfaceC0009b> cVar, String str, int i2) {
        d dVar;
        if (cVar == null) {
            dVar = null;
        } else {
            try {
                dVar = new d(cVar);
            } catch (RemoteException e2) {
                fa.a("GamesClientImpl", "service died");
                return;
            }
        }
        bC().a(dVar, str, i2, this.qQ.db(), this.qQ.da());
    }

    public void a(a.c<h.c> cVar, String str, int i2, int i3, int i4, boolean z2) {
        try {
            bC().a(new r(cVar), str, i2, i3, i4, z2);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<h.d> cVar, String str, long j2, String str2) {
        aw awVar;
        if (cVar == null) {
            awVar = null;
        } else {
            try {
                awVar = new aw(cVar);
            } catch (RemoteException e2) {
                fa.a("GamesClientImpl", "service died");
                return;
            }
        }
        bC().a(awVar, str, j2, str2);
    }

    public void a(a.c<b.c> cVar, String str, String str2) {
        try {
            bC().d(new bd(cVar), str, str2);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<h.b> cVar, String str, String str2, int i2, int i3) {
        try {
            bC().a(new ai(cVar), str, str2, i2, i3);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<h.a> cVar, String str, boolean z2) {
        try {
            bC().c(new t(cVar), str, z2);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<b.f> cVar, String str, byte[] bArr, String str2, ParticipantResult[] participantResultArr) {
        try {
            bC().a(new bh(cVar), str, bArr, str2, participantResultArr);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<b.f> cVar, String str, byte[] bArr, ParticipantResult[] participantResultArr) {
        try {
            bC().a(new bh(cVar), str, bArr, participantResultArr);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<h.a> cVar, boolean z2) {
        try {
            bC().c(new t(cVar), z2);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void a(a.c<b.e> cVar, int[] iArr) {
        try {
            bC().a(new bj(cVar), iArr);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    @Override // com.google.android.gms.internal.dk
    protected void a(dq dqVar, dk.d dVar) throws RemoteException {
        String locale = getContext().getResources().getConfiguration().locale.toString();
        Bundle bundle = new Bundle();
        bundle.putBoolean("com.google.android.gms.games.key.isHeadless", this.qU);
        bundle.putBoolean("com.google.android.gms.games.key.showConnectingPopup", this.qI);
        bundle.putInt("com.google.android.gms.games.key.connectingPopupGravity", this.qJ);
        dqVar.a(dVar, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.jD, bA(), this.qM, this.qQ.db(), locale, bundle);
    }

    @Override // com.google.android.gms.internal.dk
    protected void a(String... strArr) {
        boolean z2 = false;
        boolean z3 = false;
        for (String str : strArr) {
            if (str.equals(Scopes.GAMES)) {
                z3 = true;
            } else if (str.equals("https://www.googleapis.com/auth/games.firstparty")) {
                z2 = true;
            }
        }
        if (z2) {
            du.a(!z3, String.format("Cannot have both %s and %s!", Scopes.GAMES, "https://www.googleapis.com/auth/games.firstparty"));
        } else {
            du.a(z3, String.format("Games APIs requires %s to function.", Scopes.GAMES));
        }
    }

    @Override // com.google.android.gms.internal.dk
    protected String am() {
        return "com.google.android.gms.games.service.START";
    }

    @Override // com.google.android.gms.internal.dk
    protected String an() {
        return "com.google.android.gms.games.internal.IGamesService";
    }

    public void b(a.c<Status> cVar) {
        try {
            bC().a(new au(cVar));
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void b(a.c<b.InterfaceC0009b> cVar, String str) {
        d dVar;
        if (cVar == null) {
            dVar = null;
        } else {
            try {
                dVar = new d(cVar);
            } catch (RemoteException e2) {
                fa.a("GamesClientImpl", "service died");
                return;
            }
        }
        bC().a(dVar, str, this.qQ.db(), this.qQ.da());
    }

    public void b(a.c<b.InterfaceC0009b> cVar, String str, int i2) {
        d dVar;
        if (cVar == null) {
            dVar = null;
        } else {
            try {
                dVar = new d(cVar);
            } catch (RemoteException e2) {
                fa.a("GamesClientImpl", "service died");
                return;
            }
        }
        bC().b(dVar, str, i2, this.qQ.db(), this.qQ.da());
    }

    public void b(a.c<h.c> cVar, String str, int i2, int i3, int i4, boolean z2) {
        try {
            bC().b(new r(cVar), str, i2, i3, i4, z2);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void b(a.c<b.a> cVar, boolean z2) {
        try {
            bC().b(new f(cVar), z2);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    @Override // com.google.android.gms.internal.dk, com.google.android.gms.internal.dl.b
    public Bundle bc() {
        try {
            Bundle bc2 = bC().bc();
            if (bc2 == null) {
                return bc2;
            }
            bc2.setClassLoader(ex.class.getClassLoader());
            return bc2;
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
            return null;
        }
    }

    public void c(a.c<b.InterfaceC0009b> cVar, String str) {
        d dVar;
        if (cVar == null) {
            dVar = null;
        } else {
            try {
                dVar = new d(cVar);
            } catch (RemoteException e2) {
                fa.a("GamesClientImpl", "service died");
                return;
            }
        }
        bC().b(dVar, str, this.qQ.db(), this.qQ.da());
    }

    public void cN() {
        if (isConnected()) {
            try {
                bC().cN();
            } catch (RemoteException e2) {
                fa.a("GamesClientImpl", "service died");
            }
        }
    }

    public void clearNotifications(int notificationTypes) {
        try {
            bC().clearNotifications(notificationTypes);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    @Override // com.google.android.gms.internal.dk, com.google.android.gms.common.GooglePlayServicesClient
    public void connect() {
        cL();
        super.connect();
    }

    public void createRoom(RoomConfig config) {
        try {
            bC().a(new aq(config.getRoomUpdateListener(), config.getRoomStatusUpdateListener(), config.getMessageReceivedListener()), this.qS, config.getVariant(), config.getInvitedPlayerIds(), config.getAutoMatchCriteria(), config.isSocketEnabled(), this.qT);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void d(a.c<c.a> cVar) {
        try {
            bC().d(new j(cVar));
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void d(a.c<b.InterfaceC0011b> cVar, String str) {
        try {
            bC().n(new bb(cVar), str);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    @Override // com.google.android.gms.internal.dk, com.google.android.gms.common.GooglePlayServicesClient
    public void disconnect() {
        this.qR = false;
        if (isConnected()) {
            try {
                fc bC = bC();
                bC.cN();
                bC.f(this.qT);
            } catch (RemoteException e2) {
                fa.a("GamesClientImpl", "Failed to notify client disconnect.");
            }
        }
        cM();
        super.disconnect();
    }

    public void dismissTurnBasedMatch(String matchId) {
        try {
            bC().X(matchId);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void e(a.c<c.a> cVar) {
        try {
            bC().e(new o(cVar));
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void e(a.c<b.InterfaceC0011b> cVar, String str) {
        try {
            bC().o(new bb(cVar), str);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void f(a.c<b.c> cVar, String str) {
        try {
            bC().q(new bd(cVar), str);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void g(a.c<b.a> cVar, String str) {
        try {
            bC().p(new az(cVar), str);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public Intent getAchievementsIntent() {
        bB();
        Intent intent = new Intent("com.google.android.gms.games.VIEW_ACHIEVEMENTS");
        intent.addFlags(67108864);
        return ez.c(intent);
    }

    public Intent getAllLeaderboardsIntent() {
        bB();
        Intent intent = new Intent("com.google.android.gms.games.VIEW_LEADERBOARDS");
        intent.putExtra("com.google.android.gms.games.GAME_PACKAGE_NAME", this.qM);
        intent.addFlags(67108864);
        return ez.c(intent);
    }

    public String getAppId() {
        try {
            return bC().getAppId();
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
            return null;
        }
    }

    public String getCurrentAccountName() {
        try {
            return bC().getCurrentAccountName();
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
            return null;
        }
    }

    public Game getCurrentGame() {
        bB();
        synchronized (this) {
            if (this.qP == null) {
                try {
                    GameBuffer gameBuffer = new GameBuffer(bC().cX());
                    try {
                        if (gameBuffer.getCount() > 0) {
                            this.qP = (GameEntity) gameBuffer.get(0).freeze();
                        }
                    } finally {
                        gameBuffer.close();
                    }
                } catch (RemoteException e2) {
                    fa.a("GamesClientImpl", "service died");
                }
            }
        }
        return this.qP;
    }

    public Player getCurrentPlayer() {
        bB();
        synchronized (this) {
            if (this.qO == null) {
                try {
                    PlayerBuffer playerBuffer = new PlayerBuffer(bC().cV());
                    try {
                        if (playerBuffer.getCount() > 0) {
                            this.qO = (PlayerEntity) playerBuffer.get(0).freeze();
                        }
                    } finally {
                        playerBuffer.close();
                    }
                } catch (RemoteException e2) {
                    fa.a("GamesClientImpl", "service died");
                }
            }
        }
        return this.qO;
    }

    public String getCurrentPlayerId() {
        try {
            return bC().getCurrentPlayerId();
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
            return null;
        }
    }

    public Intent getInvitationInboxIntent() {
        bB();
        Intent intent = new Intent("com.google.android.gms.games.SHOW_INVITATIONS");
        intent.putExtra("com.google.android.gms.games.GAME_PACKAGE_NAME", this.qM);
        return ez.c(intent);
    }

    public Intent getLeaderboardIntent(String leaderboardId) {
        bB();
        Intent intent = new Intent("com.google.android.gms.games.VIEW_LEADERBOARD_SCORES");
        intent.putExtra("com.google.android.gms.games.LEADERBOARD_ID", leaderboardId);
        intent.addFlags(67108864);
        return ez.c(intent);
    }

    public Intent getMatchInboxIntent() {
        bB();
        Intent intent = new Intent("com.google.android.gms.games.SHOW_MULTIPLAYER_INBOX");
        intent.putExtra("com.google.android.gms.games.GAME_PACKAGE_NAME", this.qM);
        return ez.c(intent);
    }

    public int getMaxTurnBasedMatchDataSize() {
        try {
            return bC().getMaxTurnBasedMatchDataSize();
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
            return 2;
        }
    }

    public Intent getPlayerSearchIntent() {
        bB();
        return ez.c(new Intent("com.google.android.gms.games.PLAYER_SEARCH"));
    }

    public RealTimeSocket getRealTimeSocketForParticipant(String roomId, String participantId) {
        if (participantId == null || !ParticipantUtils.Y(participantId)) {
            throw new IllegalArgumentException("Bad participant ID");
        }
        fe feVar = this.qN.get(participantId);
        return (feVar == null || feVar.isClosed()) ? R(participantId) : feVar;
    }

    public Intent getRealTimeWaitingRoomIntent(Room room, int minParticipantsToStart) {
        bB();
        Intent intent = new Intent("com.google.android.gms.games.SHOW_REAL_TIME_WAITING_ROOM");
        du.c(room, "Room parameter must not be null");
        intent.putExtra(GamesClient.EXTRA_ROOM, room.freeze());
        du.a(minParticipantsToStart >= 0, "minParticipantsToStart must be >= 0");
        intent.putExtra("com.google.android.gms.games.MIN_PARTICIPANTS_TO_START", minParticipantsToStart);
        return ez.c(intent);
    }

    public Intent getSelectPlayersIntent(int minPlayers, int maxPlayers, boolean allowAutomatch) {
        bB();
        Intent intent = new Intent("com.google.android.gms.games.SELECT_PLAYERS");
        intent.putExtra("com.google.android.gms.games.MIN_SELECTIONS", minPlayers);
        intent.putExtra("com.google.android.gms.games.MAX_SELECTIONS", maxPlayers);
        intent.putExtra("com.google.android.gms.games.SHOW_AUTOMATCH", allowAutomatch);
        return ez.c(intent);
    }

    public Intent getSettingsIntent() {
        bB();
        Intent intent = new Intent("com.google.android.gms.games.SHOW_SETTINGS");
        intent.putExtra("com.google.android.gms.games.GAME_PACKAGE_NAME", this.qM);
        intent.addFlags(67108864);
        return ez.c(intent);
    }

    public void h(a.c<b.d> cVar, String str) {
        try {
            bC().r(new bf(cVar), str);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void h(String str, int i2) {
        try {
            bC().h(str, i2);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void i(String str, int i2) {
        try {
            bC().i(str, i2);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void joinRoom(RoomConfig config) {
        try {
            bC().a(new aq(config.getRoomUpdateListener(), config.getRoomStatusUpdateListener(), config.getMessageReceivedListener()), this.qS, config.getInvitationId(), config.isSocketEnabled(), this.qT);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void leaveRoom(RoomUpdateListener listener, String roomId) {
        try {
            bC().e(new aq(listener), roomId);
            cM();
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks
    public void onConnected(Bundle connectionHint) {
        if (this.qR) {
            this.qQ.cZ();
            this.qR = false;
        }
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener
    public void onConnectionFailed(ConnectionResult result) {
        this.qR = false;
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks
    public void onDisconnected() {
    }

    public void registerInvitationListener(OnInvitationReceivedListener listener) {
        try {
            bC().a(new l(listener), this.qT);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void registerMatchUpdateListener(OnTurnBasedMatchUpdateReceivedListener listener) {
        try {
            bC().b(new x(listener), this.qT);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public int sendUnreliableRealTimeMessageToAll(byte[] messageData, String roomId) {
        try {
            return bC().b(messageData, roomId, (String[]) null);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
            return -1;
        }
    }

    public void setGravityForPopups(int gravity) {
        this.qQ.setGravity(gravity);
    }

    public void setViewForPopups(View gamesContentView) {
        this.qQ.e(gamesContentView);
    }

    public void unregisterInvitationListener() {
        try {
            bC().g(this.qT);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }

    public void unregisterMatchUpdateListener() {
        try {
            bC().h(this.qT);
        } catch (RemoteException e2) {
            fa.a("GamesClientImpl", "service died");
        }
    }
}
