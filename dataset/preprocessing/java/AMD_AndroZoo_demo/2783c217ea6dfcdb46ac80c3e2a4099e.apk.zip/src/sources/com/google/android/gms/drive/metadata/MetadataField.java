package com.google.android.gms.drive.metadata;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.du;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class MetadataField<T> {
    private final String oQ;
    private final Set<String> oR;

    /* JADX INFO: Access modifiers changed from: protected */
    public MetadataField(String fieldName) {
        this.oQ = (String) du.c(fieldName, "fieldName");
        this.oR = Collections.singleton(fieldName);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public MetadataField(String fieldName, Collection<String> dataHolderFieldNames) {
        this.oQ = (String) du.c(fieldName, "fieldName");
        this.oR = Collections.unmodifiableSet(new HashSet(dataHolderFieldNames));
    }

    protected abstract void a(Bundle bundle, T t);

    public final void a(DataHolder dataHolder, MetadataBundle metadataBundle, int i, int i2) {
        du.c(dataHolder, "dataHolder");
        du.c(metadataBundle, "bundle");
        metadataBundle.b(this, c(dataHolder, i, i2));
    }

    public final void a(T t, Bundle bundle) {
        du.c(bundle, "bundle");
        if (t == null) {
            bundle.putString(getName(), null);
        } else {
            a(bundle, (Bundle) t);
        }
    }

    protected abstract T b(DataHolder dataHolder, int i, int i2);

    public final T c(DataHolder dataHolder, int i, int i2) {
        Iterator<String> it = this.oR.iterator();
        while (it.hasNext()) {
            if (dataHolder.hasNull(it.next(), i, i2)) {
                return null;
            }
        }
        return b(dataHolder, i, i2);
    }

    public final Collection<String> cC() {
        return this.oR;
    }

    public final T d(Bundle bundle) {
        du.c(bundle, "bundle");
        if (bundle.get(getName()) != null) {
            return e(bundle);
        }
        return null;
    }

    protected abstract T e(Bundle bundle);

    public final String getName() {
        return this.oQ;
    }

    public String toString() {
        return this.oQ;
    }
}
