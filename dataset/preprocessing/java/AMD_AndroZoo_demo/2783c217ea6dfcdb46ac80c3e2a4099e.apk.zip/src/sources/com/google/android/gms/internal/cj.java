package com.google.android.gms.internal;

import java.util.Collections;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class cj {
    public final int errorCode;
    public final List<String> fK;
    public final List<String> fL;
    public final long fO;
    public final cv gI;
    public final at ga;
    public final bc gb;
    public final String gc;
    public final aw gd;
    public final v hp;
    public final String hs;
    public final long hv;
    public final boolean hw;
    public final long hx;
    public final List<String> hy;
    public final au ip;
    public final x iq;
    public final int orientation;

    public cj(v vVar, cv cvVar, List<String> list, int i, List<String> list2, List<String> list3, int i2, long j, String str, boolean z, at atVar, bc bcVar, String str2, au auVar, aw awVar, long j2, x xVar, long j3) {
        this.hp = vVar;
        this.gI = cvVar;
        this.fK = list != null ? Collections.unmodifiableList(list) : null;
        this.errorCode = i;
        this.fL = list2 != null ? Collections.unmodifiableList(list2) : null;
        this.hy = list3 != null ? Collections.unmodifiableList(list3) : null;
        this.orientation = i2;
        this.fO = j;
        this.hs = str;
        this.hw = z;
        this.ga = atVar;
        this.gb = bcVar;
        this.gc = str2;
        this.ip = auVar;
        this.gd = awVar;
        this.hx = j2;
        this.iq = xVar;
        this.hv = j3;
    }
}
