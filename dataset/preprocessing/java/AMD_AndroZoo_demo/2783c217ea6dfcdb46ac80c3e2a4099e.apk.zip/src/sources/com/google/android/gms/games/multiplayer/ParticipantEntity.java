package com.google.android.gms.games.multiplayer;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerEntity;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.eo;
import com.google.android.gms.internal.ey;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ParticipantEntity extends ey implements Participant {
    public static final Parcelable.Creator<ParticipantEntity> CREATOR = new a();
    private final int kZ;
    private final String pW;
    private final Uri qb;
    private final Uri qc;
    private final String rm;
    private final boolean sA;
    private final PlayerEntity sB;
    private final int sC;
    private final ParticipantResult sD;
    private final int sy;
    private final String sz;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    static final class a extends d {
        a() {
        }

        @Override // com.google.android.gms.games.multiplayer.d, android.os.Parcelable.Creator
        /* renamed from: X, reason: merged with bridge method [inline-methods] */
        public ParticipantEntity createFromParcel(Parcel parcel) {
            if (ParticipantEntity.c(ParticipantEntity.cH()) || ParticipantEntity.D(ParticipantEntity.class.getCanonicalName())) {
                return super.createFromParcel(parcel);
            }
            String readString = parcel.readString();
            String readString2 = parcel.readString();
            String readString3 = parcel.readString();
            Uri parse = readString3 == null ? null : Uri.parse(readString3);
            String readString4 = parcel.readString();
            return new ParticipantEntity(2, readString, readString2, parse, readString4 == null ? null : Uri.parse(readString4), parcel.readInt(), parcel.readString(), parcel.readInt() > 0, parcel.readInt() > 0 ? PlayerEntity.CREATOR.createFromParcel(parcel) : null, 7, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ParticipantEntity(int versionCode, String participantId, String displayName, Uri iconImageUri, Uri hiResImageUri, int status, String clientAddress, boolean connectedToRoom, PlayerEntity player, int capabilities, ParticipantResult result) {
        this.kZ = versionCode;
        this.rm = participantId;
        this.pW = displayName;
        this.qb = iconImageUri;
        this.qc = hiResImageUri;
        this.sy = status;
        this.sz = clientAddress;
        this.sA = connectedToRoom;
        this.sB = player;
        this.sC = capabilities;
        this.sD = result;
    }

    public ParticipantEntity(Participant participant) {
        this.kZ = 2;
        this.rm = participant.getParticipantId();
        this.pW = participant.getDisplayName();
        this.qb = participant.getIconImageUri();
        this.qc = participant.getHiResImageUri();
        this.sy = participant.getStatus();
        this.sz = participant.dm();
        this.sA = participant.isConnectedToRoom();
        Player player = participant.getPlayer();
        this.sB = player == null ? null : new PlayerEntity(player);
        this.sC = participant.getCapabilities();
        this.sD = participant.getResult();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int a(Participant participant) {
        return ds.hashCode(participant.getPlayer(), Integer.valueOf(participant.getStatus()), participant.dm(), Boolean.valueOf(participant.isConnectedToRoom()), participant.getDisplayName(), participant.getIconImageUri(), participant.getHiResImageUri(), Integer.valueOf(participant.getCapabilities()), participant.getResult());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a(Participant participant, Object obj) {
        if (!(obj instanceof Participant)) {
            return false;
        }
        if (participant == obj) {
            return true;
        }
        Participant participant2 = (Participant) obj;
        return ds.equal(participant2.getPlayer(), participant.getPlayer()) && ds.equal(Integer.valueOf(participant2.getStatus()), Integer.valueOf(participant.getStatus())) && ds.equal(participant2.dm(), participant.dm()) && ds.equal(Boolean.valueOf(participant2.isConnectedToRoom()), Boolean.valueOf(participant.isConnectedToRoom())) && ds.equal(participant2.getDisplayName(), participant.getDisplayName()) && ds.equal(participant2.getIconImageUri(), participant.getIconImageUri()) && ds.equal(participant2.getHiResImageUri(), participant.getHiResImageUri()) && ds.equal(Integer.valueOf(participant2.getCapabilities()), Integer.valueOf(participant.getCapabilities())) && ds.equal(participant2.getResult(), participant.getResult());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String b(Participant participant) {
        return ds.e(participant).a("Player", participant.getPlayer()).a("Status", Integer.valueOf(participant.getStatus())).a("ClientAddress", participant.dm()).a("ConnectedToRoom", Boolean.valueOf(participant.isConnectedToRoom())).a("DisplayName", participant.getDisplayName()).a("IconImage", participant.getIconImageUri()).a("HiResImage", participant.getHiResImageUri()).a("Capabilities", Integer.valueOf(participant.getCapabilities())).a("Result", participant.getResult()).toString();
    }

    static /* synthetic */ Integer cH() {
        return by();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public String dm() {
        return this.sz;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.google.android.gms.common.data.Freezable
    public Participant freeze() {
        return this;
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public int getCapabilities() {
        return this.sC;
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public String getDisplayName() {
        return this.sB == null ? this.pW : this.sB.getDisplayName();
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public void getDisplayName(CharArrayBuffer dataOut) {
        if (this.sB == null) {
            eo.b(this.pW, dataOut);
        } else {
            this.sB.getDisplayName(dataOut);
        }
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public Uri getHiResImageUri() {
        return this.sB == null ? this.qc : this.sB.getHiResImageUri();
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public Uri getIconImageUri() {
        return this.sB == null ? this.qb : this.sB.getIconImageUri();
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public String getParticipantId() {
        return this.rm;
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public Player getPlayer() {
        return this.sB;
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public ParticipantResult getResult() {
        return this.sD;
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public int getStatus() {
        return this.sy;
    }

    public int getVersionCode() {
        return this.kZ;
    }

    public int hashCode() {
        return a(this);
    }

    @Override // com.google.android.gms.games.multiplayer.Participant
    public boolean isConnectedToRoom() {
        return this.sA;
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        return b(this);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        if (!bz()) {
            d.a(this, dest, flags);
            return;
        }
        dest.writeString(this.rm);
        dest.writeString(this.pW);
        dest.writeString(this.qb == null ? null : this.qb.toString());
        dest.writeString(this.qc != null ? this.qc.toString() : null);
        dest.writeInt(this.sy);
        dest.writeString(this.sz);
        dest.writeInt(this.sA ? 1 : 0);
        dest.writeInt(this.sB != null ? 1 : 0);
        if (this.sB != null) {
            this.sB.writeToParcel(dest, flags);
        }
    }
}
