package com.google.android.gms.internal;

import com.huprya.wqkqze112375.IM;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ch {
    private String hM;
    private String hN;
    private String hO;
    private List<String> hP;
    private List<String> hQ;
    private List<String> hU;
    private long hR = -1;
    private boolean hS = false;
    private final long hT = -1;
    private long hV = -1;
    private int mOrientation = -1;

    private static long a(Map<String, List<String>> map, String str) {
        List<String> list = map.get(str);
        if (list != null && !list.isEmpty()) {
            try {
                return Float.parseFloat(r0) * 1000.0f;
            } catch (NumberFormatException e) {
                cs.v("Could not parse float from " + str + " header: " + list.get(0));
            }
        }
        return -1L;
    }

    private static List<String> b(Map<String, List<String>> map, String str) {
        String str2;
        List<String> list = map.get(str);
        if (list == null || list.isEmpty() || (str2 = list.get(0)) == null) {
            return null;
        }
        return Arrays.asList(str2.trim().split("\\s+"));
    }

    private void e(Map<String, List<String>> map) {
        List<String> list = map.get("X-Afma-Ad-Size");
        if (list == null || list.isEmpty()) {
            return;
        }
        this.hM = list.get(0);
    }

    private void f(Map<String, List<String>> map) {
        List<String> b = b(map, "X-Afma-Click-Tracking-Urls");
        if (b != null) {
            this.hP = b;
        }
    }

    private void g(Map<String, List<String>> map) {
        List<String> b = b(map, "X-Afma-Tracking-Urls");
        if (b != null) {
            this.hQ = b;
        }
    }

    private void h(Map<String, List<String>> map) {
        long a = a(map, "X-Afma-Interstitial-Timeout");
        if (a != -1) {
            this.hR = a;
        }
    }

    private void i(Map<String, List<String>> map) {
        List<String> list = map.get("X-Afma-Mediation");
        if (list == null || list.isEmpty()) {
            return;
        }
        this.hS = Boolean.valueOf(list.get(0)).booleanValue();
    }

    private void j(Map<String, List<String>> map) {
        List<String> b = b(map, "X-Afma-Manual-Tracking-Urls");
        if (b != null) {
            this.hU = b;
        }
    }

    private void k(Map<String, List<String>> map) {
        long a = a(map, "X-Afma-Refresh-Rate");
        if (a != -1) {
            this.hV = a;
        }
    }

    private void l(Map<String, List<String>> map) {
        List<String> list = map.get("X-Afma-Orientation");
        if (list == null || list.isEmpty()) {
            return;
        }
        String str = list.get(0);
        if (IM.ORIENTATION_PORTRAIT.equalsIgnoreCase(str)) {
            this.mOrientation = cn.au();
        } else if (IM.ORIENTATION_LANDSCAPE.equalsIgnoreCase(str)) {
            this.mOrientation = cn.at();
        }
    }

    public void a(String str, Map<String, List<String>> map, String str2) {
        this.hN = str;
        this.hO = str2;
        d(map);
    }

    public cb aq() {
        return new cb(this.hN, this.hO, this.hP, this.hQ, this.hR, this.hS, -1L, this.hU, this.hV, this.mOrientation, this.hM);
    }

    public void d(Map<String, List<String>> map) {
        e(map);
        f(map);
        g(map);
        h(map);
        i(map);
        j(map);
        k(map);
        l(map);
    }
}
