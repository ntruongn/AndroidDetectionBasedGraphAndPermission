package com.google.android.gms.internal;

import android.content.Context;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class cy extends cw {
    public cy(cv cvVar, boolean z) {
        super(cvVar, z);
    }

    private static WebResourceResponse b(Context context, String str, String str2) throws IOException {
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str2).openConnection();
        try {
            cn.a(context, str, true, httpURLConnection);
            httpURLConnection.connect();
            return new WebResourceResponse("application/javascript", "UTF-8", new ByteArrayInputStream(cn.a(new InputStreamReader(httpURLConnection.getInputStream())).getBytes("UTF-8")));
        } finally {
            httpURLConnection.disconnect();
        }
    }

    @Override // android.webkit.WebViewClient
    public WebResourceResponse shouldInterceptRequest(WebView webView, String url) {
        WebResourceResponse b;
        try {
            if (!"mraid.js".equalsIgnoreCase(new File(url).getName())) {
                b = super.shouldInterceptRequest(webView, url);
            } else if (webView instanceof cv) {
                cv cvVar = (cv) webView;
                cvVar.aB().Y();
                if (cvVar.y().eG) {
                    cs.u("shouldInterceptRequest(http://media.admob.com/mraid/v1/mraid_app_interstitial.js)");
                    b = b(cvVar.getContext(), this.gu.aD().iF, "http://media.admob.com/mraid/v1/mraid_app_interstitial.js");
                } else if (cvVar.aE()) {
                    cs.u("shouldInterceptRequest(http://media.admob.com/mraid/v1/mraid_app_expanded_banner.js)");
                    b = b(cvVar.getContext(), this.gu.aD().iF, "http://media.admob.com/mraid/v1/mraid_app_expanded_banner.js");
                } else {
                    cs.u("shouldInterceptRequest(http://media.admob.com/mraid/v1/mraid_app_banner.js)");
                    b = b(cvVar.getContext(), this.gu.aD().iF, "http://media.admob.com/mraid/v1/mraid_app_banner.js");
                }
            } else {
                cs.v("Tried to intercept request from a WebView that wasn't an AdWebView.");
                b = super.shouldInterceptRequest(webView, url);
            }
            return b;
        } catch (IOException e) {
            cs.v("Could not fetching MRAID JS. " + e.getMessage());
            return super.shouldInterceptRequest(webView, url);
        }
    }
}
