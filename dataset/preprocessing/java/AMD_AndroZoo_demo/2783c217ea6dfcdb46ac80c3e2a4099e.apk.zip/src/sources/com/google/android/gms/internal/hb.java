package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.internal.ha;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class hb implements Parcelable.Creator<ha> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(ha haVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        Set<Integer> eF = haVar.eF();
        if (eF.contains(1)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, haVar.getVersionCode());
        }
        if (eF.contains(2)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, haVar.getAboutMe(), true);
        }
        if (eF.contains(3)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, (Parcelable) haVar.fa(), i, true);
        }
        if (eF.contains(4)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 4, haVar.getBirthday(), true);
        }
        if (eF.contains(5)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, haVar.getBraggingRights(), true);
        }
        if (eF.contains(6)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 6, haVar.getCircledByCount());
        }
        if (eF.contains(7)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 7, (Parcelable) haVar.fb(), i, true);
        }
        if (eF.contains(8)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 8, haVar.getCurrentLocation(), true);
        }
        if (eF.contains(9)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 9, haVar.getDisplayName(), true);
        }
        if (eF.contains(12)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 12, haVar.getGender());
        }
        if (eF.contains(14)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 14, haVar.getId(), true);
        }
        if (eF.contains(15)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 15, (Parcelable) haVar.fc(), i, true);
        }
        if (eF.contains(16)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 16, haVar.isPlusUser());
        }
        if (eF.contains(19)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 19, (Parcelable) haVar.fd(), i, true);
        }
        if (eF.contains(18)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 18, haVar.getLanguage(), true);
        }
        if (eF.contains(21)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 21, haVar.getObjectType());
        }
        if (eF.contains(20)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 20, haVar.getNickname(), true);
        }
        if (eF.contains(23)) {
            com.google.android.gms.common.internal.safeparcel.b.b(parcel, 23, haVar.ff(), true);
        }
        if (eF.contains(22)) {
            com.google.android.gms.common.internal.safeparcel.b.b(parcel, 22, haVar.fe(), true);
        }
        if (eF.contains(25)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 25, haVar.getRelationshipStatus());
        }
        if (eF.contains(24)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 24, haVar.getPlusOneCount());
        }
        if (eF.contains(27)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 27, haVar.getUrl(), true);
        }
        if (eF.contains(26)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 26, haVar.getTagline(), true);
        }
        if (eF.contains(29)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 29, haVar.isVerified());
        }
        if (eF.contains(28)) {
            com.google.android.gms.common.internal.safeparcel.b.b(parcel, 28, haVar.fg(), true);
        }
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aT, reason: merged with bridge method [inline-methods] */
    public ha[] newArray(int i) {
        return new ha[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: al, reason: merged with bridge method [inline-methods] */
    public ha createFromParcel(Parcel parcel) {
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        HashSet hashSet = new HashSet();
        int i = 0;
        String str = null;
        ha.a aVar = null;
        String str2 = null;
        String str3 = null;
        int i2 = 0;
        ha.b bVar = null;
        String str4 = null;
        String str5 = null;
        int i3 = 0;
        String str6 = null;
        ha.c cVar = null;
        boolean z = false;
        String str7 = null;
        ha.d dVar = null;
        String str8 = null;
        int i4 = 0;
        ArrayList arrayList = null;
        ArrayList arrayList2 = null;
        int i5 = 0;
        int i6 = 0;
        String str9 = null;
        String str10 = null;
        ArrayList arrayList3 = null;
        boolean z2 = false;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(1);
                    break;
                case 2:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(2);
                    break;
                case 3:
                    ha.a aVar2 = (ha.a) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, ha.a.CREATOR);
                    hashSet.add(3);
                    aVar = aVar2;
                    break;
                case 4:
                    str2 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(4);
                    break;
                case 5:
                    str3 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(5);
                    break;
                case 6:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(6);
                    break;
                case 7:
                    ha.b bVar2 = (ha.b) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, ha.b.CREATOR);
                    hashSet.add(7);
                    bVar = bVar2;
                    break;
                case 8:
                    str4 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(8);
                    break;
                case 9:
                    str5 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(9);
                    break;
                case 10:
                case 11:
                case 13:
                case 17:
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
                case 12:
                    i3 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(12);
                    break;
                case Status.INTERRUPTED /* 14 */:
                    str6 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(14);
                    break;
                case Status.TIMEOUT /* 15 */:
                    ha.c cVar2 = (ha.c) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, ha.c.CREATOR);
                    hashSet.add(15);
                    cVar = cVar2;
                    break;
                case 16:
                    z = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j);
                    hashSet.add(16);
                    break;
                case 18:
                    str7 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(18);
                    break;
                case 19:
                    ha.d dVar2 = (ha.d) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, ha.d.CREATOR);
                    hashSet.add(19);
                    dVar = dVar2;
                    break;
                case 20:
                    str8 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(20);
                    break;
                case 21:
                    i4 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(21);
                    break;
                case 22:
                    arrayList = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j, ha.f.CREATOR);
                    hashSet.add(22);
                    break;
                case 23:
                    arrayList2 = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j, ha.g.CREATOR);
                    hashSet.add(23);
                    break;
                case 24:
                    i5 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(24);
                    break;
                case 25:
                    i6 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(25);
                    break;
                case 26:
                    str9 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(26);
                    break;
                case 27:
                    str10 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(27);
                    break;
                case 28:
                    arrayList3 = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j, ha.h.CREATOR);
                    hashSet.add(28);
                    break;
                case 29:
                    z2 = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j);
                    hashSet.add(29);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new ha(hashSet, i, str, aVar, str2, str3, i2, bVar, str4, str5, i3, str6, cVar, z, str7, dVar, str8, i4, arrayList, arrayList2, i5, i6, str9, str10, arrayList3, z2);
    }
}
