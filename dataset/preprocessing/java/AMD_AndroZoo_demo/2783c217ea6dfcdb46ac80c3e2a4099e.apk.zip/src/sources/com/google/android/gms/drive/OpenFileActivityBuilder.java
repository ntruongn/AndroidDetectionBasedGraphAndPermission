package com.google.android.gms.drive;

import android.content.IntentSender;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.drive.internal.OpenFileIntentSenderRequest;
import com.google.android.gms.drive.internal.j;
import com.google.android.gms.internal.du;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class OpenFileActivityBuilder {
    public static final String EXTRA_RESPONSE_DRIVE_ID = "response_drive_id";
    private String oa;
    private DriveId ob;
    private String[] ol;

    public IntentSender build(GoogleApiClient apiClient) {
        du.c(this.ol, "setMimeType(String[]) must be called on this builder before calling build()");
        du.a(apiClient.isConnected(), "Client must be connected");
        try {
            return ((j) apiClient.a(Drive.jL)).cu().a(new OpenFileIntentSenderRequest(this.oa, this.ol, this.ob));
        } catch (RemoteException e) {
            throw new RuntimeException("Unable to connect Drive Play Service", e);
        }
    }

    public OpenFileActivityBuilder setActivityStartFolder(DriveId folder) {
        this.ob = (DriveId) du.f(folder);
        return this;
    }

    public OpenFileActivityBuilder setActivityTitle(String title) {
        this.oa = (String) du.f(title);
        return this;
    }

    public OpenFileActivityBuilder setMimeType(String[] mimeTypes) {
        du.b(mimeTypes != null && mimeTypes.length > 0, "mimeTypes may not be null and must contain at least one value");
        this.ol = mimeTypes;
        return this;
    }
}
