package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class el implements Parcelable.Creator<ek> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(ek ekVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, ekVar.getVersionCode());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, ekVar.ci(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, (Parcelable) ekVar.cj(), i, false);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: I, reason: merged with bridge method [inline-methods] */
    public ek[] newArray(int i) {
        return new ek[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: t, reason: merged with bridge method [inline-methods] */
    public ek createFromParcel(Parcel parcel) {
        eh ehVar = null;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        Parcel parcel2 = null;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 2:
                    parcel2 = com.google.android.gms.common.internal.safeparcel.a.z(parcel, j);
                    break;
                case 3:
                    ehVar = (eh) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, eh.CREATOR);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new ek(i, parcel2, ehVar);
    }
}
