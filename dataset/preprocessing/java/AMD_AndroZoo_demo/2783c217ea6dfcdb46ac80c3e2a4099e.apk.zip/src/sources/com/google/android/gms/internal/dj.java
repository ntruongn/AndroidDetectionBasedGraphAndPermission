package com.google.android.gms.internal;

import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class dj implements SafeParcelable {
    private static final Object mw = new Object();
    private static ClassLoader mx = null;
    private static Integer my = null;
    private boolean mz = false;

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean D(String str) {
        ClassLoader bx = bx();
        if (bx == null) {
            return true;
        }
        try {
            return a(bx.loadClass(str));
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean a(Class<?> cls) {
        try {
            return SafeParcelable.NULL.equals(cls.getField("NULL").get(null));
        } catch (IllegalAccessException e) {
            return false;
        } catch (NoSuchFieldException e2) {
            return false;
        }
    }

    protected static ClassLoader bx() {
        ClassLoader classLoader;
        synchronized (mw) {
            classLoader = mx;
        }
        return classLoader;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static Integer by() {
        Integer num;
        synchronized (mw) {
            num = my;
        }
        return num;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean bz() {
        return this.mz;
    }
}
