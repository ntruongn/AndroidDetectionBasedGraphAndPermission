package com.google.android.gms.drive.internal;

import com.google.ads.AdSize;
import com.google.android.gms.internal.hq;
import com.google.android.gms.internal.hr;
import com.google.android.gms.internal.hs;
import com.google.android.gms.internal.ht;
import com.google.android.gms.internal.hv;
import java.io.IOException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class q extends ht {
    public static final q[] oG = new q[0];
    public int versionCode = 1;
    public String oH = "";
    public long oI = -1;
    public long oJ = -1;
    private int oK = -1;

    public static q e(byte[] bArr) throws hs {
        return (q) ht.a(new q(), bArr);
    }

    @Override // com.google.android.gms.internal.ht
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public q b(hq hqVar) throws IOException {
        while (true) {
            int fz = hqVar.fz();
            switch (fz) {
                case 0:
                    break;
                case 8:
                    this.versionCode = hqVar.fB();
                    break;
                case 18:
                    this.oH = hqVar.readString();
                    break;
                case 24:
                    this.oI = hqVar.fC();
                    break;
                case AdSize.LANDSCAPE_AD_HEIGHT /* 32 */:
                    this.oJ = hqVar.fC();
                    break;
                default:
                    if (!hv.a(hqVar, fz)) {
                        break;
                    } else {
                        break;
                    }
            }
        }
        return this;
    }

    @Override // com.google.android.gms.internal.ht
    public void a(hr hrVar) throws IOException {
        hrVar.d(1, this.versionCode);
        hrVar.b(2, this.oH);
        hrVar.c(3, this.oI);
        hrVar.c(4, this.oJ);
    }

    @Override // com.google.android.gms.internal.ht
    public int cw() {
        int e = 0 + hr.e(1, this.versionCode) + hr.d(2, this.oH) + hr.d(3, this.oI) + hr.d(4, this.oJ);
        this.oK = e;
        return e;
    }
}
