package com.google.android.gms.common.data;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class d<T> extends DataBuffer<T> {
    private boolean lw;
    private ArrayList<Integer> lx;

    /* JADX INFO: Access modifiers changed from: protected */
    public d(DataHolder dataHolder) {
        super(dataHolder);
        this.lw = false;
    }

    private void bl() {
        synchronized (this) {
            if (!this.lw) {
                int count = this.lb.getCount();
                this.lx = new ArrayList<>();
                if (count > 0) {
                    this.lx.add(0);
                    String primaryDataMarkerColumn = getPrimaryDataMarkerColumn();
                    String string = this.lb.getString(primaryDataMarkerColumn, 0, this.lb.t(0));
                    int i = 1;
                    while (i < count) {
                        String string2 = this.lb.getString(primaryDataMarkerColumn, i, this.lb.t(i));
                        if (string2.equals(string)) {
                            string2 = string;
                        } else {
                            this.lx.add(Integer.valueOf(i));
                        }
                        i++;
                        string = string2;
                    }
                }
                this.lw = true;
            }
        }
    }

    private int v(int i) {
        if (i < 0 || i == this.lx.size()) {
            return 0;
        }
        return i == this.lx.size() + (-1) ? this.lb.getCount() - this.lx.get(i).intValue() : this.lx.get(i + 1).intValue() - this.lx.get(i).intValue();
    }

    protected abstract T a(int i, int i2);

    @Override // com.google.android.gms.common.data.DataBuffer
    public final T get(int position) {
        bl();
        return a(u(position), v(position));
    }

    @Override // com.google.android.gms.common.data.DataBuffer
    public int getCount() {
        bl();
        return this.lx.size();
    }

    protected abstract String getPrimaryDataMarkerColumn();

    int u(int i) {
        if (i < 0 || i >= this.lx.size()) {
            throw new IllegalArgumentException("Position " + i + " is out of bounds for this buffer");
        }
        return this.lx.get(i).intValue();
    }
}
