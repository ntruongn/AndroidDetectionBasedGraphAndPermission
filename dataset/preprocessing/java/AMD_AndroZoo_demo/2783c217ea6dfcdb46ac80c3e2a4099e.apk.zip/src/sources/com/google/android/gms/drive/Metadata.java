package com.google.android.gms.drive;

import com.google.android.gms.common.data.Freezable;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.et;
import com.google.android.gms.internal.eu;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class Metadata implements Freezable<Metadata> {
    protected abstract <T> T a(MetadataField<T> metadataField);

    public Date getCreatedDate() {
        return (Date) a(eu.oZ);
    }

    public DriveId getDriveId() {
        return (DriveId) a(et.oU);
    }

    public String getMimeType() {
        return (String) a(et.MIME_TYPE);
    }

    public Date getModifiedByMeDate() {
        return (Date) a(eu.oY);
    }

    public Date getModifiedDate() {
        return (Date) a(eu.oX);
    }

    public Date getSharedWithMeDate() {
        return (Date) a(eu.pa);
    }

    public String getTitle() {
        return (String) a(et.TITLE);
    }

    public boolean isEditable() {
        Boolean bool = (Boolean) a(et.oV);
        if (bool == null) {
            return false;
        }
        return bool.booleanValue();
    }

    public boolean isFolder() {
        return DriveFolder.MIME_TYPE.equals(getMimeType());
    }

    public boolean isStarred() {
        Boolean bool = (Boolean) a(et.STARRED);
        if (bool == null) {
            return false;
        }
        return bool.booleanValue();
    }

    public boolean isTrashed() {
        Boolean bool = (Boolean) a(et.TRASHED);
        if (bool == null) {
            return false;
        }
        return bool.booleanValue();
    }
}
