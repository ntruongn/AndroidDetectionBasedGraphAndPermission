package com.google.ads.mediation.jsadapter;

import android.text.TextUtils;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.internal.cs;
import java.net.URI;
import java.net.URISyntaxException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class BannerWebViewClient extends WebViewClient {
    private final String A;
    private boolean B = false;
    private final JavascriptAdapter r;

    public BannerWebViewClient(JavascriptAdapter adapter, String passbackUrl) {
        this.A = c(passbackUrl);
        this.r = adapter;
    }

    private boolean b(String str) {
        boolean z = false;
        String c = c(str);
        if (!TextUtils.isEmpty(c)) {
            try {
                URI uri = new URI(c);
                if ("passback".equals(uri.getScheme())) {
                    cs.r("Passback received");
                    this.r.sendAdNotReceivedUpdate();
                    z = true;
                } else if (!TextUtils.isEmpty(this.A)) {
                    URI uri2 = new URI(this.A);
                    String host = uri2.getHost();
                    String host2 = uri.getHost();
                    String path = uri2.getPath();
                    String path2 = uri.getPath();
                    if (equals(host, host2) && equals(path, path2)) {
                        cs.r("Passback received");
                        this.r.sendAdNotReceivedUpdate();
                        z = true;
                    }
                }
            } catch (URISyntaxException e) {
                cs.s(e.getMessage());
            }
        }
        return z;
    }

    private String c(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        try {
            return str.endsWith("/") ? str.substring(0, str.length() - 1) : str;
        } catch (IndexOutOfBoundsException e) {
            cs.s(e.getMessage());
            return str;
        }
    }

    private static boolean equals(Object obj1, Object obj2) {
        return obj1 == obj2 || (obj1 != null && obj1.equals(obj2));
    }

    @Override // android.webkit.WebViewClient
    public void onLoadResource(WebView view, String url) {
        cs.u("onLoadResource: " + url);
        if (b(url)) {
            return;
        }
        super.onLoadResource(view, url);
    }

    @Override // android.webkit.WebViewClient
    public void onPageFinished(WebView view, String url) {
        cs.u("onPageFinished: " + url);
        super.onPageFinished(view, url);
        if (this.B) {
            return;
        }
        this.r.startCheckingForAd();
        this.B = true;
    }

    @Override // android.webkit.WebViewClient
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        cs.u("shouldOverrideUrlLoading: " + url);
        if (!b(url)) {
            return false;
        }
        cs.r("shouldOverrideUrlLoading: received passback url");
        return true;
    }
}
