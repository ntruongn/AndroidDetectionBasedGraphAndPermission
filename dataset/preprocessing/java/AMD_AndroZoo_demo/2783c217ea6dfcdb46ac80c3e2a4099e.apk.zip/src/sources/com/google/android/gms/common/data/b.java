package com.google.android.gms.common.data;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.du;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class b {
    protected final DataHolder lb;
    protected final int ld;
    private final int le;

    public b(DataHolder dataHolder, int i) {
        this.lb = (DataHolder) du.f(dataHolder);
        du.n(i >= 0 && i < dataHolder.getCount());
        this.ld = i;
        this.le = dataHolder.t(this.ld);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean A(String str) {
        return this.lb.hasNull(str, this.ld, this.le);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a(String str, CharArrayBuffer charArrayBuffer) {
        this.lb.copyToBuffer(str, this.ld, this.le, charArrayBuffer);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return ds.equal(Integer.valueOf(bVar.ld), Integer.valueOf(this.ld)) && ds.equal(Integer.valueOf(bVar.le), Integer.valueOf(this.le)) && bVar.lb == this.lb;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean getBoolean(String column) {
        return this.lb.getBoolean(column, this.ld, this.le);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public byte[] getByteArray(String column) {
        return this.lb.getByteArray(column, this.ld, this.le);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int getInteger(String column) {
        return this.lb.getInteger(column, this.ld, this.le);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public long getLong(String column) {
        return this.lb.getLong(column, this.ld, this.le);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String getString(String column) {
        return this.lb.getString(column, this.ld, this.le);
    }

    public int hashCode() {
        return ds.hashCode(Integer.valueOf(this.ld), Integer.valueOf(this.le), this.lb);
    }

    public boolean isDataValid() {
        return !this.lb.isClosed();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public Uri z(String str) {
        return this.lb.parseUri(str, this.ld, this.le);
    }
}
