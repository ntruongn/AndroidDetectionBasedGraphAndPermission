package com.google.android.gms.drive;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class MetadataBuffer extends DataBuffer<Metadata> {
    private static final String[] oh;
    private final String oi;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class a extends Metadata {
        private final DataHolder lb;
        private final int le;
        private final int oj;

        public a(DataHolder dataHolder, int i) {
            this.lb = dataHolder;
            this.oj = i;
            this.le = dataHolder.t(i);
        }

        @Override // com.google.android.gms.drive.Metadata
        protected <T> T a(MetadataField<T> metadataField) {
            return metadataField.c(this.lb, this.oj, this.le);
        }

        @Override // com.google.android.gms.common.data.Freezable
        /* renamed from: cr, reason: merged with bridge method [inline-methods] */
        public Metadata freeze() {
            MetadataBundle cE = MetadataBundle.cE();
            Iterator<MetadataField<?>> it = com.google.android.gms.drive.metadata.internal.c.cD().iterator();
            while (it.hasNext()) {
                it.next().a(this.lb, cE, this.oj, this.le);
            }
            return new b(cE);
        }

        @Override // com.google.android.gms.common.data.Freezable
        public boolean isDataValid() {
            return !this.lb.isClosed();
        }
    }

    static {
        ArrayList arrayList = new ArrayList();
        Iterator<MetadataField<?>> it = com.google.android.gms.drive.metadata.internal.c.cD().iterator();
        while (it.hasNext()) {
            arrayList.addAll(it.next().cC());
        }
        oh = (String[]) arrayList.toArray(new String[0]);
    }

    public MetadataBuffer(DataHolder dataHolder, String nextPageToken) {
        super(dataHolder);
        this.oi = nextPageToken;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.google.android.gms.common.data.DataBuffer
    public Metadata get(int row) {
        return new a(this.lb, row);
    }

    public String getNextPageToken() {
        return this.oi;
    }
}
