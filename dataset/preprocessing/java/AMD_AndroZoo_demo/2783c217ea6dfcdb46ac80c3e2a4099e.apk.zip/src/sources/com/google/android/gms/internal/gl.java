package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.gm;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class gl extends gm.a {
    @Override // com.google.android.gms.internal.gm
    public void a(int i, Bundle bundle, Bundle bundle2) throws RemoteException {
    }

    @Override // com.google.android.gms.internal.gm
    public void a(int i, Bundle bundle, ParcelFileDescriptor parcelFileDescriptor) throws RemoteException {
    }

    @Override // com.google.android.gms.internal.gm
    public final void a(int i, Bundle bundle, ek ekVar) {
    }

    @Override // com.google.android.gms.internal.gm
    public void a(int i, ha haVar) {
    }

    @Override // com.google.android.gms.internal.gm
    public void a(DataHolder dataHolder, String str) {
    }

    @Override // com.google.android.gms.internal.gm
    public void a(DataHolder dataHolder, String str, String str2) {
    }

    @Override // com.google.android.gms.internal.gm
    public void ah(String str) throws RemoteException {
    }

    @Override // com.google.android.gms.internal.gm
    public void ai(String str) {
    }

    @Override // com.google.android.gms.internal.gm
    public void b(int i, Bundle bundle) {
    }
}
