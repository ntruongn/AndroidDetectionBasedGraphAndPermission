package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class Contents implements SafeParcelable {
    public static final Parcelable.Creator<Contents> CREATOR = new a();
    final int kZ;
    final ParcelFileDescriptor lJ;
    final int nT;
    final int nU;
    final DriveId nV;
    private boolean mClosed = false;
    private boolean nW = false;
    private boolean nX = false;

    /* JADX INFO: Access modifiers changed from: package-private */
    public Contents(int versionCode, ParcelFileDescriptor parcelFileDescriptor, int requestId, int mode, DriveId driveId) {
        this.kZ = versionCode;
        this.lJ = parcelFileDescriptor;
        this.nT = requestId;
        this.nU = mode;
        this.nV = driveId;
    }

    public void close() {
        this.mClosed = true;
    }

    public int cq() {
        return this.nT;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public DriveId getDriveId() {
        return this.nV;
    }

    public InputStream getInputStream() {
        if (this.mClosed) {
            throw new IllegalStateException("Contents have been closed, cannot access the input stream.");
        }
        if (this.nU != 268435456) {
            throw new IllegalStateException("getInputStream() can only be used with contents opened with MODE_READ_ONLY.");
        }
        if (this.nW) {
            throw new IllegalStateException("getInputStream() can only be called once per Contents instance.");
        }
        this.nW = true;
        return new FileInputStream(this.lJ.getFileDescriptor());
    }

    public int getMode() {
        return this.nU;
    }

    public OutputStream getOutputStream() {
        if (this.mClosed) {
            throw new IllegalStateException("Contents have been closed, cannot access the output stream.");
        }
        if (this.nU != 536870912) {
            throw new IllegalStateException("getOutputStream() can only be used with contents opened with MODE_WRITE_ONLY.");
        }
        if (this.nX) {
            throw new IllegalStateException("getOutputStream() can only be called once per Contents instance.");
        }
        this.nX = true;
        return new FileOutputStream(this.lJ.getFileDescriptor());
    }

    public ParcelFileDescriptor getParcelFileDescriptor() {
        if (this.mClosed) {
            throw new IllegalStateException("Contents have been closed, cannot access the output stream.");
        }
        return this.lJ;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        a.a(this, dest, flags);
    }
}
