package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class c implements Parcelable.Creator<DriveId> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(DriveId driveId, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, driveId.kZ);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, driveId.od, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, driveId.oe);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 4, driveId.of);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: M, reason: merged with bridge method [inline-methods] */
    public DriveId[] newArray(int i) {
        return new DriveId[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: v, reason: merged with bridge method [inline-methods] */
    public DriveId createFromParcel(Parcel parcel) {
        long j = 0;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        String str = null;
        long j2 = 0;
        while (parcel.dataPosition() < k) {
            int j3 = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j3)) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j3);
                    break;
                case 2:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j3);
                    break;
                case 3:
                    j2 = com.google.android.gms.common.internal.safeparcel.a.h(parcel, j3);
                    break;
                case 4:
                    j = com.google.android.gms.common.internal.safeparcel.a.h(parcel, j3);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j3);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new DriveId(i, str, j2, j);
    }
}
