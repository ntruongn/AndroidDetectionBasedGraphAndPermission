package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.ads.AdSize;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ee;
import com.google.android.gms.plus.PlusShare;
import com.google.android.gms.plus.model.moments.ItemScope;
import com.huprya.wqkqze112375.AdView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class gv extends ee implements SafeParcelable, ItemScope {
    public static final gw CREATOR = new gw();
    private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
    private String AA;
    private String AB;
    private String AC;
    private gv AD;
    private String AE;
    private String AF;
    private String AG;
    private gv AH;
    private String AI;
    private String AJ;
    private String AK;
    private String AL;
    private gv Aa;
    private List<gv> Ab;
    private String Ac;
    private String Ad;
    private gv Ae;
    private String Af;
    private String Ag;
    private String Ah;
    private List<gv> Ai;
    private String Aj;
    private String Ak;
    private String Al;
    private String Am;
    private String An;
    private String Ao;
    private String Ap;
    private String Aq;
    private gv Ar;
    private String As;
    private String At;
    private String Au;
    private gv Av;
    private gv Aw;
    private gv Ax;
    private List<gv> Ay;
    private String Az;
    private String iD;
    private final int kZ;
    private String mName;
    private String pZ;
    private double tC;
    private double tD;
    private String wF;
    private String wJ;
    private final Set<Integer> zQ;
    private gv zR;
    private List<String> zS;
    private gv zT;
    private String zU;
    private String zV;
    private String zW;
    private List<gv> zX;
    private int zY;
    private List<gv> zZ;

    static {
        zP.put("about", ee.a.a("about", 2, gv.class));
        zP.put("additionalName", ee.a.g("additionalName", 3));
        zP.put("address", ee.a.a("address", 4, gv.class));
        zP.put("addressCountry", ee.a.f("addressCountry", 5));
        zP.put("addressLocality", ee.a.f("addressLocality", 6));
        zP.put("addressRegion", ee.a.f("addressRegion", 7));
        zP.put("associated_media", ee.a.b("associated_media", 8, gv.class));
        zP.put("attendeeCount", ee.a.c("attendeeCount", 9));
        zP.put("attendees", ee.a.b("attendees", 10, gv.class));
        zP.put("audio", ee.a.a("audio", 11, gv.class));
        zP.put("author", ee.a.b("author", 12, gv.class));
        zP.put("bestRating", ee.a.f("bestRating", 13));
        zP.put("birthDate", ee.a.f("birthDate", 14));
        zP.put("byArtist", ee.a.a("byArtist", 15, gv.class));
        zP.put("caption", ee.a.f("caption", 16));
        zP.put("contentSize", ee.a.f("contentSize", 17));
        zP.put("contentUrl", ee.a.f("contentUrl", 18));
        zP.put("contributor", ee.a.b("contributor", 19, gv.class));
        zP.put("dateCreated", ee.a.f("dateCreated", 20));
        zP.put("dateModified", ee.a.f("dateModified", 21));
        zP.put("datePublished", ee.a.f("datePublished", 22));
        zP.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, ee.a.f(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, 23));
        zP.put("duration", ee.a.f("duration", 24));
        zP.put("embedUrl", ee.a.f("embedUrl", 25));
        zP.put("endDate", ee.a.f("endDate", 26));
        zP.put("familyName", ee.a.f("familyName", 27));
        zP.put("gender", ee.a.f("gender", 28));
        zP.put("geo", ee.a.a("geo", 29, gv.class));
        zP.put("givenName", ee.a.f("givenName", 30));
        zP.put("height", ee.a.f("height", 31));
        zP.put(com.huprya.wqkqze112375.j.ID, ee.a.f(com.huprya.wqkqze112375.j.ID, 32));
        zP.put(AdView.BANNER_TYPE_IMAGE, ee.a.f(AdView.BANNER_TYPE_IMAGE, 33));
        zP.put("inAlbum", ee.a.a("inAlbum", 34, gv.class));
        zP.put(com.huprya.wqkqze112375.g.LATITUDE, ee.a.d(com.huprya.wqkqze112375.g.LATITUDE, 36));
        zP.put("location", ee.a.a("location", 37, gv.class));
        zP.put(com.huprya.wqkqze112375.g.LONGITUDE, ee.a.d(com.huprya.wqkqze112375.g.LONGITUDE, 38));
        zP.put("name", ee.a.f("name", 39));
        zP.put("partOfTVSeries", ee.a.a("partOfTVSeries", 40, gv.class));
        zP.put("performers", ee.a.b("performers", 41, gv.class));
        zP.put("playerType", ee.a.f("playerType", 42));
        zP.put("postOfficeBoxNumber", ee.a.f("postOfficeBoxNumber", 43));
        zP.put("postalCode", ee.a.f("postalCode", 44));
        zP.put("ratingValue", ee.a.f("ratingValue", 45));
        zP.put("reviewRating", ee.a.a("reviewRating", 46, gv.class));
        zP.put("startDate", ee.a.f("startDate", 47));
        zP.put("streetAddress", ee.a.f("streetAddress", 48));
        zP.put("text", ee.a.f("text", 49));
        zP.put("thumbnail", ee.a.a("thumbnail", 50, gv.class));
        zP.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_THUMBNAIL_URL, ee.a.f(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_THUMBNAIL_URL, 51));
        zP.put("tickerSymbol", ee.a.f("tickerSymbol", 52));
        zP.put("type", ee.a.f("type", 53));
        zP.put(PlusShare.KEY_CALL_TO_ACTION_URL, ee.a.f(PlusShare.KEY_CALL_TO_ACTION_URL, 54));
        zP.put("width", ee.a.f("width", 55));
        zP.put("worstRating", ee.a.f("worstRating", 56));
    }

    public gv() {
        this.kZ = 1;
        this.zQ = new HashSet();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv(Set<Integer> set, int i, gv gvVar, List<String> list, gv gvVar2, String str, String str2, String str3, List<gv> list2, int i2, List<gv> list3, gv gvVar3, List<gv> list4, String str4, String str5, gv gvVar4, String str6, String str7, String str8, List<gv> list5, String str9, String str10, String str11, String str12, String str13, String str14, String str15, String str16, String str17, gv gvVar5, String str18, String str19, String str20, String str21, gv gvVar6, double d, gv gvVar7, double d2, String str22, gv gvVar8, List<gv> list6, String str23, String str24, String str25, String str26, gv gvVar9, String str27, String str28, String str29, gv gvVar10, String str30, String str31, String str32, String str33, String str34, String str35) {
        this.zQ = set;
        this.kZ = i;
        this.zR = gvVar;
        this.zS = list;
        this.zT = gvVar2;
        this.zU = str;
        this.zV = str2;
        this.zW = str3;
        this.zX = list2;
        this.zY = i2;
        this.zZ = list3;
        this.Aa = gvVar3;
        this.Ab = list4;
        this.Ac = str4;
        this.Ad = str5;
        this.Ae = gvVar4;
        this.Af = str6;
        this.Ag = str7;
        this.Ah = str8;
        this.Ai = list5;
        this.Aj = str9;
        this.Ak = str10;
        this.Al = str11;
        this.pZ = str12;
        this.Am = str13;
        this.An = str14;
        this.Ao = str15;
        this.Ap = str16;
        this.Aq = str17;
        this.Ar = gvVar5;
        this.As = str18;
        this.At = str19;
        this.wJ = str20;
        this.Au = str21;
        this.Av = gvVar6;
        this.tC = d;
        this.Aw = gvVar7;
        this.tD = d2;
        this.mName = str22;
        this.Ax = gvVar8;
        this.Ay = list6;
        this.Az = str23;
        this.AA = str24;
        this.AB = str25;
        this.AC = str26;
        this.AD = gvVar9;
        this.AE = str27;
        this.AF = str28;
        this.AG = str29;
        this.AH = gvVar10;
        this.AI = str30;
        this.AJ = str31;
        this.wF = str32;
        this.iD = str33;
        this.AK = str34;
        this.AL = str35;
    }

    public gv(Set<Integer> set, gv gvVar, List<String> list, gv gvVar2, String str, String str2, String str3, List<gv> list2, int i, List<gv> list3, gv gvVar3, List<gv> list4, String str4, String str5, gv gvVar4, String str6, String str7, String str8, List<gv> list5, String str9, String str10, String str11, String str12, String str13, String str14, String str15, String str16, String str17, gv gvVar5, String str18, String str19, String str20, String str21, gv gvVar6, double d, gv gvVar7, double d2, String str22, gv gvVar8, List<gv> list6, String str23, String str24, String str25, String str26, gv gvVar9, String str27, String str28, String str29, gv gvVar10, String str30, String str31, String str32, String str33, String str34, String str35) {
        this.zQ = set;
        this.kZ = 1;
        this.zR = gvVar;
        this.zS = list;
        this.zT = gvVar2;
        this.zU = str;
        this.zV = str2;
        this.zW = str3;
        this.zX = list2;
        this.zY = i;
        this.zZ = list3;
        this.Aa = gvVar3;
        this.Ab = list4;
        this.Ac = str4;
        this.Ad = str5;
        this.Ae = gvVar4;
        this.Af = str6;
        this.Ag = str7;
        this.Ah = str8;
        this.Ai = list5;
        this.Aj = str9;
        this.Ak = str10;
        this.Al = str11;
        this.pZ = str12;
        this.Am = str13;
        this.An = str14;
        this.Ao = str15;
        this.Ap = str16;
        this.Aq = str17;
        this.Ar = gvVar5;
        this.As = str18;
        this.At = str19;
        this.wJ = str20;
        this.Au = str21;
        this.Av = gvVar6;
        this.tC = d;
        this.Aw = gvVar7;
        this.tD = d2;
        this.mName = str22;
        this.Ax = gvVar8;
        this.Ay = list6;
        this.Az = str23;
        this.AA = str24;
        this.AB = str25;
        this.AC = str26;
        this.AD = gvVar9;
        this.AE = str27;
        this.AF = str28;
        this.AG = str29;
        this.AH = gvVar10;
        this.AI = str30;
        this.AJ = str31;
        this.wF = str32;
        this.iD = str33;
        this.AK = str34;
        this.AL = str35;
    }

    @Override // com.google.android.gms.internal.ee
    protected Object J(String str) {
        return null;
    }

    @Override // com.google.android.gms.internal.ee
    protected boolean K(String str) {
        return false;
    }

    @Override // com.google.android.gms.internal.ee
    protected boolean a(ee.a aVar) {
        return this.zQ.contains(Integer.valueOf(aVar.bX()));
    }

    @Override // com.google.android.gms.internal.ee
    protected Object b(ee.a aVar) {
        switch (aVar.bX()) {
            case 2:
                return this.zR;
            case 3:
                return this.zS;
            case 4:
                return this.zT;
            case 5:
                return this.zU;
            case 6:
                return this.zV;
            case 7:
                return this.zW;
            case 8:
                return this.zX;
            case 9:
                return Integer.valueOf(this.zY);
            case 10:
                return this.zZ;
            case 11:
                return this.Aa;
            case 12:
                return this.Ab;
            case 13:
                return this.Ac;
            case Status.INTERRUPTED /* 14 */:
                return this.Ad;
            case Status.TIMEOUT /* 15 */:
                return this.Ae;
            case 16:
                return this.Af;
            case 17:
                return this.Ag;
            case 18:
                return this.Ah;
            case 19:
                return this.Ai;
            case 20:
                return this.Aj;
            case 21:
                return this.Ak;
            case 22:
                return this.Al;
            case 23:
                return this.pZ;
            case 24:
                return this.Am;
            case 25:
                return this.An;
            case 26:
                return this.Ao;
            case 27:
                return this.Ap;
            case 28:
                return this.Aq;
            case 29:
                return this.Ar;
            case 30:
                return this.As;
            case 31:
                return this.At;
            case AdSize.LANDSCAPE_AD_HEIGHT /* 32 */:
                return this.wJ;
            case 33:
                return this.Au;
            case 34:
                return this.Av;
            case 35:
            default:
                throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            case 36:
                return Double.valueOf(this.tC);
            case 37:
                return this.Aw;
            case 38:
                return Double.valueOf(this.tD);
            case 39:
                return this.mName;
            case 40:
                return this.Ax;
            case 41:
                return this.Ay;
            case 42:
                return this.Az;
            case 43:
                return this.AA;
            case 44:
                return this.AB;
            case 45:
                return this.AC;
            case 46:
                return this.AD;
            case 47:
                return this.AE;
            case 48:
                return this.AF;
            case 49:
                return this.AG;
            case AdSize.PORTRAIT_AD_HEIGHT /* 50 */:
                return this.AH;
            case 51:
                return this.AI;
            case 52:
                return this.AJ;
            case 53:
                return this.wF;
            case 54:
                return this.iD;
            case 55:
                return this.AK;
            case 56:
                return this.AL;
        }
    }

    @Override // com.google.android.gms.internal.ee
    public HashMap<String, ee.a<?, ?>> bQ() {
        return zP;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        gw gwVar = CREATOR;
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Set<Integer> eF() {
        return this.zQ;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eG() {
        return this.zR;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eH() {
        return this.zT;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<gv> eI() {
        return this.zX;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<gv> eJ() {
        return this.zZ;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eK() {
        return this.Aa;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<gv> eL() {
        return this.Ab;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eM() {
        return this.Ae;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<gv> eN() {
        return this.Ai;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eO() {
        return this.Ar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eP() {
        return this.Av;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eQ() {
        return this.Aw;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eR() {
        return this.Ax;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<gv> eS() {
        return this.Ay;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eT() {
        return this.AD;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gv eU() {
        return this.AH;
    }

    @Override // com.google.android.gms.common.data.Freezable
    /* renamed from: eV, reason: merged with bridge method [inline-methods] */
    public gv freeze() {
        return this;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof gv)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        gv gvVar = (gv) obj;
        for (ee.a<?, ?> aVar : zP.values()) {
            if (a(aVar)) {
                if (gvVar.a(aVar) && b(aVar).equals(gvVar.b(aVar))) {
                }
                return false;
            }
            if (gvVar.a(aVar)) {
                return false;
            }
        }
        return true;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getAbout() {
        return this.zR;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public List<String> getAdditionalName() {
        return this.zS;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getAddress() {
        return this.zT;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getAddressCountry() {
        return this.zU;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getAddressLocality() {
        return this.zV;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getAddressRegion() {
        return this.zW;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public List<ItemScope> getAssociated_media() {
        return (ArrayList) this.zX;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public int getAttendeeCount() {
        return this.zY;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public List<ItemScope> getAttendees() {
        return (ArrayList) this.zZ;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getAudio() {
        return this.Aa;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public List<ItemScope> getAuthor() {
        return (ArrayList) this.Ab;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getBestRating() {
        return this.Ac;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getBirthDate() {
        return this.Ad;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getByArtist() {
        return this.Ae;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getCaption() {
        return this.Af;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getContentSize() {
        return this.Ag;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getContentUrl() {
        return this.Ah;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public List<ItemScope> getContributor() {
        return (ArrayList) this.Ai;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getDateCreated() {
        return this.Aj;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getDateModified() {
        return this.Ak;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getDatePublished() {
        return this.Al;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getDescription() {
        return this.pZ;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getDuration() {
        return this.Am;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getEmbedUrl() {
        return this.An;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getEndDate() {
        return this.Ao;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getFamilyName() {
        return this.Ap;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getGender() {
        return this.Aq;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getGeo() {
        return this.Ar;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getGivenName() {
        return this.As;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getHeight() {
        return this.At;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getId() {
        return this.wJ;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getImage() {
        return this.Au;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getInAlbum() {
        return this.Av;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public double getLatitude() {
        return this.tC;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getLocation() {
        return this.Aw;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public double getLongitude() {
        return this.tD;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getName() {
        return this.mName;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getPartOfTVSeries() {
        return this.Ax;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public List<ItemScope> getPerformers() {
        return (ArrayList) this.Ay;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getPlayerType() {
        return this.Az;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getPostOfficeBoxNumber() {
        return this.AA;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getPostalCode() {
        return this.AB;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getRatingValue() {
        return this.AC;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getReviewRating() {
        return this.AD;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getStartDate() {
        return this.AE;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getStreetAddress() {
        return this.AF;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getText() {
        return this.AG;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public ItemScope getThumbnail() {
        return this.AH;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getThumbnailUrl() {
        return this.AI;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getTickerSymbol() {
        return this.AJ;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getType() {
        return this.wF;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getUrl() {
        return this.iD;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.kZ;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getWidth() {
        return this.AK;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public String getWorstRating() {
        return this.AL;
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAbout() {
        return this.zQ.contains(2);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAdditionalName() {
        return this.zQ.contains(3);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAddress() {
        return this.zQ.contains(4);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAddressCountry() {
        return this.zQ.contains(5);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAddressLocality() {
        return this.zQ.contains(6);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAddressRegion() {
        return this.zQ.contains(7);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAssociated_media() {
        return this.zQ.contains(8);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAttendeeCount() {
        return this.zQ.contains(9);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAttendees() {
        return this.zQ.contains(10);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAudio() {
        return this.zQ.contains(11);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasAuthor() {
        return this.zQ.contains(12);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasBestRating() {
        return this.zQ.contains(13);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasBirthDate() {
        return this.zQ.contains(14);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasByArtist() {
        return this.zQ.contains(15);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasCaption() {
        return this.zQ.contains(16);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasContentSize() {
        return this.zQ.contains(17);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasContentUrl() {
        return this.zQ.contains(18);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasContributor() {
        return this.zQ.contains(19);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasDateCreated() {
        return this.zQ.contains(20);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasDateModified() {
        return this.zQ.contains(21);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasDatePublished() {
        return this.zQ.contains(22);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasDescription() {
        return this.zQ.contains(23);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasDuration() {
        return this.zQ.contains(24);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasEmbedUrl() {
        return this.zQ.contains(25);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasEndDate() {
        return this.zQ.contains(26);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasFamilyName() {
        return this.zQ.contains(27);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasGender() {
        return this.zQ.contains(28);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasGeo() {
        return this.zQ.contains(29);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasGivenName() {
        return this.zQ.contains(30);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasHeight() {
        return this.zQ.contains(31);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasId() {
        return this.zQ.contains(32);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasImage() {
        return this.zQ.contains(33);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasInAlbum() {
        return this.zQ.contains(34);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasLatitude() {
        return this.zQ.contains(36);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasLocation() {
        return this.zQ.contains(37);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasLongitude() {
        return this.zQ.contains(38);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasName() {
        return this.zQ.contains(39);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasPartOfTVSeries() {
        return this.zQ.contains(40);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasPerformers() {
        return this.zQ.contains(41);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasPlayerType() {
        return this.zQ.contains(42);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasPostOfficeBoxNumber() {
        return this.zQ.contains(43);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasPostalCode() {
        return this.zQ.contains(44);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasRatingValue() {
        return this.zQ.contains(45);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasReviewRating() {
        return this.zQ.contains(46);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasStartDate() {
        return this.zQ.contains(47);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasStreetAddress() {
        return this.zQ.contains(48);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasText() {
        return this.zQ.contains(49);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasThumbnail() {
        return this.zQ.contains(50);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasThumbnailUrl() {
        return this.zQ.contains(51);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasTickerSymbol() {
        return this.zQ.contains(52);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasType() {
        return this.zQ.contains(53);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasUrl() {
        return this.zQ.contains(54);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasWidth() {
        return this.zQ.contains(55);
    }

    @Override // com.google.android.gms.plus.model.moments.ItemScope
    public boolean hasWorstRating() {
        return this.zQ.contains(56);
    }

    public int hashCode() {
        int i = 0;
        Iterator<ee.a<?, ?>> it = zP.values().iterator();
        while (true) {
            int i2 = i;
            if (!it.hasNext()) {
                return i2;
            }
            ee.a<?, ?> next = it.next();
            if (a(next)) {
                i = b(next).hashCode() + i2 + next.bX();
            } else {
                i = i2;
            }
        }
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        gw gwVar = CREATOR;
        gw.a(this, out, flags);
    }
}
