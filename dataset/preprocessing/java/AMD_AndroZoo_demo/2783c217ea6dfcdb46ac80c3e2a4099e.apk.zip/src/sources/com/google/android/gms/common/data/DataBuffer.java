package com.google.android.gms.common.data;

import android.os.Bundle;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class DataBuffer<T> implements Iterable<T> {
    protected final DataHolder lb;

    /* JADX INFO: Access modifiers changed from: protected */
    public DataBuffer(DataHolder dataHolder) {
        this.lb = dataHolder;
        if (this.lb != null) {
            this.lb.c(this);
        }
    }

    public void close() {
        if (this.lb != null) {
            this.lb.close();
        }
    }

    public int describeContents() {
        return 0;
    }

    public abstract T get(int i);

    public int getCount() {
        if (this.lb == null) {
            return 0;
        }
        return this.lb.getCount();
    }

    public Bundle getMetadata() {
        return this.lb.getMetadata();
    }

    public boolean isClosed() {
        if (this.lb == null) {
            return true;
        }
        return this.lb.isClosed();
    }

    @Override // java.lang.Iterable
    public Iterator<T> iterator() {
        return new a(this);
    }
}
