package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.mediation.MediationServerParameters;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.internal.bb;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ba extends bb.a {
    private Map<Class<? extends NetworkExtras>, NetworkExtras> ge;

    private <NETWORK_EXTRAS extends com.google.ads.mediation.NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> bc m(String str) throws RemoteException {
        try {
            MediationAdapter mediationAdapter = (MediationAdapter) Class.forName(str).newInstance();
            return new be(mediationAdapter, (com.google.ads.mediation.NetworkExtras) this.ge.get(mediationAdapter.getAdditionalParametersType()));
        } catch (Throwable th) {
            cs.v("Could not instantiate mediation adapter: " + str + ". " + th.getMessage());
            throw new RemoteException();
        }
    }

    public void c(Map<Class<? extends NetworkExtras>, NetworkExtras> map) {
        this.ge = map;
    }

    @Override // com.google.android.gms.internal.bb
    public bc l(String str) throws RemoteException {
        return m(str);
    }
}
