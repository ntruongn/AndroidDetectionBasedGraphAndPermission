package com.google.android.gms.appstate;

import android.content.Context;
import com.google.android.gms.appstate.b;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a;
import com.google.android.gms.internal.db;
import com.google.android.gms.internal.dg;
import com.google.android.gms.internal.du;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class AppStateClient implements GooglePlayServicesClient {
    public static final int STATUS_CLIENT_RECONNECT_REQUIRED = 2;
    public static final int STATUS_DEVELOPER_ERROR = 7;
    public static final int STATUS_INTERNAL_ERROR = 1;
    public static final int STATUS_NETWORK_ERROR_NO_DATA = 4;
    public static final int STATUS_NETWORK_ERROR_OPERATION_DEFERRED = 5;
    public static final int STATUS_NETWORK_ERROR_OPERATION_FAILED = 6;
    public static final int STATUS_NETWORK_ERROR_STALE_DATA = 3;
    public static final int STATUS_OK = 0;
    public static final int STATUS_STATE_KEY_LIMIT_EXCEEDED = 2003;
    public static final int STATUS_STATE_KEY_NOT_FOUND = 2002;
    public static final int STATUS_WRITE_OUT_OF_DATE_VERSION = 2000;
    public static final int STATUS_WRITE_SIZE_EXCEEDED = 2001;
    private final db ju;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class Builder {
        private static final String[] jz = {Scopes.APP_STATE};
        private GooglePlayServicesClient.ConnectionCallbacks jA;
        private GooglePlayServicesClient.OnConnectionFailedListener jB;
        private String[] jC = jz;
        private String jD = "<<default account>>";
        private Context mContext;

        public Builder(Context context, GooglePlayServicesClient.ConnectionCallbacks connectedListener, GooglePlayServicesClient.OnConnectionFailedListener connectionFailedListener) {
            this.mContext = context;
            this.jA = connectedListener;
            this.jB = connectionFailedListener;
        }

        public AppStateClient create() {
            return new AppStateClient(this.mContext, this.jA, this.jB, this.jD, this.jC);
        }

        public Builder setAccountName(String accountName) {
            this.jD = (String) du.f(accountName);
            return this;
        }

        public Builder setScopes(String... scopes) {
            this.jC = scopes;
            return this;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private static final class a implements a.c<b.e> {
        private final OnStateLoadedListener jE;

        a(OnStateLoadedListener onStateLoadedListener) {
            this.jE = onStateLoadedListener;
        }

        @Override // com.google.android.gms.common.api.a.c
        public void a(b.e eVar) {
            if (this.jE == null) {
                return;
            }
            if (eVar.getStatus().getStatusCode() == 2000) {
                b.a aP = eVar.aP();
                dg.d(aP);
                this.jE.onStateConflict(aP.aK(), aP.aL(), aP.getLocalData(), aP.aM());
            } else {
                b.d aO = eVar.aO();
                dg.d(aO);
                this.jE.onStateLoaded(aO.getStatus().getStatusCode(), aO.aK(), aO.getLocalData());
            }
        }
    }

    private AppStateClient(Context context, GooglePlayServicesClient.ConnectionCallbacks connectedListener, GooglePlayServicesClient.OnConnectionFailedListener connectionFailedListener, String accountName, String[] scopes) {
        this.ju = new db(context, connectedListener, connectionFailedListener, accountName, scopes);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void connect() {
        this.ju.connect();
    }

    public void deleteState(final OnStateDeletedListener listener, int stateKey) {
        this.ju.a(new a.c<b.InterfaceC0000b>() { // from class: com.google.android.gms.appstate.AppStateClient.1
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.InterfaceC0000b interfaceC0000b) {
                listener.onStateDeleted(interfaceC0000b.getStatus().getStatusCode(), interfaceC0000b.aK());
            }
        }, stateKey);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void disconnect() {
        this.ju.disconnect();
    }

    public int getMaxNumKeys() {
        return this.ju.getMaxNumKeys();
    }

    public int getMaxStateSize() {
        return this.ju.getMaxStateSize();
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnected() {
        return this.ju.isConnected();
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnecting() {
        return this.ju.isConnecting();
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks listener) {
        return this.ju.isConnectionCallbacksRegistered(listener);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        return this.ju.isConnectionFailedListenerRegistered(listener);
    }

    public void listStates(final OnStateListLoadedListener listener) {
        this.ju.a(new a.c<b.c>() { // from class: com.google.android.gms.appstate.AppStateClient.2
            @Override // com.google.android.gms.common.api.a.c
            public void a(b.c cVar) {
                listener.onStateListLoaded(cVar.getStatus().getStatusCode(), cVar.aN());
            }
        });
    }

    public void loadState(OnStateLoadedListener listener, int stateKey) {
        this.ju.b(new a(listener), stateKey);
    }

    public void reconnect() {
        this.ju.disconnect();
        this.ju.connect();
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        this.ju.registerConnectionCallbacks(listener);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        this.ju.registerConnectionFailedListener(listener);
    }

    public void resolveState(OnStateLoadedListener listener, int stateKey, String resolvedVersion, byte[] resolvedData) {
        this.ju.a(new a(listener), stateKey, resolvedVersion, resolvedData);
    }

    public void signOut() {
        this.ju.b(new a.c<Status>() { // from class: com.google.android.gms.appstate.AppStateClient.3
            @Override // com.google.android.gms.common.api.a.c
            public void a(Status status) {
            }
        });
    }

    public void signOut(final OnSignOutCompleteListener listener) {
        du.c(listener, "Must provide a valid listener");
        this.ju.b(new a.c<Status>() { // from class: com.google.android.gms.appstate.AppStateClient.4
            @Override // com.google.android.gms.common.api.a.c
            public void a(Status status) {
                listener.onSignOutComplete();
            }
        });
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        this.ju.unregisterConnectionCallbacks(listener);
    }

    @Override // com.google.android.gms.common.GooglePlayServicesClient
    public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        this.ju.unregisterConnectionFailedListener(listener);
    }

    public void updateState(int stateKey, byte[] data) {
        this.ju.a(new a(null), stateKey, data);
    }

    public void updateStateImmediate(OnStateLoadedListener listener, int stateKey, byte[] data) {
        du.c(listener, "Must provide a valid listener");
        this.ju.a(new a(listener), stateKey, data);
    }
}
