package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class gd implements SafeParcelable {
    public static final ge CREATOR = new ge();
    public final String name;
    public final int versionCode;
    public final String xa;
    public final String xb;
    public final String xc;
    public final List<String> xd;

    public gd(int i, String str, String str2, String str3, String str4, List<String> list) {
        this.versionCode = i;
        this.name = str;
        this.xa = str2;
        this.xb = str3;
        this.xc = str4;
        this.xd = list;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        ge geVar = CREATOR;
        return 0;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof gd)) {
            return false;
        }
        gd gdVar = (gd) object;
        return ds.equal(this.name, gdVar.name) && ds.equal(this.xa, gdVar.xa) && ds.equal(this.xb, gdVar.xb) && ds.equal(this.xc, gdVar.xc) && ds.equal(this.xd, gdVar.xd);
    }

    public int hashCode() {
        return ds.hashCode(this.name, this.xa, this.xb, this.xc);
    }

    public String toString() {
        return ds.e(this).a("name", this.name).a("address", this.xa).a("internationalPhoneNumber", this.xb).a("regularOpenHours", this.xc).a("attributions", this.xd).toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int flags) {
        ge geVar = CREATOR;
        ge.a(this, parcel, flags);
    }
}
