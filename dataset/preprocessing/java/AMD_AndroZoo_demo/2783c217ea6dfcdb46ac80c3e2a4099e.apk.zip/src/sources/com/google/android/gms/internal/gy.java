package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import java.util.HashSet;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class gy implements Parcelable.Creator<gx> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(gx gxVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        Set<Integer> eF = gxVar.eF();
        if (eF.contains(1)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, gxVar.getVersionCode());
        }
        if (eF.contains(2)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, gxVar.getId(), true);
        }
        if (eF.contains(4)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 4, (Parcelable) gxVar.eW(), i, true);
        }
        if (eF.contains(5)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, gxVar.getStartDate(), true);
        }
        if (eF.contains(6)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 6, (Parcelable) gxVar.eX(), i, true);
        }
        if (eF.contains(7)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 7, gxVar.getType(), true);
        }
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aS, reason: merged with bridge method [inline-methods] */
    public gx[] newArray(int i) {
        return new gx[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: ak, reason: merged with bridge method [inline-methods] */
    public gx createFromParcel(Parcel parcel) {
        String str = null;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        HashSet hashSet = new HashSet();
        int i = 0;
        gv gvVar = null;
        String str2 = null;
        gv gvVar2 = null;
        String str3 = null;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(1);
                    break;
                case 2:
                    str3 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(2);
                    break;
                case 3:
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
                case 4:
                    gv gvVar3 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(4);
                    gvVar2 = gvVar3;
                    break;
                case 5:
                    str2 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(5);
                    break;
                case 6:
                    gv gvVar4 = (gv) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, gv.CREATOR);
                    hashSet.add(6);
                    gvVar = gvVar4;
                    break;
                case 7:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(7);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new gx(hashSet, i, str3, gvVar2, str2, gvVar, str);
    }
}
