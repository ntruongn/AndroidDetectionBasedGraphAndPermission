package com.google.android.gms.internal;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class bz implements SafeParcelable {
    public static final ca CREATOR = new ca();
    public final String adUnitId;
    public final ApplicationInfo applicationInfo;
    public final ct ej;
    public final x em;
    public final Bundle ho;
    public final v hp;
    public final PackageInfo hq;
    public final String hr;
    public final String hs;
    public final String ht;
    public final int versionCode;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a {
        public final String adUnitId;
        public final ApplicationInfo applicationInfo;
        public final ct ej;
        public final x em;
        public final Bundle ho;
        public final v hp;
        public final PackageInfo hq;
        public final String hs;
        public final String ht;

        public a(Bundle bundle, v vVar, x xVar, String str, ApplicationInfo applicationInfo, PackageInfo packageInfo, String str2, String str3, ct ctVar) {
            this.ho = bundle;
            this.hp = vVar;
            this.em = xVar;
            this.adUnitId = str;
            this.applicationInfo = applicationInfo;
            this.hq = packageInfo;
            this.hs = str2;
            this.ht = str3;
            this.ej = ctVar;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public bz(int i, Bundle bundle, v vVar, x xVar, String str, ApplicationInfo applicationInfo, PackageInfo packageInfo, String str2, String str3, String str4, ct ctVar) {
        this.versionCode = i;
        this.ho = bundle;
        this.hp = vVar;
        this.em = xVar;
        this.adUnitId = str;
        this.applicationInfo = applicationInfo;
        this.hq = packageInfo;
        this.hr = str2;
        this.hs = str3;
        this.ht = str4;
        this.ej = ctVar;
    }

    public bz(Bundle bundle, v vVar, x xVar, String str, ApplicationInfo applicationInfo, PackageInfo packageInfo, String str2, String str3, String str4, ct ctVar) {
        this(1, bundle, vVar, xVar, str, applicationInfo, packageInfo, str2, str3, str4, ctVar);
    }

    public bz(a aVar, String str) {
        this(aVar.ho, aVar.hp, aVar.em, aVar.adUnitId, aVar.applicationInfo, aVar.hq, str, aVar.hs, aVar.ht, aVar.ej);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        ca.a(this, out, flags);
    }
}
