package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.internal.ha;
import java.util.HashSet;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class hf implements Parcelable.Creator<ha.b.C0041b> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(ha.b.C0041b c0041b, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        Set<Integer> eF = c0041b.eF();
        if (eF.contains(1)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, c0041b.getVersionCode());
        }
        if (eF.contains(2)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 2, c0041b.getHeight());
        }
        if (eF.contains(3)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, c0041b.getUrl(), true);
        }
        if (eF.contains(4)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 4, c0041b.getWidth());
        }
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aX, reason: merged with bridge method [inline-methods] */
    public ha.b.C0041b[] newArray(int i) {
        return new ha.b.C0041b[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: ap, reason: merged with bridge method [inline-methods] */
    public ha.b.C0041b createFromParcel(Parcel parcel) {
        int i = 0;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        HashSet hashSet = new HashSet();
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i3 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(1);
                    break;
                case 2:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(2);
                    break;
                case 3:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    hashSet.add(3);
                    break;
                case 4:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(4);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new ha.b.C0041b(hashSet, i3, i2, str, i);
    }
}
