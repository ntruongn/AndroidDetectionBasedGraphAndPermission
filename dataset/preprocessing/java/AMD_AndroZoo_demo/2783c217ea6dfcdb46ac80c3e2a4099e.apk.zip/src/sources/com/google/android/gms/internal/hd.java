package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.internal.ha;
import java.util.HashSet;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class hd implements Parcelable.Creator<ha.b> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(ha.b bVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        Set<Integer> eF = bVar.eF();
        if (eF.contains(1)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, bVar.getVersionCode());
        }
        if (eF.contains(2)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, (Parcelable) bVar.fj(), i, true);
        }
        if (eF.contains(3)) {
            com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, (Parcelable) bVar.fk(), i, true);
        }
        if (eF.contains(4)) {
            com.google.android.gms.common.internal.safeparcel.b.c(parcel, 4, bVar.getLayout());
        }
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aV, reason: merged with bridge method [inline-methods] */
    public ha.b[] newArray(int i) {
        return new ha.b[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: an, reason: merged with bridge method [inline-methods] */
    public ha.b createFromParcel(Parcel parcel) {
        ha.b.C0041b c0041b = null;
        int i = 0;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        HashSet hashSet = new HashSet();
        ha.b.a aVar = null;
        int i2 = 0;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(1);
                    break;
                case 2:
                    ha.b.a aVar2 = (ha.b.a) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, ha.b.a.CREATOR);
                    hashSet.add(2);
                    aVar = aVar2;
                    break;
                case 3:
                    ha.b.C0041b c0041b2 = (ha.b.C0041b) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, ha.b.C0041b.CREATOR);
                    hashSet.add(3);
                    c0041b = c0041b2;
                    break;
                case 4:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    hashSet.add(4);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new ha.b(hashSet, i2, aVar, c0041b, i);
    }
}
