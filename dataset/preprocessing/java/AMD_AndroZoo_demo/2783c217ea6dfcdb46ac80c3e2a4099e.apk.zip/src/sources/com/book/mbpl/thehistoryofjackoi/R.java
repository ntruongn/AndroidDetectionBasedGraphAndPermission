package com.book.mbpl.thehistoryofjackoi;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class R {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class attr {
        public static final int adSize = 0x7f010000;
        public static final int adSizes = 0x7f010001;
        public static final int adUnitId = 0x7f010002;
        public static final int animation = 0x7f010013;
        public static final int banner_type = 0x7f010012;
        public static final int cameraBearing = 0x7f010004;
        public static final int cameraTargetLat = 0x7f010005;
        public static final int cameraTargetLng = 0x7f010006;
        public static final int cameraTilt = 0x7f010007;
        public static final int cameraZoom = 0x7f010008;
        public static final int canShowMR = 0x7f010015;
        public static final int mapType = 0x7f010003;
        public static final int placementType = 0x7f010014;
        public static final int test_mode = 0x7f010011;
        public static final int uiCompass = 0x7f010009;
        public static final int uiRotateGestures = 0x7f01000a;
        public static final int uiScrollGestures = 0x7f01000b;
        public static final int uiTiltGestures = 0x7f01000c;
        public static final int uiZoomControls = 0x7f01000d;
        public static final int uiZoomGestures = 0x7f01000e;
        public static final int useViewLifecycle = 0x7f01000f;
        public static final int zOrderOnTop = 0x7f010010;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class color {
        public static final int common_action_bar_splitter = 0x7f040009;
        public static final int common_signin_btn_dark_text_default = 0x7f040000;
        public static final int common_signin_btn_dark_text_disabled = 0x7f040002;
        public static final int common_signin_btn_dark_text_focused = 0x7f040003;
        public static final int common_signin_btn_dark_text_pressed = 0x7f040001;
        public static final int common_signin_btn_default_background = 0x7f040008;
        public static final int common_signin_btn_light_text_default = 0x7f040004;
        public static final int common_signin_btn_light_text_disabled = 0x7f040006;
        public static final int common_signin_btn_light_text_focused = 0x7f040007;
        public static final int common_signin_btn_light_text_pressed = 0x7f040005;
        public static final int common_signin_btn_text_dark = 0x7f04000a;
        public static final int common_signin_btn_text_light = 0x7f04000b;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class drawable {
        public static final int aa = 0x7f020000;
        public static final int btn_red = 0x7f020001;
        public static final int common_signin_btn_icon_dark = 0x7f020002;
        public static final int common_signin_btn_icon_disabled_dark = 0x7f020003;
        public static final int common_signin_btn_icon_disabled_focus_dark = 0x7f020004;
        public static final int common_signin_btn_icon_disabled_focus_light = 0x7f020005;
        public static final int common_signin_btn_icon_disabled_light = 0x7f020006;
        public static final int common_signin_btn_icon_focus_dark = 0x7f020007;
        public static final int common_signin_btn_icon_focus_light = 0x7f020008;
        public static final int common_signin_btn_icon_light = 0x7f020009;
        public static final int common_signin_btn_icon_normal_dark = 0x7f02000a;
        public static final int common_signin_btn_icon_normal_light = 0x7f02000b;
        public static final int common_signin_btn_icon_pressed_dark = 0x7f02000c;
        public static final int common_signin_btn_icon_pressed_light = 0x7f02000d;
        public static final int common_signin_btn_text_dark = 0x7f02000e;
        public static final int common_signin_btn_text_disabled_dark = 0x7f02000f;
        public static final int common_signin_btn_text_disabled_focus_dark = 0x7f020010;
        public static final int common_signin_btn_text_disabled_focus_light = 0x7f020011;
        public static final int common_signin_btn_text_disabled_light = 0x7f020012;
        public static final int common_signin_btn_text_focus_dark = 0x7f020013;
        public static final int common_signin_btn_text_focus_light = 0x7f020014;
        public static final int common_signin_btn_text_light = 0x7f020015;
        public static final int common_signin_btn_text_normal_dark = 0x7f020016;
        public static final int common_signin_btn_text_normal_light = 0x7f020017;
        public static final int common_signin_btn_text_pressed_dark = 0x7f020018;
        public static final int common_signin_btn_text_pressed_light = 0x7f020019;
        public static final int hey = 0x7f02001a;
        public static final int ic_launcher = 0x7f02001b;
        public static final int ic_plusone_medium_off_client = 0x7f02001c;
        public static final int ic_plusone_small_off_client = 0x7f02001d;
        public static final int ic_plusone_standard_off_client = 0x7f02001e;
        public static final int ic_plusone_tall_off_client = 0x7f02001f;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class id {
        public static final int TextShow = 0x7f05000b;
        public static final int exit = 0x7f050012;
        public static final int f1 = 0x7f050007;
        public static final int f2 = 0x7f050008;
        public static final int f3 = 0x7f050009;
        public static final int hybrid = 0x7f050004;
        public static final int imageView1 = 0x7f050010;
        public static final int linearLayout1 = 0x7f05000a;
        public static final int linearLayout2 = 0x7f05000d;
        public static final int linearLayout3 = 0x7f050006;
        public static final int myAdview = 0x7f05000c;
        public static final int mylayout = 0x7f050005;
        public static final int none = 0x7f050000;
        public static final int normal = 0x7f050001;
        public static final int readbtn = 0x7f050011;
        public static final int return_to_chapter = 0x7f05000e;
        public static final int satellite = 0x7f050002;
        public static final int terrain = 0x7f050003;
        public static final int textView1 = 0x7f05000f;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class integer {
        public static final int google_play_services_version = 0x7f070000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class layout {
        public static final int chapterwindow = 0x7f030000;
        public static final int main = 0x7f030001;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class string {
        public static final int A = 0x7f06001f;
        public static final int app_name = 0x7f06001a;
        public static final int auth_client_needs_enabling_title = 0x7f060015;
        public static final int auth_client_needs_installation_title = 0x7f060016;
        public static final int auth_client_needs_update_title = 0x7f060017;
        public static final int auth_client_play_services_err_notification_msg = 0x7f060018;
        public static final int auth_client_requested_by_msg = 0x7f060019;
        public static final int auth_client_using_bad_version_title = 0x7f060014;
        public static final int click_here_to_read = 0x7f06001e;
        public static final int common_google_play_services_enable_button = 0x7f060006;
        public static final int common_google_play_services_enable_text = 0x7f060005;
        public static final int common_google_play_services_enable_title = 0x7f060004;
        public static final int common_google_play_services_install_button = 0x7f060003;
        public static final int common_google_play_services_install_text_phone = 0x7f060001;
        public static final int common_google_play_services_install_text_tablet = 0x7f060002;
        public static final int common_google_play_services_install_title = 0x7f060000;
        public static final int common_google_play_services_invalid_account_text = 0x7f06000c;
        public static final int common_google_play_services_invalid_account_title = 0x7f06000b;
        public static final int common_google_play_services_network_error_text = 0x7f06000a;
        public static final int common_google_play_services_network_error_title = 0x7f060009;
        public static final int common_google_play_services_unknown_issue = 0x7f06000d;
        public static final int common_google_play_services_unsupported_date_text = 0x7f060010;
        public static final int common_google_play_services_unsupported_text = 0x7f06000f;
        public static final int common_google_play_services_unsupported_title = 0x7f06000e;
        public static final int common_google_play_services_update_button = 0x7f060011;
        public static final int common_google_play_services_update_text = 0x7f060008;
        public static final int common_google_play_services_update_title = 0x7f060007;
        public static final int common_signin_button_text = 0x7f060012;
        public static final int common_signin_button_text_long = 0x7f060013;
        public static final int return_to_chapters = 0x7f06001d;
        public static final int return_to_mainmenu = 0x7f06001c;
        public static final int title = 0x7f06001b;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class styleable {
        public static final int AdView_animation = 0x00000002;
        public static final int AdView_banner_type = 0x00000001;
        public static final int AdView_canShowMR = 0x00000004;
        public static final int AdView_placementType = 0x00000003;
        public static final int AdView_test_mode = 0x00000000;
        public static final int AdsAttrs_adSize = 0x00000000;
        public static final int AdsAttrs_adSizes = 0x00000001;
        public static final int AdsAttrs_adUnitId = 0x00000002;
        public static final int MapAttrs_cameraBearing = 0x00000001;
        public static final int MapAttrs_cameraTargetLat = 0x00000002;
        public static final int MapAttrs_cameraTargetLng = 0x00000003;
        public static final int MapAttrs_cameraTilt = 0x00000004;
        public static final int MapAttrs_cameraZoom = 0x00000005;
        public static final int MapAttrs_mapType = 0x00000000;
        public static final int MapAttrs_uiCompass = 0x00000006;
        public static final int MapAttrs_uiRotateGestures = 0x00000007;
        public static final int MapAttrs_uiScrollGestures = 0x00000008;
        public static final int MapAttrs_uiTiltGestures = 0x00000009;
        public static final int MapAttrs_uiZoomControls = 0x0000000a;
        public static final int MapAttrs_uiZoomGestures = 0x0000000b;
        public static final int MapAttrs_useViewLifecycle = 0x0000000c;
        public static final int MapAttrs_zOrderOnTop = 0x0000000d;
        public static final int[] AdView = {R.attr.test_mode, R.attr.banner_type, R.attr.animation, R.attr.placementType, R.attr.canShowMR};
        public static final int[] AdsAttrs = {2130771968, 2130771969, 2130771970};
        public static final int[] MapAttrs = {2130771971, 2130771972, 2130771973, 2130771974, 2130771975, 2130771976, 2130771977, 2130771978, 2130771979, 2130771980, 2130771981, 2130771982, 2130771983, 2130771984};
    }
}
