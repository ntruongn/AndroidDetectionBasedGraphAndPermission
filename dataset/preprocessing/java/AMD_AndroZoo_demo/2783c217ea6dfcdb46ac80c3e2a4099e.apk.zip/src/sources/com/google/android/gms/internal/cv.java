package com.google.android.gms.internal;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.MutableContextWrapper;
import android.net.Uri;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.google.android.gms.drive.DriveFile;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class cv extends WebView implements DownloadListener {
    private x fU;
    private final Object fx;
    private final h hc;
    private final cw iJ;
    private final a iK;
    private final ct iL;
    private bk iM;
    private boolean iN;
    private boolean iO;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class a extends MutableContextWrapper {
        private Activity iP;
        private Context iQ;

        public a(Context context) {
            super(context);
            setBaseContext(context);
        }

        @Override // android.content.MutableContextWrapper
        public void setBaseContext(Context base) {
            this.iQ = base.getApplicationContext();
            this.iP = base instanceof Activity ? (Activity) base : null;
            super.setBaseContext(this.iQ);
        }

        @Override // android.content.ContextWrapper, android.content.Context
        public void startActivity(Intent intent) {
            if (this.iP != null) {
                this.iP.startActivity(intent);
            } else {
                intent.setFlags(DriveFile.MODE_READ_ONLY);
                this.iQ.startActivity(intent);
            }
        }
    }

    private cv(a aVar, x xVar, boolean z, boolean z2, h hVar, ct ctVar) {
        super(aVar);
        this.fx = new Object();
        this.iK = aVar;
        this.fU = xVar;
        this.iN = z;
        this.hc = hVar;
        this.iL = ctVar;
        setBackgroundColor(0);
        WebSettings settings = getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setSavePassword(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        cn.a(aVar, ctVar.iF, settings);
        if (Build.VERSION.SDK_INT >= 17) {
            cp.a(getContext(), settings);
        } else if (Build.VERSION.SDK_INT >= 11) {
            co.a(getContext(), settings);
        }
        setDownloadListener(this);
        if (Build.VERSION.SDK_INT >= 11) {
            this.iJ = new cy(this, z2);
        } else {
            this.iJ = new cw(this, z2);
        }
        setWebViewClient(this.iJ);
        if (Build.VERSION.SDK_INT >= 14) {
            setWebChromeClient(new cz(this));
        } else if (Build.VERSION.SDK_INT >= 11) {
            setWebChromeClient(new cx(this));
        }
        aF();
    }

    public static cv a(Context context, x xVar, boolean z, boolean z2, h hVar, ct ctVar) {
        return new cv(new a(context), xVar, z, z2, hVar, ctVar);
    }

    private void aF() {
        synchronized (this.fx) {
            if (this.iN || this.fU.eG) {
                if (Build.VERSION.SDK_INT < 14) {
                    cs.r("Disabling hardware acceleration on an overlay.");
                    aG();
                } else {
                    cs.r("Enabling hardware acceleration on an overlay.");
                    aH();
                }
            } else if (Build.VERSION.SDK_INT < 18) {
                cs.r("Disabling hardware acceleration on an AdView.");
                aG();
            } else {
                cs.r("Enabling hardware acceleration on an AdView.");
                aH();
            }
        }
    }

    private void aG() {
        synchronized (this.fx) {
            if (!this.iO && Build.VERSION.SDK_INT >= 11) {
                co.c(this);
            }
            this.iO = true;
        }
    }

    private void aH() {
        synchronized (this.fx) {
            if (this.iO && Build.VERSION.SDK_INT >= 11) {
                co.d(this);
            }
            this.iO = false;
        }
    }

    public void a(Context context, x xVar) {
        synchronized (this.fx) {
            this.iK.setBaseContext(context);
            this.iM = null;
            this.fU = xVar;
            this.iN = false;
            cn.b(this);
            loadUrl("about:blank");
            this.iJ.reset();
        }
    }

    public void a(bk bkVar) {
        synchronized (this.fx) {
            this.iM = bkVar;
        }
    }

    public void a(x xVar) {
        synchronized (this.fx) {
            this.fU = xVar;
            requestLayout();
        }
    }

    public void a(String str, Map<String, ?> map) {
        StringBuilder sb = new StringBuilder();
        sb.append("javascript:AFMA_ReceiveMessage('");
        sb.append(str);
        sb.append("'");
        if (map != null) {
            try {
                String jSONObject = cn.m(map).toString();
                sb.append(",");
                sb.append(jSONObject);
            } catch (JSONException e) {
                cs.v("Could not convert AFMA event parameters to JSON.");
                return;
            }
        }
        sb.append(");");
        cs.u("Dispatching AFMA event: " + ((Object) sb));
        loadUrl(sb.toString());
    }

    public bk aA() {
        bk bkVar;
        synchronized (this.fx) {
            bkVar = this.iM;
        }
        return bkVar;
    }

    public cw aB() {
        return this.iJ;
    }

    public h aC() {
        return this.hc;
    }

    public ct aD() {
        return this.iL;
    }

    public boolean aE() {
        boolean z;
        synchronized (this.fx) {
            z = this.iN;
        }
        return z;
    }

    public void ay() {
        HashMap hashMap = new HashMap(1);
        hashMap.put("version", this.iL.iF);
        a("onhide", hashMap);
    }

    public void az() {
        HashMap hashMap = new HashMap(1);
        hashMap.put("version", this.iL.iF);
        a("onshow", hashMap);
    }

    public void l(boolean z) {
        synchronized (this.fx) {
            this.iN = z;
            aF();
        }
    }

    @Override // android.webkit.DownloadListener
    public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long size) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(url), mimeType);
            getContext().startActivity(intent);
        } catch (ActivityNotFoundException e) {
            cs.r("Couldn't find an Activity to view url/mimetype: " + url + " / " + mimeType);
        }
    }

    @Override // android.webkit.WebView, android.widget.AbsoluteLayout, android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        synchronized (this.fx) {
            if (isInEditMode() || this.iN) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                return;
            }
            int mode = View.MeasureSpec.getMode(widthMeasureSpec);
            int size = View.MeasureSpec.getSize(widthMeasureSpec);
            int mode2 = View.MeasureSpec.getMode(heightMeasureSpec);
            int size2 = View.MeasureSpec.getSize(heightMeasureSpec);
            int i = (mode == Integer.MIN_VALUE || mode == 1073741824) ? size : Integer.MAX_VALUE;
            int i2 = (mode2 == Integer.MIN_VALUE || mode2 == 1073741824) ? size2 : Integer.MAX_VALUE;
            if (this.fU.widthPixels > i || this.fU.heightPixels > i2) {
                cs.v("Not enough space to show ad. Needs " + this.fU.widthPixels + "x" + this.fU.heightPixels + " pixels, but only has " + size + "x" + size2 + " pixels.");
                if (getVisibility() != 8) {
                    setVisibility(4);
                }
                setMeasuredDimension(0, 0);
            } else {
                if (getVisibility() != 8) {
                    setVisibility(0);
                }
                setMeasuredDimension(this.fU.widthPixels, this.fU.heightPixels);
            }
        }
    }

    @Override // android.webkit.WebView, android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        if (this.hc != null) {
            this.hc.a(event);
        }
        return super.onTouchEvent(event);
    }

    public void setContext(Context context) {
        this.iK.setBaseContext(context);
    }

    public x y() {
        x xVar;
        synchronized (this.fx) {
            xVar = this.fU;
        }
        return xVar;
    }
}
