package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.a;
import com.google.android.gms.internal.dh;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.du;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class GoogleApiClient {
    private final dl kB;
    private final Queue<a<?>> kC;
    private ConnectionResult kD;
    private int kE;
    private int kF;
    private int kG;
    private final Bundle kH;
    private final Map<Api.b<?>, Api.a> kI;
    private boolean kJ;
    private final ConnectionCallbacks kK;
    private final dl.b kL;
    private final Object kt;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface ApiOptions {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class Builder {
        private String jD;
        private final Set<String> kO;
        private int kP;
        private View kQ;
        private String kR;
        private final Map<Api, ApiOptions> kS;
        private final Set<ConnectionCallbacks> kT;
        private final Set<OnConnectionFailedListener> kU;
        private final Context mContext;

        public Builder(Context context) {
            this.kO = new HashSet();
            this.kS = new HashMap();
            this.kT = new HashSet();
            this.kU = new HashSet();
            this.mContext = context;
            this.kR = context.getPackageName();
        }

        public Builder(Context context, ConnectionCallbacks connectedListener, OnConnectionFailedListener connectionFailedListener) {
            this(context);
            du.c(connectedListener, "Must provide a connected listener");
            this.kT.add(connectedListener);
            du.c(connectionFailedListener, "Must provide a connection failed listener");
            this.kU.add(connectionFailedListener);
        }

        public Builder addApi(Api api) {
            return addApi(api, null);
        }

        public Builder addApi(Api api, ApiOptions options) {
            this.kS.put(api, options);
            List<Scope> aW = api.aW();
            int size = aW.size();
            for (int i = 0; i < size; i++) {
                this.kO.add(aW.get(i).be());
            }
            return this;
        }

        public Builder addConnectionCallbacks(ConnectionCallbacks listener) {
            this.kT.add(listener);
            return this;
        }

        public Builder addOnConnectionFailedListener(OnConnectionFailedListener listener) {
            this.kU.add(listener);
            return this;
        }

        public Builder addScope(Scope scope) {
            this.kO.add(scope.be());
            return this;
        }

        public dh bd() {
            return new dh(this.jD, this.kO, this.kP, this.kQ, this.kR);
        }

        public GoogleApiClient build() {
            return new GoogleApiClient(this.mContext, bd(), this.kS, this.kT, this.kU);
        }

        public Builder setAccountName(String accountName) {
            this.jD = accountName;
            return this;
        }

        public Builder setGravityForPopups(int gravityForPopups) {
            this.kP = gravityForPopups;
            return this;
        }

        public Builder setViewForPopups(View viewForPopups) {
            this.kQ = viewForPopups;
            return this;
        }

        public Builder useDefaultAccount() {
            return setAccountName("<<default account>>");
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface ConnectionCallbacks extends GooglePlayServicesClient.ConnectionCallbacks {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface OnConnectionFailedListener extends GooglePlayServicesClient.OnConnectionFailedListener {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface a<A extends Api.a> {
        void a(A a);

        Api.b<A> aV();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private GoogleApiClient(Context context, dh commonSettings, Map<Api, ApiOptions> apis, Set<ConnectionCallbacks> connectedCallbacks, Set<OnConnectionFailedListener> onConnectionFailedListeners) {
        this.kt = new Object();
        this.kC = new LinkedList();
        this.kF = 3;
        this.kH = new Bundle();
        this.kI = new HashMap();
        this.kK = new ConnectionCallbacks() { // from class: com.google.android.gms.common.api.GoogleApiClient.1
            @Override // com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks
            public void onConnected(Bundle connectionHint) {
                synchronized (GoogleApiClient.this.kt) {
                    if (GoogleApiClient.this.kF == 1) {
                        if (connectionHint != null) {
                            GoogleApiClient.this.kH.putAll(connectionHint);
                        }
                        GoogleApiClient.this.aY();
                    }
                }
            }

            @Override // com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks
            public void onDisconnected() {
                GoogleApiClient.this.ba();
            }
        };
        this.kL = new dl.b() { // from class: com.google.android.gms.common.api.GoogleApiClient.2
            @Override // com.google.android.gms.internal.dl.b
            public boolean bb() {
                return GoogleApiClient.this.kJ;
            }

            @Override // com.google.android.gms.internal.dl.b
            public Bundle bc() {
                return null;
            }

            @Override // com.google.android.gms.internal.dl.b
            public boolean isConnected() {
                return GoogleApiClient.this.isConnected();
            }
        };
        this.kB = new dl(context, this.kL);
        Iterator<ConnectionCallbacks> it = connectedCallbacks.iterator();
        while (it.hasNext()) {
            this.kB.registerConnectionCallbacks(it.next());
        }
        Iterator<OnConnectionFailedListener> it2 = onConnectionFailedListeners.iterator();
        while (it2.hasNext()) {
            this.kB.registerConnectionFailedListener(it2.next());
        }
        for (Api api : apis.keySet()) {
            final Api.b<?> aV = api.aV();
            this.kI.put(aV, aV.b(context, commonSettings, apis.get(api), this.kK, new OnConnectionFailedListener() { // from class: com.google.android.gms.common.api.GoogleApiClient.3
                @Override // com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener
                public void onConnectionFailed(ConnectionResult result) {
                    synchronized (GoogleApiClient.this.kt) {
                        if (GoogleApiClient.this.kD == null || aV.getPriority() < GoogleApiClient.this.kE) {
                            GoogleApiClient.this.kD = result;
                            GoogleApiClient.this.kE = aV.getPriority();
                        }
                        GoogleApiClient.this.aY();
                    }
                }
            }));
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private <A extends Api.a> void a(a<A> aVar) {
        synchronized (this.kt) {
            du.a(isConnected(), "GoogleApiClient is not connected yet.");
            du.a(aVar.aV() != null, "This task can not be executed or enqueued (it's probably a Batch or malformed)");
            aVar.a(a(aVar.aV()));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void aY() {
        synchronized (this.kt) {
            this.kG--;
            if (this.kG == 0) {
                if (this.kD != null) {
                    this.kF = 3;
                    Iterator<Api.a> it = this.kI.values().iterator();
                    while (it.hasNext()) {
                        it.next().disconnect();
                    }
                    this.kB.a(this.kD);
                } else {
                    this.kF = 2;
                    this.kB.b(this.kH.isEmpty() ? null : this.kH);
                    aZ();
                }
            }
        }
    }

    private void aZ() {
        du.a(isConnected(), "GoogleApiClient is not connected yet.");
        synchronized (this.kt) {
            while (!this.kC.isEmpty()) {
                a(this.kC.remove());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void ba() {
        synchronized (this.kt) {
            this.kJ = false;
            this.kC.clear();
            Iterator<Api.a> it = this.kI.values().iterator();
            while (it.hasNext()) {
                it.next().disconnect();
            }
            if (this.kF != 3) {
                this.kF = 3;
                this.kB.bG();
            }
        }
    }

    public <C extends Api.a> C a(Api.b<C> bVar) {
        C c = (C) this.kI.get(bVar);
        du.c(c, "Appropriate Api was not requested.");
        return c;
    }

    public <A extends Api.a, T extends a.AbstractC0001a<?, ?, A>> T a(T t) {
        synchronized (this.kt) {
            if (isConnected()) {
                b((GoogleApiClient) t);
            } else {
                this.kC.add(t);
            }
        }
        return t;
    }

    public <A extends Api.a, T extends a.AbstractC0001a<?, ?, A>> T b(T t) {
        du.a(isConnected(), "GoogleApiClient is not connected yet.");
        aZ();
        a((a) t);
        return t;
    }

    public void connect() {
        synchronized (this.kt) {
            if (isConnected() || isConnecting()) {
                return;
            }
            this.kJ = true;
            this.kD = null;
            this.kF = 1;
            this.kH.clear();
            this.kG = this.kI.size();
            Iterator<Api.a> it = this.kI.values().iterator();
            while (it.hasNext()) {
                it.next().connect();
            }
        }
    }

    public void disconnect() {
        ba();
    }

    public boolean isConnected() {
        boolean z;
        synchronized (this.kt) {
            z = this.kF == 2;
        }
        return z;
    }

    public boolean isConnecting() {
        boolean z;
        synchronized (this.kt) {
            z = this.kF == 1;
        }
        return z;
    }

    public boolean isConnectionCallbacksRegistered(ConnectionCallbacks listener) {
        return this.kB.isConnectionCallbacksRegistered(listener);
    }

    public boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener listener) {
        return this.kB.isConnectionFailedListenerRegistered(listener);
    }

    public void reconnect() {
        disconnect();
        connect();
    }

    public void registerConnectionCallbacks(ConnectionCallbacks listener) {
        this.kB.registerConnectionCallbacks(listener);
    }

    public void registerConnectionFailedListener(OnConnectionFailedListener listener) {
        this.kB.registerConnectionFailedListener(listener);
    }

    public void unregisterConnectionCallbacks(ConnectionCallbacks listener) {
        this.kB.unregisterConnectionCallbacks(listener);
    }

    public void unregisterConnectionFailedListener(OnConnectionFailedListener listener) {
        this.kB.unregisterConnectionFailedListener(listener);
    }
}
