package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class bl implements Parcelable.Creator<bm> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(bm bmVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, bmVar.versionCode);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, (Parcelable) bmVar.gF, i, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, bmVar.aa(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 4, bmVar.ab(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, bmVar.ac(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 6, bmVar.ad(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 7, bmVar.gK, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 8, bmVar.gL);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 9, bmVar.gM, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 10, bmVar.ae(), false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 11, bmVar.orientation);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 12, bmVar.gO);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 13, bmVar.gn, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 14, (Parcelable) bmVar.ej, i, false);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: e, reason: merged with bridge method [inline-methods] */
    public bm createFromParcel(Parcel parcel) {
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        bj bjVar = null;
        IBinder iBinder = null;
        IBinder iBinder2 = null;
        IBinder iBinder3 = null;
        IBinder iBinder4 = null;
        String str = null;
        boolean z = false;
        String str2 = null;
        IBinder iBinder5 = null;
        int i2 = 0;
        int i3 = 0;
        String str3 = null;
        ct ctVar = null;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 2:
                    bjVar = (bj) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, bj.CREATOR);
                    break;
                case 3:
                    iBinder = com.google.android.gms.common.internal.safeparcel.a.n(parcel, j);
                    break;
                case 4:
                    iBinder2 = com.google.android.gms.common.internal.safeparcel.a.n(parcel, j);
                    break;
                case 5:
                    iBinder3 = com.google.android.gms.common.internal.safeparcel.a.n(parcel, j);
                    break;
                case 6:
                    iBinder4 = com.google.android.gms.common.internal.safeparcel.a.n(parcel, j);
                    break;
                case 7:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    break;
                case 8:
                    z = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j);
                    break;
                case 9:
                    str2 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    break;
                case 10:
                    iBinder5 = com.google.android.gms.common.internal.safeparcel.a.n(parcel, j);
                    break;
                case 11:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 12:
                    i3 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 13:
                    str3 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    break;
                case Status.INTERRUPTED /* 14 */:
                    ctVar = (ct) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, ct.CREATOR);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new bm(i, bjVar, iBinder, iBinder2, iBinder3, iBinder4, str, z, str2, iBinder5, i2, i3, str3, ctVar);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: j, reason: merged with bridge method [inline-methods] */
    public bm[] newArray(int i) {
        return new bm[i];
    }
}
