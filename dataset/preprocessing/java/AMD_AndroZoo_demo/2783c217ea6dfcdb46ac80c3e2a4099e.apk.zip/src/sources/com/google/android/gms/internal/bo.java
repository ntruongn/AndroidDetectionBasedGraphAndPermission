package com.google.android.gms.internal;

import android.content.Context;
import android.media.MediaPlayer;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.VideoView;
import com.huprya.wqkqze112375.IM;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class bo extends FrameLayout implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener {
    private final MediaController gP;
    private final a gQ;
    private final VideoView gR;
    private long gS;
    private String gT;
    private final cv gu;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a {
        private final Runnable ep;
        private volatile boolean gU = false;

        public a(final bo boVar) {
            this.ep = new Runnable() { // from class: com.google.android.gms.internal.bo.a.1
                private final WeakReference<bo> gV;

                {
                    this.gV = new WeakReference<>(boVar);
                }

                @Override // java.lang.Runnable
                public void run() {
                    bo boVar2 = this.gV.get();
                    if (a.this.gU || boVar2 == null) {
                        return;
                    }
                    boVar2.ag();
                    a.this.ah();
                }
            };
        }

        public void ah() {
            cr.iE.postDelayed(this.ep, 250L);
        }

        public void cancel() {
            this.gU = true;
            cr.iE.removeCallbacks(this.ep);
        }
    }

    public bo(Context context, cv cvVar) {
        super(context);
        this.gu = cvVar;
        this.gR = new VideoView(context);
        addView(this.gR, new FrameLayout.LayoutParams(-1, -1, 17));
        this.gP = new MediaController(context);
        this.gQ = new a(this);
        this.gQ.ah();
        this.gR.setOnCompletionListener(this);
        this.gR.setOnPreparedListener(this);
        this.gR.setOnErrorListener(this);
    }

    private static void a(cv cvVar, String str) {
        a(cvVar, str, new HashMap(1));
    }

    public static void a(cv cvVar, String str, String str2) {
        boolean z = str2 == null;
        HashMap hashMap = new HashMap(z ? 2 : 3);
        hashMap.put("what", str);
        if (!z) {
            hashMap.put("extra", str2);
        }
        a(cvVar, IM.EVENT_ERROR, hashMap);
    }

    private static void a(cv cvVar, String str, String str2, String str3) {
        HashMap hashMap = new HashMap(2);
        hashMap.put(str2, str3);
        a(cvVar, str, hashMap);
    }

    private static void a(cv cvVar, String str, Map<String, String> map) {
        map.put("event", str);
        cvVar.a("onVideoEvent", map);
    }

    public void af() {
        if (TextUtils.isEmpty(this.gT)) {
            a(this.gu, "no_src", (String) null);
        } else {
            this.gR.setVideoPath(this.gT);
        }
    }

    public void ag() {
        long currentPosition = this.gR.getCurrentPosition();
        if (this.gS != currentPosition) {
            a(this.gu, "timeupdate", "time", String.valueOf(((float) currentPosition) / 1000.0f));
            this.gS = currentPosition;
        }
    }

    public void b(MotionEvent motionEvent) {
        this.gR.dispatchTouchEvent(motionEvent);
    }

    public void destroy() {
        this.gQ.cancel();
        this.gR.stopPlayback();
    }

    public void i(boolean z) {
        if (z) {
            this.gR.setMediaController(this.gP);
        } else {
            this.gP.hide();
            this.gR.setMediaController(null);
        }
    }

    public void n(String str) {
        this.gT = str;
    }

    @Override // android.media.MediaPlayer.OnCompletionListener
    public void onCompletion(MediaPlayer mediaPlayer) {
        a(this.gu, "ended");
    }

    @Override // android.media.MediaPlayer.OnErrorListener
    public boolean onError(MediaPlayer mediaPlayer, int what, int extra) {
        a(this.gu, String.valueOf(what), String.valueOf(extra));
        return true;
    }

    @Override // android.media.MediaPlayer.OnPreparedListener
    public void onPrepared(MediaPlayer mediaPlayer) {
        a(this.gu, "canplaythrough", "duration", String.valueOf(this.gR.getDuration() / 1000.0f));
    }

    public void pause() {
        this.gR.pause();
    }

    public void play() {
        this.gR.start();
    }

    public void seekTo(int timeInMilliseconds) {
        this.gR.seekTo(timeInMilliseconds);
    }
}
