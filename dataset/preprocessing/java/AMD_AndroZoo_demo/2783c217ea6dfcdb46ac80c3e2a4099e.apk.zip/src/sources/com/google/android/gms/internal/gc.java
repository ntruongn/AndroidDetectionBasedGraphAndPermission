package com.google.android.gms.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class gc implements Parcelable.Creator<gb> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(gb gbVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 1, gbVar.getId(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, gbVar.dM(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, (Parcelable) gbVar.dN(), i, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 4, (Parcelable) gbVar.dF(), i, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, gbVar.dG());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 6, (Parcelable) gbVar.dH(), i, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 7, gbVar.dO(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 8, (Parcelable) gbVar.dI(), i, false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 9, gbVar.dJ());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 10, gbVar.getRating());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 11, gbVar.dK());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 12, gbVar.dL());
        com.google.android.gms.common.internal.safeparcel.b.b(parcel, 13, gbVar.dE(), false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1000, gbVar.kZ);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aL, reason: merged with bridge method [inline-methods] */
    public gb[] newArray(int i) {
        return new gb[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: af, reason: merged with bridge method [inline-methods] */
    public gb createFromParcel(Parcel parcel) {
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        String str = null;
        ArrayList arrayList = null;
        Bundle bundle = null;
        gd gdVar = null;
        LatLng latLng = null;
        float f = BitmapDescriptorFactory.HUE_RED;
        LatLngBounds latLngBounds = null;
        String str2 = null;
        Uri uri = null;
        boolean z = false;
        float f2 = BitmapDescriptorFactory.HUE_RED;
        int i2 = 0;
        long j = 0;
        while (parcel.dataPosition() < k) {
            int j2 = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j2)) {
                case 1:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j2);
                    break;
                case 2:
                    bundle = com.google.android.gms.common.internal.safeparcel.a.o(parcel, j2);
                    break;
                case 3:
                    gdVar = (gd) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j2, gd.CREATOR);
                    break;
                case 4:
                    latLng = (LatLng) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j2, LatLng.CREATOR);
                    break;
                case 5:
                    f = com.google.android.gms.common.internal.safeparcel.a.j(parcel, j2);
                    break;
                case 6:
                    latLngBounds = (LatLngBounds) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j2, LatLngBounds.CREATOR);
                    break;
                case 7:
                    str2 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j2);
                    break;
                case 8:
                    uri = (Uri) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j2, Uri.CREATOR);
                    break;
                case 9:
                    z = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j2);
                    break;
                case 10:
                    f2 = com.google.android.gms.common.internal.safeparcel.a.j(parcel, j2);
                    break;
                case 11:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j2);
                    break;
                case 12:
                    j = com.google.android.gms.common.internal.safeparcel.a.h(parcel, j2);
                    break;
                case 13:
                    arrayList = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j2, fw.CREATOR);
                    break;
                case 1000:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j2);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j2);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new gb(i, str, arrayList, bundle, gdVar, latLng, f, latLngBounds, str2, uri, z, f2, i2, j);
    }
}
