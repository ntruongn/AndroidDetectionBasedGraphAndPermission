package com.google.android.gms.internal;

import android.os.Process;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class cm {
    private static final ThreadFactory iv = new ThreadFactory() { // from class: com.google.android.gms.internal.cm.2
        private final AtomicInteger iy = new AtomicInteger(1);

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, "AdWorker #" + this.iy.getAndIncrement());
        }
    };
    private static final ThreadPoolExecutor iw = new ThreadPoolExecutor(0, 10, 65, TimeUnit.SECONDS, new SynchronousQueue(true), iv);

    public static void execute(final Runnable task) {
        try {
            iw.execute(new Runnable() { // from class: com.google.android.gms.internal.cm.1
                @Override // java.lang.Runnable
                public void run() {
                    Process.setThreadPriority(10);
                    task.run();
                }
            });
        } catch (RejectedExecutionException e) {
            cs.b("Too many background threads already running. Aborting task.", e);
        }
    }
}
