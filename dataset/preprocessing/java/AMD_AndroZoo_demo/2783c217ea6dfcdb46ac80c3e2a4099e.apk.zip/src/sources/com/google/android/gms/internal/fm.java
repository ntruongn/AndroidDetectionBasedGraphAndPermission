package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.dk;
import com.google.android.gms.internal.fj;
import com.google.android.gms.internal.fk;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationStatusCodes;
import java.util.HashMap;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class fm extends dk<fk> {
    private final fp<fk> tM;
    private final fl tS;
    private final HashMap tT;
    private final String tU;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private final class a extends dk<fk>.b<LocationClient.OnAddGeofencesResultListener> {
        private final int ka;
        private final String[] tV;

        public a(LocationClient.OnAddGeofencesResultListener onAddGeofencesResultListener, int i, String[] strArr) {
            super(onAddGeofencesResultListener);
            this.ka = LocationStatusCodes.aD(i);
            this.tV = strArr;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(LocationClient.OnAddGeofencesResultListener onAddGeofencesResultListener) {
            if (onAddGeofencesResultListener != null) {
                onAddGeofencesResultListener.onAddGeofencesResult(this.ka, this.tV);
            }
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class b extends fj.a {
        private LocationClient.OnAddGeofencesResultListener tX;
        private LocationClient.OnRemoveGeofencesResultListener tY;
        private fm tZ;

        public b(LocationClient.OnAddGeofencesResultListener onAddGeofencesResultListener, fm fmVar) {
            this.tX = onAddGeofencesResultListener;
            this.tY = null;
            this.tZ = fmVar;
        }

        public b(LocationClient.OnRemoveGeofencesResultListener onRemoveGeofencesResultListener, fm fmVar) {
            this.tY = onRemoveGeofencesResultListener;
            this.tX = null;
            this.tZ = fmVar;
        }

        @Override // com.google.android.gms.internal.fj
        public void onAddGeofencesResult(int statusCode, String[] geofenceRequestIds) throws RemoteException {
            if (this.tZ == null) {
                Log.wtf("LocationClientImpl", "onAddGeofenceResult called multiple times");
                return;
            }
            fm fmVar = this.tZ;
            fm fmVar2 = this.tZ;
            fmVar2.getClass();
            fmVar.a(new a(this.tX, statusCode, geofenceRequestIds));
            this.tZ = null;
            this.tX = null;
            this.tY = null;
        }

        @Override // com.google.android.gms.internal.fj
        public void onRemoveGeofencesByPendingIntentResult(int statusCode, PendingIntent pendingIntent) {
            if (this.tZ == null) {
                Log.wtf("LocationClientImpl", "onRemoveGeofencesByPendingIntentResult called multiple times");
                return;
            }
            fm fmVar = this.tZ;
            fm fmVar2 = this.tZ;
            fmVar2.getClass();
            fmVar.a(new d(1, this.tY, statusCode, pendingIntent));
            this.tZ = null;
            this.tX = null;
            this.tY = null;
        }

        @Override // com.google.android.gms.internal.fj
        public void onRemoveGeofencesByRequestIdsResult(int statusCode, String[] geofenceRequestIds) {
            if (this.tZ == null) {
                Log.wtf("LocationClientImpl", "onRemoveGeofencesByRequestIdsResult called multiple times");
                return;
            }
            fm fmVar = this.tZ;
            fm fmVar2 = this.tZ;
            fmVar2.getClass();
            fmVar.a(new d(2, this.tY, statusCode, geofenceRequestIds));
            this.tZ = null;
            this.tX = null;
            this.tY = null;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private final class c implements fp<fk> {
        private c() {
        }

        @Override // com.google.android.gms.internal.fp
        public void bB() {
            fm.this.bB();
        }

        @Override // com.google.android.gms.internal.fp
        /* renamed from: dr, reason: merged with bridge method [inline-methods] */
        public fk bC() {
            return (fk) fm.this.bC();
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private final class d extends dk<fk>.b<LocationClient.OnRemoveGeofencesResultListener> {
        private final int ka;
        private final PendingIntent mPendingIntent;
        private final String[] tV;
        private final int ua;

        public d(int i, LocationClient.OnRemoveGeofencesResultListener onRemoveGeofencesResultListener, int i2, PendingIntent pendingIntent) {
            super(onRemoveGeofencesResultListener);
            dg.n(i == 1);
            this.ua = i;
            this.ka = LocationStatusCodes.aD(i2);
            this.mPendingIntent = pendingIntent;
            this.tV = null;
        }

        public d(int i, LocationClient.OnRemoveGeofencesResultListener onRemoveGeofencesResultListener, int i2, String[] strArr) {
            super(onRemoveGeofencesResultListener);
            dg.n(i == 2);
            this.ua = i;
            this.ka = LocationStatusCodes.aD(i2);
            this.tV = strArr;
            this.mPendingIntent = null;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(LocationClient.OnRemoveGeofencesResultListener onRemoveGeofencesResultListener) {
            if (onRemoveGeofencesResultListener != null) {
                switch (this.ua) {
                    case 1:
                        onRemoveGeofencesResultListener.onRemoveGeofencesByPendingIntentResult(this.ka, this.mPendingIntent);
                        return;
                    case 2:
                        onRemoveGeofencesResultListener.onRemoveGeofencesByRequestIdsResult(this.ka, this.tV);
                        return;
                    default:
                        Log.wtf("LocationClientImpl", "Unsupported action: " + this.ua);
                        return;
                }
            }
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    public fm(Context context, GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener, String str) {
        super(context, connectionCallbacks, onConnectionFailedListener, new String[0]);
        this.tM = new c();
        this.tT = new HashMap();
        this.tS = new fl(context, this.tM);
        this.tU = str;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.internal.dk
    /* renamed from: J, reason: merged with bridge method [inline-methods] */
    public fk p(IBinder iBinder) {
        return fk.a.I(iBinder);
    }

    @Override // com.google.android.gms.internal.dk
    protected void a(dq dqVar, dk.d dVar) throws RemoteException {
        Bundle bundle = new Bundle();
        bundle.putString("client_name", this.tU);
        dqVar.e(dVar, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), bundle);
    }

    public void addGeofences(List<fn> geofences, PendingIntent pendingIntent, LocationClient.OnAddGeofencesResultListener listener) {
        b bVar;
        bB();
        du.b(geofences != null && geofences.size() > 0, "At least one geofence must be specified.");
        du.c(pendingIntent, "PendingIntent must be specified.");
        du.c(listener, "OnAddGeofencesResultListener not provided.");
        if (listener == null) {
            bVar = null;
        } else {
            try {
                bVar = new b(listener, this);
            } catch (RemoteException e) {
                throw new IllegalStateException(e);
            }
        }
        bC().a(geofences, pendingIntent, bVar, getContext().getPackageName());
    }

    @Override // com.google.android.gms.internal.dk
    protected String am() {
        return "com.google.android.location.internal.GoogleLocationManagerService.START";
    }

    @Override // com.google.android.gms.internal.dk
    protected String an() {
        return "com.google.android.gms.location.internal.IGoogleLocationManagerService";
    }

    @Override // com.google.android.gms.internal.dk, com.google.android.gms.common.GooglePlayServicesClient
    public void disconnect() {
        synchronized (this.tS) {
            if (isConnected()) {
                this.tS.removeAllListeners();
                this.tS.dq();
            }
            super.disconnect();
        }
    }

    public Location getLastLocation() {
        return this.tS.getLastLocation();
    }

    public void removeActivityUpdates(PendingIntent callbackIntent) {
        bB();
        du.f(callbackIntent);
        try {
            bC().removeActivityUpdates(callbackIntent);
        } catch (RemoteException e) {
            throw new IllegalStateException(e);
        }
    }

    public void removeGeofences(PendingIntent pendingIntent, LocationClient.OnRemoveGeofencesResultListener listener) {
        b bVar;
        bB();
        du.c(pendingIntent, "PendingIntent must be specified.");
        du.c(listener, "OnRemoveGeofencesResultListener not provided.");
        if (listener == null) {
            bVar = null;
        } else {
            try {
                bVar = new b(listener, this);
            } catch (RemoteException e) {
                throw new IllegalStateException(e);
            }
        }
        bC().a(pendingIntent, bVar, getContext().getPackageName());
    }

    public void removeGeofences(List<String> geofenceRequestIds, LocationClient.OnRemoveGeofencesResultListener listener) {
        b bVar;
        bB();
        du.b(geofenceRequestIds != null && geofenceRequestIds.size() > 0, "geofenceRequestIds can't be null nor empty.");
        du.c(listener, "OnRemoveGeofencesResultListener not provided.");
        String[] strArr = (String[]) geofenceRequestIds.toArray(new String[0]);
        if (listener == null) {
            bVar = null;
        } else {
            try {
                bVar = new b(listener, this);
            } catch (RemoteException e) {
                throw new IllegalStateException(e);
            }
        }
        bC().a(strArr, bVar, getContext().getPackageName());
    }

    public void removeLocationUpdates(PendingIntent callbackIntent) {
        this.tS.removeLocationUpdates(callbackIntent);
    }

    public void removeLocationUpdates(LocationListener listener) {
        this.tS.removeLocationUpdates(listener);
    }

    public void requestActivityUpdates(long detectionIntervalMillis, PendingIntent callbackIntent) {
        bB();
        du.f(callbackIntent);
        du.b(detectionIntervalMillis >= 0, "detectionIntervalMillis must be >= 0");
        try {
            bC().a(detectionIntervalMillis, true, callbackIntent);
        } catch (RemoteException e) {
            throw new IllegalStateException(e);
        }
    }

    public void requestLocationUpdates(LocationRequest request, PendingIntent callbackIntent) {
        this.tS.requestLocationUpdates(request, callbackIntent);
    }

    public void requestLocationUpdates(LocationRequest request, LocationListener listener) {
        requestLocationUpdates(request, listener, null);
    }

    public void requestLocationUpdates(LocationRequest request, LocationListener listener, Looper looper) {
        synchronized (this.tS) {
            this.tS.requestLocationUpdates(request, listener, looper);
        }
    }

    public void setMockLocation(Location mockLocation) {
        this.tS.setMockLocation(mockLocation);
    }

    public void setMockMode(boolean isMockMode) {
        this.tS.setMockMode(isMockMode);
    }
}
