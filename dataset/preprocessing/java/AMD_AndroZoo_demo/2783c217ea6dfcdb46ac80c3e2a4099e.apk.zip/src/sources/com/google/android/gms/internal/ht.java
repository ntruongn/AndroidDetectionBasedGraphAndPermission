package com.google.android.gms.internal;

import java.io.IOException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class ht {
    protected int oK = -1;

    public static final <T extends ht> T a(T t, byte[] bArr) throws hs {
        return (T) b(t, bArr, 0, bArr.length);
    }

    public static final void a(ht htVar, byte[] bArr, int i, int i2) {
        try {
            hr b = hr.b(bArr, i, i2);
            htVar.a(b);
            b.fK();
        } catch (IOException e) {
            throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", e);
        }
    }

    public static final byte[] a(ht htVar) {
        byte[] bArr = new byte[htVar.cw()];
        a(htVar, bArr, 0, bArr.length);
        return bArr;
    }

    public static final <T extends ht> T b(T t, byte[] bArr, int i, int i2) throws hs {
        try {
            hq a = hq.a(bArr, i, i2);
            t.b(a);
            a.bp(0);
            return t;
        } catch (hs e) {
            throw e;
        } catch (IOException e2) {
            throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).");
        }
    }

    public abstract void a(hr hrVar) throws IOException;

    public abstract ht b(hq hqVar) throws IOException;

    public int cw() {
        this.oK = 0;
        return 0;
    }

    public String toString() {
        return hu.b(this);
    }
}
