package com.google.android.gms.common.data;

import android.os.Bundle;
import com.google.android.gms.internal.dg;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class FilteredDataBuffer<T> extends DataBuffer<T> {
    protected final DataBuffer<T> mDataBuffer;

    public FilteredDataBuffer(DataBuffer<T> dataBuffer) {
        super(null);
        dg.d(dataBuffer);
        this.mDataBuffer = dataBuffer;
    }

    @Override // com.google.android.gms.common.data.DataBuffer
    public void close() {
        this.mDataBuffer.close();
    }

    protected abstract int computeRealPosition(int i);

    @Override // com.google.android.gms.common.data.DataBuffer
    public T get(int position) {
        return this.mDataBuffer.get(computeRealPosition(position));
    }

    @Override // com.google.android.gms.common.data.DataBuffer
    public Bundle getMetadata() {
        return this.mDataBuffer.getMetadata();
    }

    @Override // com.google.android.gms.common.data.DataBuffer
    public boolean isClosed() {
        return this.mDataBuffer.isClosed();
    }
}
