package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class s implements Parcelable.Creator<OnDownloadProgressResponse> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(OnDownloadProgressResponse onDownloadProgressResponse, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, onDownloadProgressResponse.kZ);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, onDownloadProgressResponse.oL);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, onDownloadProgressResponse.oM);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: D, reason: merged with bridge method [inline-methods] */
    public OnDownloadProgressResponse createFromParcel(Parcel parcel) {
        long j = 0;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        long j2 = 0;
        while (parcel.dataPosition() < k) {
            int j3 = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j3)) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j3);
                    break;
                case 2:
                    j2 = com.google.android.gms.common.internal.safeparcel.a.h(parcel, j3);
                    break;
                case 3:
                    j = com.google.android.gms.common.internal.safeparcel.a.h(parcel, j3);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j3);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new OnDownloadProgressResponse(i, j2, j);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: U, reason: merged with bridge method [inline-methods] */
    public OnDownloadProgressResponse[] newArray(int i) {
        return new OnDownloadProgressResponse[i];
    }
}
