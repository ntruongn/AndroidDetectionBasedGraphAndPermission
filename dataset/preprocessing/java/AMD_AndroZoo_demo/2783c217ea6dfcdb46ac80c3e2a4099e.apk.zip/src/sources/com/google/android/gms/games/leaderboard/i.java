package com.google.android.gms.games.leaderboard;

import android.content.ContentValues;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.du;
import com.google.android.gms.internal.fh;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class i {
    private static final String[] so = {"leaderboardId", "playerId", "timeSpan", "hasResult", "rawScore", "formattedScore", "newBest", "scoreTag"};
    private int ka;
    private String qK;
    private String rL;
    private HashMap<Integer, a> sp = new HashMap<>();

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a {
        public final String formattedScore;
        public final boolean newBest;
        public final long rawScore;
        public final String scoreTag;

        public a(long j, String str, String str2, boolean z) {
            this.rawScore = j;
            this.formattedScore = str;
            this.scoreTag = str2;
            this.newBest = z;
        }

        public String toString() {
            return ds.e(this).a("RawScore", Long.valueOf(this.rawScore)).a("FormattedScore", this.formattedScore).a("ScoreTag", this.scoreTag).a("NewBest", Boolean.valueOf(this.newBest)).toString();
        }
    }

    public i(DataHolder dataHolder) {
        this.ka = dataHolder.getStatusCode();
        int count = dataHolder.getCount();
        du.p(count == 3);
        for (int i = 0; i < count; i++) {
            int t = dataHolder.t(i);
            if (i == 0) {
                this.rL = dataHolder.getString("leaderboardId", i, t);
                this.qK = dataHolder.getString("playerId", i, t);
            }
            if (dataHolder.getBoolean("hasResult", i, t)) {
                a(new a(dataHolder.getLong("rawScore", i, t), dataHolder.getString("formattedScore", i, t), dataHolder.getString("scoreTag", i, t), dataHolder.getBoolean("newBest", i, t)), dataHolder.getInteger("timeSpan", i, t));
            }
        }
    }

    private void a(a aVar, int i) {
        this.sp.put(Integer.valueOf(i), aVar);
    }

    private ContentValues au(int i) {
        a av = av(i);
        ContentValues contentValues = new ContentValues();
        contentValues.put("leaderboardId", this.rL);
        contentValues.put("playerId", this.qK);
        contentValues.put("timeSpan", Integer.valueOf(i));
        if (av != null) {
            contentValues.put("rawScore", Long.valueOf(av.rawScore));
            contentValues.put("formattedScore", av.formattedScore);
            contentValues.put("scoreTag", av.scoreTag);
            contentValues.put("newBest", Boolean.valueOf(av.newBest));
            contentValues.put("hasResult", (Boolean) true);
        } else {
            contentValues.put("hasResult", (Boolean) false);
        }
        return contentValues;
    }

    public a av(int i) {
        return this.sp.get(Integer.valueOf(i));
    }

    public DataHolder dl() {
        DataHolder.Builder builder = DataHolder.builder(so);
        for (int i = 0; i < 3; i++) {
            builder.withRow(au(i));
        }
        return builder.build(this.ka);
    }

    public String toString() {
        ds.a a2 = ds.e(this).a("PlayerId", this.qK).a("StatusCode", Integer.valueOf(this.ka));
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= 3) {
                return a2.toString();
            }
            a aVar = this.sp.get(Integer.valueOf(i2));
            a2.a("TimesSpan", fh.at(i2));
            a2.a("Result", aVar == null ? "null" : aVar.toString());
            i = i2 + 1;
        }
    }
}
