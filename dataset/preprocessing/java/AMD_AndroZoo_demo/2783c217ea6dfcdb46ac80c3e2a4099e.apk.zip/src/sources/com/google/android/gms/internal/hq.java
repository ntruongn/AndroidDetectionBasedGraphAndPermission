package com.google.android.gms.internal;

import java.io.IOException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class hq {
    private int CJ;
    private int CK;
    private int CL;
    private int CM;
    private int CN = Integer.MAX_VALUE;
    private int CO = 64;
    private int CP = 67108864;
    private final byte[] buffer;

    private hq(byte[] bArr, int i, int i2) {
        this.buffer = bArr;
        this.CJ = i;
        this.CK = i + i2;
        this.CL = i;
    }

    public static hq a(byte[] bArr, int i, int i2) {
        return new hq(bArr, i, i2);
    }

    public static long j(long j) {
        return (j >>> 1) ^ (-(1 & j));
    }

    public void bp(int i) throws hs {
        if (this.CM != i) {
            throw hs.fP();
        }
    }

    public boolean bq(int i) throws IOException {
        switch (hv.bz(i)) {
            case 0:
                fB();
                return true;
            case 1:
                fG();
                return true;
            case 2:
                bs(fD());
                return true;
            case 3:
                fA();
                bp(hv.g(hv.bA(i), 4));
                return true;
            case 4:
                return false;
            case 5:
                fF();
                return true;
            default:
                throw hs.fQ();
        }
    }

    public byte[] br(int i) throws IOException {
        if (i < 0) {
            throw hs.fM();
        }
        if (this.CL + i > this.CN) {
            bs(this.CN - this.CL);
            throw hs.fL();
        }
        if (i > this.CK - this.CL) {
            throw hs.fL();
        }
        byte[] bArr = new byte[i];
        System.arraycopy(this.buffer, this.CL, bArr, 0, i);
        this.CL += i;
        return bArr;
    }

    public void bs(int i) throws IOException {
        if (i < 0) {
            throw hs.fM();
        }
        if (this.CL + i > this.CN) {
            bs(this.CN - this.CL);
            throw hs.fL();
        }
        if (i > this.CK - this.CL) {
            throw hs.fL();
        }
        this.CL += i;
    }

    public void fA() throws IOException {
        int fz;
        do {
            fz = fz();
            if (fz == 0) {
                return;
            }
        } while (bq(fz));
    }

    public int fB() throws IOException {
        return fD();
    }

    public long fC() throws IOException {
        return j(fE());
    }

    public int fD() throws IOException {
        byte fI = fI();
        if (fI >= 0) {
            return fI;
        }
        int i = fI & Byte.MAX_VALUE;
        byte fI2 = fI();
        if (fI2 >= 0) {
            return i | (fI2 << 7);
        }
        int i2 = i | ((fI2 & Byte.MAX_VALUE) << 7);
        byte fI3 = fI();
        if (fI3 >= 0) {
            return i2 | (fI3 << 14);
        }
        int i3 = i2 | ((fI3 & Byte.MAX_VALUE) << 14);
        byte fI4 = fI();
        if (fI4 >= 0) {
            return i3 | (fI4 << 21);
        }
        int i4 = i3 | ((fI4 & Byte.MAX_VALUE) << 21);
        byte fI5 = fI();
        int i5 = i4 | (fI5 << 28);
        if (fI5 >= 0) {
            return i5;
        }
        for (int i6 = 0; i6 < 5; i6++) {
            if (fI() >= 0) {
                return i5;
            }
        }
        throw hs.fN();
    }

    public long fE() throws IOException {
        long j = 0;
        for (int i = 0; i < 64; i += 7) {
            j |= (r3 & Byte.MAX_VALUE) << i;
            if ((fI() & 128) == 0) {
                return j;
            }
        }
        throw hs.fN();
    }

    public int fF() throws IOException {
        return (fI() & 255) | ((fI() & 255) << 8) | ((fI() & 255) << 16) | ((fI() & 255) << 24);
    }

    public long fG() throws IOException {
        return ((fI() & 255) << 8) | (fI() & 255) | ((fI() & 255) << 16) | ((fI() & 255) << 24) | ((fI() & 255) << 32) | ((fI() & 255) << 40) | ((fI() & 255) << 48) | ((fI() & 255) << 56);
    }

    public boolean fH() {
        return this.CL == this.CK;
    }

    public byte fI() throws IOException {
        if (this.CL == this.CK) {
            throw hs.fL();
        }
        byte[] bArr = this.buffer;
        int i = this.CL;
        this.CL = i + 1;
        return bArr[i];
    }

    public int fz() throws IOException {
        if (fH()) {
            this.CM = 0;
            return 0;
        }
        this.CM = fD();
        if (this.CM == 0) {
            throw hs.fO();
        }
        return this.CM;
    }

    public String readString() throws IOException {
        int fD = fD();
        if (fD > this.CK - this.CL || fD <= 0) {
            return new String(br(fD), "UTF-8");
        }
        String str = new String(this.buffer, this.CL, fD, "UTF-8");
        this.CL = fD + this.CL;
        return str;
    }
}
