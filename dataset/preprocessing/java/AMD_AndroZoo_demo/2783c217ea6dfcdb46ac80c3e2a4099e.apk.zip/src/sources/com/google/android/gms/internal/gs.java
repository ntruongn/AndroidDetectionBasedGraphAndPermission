package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class gs implements SafeParcelable {
    public static final gu CREATOR = new gu();
    private final String jD;
    private final int kZ;
    private final String[] zG;
    private final String[] zH;
    private final String[] zI;
    private final String zJ;
    private final String zK;
    private final String zL;
    private final String zM;

    /* JADX INFO: Access modifiers changed from: package-private */
    public gs(int i, String str, String[] strArr, String[] strArr2, String[] strArr3, String str2, String str3, String str4, String str5) {
        this.kZ = i;
        this.jD = str;
        this.zG = strArr;
        this.zH = strArr2;
        this.zI = strArr3;
        this.zJ = str2;
        this.zK = str3;
        this.zL = str4;
        this.zM = str5;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public gs(String str, String[] strArr, String[] strArr2, String[] strArr3, String str2, String str3, String str4) {
        this.kZ = 1;
        this.jD = str;
        this.zG = strArr;
        this.zH = strArr2;
        this.zI = strArr3;
        this.zJ = str2;
        this.zK = str3;
        this.zL = str4;
        this.zM = null;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String eA() {
        return this.zK;
    }

    public String eB() {
        return this.zL;
    }

    public String eC() {
        return this.zM;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof gs)) {
            return false;
        }
        gs gsVar = (gs) obj;
        return this.kZ == gsVar.kZ && ds.equal(this.jD, gsVar.jD) && ds.equal(this.zG, gsVar.zG) && ds.equal(this.zH, gsVar.zH) && ds.equal(this.zI, gsVar.zI) && ds.equal(this.zJ, gsVar.zJ) && ds.equal(this.zK, gsVar.zK) && ds.equal(this.zL, gsVar.zL) && ds.equal(this.zM, gsVar.zM);
    }

    public String[] ew() {
        return this.zG;
    }

    public String[] ex() {
        return this.zH;
    }

    public String[] ey() {
        return this.zI;
    }

    public String ez() {
        return this.zJ;
    }

    public String getAccountName() {
        return this.jD;
    }

    public int getVersionCode() {
        return this.kZ;
    }

    public int hashCode() {
        return ds.hashCode(Integer.valueOf(this.kZ), this.jD, this.zG, this.zH, this.zI, this.zJ, this.zK, this.zL, this.zM);
    }

    public String toString() {
        return ds.e(this).a("versionCode", Integer.valueOf(this.kZ)).a("accountName", this.jD).a("requestedScopes", this.zG).a("visibleActivities", this.zH).a("requiredFeatures", this.zI).a("packageNameForAuth", this.zJ).a("callingPackageName", this.zK).a("applicationName", this.zL).toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        gu.a(this, out, flags);
    }
}
