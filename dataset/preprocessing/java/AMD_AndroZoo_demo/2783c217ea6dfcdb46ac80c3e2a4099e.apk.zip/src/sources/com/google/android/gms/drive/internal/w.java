package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.drive.DriveId;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class w implements Parcelable.Creator<OpenContentsRequest> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(OpenContentsRequest openContentsRequest, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, openContentsRequest.kZ);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, (Parcelable) openContentsRequest.oF, i, false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 3, openContentsRequest.nU);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: H, reason: merged with bridge method [inline-methods] */
    public OpenContentsRequest createFromParcel(Parcel parcel) {
        int g;
        DriveId driveId;
        int i;
        int i2 = 0;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        DriveId driveId2 = null;
        int i3 = 0;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    int i4 = i2;
                    driveId = driveId2;
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    g = i4;
                    break;
                case 2:
                    DriveId driveId3 = (DriveId) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, DriveId.CREATOR);
                    i = i3;
                    g = i2;
                    driveId = driveId3;
                    break;
                case 3:
                    g = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    driveId = driveId2;
                    i = i3;
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    g = i2;
                    driveId = driveId2;
                    i = i3;
                    break;
            }
            i3 = i;
            driveId2 = driveId;
            i2 = g;
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new OpenContentsRequest(i3, driveId2, i2);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: Y, reason: merged with bridge method [inline-methods] */
    public OpenContentsRequest[] newArray(int i) {
        return new OpenContentsRequest[i];
    }
}
