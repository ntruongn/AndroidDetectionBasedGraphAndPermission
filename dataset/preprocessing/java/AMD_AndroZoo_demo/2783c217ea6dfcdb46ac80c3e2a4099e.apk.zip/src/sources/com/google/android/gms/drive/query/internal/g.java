package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class g implements Parcelable.Creator<NotFilter> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(NotFilter notFilter, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1000, notFilter.kZ);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 1, (Parcelable) notFilter.pq, i, false);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: S, reason: merged with bridge method [inline-methods] */
    public NotFilter createFromParcel(Parcel parcel) {
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        int i = 0;
        FilterHolder filterHolder = null;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    filterHolder = (FilterHolder) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, FilterHolder.CREATOR);
                    break;
                case 1000:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new NotFilter(i, filterHolder);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: aj, reason: merged with bridge method [inline-methods] */
    public NotFilter[] newArray(int i) {
        return new NotFilter[i];
    }
}
