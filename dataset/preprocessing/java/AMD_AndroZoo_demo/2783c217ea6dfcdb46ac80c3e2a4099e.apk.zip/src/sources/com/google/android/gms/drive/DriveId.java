package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.internal.q;
import com.google.android.gms.internal.du;
import com.google.android.gms.internal.hs;
import com.google.android.gms.internal.ht;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class DriveId implements SafeParcelable {
    public static final Parcelable.Creator<DriveId> CREATOR = new c();
    final int kZ;
    final String od;
    final long oe;
    final long of;
    private volatile String og;

    /* JADX INFO: Access modifiers changed from: package-private */
    public DriveId(int versionCode, String resourceId, long sqlId, long databaseInstanceId) {
        this.og = null;
        this.kZ = versionCode;
        this.od = resourceId;
        du.p(!"".equals(resourceId));
        this.oe = sqlId;
        this.of = databaseInstanceId;
    }

    public DriveId(String resourceId, long sqlId, long databaseInstanceId) {
        this(1, resourceId, sqlId, databaseInstanceId);
    }

    public static DriveId createFromResourceId(String resourceId) {
        du.f(resourceId);
        return new DriveId(resourceId, -1L, -1L);
    }

    static DriveId d(byte[] bArr) {
        try {
            q e = q.e(bArr);
            return new DriveId(e.versionCode, "".equals(e.oH) ? null : e.oH, e.oI, e.oJ);
        } catch (hs e2) {
            throw new IllegalArgumentException();
        }
    }

    public static DriveId decodeFromString(String s) {
        du.b(s.startsWith("DriveId:"), "Invalid DriveId: " + s);
        return d(Base64.decode(s.substring("DriveId:".length()), 10));
    }

    final byte[] cs() {
        q qVar = new q();
        qVar.versionCode = this.kZ;
        qVar.oH = this.od == null ? "" : this.od;
        qVar.oI = this.oe;
        qVar.oJ = this.of;
        return ht.a(qVar);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public final String encodeToString() {
        if (this.og == null) {
            this.og = "DriveId:" + Base64.encodeToString(cs(), 10);
        }
        return this.og;
    }

    public boolean equals(Object obj) {
        if (obj instanceof DriveId) {
            return encodeToString().equals(((DriveId) obj).encodeToString());
        }
        return false;
    }

    public String getResourceId() {
        return this.od;
    }

    public int hashCode() {
        return encodeToString().hashCode();
    }

    public String toString() {
        return encodeToString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        c.a(this, out, flags);
    }
}
