package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.internal.cd;
import com.google.android.gms.internal.dk;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class by extends dk<cd> {
    private final int hn;

    public by(Context context, GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener, int i) {
        super(context, connectionCallbacks, onConnectionFailedListener, new String[0]);
        this.hn = i;
    }

    @Override // com.google.android.gms.internal.dk
    protected void a(dq dqVar, dk.d dVar) throws RemoteException {
        dqVar.g(dVar, this.hn, getContext().getPackageName(), new Bundle());
    }

    @Override // com.google.android.gms.internal.dk
    protected String am() {
        return "com.google.android.gms.ads.service.START";
    }

    @Override // com.google.android.gms.internal.dk
    protected String an() {
        return "com.google.android.gms.ads.internal.request.IAdRequestService";
    }

    public cd ao() {
        return (cd) super.bC();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.internal.dk
    /* renamed from: o, reason: merged with bridge method [inline-methods] */
    public cd p(IBinder iBinder) {
        return cd.a.q(iBinder);
    }
}
