package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ee;
import com.google.android.gms.plus.PlusShare;
import com.google.android.gms.plus.model.people.Person;
import com.huprya.wqkqze112375.AdView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ha extends ee implements SafeParcelable, Person {
    public static final hb CREATOR = new hb();
    private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
    private String AP;
    private a AQ;
    private String AR;
    private String AS;
    private int AT;
    private b AU;
    private String AV;
    private c AW;
    private boolean AX;
    private String AY;
    private d AZ;
    private String Ba;
    private int Bb;
    private List<f> Bc;
    private List<g> Bd;
    private int Be;
    private int Bf;
    private String Bg;
    private List<h> Bh;
    private boolean Bi;
    private int eL;
    private String iD;
    private final int kZ;
    private String pW;
    private String wJ;
    private final Set<Integer> zQ;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a extends ee implements SafeParcelable, Person.AgeRange {
        public static final hc CREATOR = new hc();
        private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
        private int Bj;
        private int Bk;
        private final int kZ;
        private final Set<Integer> zQ;

        static {
            zP.put("max", ee.a.c("max", 2));
            zP.put("min", ee.a.c("min", 3));
        }

        public a() {
            this.kZ = 1;
            this.zQ = new HashSet();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public a(Set<Integer> set, int i, int i2, int i3) {
            this.zQ = set;
            this.kZ = i;
            this.Bj = i2;
            this.Bk = i3;
        }

        @Override // com.google.android.gms.internal.ee
        protected Object J(String str) {
            return null;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean K(String str) {
            return false;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean a(ee.a aVar) {
            return this.zQ.contains(Integer.valueOf(aVar.bX()));
        }

        @Override // com.google.android.gms.internal.ee
        protected Object b(ee.a aVar) {
            switch (aVar.bX()) {
                case 2:
                    return Integer.valueOf(this.Bj);
                case 3:
                    return Integer.valueOf(this.Bk);
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            }
        }

        @Override // com.google.android.gms.internal.ee
        public HashMap<String, ee.a<?, ?>> bQ() {
            return zP;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            hc hcVar = CREATOR;
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public Set<Integer> eF() {
            return this.zQ;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof a)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            a aVar = (a) obj;
            for (ee.a<?, ?> aVar2 : zP.values()) {
                if (a(aVar2)) {
                    if (aVar.a(aVar2) && b(aVar2).equals(aVar.b(aVar2))) {
                    }
                    return false;
                }
                if (aVar.a(aVar2)) {
                    return false;
                }
            }
            return true;
        }

        @Override // com.google.android.gms.common.data.Freezable
        /* renamed from: fi, reason: merged with bridge method [inline-methods] */
        public a freeze() {
            return this;
        }

        @Override // com.google.android.gms.plus.model.people.Person.AgeRange
        public int getMax() {
            return this.Bj;
        }

        @Override // com.google.android.gms.plus.model.people.Person.AgeRange
        public int getMin() {
            return this.Bk;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public int getVersionCode() {
            return this.kZ;
        }

        @Override // com.google.android.gms.plus.model.people.Person.AgeRange
        public boolean hasMax() {
            return this.zQ.contains(2);
        }

        @Override // com.google.android.gms.plus.model.people.Person.AgeRange
        public boolean hasMin() {
            return this.zQ.contains(3);
        }

        public int hashCode() {
            int i = 0;
            Iterator<ee.a<?, ?>> it = zP.values().iterator();
            while (true) {
                int i2 = i;
                if (!it.hasNext()) {
                    return i2;
                }
                ee.a<?, ?> next = it.next();
                if (a(next)) {
                    i = b(next).hashCode() + i2 + next.bX();
                } else {
                    i = i2;
                }
            }
        }

        @Override // com.google.android.gms.common.data.Freezable
        public boolean isDataValid() {
            return true;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            hc hcVar = CREATOR;
            hc.a(this, out, flags);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class b extends ee implements SafeParcelable, Person.Cover {
        public static final hd CREATOR = new hd();
        private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
        private a Bl;
        private C0041b Bm;
        private int Bn;
        private final int kZ;
        private final Set<Integer> zQ;

        /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
        public static final class a extends ee implements SafeParcelable, Person.Cover.CoverInfo {
            public static final he CREATOR = new he();
            private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
            private int Bo;
            private int Bp;
            private final int kZ;
            private final Set<Integer> zQ;

            static {
                zP.put("leftImageOffset", ee.a.c("leftImageOffset", 2));
                zP.put("topImageOffset", ee.a.c("topImageOffset", 3));
            }

            public a() {
                this.kZ = 1;
                this.zQ = new HashSet();
            }

            /* JADX INFO: Access modifiers changed from: package-private */
            public a(Set<Integer> set, int i, int i2, int i3) {
                this.zQ = set;
                this.kZ = i;
                this.Bo = i2;
                this.Bp = i3;
            }

            @Override // com.google.android.gms.internal.ee
            protected Object J(String str) {
                return null;
            }

            @Override // com.google.android.gms.internal.ee
            protected boolean K(String str) {
                return false;
            }

            @Override // com.google.android.gms.internal.ee
            protected boolean a(ee.a aVar) {
                return this.zQ.contains(Integer.valueOf(aVar.bX()));
            }

            @Override // com.google.android.gms.internal.ee
            protected Object b(ee.a aVar) {
                switch (aVar.bX()) {
                    case 2:
                        return Integer.valueOf(this.Bo);
                    case 3:
                        return Integer.valueOf(this.Bp);
                    default:
                        throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
                }
            }

            @Override // com.google.android.gms.internal.ee
            public HashMap<String, ee.a<?, ?>> bQ() {
                return zP;
            }

            @Override // android.os.Parcelable
            public int describeContents() {
                he heVar = CREATOR;
                return 0;
            }

            /* JADX INFO: Access modifiers changed from: package-private */
            public Set<Integer> eF() {
                return this.zQ;
            }

            public boolean equals(Object obj) {
                if (!(obj instanceof a)) {
                    return false;
                }
                if (this == obj) {
                    return true;
                }
                a aVar = (a) obj;
                for (ee.a<?, ?> aVar2 : zP.values()) {
                    if (a(aVar2)) {
                        if (aVar.a(aVar2) && b(aVar2).equals(aVar.b(aVar2))) {
                        }
                        return false;
                    }
                    if (aVar.a(aVar2)) {
                        return false;
                    }
                }
                return true;
            }

            @Override // com.google.android.gms.common.data.Freezable
            /* renamed from: fm, reason: merged with bridge method [inline-methods] */
            public a freeze() {
                return this;
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverInfo
            public int getLeftImageOffset() {
                return this.Bo;
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverInfo
            public int getTopImageOffset() {
                return this.Bp;
            }

            /* JADX INFO: Access modifiers changed from: package-private */
            public int getVersionCode() {
                return this.kZ;
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverInfo
            public boolean hasLeftImageOffset() {
                return this.zQ.contains(2);
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverInfo
            public boolean hasTopImageOffset() {
                return this.zQ.contains(3);
            }

            public int hashCode() {
                int i = 0;
                Iterator<ee.a<?, ?>> it = zP.values().iterator();
                while (true) {
                    int i2 = i;
                    if (!it.hasNext()) {
                        return i2;
                    }
                    ee.a<?, ?> next = it.next();
                    if (a(next)) {
                        i = b(next).hashCode() + i2 + next.bX();
                    } else {
                        i = i2;
                    }
                }
            }

            @Override // com.google.android.gms.common.data.Freezable
            public boolean isDataValid() {
                return true;
            }

            @Override // android.os.Parcelable
            public void writeToParcel(Parcel out, int flags) {
                he heVar = CREATOR;
                he.a(this, out, flags);
            }
        }

        /* renamed from: com.google.android.gms.internal.ha$b$b, reason: collision with other inner class name */
        /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
        public static final class C0041b extends ee implements SafeParcelable, Person.Cover.CoverPhoto {
            public static final hf CREATOR = new hf();
            private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
            private String iD;
            private final int kZ;
            private int v;
            private int w;
            private final Set<Integer> zQ;

            static {
                zP.put("height", ee.a.c("height", 2));
                zP.put(PlusShare.KEY_CALL_TO_ACTION_URL, ee.a.f(PlusShare.KEY_CALL_TO_ACTION_URL, 3));
                zP.put("width", ee.a.c("width", 4));
            }

            public C0041b() {
                this.kZ = 1;
                this.zQ = new HashSet();
            }

            /* JADX INFO: Access modifiers changed from: package-private */
            public C0041b(Set<Integer> set, int i, int i2, String str, int i3) {
                this.zQ = set;
                this.kZ = i;
                this.v = i2;
                this.iD = str;
                this.w = i3;
            }

            @Override // com.google.android.gms.internal.ee
            protected Object J(String str) {
                return null;
            }

            @Override // com.google.android.gms.internal.ee
            protected boolean K(String str) {
                return false;
            }

            @Override // com.google.android.gms.internal.ee
            protected boolean a(ee.a aVar) {
                return this.zQ.contains(Integer.valueOf(aVar.bX()));
            }

            @Override // com.google.android.gms.internal.ee
            protected Object b(ee.a aVar) {
                switch (aVar.bX()) {
                    case 2:
                        return Integer.valueOf(this.v);
                    case 3:
                        return this.iD;
                    case 4:
                        return Integer.valueOf(this.w);
                    default:
                        throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
                }
            }

            @Override // com.google.android.gms.internal.ee
            public HashMap<String, ee.a<?, ?>> bQ() {
                return zP;
            }

            @Override // android.os.Parcelable
            public int describeContents() {
                hf hfVar = CREATOR;
                return 0;
            }

            /* JADX INFO: Access modifiers changed from: package-private */
            public Set<Integer> eF() {
                return this.zQ;
            }

            public boolean equals(Object obj) {
                if (!(obj instanceof C0041b)) {
                    return false;
                }
                if (this == obj) {
                    return true;
                }
                C0041b c0041b = (C0041b) obj;
                for (ee.a<?, ?> aVar : zP.values()) {
                    if (a(aVar)) {
                        if (c0041b.a(aVar) && b(aVar).equals(c0041b.b(aVar))) {
                        }
                        return false;
                    }
                    if (c0041b.a(aVar)) {
                        return false;
                    }
                }
                return true;
            }

            @Override // com.google.android.gms.common.data.Freezable
            /* renamed from: fn, reason: merged with bridge method [inline-methods] */
            public C0041b freeze() {
                return this;
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverPhoto
            public int getHeight() {
                return this.v;
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverPhoto
            public String getUrl() {
                return this.iD;
            }

            /* JADX INFO: Access modifiers changed from: package-private */
            public int getVersionCode() {
                return this.kZ;
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverPhoto
            public int getWidth() {
                return this.w;
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverPhoto
            public boolean hasHeight() {
                return this.zQ.contains(2);
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverPhoto
            public boolean hasUrl() {
                return this.zQ.contains(3);
            }

            @Override // com.google.android.gms.plus.model.people.Person.Cover.CoverPhoto
            public boolean hasWidth() {
                return this.zQ.contains(4);
            }

            public int hashCode() {
                int i = 0;
                Iterator<ee.a<?, ?>> it = zP.values().iterator();
                while (true) {
                    int i2 = i;
                    if (!it.hasNext()) {
                        return i2;
                    }
                    ee.a<?, ?> next = it.next();
                    if (a(next)) {
                        i = b(next).hashCode() + i2 + next.bX();
                    } else {
                        i = i2;
                    }
                }
            }

            @Override // com.google.android.gms.common.data.Freezable
            public boolean isDataValid() {
                return true;
            }

            @Override // android.os.Parcelable
            public void writeToParcel(Parcel out, int flags) {
                hf hfVar = CREATOR;
                hf.a(this, out, flags);
            }
        }

        static {
            zP.put("coverInfo", ee.a.a("coverInfo", 2, a.class));
            zP.put("coverPhoto", ee.a.a("coverPhoto", 3, C0041b.class));
            zP.put("layout", ee.a.a("layout", 4, new eb().b("banner", 0), false));
        }

        public b() {
            this.kZ = 1;
            this.zQ = new HashSet();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public b(Set<Integer> set, int i, a aVar, C0041b c0041b, int i2) {
            this.zQ = set;
            this.kZ = i;
            this.Bl = aVar;
            this.Bm = c0041b;
            this.Bn = i2;
        }

        @Override // com.google.android.gms.internal.ee
        protected Object J(String str) {
            return null;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean K(String str) {
            return false;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean a(ee.a aVar) {
            return this.zQ.contains(Integer.valueOf(aVar.bX()));
        }

        @Override // com.google.android.gms.internal.ee
        protected Object b(ee.a aVar) {
            switch (aVar.bX()) {
                case 2:
                    return this.Bl;
                case 3:
                    return this.Bm;
                case 4:
                    return Integer.valueOf(this.Bn);
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            }
        }

        @Override // com.google.android.gms.internal.ee
        public HashMap<String, ee.a<?, ?>> bQ() {
            return zP;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            hd hdVar = CREATOR;
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public Set<Integer> eF() {
            return this.zQ;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof b)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            b bVar = (b) obj;
            for (ee.a<?, ?> aVar : zP.values()) {
                if (a(aVar)) {
                    if (bVar.a(aVar) && b(aVar).equals(bVar.b(aVar))) {
                    }
                    return false;
                }
                if (bVar.a(aVar)) {
                    return false;
                }
            }
            return true;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public a fj() {
            return this.Bl;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public C0041b fk() {
            return this.Bm;
        }

        @Override // com.google.android.gms.common.data.Freezable
        /* renamed from: fl, reason: merged with bridge method [inline-methods] */
        public b freeze() {
            return this;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Cover
        public Person.Cover.CoverInfo getCoverInfo() {
            return this.Bl;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Cover
        public Person.Cover.CoverPhoto getCoverPhoto() {
            return this.Bm;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Cover
        public int getLayout() {
            return this.Bn;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public int getVersionCode() {
            return this.kZ;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Cover
        public boolean hasCoverInfo() {
            return this.zQ.contains(2);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Cover
        public boolean hasCoverPhoto() {
            return this.zQ.contains(3);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Cover
        public boolean hasLayout() {
            return this.zQ.contains(4);
        }

        public int hashCode() {
            int i = 0;
            Iterator<ee.a<?, ?>> it = zP.values().iterator();
            while (true) {
                int i2 = i;
                if (!it.hasNext()) {
                    return i2;
                }
                ee.a<?, ?> next = it.next();
                if (a(next)) {
                    i = b(next).hashCode() + i2 + next.bX();
                } else {
                    i = i2;
                }
            }
        }

        @Override // com.google.android.gms.common.data.Freezable
        public boolean isDataValid() {
            return true;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            hd hdVar = CREATOR;
            hd.a(this, out, flags);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class c extends ee implements SafeParcelable, Person.Image {
        public static final hg CREATOR = new hg();
        private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
        private String iD;
        private final int kZ;
        private final Set<Integer> zQ;

        static {
            zP.put(PlusShare.KEY_CALL_TO_ACTION_URL, ee.a.f(PlusShare.KEY_CALL_TO_ACTION_URL, 2));
        }

        public c() {
            this.kZ = 1;
            this.zQ = new HashSet();
        }

        public c(String str) {
            this.zQ = new HashSet();
            this.kZ = 1;
            this.iD = str;
            this.zQ.add(2);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public c(Set<Integer> set, int i, String str) {
            this.zQ = set;
            this.kZ = i;
            this.iD = str;
        }

        @Override // com.google.android.gms.internal.ee
        protected Object J(String str) {
            return null;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean K(String str) {
            return false;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean a(ee.a aVar) {
            return this.zQ.contains(Integer.valueOf(aVar.bX()));
        }

        @Override // com.google.android.gms.internal.ee
        protected Object b(ee.a aVar) {
            switch (aVar.bX()) {
                case 2:
                    return this.iD;
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            }
        }

        @Override // com.google.android.gms.internal.ee
        public HashMap<String, ee.a<?, ?>> bQ() {
            return zP;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            hg hgVar = CREATOR;
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public Set<Integer> eF() {
            return this.zQ;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof c)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            c cVar = (c) obj;
            for (ee.a<?, ?> aVar : zP.values()) {
                if (a(aVar)) {
                    if (cVar.a(aVar) && b(aVar).equals(cVar.b(aVar))) {
                    }
                    return false;
                }
                if (cVar.a(aVar)) {
                    return false;
                }
            }
            return true;
        }

        @Override // com.google.android.gms.common.data.Freezable
        /* renamed from: fo, reason: merged with bridge method [inline-methods] */
        public c freeze() {
            return this;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Image
        public String getUrl() {
            return this.iD;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public int getVersionCode() {
            return this.kZ;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Image
        public boolean hasUrl() {
            return this.zQ.contains(2);
        }

        public int hashCode() {
            int i = 0;
            Iterator<ee.a<?, ?>> it = zP.values().iterator();
            while (true) {
                int i2 = i;
                if (!it.hasNext()) {
                    return i2;
                }
                ee.a<?, ?> next = it.next();
                if (a(next)) {
                    i = b(next).hashCode() + i2 + next.bX();
                } else {
                    i = i2;
                }
            }
        }

        @Override // com.google.android.gms.common.data.Freezable
        public boolean isDataValid() {
            return true;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            hg hgVar = CREATOR;
            hg.a(this, out, flags);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class d extends ee implements SafeParcelable, Person.Name {
        public static final hh CREATOR = new hh();
        private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
        private String Ap;
        private String As;
        private String Bq;
        private String Br;
        private String Bs;
        private String Bt;
        private final int kZ;
        private final Set<Integer> zQ;

        static {
            zP.put("familyName", ee.a.f("familyName", 2));
            zP.put("formatted", ee.a.f("formatted", 3));
            zP.put("givenName", ee.a.f("givenName", 4));
            zP.put("honorificPrefix", ee.a.f("honorificPrefix", 5));
            zP.put("honorificSuffix", ee.a.f("honorificSuffix", 6));
            zP.put("middleName", ee.a.f("middleName", 7));
        }

        public d() {
            this.kZ = 1;
            this.zQ = new HashSet();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public d(Set<Integer> set, int i, String str, String str2, String str3, String str4, String str5, String str6) {
            this.zQ = set;
            this.kZ = i;
            this.Ap = str;
            this.Bq = str2;
            this.As = str3;
            this.Br = str4;
            this.Bs = str5;
            this.Bt = str6;
        }

        @Override // com.google.android.gms.internal.ee
        protected Object J(String str) {
            return null;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean K(String str) {
            return false;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean a(ee.a aVar) {
            return this.zQ.contains(Integer.valueOf(aVar.bX()));
        }

        @Override // com.google.android.gms.internal.ee
        protected Object b(ee.a aVar) {
            switch (aVar.bX()) {
                case 2:
                    return this.Ap;
                case 3:
                    return this.Bq;
                case 4:
                    return this.As;
                case 5:
                    return this.Br;
                case 6:
                    return this.Bs;
                case 7:
                    return this.Bt;
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            }
        }

        @Override // com.google.android.gms.internal.ee
        public HashMap<String, ee.a<?, ?>> bQ() {
            return zP;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            hh hhVar = CREATOR;
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public Set<Integer> eF() {
            return this.zQ;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof d)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            d dVar = (d) obj;
            for (ee.a<?, ?> aVar : zP.values()) {
                if (a(aVar)) {
                    if (dVar.a(aVar) && b(aVar).equals(dVar.b(aVar))) {
                    }
                    return false;
                }
                if (dVar.a(aVar)) {
                    return false;
                }
            }
            return true;
        }

        @Override // com.google.android.gms.common.data.Freezable
        /* renamed from: fp, reason: merged with bridge method [inline-methods] */
        public d freeze() {
            return this;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public String getFamilyName() {
            return this.Ap;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public String getFormatted() {
            return this.Bq;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public String getGivenName() {
            return this.As;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public String getHonorificPrefix() {
            return this.Br;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public String getHonorificSuffix() {
            return this.Bs;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public String getMiddleName() {
            return this.Bt;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public int getVersionCode() {
            return this.kZ;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public boolean hasFamilyName() {
            return this.zQ.contains(2);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public boolean hasFormatted() {
            return this.zQ.contains(3);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public boolean hasGivenName() {
            return this.zQ.contains(4);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public boolean hasHonorificPrefix() {
            return this.zQ.contains(5);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public boolean hasHonorificSuffix() {
            return this.zQ.contains(6);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Name
        public boolean hasMiddleName() {
            return this.zQ.contains(7);
        }

        public int hashCode() {
            int i = 0;
            Iterator<ee.a<?, ?>> it = zP.values().iterator();
            while (true) {
                int i2 = i;
                if (!it.hasNext()) {
                    return i2;
                }
                ee.a<?, ?> next = it.next();
                if (a(next)) {
                    i = b(next).hashCode() + i2 + next.bX();
                } else {
                    i = i2;
                }
            }
        }

        @Override // com.google.android.gms.common.data.Freezable
        public boolean isDataValid() {
            return true;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            hh hhVar = CREATOR;
            hh.a(this, out, flags);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static class e {
        public static int al(String str) {
            if (str.equals("person")) {
                return 0;
            }
            if (str.equals("page")) {
                return 1;
            }
            throw new IllegalArgumentException("Unknown objectType string: " + str);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class f extends ee implements SafeParcelable, Person.Organizations {
        public static final hi CREATOR = new hi();
        private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
        private String AE;
        private String Ao;
        private String Bu;
        private String Bv;
        private boolean Bw;
        private final int kZ;
        private int lP;
        private String mName;
        private String oa;
        private String pZ;
        private final Set<Integer> zQ;

        static {
            zP.put("department", ee.a.f("department", 2));
            zP.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, ee.a.f(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, 3));
            zP.put("endDate", ee.a.f("endDate", 4));
            zP.put("location", ee.a.f("location", 5));
            zP.put("name", ee.a.f("name", 6));
            zP.put("primary", ee.a.e("primary", 7));
            zP.put("startDate", ee.a.f("startDate", 8));
            zP.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, ee.a.f(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, 9));
            zP.put("type", ee.a.a("type", 10, new eb().b("work", 0).b("school", 1), false));
        }

        public f() {
            this.kZ = 1;
            this.zQ = new HashSet();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public f(Set<Integer> set, int i, String str, String str2, String str3, String str4, String str5, boolean z, String str6, String str7, int i2) {
            this.zQ = set;
            this.kZ = i;
            this.Bu = str;
            this.pZ = str2;
            this.Ao = str3;
            this.Bv = str4;
            this.mName = str5;
            this.Bw = z;
            this.AE = str6;
            this.oa = str7;
            this.lP = i2;
        }

        @Override // com.google.android.gms.internal.ee
        protected Object J(String str) {
            return null;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean K(String str) {
            return false;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean a(ee.a aVar) {
            return this.zQ.contains(Integer.valueOf(aVar.bX()));
        }

        @Override // com.google.android.gms.internal.ee
        protected Object b(ee.a aVar) {
            switch (aVar.bX()) {
                case 2:
                    return this.Bu;
                case 3:
                    return this.pZ;
                case 4:
                    return this.Ao;
                case 5:
                    return this.Bv;
                case 6:
                    return this.mName;
                case 7:
                    return Boolean.valueOf(this.Bw);
                case 8:
                    return this.AE;
                case 9:
                    return this.oa;
                case 10:
                    return Integer.valueOf(this.lP);
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            }
        }

        @Override // com.google.android.gms.internal.ee
        public HashMap<String, ee.a<?, ?>> bQ() {
            return zP;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            hi hiVar = CREATOR;
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public Set<Integer> eF() {
            return this.zQ;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof f)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            f fVar = (f) obj;
            for (ee.a<?, ?> aVar : zP.values()) {
                if (a(aVar)) {
                    if (fVar.a(aVar) && b(aVar).equals(fVar.b(aVar))) {
                    }
                    return false;
                }
                if (fVar.a(aVar)) {
                    return false;
                }
            }
            return true;
        }

        @Override // com.google.android.gms.common.data.Freezable
        /* renamed from: fq, reason: merged with bridge method [inline-methods] */
        public f freeze() {
            return this;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public String getDepartment() {
            return this.Bu;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public String getDescription() {
            return this.pZ;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public String getEndDate() {
            return this.Ao;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public String getLocation() {
            return this.Bv;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public String getName() {
            return this.mName;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public String getStartDate() {
            return this.AE;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public String getTitle() {
            return this.oa;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public int getType() {
            return this.lP;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public int getVersionCode() {
            return this.kZ;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean hasDepartment() {
            return this.zQ.contains(2);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean hasDescription() {
            return this.zQ.contains(3);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean hasEndDate() {
            return this.zQ.contains(4);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean hasLocation() {
            return this.zQ.contains(5);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean hasName() {
            return this.zQ.contains(6);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean hasPrimary() {
            return this.zQ.contains(7);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean hasStartDate() {
            return this.zQ.contains(8);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean hasTitle() {
            return this.zQ.contains(9);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean hasType() {
            return this.zQ.contains(10);
        }

        public int hashCode() {
            int i = 0;
            Iterator<ee.a<?, ?>> it = zP.values().iterator();
            while (true) {
                int i2 = i;
                if (!it.hasNext()) {
                    return i2;
                }
                ee.a<?, ?> next = it.next();
                if (a(next)) {
                    i = b(next).hashCode() + i2 + next.bX();
                } else {
                    i = i2;
                }
            }
        }

        @Override // com.google.android.gms.common.data.Freezable
        public boolean isDataValid() {
            return true;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Organizations
        public boolean isPrimary() {
            return this.Bw;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            hi hiVar = CREATOR;
            hi.a(this, out, flags);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class g extends ee implements SafeParcelable, Person.PlacesLived {
        public static final hj CREATOR = new hj();
        private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
        private boolean Bw;
        private final int kZ;
        private String mValue;
        private final Set<Integer> zQ;

        static {
            zP.put("primary", ee.a.e("primary", 2));
            zP.put("value", ee.a.f("value", 3));
        }

        public g() {
            this.kZ = 1;
            this.zQ = new HashSet();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public g(Set<Integer> set, int i, boolean z, String str) {
            this.zQ = set;
            this.kZ = i;
            this.Bw = z;
            this.mValue = str;
        }

        @Override // com.google.android.gms.internal.ee
        protected Object J(String str) {
            return null;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean K(String str) {
            return false;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean a(ee.a aVar) {
            return this.zQ.contains(Integer.valueOf(aVar.bX()));
        }

        @Override // com.google.android.gms.internal.ee
        protected Object b(ee.a aVar) {
            switch (aVar.bX()) {
                case 2:
                    return Boolean.valueOf(this.Bw);
                case 3:
                    return this.mValue;
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            }
        }

        @Override // com.google.android.gms.internal.ee
        public HashMap<String, ee.a<?, ?>> bQ() {
            return zP;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            hj hjVar = CREATOR;
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public Set<Integer> eF() {
            return this.zQ;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof g)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            g gVar = (g) obj;
            for (ee.a<?, ?> aVar : zP.values()) {
                if (a(aVar)) {
                    if (gVar.a(aVar) && b(aVar).equals(gVar.b(aVar))) {
                    }
                    return false;
                }
                if (gVar.a(aVar)) {
                    return false;
                }
            }
            return true;
        }

        @Override // com.google.android.gms.common.data.Freezable
        /* renamed from: fr, reason: merged with bridge method [inline-methods] */
        public g freeze() {
            return this;
        }

        @Override // com.google.android.gms.plus.model.people.Person.PlacesLived
        public String getValue() {
            return this.mValue;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public int getVersionCode() {
            return this.kZ;
        }

        @Override // com.google.android.gms.plus.model.people.Person.PlacesLived
        public boolean hasPrimary() {
            return this.zQ.contains(2);
        }

        @Override // com.google.android.gms.plus.model.people.Person.PlacesLived
        public boolean hasValue() {
            return this.zQ.contains(3);
        }

        public int hashCode() {
            int i = 0;
            Iterator<ee.a<?, ?>> it = zP.values().iterator();
            while (true) {
                int i2 = i;
                if (!it.hasNext()) {
                    return i2;
                }
                ee.a<?, ?> next = it.next();
                if (a(next)) {
                    i = b(next).hashCode() + i2 + next.bX();
                } else {
                    i = i2;
                }
            }
        }

        @Override // com.google.android.gms.common.data.Freezable
        public boolean isDataValid() {
            return true;
        }

        @Override // com.google.android.gms.plus.model.people.Person.PlacesLived
        public boolean isPrimary() {
            return this.Bw;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            hj hjVar = CREATOR;
            hj.a(this, out, flags);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class h extends ee implements SafeParcelable, Person.Urls {
        public static final hk CREATOR = new hk();
        private static final HashMap<String, ee.a<?, ?>> zP = new HashMap<>();
        private String Bx;
        private final int By;
        private final int kZ;
        private int lP;
        private String mValue;
        private final Set<Integer> zQ;

        static {
            zP.put(PlusShare.KEY_CALL_TO_ACTION_LABEL, ee.a.f(PlusShare.KEY_CALL_TO_ACTION_LABEL, 5));
            zP.put("type", ee.a.a("type", 6, new eb().b("home", 0).b("work", 1).b("blog", 2).b("profile", 3).b("other", 4).b("otherProfile", 5).b("contributor", 6).b("website", 7), false));
            zP.put("value", ee.a.f("value", 4));
        }

        public h() {
            this.By = 4;
            this.kZ = 2;
            this.zQ = new HashSet();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public h(Set<Integer> set, int i, String str, int i2, String str2, int i3) {
            this.By = 4;
            this.zQ = set;
            this.kZ = i;
            this.Bx = str;
            this.lP = i2;
            this.mValue = str2;
        }

        @Override // com.google.android.gms.internal.ee
        protected Object J(String str) {
            return null;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean K(String str) {
            return false;
        }

        @Override // com.google.android.gms.internal.ee
        protected boolean a(ee.a aVar) {
            return this.zQ.contains(Integer.valueOf(aVar.bX()));
        }

        @Override // com.google.android.gms.internal.ee
        protected Object b(ee.a aVar) {
            switch (aVar.bX()) {
                case 4:
                    return this.mValue;
                case 5:
                    return this.Bx;
                case 6:
                    return Integer.valueOf(this.lP);
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            }
        }

        @Override // com.google.android.gms.internal.ee
        public HashMap<String, ee.a<?, ?>> bQ() {
            return zP;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            hk hkVar = CREATOR;
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public Set<Integer> eF() {
            return this.zQ;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof h)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            h hVar = (h) obj;
            for (ee.a<?, ?> aVar : zP.values()) {
                if (a(aVar)) {
                    if (hVar.a(aVar) && b(aVar).equals(hVar.b(aVar))) {
                    }
                    return false;
                }
                if (hVar.a(aVar)) {
                    return false;
                }
            }
            return true;
        }

        @Deprecated
        public int fs() {
            return 4;
        }

        @Override // com.google.android.gms.common.data.Freezable
        /* renamed from: ft, reason: merged with bridge method [inline-methods] */
        public h freeze() {
            return this;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Urls
        public String getLabel() {
            return this.Bx;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Urls
        public int getType() {
            return this.lP;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Urls
        public String getValue() {
            return this.mValue;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public int getVersionCode() {
            return this.kZ;
        }

        @Override // com.google.android.gms.plus.model.people.Person.Urls
        public boolean hasLabel() {
            return this.zQ.contains(5);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Urls
        public boolean hasType() {
            return this.zQ.contains(6);
        }

        @Override // com.google.android.gms.plus.model.people.Person.Urls
        public boolean hasValue() {
            return this.zQ.contains(4);
        }

        public int hashCode() {
            int i = 0;
            Iterator<ee.a<?, ?>> it = zP.values().iterator();
            while (true) {
                int i2 = i;
                if (!it.hasNext()) {
                    return i2;
                }
                ee.a<?, ?> next = it.next();
                if (a(next)) {
                    i = b(next).hashCode() + i2 + next.bX();
                } else {
                    i = i2;
                }
            }
        }

        @Override // com.google.android.gms.common.data.Freezable
        public boolean isDataValid() {
            return true;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            hk hkVar = CREATOR;
            hk.a(this, out, flags);
        }
    }

    static {
        zP.put("aboutMe", ee.a.f("aboutMe", 2));
        zP.put("ageRange", ee.a.a("ageRange", 3, a.class));
        zP.put("birthday", ee.a.f("birthday", 4));
        zP.put("braggingRights", ee.a.f("braggingRights", 5));
        zP.put("circledByCount", ee.a.c("circledByCount", 6));
        zP.put("cover", ee.a.a("cover", 7, b.class));
        zP.put("currentLocation", ee.a.f("currentLocation", 8));
        zP.put("displayName", ee.a.f("displayName", 9));
        zP.put("gender", ee.a.a("gender", 12, new eb().b("male", 0).b("female", 1).b("other", 2), false));
        zP.put(com.huprya.wqkqze112375.j.ID, ee.a.f(com.huprya.wqkqze112375.j.ID, 14));
        zP.put(AdView.BANNER_TYPE_IMAGE, ee.a.a(AdView.BANNER_TYPE_IMAGE, 15, c.class));
        zP.put("isPlusUser", ee.a.e("isPlusUser", 16));
        zP.put(com.huprya.wqkqze112375.g.LANGUAGE, ee.a.f(com.huprya.wqkqze112375.g.LANGUAGE, 18));
        zP.put("name", ee.a.a("name", 19, d.class));
        zP.put("nickname", ee.a.f("nickname", 20));
        zP.put("objectType", ee.a.a("objectType", 21, new eb().b("person", 0).b("page", 1), false));
        zP.put("organizations", ee.a.b("organizations", 22, f.class));
        zP.put("placesLived", ee.a.b("placesLived", 23, g.class));
        zP.put("plusOneCount", ee.a.c("plusOneCount", 24));
        zP.put("relationshipStatus", ee.a.a("relationshipStatus", 25, new eb().b("single", 0).b("in_a_relationship", 1).b("engaged", 2).b("married", 3).b("its_complicated", 4).b("open_relationship", 5).b("widowed", 6).b("in_domestic_partnership", 7).b("in_civil_union", 8), false));
        zP.put("tagline", ee.a.f("tagline", 26));
        zP.put(PlusShare.KEY_CALL_TO_ACTION_URL, ee.a.f(PlusShare.KEY_CALL_TO_ACTION_URL, 27));
        zP.put("urls", ee.a.b("urls", 28, h.class));
        zP.put("verified", ee.a.e("verified", 29));
    }

    public ha() {
        this.kZ = 2;
        this.zQ = new HashSet();
    }

    public ha(String str, String str2, c cVar, int i, String str3) {
        this.kZ = 2;
        this.zQ = new HashSet();
        this.pW = str;
        this.zQ.add(9);
        this.wJ = str2;
        this.zQ.add(14);
        this.AW = cVar;
        this.zQ.add(15);
        this.Bb = i;
        this.zQ.add(21);
        this.iD = str3;
        this.zQ.add(27);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ha(Set<Integer> set, int i, String str, a aVar, String str2, String str3, int i2, b bVar, String str4, String str5, int i3, String str6, c cVar, boolean z, String str7, d dVar, String str8, int i4, List<f> list, List<g> list2, int i5, int i6, String str9, String str10, List<h> list3, boolean z2) {
        this.zQ = set;
        this.kZ = i;
        this.AP = str;
        this.AQ = aVar;
        this.AR = str2;
        this.AS = str3;
        this.AT = i2;
        this.AU = bVar;
        this.AV = str4;
        this.pW = str5;
        this.eL = i3;
        this.wJ = str6;
        this.AW = cVar;
        this.AX = z;
        this.AY = str7;
        this.AZ = dVar;
        this.Ba = str8;
        this.Bb = i4;
        this.Bc = list;
        this.Bd = list2;
        this.Be = i5;
        this.Bf = i6;
        this.Bg = str9;
        this.iD = str10;
        this.Bh = list3;
        this.Bi = z2;
    }

    public static ha g(byte[] bArr) {
        Parcel obtain = Parcel.obtain();
        obtain.unmarshall(bArr, 0, bArr.length);
        obtain.setDataPosition(0);
        ha createFromParcel = CREATOR.createFromParcel(obtain);
        obtain.recycle();
        return createFromParcel;
    }

    @Override // com.google.android.gms.internal.ee
    protected Object J(String str) {
        return null;
    }

    @Override // com.google.android.gms.internal.ee
    protected boolean K(String str) {
        return false;
    }

    @Override // com.google.android.gms.internal.ee
    protected boolean a(ee.a aVar) {
        return this.zQ.contains(Integer.valueOf(aVar.bX()));
    }

    @Override // com.google.android.gms.internal.ee
    protected Object b(ee.a aVar) {
        switch (aVar.bX()) {
            case 2:
                return this.AP;
            case 3:
                return this.AQ;
            case 4:
                return this.AR;
            case 5:
                return this.AS;
            case 6:
                return Integer.valueOf(this.AT);
            case 7:
                return this.AU;
            case 8:
                return this.AV;
            case 9:
                return this.pW;
            case 10:
            case 11:
            case 13:
            case 17:
            default:
                throw new IllegalStateException("Unknown safe parcelable id=" + aVar.bX());
            case 12:
                return Integer.valueOf(this.eL);
            case Status.INTERRUPTED /* 14 */:
                return this.wJ;
            case Status.TIMEOUT /* 15 */:
                return this.AW;
            case 16:
                return Boolean.valueOf(this.AX);
            case 18:
                return this.AY;
            case 19:
                return this.AZ;
            case 20:
                return this.Ba;
            case 21:
                return Integer.valueOf(this.Bb);
            case 22:
                return this.Bc;
            case 23:
                return this.Bd;
            case 24:
                return Integer.valueOf(this.Be);
            case 25:
                return Integer.valueOf(this.Bf);
            case 26:
                return this.Bg;
            case 27:
                return this.iD;
            case 28:
                return this.Bh;
            case 29:
                return Boolean.valueOf(this.Bi);
        }
    }

    @Override // com.google.android.gms.internal.ee
    public HashMap<String, ee.a<?, ?>> bQ() {
        return zP;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        hb hbVar = CREATOR;
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Set<Integer> eF() {
        return this.zQ;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof ha)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        ha haVar = (ha) obj;
        for (ee.a<?, ?> aVar : zP.values()) {
            if (a(aVar)) {
                if (haVar.a(aVar) && b(aVar).equals(haVar.b(aVar))) {
                }
                return false;
            }
            if (haVar.a(aVar)) {
                return false;
            }
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public a fa() {
        return this.AQ;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public b fb() {
        return this.AU;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public c fc() {
        return this.AW;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public d fd() {
        return this.AZ;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<f> fe() {
        return this.Bc;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<g> ff() {
        return this.Bd;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<h> fg() {
        return this.Bh;
    }

    @Override // com.google.android.gms.common.data.Freezable
    /* renamed from: fh, reason: merged with bridge method [inline-methods] */
    public ha freeze() {
        return this;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getAboutMe() {
        return this.AP;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public Person.AgeRange getAgeRange() {
        return this.AQ;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getBirthday() {
        return this.AR;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getBraggingRights() {
        return this.AS;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public int getCircledByCount() {
        return this.AT;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public Person.Cover getCover() {
        return this.AU;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getCurrentLocation() {
        return this.AV;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getDisplayName() {
        return this.pW;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public int getGender() {
        return this.eL;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getId() {
        return this.wJ;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public Person.Image getImage() {
        return this.AW;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getLanguage() {
        return this.AY;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public Person.Name getName() {
        return this.AZ;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getNickname() {
        return this.Ba;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public int getObjectType() {
        return this.Bb;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public List<Person.Organizations> getOrganizations() {
        return (ArrayList) this.Bc;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public List<Person.PlacesLived> getPlacesLived() {
        return (ArrayList) this.Bd;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public int getPlusOneCount() {
        return this.Be;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public int getRelationshipStatus() {
        return this.Bf;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getTagline() {
        return this.Bg;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public String getUrl() {
        return this.iD;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public List<Person.Urls> getUrls() {
        return (ArrayList) this.Bh;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.kZ;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasAboutMe() {
        return this.zQ.contains(2);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasAgeRange() {
        return this.zQ.contains(3);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasBirthday() {
        return this.zQ.contains(4);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasBraggingRights() {
        return this.zQ.contains(5);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasCircledByCount() {
        return this.zQ.contains(6);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasCover() {
        return this.zQ.contains(7);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasCurrentLocation() {
        return this.zQ.contains(8);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasDisplayName() {
        return this.zQ.contains(9);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasGender() {
        return this.zQ.contains(12);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasId() {
        return this.zQ.contains(14);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasImage() {
        return this.zQ.contains(15);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasIsPlusUser() {
        return this.zQ.contains(16);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasLanguage() {
        return this.zQ.contains(18);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasName() {
        return this.zQ.contains(19);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasNickname() {
        return this.zQ.contains(20);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasObjectType() {
        return this.zQ.contains(21);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasOrganizations() {
        return this.zQ.contains(22);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasPlacesLived() {
        return this.zQ.contains(23);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasPlusOneCount() {
        return this.zQ.contains(24);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasRelationshipStatus() {
        return this.zQ.contains(25);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasTagline() {
        return this.zQ.contains(26);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasUrl() {
        return this.zQ.contains(27);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasUrls() {
        return this.zQ.contains(28);
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean hasVerified() {
        return this.zQ.contains(29);
    }

    public int hashCode() {
        int i = 0;
        Iterator<ee.a<?, ?>> it = zP.values().iterator();
        while (true) {
            int i2 = i;
            if (!it.hasNext()) {
                return i2;
            }
            ee.a<?, ?> next = it.next();
            if (a(next)) {
                i = b(next).hashCode() + i2 + next.bX();
            } else {
                i = i2;
            }
        }
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean isPlusUser() {
        return this.AX;
    }

    @Override // com.google.android.gms.plus.model.people.Person
    public boolean isVerified() {
        return this.Bi;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        hb hbVar = CREATOR;
        hb.a(this, out, flags);
    }
}
