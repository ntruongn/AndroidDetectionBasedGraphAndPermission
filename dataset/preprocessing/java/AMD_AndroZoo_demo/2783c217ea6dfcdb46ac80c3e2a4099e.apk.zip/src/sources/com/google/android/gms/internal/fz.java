package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class fz extends fr implements SafeParcelable {
    public static final ga CREATOR = new ga();
    private static final fz wG = new fz(0, new gb[0], new float[0]);
    final int kZ;
    private final gb[] wH;
    private final float[] wI;

    /* JADX INFO: Access modifiers changed from: package-private */
    public fz(int i, gb[] gbVarArr, float[] fArr) {
        du.b(gbVarArr.length == fArr.length, "mismatched places to probabilities arrays");
        this.kZ = i;
        this.wH = gbVarArr;
        this.wI = fArr;
    }

    public gb[] dC() {
        return this.wH;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public float[] dD() {
        return this.wI;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        ga gaVar = CREATOR;
        return 0;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof fz)) {
            return false;
        }
        fz fzVar = (fz) object;
        return this.wH.equals(fzVar.wH) && this.wI.equals(fzVar.wI);
    }

    public int hashCode() {
        return ds.hashCode(this.wH, this.wI);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("PlaceEstimate{");
        for (int i = 0; i < this.wH.length; i++) {
            sb.append(String.format("(%f, %s)", Float.valueOf(this.wI[i]), this.wH[i].toString()));
            if (i != this.wH.length - 1) {
                sb.append(",");
            }
        }
        sb.append("}");
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int flags) {
        ga gaVar = CREATOR;
        ga.a(this, parcel, flags);
    }
}
