package com.google.android.gms.common.api;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.internal.du;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class a {

    /* renamed from: com.google.android.gms.common.api.a$a, reason: collision with other inner class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static abstract class AbstractC0001a<R extends Result, C, A extends Api.a> implements GoogleApiClient.a<A>, PendingResult<R, C>, c<R> {
        private final Api.b<A> ks;
        private R ky;
        private boolean kz;
        private final Object kt = new Object();
        private final CountDownLatch kv = new CountDownLatch(1);
        private final ArrayList<PendingResult.a> kw = new ArrayList<>();
        private final ArrayList<C> kx = new ArrayList<>();
        private final b<R, C> ku = (b<R, C>) new b<R, C>() { // from class: com.google.android.gms.common.api.a.a.1
            protected void a(C c, R r) {
                AbstractC0001a.this.a(c, r);
            }

            /* JADX WARN: Multi-variable type inference failed */
            @Override // com.google.android.gms.common.api.a.b
            protected /* bridge */ /* synthetic */ void a(Object obj, Object obj2) {
                a((AnonymousClass1) obj, obj2);
            }
        };

        public AbstractC0001a(Api.b<A> bVar) {
            this.ks = bVar;
        }

        private void aX() {
            if (this.ky == null || !(this.ky instanceof Releasable)) {
                return;
            }
            ((Releasable) this.ky).release();
        }

        @Override // com.google.android.gms.common.api.GoogleApiClient.a
        public final void a(A a) {
            b((AbstractC0001a<R, C, A>) a);
        }

        @Override // com.google.android.gms.common.api.a.c
        public final void a(R r) {
            du.a(!isReady(), "Results have already been reported.");
            synchronized (this.kt) {
                this.ky = r;
                this.kv.countDown();
                if (!this.kz) {
                    Iterator<C> it = this.kx.iterator();
                    while (it.hasNext()) {
                        this.ku.b(it.next(), this.ky);
                    }
                }
                Iterator<PendingResult.a> it2 = this.kw.iterator();
                while (it2.hasNext()) {
                    it2.next().c(this.ky.getStatus());
                }
                this.kx.clear();
                this.kw.clear();
                if (this.kz) {
                    aX();
                }
            }
        }

        protected abstract void a(C c, R r);

        @Override // com.google.android.gms.common.api.GoogleApiClient.a
        public final Api.b<A> aV() {
            return this.ks;
        }

        @Override // com.google.android.gms.common.api.PendingResult
        public final void addResultCallback(C callback) {
            synchronized (this.kt) {
                if (!isReady()) {
                    this.kx.add(callback);
                } else if (!this.kz) {
                    this.ku.b(callback, this.ky);
                }
            }
        }

        @Override // com.google.android.gms.common.api.PendingResult
        public final R await() {
            du.a(!this.kz, "Results have already been released.");
            try {
                this.kv.await();
            } catch (InterruptedException e) {
                a((AbstractC0001a<R, C, A>) b(Status.kX));
            }
            du.a(isReady(), "Result is not ready.");
            return this.ky;
        }

        @Override // com.google.android.gms.common.api.PendingResult
        public final R await(long time, TimeUnit units) {
            du.a(!this.kz, "Results have already been released.");
            try {
                if (!this.kv.await(time, units)) {
                    a((AbstractC0001a<R, C, A>) b(Status.kY));
                }
            } catch (InterruptedException e) {
                a((AbstractC0001a<R, C, A>) b(Status.kX));
            }
            du.a(isReady(), "Result is not ready.");
            return this.ky;
        }

        protected abstract void b(A a);

        public final boolean isReady() {
            return this.kv.getCount() == 0;
        }

        @Override // com.google.android.gms.common.api.PendingResult, com.google.android.gms.common.api.Releasable
        public final void release() {
            synchronized (this.kt) {
                this.kz = true;
                aX();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static abstract class b<R, C> extends Handler {
        public b() {
            this(Looper.getMainLooper());
        }

        public b(Looper looper) {
            super(looper);
        }

        protected abstract void a(C c, R r);

        public void b(C c, R r) {
            sendMessage(obtainMessage(1, new Pair(c, r)));
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    Pair pair = (Pair) msg.obj;
                    a(pair.first, pair.second);
                    return;
                default:
                    Log.wtf("GoogleApi", "Don't know how to handle this message.");
                    return;
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface c<R> {
        void a(R r);
    }
}
