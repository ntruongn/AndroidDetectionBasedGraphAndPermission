package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.dk;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class dm implements Handler.Callback {
    private static final Object mT = new Object();
    private static dm mU;
    private final Context iQ;
    private final Handler mHandler;
    private final HashMap<String, a> mV = new HashMap<>();

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class a {
        private final String mW;
        private boolean mZ;
        private IBinder na;
        private ComponentName nb;
        private final ServiceConnectionC0026a mX = new ServiceConnectionC0026a();
        private final HashSet<dk<?>.e> mY = new HashSet<>();
        private int mState = 0;

        /* renamed from: com.google.android.gms.internal.dm$a$a, reason: collision with other inner class name */
        /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
        public class ServiceConnectionC0026a implements ServiceConnection {
            public ServiceConnectionC0026a() {
            }

            @Override // android.content.ServiceConnection
            public void onServiceConnected(ComponentName component, IBinder binder) {
                synchronized (dm.this.mV) {
                    a.this.na = binder;
                    a.this.nb = component;
                    Iterator it = a.this.mY.iterator();
                    while (it.hasNext()) {
                        ((dk.e) it.next()).onServiceConnected(component, binder);
                    }
                    a.this.mState = 1;
                }
            }

            @Override // android.content.ServiceConnection
            public void onServiceDisconnected(ComponentName component) {
                synchronized (dm.this.mV) {
                    a.this.na = null;
                    a.this.nb = component;
                    Iterator it = a.this.mY.iterator();
                    while (it.hasNext()) {
                        ((dk.e) it.next()).onServiceDisconnected(component);
                    }
                    a.this.mState = 2;
                }
            }
        }

        public a(String str) {
            this.mW = str;
        }

        public void a(dk<?>.e eVar) {
            this.mY.add(eVar);
        }

        public void b(dk<?>.e eVar) {
            this.mY.remove(eVar);
        }

        public ServiceConnectionC0026a bH() {
            return this.mX;
        }

        public String bI() {
            return this.mW;
        }

        public boolean bJ() {
            return this.mY.isEmpty();
        }

        public boolean c(dk<?>.e eVar) {
            return this.mY.contains(eVar);
        }

        public IBinder getBinder() {
            return this.na;
        }

        public ComponentName getComponentName() {
            return this.nb;
        }

        public int getState() {
            return this.mState;
        }

        public boolean isBound() {
            return this.mZ;
        }

        public void o(boolean z) {
            this.mZ = z;
        }
    }

    private dm(Context context) {
        this.mHandler = new Handler(context.getMainLooper(), this);
        this.iQ = context.getApplicationContext();
    }

    public static dm s(Context context) {
        synchronized (mT) {
            if (mU == null) {
                mU = new dm(context.getApplicationContext());
            }
        }
        return mU;
    }

    public boolean a(String str, dk<?>.e eVar) {
        boolean isBound;
        synchronized (this.mV) {
            a aVar = this.mV.get(str);
            if (aVar != null) {
                this.mHandler.removeMessages(0, aVar);
                if (!aVar.c(eVar)) {
                    aVar.a(eVar);
                    switch (aVar.getState()) {
                        case 1:
                            eVar.onServiceConnected(aVar.getComponentName(), aVar.getBinder());
                            break;
                        case 2:
                            aVar.o(this.iQ.bindService(new Intent(str).setPackage(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE), aVar.bH(), 129));
                            break;
                    }
                } else {
                    throw new IllegalStateException("Trying to bind a GmsServiceConnection that was already connected before.  startServiceAction=" + str);
                }
            } else {
                aVar = new a(str);
                aVar.a(eVar);
                aVar.o(this.iQ.bindService(new Intent(str).setPackage(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE), aVar.bH(), 129));
                this.mV.put(str, aVar);
            }
            isBound = aVar.isBound();
        }
        return isBound;
    }

    public void b(String str, dk<?>.e eVar) {
        synchronized (this.mV) {
            a aVar = this.mV.get(str);
            if (aVar == null) {
                throw new IllegalStateException("Nonexistent connection status for service action: " + str);
            }
            if (!aVar.c(eVar)) {
                throw new IllegalStateException("Trying to unbind a GmsServiceConnection  that was not bound before.  startServiceAction=" + str);
            }
            aVar.b(eVar);
            if (aVar.bJ()) {
                this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(0, aVar), 5000L);
            }
        }
    }

    @Override // android.os.Handler.Callback
    public boolean handleMessage(Message msg) {
        switch (msg.what) {
            case 0:
                a aVar = (a) msg.obj;
                synchronized (this.mV) {
                    if (aVar.bJ()) {
                        this.iQ.unbindService(aVar.bH());
                        this.mV.remove(aVar.bI());
                    }
                }
                return true;
            default:
                return false;
        }
    }
}
