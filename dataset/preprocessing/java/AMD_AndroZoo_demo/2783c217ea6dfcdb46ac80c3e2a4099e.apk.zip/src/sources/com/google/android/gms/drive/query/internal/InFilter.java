package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.CollectionMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.query.Filter;
import java.util.Collections;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class InFilter<T> implements SafeParcelable, Filter {
    public static final e CREATOR = new e();
    final int kZ;
    final MetadataBundle pg;
    private final CollectionMetadataField<T> po;

    /* JADX INFO: Access modifiers changed from: package-private */
    public InFilter(int versionCode, MetadataBundle value) {
        this.kZ = versionCode;
        this.pg = value;
        this.po = (CollectionMetadataField) d.b(value);
    }

    public InFilter(CollectionMetadataField<T> field, T value) {
        this(1, MetadataBundle.a(field, Collections.singleton(value)));
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        e.a(this, out, flags);
    }
}
