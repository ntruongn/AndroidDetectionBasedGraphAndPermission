package com.google.android.gms.dynamic;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.dynamic.LifecycleDelegate;
import java.util.Iterator;
import java.util.LinkedList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public abstract class a<T extends LifecycleDelegate> {
    private T pG;
    private Bundle pH;
    private LinkedList<InterfaceC0007a> pI;
    private final d<T> pJ = (d<T>) new d<T>() { // from class: com.google.android.gms.dynamic.a.1
        @Override // com.google.android.gms.dynamic.d
        public void a(T t) {
            a.this.pG = t;
            Iterator it = a.this.pI.iterator();
            while (it.hasNext()) {
                ((InterfaceC0007a) it.next()).b(a.this.pG);
            }
            a.this.pI.clear();
            a.this.pH = null;
        }
    };

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: com.google.android.gms.dynamic.a$a, reason: collision with other inner class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface InterfaceC0007a {
        void b(LifecycleDelegate lifecycleDelegate);

        int getState();
    }

    private void a(Bundle bundle, InterfaceC0007a interfaceC0007a) {
        if (this.pG != null) {
            interfaceC0007a.b(this.pG);
            return;
        }
        if (this.pI == null) {
            this.pI = new LinkedList<>();
        }
        this.pI.add(interfaceC0007a);
        if (bundle != null) {
            if (this.pH == null) {
                this.pH = (Bundle) bundle.clone();
            } else {
                this.pH.putAll(bundle);
            }
        }
        a(this.pJ);
    }

    private void al(int i) {
        while (!this.pI.isEmpty() && this.pI.getLast().getState() >= i) {
            this.pI.removeLast();
        }
    }

    public void a(FrameLayout frameLayout) {
        final Context context = frameLayout.getContext();
        final int isGooglePlayServicesAvailable = GooglePlayServicesUtil.isGooglePlayServicesAvailable(context);
        String b = GooglePlayServicesUtil.b(context, isGooglePlayServicesAvailable, -1);
        String b2 = GooglePlayServicesUtil.b(context, isGooglePlayServicesAvailable);
        LinearLayout linearLayout = new LinearLayout(frameLayout.getContext());
        linearLayout.setOrientation(1);
        linearLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        frameLayout.addView(linearLayout);
        TextView textView = new TextView(frameLayout.getContext());
        textView.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        textView.setText(b);
        linearLayout.addView(textView);
        if (b2 != null) {
            Button button = new Button(context);
            button.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
            button.setText(b2);
            linearLayout.addView(button);
            button.setOnClickListener(new View.OnClickListener() { // from class: com.google.android.gms.dynamic.a.5
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    context.startActivity(GooglePlayServicesUtil.a(context, isGooglePlayServicesAvailable, -1));
                }
            });
        }
    }

    protected abstract void a(d<T> dVar);

    public T cG() {
        return this.pG;
    }

    public void onCreate(final Bundle savedInstanceState) {
        a(savedInstanceState, new InterfaceC0007a() { // from class: com.google.android.gms.dynamic.a.3
            @Override // com.google.android.gms.dynamic.a.InterfaceC0007a
            public void b(LifecycleDelegate lifecycleDelegate) {
                a.this.pG.onCreate(savedInstanceState);
            }

            @Override // com.google.android.gms.dynamic.a.InterfaceC0007a
            public int getState() {
                return 1;
            }
        });
    }

    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
        final FrameLayout frameLayout = new FrameLayout(inflater.getContext());
        a(savedInstanceState, new InterfaceC0007a() { // from class: com.google.android.gms.dynamic.a.4
            @Override // com.google.android.gms.dynamic.a.InterfaceC0007a
            public void b(LifecycleDelegate lifecycleDelegate) {
                frameLayout.removeAllViews();
                frameLayout.addView(a.this.pG.onCreateView(inflater, container, savedInstanceState));
            }

            @Override // com.google.android.gms.dynamic.a.InterfaceC0007a
            public int getState() {
                return 2;
            }
        });
        if (this.pG == null) {
            a(frameLayout);
        }
        return frameLayout;
    }

    public void onDestroy() {
        if (this.pG != null) {
            this.pG.onDestroy();
        } else {
            al(1);
        }
    }

    public void onDestroyView() {
        if (this.pG != null) {
            this.pG.onDestroyView();
        } else {
            al(2);
        }
    }

    public void onInflate(final Activity activity, final Bundle attrs, final Bundle savedInstanceState) {
        a(savedInstanceState, new InterfaceC0007a() { // from class: com.google.android.gms.dynamic.a.2
            @Override // com.google.android.gms.dynamic.a.InterfaceC0007a
            public void b(LifecycleDelegate lifecycleDelegate) {
                a.this.pG.onInflate(activity, attrs, savedInstanceState);
            }

            @Override // com.google.android.gms.dynamic.a.InterfaceC0007a
            public int getState() {
                return 0;
            }
        });
    }

    public void onLowMemory() {
        if (this.pG != null) {
            this.pG.onLowMemory();
        }
    }

    public void onPause() {
        if (this.pG != null) {
            this.pG.onPause();
        } else {
            al(3);
        }
    }

    public void onResume() {
        a((Bundle) null, new InterfaceC0007a() { // from class: com.google.android.gms.dynamic.a.6
            @Override // com.google.android.gms.dynamic.a.InterfaceC0007a
            public void b(LifecycleDelegate lifecycleDelegate) {
                a.this.pG.onResume();
            }

            @Override // com.google.android.gms.dynamic.a.InterfaceC0007a
            public int getState() {
                return 3;
            }
        });
    }

    public void onSaveInstanceState(Bundle outState) {
        if (this.pG != null) {
            this.pG.onSaveInstanceState(outState);
        } else if (this.pH != null) {
            outState.putAll(this.pH);
        }
    }
}
