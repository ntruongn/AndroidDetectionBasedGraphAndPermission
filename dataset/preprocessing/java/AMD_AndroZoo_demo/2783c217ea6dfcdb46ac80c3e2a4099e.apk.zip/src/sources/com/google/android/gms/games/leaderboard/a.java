package com.google.android.gms.games.leaderboard;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.eo;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class a implements Leaderboard {
    private final String pW;
    private final Uri qb;
    private final String rL;
    private final int rM;
    private final ArrayList<f> rN;

    public a(Leaderboard leaderboard) {
        this.rL = leaderboard.getLeaderboardId();
        this.pW = leaderboard.getDisplayName();
        this.qb = leaderboard.getIconImageUri();
        this.rM = leaderboard.getScoreOrder();
        ArrayList<LeaderboardVariant> variants = leaderboard.getVariants();
        int size = variants.size();
        this.rN = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            this.rN.add((f) variants.get(i).freeze());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int a(Leaderboard leaderboard) {
        return ds.hashCode(leaderboard.getLeaderboardId(), leaderboard.getDisplayName(), leaderboard.getIconImageUri(), Integer.valueOf(leaderboard.getScoreOrder()), leaderboard.getVariants());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a(Leaderboard leaderboard, Object obj) {
        if (!(obj instanceof Leaderboard)) {
            return false;
        }
        if (leaderboard == obj) {
            return true;
        }
        Leaderboard leaderboard2 = (Leaderboard) obj;
        return ds.equal(leaderboard2.getLeaderboardId(), leaderboard.getLeaderboardId()) && ds.equal(leaderboard2.getDisplayName(), leaderboard.getDisplayName()) && ds.equal(leaderboard2.getIconImageUri(), leaderboard.getIconImageUri()) && ds.equal(Integer.valueOf(leaderboard2.getScoreOrder()), Integer.valueOf(leaderboard.getScoreOrder())) && ds.equal(leaderboard2.getVariants(), leaderboard.getVariants());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String b(Leaderboard leaderboard) {
        return ds.e(leaderboard).a("LeaderboardId", leaderboard.getLeaderboardId()).a("DisplayName", leaderboard.getDisplayName()).a("IconImageUri", leaderboard.getIconImageUri()).a("ScoreOrder", Integer.valueOf(leaderboard.getScoreOrder())).a("Variants", leaderboard.getVariants()).toString();
    }

    @Override // com.google.android.gms.common.data.Freezable
    /* renamed from: dd, reason: merged with bridge method [inline-methods] */
    public Leaderboard freeze() {
        return this;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    @Override // com.google.android.gms.games.leaderboard.Leaderboard
    public String getDisplayName() {
        return this.pW;
    }

    @Override // com.google.android.gms.games.leaderboard.Leaderboard
    public void getDisplayName(CharArrayBuffer dataOut) {
        eo.b(this.pW, dataOut);
    }

    @Override // com.google.android.gms.games.leaderboard.Leaderboard
    public Uri getIconImageUri() {
        return this.qb;
    }

    @Override // com.google.android.gms.games.leaderboard.Leaderboard
    public String getLeaderboardId() {
        return this.rL;
    }

    @Override // com.google.android.gms.games.leaderboard.Leaderboard
    public int getScoreOrder() {
        return this.rM;
    }

    @Override // com.google.android.gms.games.leaderboard.Leaderboard
    public ArrayList<LeaderboardVariant> getVariants() {
        return new ArrayList<>(this.rN);
    }

    public int hashCode() {
        return a(this);
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        return b(this);
    }
}
