package com.google.android.gms.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class gb extends fq implements SafeParcelable {
    public static final gc CREATOR = new gc();
    final int kZ;
    private final String wJ;
    private final Bundle wK;
    private final gd wL;
    private final LatLng wM;
    private final float wN;
    private final LatLngBounds wO;
    private final String wP;
    private final Uri wQ;
    private final boolean wR;
    private final float wS;
    private final int wT;
    private final long wU;
    private final List<fw> wV;
    private final Map<fw, String> wW;
    private final TimeZone wX;
    private Locale wY;
    private gf wZ;

    /* JADX INFO: Access modifiers changed from: package-private */
    public gb(int i, String str, List<fw> list, Bundle bundle, gd gdVar, LatLng latLng, float f, LatLngBounds latLngBounds, String str2, Uri uri, boolean z, float f2, int i2, long j) {
        this.kZ = i;
        this.wJ = str;
        this.wV = Collections.unmodifiableList(list);
        this.wK = bundle;
        this.wL = gdVar;
        this.wM = latLng;
        this.wN = f;
        this.wO = latLngBounds;
        this.wP = str2;
        this.wQ = uri;
        this.wR = z;
        this.wS = f2;
        this.wT = i2;
        this.wU = j;
        HashMap hashMap = new HashMap();
        for (String str3 : bundle.keySet()) {
            hashMap.put(fw.ab(str3), bundle.getString(str3));
        }
        this.wW = Collections.unmodifiableMap(hashMap);
        this.wX = TimeZone.getTimeZone(this.wP);
        this.wY = null;
        this.wZ = null;
    }

    private void ac(String str) {
        if (this.wZ != null) {
            this.wZ.b(this.wJ, "PlaceImpl", str);
        }
    }

    public List<fw> dE() {
        ac("getTypes");
        return this.wV;
    }

    public LatLng dF() {
        ac("getLatLng");
        return this.wM;
    }

    public float dG() {
        ac("getLevelNumber");
        return this.wN;
    }

    public LatLngBounds dH() {
        ac("getViewport");
        return this.wO;
    }

    public Uri dI() {
        ac("getWebsiteUri");
        return this.wQ;
    }

    public boolean dJ() {
        ac("isPermanentlyClosed");
        return this.wR;
    }

    public int dK() {
        ac("getPriceLevel");
        return this.wT;
    }

    public long dL() {
        return this.wU;
    }

    public Bundle dM() {
        return this.wK;
    }

    public gd dN() {
        return this.wL;
    }

    public String dO() {
        return this.wP;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        gc gcVar = CREATOR;
        return 0;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof gb)) {
            return false;
        }
        gb gbVar = (gb) object;
        return this.wJ.equals(gbVar.wJ) && ds.equal(this.wY, gbVar.wY) && this.wU == gbVar.wU;
    }

    public String getId() {
        ac("getId");
        return this.wJ;
    }

    public float getRating() {
        ac("getRating");
        return this.wS;
    }

    public int hashCode() {
        return ds.hashCode(this.wJ, this.wY, Long.valueOf(this.wU));
    }

    public String toString() {
        return ds.e(this).a(com.huprya.wqkqze112375.j.ID, this.wJ).a("localization", this.wL).a("locale", this.wY).a("latlng", this.wM).a("levelNumber", Float.valueOf(this.wN)).a("viewport", this.wO).a("timeZone", this.wP).a("websiteUri", this.wQ).a("isPermanentlyClosed", Boolean.valueOf(this.wR)).a("priceLevel", Integer.valueOf(this.wT)).a("timestampSecs", Long.valueOf(this.wU)).toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int flags) {
        gc gcVar = CREATOR;
        gc.a(this, parcel, flags);
    }
}
