package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ee;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class dz implements SafeParcelable {
    public static final ea CREATOR = new ea();
    private final int kZ;
    private final eb nr;

    /* JADX INFO: Access modifiers changed from: package-private */
    public dz(int i, eb ebVar) {
        this.kZ = i;
        this.nr = ebVar;
    }

    private dz(eb ebVar) {
        this.kZ = 1;
        this.nr = ebVar;
    }

    public static dz a(ee.b<?, ?> bVar) {
        if (bVar instanceof eb) {
            return new dz((eb) bVar);
        }
        throw new IllegalArgumentException("Unsupported safe parcelable field converter class.");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public eb bL() {
        return this.nr;
    }

    public ee.b<?, ?> bM() {
        if (this.nr != null) {
            return this.nr;
        }
        throw new IllegalStateException("There was no converter wrapped in this ConverterWrapper.");
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        ea eaVar = CREATOR;
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.kZ;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        ea eaVar = CREATOR;
        ea.a(this, out, flags);
    }
}
