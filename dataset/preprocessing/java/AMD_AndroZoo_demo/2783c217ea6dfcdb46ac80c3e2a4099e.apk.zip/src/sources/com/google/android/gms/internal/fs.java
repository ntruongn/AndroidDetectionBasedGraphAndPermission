package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class fs implements SafeParcelable {
    public static final ft CREATOR = new ft();
    final int kZ;
    private final int uc;
    final List<fw> ud;
    private final String ue;
    private final String uf;
    private final boolean ug;
    private final Set<fw> uh;

    /* JADX INFO: Access modifiers changed from: package-private */
    public fs(int i, int i2, List<fw> list, String str, String str2, boolean z) {
        this.kZ = i;
        this.uc = i2;
        this.ud = list == null ? Collections.emptyList() : Collections.unmodifiableList(list);
        this.ue = str == null ? "" : str;
        this.uf = str2 == null ? "" : str2;
        this.ug = z;
        if (this.ud.isEmpty()) {
            this.uh = Collections.emptySet();
        } else {
            this.uh = Collections.unmodifiableSet(new HashSet(this.ud));
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        ft ftVar = CREATOR;
        return 0;
    }

    public int dw() {
        return this.uc;
    }

    public String dx() {
        return this.ue;
    }

    public String dy() {
        return this.uf;
    }

    public boolean dz() {
        return this.ug;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof fs)) {
            return false;
        }
        fs fsVar = (fs) object;
        return this.uc == fsVar.uc && this.uh.equals(fsVar.uh) && this.ue == fsVar.ue && this.uf == fsVar.uf && this.ug == fsVar.ug;
    }

    public int hashCode() {
        return ds.hashCode(Integer.valueOf(this.uc), this.uh, this.ue, this.uf, Boolean.valueOf(this.ug));
    }

    public String toString() {
        return ds.e(this).a("maxResults", Integer.valueOf(this.uc)).a("types", this.uh).a("nameQuery", this.ue).a("textQuery", this.uf).a("isOpenNowRequired", Boolean.valueOf(this.ug)).toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int flags) {
        ft ftVar = CREATOR;
        ft.a(this, parcel, flags);
    }
}
