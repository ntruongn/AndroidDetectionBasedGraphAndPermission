package com.google.android.gms.drive;

import android.content.Context;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.drive.internal.h;
import com.google.android.gms.drive.internal.j;
import com.google.android.gms.internal.dh;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class Drive {
    public static final Api.b<j> jL = new Api.b<j>() { // from class: com.google.android.gms.drive.Drive.1
        @Override // com.google.android.gms.common.api.Api.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public j b(Context context, dh dhVar, GoogleApiClient.ApiOptions apiOptions, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {
            List<String> bu = dhVar.bu();
            return new j(context, dhVar, connectionCallbacks, onConnectionFailedListener, (String[]) bu.toArray(new String[bu.size()]));
        }

        @Override // com.google.android.gms.common.api.Api.b
        public int getPriority() {
            return Integer.MAX_VALUE;
        }
    };
    public static final Scope SCOPE_FILE = new Scope(Scopes.DRIVE_FILE);
    public static final Api API = new Api(jL, new Scope[0]);
    public static final DriveApi DriveApi = new h();

    private Drive() {
    }
}
