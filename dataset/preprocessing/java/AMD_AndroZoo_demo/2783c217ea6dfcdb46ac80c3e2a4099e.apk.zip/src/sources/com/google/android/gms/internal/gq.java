package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.dk;
import com.google.android.gms.internal.gp;
import com.google.android.gms.plus.PlusClient;
import com.google.android.gms.plus.model.moments.Moment;
import com.google.android.gms.plus.model.moments.MomentBuffer;
import com.google.android.gms.plus.model.people.Person;
import com.google.android.gms.plus.model.people.PersonBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class gq extends dk<gp> implements GooglePlayServicesClient {
    private Person zx;
    private gs zy;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class a extends gl {
        private final PlusClient.OnMomentsLoadedListener zz;

        public a(PlusClient.OnMomentsLoadedListener onMomentsLoadedListener) {
            this.zz = onMomentsLoadedListener;
        }

        @Override // com.google.android.gms.internal.gl, com.google.android.gms.internal.gm
        public void a(DataHolder dataHolder, String str, String str2) {
            DataHolder dataHolder2;
            ConnectionResult connectionResult = new ConnectionResult(dataHolder.getStatusCode(), dataHolder.getMetadata() != null ? (PendingIntent) dataHolder.getMetadata().getParcelable("pendingIntent") : null);
            if (connectionResult.isSuccess() || dataHolder == null) {
                dataHolder2 = dataHolder;
            } else {
                if (!dataHolder.isClosed()) {
                    dataHolder.close();
                }
                dataHolder2 = null;
            }
            gq.this.a(new b(this.zz, connectionResult, dataHolder2, str, str2));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class b extends dk<gp>.c<PlusClient.OnMomentsLoadedListener> {
        private final String oi;
        private final ConnectionResult zB;
        private final String zC;

        public b(PlusClient.OnMomentsLoadedListener onMomentsLoadedListener, ConnectionResult connectionResult, DataHolder dataHolder, String str, String str2) {
            super(onMomentsLoadedListener, dataHolder);
            this.zB = connectionResult;
            this.oi = str;
            this.zC = str2;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(PlusClient.OnMomentsLoadedListener onMomentsLoadedListener, DataHolder dataHolder) {
            onMomentsLoadedListener.onMomentsLoaded(this.zB, dataHolder != null ? new MomentBuffer(dataHolder) : null, this.oi, this.zC);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class c extends gl {
        private final PlusClient.OnPeopleLoadedListener zD;

        public c(PlusClient.OnPeopleLoadedListener onPeopleLoadedListener) {
            this.zD = onPeopleLoadedListener;
        }

        @Override // com.google.android.gms.internal.gl, com.google.android.gms.internal.gm
        public void a(DataHolder dataHolder, String str) {
            DataHolder dataHolder2;
            ConnectionResult connectionResult = new ConnectionResult(dataHolder.getStatusCode(), dataHolder.getMetadata() != null ? (PendingIntent) dataHolder.getMetadata().getParcelable("pendingIntent") : null);
            if (connectionResult.isSuccess() || dataHolder == null) {
                dataHolder2 = dataHolder;
            } else {
                if (!dataHolder.isClosed()) {
                    dataHolder.close();
                }
                dataHolder2 = null;
            }
            gq.this.a(new d(this.zD, connectionResult, dataHolder2, str));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class d extends dk<gp>.c<PlusClient.OnPeopleLoadedListener> {
        private final String oi;
        private final ConnectionResult zB;

        public d(PlusClient.OnPeopleLoadedListener onPeopleLoadedListener, ConnectionResult connectionResult, DataHolder dataHolder, String str) {
            super(onPeopleLoadedListener, dataHolder);
            this.zB = connectionResult;
            this.oi = str;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.c
        public void a(PlusClient.OnPeopleLoadedListener onPeopleLoadedListener, DataHolder dataHolder) {
            onPeopleLoadedListener.onPeopleLoaded(this.zB, dataHolder != null ? new PersonBuffer(dataHolder) : null, this.oi);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    final class e extends gl {
        private final PlusClient.OnAccessRevokedListener zE;

        public e(PlusClient.OnAccessRevokedListener onAccessRevokedListener) {
            this.zE = onAccessRevokedListener;
        }

        @Override // com.google.android.gms.internal.gl, com.google.android.gms.internal.gm
        public void b(int i, Bundle bundle) {
            gq.this.a(new f(this.zE, new ConnectionResult(i, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class f extends dk<gp>.b<PlusClient.OnAccessRevokedListener> {
        private final ConnectionResult zB;

        public f(PlusClient.OnAccessRevokedListener onAccessRevokedListener, ConnectionResult connectionResult) {
            super(onAccessRevokedListener);
            this.zB = connectionResult;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dk.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void b(PlusClient.OnAccessRevokedListener onAccessRevokedListener) {
            gq.this.disconnect();
            if (onAccessRevokedListener != null) {
                onAccessRevokedListener.onAccessRevoked(this.zB);
            }
        }

        @Override // com.google.android.gms.internal.dk.b
        protected void aQ() {
        }
    }

    public gq(Context context, gs gsVar, GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener) {
        super(context, connectionCallbacks, onConnectionFailedListener, gsVar.ew());
        this.zy = gsVar;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.internal.dk
    public void a(int i, IBinder iBinder, Bundle bundle) {
        if (i == 0 && bundle != null && bundle.containsKey("loaded_person")) {
            this.zx = ha.g(bundle.getByteArray("loaded_person"));
        }
        super.a(i, iBinder, bundle);
    }

    @Override // com.google.android.gms.internal.dk
    protected void a(dq dqVar, dk.d dVar) throws RemoteException {
        Bundle bundle = new Bundle();
        bundle.putStringArray("request_visible_actions", this.zy.ex());
        dqVar.a(dVar, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, this.zy.eA(), this.zy.ez(), bA(), this.zy.getAccountName(), bundle);
    }

    public void a(PlusClient.OnPeopleLoadedListener onPeopleLoadedListener, Collection<String> collection) {
        bB();
        c cVar = new c(onPeopleLoadedListener);
        try {
            bC().a(cVar, new ArrayList(collection));
        } catch (RemoteException e2) {
            cVar.a(DataHolder.empty(8), (String) null);
        }
    }

    public void a(PlusClient.OnPeopleLoadedListener onPeopleLoadedListener, String[] strArr) {
        a(onPeopleLoadedListener, Arrays.asList(strArr));
    }

    public boolean aj(String str) {
        return Arrays.asList(bA()).contains(str);
    }

    @Override // com.google.android.gms.internal.dk
    protected String am() {
        return "com.google.android.gms.plus.service.START";
    }

    @Override // com.google.android.gms.internal.dk
    protected String an() {
        return "com.google.android.gms.plus.internal.IPlusService";
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.internal.dk
    /* renamed from: av, reason: merged with bridge method [inline-methods] */
    public gp p(IBinder iBinder) {
        return gp.a.au(iBinder);
    }

    public void clearDefaultAccount() {
        bB();
        try {
            this.zx = null;
            bC().clearDefaultAccount();
        } catch (RemoteException e2) {
            throw new IllegalStateException(e2);
        }
    }

    public String getAccountName() {
        bB();
        try {
            return bC().getAccountName();
        } catch (RemoteException e2) {
            throw new IllegalStateException(e2);
        }
    }

    public Person getCurrentPerson() {
        bB();
        return this.zx;
    }

    public void loadMoments(PlusClient.OnMomentsLoadedListener listener) {
        loadMoments(listener, 20, null, null, null, "me");
    }

    public void loadMoments(PlusClient.OnMomentsLoadedListener listener, int maxResults, String pageToken, Uri targetUrl, String type, String userId) {
        bB();
        a aVar = listener != null ? new a(listener) : null;
        try {
            bC().a(aVar, maxResults, pageToken, targetUrl, type, userId);
        } catch (RemoteException e2) {
            aVar.a(DataHolder.empty(8), (String) null, (String) null);
        }
    }

    public void loadVisiblePeople(PlusClient.OnPeopleLoadedListener listener, int orderBy, String pageToken) {
        bB();
        c cVar = new c(listener);
        try {
            bC().a(cVar, 1, orderBy, -1, pageToken);
        } catch (RemoteException e2) {
            cVar.a(DataHolder.empty(8), (String) null);
        }
    }

    public void loadVisiblePeople(PlusClient.OnPeopleLoadedListener listener, String pageToken) {
        loadVisiblePeople(listener, 0, pageToken);
    }

    public void removeMoment(String momentId) {
        bB();
        try {
            bC().removeMoment(momentId);
        } catch (RemoteException e2) {
            throw new IllegalStateException(e2);
        }
    }

    public void revokeAccessAndDisconnect(PlusClient.OnAccessRevokedListener listener) {
        bB();
        clearDefaultAccount();
        e eVar = new e(listener);
        try {
            bC().b(eVar);
        } catch (RemoteException e2) {
            eVar.b(8, null);
        }
    }

    public void writeMoment(Moment moment) {
        bB();
        try {
            bC().a(ek.a((gx) moment));
        } catch (RemoteException e2) {
            throw new IllegalStateException(e2);
        }
    }
}
