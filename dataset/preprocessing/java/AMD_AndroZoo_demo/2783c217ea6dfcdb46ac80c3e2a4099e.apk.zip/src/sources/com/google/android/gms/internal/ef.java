package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.internal.ee;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class ef implements Parcelable.Creator<ee.a> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(ee.a aVar, Parcel parcel, int i) {
        int l = com.google.android.gms.common.internal.safeparcel.b.l(parcel);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 1, aVar.getVersionCode());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 2, aVar.bO());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, aVar.bU());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 4, aVar.bP());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, aVar.bV());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 6, aVar.bW(), false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 7, aVar.bX());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 8, aVar.bZ(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 9, (Parcelable) aVar.cb(), i, false);
        com.google.android.gms.common.internal.safeparcel.b.D(parcel, l);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: E, reason: merged with bridge method [inline-methods] */
    public ee.a[] newArray(int i) {
        return new ee.a[i];
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: p, reason: merged with bridge method [inline-methods] */
    public ee.a createFromParcel(Parcel parcel) {
        dz dzVar = null;
        int i = 0;
        int k = com.google.android.gms.common.internal.safeparcel.a.k(parcel);
        String str = null;
        String str2 = null;
        boolean z = false;
        int i2 = 0;
        boolean z2 = false;
        int i3 = 0;
        int i4 = 0;
        while (parcel.dataPosition() < k) {
            int j = com.google.android.gms.common.internal.safeparcel.a.j(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.a.A(j)) {
                case 1:
                    i4 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 2:
                    i3 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 3:
                    z2 = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j);
                    break;
                case 4:
                    i2 = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 5:
                    z = com.google.android.gms.common.internal.safeparcel.a.c(parcel, j);
                    break;
                case 6:
                    str2 = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    break;
                case 7:
                    i = com.google.android.gms.common.internal.safeparcel.a.g(parcel, j);
                    break;
                case 8:
                    str = com.google.android.gms.common.internal.safeparcel.a.m(parcel, j);
                    break;
                case 9:
                    dzVar = (dz) com.google.android.gms.common.internal.safeparcel.a.a(parcel, j, dz.CREATOR);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.a.b(parcel, j);
                    break;
            }
        }
        if (parcel.dataPosition() != k) {
            throw new a.C0003a("Overread allowed size end=" + k, parcel);
        }
        return new ee.a(i4, i3, z2, i2, z, str2, i, str, dzVar);
    }
}
