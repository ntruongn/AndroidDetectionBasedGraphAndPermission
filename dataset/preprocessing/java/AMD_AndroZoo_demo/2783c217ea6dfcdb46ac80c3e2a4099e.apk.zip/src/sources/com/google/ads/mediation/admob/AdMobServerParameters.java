package com.google.ads.mediation.admob;

import com.google.ads.mediation.MediationServerParameters;
import com.huprya.wqkqze112375.g;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class AdMobServerParameters extends MediationServerParameters {
    public String adJson;

    @MediationServerParameters.Parameter(name = "pubid")
    public String adUnitId;

    @MediationServerParameters.Parameter(name = "mad_hac", required = g.isDebugMode)
    public String allowHouseAds = null;
    public int tagForChildDirectedTreatment = -1;
}
