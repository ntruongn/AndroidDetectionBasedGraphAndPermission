package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.net.Uri;
import android.widget.ImageView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class df extends ImageView {
    private Uri mq;
    private int mr;
    private int ms;

    public int bs() {
        return this.mr;
    }

    public void d(Uri uri) {
        this.mq = uri;
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.ms != 0) {
            canvas.drawColor(this.ms);
        }
    }

    public void x(int i) {
        this.mr = i;
    }
}
