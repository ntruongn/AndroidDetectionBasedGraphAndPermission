package com.google.android.gms.common.images;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.common.images.ImageManager;
import com.google.android.gms.internal.de;
import com.google.android.gms.internal.df;
import com.google.android.gms.internal.dg;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.es;
import java.lang.ref.WeakReference;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class a {
    final C0002a lM;
    private int lN;
    private int lO;
    int lP;
    private int lQ;
    private WeakReference<ImageManager.OnImageLoadedListener> lR;
    private WeakReference<ImageView> lS;
    private WeakReference<TextView> lT;
    private int lU;
    private boolean lV;
    private boolean lW;

    /* renamed from: com.google.android.gms.common.images.a$a, reason: collision with other inner class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class C0002a {
        public final Uri uri;

        public C0002a(Uri uri) {
            this.uri = uri;
        }

        public boolean equals(Object obj) {
            if (obj instanceof C0002a) {
                return this == obj || ((C0002a) obj).hashCode() == hashCode();
            }
            return false;
        }

        public int hashCode() {
            return ds.hashCode(this.uri);
        }
    }

    public a(int i) {
        this.lN = 0;
        this.lO = 0;
        this.lU = -1;
        this.lV = true;
        this.lW = false;
        this.lM = new C0002a(null);
        this.lO = i;
    }

    public a(Uri uri) {
        this.lN = 0;
        this.lO = 0;
        this.lU = -1;
        this.lV = true;
        this.lW = false;
        this.lM = new C0002a(uri);
        this.lO = 0;
    }

    private de a(Drawable drawable, Drawable drawable2) {
        if (drawable == null) {
            drawable = null;
        } else if (drawable instanceof de) {
            drawable = ((de) drawable).bq();
        }
        return new de(drawable, drawable2);
    }

    private void a(Drawable drawable, boolean z, boolean z2, boolean z3) {
        ImageManager.OnImageLoadedListener onImageLoadedListener;
        switch (this.lP) {
            case 1:
                if (z2 || (onImageLoadedListener = this.lR.get()) == null) {
                    return;
                }
                onImageLoadedListener.onImageLoaded(this.lM.uri, drawable, z3);
                return;
            case 2:
                ImageView imageView = this.lS.get();
                if (imageView != null) {
                    a(imageView, drawable, z, z2, z3);
                    return;
                }
                return;
            case 3:
                TextView textView = this.lT.get();
                if (textView != null) {
                    a(textView, this.lU, drawable, z, z2);
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void a(ImageView imageView, Drawable drawable, boolean z, boolean z2, boolean z3) {
        boolean z4 = (z2 || z3) ? false : true;
        if (z4 && (imageView instanceof df)) {
            int bs = ((df) imageView).bs();
            if (this.lO != 0 && bs == this.lO) {
                return;
            }
        }
        boolean a = a(z, z2);
        Drawable a2 = a ? a(imageView.getDrawable(), drawable) : drawable;
        imageView.setImageDrawable(a2);
        if (imageView instanceof df) {
            df dfVar = (df) imageView;
            dfVar.d(z3 ? this.lM.uri : null);
            dfVar.x(z4 ? this.lO : 0);
        }
        if (a) {
            ((de) a2).startTransition(250);
        }
    }

    private void a(TextView textView, int i, Drawable drawable, boolean z, boolean z2) {
        boolean a = a(z, z2);
        Drawable[] compoundDrawablesRelative = es.cp() ? textView.getCompoundDrawablesRelative() : textView.getCompoundDrawables();
        Drawable a2 = a ? a(compoundDrawablesRelative[i], drawable) : drawable;
        Drawable drawable2 = i == 0 ? a2 : compoundDrawablesRelative[0];
        Drawable drawable3 = i == 1 ? a2 : compoundDrawablesRelative[1];
        Drawable drawable4 = i == 2 ? a2 : compoundDrawablesRelative[2];
        Drawable drawable5 = i == 3 ? a2 : compoundDrawablesRelative[3];
        if (es.cp()) {
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable2, drawable3, drawable4, drawable5);
        } else {
            textView.setCompoundDrawablesWithIntrinsicBounds(drawable2, drawable3, drawable4, drawable5);
        }
        if (a) {
            ((de) a2).startTransition(250);
        }
    }

    private boolean a(boolean z, boolean z2) {
        return this.lV && !z2 && (!z || this.lW);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(Context context, Bitmap bitmap, boolean z) {
        dg.d(bitmap);
        a(new BitmapDrawable(context.getResources(), bitmap), z, false, true);
    }

    public void a(ImageView imageView) {
        dg.d(imageView);
        this.lR = null;
        this.lS = new WeakReference<>(imageView);
        this.lT = null;
        this.lU = -1;
        this.lP = 2;
        this.lQ = imageView.hashCode();
    }

    public void a(ImageManager.OnImageLoadedListener onImageLoadedListener) {
        dg.d(onImageLoadedListener);
        this.lR = new WeakReference<>(onImageLoadedListener);
        this.lS = null;
        this.lT = null;
        this.lU = -1;
        this.lP = 1;
        this.lQ = ds.hashCode(onImageLoadedListener, this.lM);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(Context context, boolean z) {
        a(this.lO != 0 ? context.getResources().getDrawable(this.lO) : null, z, false, false);
    }

    public boolean equals(Object obj) {
        if (obj instanceof a) {
            return this == obj || ((a) obj).hashCode() == hashCode();
        }
        return false;
    }

    public int hashCode() {
        return this.lQ;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void r(Context context) {
        a(this.lN != 0 ? context.getResources().getDrawable(this.lN) : null, false, true, false);
    }

    public void w(int i) {
        this.lO = i;
    }
}
