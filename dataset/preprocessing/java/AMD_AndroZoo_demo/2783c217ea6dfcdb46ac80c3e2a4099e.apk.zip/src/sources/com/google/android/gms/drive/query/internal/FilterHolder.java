package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.Filter;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class FilterHolder implements SafeParcelable {
    public static final Parcelable.Creator<FilterHolder> CREATOR = new c();
    final int kZ;
    final ComparisonFilter<?> pi;
    final FieldOnlyFilter pj;
    final LogicalFilter pk;
    final NotFilter pl;
    final InFilter<?> pm;
    private final Filter pn;

    /* JADX INFO: Access modifiers changed from: package-private */
    public FilterHolder(int versionCode, ComparisonFilter<?> comparisonField, FieldOnlyFilter fieldOnlyFilter, LogicalFilter logicalFilter, NotFilter notFilter, InFilter<?> containsFilter) {
        this.kZ = versionCode;
        this.pi = comparisonField;
        this.pj = fieldOnlyFilter;
        this.pk = logicalFilter;
        this.pl = notFilter;
        this.pm = containsFilter;
        if (this.pi != null) {
            this.pn = this.pi;
            return;
        }
        if (this.pj != null) {
            this.pn = this.pj;
            return;
        }
        if (this.pk != null) {
            this.pn = this.pk;
        } else if (this.pl != null) {
            this.pn = this.pl;
        } else {
            if (this.pm == null) {
                throw new IllegalArgumentException("At least one filter must be set.");
            }
            this.pn = this.pm;
        }
    }

    public FilterHolder(Filter filter) {
        this.kZ = 1;
        this.pi = filter instanceof ComparisonFilter ? (ComparisonFilter) filter : null;
        this.pj = filter instanceof FieldOnlyFilter ? (FieldOnlyFilter) filter : null;
        this.pk = filter instanceof LogicalFilter ? (LogicalFilter) filter : null;
        this.pl = filter instanceof NotFilter ? (NotFilter) filter : null;
        this.pm = filter instanceof InFilter ? (InFilter) filter : null;
        if (this.pi == null && this.pj == null && this.pk == null && this.pl == null && this.pm == null) {
            throw new IllegalArgumentException("Invalid filter type or null filter.");
        }
        this.pn = filter;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        c.a(this, out, flags);
    }
}
