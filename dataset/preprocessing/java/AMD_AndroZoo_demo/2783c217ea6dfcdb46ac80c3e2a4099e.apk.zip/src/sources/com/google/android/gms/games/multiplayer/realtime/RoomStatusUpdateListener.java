package com.google.android.gms.games.multiplayer.realtime;

import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public interface RoomStatusUpdateListener {
    void onConnectedToRoom(Room room);

    void onDisconnectedFromRoom(Room room);

    void onP2PConnected(String str);

    void onP2PDisconnected(String str);

    void onPeerDeclined(Room room, List<String> list);

    void onPeerInvitedToRoom(Room room, List<String> list);

    void onPeerJoined(Room room, List<String> list);

    void onPeerLeft(Room room, List<String> list);

    void onPeersConnected(Room room, List<String> list);

    void onPeersDisconnected(Room room, List<String> list);

    void onRoomAutoMatching(Room room);

    void onRoomConnecting(Room room);
}
