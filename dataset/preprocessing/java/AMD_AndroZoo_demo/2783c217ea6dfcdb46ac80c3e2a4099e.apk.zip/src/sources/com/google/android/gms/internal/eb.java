package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ee;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class eb implements SafeParcelable, ee.b<String, Integer> {
    public static final ec CREATOR = new ec();
    private final int kZ;
    private final HashMap<String, Integer> ns;
    private final HashMap<Integer, String> nt;
    private final ArrayList<a> nu;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a implements SafeParcelable {
        public static final ed CREATOR = new ed();
        final String nv;
        final int nw;
        final int versionCode;

        /* JADX INFO: Access modifiers changed from: package-private */
        public a(int i, String str, int i2) {
            this.versionCode = i;
            this.nv = str;
            this.nw = i2;
        }

        a(String str, int i) {
            this.versionCode = 1;
            this.nv = str;
            this.nw = i;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            ed edVar = CREATOR;
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            ed edVar = CREATOR;
            ed.a(this, out, flags);
        }
    }

    public eb() {
        this.kZ = 1;
        this.ns = new HashMap<>();
        this.nt = new HashMap<>();
        this.nu = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public eb(int i, ArrayList<a> arrayList) {
        this.kZ = i;
        this.ns = new HashMap<>();
        this.nt = new HashMap<>();
        this.nu = null;
        a(arrayList);
    }

    private void a(ArrayList<a> arrayList) {
        Iterator<a> it = arrayList.iterator();
        while (it.hasNext()) {
            a next = it.next();
            b(next.nv, next.nw);
        }
    }

    @Override // com.google.android.gms.internal.ee.b
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public String g(Integer num) {
        String str = this.nt.get(num);
        return (str == null && this.ns.containsKey("gms_unknown")) ? "gms_unknown" : str;
    }

    public eb b(String str, int i) {
        this.ns.put(str, Integer.valueOf(i));
        this.nt.put(Integer.valueOf(i), str);
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ArrayList<a> bN() {
        ArrayList<a> arrayList = new ArrayList<>();
        for (String str : this.ns.keySet()) {
            arrayList.add(new a(str, this.ns.get(str).intValue()));
        }
        return arrayList;
    }

    @Override // com.google.android.gms.internal.ee.b
    public int bO() {
        return 7;
    }

    @Override // com.google.android.gms.internal.ee.b
    public int bP() {
        return 0;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        ec ecVar = CREATOR;
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.kZ;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        ec ecVar = CREATOR;
        ec.a(this, out, flags);
    }
}
