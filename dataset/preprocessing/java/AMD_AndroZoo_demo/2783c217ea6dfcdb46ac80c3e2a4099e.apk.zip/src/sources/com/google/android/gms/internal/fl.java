package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.ContentProviderClient;
import android.content.Context;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.a;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class fl {
    private final Context mContext;
    private final fp<fk> tM;
    private ContentProviderClient tN = null;
    private boolean tO = false;
    private HashMap<LocationListener, b> tP = new HashMap<>();

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private static class a extends Handler {
        private final LocationListener tQ;

        public a(LocationListener locationListener) {
            this.tQ = locationListener;
        }

        public a(LocationListener locationListener, Looper looper) {
            super(looper);
            this.tQ = locationListener;
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    this.tQ.onLocationChanged(new Location((Location) msg.obj));
                    return;
                default:
                    Log.e("LocationClientHelper", "unknown message in LocationHandler.handleMessage");
                    return;
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private static class b extends a.AbstractBinderC0046a {
        private Handler tR;

        b(LocationListener locationListener, Looper looper) {
            this.tR = looper == null ? new a(locationListener) : new a(locationListener, looper);
        }

        @Override // com.google.android.gms.location.a
        public void onLocationChanged(Location location) {
            if (this.tR == null) {
                Log.e("LocationClientHelper", "Received a location in client after calling removeLocationUpdates.");
                return;
            }
            Message obtain = Message.obtain();
            obtain.what = 1;
            obtain.obj = location;
            this.tR.sendMessage(obtain);
        }

        public void release() {
            this.tR = null;
        }
    }

    public fl(Context context, fp<fk> fpVar) {
        this.mContext = context;
        this.tM = fpVar;
    }

    public void dq() {
        if (this.tO) {
            setMockMode(false);
        }
    }

    public Location getLastLocation() {
        this.tM.bB();
        try {
            return this.tM.bC().dp();
        } catch (RemoteException e) {
            throw new IllegalStateException(e);
        }
    }

    public void removeAllListeners() {
        try {
            synchronized (this.tP) {
                for (b bVar : this.tP.values()) {
                    if (bVar != null) {
                        this.tM.bC().a(bVar);
                    }
                }
                this.tP.clear();
            }
        } catch (RemoteException e) {
            throw new IllegalStateException(e);
        }
    }

    public void removeLocationUpdates(PendingIntent callbackIntent) {
        this.tM.bB();
        try {
            this.tM.bC().a(callbackIntent);
        } catch (RemoteException e) {
            throw new IllegalStateException(e);
        }
    }

    public void removeLocationUpdates(LocationListener listener) {
        this.tM.bB();
        du.c(listener, "Invalid null listener");
        synchronized (this.tP) {
            b remove = this.tP.remove(listener);
            if (this.tN != null && this.tP.isEmpty()) {
                this.tN.release();
                this.tN = null;
            }
            if (remove != null) {
                remove.release();
                try {
                    this.tM.bC().a(remove);
                } catch (RemoteException e) {
                    throw new IllegalStateException(e);
                }
            }
        }
    }

    public void requestLocationUpdates(LocationRequest request, PendingIntent callbackIntent) {
        this.tM.bB();
        try {
            this.tM.bC().a(request, callbackIntent);
        } catch (RemoteException e) {
            throw new IllegalStateException(e);
        }
    }

    public void requestLocationUpdates(LocationRequest request, LocationListener listener, Looper looper) {
        this.tM.bB();
        if (looper == null) {
            du.c(Looper.myLooper(), "Can't create handler inside thread that has not called Looper.prepare()");
        }
        synchronized (this.tP) {
            b bVar = this.tP.get(listener);
            b bVar2 = bVar == null ? new b(listener, looper) : bVar;
            this.tP.put(listener, bVar2);
            try {
                this.tM.bC().a(request, bVar2, this.mContext.getPackageName());
            } catch (RemoteException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    public void setMockLocation(Location mockLocation) {
        this.tM.bB();
        try {
            this.tM.bC().setMockLocation(mockLocation);
        } catch (RemoteException e) {
            throw new IllegalStateException(e);
        }
    }

    public void setMockMode(boolean isMockMode) {
        this.tM.bB();
        try {
            this.tM.bC().setMockMode(isMockMode);
            this.tO = isMockMode;
        } catch (RemoteException e) {
            throw new IllegalStateException(e);
        }
    }
}
