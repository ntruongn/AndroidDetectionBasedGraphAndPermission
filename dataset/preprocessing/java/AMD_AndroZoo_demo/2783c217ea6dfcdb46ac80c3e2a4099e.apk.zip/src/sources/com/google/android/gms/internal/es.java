package com.google.android.gms.internal;

import android.os.Build;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class es {
    private static boolean K(int i) {
        return Build.VERSION.SDK_INT >= i;
    }

    public static boolean ck() {
        return K(11);
    }

    public static boolean cl() {
        return K(12);
    }

    public static boolean cm() {
        return K(13);
    }

    public static boolean cn() {
        return K(14);
    }

    public static boolean co() {
        return K(16);
    }

    public static boolean cp() {
        return K(17);
    }
}
