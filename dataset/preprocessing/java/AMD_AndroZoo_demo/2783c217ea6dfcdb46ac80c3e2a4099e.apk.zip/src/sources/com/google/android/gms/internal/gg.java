package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class gg implements SafeParcelable {
    public static final gh CREATOR = new gh();
    public final int versionCode;
    public final String xj;
    public final String xk;

    public gg(int i, String str, String str2) {
        this.versionCode = i;
        this.xj = str;
        this.xk = str2;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        gh ghVar = CREATOR;
        return 0;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || !(object instanceof gg)) {
            return false;
        }
        gg ggVar = (gg) object;
        return this.xk.equals(ggVar.xk) && this.xj.equals(ggVar.xj);
    }

    public int hashCode() {
        return ds.hashCode(this.xj, this.xk);
    }

    public String toString() {
        return ds.e(this).a(GoogleAuthUtil.KEY_CLIENT_PACKAGE_NAME, this.xj).a("locale", this.xk).toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        gh ghVar = CREATOR;
        gh.a(this, out, flags);
    }
}
