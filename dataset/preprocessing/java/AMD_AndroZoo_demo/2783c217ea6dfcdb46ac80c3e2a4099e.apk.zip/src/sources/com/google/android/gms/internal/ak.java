package com.google.android.gms.internal;

import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ak implements an {
    private final al fm;

    public ak(al alVar) {
        this.fm = alVar;
    }

    @Override // com.google.android.gms.internal.an
    public void a(cv cvVar, Map<String, String> map) {
        String str = map.get("name");
        if (str == null) {
            cs.v("App event with no name parameter.");
        } else {
            this.fm.onAppEvent(str, map.get("info"));
        }
    }
}
