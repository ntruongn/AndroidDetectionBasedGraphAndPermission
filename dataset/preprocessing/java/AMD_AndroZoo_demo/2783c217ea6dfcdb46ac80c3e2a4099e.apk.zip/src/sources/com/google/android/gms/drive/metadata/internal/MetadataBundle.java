package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.du;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class MetadataBundle implements SafeParcelable {
    public static final Parcelable.Creator<MetadataBundle> CREATOR = new d();
    final int kZ;
    final Bundle oT;

    /* JADX INFO: Access modifiers changed from: package-private */
    public MetadataBundle(int versionCode, Bundle valueBundle) {
        this.kZ = versionCode;
        this.oT = (Bundle) du.f(valueBundle);
        this.oT.setClassLoader(getClass().getClassLoader());
        for (String str : this.oT.keySet()) {
            if (c.P(str) == null) {
                this.oT.remove(str);
                Log.w("MetadataBundle", "Ignored unknown metadata field in bundle: " + str);
            }
        }
    }

    private MetadataBundle(Bundle valueBundle) {
        this(1, valueBundle);
    }

    public static <T> MetadataBundle a(MetadataField<T> metadataField, T t) {
        MetadataBundle cE = cE();
        cE.b(metadataField, t);
        return cE;
    }

    public static MetadataBundle a(MetadataBundle metadataBundle) {
        return new MetadataBundle(new Bundle(metadataBundle.oT));
    }

    public static MetadataBundle cE() {
        return new MetadataBundle(new Bundle());
    }

    public <T> T a(MetadataField<T> metadataField) {
        return metadataField.d(this.oT);
    }

    public <T> void b(MetadataField<T> metadataField, T t) {
        if (c.P(metadataField.getName()) == null) {
            throw new IllegalArgumentException("Unregistered field: " + metadataField.getName());
        }
        metadataField.a((MetadataField<T>) t, this.oT);
    }

    public Set<MetadataField<?>> cF() {
        HashSet hashSet = new HashSet();
        Iterator<String> it = this.oT.keySet().iterator();
        while (it.hasNext()) {
            hashSet.add(c.P(it.next()));
        }
        return hashSet;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MetadataBundle)) {
            return false;
        }
        MetadataBundle metadataBundle = (MetadataBundle) obj;
        Set<String> keySet = this.oT.keySet();
        if (!keySet.equals(metadataBundle.oT.keySet())) {
            return false;
        }
        for (String str : keySet) {
            if (!ds.equal(this.oT.get(str), metadataBundle.oT.get(str))) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int i = 1;
        Iterator<String> it = this.oT.keySet().iterator();
        while (true) {
            int i2 = i;
            if (!it.hasNext()) {
                return i2;
            }
            i = this.oT.get(it.next()).hashCode() + (i2 * 31);
        }
    }

    public String toString() {
        return "MetadataBundle [values=" + this.oT + "]";
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        d.a(this, dest, flags);
    }
}
