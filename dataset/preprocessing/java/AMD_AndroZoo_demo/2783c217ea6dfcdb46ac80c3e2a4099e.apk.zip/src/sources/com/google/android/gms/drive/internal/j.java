package com.google.android.gms.drive.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.internal.o;
import com.google.android.gms.internal.dh;
import com.google.android.gms.internal.dk;
import com.google.android.gms.internal.dq;
import com.google.android.gms.internal.du;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class j extends dk<o> {
    private final String jD;
    private DriveId ou;

    public j(Context context, dh dhVar, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener, String[] strArr) {
        super(context, connectionCallbacks, onConnectionFailedListener, strArr);
        this.jD = (String) du.c(dhVar.bt(), "Must call Api.ClientBuilder.setAccountName()");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.internal.dk
    public void a(int i, IBinder iBinder, Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(getClass().getClassLoader());
            this.ou = (DriveId) bundle.getParcelable("com.google.android.gms.drive.root_id");
        }
        super.a(i, iBinder, bundle);
    }

    @Override // com.google.android.gms.internal.dk
    protected void a(dq dqVar, dk.d dVar) throws RemoteException {
        String packageName = getContext().getPackageName();
        du.f(dVar);
        du.f(packageName);
        du.f(bA());
        Log.d("DriveClientImpl", "Retrieving drive service");
        dqVar.a(dVar, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, packageName, bA(), this.jD, new Bundle());
    }

    @Override // com.google.android.gms.internal.dk
    protected String am() {
        return "com.google.android.gms.drive.ApiService.START";
    }

    @Override // com.google.android.gms.internal.dk
    protected String an() {
        return "com.google.android.gms.drive.internal.IDriveService";
    }

    public o cu() {
        return bC();
    }

    public DriveId cv() {
        return this.ou;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.internal.dk
    /* renamed from: z, reason: merged with bridge method [inline-methods] */
    public o p(IBinder iBinder) {
        return o.a.A(iBinder);
    }
}
