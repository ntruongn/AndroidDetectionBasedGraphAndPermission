package com.google.android.gms.auth;

import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public class GooglePlayServicesAvailabilityException extends UserRecoverableAuthException {
    private final int jW;

    /* JADX INFO: Access modifiers changed from: package-private */
    public GooglePlayServicesAvailabilityException(int connectionStatusCode, String msg, Intent intent) {
        super(msg, intent);
        this.jW = connectionStatusCode;
    }

    public int getConnectionStatusCode() {
        return this.jW;
    }
}
