package com.google.android.gms.appstate;

import com.google.android.gms.internal.ds;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class a implements AppState {
    private final int jF;
    private final String jG;
    private final byte[] jH;
    private final boolean jI;
    private final String jJ;
    private final byte[] jK;

    public a(AppState appState) {
        this.jF = appState.getKey();
        this.jG = appState.getLocalVersion();
        this.jH = appState.getLocalData();
        this.jI = appState.hasConflict();
        this.jJ = appState.getConflictVersion();
        this.jK = appState.getConflictData();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int a(AppState appState) {
        return ds.hashCode(Integer.valueOf(appState.getKey()), appState.getLocalVersion(), appState.getLocalData(), Boolean.valueOf(appState.hasConflict()), appState.getConflictVersion(), appState.getConflictData());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a(AppState appState, Object obj) {
        if (!(obj instanceof AppState)) {
            return false;
        }
        if (appState == obj) {
            return true;
        }
        AppState appState2 = (AppState) obj;
        return ds.equal(Integer.valueOf(appState2.getKey()), Integer.valueOf(appState.getKey())) && ds.equal(appState2.getLocalVersion(), appState.getLocalVersion()) && ds.equal(appState2.getLocalData(), appState.getLocalData()) && ds.equal(Boolean.valueOf(appState2.hasConflict()), Boolean.valueOf(appState.hasConflict())) && ds.equal(appState2.getConflictVersion(), appState.getConflictVersion()) && ds.equal(appState2.getConflictData(), appState.getConflictData());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String b(AppState appState) {
        return ds.e(appState).a("Key", Integer.valueOf(appState.getKey())).a("LocalVersion", appState.getLocalVersion()).a("LocalData", appState.getLocalData()).a("HasConflict", Boolean.valueOf(appState.hasConflict())).a("ConflictVersion", appState.getConflictVersion()).a("ConflictData", appState.getConflictData()).toString();
    }

    @Override // com.google.android.gms.common.data.Freezable
    /* renamed from: aJ, reason: merged with bridge method [inline-methods] */
    public AppState freeze() {
        return this;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    @Override // com.google.android.gms.appstate.AppState
    public byte[] getConflictData() {
        return this.jK;
    }

    @Override // com.google.android.gms.appstate.AppState
    public String getConflictVersion() {
        return this.jJ;
    }

    @Override // com.google.android.gms.appstate.AppState
    public int getKey() {
        return this.jF;
    }

    @Override // com.google.android.gms.appstate.AppState
    public byte[] getLocalData() {
        return this.jH;
    }

    @Override // com.google.android.gms.appstate.AppState
    public String getLocalVersion() {
        return this.jG;
    }

    @Override // com.google.android.gms.appstate.AppState
    public boolean hasConflict() {
        return this.jI;
    }

    public int hashCode() {
        return a(this);
    }

    @Override // com.google.android.gms.common.data.Freezable
    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        return b(this);
    }
}
