package com.google.android.gms.common.images;

import android.app.ActivityManager;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.ResultReceiver;
import android.util.Log;
import android.widget.ImageView;
import com.google.android.gms.common.images.a;
import com.google.android.gms.internal.dg;
import com.google.android.gms.internal.dy;
import com.google.android.gms.internal.es;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class ImageManager {
    private static ImageManager lA;
    private static ImageManager lB;
    private static final Object ly = new Object();
    private static HashSet<Uri> lz = new HashSet<>();
    private final b lD;
    private final Map<com.google.android.gms.common.images.a, ImageReceiver> lE;
    private final Map<Uri, ImageReceiver> lF;
    private final Context mContext;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService lC = Executors.newFixedThreadPool(4);

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class ImageReceiver extends ResultReceiver {
        private final ArrayList<com.google.android.gms.common.images.a> lG;
        boolean lH;
        private final Uri mUri;

        ImageReceiver(Uri uri) {
            super(new Handler(Looper.getMainLooper()));
            this.lH = false;
            this.mUri = uri;
            this.lG = new ArrayList<>();
        }

        public void bp() {
            Intent intent = new Intent("com.google.android.gms.common.images.LOAD_IMAGE");
            intent.putExtra("com.google.android.gms.extras.uri", this.mUri);
            intent.putExtra("com.google.android.gms.extras.resultReceiver", this);
            intent.putExtra("com.google.android.gms.extras.priority", 3);
            ImageManager.this.mContext.sendBroadcast(intent);
        }

        public void c(com.google.android.gms.common.images.a aVar) {
            dg.a(!this.lH, "Cannot add an ImageRequest when mHandlingRequests is true");
            dg.B("ImageReceiver.addImageRequest() must be called in the main thread");
            this.lG.add(aVar);
        }

        public void d(com.google.android.gms.common.images.a aVar) {
            dg.a(!this.lH, "Cannot remove an ImageRequest when mHandlingRequests is true");
            dg.B("ImageReceiver.removeImageRequest() must be called in the main thread");
            this.lG.remove(aVar);
        }

        @Override // android.os.ResultReceiver
        public void onReceiveResult(int resultCode, Bundle resultData) {
            ImageManager.this.lC.execute(new c(this.mUri, (ParcelFileDescriptor) resultData.getParcelable("com.google.android.gms.extra.fileDescriptor")));
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public interface OnImageLoadedListener {
        void onImageLoaded(Uri uri, Drawable drawable, boolean z);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a {
        static int a(ActivityManager activityManager) {
            return activityManager.getLargeMemoryClass();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class b extends dy<a.C0002a, Bitmap> {
        public b(Context context) {
            super(q(context));
        }

        private static int q(Context context) {
            ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
            return (int) (((((context.getApplicationInfo().flags & 1048576) != 0) && es.ck()) ? a.a(activityManager) : activityManager.getMemoryClass()) * 1048576 * 0.33f);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dy
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public int sizeOf(a.C0002a c0002a, Bitmap bitmap) {
            return bitmap.getHeight() * bitmap.getRowBytes();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.google.android.gms.internal.dy
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void entryRemoved(boolean z, a.C0002a c0002a, Bitmap bitmap, Bitmap bitmap2) {
            super.entryRemoved(z, c0002a, bitmap, bitmap2);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private final class c implements Runnable {
        private final ParcelFileDescriptor lJ;
        private final Uri mUri;

        public c(Uri uri, ParcelFileDescriptor parcelFileDescriptor) {
            this.mUri = uri;
            this.lJ = parcelFileDescriptor;
        }

        @Override // java.lang.Runnable
        public void run() {
            dg.C("LoadBitmapFromDiskRunnable can't be executed in the main thread");
            boolean z = false;
            Bitmap bitmap = null;
            if (this.lJ != null) {
                try {
                    bitmap = BitmapFactory.decodeFileDescriptor(this.lJ.getFileDescriptor());
                } catch (OutOfMemoryError e) {
                    Log.e("ImageManager", "OOM while loading bitmap for uri: " + this.mUri, e);
                    z = true;
                }
                try {
                    this.lJ.close();
                } catch (IOException e2) {
                    Log.e("ImageManager", "closed failed", e2);
                }
            }
            CountDownLatch countDownLatch = new CountDownLatch(1);
            ImageManager.this.mHandler.post(new f(this.mUri, bitmap, z, countDownLatch));
            try {
                countDownLatch.await();
            } catch (InterruptedException e3) {
                Log.w("ImageManager", "Latch interrupted while posting " + this.mUri);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public final class d implements Runnable {
        private final com.google.android.gms.common.images.a lK;

        public d(com.google.android.gms.common.images.a aVar) {
            this.lK = aVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            dg.B("LoadImageRunnable must be executed on the main thread");
            ImageManager.this.b(this.lK);
            a.C0002a c0002a = this.lK.lM;
            if (c0002a.uri == null) {
                this.lK.b(ImageManager.this.mContext, true);
                return;
            }
            Bitmap a = ImageManager.this.a(c0002a);
            if (a != null) {
                this.lK.a(ImageManager.this.mContext, a, true);
                return;
            }
            this.lK.r(ImageManager.this.mContext);
            ImageReceiver imageReceiver = (ImageReceiver) ImageManager.this.lF.get(c0002a.uri);
            if (imageReceiver == null) {
                imageReceiver = new ImageReceiver(c0002a.uri);
                ImageManager.this.lF.put(c0002a.uri, imageReceiver);
            }
            imageReceiver.c(this.lK);
            if (this.lK.lP != 1) {
                ImageManager.this.lE.put(this.lK, imageReceiver);
            }
            synchronized (ImageManager.ly) {
                if (!ImageManager.lz.contains(c0002a.uri)) {
                    ImageManager.lz.add(c0002a.uri);
                    imageReceiver.bp();
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class e implements ComponentCallbacks2 {
        private final b lD;

        public e(b bVar) {
            this.lD = bVar;
        }

        @Override // android.content.ComponentCallbacks
        public void onConfigurationChanged(Configuration newConfig) {
        }

        @Override // android.content.ComponentCallbacks
        public void onLowMemory() {
            this.lD.evictAll();
        }

        @Override // android.content.ComponentCallbacks2
        public void onTrimMemory(int level) {
            if (level >= 60) {
                this.lD.evictAll();
            } else if (level >= 20) {
                this.lD.trimToSize(this.lD.size() / 2);
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    private final class f implements Runnable {
        private final CountDownLatch kv;
        private boolean lL;
        private final Bitmap mBitmap;
        private final Uri mUri;

        public f(Uri uri, Bitmap bitmap, boolean z, CountDownLatch countDownLatch) {
            this.mUri = uri;
            this.mBitmap = bitmap;
            this.lL = z;
            this.kv = countDownLatch;
        }

        private void a(ImageReceiver imageReceiver, boolean z) {
            imageReceiver.lH = true;
            ArrayList arrayList = imageReceiver.lG;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                com.google.android.gms.common.images.a aVar = (com.google.android.gms.common.images.a) arrayList.get(i);
                if (z) {
                    aVar.a(ImageManager.this.mContext, this.mBitmap, false);
                } else {
                    aVar.b(ImageManager.this.mContext, false);
                }
                if (aVar.lP != 1) {
                    ImageManager.this.lE.remove(aVar);
                }
            }
            imageReceiver.lH = false;
        }

        @Override // java.lang.Runnable
        public void run() {
            dg.B("OnBitmapLoadedRunnable must be executed in the main thread");
            boolean z = this.mBitmap != null;
            if (ImageManager.this.lD != null) {
                if (this.lL) {
                    ImageManager.this.lD.evictAll();
                    System.gc();
                    this.lL = false;
                    ImageManager.this.mHandler.post(this);
                    return;
                }
                if (z) {
                    ImageManager.this.lD.put(new a.C0002a(this.mUri), this.mBitmap);
                }
            }
            ImageReceiver imageReceiver = (ImageReceiver) ImageManager.this.lF.remove(this.mUri);
            if (imageReceiver != null) {
                a(imageReceiver, z);
            }
            this.kv.countDown();
            synchronized (ImageManager.ly) {
                ImageManager.lz.remove(this.mUri);
            }
        }
    }

    private ImageManager(Context context, boolean withMemoryCache) {
        this.mContext = context.getApplicationContext();
        if (withMemoryCache) {
            this.lD = new b(this.mContext);
            if (es.cn()) {
                bm();
            }
        } else {
            this.lD = null;
        }
        this.lE = new HashMap();
        this.lF = new HashMap();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Bitmap a(a.C0002a c0002a) {
        if (this.lD == null) {
            return null;
        }
        return this.lD.get(c0002a);
    }

    public static ImageManager a(Context context, boolean z) {
        if (z) {
            if (lB == null) {
                lB = new ImageManager(context, true);
            }
            return lB;
        }
        if (lA == null) {
            lA = new ImageManager(context, false);
        }
        return lA;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean b(com.google.android.gms.common.images.a aVar) {
        ImageReceiver imageReceiver;
        dg.B("ImageManager.cleanupHashMaps() must be called in the main thread");
        if (aVar.lP != 1 && (imageReceiver = this.lE.get(aVar)) != null) {
            if (imageReceiver.lH) {
                return false;
            }
            this.lE.remove(aVar);
            imageReceiver.d(aVar);
            return true;
        }
        return true;
    }

    private void bm() {
        this.mContext.registerComponentCallbacks(new e(this.lD));
    }

    public static ImageManager create(Context context) {
        return a(context, false);
    }

    public void a(com.google.android.gms.common.images.a aVar) {
        dg.B("ImageManager.loadImage() must be called in the main thread");
        boolean b2 = b(aVar);
        d dVar = new d(aVar);
        if (b2) {
            dVar.run();
        } else {
            this.mHandler.post(dVar);
        }
    }

    public void loadImage(ImageView imageView, int resId) {
        com.google.android.gms.common.images.a aVar = new com.google.android.gms.common.images.a(resId);
        aVar.a(imageView);
        a(aVar);
    }

    public void loadImage(ImageView imageView, Uri uri) {
        com.google.android.gms.common.images.a aVar = new com.google.android.gms.common.images.a(uri);
        aVar.a(imageView);
        a(aVar);
    }

    public void loadImage(ImageView imageView, Uri uri, int defaultResId) {
        com.google.android.gms.common.images.a aVar = new com.google.android.gms.common.images.a(uri);
        aVar.w(defaultResId);
        aVar.a(imageView);
        a(aVar);
    }

    public void loadImage(OnImageLoadedListener listener, Uri uri) {
        com.google.android.gms.common.images.a aVar = new com.google.android.gms.common.images.a(uri);
        aVar.a(listener);
        a(aVar);
    }

    public void loadImage(OnImageLoadedListener listener, Uri uri, int defaultResId) {
        com.google.android.gms.common.images.a aVar = new com.google.android.gms.common.images.a(uri);
        aVar.w(defaultResId);
        aVar.a(listener);
        a(aVar);
    }
}
