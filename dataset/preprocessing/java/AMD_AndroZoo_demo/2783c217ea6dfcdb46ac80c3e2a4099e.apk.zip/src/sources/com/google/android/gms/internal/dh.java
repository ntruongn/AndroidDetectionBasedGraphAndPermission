package com.google.android.gms.internal;

import android.os.Parcel;
import android.view.View;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
public final class dh {
    private final View kQ;
    private final a mt;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/2783c217ea6dfcdb46ac80c3e2a4099e.apk/classes.dex */
    public static final class a implements SafeParcelable {
        public static final dt CREATOR = new dt();
        private final String jD;
        private final int kP;
        private final String kR;
        private final int kZ;
        private final List<String> mu;

        /* JADX INFO: Access modifiers changed from: package-private */
        public a(int i, String str, List<String> list, int i2, String str2) {
            this.mu = new ArrayList();
            this.kZ = i;
            this.jD = str;
            this.mu.addAll(list);
            this.kP = i2;
            this.kR = str2;
        }

        public a(String str, Collection<String> collection, int i, String str2) {
            this(3, str, new ArrayList(collection), i, str2);
        }

        public String bt() {
            return this.jD != null ? this.jD : "<<default account>>";
        }

        public List<String> bu() {
            return new ArrayList(this.mu);
        }

        public int bv() {
            return this.kP;
        }

        public String bw() {
            return this.kR;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public String getAccountName() {
            return this.jD;
        }

        public int getVersionCode() {
            return this.kZ;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            dt.a(this, out, flags);
        }
    }

    public dh(String str, Collection<String> collection, int i, View view, String str2) {
        this.mt = new a(str, collection, i, str2);
        this.kQ = view;
    }

    public String bt() {
        return this.mt.bt();
    }

    public List<String> bu() {
        return this.mt.bu();
    }
}
