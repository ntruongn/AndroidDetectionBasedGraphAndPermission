package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.IntentSender;
import android.os.Parcel;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.ee;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class Status implements Result, SafeParcelable {
    private final int kg;
    private final int mC;
    private final PendingIntent mPendingIntent;
    private final String nD;
    public static final Status nA = new Status(0, null, null);
    public static final Status nB = new Status(14, null, null);
    public static final Status nC = new Status(15, null, null);
    public static final StatusCreator CREATOR = new StatusCreator();

    public Status(int i) {
        this(1, i, null, null);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Status(int i, int i2, String str, PendingIntent pendingIntent) {
        this.kg = i;
        this.mC = i2;
        this.nD = str;
        this.mPendingIntent = pendingIntent;
    }

    public Status(int i, String str, PendingIntent pendingIntent) {
        this(1, i, str, pendingIntent);
    }

    private String bh() {
        return this.nD != null ? this.nD : CommonStatusCodes.getStatusCodeString(this.mC);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public PendingIntent bs() {
        return this.mPendingIntent;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String bt() {
        return this.nD;
    }

    @Deprecated
    public ConnectionResult bu() {
        return new ConnectionResult(this.mC, this.mPendingIntent);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.kg == status.kg && this.mC == status.mC && ee.equal(this.nD, status.nD) && ee.equal(this.mPendingIntent, status.mPendingIntent);
    }

    public PendingIntent getResolution() {
        return this.mPendingIntent;
    }

    @Override // com.google.android.gms.common.api.Result
    public Status getStatus() {
        return this;
    }

    public int getStatusCode() {
        return this.mC;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.kg;
    }

    public boolean hasResolution() {
        return this.mPendingIntent != null;
    }

    public int hashCode() {
        return ee.hashCode(Integer.valueOf(this.kg), Integer.valueOf(this.mC), this.nD, this.mPendingIntent);
    }

    public boolean isInterrupted() {
        return this.mC == 14;
    }

    public boolean isSuccess() {
        return this.mC <= 0;
    }

    public void startResolutionForResult(Activity activity, int i) throws IntentSender.SendIntentException {
        if (hasResolution()) {
            activity.startIntentSenderForResult(this.mPendingIntent.getIntentSender(), i, null, 0, 0, 0);
        }
    }

    public String toString() {
        return ee.e(this).a("statusCode", bh()).a("resolution", this.mPendingIntent).toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        StatusCreator.a(this, parcel, i);
    }
}
