package com.google.android.gms.ads;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public abstract class AdListener {
    public void onAdClosed() {
    }

    public void onAdFailedToLoad(int i) {
    }

    public void onAdLeftApplication() {
    }

    public void onAdLoaded() {
    }

    public void onAdOpened() {
    }
}
