package com.google.android.gms.internal;

import android.util.Log;
import com.google.ads.AdRequest;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class ct {
    public static void a(String str, Throwable th) {
        if (n(3)) {
            Log.d(AdRequest.LOGTAG, str, th);
        }
    }

    public static void b(String str, Throwable th) {
        if (n(5)) {
            Log.w(AdRequest.LOGTAG, str, th);
        }
    }

    public static boolean n(int i) {
        return (i >= 5 || Log.isLoggable(AdRequest.LOGTAG, i)) && i != 2;
    }

    public static void r(String str) {
        if (n(3)) {
            Log.d(AdRequest.LOGTAG, str);
        }
    }

    public static void s(String str) {
        if (n(6)) {
            Log.e(AdRequest.LOGTAG, str);
        }
    }

    public static void t(String str) {
        if (n(4)) {
            Log.i(AdRequest.LOGTAG, str);
        }
    }

    public static void u(String str) {
        if (n(2)) {
            Log.v(AdRequest.LOGTAG, str);
        }
    }

    public static void v(String str) {
        if (n(5)) {
            Log.w(AdRequest.LOGTAG, str);
        }
    }
}
