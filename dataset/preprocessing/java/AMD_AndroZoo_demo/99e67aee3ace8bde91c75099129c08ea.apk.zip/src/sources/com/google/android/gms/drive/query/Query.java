package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.internal.LogicalFilter;
import com.google.android.gms.drive.query.internal.Operator;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class Query implements SafeParcelable {
    public static final Parcelable.Creator<Query> CREATOR = new a();
    final int kg;
    LogicalFilter rO;
    String rP;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public static class Builder {
        private String rP;
        private final List<Filter> rQ = new ArrayList();

        public Builder addFilter(Filter filter) {
            this.rQ.add(filter);
            return this;
        }

        public Query build() {
            return new Query(new LogicalFilter(Operator.si, this.rQ), this.rP);
        }

        public Builder setPageToken(String str) {
            this.rP = str;
            return this;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Query(int i, LogicalFilter logicalFilter, String str) {
        this.kg = i;
        this.rO = logicalFilter;
        this.rP = str;
    }

    Query(LogicalFilter logicalFilter, String str) {
        this(1, logicalFilter, str);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public Filter getFilter() {
        return this.rO;
    }

    public String getPageToken() {
        return this.rP;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        a.a(this, parcel, i);
    }
}
