package com.google.android.gms.drive;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class MetadataBuffer extends DataBuffer<Metadata> {
    private static final String[] qS;
    private final String qT;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public static class a extends Metadata {
        private final DataHolder nE;
        private final int nH;
        private final int qU;

        public a(DataHolder dataHolder, int i) {
            this.nE = dataHolder;
            this.qU = i;
            this.nH = dataHolder.C(i);
        }

        @Override // com.google.android.gms.drive.Metadata
        protected <T> T a(MetadataField<T> metadataField) {
            return metadataField.c(this.nE, this.qU, this.nH);
        }

        @Override // com.google.android.gms.common.data.Freezable
        /* renamed from: cK, reason: merged with bridge method [inline-methods] */
        public Metadata freeze() {
            MetadataBundle cX = MetadataBundle.cX();
            Iterator<MetadataField<?>> it2 = com.google.android.gms.drive.metadata.internal.c.cW().iterator();
            while (it2.hasNext()) {
                it2.next().a(this.nE, cX, this.qU, this.nH);
            }
            return new b(cX);
        }

        @Override // com.google.android.gms.common.data.Freezable
        public boolean isDataValid() {
            return !this.nE.isClosed();
        }
    }

    static {
        ArrayList arrayList = new ArrayList();
        Iterator<MetadataField<?>> it2 = com.google.android.gms.drive.metadata.internal.c.cW().iterator();
        while (it2.hasNext()) {
            arrayList.addAll(it2.next().cV());
        }
        qS = (String[]) arrayList.toArray(new String[0]);
    }

    public MetadataBuffer(DataHolder dataHolder, String str) {
        super(dataHolder);
        this.qT = str;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.google.android.gms.common.data.DataBuffer
    public Metadata get(int i) {
        return new a(this.nE, i);
    }

    public String getNextPageToken() {
        return this.qT;
    }
}
