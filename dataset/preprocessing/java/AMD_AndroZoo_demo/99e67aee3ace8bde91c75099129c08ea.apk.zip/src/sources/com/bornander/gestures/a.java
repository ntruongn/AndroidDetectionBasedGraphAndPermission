package com.bornander.gestures;

import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;

/* compiled from: GestureListener.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class a extends GestureDetector.SimpleOnGestureListener {
    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnDoubleTapListener
    public boolean onDoubleTap(MotionEvent motionEvent) {
        Log.i("Double Tap", "Tapped at: (" + motionEvent.getX() + "," + motionEvent.getY() + ")");
        return true;
    }
}
