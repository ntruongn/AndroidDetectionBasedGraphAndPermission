package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.OrderedMetadataField;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class fi {
    public static final OrderedMetadataField<Date> rJ = new com.google.android.gms.drive.metadata.internal.b("modified");
    public static final OrderedMetadataField<Date> rK = new com.google.android.gms.drive.metadata.internal.b("modifiedByMe");
    public static final OrderedMetadataField<Date> rL = new com.google.android.gms.drive.metadata.internal.b("created");
    public static final OrderedMetadataField<Date> rM = new com.google.android.gms.drive.metadata.internal.b("sharedWithMe");
}
