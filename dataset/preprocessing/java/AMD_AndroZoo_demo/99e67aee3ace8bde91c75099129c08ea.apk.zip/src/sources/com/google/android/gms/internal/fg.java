package com.google.android.gms.internal;

import android.os.Build;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class fg {
    private static boolean X(int i) {
        return Build.VERSION.SDK_INT >= i;
    }

    public static boolean cD() {
        return X(11);
    }

    public static boolean cE() {
        return X(12);
    }

    public static boolean cF() {
        return X(13);
    }

    public static boolean cG() {
        return X(14);
    }

    public static boolean cH() {
        return X(16);
    }

    public static boolean cI() {
        return X(17);
    }
}
