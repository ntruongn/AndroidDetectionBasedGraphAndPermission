package com.google.ads.mediation.jsadapter;

import com.google.ads.mediation.MediationServerParameters;
import com.vklovoxqp.hjmcpkkxt140244.BuildConfig;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class JavascriptServerParameters extends MediationServerParameters {

    @MediationServerParameters.Parameter(name = "adxtym_height", required = false)
    public Integer height;

    @MediationServerParameters.Parameter(name = "adxtym_html", required = BuildConfig.DEBUG)
    public String htmlScript;

    @MediationServerParameters.Parameter(name = "adxtym_passback_url", required = false)
    public String passBackUrl;

    @MediationServerParameters.Parameter(name = "adxtym_width", required = false)
    public Integer width;
}
