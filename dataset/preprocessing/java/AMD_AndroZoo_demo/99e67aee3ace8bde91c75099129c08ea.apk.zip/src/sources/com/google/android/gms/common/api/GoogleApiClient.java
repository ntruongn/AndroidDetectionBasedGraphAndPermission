package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.a;
import com.google.android.gms.internal.dt;
import com.google.android.gms.internal.dx;
import com.google.android.gms.internal.eg;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class GoogleApiClient {
    private final Object mV;
    private final a nc;
    private final dx ne;
    final Queue<b<?>> nf;
    private ConnectionResult ng;
    private int nh;
    private int ni;
    private int nj;
    private final Bundle nk;
    private final Map<Api.b<?>, Api.a> nl;
    private boolean nm;
    final Set<b> nn;
    final ConnectionCallbacks no;
    private final dx.b np;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public interface ApiOptions {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public static final class Builder {
        private String jG;
        private final Context mContext;
        private final Set<String> ns;
        private int nt;
        private View nu;
        private String nv;
        private final Map<Api, ApiOptions> nw;
        private final Set<ConnectionCallbacks> nx;
        private final Set<OnConnectionFailedListener> ny;

        public Builder(Context context) {
            this.ns = new HashSet();
            this.nw = new HashMap();
            this.nx = new HashSet();
            this.ny = new HashSet();
            this.mContext = context;
            this.nv = context.getPackageName();
        }

        public Builder(Context context, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            this(context);
            eg.b(connectionCallbacks, "Must provide a connected listener");
            this.nx.add(connectionCallbacks);
            eg.b(onConnectionFailedListener, "Must provide a connection failed listener");
            this.ny.add(onConnectionFailedListener);
        }

        public Builder addApi(Api api) {
            return addApi(api, null);
        }

        public Builder addApi(Api api, ApiOptions apiOptions) {
            this.nw.put(api, apiOptions);
            List<Scope> bk = api.bk();
            int size = bk.size();
            for (int i = 0; i < size; i++) {
                this.ns.add(bk.get(i).br());
            }
            return this;
        }

        public Builder addConnectionCallbacks(ConnectionCallbacks connectionCallbacks) {
            this.nx.add(connectionCallbacks);
            return this;
        }

        public Builder addOnConnectionFailedListener(OnConnectionFailedListener onConnectionFailedListener) {
            this.ny.add(onConnectionFailedListener);
            return this;
        }

        public Builder addScope(Scope scope) {
            this.ns.add(scope.br());
            return this;
        }

        public dt bq() {
            return new dt(this.jG, this.ns, this.nt, this.nu, this.nv);
        }

        public GoogleApiClient build() {
            return new GoogleApiClient(this.mContext, bq(), this.nw, this.nx, this.ny);
        }

        public Builder setAccountName(String str) {
            this.jG = str;
            return this;
        }

        public Builder setGravityForPopups(int i) {
            this.nt = i;
            return this;
        }

        public Builder setViewForPopups(View view) {
            this.nu = view;
            return this;
        }

        public Builder useDefaultAccount() {
            return setAccountName("<<default account>>");
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public interface ConnectionCallbacks {
        public static final int CAUSE_NETWORK_LOST = 2;
        public static final int CAUSE_SERVICE_DISCONNECTED = 1;

        void onConnected(Bundle bundle);

        void onConnectionSuspended(int i);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public interface OnConnectionFailedListener extends GooglePlayServicesClient.OnConnectionFailedListener {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public interface a {
        void b(b bVar);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public interface b<A extends Api.a> {
        void a(a aVar);

        void b(A a);

        Api.b<A> bj();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private GoogleApiClient(Context context, dt dtVar, Map<Api, ApiOptions> map, Set<ConnectionCallbacks> set, Set<OnConnectionFailedListener> set2) {
        this.mV = new Object();
        this.nf = new LinkedList();
        this.ni = 4;
        this.nk = new Bundle();
        this.nl = new HashMap();
        this.nn = new HashSet();
        this.nc = new a() { // from class: com.google.android.gms.common.api.GoogleApiClient.1
            @Override // com.google.android.gms.common.api.GoogleApiClient.a
            public void b(b bVar) {
                synchronized (GoogleApiClient.this.mV) {
                    GoogleApiClient.this.nn.remove(bVar);
                }
            }
        };
        this.no = new ConnectionCallbacks() { // from class: com.google.android.gms.common.api.GoogleApiClient.2
            @Override // com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks
            public void onConnected(Bundle bundle) {
                synchronized (GoogleApiClient.this.mV) {
                    if (GoogleApiClient.this.ni == 1) {
                        if (bundle != null) {
                            GoogleApiClient.this.nk.putAll(bundle);
                        }
                        GoogleApiClient.this.bn();
                    }
                }
            }

            @Override // com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks
            public void onConnectionSuspended(int i) {
                synchronized (GoogleApiClient.this.mV) {
                    GoogleApiClient.this.A(i);
                    if (i == 2) {
                        GoogleApiClient.this.connect();
                    }
                }
            }
        };
        this.np = new dx.b() { // from class: com.google.android.gms.common.api.GoogleApiClient.3
            @Override // com.google.android.gms.internal.dx.b
            public Bundle aU() {
                return null;
            }

            @Override // com.google.android.gms.internal.dx.b
            public boolean bp() {
                return GoogleApiClient.this.nm;
            }

            @Override // com.google.android.gms.internal.dx.b
            public boolean isConnected() {
                return GoogleApiClient.this.isConnected();
            }
        };
        this.ne = new dx(context, this.np);
        Iterator<ConnectionCallbacks> it2 = set.iterator();
        while (it2.hasNext()) {
            this.ne.registerConnectionCallbacks(it2.next());
        }
        Iterator<OnConnectionFailedListener> it3 = set2.iterator();
        while (it3.hasNext()) {
            this.ne.registerConnectionFailedListener(it3.next());
        }
        for (Api api : map.keySet()) {
            final Api.b<?> bj = api.bj();
            this.nl.put(bj, bj.b(context, dtVar, map.get(api), this.no, new OnConnectionFailedListener() { // from class: com.google.android.gms.common.api.GoogleApiClient.4
                @Override // com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener
                public void onConnectionFailed(ConnectionResult connectionResult) {
                    synchronized (GoogleApiClient.this.mV) {
                        if (GoogleApiClient.this.ng == null || bj.getPriority() < GoogleApiClient.this.nh) {
                            GoogleApiClient.this.ng = connectionResult;
                            GoogleApiClient.this.nh = bj.getPriority();
                        }
                        GoogleApiClient.this.bn();
                    }
                }
            }));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void A(int i) {
        synchronized (this.mV) {
            if (this.ni != 3) {
                boolean isConnected = isConnected();
                this.ni = 3;
                if (i == -1) {
                    this.nf.clear();
                }
                for (b bVar : this.nn) {
                    if (bVar instanceof Releasable) {
                        try {
                            ((Releasable) bVar).release();
                        } catch (Exception e) {
                            Log.w("GoogleApiClient", "Unable to release " + bVar, e);
                        }
                    }
                }
                this.nn.clear();
                this.nm = false;
                for (Api.a aVar : this.nl.values()) {
                    if (aVar.isConnected()) {
                        aVar.disconnect();
                    }
                }
                this.nm = true;
                this.ni = 4;
                if (isConnected) {
                    if (i != -1) {
                        this.ne.J(i);
                    }
                    this.nm = false;
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private <A extends Api.a> void a(b<A> bVar) {
        synchronized (this.mV) {
            eg.a(isConnected(), "GoogleApiClient is not connected yet.");
            eg.a(bVar.bj() != null, "This task can not be executed or enqueued (it's probably a Batch or malformed)");
            if (bVar instanceof Releasable) {
                this.nn.add(bVar);
                bVar.a(this.nc);
            }
            bVar.b(a(bVar.bj()));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void bn() {
        synchronized (this.mV) {
            this.nj--;
            if (this.nj == 0) {
                if (this.ng != null) {
                    A(3);
                    this.ne.a(this.ng);
                    this.nm = false;
                } else {
                    this.ni = 2;
                    bo();
                    this.ne.b(this.nk.isEmpty() ? null : this.nk);
                }
            }
        }
    }

    private void bo() {
        eg.a(isConnected(), "GoogleApiClient is not connected yet.");
        synchronized (this.mV) {
            while (!this.nf.isEmpty()) {
                a(this.nf.remove());
            }
        }
    }

    public <C extends Api.a> C a(Api.b<C> bVar) {
        C c = (C) this.nl.get(bVar);
        eg.b(c, "Appropriate Api was not requested.");
        return c;
    }

    public <A extends Api.a, T extends a.AbstractC0007a<? extends Result, A>> T a(T t) {
        synchronized (this.mV) {
            if (isConnected()) {
                b(t);
            } else {
                this.nf.add(t);
            }
        }
        return t;
    }

    public <A extends Api.a, T extends a.AbstractC0007a<? extends Result, A>> T b(T t) {
        eg.a(isConnected(), "GoogleApiClient is not connected yet.");
        bo();
        a((b) t);
        return t;
    }

    public void connect() {
        synchronized (this.mV) {
            if (isConnected() || isConnecting()) {
                return;
            }
            this.nm = true;
            this.ng = null;
            this.ni = 1;
            this.nk.clear();
            this.nj = this.nl.size();
            Iterator<Api.a> it2 = this.nl.values().iterator();
            while (it2.hasNext()) {
                it2.next().connect();
            }
        }
    }

    public void disconnect() {
        A(-1);
    }

    public boolean isConnected() {
        boolean z;
        synchronized (this.mV) {
            z = this.ni == 2;
        }
        return z;
    }

    public boolean isConnecting() {
        boolean z;
        synchronized (this.mV) {
            z = this.ni == 1;
        }
        return z;
    }

    public boolean isConnectionCallbacksRegistered(ConnectionCallbacks connectionCallbacks) {
        return this.ne.isConnectionCallbacksRegistered(connectionCallbacks);
    }

    public boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener onConnectionFailedListener) {
        return this.ne.isConnectionFailedListenerRegistered(onConnectionFailedListener);
    }

    public void reconnect() {
        disconnect();
        connect();
    }

    public void registerConnectionCallbacks(ConnectionCallbacks connectionCallbacks) {
        this.ne.registerConnectionCallbacks(connectionCallbacks);
    }

    public void registerConnectionFailedListener(OnConnectionFailedListener onConnectionFailedListener) {
        this.ne.registerConnectionFailedListener(onConnectionFailedListener);
    }

    public void unregisterConnectionCallbacks(ConnectionCallbacks connectionCallbacks) {
        this.ne.unregisterConnectionCallbacks(connectionCallbacks);
    }

    public void unregisterConnectionFailedListener(OnConnectionFailedListener onConnectionFailedListener) {
        this.ne.unregisterConnectionFailedListener(onConnectionFailedListener);
    }
}
