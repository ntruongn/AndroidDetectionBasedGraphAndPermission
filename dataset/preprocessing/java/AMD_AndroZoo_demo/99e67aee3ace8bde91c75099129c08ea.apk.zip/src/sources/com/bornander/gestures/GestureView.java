package com.bornander.gestures;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class GestureView extends View implements View.OnTouchListener {
    int a;
    int b;
    int c;
    int d;
    private final Bitmap e;
    private final int f;
    private final int g;
    private Matrix h;
    private com.bornander.a.a i;
    private float j;
    private float k;
    private boolean l;
    private b m;
    private boolean n;
    private float o;
    private com.bornander.a.a p;
    private com.bornander.a.a q;
    private com.bornander.a.a r;
    private com.bornander.a.a s;
    private Paint t;
    private float u;
    private GestureDetector v;

    public void setVisible(boolean z) {
        this.l = z;
    }

    public GestureView(Context context, Bitmap bitmap, int i, int i2, int i3, int i4, boolean z) {
        super(context);
        this.h = new Matrix();
        this.i = new com.bornander.a.a();
        this.j = 0.7f;
        this.k = BitmapDescriptorFactory.HUE_RED;
        this.m = new b(2);
        this.n = false;
        this.p = null;
        this.q = null;
        this.r = null;
        this.s = null;
        this.u = BitmapDescriptorFactory.HUE_RED;
        this.a = i;
        this.b = i2;
        this.d = i4;
        this.c = i3;
        this.e = bitmap;
        this.f = bitmap.getWidth();
        this.g = bitmap.getHeight();
        this.l = z;
        this.t = new Paint();
        this.v = new GestureDetector(context, new a());
        setOnTouchListener(this);
    }

    private static float a(float f) {
        return (float) ((f * 180.0d) / 3.141592653589793d);
    }

    private com.bornander.a.a a(com.bornander.a.a aVar) {
        float a = aVar.a();
        float b = aVar.b();
        if (a < this.j) {
            a = this.j;
        }
        if (b < this.j) {
            b = this.j;
        }
        if (a > this.d + this.j) {
            a = this.d + this.j;
        }
        if (b > this.c + this.j) {
            b = this.c + this.j;
        }
        return aVar.a(a, b);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.n) {
            this.i.a(getWidth() / 2, getHeight() / 2);
            this.n = true;
        }
        a();
        canvas.drawBitmap(this.e, this.h, this.t);
    }

    private void a() {
        this.h.reset();
        this.h.postTranslate((-this.f) / 2.0f, (-this.g) / 2.0f);
        this.h.postRotate(this.u);
        this.h.postRotate(a(this.k));
        this.h.postScale(this.j, this.j);
        this.i = a(this.i);
        this.h.postTranslate(this.i.a(), this.i.b());
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (!this.l) {
            return false;
        }
        this.p = null;
        this.q = null;
        this.r = null;
        this.s = null;
        try {
            this.m.a(motionEvent);
            if (this.m.a() == 1) {
                this.p = this.m.c(0);
                this.r = this.m.d(0);
                this.o = 80.0f + this.j;
                this.i.b(this.m.b(0));
            } else if (this.m.a() == 2) {
                this.p = this.m.c(0);
                this.r = this.m.d(0);
                this.q = this.m.c(1);
                this.s = this.m.d(1);
                com.bornander.a.a a = this.m.a(0, 1);
                com.bornander.a.a b = this.m.b(0, 1);
                float c = a.c();
                float c2 = b.c();
                if (c2 != BitmapDescriptorFactory.HUE_RED) {
                    this.j = (c / c2) * this.j;
                    if (this.j < 0.21f) {
                        this.j = 0.21f;
                    } else if (this.j > 4.1f) {
                        this.j = 4.1f;
                    }
                }
                this.k -= com.bornander.a.a.b(a, b);
            }
            invalidate();
            return true;
        } catch (Throwable th) {
            return true;
        }
    }
}
