package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.Filter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class LogicalFilter implements SafeParcelable, Filter {
    public static final Parcelable.Creator<LogicalFilter> CREATOR = new f();
    final int kg;
    private List<Filter> rQ;
    final Operator rR;
    final List<FilterHolder> sb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public LogicalFilter(int i, Operator operator, List<FilterHolder> list) {
        this.kg = i;
        this.rR = operator;
        this.sb = list;
    }

    public LogicalFilter(Operator operator, Filter filter, Filter... filterArr) {
        this.kg = 1;
        this.rR = operator;
        this.sb = new ArrayList(filterArr.length + 1);
        this.sb.add(new FilterHolder(filter));
        this.rQ = new ArrayList(filterArr.length + 1);
        this.rQ.add(filter);
        for (Filter filter2 : filterArr) {
            this.sb.add(new FilterHolder(filter2));
            this.rQ.add(filter2);
        }
    }

    public LogicalFilter(Operator operator, List<Filter> list) {
        this.kg = 1;
        this.rR = operator;
        this.rQ = list;
        this.sb = new ArrayList(list.size());
        Iterator<Filter> it2 = list.iterator();
        while (it2.hasNext()) {
            this.sb.add(new FilterHolder(it2.next()));
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        f.a(this, parcel, i);
    }
}
