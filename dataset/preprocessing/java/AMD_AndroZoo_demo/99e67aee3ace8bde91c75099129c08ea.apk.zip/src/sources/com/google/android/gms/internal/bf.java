package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.ads.AdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class bf<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> implements MediationBannerListener, MediationInterstitialListener {
    private final bd gi;

    public bf(bd bdVar) {
        this.gi = bdVar;
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onClick(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ct.r("Adapter called onClick.");
        if (!cs.ay()) {
            ct.v("onClick must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.w();
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdClicked.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.w();
            } catch (RemoteException e) {
                ct.b("Could not call onAdClicked.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onDismissScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ct.r("Adapter called onDismissScreen.");
        if (!cs.ay()) {
            ct.v("onDismissScreen must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.4
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdClosed();
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdClosed.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdClosed();
            } catch (RemoteException e) {
                ct.b("Could not call onAdClosed.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onDismissScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        ct.r("Adapter called onDismissScreen.");
        if (!cs.ay()) {
            ct.v("onDismissScreen must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.9
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdClosed();
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdClosed.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdClosed();
            } catch (RemoteException e) {
                ct.b("Could not call onAdClosed.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onFailedToReceiveAd(MediationBannerAdapter<?, ?> mediationBannerAdapter, final AdRequest.ErrorCode errorCode) {
        ct.r("Adapter called onFailedToReceiveAd with error. " + errorCode);
        if (!cs.ay()) {
            ct.v("onFailedToReceiveAd must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.5
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdFailedToLoad(bg.a(errorCode));
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdFailedToLoad.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdFailedToLoad(bg.a(errorCode));
            } catch (RemoteException e) {
                ct.b("Could not call onAdFailedToLoad.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onFailedToReceiveAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter, final AdRequest.ErrorCode errorCode) {
        ct.r("Adapter called onFailedToReceiveAd with error " + errorCode + ".");
        if (!cs.ay()) {
            ct.v("onFailedToReceiveAd must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.10
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdFailedToLoad(bg.a(errorCode));
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdFailedToLoad.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdFailedToLoad(bg.a(errorCode));
            } catch (RemoteException e) {
                ct.b("Could not call onAdFailedToLoad.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onLeaveApplication(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ct.r("Adapter called onLeaveApplication.");
        if (!cs.ay()) {
            ct.v("onLeaveApplication must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.6
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdLeftApplication();
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdLeftApplication.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdLeftApplication();
            } catch (RemoteException e) {
                ct.b("Could not call onAdLeftApplication.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onLeaveApplication(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        ct.r("Adapter called onLeaveApplication.");
        if (!cs.ay()) {
            ct.v("onLeaveApplication must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.11
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdLeftApplication();
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdLeftApplication.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdLeftApplication();
            } catch (RemoteException e) {
                ct.b("Could not call onAdLeftApplication.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onPresentScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ct.r("Adapter called onPresentScreen.");
        if (!cs.ay()) {
            ct.v("onPresentScreen must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.7
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdOpened();
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdOpened.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdOpened();
            } catch (RemoteException e) {
                ct.b("Could not call onAdOpened.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onPresentScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        ct.r("Adapter called onPresentScreen.");
        if (!cs.ay()) {
            ct.v("onPresentScreen must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.2
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdOpened();
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdOpened.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdOpened();
            } catch (RemoteException e) {
                ct.b("Could not call onAdOpened.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationBannerListener
    public void onReceivedAd(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ct.r("Adapter called onReceivedAd.");
        if (!cs.ay()) {
            ct.v("onReceivedAd must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.8
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdLoaded();
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdLoaded.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdLoaded();
            } catch (RemoteException e) {
                ct.b("Could not call onAdLoaded.", e);
            }
        }
    }

    @Override // com.google.ads.mediation.MediationInterstitialListener
    public void onReceivedAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        ct.r("Adapter called onReceivedAd.");
        if (!cs.ay()) {
            ct.v("onReceivedAd must be called on the main UI thread.");
            cs.iI.post(new Runnable() { // from class: com.google.android.gms.internal.bf.3
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        bf.this.gi.onAdLoaded();
                    } catch (RemoteException e) {
                        ct.b("Could not call onAdLoaded.", e);
                    }
                }
            });
        } else {
            try {
                this.gi.onAdLoaded();
            } catch (RemoteException e) {
                ct.b("Could not call onAdLoaded.", e);
            }
        }
    }
}
