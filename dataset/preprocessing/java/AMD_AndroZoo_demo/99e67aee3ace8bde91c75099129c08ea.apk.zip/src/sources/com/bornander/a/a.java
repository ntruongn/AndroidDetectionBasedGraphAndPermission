package com.bornander.a;

import com.google.android.gms.maps.model.BitmapDescriptorFactory;

/* compiled from: Vector2D.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class a {
    private float a;
    private float b;

    public a() {
    }

    public a(a aVar) {
        this.a = aVar.a;
        this.b = aVar.b;
    }

    public a(float f, float f2) {
        this.a = f;
        this.b = f2;
    }

    public float a() {
        return this.a;
    }

    public float b() {
        return this.b;
    }

    public float c() {
        return (float) Math.sqrt((this.a * this.a) + (this.b * this.b));
    }

    public a a(a aVar) {
        this.a = aVar.a();
        this.b = aVar.b();
        return this;
    }

    public a a(float f, float f2) {
        this.a = f;
        this.b = f2;
        return this;
    }

    public a b(a aVar) {
        this.a += aVar.a();
        this.b += aVar.b();
        return this;
    }

    public static a a(a aVar, a aVar2) {
        return new a(aVar.a - aVar2.a, aVar.b - aVar2.b);
    }

    public static float b(a aVar, a aVar2) {
        a c = c(aVar);
        a c2 = c(aVar2);
        return (float) (Math.atan2(c2.b, c2.a) - Math.atan2(c.b, c.a));
    }

    public static a c(a aVar) {
        float c = aVar.c();
        return c == BitmapDescriptorFactory.HUE_RED ? new a() : new a(aVar.a / c, aVar.b / c);
    }

    public String toString() {
        return String.format("(%.4f, %.4f)", Float.valueOf(this.a), Float.valueOf(this.b));
    }
}
