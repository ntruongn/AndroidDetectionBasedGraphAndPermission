package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.CollectionMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.query.Filter;
import java.util.Collections;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class InFilter<T> implements SafeParcelable, Filter {
    public static final e CREATOR = new e();
    final int kg;
    final MetadataBundle rS;
    private final CollectionMetadataField<T> sa;

    /* JADX INFO: Access modifiers changed from: package-private */
    public InFilter(int i, MetadataBundle metadataBundle) {
        this.kg = i;
        this.rS = metadataBundle;
        this.sa = (CollectionMetadataField) d.b(metadataBundle);
    }

    public InFilter(CollectionMetadataField<T> collectionMetadataField, T t) {
        this(1, MetadataBundle.a(collectionMetadataField, Collections.singleton(t)));
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        e.a(this, parcel, i);
    }
}
