package com.google.android.gms.drive.metadata;

import java.lang.Comparable;
import java.util.Collection;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public abstract class OrderedMetadataField<T extends Comparable<T>> extends MetadataField<T> {
    /* JADX INFO: Access modifiers changed from: protected */
    public OrderedMetadataField(String str) {
        super(str);
    }

    protected OrderedMetadataField(String str, Collection<String> collection) {
        super(str, collection);
    }
}
