package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.es;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class ep implements SafeParcelable, es.b<String, Integer> {
    public static final eq CREATOR = new eq();
    private final int kg;
    private final HashMap<String, Integer> qd;
    private final HashMap<Integer, String> qe;
    private final ArrayList<a> qf;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public static final class a implements SafeParcelable {
        public static final er CREATOR = new er();
        final String qg;
        final int qh;
        final int versionCode;

        /* JADX INFO: Access modifiers changed from: package-private */
        public a(int i, String str, int i2) {
            this.versionCode = i;
            this.qg = str;
            this.qh = i2;
        }

        a(String str, int i) {
            this.versionCode = 1;
            this.qg = str;
            this.qh = i;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            er erVar = CREATOR;
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            er erVar = CREATOR;
            er.a(this, parcel, i);
        }
    }

    public ep() {
        this.kg = 1;
        this.qd = new HashMap<>();
        this.qe = new HashMap<>();
        this.qf = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ep(int i, ArrayList<a> arrayList) {
        this.kg = i;
        this.qd = new HashMap<>();
        this.qe = new HashMap<>();
        this.qf = null;
        a(arrayList);
    }

    private void a(ArrayList<a> arrayList) {
        Iterator<a> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            a next = it2.next();
            c(next.qg, next.qh);
        }
    }

    @Override // com.google.android.gms.internal.es.b
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public String g(Integer num) {
        String str = this.qe.get(num);
        return (str == null && this.qd.containsKey("gms_unknown")) ? "gms_unknown" : str;
    }

    public ep c(String str, int i) {
        this.qd.put(str, Integer.valueOf(i));
        this.qe.put(Integer.valueOf(i), str);
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ArrayList<a> cg() {
        ArrayList<a> arrayList = new ArrayList<>();
        for (String str : this.qd.keySet()) {
            arrayList.add(new a(str, this.qd.get(str).intValue()));
        }
        return arrayList;
    }

    @Override // com.google.android.gms.internal.es.b
    public int ch() {
        return 7;
    }

    @Override // com.google.android.gms.internal.es.b
    public int ci() {
        return 0;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        eq eqVar = CREATOR;
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.kg;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        eq eqVar = CREATOR;
        eq.a(this, parcel, i);
    }
}
