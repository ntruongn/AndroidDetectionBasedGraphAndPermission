package com.google.android.gms.games.multiplayer;

import com.google.android.gms.common.data.DataBuffer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class ParticipantBuffer extends DataBuffer<Participant> {
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.google.android.gms.common.data.DataBuffer
    public Participant get(int i) {
        return new d(this.nE, i);
    }
}
