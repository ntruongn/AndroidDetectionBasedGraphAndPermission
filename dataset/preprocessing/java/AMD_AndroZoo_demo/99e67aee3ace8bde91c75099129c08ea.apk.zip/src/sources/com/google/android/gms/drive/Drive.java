package com.google.android.gms.drive;

import android.content.Context;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.drive.internal.h;
import com.google.android.gms.drive.internal.j;
import com.google.android.gms.internal.dt;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class Drive {
    public static final Api.b<j> jO = new Api.b<j>() { // from class: com.google.android.gms.drive.Drive.1
        @Override // com.google.android.gms.common.api.Api.b
        /* renamed from: d, reason: merged with bridge method [inline-methods] */
        public j b(Context context, dt dtVar, GoogleApiClient.ApiOptions apiOptions, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {
            List<String> bH = dtVar.bH();
            return new j(context, dtVar, connectionCallbacks, onConnectionFailedListener, (String[]) bH.toArray(new String[bH.size()]));
        }

        @Override // com.google.android.gms.common.api.Api.b
        public int getPriority() {
            return Integer.MAX_VALUE;
        }
    };
    public static final Scope SCOPE_FILE = new Scope(Scopes.DRIVE_FILE);
    public static final Api API = new Api(jO, new Scope[0]);
    public static final DriveApi DriveApi = new h();

    private Drive() {
    }
}
