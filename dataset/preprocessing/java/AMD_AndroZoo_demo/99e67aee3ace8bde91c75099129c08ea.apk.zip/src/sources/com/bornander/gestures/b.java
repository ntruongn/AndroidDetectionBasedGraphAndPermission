package com.bornander.gestures;

import android.support.v4.view.f;
import android.view.MotionEvent;

/* compiled from: TouchManager.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class b {
    private final int a;
    private final com.bornander.a.a[] b;
    private final com.bornander.a.a[] c;

    public b(int i) {
        this.a = i;
        this.b = new com.bornander.a.a[i];
        this.c = new com.bornander.a.a[i];
    }

    public boolean a(int i) {
        return this.b[i] != null;
    }

    public int a() {
        int i = 0;
        for (com.bornander.a.a aVar : this.b) {
            if (aVar != null) {
                i++;
            }
        }
        return i;
    }

    public com.bornander.a.a b(int i) {
        if (a(i)) {
            return com.bornander.a.a.a(this.b[i], this.c[i] != null ? this.c[i] : this.b[i]);
        }
        return new com.bornander.a.a();
    }

    private static com.bornander.a.a a(com.bornander.a.a aVar, com.bornander.a.a aVar2) {
        if (aVar == null || aVar2 == null) {
            throw new RuntimeException("can't do this on nulls");
        }
        return com.bornander.a.a.a(aVar2, aVar);
    }

    public com.bornander.a.a c(int i) {
        return this.b[i] != null ? this.b[i] : new com.bornander.a.a();
    }

    public com.bornander.a.a d(int i) {
        return this.c[i] != null ? this.c[i] : new com.bornander.a.a();
    }

    public com.bornander.a.a a(int i, int i2) {
        return a(this.b[i], this.b[i2]);
    }

    public com.bornander.a.a b(int i, int i2) {
        return (this.c[i] == null || this.c[i2] == null) ? a(this.b[i], this.b[i2]) : a(this.c[i], this.c[i2]);
    }

    public void a(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & f.ACTION_MASK;
        if (action == 6 || action == 1) {
            int action2 = motionEvent.getAction() >> 8;
            com.bornander.a.a[] aVarArr = this.c;
            this.b[action2] = null;
            aVarArr[action2] = null;
            return;
        }
        for (int i = 0; i < this.a; i++) {
            if (i < motionEvent.getPointerCount()) {
                int pointerId = motionEvent.getPointerId(i);
                com.bornander.a.a aVar = new com.bornander.a.a(motionEvent.getX(i), motionEvent.getY(i));
                if (this.b[pointerId] == null) {
                    this.b[pointerId] = aVar;
                } else {
                    if (this.c[pointerId] != null) {
                        this.c[pointerId].a(this.b[pointerId]);
                    } else {
                        this.c[pointerId] = new com.bornander.a.a(aVar);
                    }
                    if (com.bornander.a.a.a(this.b[pointerId], aVar).c() < 64.0f) {
                        this.b[pointerId].a(aVar);
                    }
                }
            } else {
                com.bornander.a.a[] aVarArr2 = this.c;
                this.b[i] = null;
                aVarArr2[i] = null;
            }
        }
    }
}
