package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.gms.drive.metadata.MetadataField;
import java.util.Collection;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public abstract class f<T extends Parcelable> extends MetadataField<T> {
    public f(String str, Collection<String> collection) {
        super(str, collection);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.drive.metadata.MetadataField
    public void a(Bundle bundle, T t) {
        bundle.putParcelable(getName(), t);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.drive.metadata.MetadataField
    /* renamed from: j, reason: merged with bridge method [inline-methods] */
    public T e(Bundle bundle) {
        return (T) bundle.getParcelable(getName());
    }
}
