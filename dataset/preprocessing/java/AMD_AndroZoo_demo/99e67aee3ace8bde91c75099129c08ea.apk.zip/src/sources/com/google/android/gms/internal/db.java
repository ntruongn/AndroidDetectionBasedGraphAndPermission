package com.google.android.gms.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.dd;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public abstract class db extends dd.a {
    @Override // com.google.android.gms.internal.dd
    public void a(int i, DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.dd
    public void a(DataHolder dataHolder) {
    }

    @Override // com.google.android.gms.internal.dd
    public void onSignOutComplete() {
    }

    @Override // com.google.android.gms.internal.dd
    public void onStateDeleted(int i, int i2) {
    }

    @Override // com.google.android.gms.internal.dd
    public void p(int i) {
    }
}
