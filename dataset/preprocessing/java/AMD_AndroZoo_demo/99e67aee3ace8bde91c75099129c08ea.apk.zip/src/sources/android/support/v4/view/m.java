package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatGingerbread.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
class m {
    public static int a(View view) {
        return view.getOverScrollMode();
    }
}
