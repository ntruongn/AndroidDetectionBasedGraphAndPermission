package android.support.v4.view;

import android.graphics.Paint;
import android.os.Build;
import android.view.View;

/* compiled from: ViewCompat.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class l {
    private static final long FAKE_FRAME_TIME = 10;
    public static final int IMPORTANT_FOR_ACCESSIBILITY_AUTO = 0;
    public static final int IMPORTANT_FOR_ACCESSIBILITY_NO = 2;
    public static final int IMPORTANT_FOR_ACCESSIBILITY_YES = 1;
    public static final int LAYER_TYPE_HARDWARE = 2;
    public static final int LAYER_TYPE_NONE = 0;
    public static final int LAYER_TYPE_SOFTWARE = 1;
    public static final int OVER_SCROLL_ALWAYS = 0;
    public static final int OVER_SCROLL_IF_CONTENT_SCROLLS = 1;
    public static final int OVER_SCROLL_NEVER = 2;
    static final g a;

    /* compiled from: ViewCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    interface g {
        int a(View view);

        void a(View view, int i, Paint paint);

        void a(View view, android.support.v4.view.a aVar);

        void a(View view, Runnable runnable);

        boolean a(View view, int i);

        void b(View view);

        void b(View view, int i);

        int c(View view);
    }

    /* compiled from: ViewCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class a implements g {
        a() {
        }

        @Override // android.support.v4.view.l.g
        public boolean a(View view, int i) {
            return false;
        }

        @Override // android.support.v4.view.l.g
        public int a(View view) {
            return 2;
        }

        @Override // android.support.v4.view.l.g
        public void a(View view, android.support.v4.view.a aVar) {
        }

        @Override // android.support.v4.view.l.g
        public void b(View view) {
            view.postInvalidateDelayed(a());
        }

        @Override // android.support.v4.view.l.g
        public void a(View view, Runnable runnable) {
            view.postDelayed(runnable, a());
        }

        long a() {
            return l.FAKE_FRAME_TIME;
        }

        @Override // android.support.v4.view.l.g
        public int c(View view) {
            return 0;
        }

        @Override // android.support.v4.view.l.g
        public void b(View view, int i) {
        }

        @Override // android.support.v4.view.l.g
        public void a(View view, int i, Paint paint) {
        }
    }

    /* compiled from: ViewCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class b extends a {
        b() {
        }

        @Override // android.support.v4.view.l.a, android.support.v4.view.l.g
        public int a(View view) {
            return m.a(view);
        }
    }

    /* compiled from: ViewCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class c extends b {
        c() {
        }

        @Override // android.support.v4.view.l.a
        long a() {
            return n.a();
        }

        @Override // android.support.v4.view.l.a, android.support.v4.view.l.g
        public void a(View view, int i, Paint paint) {
            n.a(view, i, paint);
        }
    }

    /* compiled from: ViewCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class d extends c {
        d() {
        }

        @Override // android.support.v4.view.l.a, android.support.v4.view.l.g
        public boolean a(View view, int i) {
            return o.a(view, i);
        }

        @Override // android.support.v4.view.l.a, android.support.v4.view.l.g
        public void a(View view, android.support.v4.view.a aVar) {
            o.a(view, aVar.a());
        }
    }

    /* compiled from: ViewCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class e extends d {
        e() {
        }

        @Override // android.support.v4.view.l.a, android.support.v4.view.l.g
        public void b(View view) {
            p.a(view);
        }

        @Override // android.support.v4.view.l.a, android.support.v4.view.l.g
        public void a(View view, Runnable runnable) {
            p.a(view, runnable);
        }

        @Override // android.support.v4.view.l.a, android.support.v4.view.l.g
        public int c(View view) {
            return p.b(view);
        }

        @Override // android.support.v4.view.l.a, android.support.v4.view.l.g
        public void b(View view, int i) {
            p.a(view, i);
        }
    }

    /* compiled from: ViewCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class f extends e {
        f() {
        }
    }

    static {
        int i = Build.VERSION.SDK_INT;
        if (i >= 17) {
            a = new f();
            return;
        }
        if (i >= 16) {
            a = new e();
            return;
        }
        if (i >= 14) {
            a = new d();
            return;
        }
        if (i >= 11) {
            a = new c();
        } else if (i >= 9) {
            a = new b();
        } else {
            a = new a();
        }
    }

    public static boolean a(View view, int i) {
        return a.a(view, i);
    }

    public static int a(View view) {
        return a.a(view);
    }

    public static void a(View view, android.support.v4.view.a aVar) {
        a.a(view, aVar);
    }

    public static void b(View view) {
        a.b(view);
    }

    public static void a(View view, Runnable runnable) {
        a.a(view, runnable);
    }

    public static int c(View view) {
        return a.c(view);
    }

    public static void b(View view, int i) {
        a.b(view, i);
    }

    public static void a(View view, int i, Paint paint) {
        a.a(view, i, paint);
    }
}
