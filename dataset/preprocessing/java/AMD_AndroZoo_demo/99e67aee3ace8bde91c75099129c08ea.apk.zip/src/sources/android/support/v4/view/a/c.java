package android.support.v4.view.a;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.a.d;
import java.util.ArrayList;
import java.util.List;

/* compiled from: AccessibilityNodeProviderCompat.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class c {
    private static final a a;
    private final Object b;

    /* compiled from: AccessibilityNodeProviderCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    interface a {
        Object a(c cVar);
    }

    /* compiled from: AccessibilityNodeProviderCompat.java */
    /* renamed from: android.support.v4.view.a.c$c, reason: collision with other inner class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class C0005c implements a {
        C0005c() {
        }

        @Override // android.support.v4.view.a.c.a
        public Object a(c cVar) {
            return null;
        }
    }

    /* compiled from: AccessibilityNodeProviderCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class b extends C0005c {
        b() {
        }

        @Override // android.support.v4.view.a.c.C0005c, android.support.v4.view.a.c.a
        public Object a(final c cVar) {
            return d.a(new d.a() { // from class: android.support.v4.view.a.c.b.1
                @Override // android.support.v4.view.a.d.a
                public boolean a(int i, int i2, Bundle bundle) {
                    return cVar.a(i, i2, bundle);
                }

                @Override // android.support.v4.view.a.d.a
                public List<Object> a(String str, int i) {
                    List<android.support.v4.view.a.a> a = cVar.a(str, i);
                    ArrayList arrayList = new ArrayList();
                    int size = a.size();
                    for (int i2 = 0; i2 < size; i2++) {
                        arrayList.add(a.get(i2).a());
                    }
                    return arrayList;
                }

                @Override // android.support.v4.view.a.d.a
                public Object a(int i) {
                    android.support.v4.view.a.a a = cVar.a(i);
                    if (a == null) {
                        return null;
                    }
                    return a.a();
                }
            });
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 16) {
            a = new b();
        } else {
            a = new C0005c();
        }
    }

    public c() {
        this.b = a.a(this);
    }

    public c(Object obj) {
        this.b = obj;
    }

    public Object a() {
        return this.b;
    }

    public android.support.v4.view.a.a a(int i) {
        return null;
    }

    public boolean a(int i, int i2, Bundle bundle) {
        return false;
    }

    public List<android.support.v4.view.a.a> a(String str, int i) {
        return null;
    }
}
