package android.support.v4.view.a;

import android.os.Build;

/* compiled from: AccessibilityNodeInfoCompat.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class a {
    public static final int ACTION_ACCESSIBILITY_FOCUS = 64;
    public static final String ACTION_ARGUMENT_HTML_ELEMENT_STRING = "ACTION_ARGUMENT_HTML_ELEMENT_STRING";
    public static final String ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT = "ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT";
    public static final int ACTION_CLEAR_ACCESSIBILITY_FOCUS = 128;
    public static final int ACTION_CLEAR_FOCUS = 2;
    public static final int ACTION_CLEAR_SELECTION = 8;
    public static final int ACTION_CLICK = 16;
    public static final int ACTION_FOCUS = 1;
    public static final int ACTION_LONG_CLICK = 32;
    public static final int ACTION_NEXT_AT_MOVEMENT_GRANULARITY = 256;
    public static final int ACTION_NEXT_HTML_ELEMENT = 1024;
    public static final int ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY = 512;
    public static final int ACTION_PREVIOUS_HTML_ELEMENT = 2048;
    public static final int ACTION_SCROLL_BACKWARD = 8192;
    public static final int ACTION_SCROLL_FORWARD = 4096;
    public static final int ACTION_SELECT = 4;
    public static final int FOCUS_ACCESSIBILITY = 2;
    public static final int FOCUS_INPUT = 1;
    public static final int MOVEMENT_GRANULARITY_CHARACTER = 1;
    public static final int MOVEMENT_GRANULARITY_LINE = 4;
    public static final int MOVEMENT_GRANULARITY_PAGE = 16;
    public static final int MOVEMENT_GRANULARITY_PARAGRAPH = 8;
    public static final int MOVEMENT_GRANULARITY_WORD = 2;
    private static final b a;
    private final Object b;

    /* compiled from: AccessibilityNodeInfoCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    interface b {
        void a(Object obj, int i);

        void a(Object obj, CharSequence charSequence);

        void a(Object obj, boolean z);
    }

    /* compiled from: AccessibilityNodeInfoCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class d implements b {
        d() {
        }

        @Override // android.support.v4.view.a.a.b
        public void a(Object obj, int i) {
        }

        @Override // android.support.v4.view.a.a.b
        public void a(Object obj, CharSequence charSequence) {
        }

        @Override // android.support.v4.view.a.a.b
        public void a(Object obj, boolean z) {
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat.java */
    /* renamed from: android.support.v4.view.a.a$a, reason: collision with other inner class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class C0004a extends d {
        C0004a() {
        }

        @Override // android.support.v4.view.a.a.d, android.support.v4.view.a.a.b
        public void a(Object obj, int i) {
            android.support.v4.view.a.b.a(obj, i);
        }

        @Override // android.support.v4.view.a.a.d, android.support.v4.view.a.a.b
        public void a(Object obj, CharSequence charSequence) {
            android.support.v4.view.a.b.a(obj, charSequence);
        }

        @Override // android.support.v4.view.a.a.d, android.support.v4.view.a.a.b
        public void a(Object obj, boolean z) {
            android.support.v4.view.a.b.a(obj, z);
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class c extends C0004a {
        c() {
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 16) {
            a = new c();
        } else if (Build.VERSION.SDK_INT >= 14) {
            a = new C0004a();
        } else {
            a = new d();
        }
    }

    public a(Object obj) {
        this.b = obj;
    }

    public Object a() {
        return this.b;
    }

    public void a(int i) {
        a.a(this.b, i);
    }

    public void a(boolean z) {
        a.a(this.b, z);
    }

    public void a(CharSequence charSequence) {
        a.a(this.b, charSequence);
    }

    public int hashCode() {
        if (this.b == null) {
            return 0;
        }
        return this.b.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            a aVar = (a) obj;
            return this.b == null ? aVar.b == null : this.b.equals(aVar.b);
        }
        return false;
    }
}
