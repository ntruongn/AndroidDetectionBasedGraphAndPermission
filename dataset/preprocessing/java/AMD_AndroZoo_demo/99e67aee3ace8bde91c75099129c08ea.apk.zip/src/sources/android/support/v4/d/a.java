package android.support.v4.d;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build;

/* compiled from: EdgeEffectCompat.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class a {
    private static final c b;
    private Object a;

    /* compiled from: EdgeEffectCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    interface c {
        Object a(Context context);

        void a(Object obj, int i, int i2);

        boolean a(Object obj);

        boolean a(Object obj, float f);

        boolean a(Object obj, Canvas canvas);

        void b(Object obj);

        boolean c(Object obj);
    }

    static {
        if (Build.VERSION.SDK_INT >= 14) {
            b = new b();
        } else {
            b = new C0002a();
        }
    }

    /* compiled from: EdgeEffectCompat.java */
    /* renamed from: android.support.v4.d.a$a, reason: collision with other inner class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class C0002a implements c {
        C0002a() {
        }

        @Override // android.support.v4.d.a.c
        public Object a(Context context) {
            return null;
        }

        @Override // android.support.v4.d.a.c
        public void a(Object obj, int i, int i2) {
        }

        @Override // android.support.v4.d.a.c
        public boolean a(Object obj) {
            return true;
        }

        @Override // android.support.v4.d.a.c
        public void b(Object obj) {
        }

        @Override // android.support.v4.d.a.c
        public boolean a(Object obj, float f) {
            return false;
        }

        @Override // android.support.v4.d.a.c
        public boolean c(Object obj) {
            return false;
        }

        @Override // android.support.v4.d.a.c
        public boolean a(Object obj, Canvas canvas) {
            return false;
        }
    }

    /* compiled from: EdgeEffectCompat.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class b implements c {
        b() {
        }

        @Override // android.support.v4.d.a.c
        public Object a(Context context) {
            return android.support.v4.d.b.a(context);
        }

        @Override // android.support.v4.d.a.c
        public void a(Object obj, int i, int i2) {
            android.support.v4.d.b.a(obj, i, i2);
        }

        @Override // android.support.v4.d.a.c
        public boolean a(Object obj) {
            return android.support.v4.d.b.a(obj);
        }

        @Override // android.support.v4.d.a.c
        public void b(Object obj) {
            android.support.v4.d.b.b(obj);
        }

        @Override // android.support.v4.d.a.c
        public boolean a(Object obj, float f) {
            return android.support.v4.d.b.a(obj, f);
        }

        @Override // android.support.v4.d.a.c
        public boolean c(Object obj) {
            return android.support.v4.d.b.c(obj);
        }

        @Override // android.support.v4.d.a.c
        public boolean a(Object obj, Canvas canvas) {
            return android.support.v4.d.b.a(obj, canvas);
        }
    }

    public a(Context context) {
        this.a = b.a(context);
    }

    public void a(int i, int i2) {
        b.a(this.a, i, i2);
    }

    public boolean a() {
        return b.a(this.a);
    }

    public void b() {
        b.b(this.a);
    }

    public boolean a(float f) {
        return b.a(this.a, f);
    }

    public boolean c() {
        return b.c(this.a);
    }

    public boolean a(Canvas canvas) {
        return b.a(this.a, canvas);
    }
}
