package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.FloatMath;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class ViewPager extends ViewGroup {
    private static final int CLOSE_ENOUGH = 2;
    private static final boolean DEBUG = false;
    private static final int DEFAULT_GUTTER_SIZE = 16;
    private static final int DEFAULT_OFFSCREEN_PAGES = 1;
    private static final int DRAW_ORDER_DEFAULT = 0;
    private static final int DRAW_ORDER_FORWARD = 1;
    private static final int DRAW_ORDER_REVERSE = 2;
    private static final int INVALID_POINTER = -1;
    private static final int MAX_SETTLE_DURATION = 600;
    private static final int MIN_DISTANCE_FOR_FLING = 25;
    public static final int SCROLL_STATE_DRAGGING = 1;
    public static final int SCROLL_STATE_IDLE = 0;
    public static final int SCROLL_STATE_SETTLING = 2;
    private static final String TAG = "ViewPager";
    private static final boolean USE_CACHE = false;
    private boolean A;
    private int B;
    private int C;
    private int D;
    private float E;
    private float F;
    private float G;
    private int H;
    private VelocityTracker I;
    private int J;
    private int K;
    private int L;
    private int M;
    private int N;
    private int O;
    private boolean P;
    private android.support.v4.d.a Q;
    private android.support.v4.d.a R;
    private boolean S;
    private boolean T;
    private boolean U;
    private int V;
    private e W;
    private e Z;
    private d aa;
    private f ab;
    private Method ac;
    private int ad;
    private ArrayList<View> ae;
    private final Runnable ag;
    private int ah;
    private final ArrayList<b> d;
    private final b e;
    private final Rect f;
    private android.support.v4.view.h g;
    private int h;
    private int i;
    private Parcelable j;
    private ClassLoader k;
    private Scroller l;
    private g m;
    private int n;
    private Drawable o;
    private int p;
    private int q;
    private float r;
    private float s;
    private int t;
    private int u;
    private boolean v;
    private boolean w;
    private boolean x;
    private int y;
    private boolean z;
    private static final int[] a = {16842931};
    private static final Comparator<b> b = new Comparator<b>() { // from class: android.support.v4.view.ViewPager.1
        @Override // java.util.Comparator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(b bVar, b bVar2) {
            return bVar.b - bVar2.b;
        }
    };
    private static final Interpolator c = new Interpolator() { // from class: android.support.v4.view.ViewPager.2
        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f2) {
            float f3 = f2 - 1.0f;
            return (f3 * f3 * f3 * f3 * f3) + 1.0f;
        }
    };
    private static final h af = new h();

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    interface a {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    interface d {
        void a(android.support.v4.view.h hVar, android.support.v4.view.h hVar2);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public interface e {
        void a(int i);

        void a(int i, float f, int i2);

        void b(int i);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public interface f {
        void a(View view, float f);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public static class b {
        Object a;
        int b;
        boolean c;
        float d;
        float e;

        b() {
        }
    }

    public ViewPager(Context context) {
        super(context);
        this.d = new ArrayList<>();
        this.e = new b();
        this.f = new Rect();
        this.i = -1;
        this.j = null;
        this.k = null;
        this.r = -3.4028235E38f;
        this.s = Float.MAX_VALUE;
        this.y = 1;
        this.H = -1;
        this.S = true;
        this.T = false;
        this.ag = new Runnable() { // from class: android.support.v4.view.ViewPager.3
            @Override // java.lang.Runnable
            public void run() {
                ViewPager.this.setScrollState(0);
                ViewPager.this.c();
            }
        };
        this.ah = 0;
        a();
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d = new ArrayList<>();
        this.e = new b();
        this.f = new Rect();
        this.i = -1;
        this.j = null;
        this.k = null;
        this.r = -3.4028235E38f;
        this.s = Float.MAX_VALUE;
        this.y = 1;
        this.H = -1;
        this.S = true;
        this.T = false;
        this.ag = new Runnable() { // from class: android.support.v4.view.ViewPager.3
            @Override // java.lang.Runnable
            public void run() {
                ViewPager.this.setScrollState(0);
                ViewPager.this.c();
            }
        };
        this.ah = 0;
        a();
    }

    void a() {
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context = getContext();
        this.l = new Scroller(context, c);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.D = q.a(viewConfiguration);
        this.J = viewConfiguration.getScaledMinimumFlingVelocity();
        this.K = viewConfiguration.getScaledMaximumFlingVelocity();
        this.Q = new android.support.v4.d.a(context);
        this.R = new android.support.v4.d.a(context);
        float f2 = context.getResources().getDisplayMetrics().density;
        this.L = (int) (25.0f * f2);
        this.M = (int) (2.0f * f2);
        this.B = (int) (f2 * 16.0f);
        l.a(this, new c());
        if (l.c(this) == 0) {
            l.b(this, 1);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        removeCallbacks(this.ag);
        super.onDetachedFromWindow();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setScrollState(int i) {
        if (this.ah != i) {
            this.ah = i;
            if (i == 1) {
                this.O = -1;
                this.N = -1;
            }
            if (this.ab != null) {
                b(i != 0);
            }
            if (this.W != null) {
                this.W.b(i);
            }
        }
    }

    public void setAdapter(android.support.v4.view.h hVar) {
        if (this.g != null) {
            this.g.b(this.m);
            this.g.a((ViewGroup) this);
            for (int i = 0; i < this.d.size(); i++) {
                b bVar = this.d.get(i);
                this.g.a((ViewGroup) this, bVar.b, bVar.a);
            }
            this.g.b((ViewGroup) this);
            this.d.clear();
            g();
            this.h = 0;
            scrollTo(0, 0);
        }
        android.support.v4.view.h hVar2 = this.g;
        this.g = hVar;
        if (this.g != null) {
            if (this.m == null) {
                this.m = new g();
            }
            this.g.a((DataSetObserver) this.m);
            this.x = false;
            this.S = true;
            if (this.i >= 0) {
                this.g.a(this.j, this.k);
                a(this.i, false, true);
                this.i = -1;
                this.j = null;
                this.k = null;
            } else {
                c();
            }
        }
        if (this.aa != null && hVar2 != hVar) {
            this.aa.a(hVar2, hVar);
        }
    }

    private void g() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 < getChildCount()) {
                if (!((LayoutParams) getChildAt(i2).getLayoutParams()).a) {
                    removeViewAt(i2);
                    i2--;
                }
                i = i2 + 1;
            } else {
                return;
            }
        }
    }

    public android.support.v4.view.h getAdapter() {
        return this.g;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void setOnAdapterChangeListener(d dVar) {
        this.aa = dVar;
    }

    public void setCurrentItem(int i) {
        this.x = false;
        a(i, !this.S, false);
    }

    public void a(int i, boolean z) {
        this.x = false;
        a(i, z, false);
    }

    public int getCurrentItem() {
        return this.h;
    }

    void a(int i, boolean z, boolean z2) {
        a(i, z, z2, 0);
    }

    void a(int i, boolean z, boolean z2, int i2) {
        if (this.g == null || this.g.a() <= 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (!z2 && this.h == i && this.d.size() != 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (i < 0) {
            i = 0;
        } else if (i >= this.g.a()) {
            i = this.g.a() - 1;
        }
        int i3 = this.y;
        if (i > this.h + i3 || i < this.h - i3) {
            for (int i4 = 0; i4 < this.d.size(); i4++) {
                this.d.get(i4).c = true;
            }
        }
        boolean z3 = this.h != i;
        a(i);
        a(i, z, i2, z3);
    }

    private void a(int i, boolean z, int i2, boolean z2) {
        int i3;
        b b2 = b(i);
        if (b2 != null) {
            i3 = (int) (Math.max(this.r, Math.min(b2.e, this.s)) * getWidth());
        } else {
            i3 = 0;
        }
        if (z) {
            a(i3, 0, i2);
            if (z2 && this.W != null) {
                this.W.a(i);
            }
            if (z2 && this.Z != null) {
                this.Z.a(i);
                return;
            }
            return;
        }
        if (z2 && this.W != null) {
            this.W.a(i);
        }
        if (z2 && this.Z != null) {
            this.Z.a(i);
        }
        a(false);
        scrollTo(i3, 0);
    }

    public void setOnPageChangeListener(e eVar) {
        this.W = eVar;
    }

    void setChildrenDrawingOrderEnabledCompat(boolean z) {
        if (this.ac == null) {
            try {
                this.ac = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException e2) {
                Log.e(TAG, "Can't find setChildrenDrawingOrderEnabled", e2);
            }
        }
        try {
            this.ac.invoke(this, Boolean.valueOf(z));
        } catch (Exception e3) {
            Log.e(TAG, "Error changing children drawing order", e3);
        }
    }

    @Override // android.view.ViewGroup
    protected int getChildDrawingOrder(int i, int i2) {
        if (this.ad == 2) {
            i2 = (i - 1) - i2;
        }
        return ((LayoutParams) this.ae.get(i2).getLayoutParams()).f;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public e a(e eVar) {
        e eVar2 = this.Z;
        this.Z = eVar;
        return eVar2;
    }

    public int getOffscreenPageLimit() {
        return this.y;
    }

    public void setOffscreenPageLimit(int i) {
        if (i < 1) {
            Log.w(TAG, "Requested offscreen page limit " + i + " too small; defaulting to 1");
            i = 1;
        }
        if (i != this.y) {
            this.y = i;
            c();
        }
    }

    public void setPageMargin(int i) {
        int i2 = this.n;
        this.n = i;
        int width = getWidth();
        a(width, width, i, i2);
        requestLayout();
    }

    public int getPageMargin() {
        return this.n;
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.o = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    public void setPageMarginDrawable(int i) {
        setPageMarginDrawable(getContext().getResources().getDrawable(i));
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.o;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.o;
        if (drawable != null && drawable.isStateful()) {
            drawable.setState(getDrawableState());
        }
    }

    float a(float f2) {
        return (float) Math.sin((float) ((f2 - 0.5f) * 0.4712389167638204d));
    }

    void a(int i, int i2, int i3) {
        int abs;
        if (getChildCount() == 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int i4 = i - scrollX;
        int i5 = i2 - scrollY;
        if (i4 == 0 && i5 == 0) {
            a(false);
            c();
            setScrollState(0);
            return;
        }
        setScrollingCacheEnabled(true);
        setScrollState(2);
        int width = getWidth();
        int i6 = width / 2;
        float a2 = (i6 * a(Math.min(1.0f, (Math.abs(i4) * 1.0f) / width))) + i6;
        int abs2 = Math.abs(i3);
        if (abs2 > 0) {
            abs = Math.round(1000.0f * Math.abs(a2 / abs2)) * 4;
        } else {
            abs = (int) (((Math.abs(i4) / ((width * this.g.b(this.h)) + this.n)) + 1.0f) * 100.0f);
        }
        this.l.startScroll(scrollX, scrollY, i4, i5, Math.min(abs, (int) MAX_SETTLE_DURATION));
        l.b(this);
    }

    b a(int i, int i2) {
        b bVar = new b();
        bVar.b = i;
        bVar.a = this.g.a((ViewGroup) this, i);
        bVar.d = this.g.b(i);
        if (i2 < 0 || i2 >= this.d.size()) {
            this.d.add(bVar);
        } else {
            this.d.add(i2, bVar);
        }
        return bVar;
    }

    void b() {
        int i;
        boolean z;
        int i2;
        boolean z2;
        boolean z3 = this.d.size() < (this.y * 2) + 1 && this.d.size() < this.g.a();
        boolean z4 = false;
        int i3 = this.h;
        boolean z5 = z3;
        int i4 = 0;
        while (i4 < this.d.size()) {
            b bVar = this.d.get(i4);
            int a2 = this.g.a(bVar.a);
            if (a2 == -1) {
                i = i4;
                z = z4;
                i2 = i3;
                z2 = z5;
            } else if (a2 == -2) {
                this.d.remove(i4);
                int i5 = i4 - 1;
                if (!z4) {
                    this.g.a((ViewGroup) this);
                    z4 = true;
                }
                this.g.a((ViewGroup) this, bVar.b, bVar.a);
                if (this.h == bVar.b) {
                    i = i5;
                    z = z4;
                    i2 = Math.max(0, Math.min(this.h, this.g.a() - 1));
                    z2 = true;
                } else {
                    i = i5;
                    z = z4;
                    i2 = i3;
                    z2 = true;
                }
            } else if (bVar.b != a2) {
                if (bVar.b == this.h) {
                    i3 = a2;
                }
                bVar.b = a2;
                i = i4;
                z = z4;
                i2 = i3;
                z2 = true;
            } else {
                i = i4;
                z = z4;
                i2 = i3;
                z2 = z5;
            }
            z5 = z2;
            i3 = i2;
            z4 = z;
            i4 = i + 1;
        }
        if (z4) {
            this.g.b((ViewGroup) this);
        }
        Collections.sort(this.d, b);
        if (z5) {
            int childCount = getChildCount();
            for (int i6 = 0; i6 < childCount; i6++) {
                LayoutParams layoutParams = (LayoutParams) getChildAt(i6).getLayoutParams();
                if (!layoutParams.a) {
                    layoutParams.c = BitmapDescriptorFactory.HUE_RED;
                }
            }
            a(i3, false, true);
            requestLayout();
        }
    }

    void c() {
        a(this.h);
    }

    /* JADX WARN: Code restructure failed: missing block: B:20:0x0058, code lost:
    
        if (r0.b == r14.h) goto L19;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void a(int r15) {
        /*
            Method dump skipped, instructions count: 589
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.a(int):void");
    }

    private void a(b bVar, int i, b bVar2) {
        b bVar3;
        b bVar4;
        int a2 = this.g.a();
        int width = getWidth();
        float f2 = width > 0 ? this.n / width : 0.0f;
        if (bVar2 != null) {
            int i2 = bVar2.b;
            if (i2 < bVar.b) {
                float f3 = bVar2.e + bVar2.d + f2;
                int i3 = i2 + 1;
                int i4 = 0;
                while (i3 <= bVar.b && i4 < this.d.size()) {
                    b bVar5 = this.d.get(i4);
                    while (true) {
                        bVar4 = bVar5;
                        if (i3 <= bVar4.b || i4 >= this.d.size() - 1) {
                            break;
                        }
                        i4++;
                        bVar5 = this.d.get(i4);
                    }
                    while (i3 < bVar4.b) {
                        f3 += this.g.b(i3) + f2;
                        i3++;
                    }
                    bVar4.e = f3;
                    f3 += bVar4.d + f2;
                    i3++;
                }
            } else if (i2 > bVar.b) {
                int size = this.d.size() - 1;
                float f4 = bVar2.e;
                int i5 = i2 - 1;
                while (i5 >= bVar.b && size >= 0) {
                    b bVar6 = this.d.get(size);
                    while (true) {
                        bVar3 = bVar6;
                        if (i5 >= bVar3.b || size <= 0) {
                            break;
                        }
                        size--;
                        bVar6 = this.d.get(size);
                    }
                    while (i5 > bVar3.b) {
                        f4 -= this.g.b(i5) + f2;
                        i5--;
                    }
                    f4 -= bVar3.d + f2;
                    bVar3.e = f4;
                    i5--;
                }
            }
        }
        int size2 = this.d.size();
        float f5 = bVar.e;
        int i6 = bVar.b - 1;
        this.r = bVar.b == 0 ? bVar.e : -3.4028235E38f;
        this.s = bVar.b == a2 + (-1) ? (bVar.e + bVar.d) - 1.0f : Float.MAX_VALUE;
        for (int i7 = i - 1; i7 >= 0; i7--) {
            b bVar7 = this.d.get(i7);
            float f6 = f5;
            while (i6 > bVar7.b) {
                f6 -= this.g.b(i6) + f2;
                i6--;
            }
            f5 = f6 - (bVar7.d + f2);
            bVar7.e = f5;
            if (bVar7.b == 0) {
                this.r = f5;
            }
            i6--;
        }
        float f7 = bVar.e + bVar.d + f2;
        int i8 = bVar.b + 1;
        for (int i9 = i + 1; i9 < size2; i9++) {
            b bVar8 = this.d.get(i9);
            float f8 = f7;
            while (i8 < bVar8.b) {
                f8 = this.g.b(i8) + f2 + f8;
                i8++;
            }
            if (bVar8.b == a2 - 1) {
                this.s = (bVar8.d + f8) - 1.0f;
            }
            bVar8.e = f8;
            f7 = f8 + bVar8.d + f2;
            i8++;
        }
        this.T = false;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = android.support.v4.b.a.a(new android.support.v4.b.b<SavedState>() { // from class: android.support.v4.view.ViewPager.SavedState.1
            @Override // android.support.v4.b.b
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public SavedState a(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }

            @Override // android.support.v4.b.b
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public SavedState[] a(int i) {
                return new SavedState[i];
            }
        });
        int a;
        Parcelable b;
        ClassLoader c;

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.a);
            parcel.writeParcelable(this.b, i);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.a + "}";
        }

        SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel);
            classLoader = classLoader == null ? getClass().getClassLoader() : classLoader;
            this.a = parcel.readInt();
            this.b = parcel.readParcelable(classLoader);
            this.c = classLoader;
        }
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.a = this.h;
        if (this.g != null) {
            savedState.b = this.g.b();
        }
        return savedState;
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        if (this.g != null) {
            this.g.a(savedState.b, savedState.c);
            a(savedState.a, false, true);
        } else {
            this.i = savedState.a;
            this.j = savedState.b;
            this.k = savedState.c;
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        ViewGroup.LayoutParams generateLayoutParams = !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : layoutParams;
        LayoutParams layoutParams2 = (LayoutParams) generateLayoutParams;
        layoutParams2.a |= view instanceof a;
        if (this.v) {
            if (layoutParams2 != null && layoutParams2.a) {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            }
            layoutParams2.d = true;
            addViewInLayout(view, i, generateLayoutParams);
            return;
        }
        super.addView(view, i, generateLayoutParams);
    }

    b a(View view) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 < this.d.size()) {
                b bVar = this.d.get(i2);
                if (!this.g.a(view, bVar.a)) {
                    i = i2 + 1;
                } else {
                    return bVar;
                }
            } else {
                return null;
            }
        }
    }

    b b(View view) {
        while (true) {
            Object parent = view.getParent();
            if (parent != this) {
                if (parent == null || !(parent instanceof View)) {
                    break;
                }
                view = (View) parent;
            } else {
                return a(view);
            }
        }
        return null;
    }

    b b(int i) {
        int i2 = 0;
        while (true) {
            int i3 = i2;
            if (i3 < this.d.size()) {
                b bVar = this.d.get(i3);
                if (bVar.b != i) {
                    i2 = i3 + 1;
                } else {
                    return bVar;
                }
            } else {
                return null;
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.S = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x00a0  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00b4  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void onMeasure(int r14, int r15) {
        /*
            Method dump skipped, instructions count: 275
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.onMeasure(int, int):void");
    }

    @Override // android.view.View
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3) {
            a(i, i3, this.n, this.n);
        }
    }

    private void a(int i, int i2, int i3, int i4) {
        if (i2 > 0 && !this.d.isEmpty()) {
            int scrollX = (int) ((i + i3) * (getScrollX() / (i2 + i4)));
            scrollTo(scrollX, getScrollY());
            if (!this.l.isFinished()) {
                this.l.startScroll(scrollX, 0, (int) (b(this.h).e * i), 0, this.l.getDuration() - this.l.timePassed());
                return;
            }
            return;
        }
        b b2 = b(this.h);
        int min = (int) ((b2 != null ? Math.min(b2.e, this.s) : BitmapDescriptorFactory.HUE_RED) * i);
        if (min != getScrollX()) {
            a(false);
            scrollTo(min, getScrollY());
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        b a2;
        int i5;
        int i6;
        int i7;
        int measuredHeight;
        int i8;
        int i9;
        this.v = true;
        c();
        this.v = false;
        int childCount = getChildCount();
        int i10 = i3 - i;
        int i11 = i4 - i2;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i12 = 0;
        int i13 = 0;
        while (i13 < childCount) {
            View childAt = getChildAt(i13);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (layoutParams.a) {
                    int i14 = layoutParams.b & 7;
                    int i15 = layoutParams.b & 112;
                    switch (i14) {
                        case 1:
                            i7 = Math.max((i10 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                            break;
                        case 2:
                        case 4:
                        default:
                            i7 = paddingLeft;
                            break;
                        case 3:
                            i7 = paddingLeft;
                            paddingLeft = childAt.getMeasuredWidth() + paddingLeft;
                            break;
                        case 5:
                            int measuredWidth = (i10 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                            i7 = measuredWidth;
                            break;
                    }
                    switch (i15) {
                        case 16:
                            measuredHeight = Math.max((i11 - childAt.getMeasuredHeight()) / 2, paddingTop);
                            int i16 = paddingBottom;
                            i8 = paddingTop;
                            i9 = i16;
                            break;
                        case 48:
                            int measuredHeight2 = childAt.getMeasuredHeight() + paddingTop;
                            int i17 = paddingTop;
                            i9 = paddingBottom;
                            i8 = measuredHeight2;
                            measuredHeight = i17;
                            break;
                        case 80:
                            measuredHeight = (i11 - paddingBottom) - childAt.getMeasuredHeight();
                            int measuredHeight3 = paddingBottom + childAt.getMeasuredHeight();
                            i8 = paddingTop;
                            i9 = measuredHeight3;
                            break;
                        default:
                            measuredHeight = paddingTop;
                            int i18 = paddingBottom;
                            i8 = paddingTop;
                            i9 = i18;
                            break;
                    }
                    int i19 = i7 + scrollX;
                    childAt.layout(i19, measuredHeight, childAt.getMeasuredWidth() + i19, childAt.getMeasuredHeight() + measuredHeight);
                    i5 = i12 + 1;
                    i6 = i8;
                    paddingBottom = i9;
                    i13++;
                    paddingLeft = paddingLeft;
                    paddingRight = paddingRight;
                    paddingTop = i6;
                    i12 = i5;
                }
            }
            i5 = i12;
            i6 = paddingTop;
            i13++;
            paddingLeft = paddingLeft;
            paddingRight = paddingRight;
            paddingTop = i6;
            i12 = i5;
        }
        for (int i20 = 0; i20 < childCount; i20++) {
            View childAt2 = getChildAt(i20);
            if (childAt2.getVisibility() != 8) {
                LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                if (!layoutParams2.a && (a2 = a(childAt2)) != null) {
                    int i21 = ((int) (a2.e * i10)) + paddingLeft;
                    if (layoutParams2.d) {
                        layoutParams2.d = false;
                        childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (layoutParams2.c * ((i10 - paddingLeft) - paddingRight)), 1073741824), View.MeasureSpec.makeMeasureSpec((i11 - paddingTop) - paddingBottom, 1073741824));
                    }
                    childAt2.layout(i21, paddingTop, childAt2.getMeasuredWidth() + i21, childAt2.getMeasuredHeight() + paddingTop);
                }
            }
        }
        this.p = paddingTop;
        this.q = i11 - paddingBottom;
        this.V = i12;
        this.S = false;
    }

    @Override // android.view.View
    public void computeScroll() {
        if (!this.l.isFinished() && this.l.computeScrollOffset()) {
            int scrollX = getScrollX();
            int scrollY = getScrollY();
            int currX = this.l.getCurrX();
            int currY = this.l.getCurrY();
            if (scrollX != currX || scrollY != currY) {
                scrollTo(currX, currY);
                if (!d(currX)) {
                    this.l.abortAnimation();
                    scrollTo(0, currY);
                }
            }
            l.b(this);
            return;
        }
        a(true);
    }

    private boolean d(int i) {
        if (this.d.size() == 0) {
            this.U = false;
            a(0, BitmapDescriptorFactory.HUE_RED, 0);
            if (this.U) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
        b h2 = h();
        int width = getWidth();
        int i2 = this.n + width;
        int i3 = h2.b;
        float f2 = ((i / width) - h2.e) / (h2.d + (this.n / width));
        this.U = false;
        a(i3, f2, (int) (i2 * f2));
        if (!this.U) {
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
        return true;
    }

    protected void a(int i, float f2, int i2) {
        int measuredWidth;
        int i3;
        int i4;
        if (this.V > 0) {
            int scrollX = getScrollX();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int width = getWidth();
            int childCount = getChildCount();
            int i5 = 0;
            while (i5 < childCount) {
                View childAt = getChildAt(i5);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (layoutParams.a) {
                    switch (layoutParams.b & 7) {
                        case 1:
                            measuredWidth = Math.max((width - childAt.getMeasuredWidth()) / 2, paddingLeft);
                            int i6 = paddingRight;
                            i3 = paddingLeft;
                            i4 = i6;
                            break;
                        case 2:
                        case 4:
                        default:
                            measuredWidth = paddingLeft;
                            int i7 = paddingRight;
                            i3 = paddingLeft;
                            i4 = i7;
                            break;
                        case 3:
                            int width2 = childAt.getWidth() + paddingLeft;
                            int i8 = paddingLeft;
                            i4 = paddingRight;
                            i3 = width2;
                            measuredWidth = i8;
                            break;
                        case 5:
                            measuredWidth = (width - paddingRight) - childAt.getMeasuredWidth();
                            int measuredWidth2 = paddingRight + childAt.getMeasuredWidth();
                            i3 = paddingLeft;
                            i4 = measuredWidth2;
                            break;
                    }
                    int left = (measuredWidth + scrollX) - childAt.getLeft();
                    if (left != 0) {
                        childAt.offsetLeftAndRight(left);
                    }
                } else {
                    int i9 = paddingRight;
                    i3 = paddingLeft;
                    i4 = i9;
                }
                i5++;
                int i10 = i4;
                paddingLeft = i3;
                paddingRight = i10;
            }
        }
        if (this.N < 0 || i < this.N) {
            this.N = i;
        }
        if (this.O < 0 || FloatMath.ceil(i + f2) > this.O) {
            this.O = i + 1;
        }
        if (this.W != null) {
            this.W.a(i, f2, i2);
        }
        if (this.Z != null) {
            this.Z.a(i, f2, i2);
        }
        if (this.ab != null) {
            int scrollX2 = getScrollX();
            int childCount2 = getChildCount();
            for (int i11 = 0; i11 < childCount2; i11++) {
                View childAt2 = getChildAt(i11);
                if (!((LayoutParams) childAt2.getLayoutParams()).a) {
                    this.ab.a(childAt2, (childAt2.getLeft() - scrollX2) / getWidth());
                }
            }
        }
        this.U = true;
    }

    private void a(boolean z) {
        boolean z2 = this.ah == 2;
        if (z2) {
            setScrollingCacheEnabled(false);
            this.l.abortAnimation();
            int scrollX = getScrollX();
            int scrollY = getScrollY();
            int currX = this.l.getCurrX();
            int currY = this.l.getCurrY();
            if (scrollX != currX || scrollY != currY) {
                scrollTo(currX, currY);
            }
        }
        this.x = false;
        boolean z3 = z2;
        for (int i = 0; i < this.d.size(); i++) {
            b bVar = this.d.get(i);
            if (bVar.c) {
                bVar.c = false;
                z3 = true;
            }
        }
        if (z3) {
            if (z) {
                l.a(this, this.ag);
            } else {
                this.ag.run();
            }
        }
    }

    private boolean a(float f2, float f3) {
        return (f2 < ((float) this.C) && f3 > BitmapDescriptorFactory.HUE_RED) || (f2 > ((float) (getWidth() - this.C)) && f3 < BitmapDescriptorFactory.HUE_RED);
    }

    private void b(boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            l.a(getChildAt(i), z ? 2 : 0, null);
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & android.support.v4.view.f.ACTION_MASK;
        if (action == 3 || action == 1) {
            this.z = false;
            this.A = false;
            this.H = -1;
            if (this.I == null) {
                return false;
            }
            this.I.recycle();
            this.I = null;
            return false;
        }
        if (action != 0) {
            if (this.z) {
                return true;
            }
            if (this.A) {
                return false;
            }
        }
        switch (action) {
            case 0:
                float x = motionEvent.getX();
                this.E = x;
                this.F = x;
                this.G = motionEvent.getY();
                this.H = android.support.v4.view.f.b(motionEvent, 0);
                this.A = false;
                this.l.computeScrollOffset();
                if (this.ah == 2 && Math.abs(this.l.getFinalX() - this.l.getCurrX()) > this.M) {
                    this.l.abortAnimation();
                    this.x = false;
                    c();
                    this.z = true;
                    setScrollState(1);
                    break;
                } else {
                    a(false);
                    this.z = false;
                    break;
                }
            case 2:
                int i = this.H;
                if (i != -1) {
                    int a2 = android.support.v4.view.f.a(motionEvent, i);
                    float c2 = android.support.v4.view.f.c(motionEvent, a2);
                    float f2 = c2 - this.F;
                    float abs = Math.abs(f2);
                    float d2 = android.support.v4.view.f.d(motionEvent, a2);
                    float abs2 = Math.abs(d2 - this.G);
                    if (f2 != BitmapDescriptorFactory.HUE_RED && !a(this.F, f2) && a(this, false, (int) f2, (int) c2, (int) d2)) {
                        this.F = c2;
                        this.E = c2;
                        this.G = d2;
                        this.A = true;
                        return false;
                    }
                    if (abs > this.D && abs > abs2) {
                        this.z = true;
                        setScrollState(1);
                        this.F = f2 > BitmapDescriptorFactory.HUE_RED ? this.E + this.D : this.E - this.D;
                        setScrollingCacheEnabled(true);
                    } else if (abs2 > this.D) {
                        this.A = true;
                    }
                    if (this.z && b(c2)) {
                        l.b(this);
                        break;
                    }
                }
                break;
            case 6:
                a(motionEvent);
                break;
        }
        if (this.I == null) {
            this.I = VelocityTracker.obtain();
        }
        this.I.addMovement(motionEvent);
        return this.z;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z = false;
        if (this.P) {
            return true;
        }
        if (motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) {
            return false;
        }
        if (this.g == null || this.g.a() == 0) {
            return false;
        }
        if (this.I == null) {
            this.I = VelocityTracker.obtain();
        }
        this.I.addMovement(motionEvent);
        switch (motionEvent.getAction() & android.support.v4.view.f.ACTION_MASK) {
            case 0:
                this.l.abortAnimation();
                this.x = false;
                c();
                this.z = true;
                setScrollState(1);
                float x = motionEvent.getX();
                this.E = x;
                this.F = x;
                this.H = android.support.v4.view.f.b(motionEvent, 0);
                break;
            case 1:
                if (this.z) {
                    VelocityTracker velocityTracker = this.I;
                    velocityTracker.computeCurrentVelocity(1000, this.K);
                    int a2 = (int) j.a(velocityTracker, this.H);
                    this.x = true;
                    int width = getWidth();
                    int scrollX = getScrollX();
                    b h2 = h();
                    a(a(h2.b, ((scrollX / width) - h2.e) / h2.d, a2, (int) (android.support.v4.view.f.c(motionEvent, android.support.v4.view.f.a(motionEvent, this.H)) - this.E)), true, true, a2);
                    this.H = -1;
                    i();
                    z = this.R.c() | this.Q.c();
                    break;
                }
                break;
            case 2:
                if (!this.z) {
                    int a3 = android.support.v4.view.f.a(motionEvent, this.H);
                    float c2 = android.support.v4.view.f.c(motionEvent, a3);
                    float abs = Math.abs(c2 - this.F);
                    float abs2 = Math.abs(android.support.v4.view.f.d(motionEvent, a3) - this.G);
                    if (abs > this.D && abs > abs2) {
                        this.z = true;
                        this.F = c2 - this.E > BitmapDescriptorFactory.HUE_RED ? this.E + this.D : this.E - this.D;
                        setScrollState(1);
                        setScrollingCacheEnabled(true);
                    }
                }
                if (this.z) {
                    z = false | b(android.support.v4.view.f.c(motionEvent, android.support.v4.view.f.a(motionEvent, this.H)));
                    break;
                }
                break;
            case 3:
                if (this.z) {
                    a(this.h, true, 0, false);
                    this.H = -1;
                    i();
                    z = this.R.c() | this.Q.c();
                    break;
                }
                break;
            case 5:
                int a4 = android.support.v4.view.f.a(motionEvent);
                this.F = android.support.v4.view.f.c(motionEvent, a4);
                this.H = android.support.v4.view.f.b(motionEvent, a4);
                break;
            case 6:
                a(motionEvent);
                this.F = android.support.v4.view.f.c(motionEvent, android.support.v4.view.f.a(motionEvent, this.H));
                break;
        }
        if (z) {
            l.b(this);
        }
        return true;
    }

    private boolean b(float f2) {
        boolean z;
        float f3;
        boolean z2 = true;
        float f4 = this.F - f2;
        this.F = f2;
        float scrollX = getScrollX() + f4;
        int width = getWidth();
        float f5 = width * this.r;
        float f6 = width * this.s;
        b bVar = this.d.get(0);
        b bVar2 = this.d.get(this.d.size() - 1);
        if (bVar.b != 0) {
            f5 = bVar.e * width;
            z = false;
        } else {
            z = true;
        }
        if (bVar2.b != this.g.a() - 1) {
            f3 = bVar2.e * width;
            z2 = false;
        } else {
            f3 = f6;
        }
        if (scrollX < f5) {
            if (z) {
                r2 = this.Q.a(Math.abs(f5 - scrollX) / width);
            }
        } else if (scrollX > f3) {
            r2 = z2 ? this.R.a(Math.abs(scrollX - f3) / width) : false;
            f5 = f3;
        } else {
            f5 = scrollX;
        }
        this.F += f5 - ((int) f5);
        scrollTo((int) f5, getScrollY());
        d((int) f5);
        return r2;
    }

    private b h() {
        int i;
        b bVar;
        int width = getWidth();
        float scrollX = width > 0 ? getScrollX() / width : 0.0f;
        float f2 = width > 0 ? this.n / width : 0.0f;
        float f3 = 0.0f;
        float f4 = 0.0f;
        int i2 = -1;
        int i3 = 0;
        boolean z = true;
        b bVar2 = null;
        while (i3 < this.d.size()) {
            b bVar3 = this.d.get(i3);
            if (z || bVar3.b == i2 + 1) {
                i = i3;
                bVar = bVar3;
            } else {
                b bVar4 = this.e;
                bVar4.e = f3 + f4 + f2;
                bVar4.b = i2 + 1;
                bVar4.d = this.g.b(bVar4.b);
                i = i3 - 1;
                bVar = bVar4;
            }
            float f5 = bVar.e;
            float f6 = bVar.d + f5 + f2;
            if (!z && scrollX < f5) {
                return bVar2;
            }
            if (scrollX < f6 || i == this.d.size() - 1) {
                return bVar;
            }
            f4 = f5;
            i2 = bVar.b;
            z = false;
            f3 = bVar.d;
            bVar2 = bVar;
            i3 = i + 1;
        }
        return bVar2;
    }

    private int a(int i, float f2, int i2, int i3) {
        if (Math.abs(i3) > this.L && Math.abs(i2) > this.J) {
            if (i2 <= 0) {
                i++;
            }
        } else if (this.N >= 0 && this.N < i && f2 < 0.5f) {
            i++;
        } else if (this.O >= 0 && this.O > i + 1 && f2 >= 0.5f) {
            i--;
        } else {
            i = (int) (i + f2 + 0.5f);
        }
        if (this.d.size() > 0) {
            return Math.max(this.d.get(0).b, Math.min(i, this.d.get(this.d.size() - 1).b));
        }
        return i;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        boolean z = false;
        int a2 = l.a(this);
        if (a2 == 0 || (a2 == 1 && this.g != null && this.g.a() > 1)) {
            if (!this.Q.a()) {
                int save = canvas.save();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((-height) + getPaddingTop(), this.r * width);
                this.Q.a(height, width);
                z = false | this.Q.a(canvas);
                canvas.restoreToCount(save);
            }
            if (!this.R.a()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate(-getPaddingTop(), (-(this.s + 1.0f)) * width2);
                this.R.a(height2, width2);
                z |= this.R.a(canvas);
                canvas.restoreToCount(save2);
            }
        } else {
            this.Q.b();
            this.R.b();
        }
        if (z) {
            l.b(this);
        }
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        float f2;
        super.onDraw(canvas);
        if (this.n > 0 && this.o != null && this.d.size() > 0 && this.g != null) {
            int scrollX = getScrollX();
            int width = getWidth();
            float f3 = this.n / width;
            b bVar = this.d.get(0);
            float f4 = bVar.e;
            int size = this.d.size();
            int i = bVar.b;
            int i2 = this.d.get(size - 1).b;
            int i3 = 0;
            for (int i4 = i; i4 < i2; i4++) {
                while (i4 > bVar.b && i3 < size) {
                    i3++;
                    bVar = this.d.get(i3);
                }
                if (i4 == bVar.b) {
                    f2 = (bVar.e + bVar.d) * width;
                    f4 = bVar.e + bVar.d + f3;
                } else {
                    float b2 = this.g.b(i4);
                    f2 = (f4 + b2) * width;
                    f4 += b2 + f3;
                }
                if (this.n + f2 > scrollX) {
                    this.o.setBounds((int) f2, this.p, (int) (this.n + f2 + 0.5f), this.q);
                    this.o.draw(canvas);
                }
                if (f2 > scrollX + width) {
                    return;
                }
            }
        }
    }

    private void a(MotionEvent motionEvent) {
        int a2 = android.support.v4.view.f.a(motionEvent);
        if (android.support.v4.view.f.b(motionEvent, a2) == this.H) {
            int i = a2 == 0 ? 1 : 0;
            this.F = android.support.v4.view.f.c(motionEvent, i);
            this.H = android.support.v4.view.f.b(motionEvent, i);
            if (this.I != null) {
                this.I.clear();
            }
        }
    }

    private void i() {
        this.z = false;
        this.A = false;
        if (this.I != null) {
            this.I.recycle();
            this.I = null;
        }
    }

    private void setScrollingCacheEnabled(boolean z) {
        if (this.w != z) {
            this.w = z;
        }
    }

    protected boolean a(View view, boolean z, int i, int i2, int i3) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (i2 + scrollX >= childAt.getLeft() && i2 + scrollX < childAt.getRight() && i3 + scrollY >= childAt.getTop() && i3 + scrollY < childAt.getBottom() && a(childAt, true, i, (i2 + scrollX) - childAt.getLeft(), (i3 + scrollY) - childAt.getTop())) {
                    return true;
                }
            }
        }
        return z && l.a(view, -i);
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || a(keyEvent);
    }

    public boolean a(KeyEvent keyEvent) {
        if (keyEvent.getAction() != 0) {
            return false;
        }
        switch (keyEvent.getKeyCode()) {
            case 21:
                return c(17);
            case 22:
                return c(66);
            case 61:
                if (Build.VERSION.SDK_INT < 11) {
                    return false;
                }
                if (android.support.v4.view.d.a(keyEvent)) {
                    return c(2);
                }
                if (!android.support.v4.view.d.a(keyEvent, 1)) {
                    return false;
                }
                return c(1);
            default:
                return false;
        }
    }

    public boolean c(int i) {
        boolean d2;
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i);
        if (findNextFocus != null && findNextFocus != findFocus) {
            if (i == 17) {
                int i2 = a(this.f, findNextFocus).left;
                int i3 = a(this.f, findFocus).left;
                if (findFocus != null && i2 >= i3) {
                    d2 = d();
                } else {
                    d2 = findNextFocus.requestFocus();
                }
            } else {
                if (i == 66) {
                    int i4 = a(this.f, findNextFocus).left;
                    int i5 = a(this.f, findFocus).left;
                    if (findFocus != null && i4 <= i5) {
                        d2 = e();
                    } else {
                        d2 = findNextFocus.requestFocus();
                    }
                }
                d2 = false;
            }
        } else if (i == 17 || i == 1) {
            d2 = d();
        } else {
            if (i == 66 || i == 2) {
                d2 = e();
            }
            d2 = false;
        }
        if (d2) {
            playSoundEffect(SoundEffectConstants.getContantForFocusDirection(i));
        }
        return d2;
    }

    private Rect a(Rect rect, View view) {
        Rect rect2 = rect == null ? new Rect() : rect;
        if (view == null) {
            rect2.set(0, 0, 0, 0);
            return rect2;
        }
        rect2.left = view.getLeft();
        rect2.right = view.getRight();
        rect2.top = view.getTop();
        rect2.bottom = view.getBottom();
        ViewParent parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = (ViewGroup) parent;
            rect2.left += viewGroup.getLeft();
            rect2.right += viewGroup.getRight();
            rect2.top += viewGroup.getTop();
            rect2.bottom += viewGroup.getBottom();
            parent = viewGroup.getParent();
        }
        return rect2;
    }

    boolean d() {
        if (this.h <= 0) {
            return false;
        }
        a(this.h - 1, true);
        return true;
    }

    boolean e() {
        if (this.g == null || this.h >= this.g.a() - 1) {
            return false;
        }
        a(this.h + 1, true);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        b a2;
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() == 0 && (a2 = a(childAt)) != null && a2.b == this.h) {
                    childAt.addFocusables(arrayList, i, i2);
                }
            }
        }
        if ((descendantFocusability != 262144 || size == arrayList.size()) && isFocusable()) {
            if (((i2 & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) && arrayList != null) {
                arrayList.add(this);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addTouchables(ArrayList<View> arrayList) {
        b a2;
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0 && (a2 = a(childAt)) != null && a2.b == this.h) {
                childAt.addTouchables(arrayList);
            }
        }
    }

    @Override // android.view.ViewGroup
    protected boolean onRequestFocusInDescendants(int i, Rect rect) {
        int i2;
        b a2;
        int i3 = -1;
        int childCount = getChildCount();
        if ((i & 2) != 0) {
            i3 = 1;
            i2 = 0;
        } else {
            i2 = childCount - 1;
            childCount = -1;
        }
        while (i2 != childCount) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0 && (a2 = a(childAt)) != null && a2.b == this.h && childAt.requestFocus(i, rect)) {
                return true;
            }
            i2 += i3;
        }
        return false;
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        b a2;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0 && (a2 = a(childAt)) != null && a2.b == this.h && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams();
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public class c extends android.support.v4.view.a {
        c() {
        }

        @Override // android.support.v4.view.a
        public void d(View view, AccessibilityEvent accessibilityEvent) {
            super.d(view, accessibilityEvent);
            accessibilityEvent.setClassName(ViewPager.class.getName());
        }

        @Override // android.support.v4.view.a
        public void a(View view, android.support.v4.view.a.a aVar) {
            super.a(view, aVar);
            aVar.a(ViewPager.class.getName());
            aVar.a(ViewPager.this.g != null && ViewPager.this.g.a() > 1);
            if (ViewPager.this.g != null && ViewPager.this.h >= 0 && ViewPager.this.h < ViewPager.this.g.a() - 1) {
                aVar.a(4096);
            }
            if (ViewPager.this.g != null && ViewPager.this.h > 0 && ViewPager.this.h < ViewPager.this.g.a()) {
                aVar.a(8192);
            }
        }

        @Override // android.support.v4.view.a
        public boolean a(View view, int i, Bundle bundle) {
            if (super.a(view, i, bundle)) {
                return true;
            }
            switch (i) {
                case 4096:
                    if (ViewPager.this.g == null || ViewPager.this.h < 0 || ViewPager.this.h >= ViewPager.this.g.a() - 1) {
                        return false;
                    }
                    ViewPager.this.setCurrentItem(ViewPager.this.h + 1);
                    return true;
                case 8192:
                    if (ViewPager.this.g == null || ViewPager.this.h <= 0 || ViewPager.this.h >= ViewPager.this.g.a()) {
                        return false;
                    }
                    ViewPager.this.setCurrentItem(ViewPager.this.h - 1);
                    return true;
                default:
                    return false;
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    private class g extends DataSetObserver {
        private g() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            ViewPager.this.b();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            ViewPager.this.b();
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public static class LayoutParams extends ViewGroup.LayoutParams {
        public boolean a;
        public int b;
        float c;
        boolean d;
        int e;
        int f;

        public LayoutParams() {
            super(-1, -1);
            this.c = BitmapDescriptorFactory.HUE_RED;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.c = BitmapDescriptorFactory.HUE_RED;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ViewPager.a);
            this.b = obtainStyledAttributes.getInteger(0, 48);
            obtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public static class h implements Comparator<View> {
        h() {
        }

        @Override // java.util.Comparator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(View view, View view2) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            LayoutParams layoutParams2 = (LayoutParams) view2.getLayoutParams();
            if (layoutParams.a != layoutParams2.a) {
                return layoutParams.a ? 1 : -1;
            }
            return layoutParams.e - layoutParams2.e;
        }
    }
}
