package android.support.v4.app;

import android.os.Bundle;

/* compiled from: LoaderManager.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public abstract class g {

    /* compiled from: LoaderManager.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public interface a<D> {
        android.support.v4.a.a<D> a(int i, Bundle bundle);

        void a(android.support.v4.a.a<D> aVar);

        void a(android.support.v4.a.a<D> aVar, D d);
    }

    public boolean a() {
        return false;
    }
}
