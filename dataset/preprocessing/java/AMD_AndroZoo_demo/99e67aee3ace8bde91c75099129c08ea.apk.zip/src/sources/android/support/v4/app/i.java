package android.support.v4.app;

import android.util.AndroidRuntimeException;

/* compiled from: SuperNotCalledException.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
final class i extends AndroidRuntimeException {
    public i(String str) {
        super(str);
    }
}
