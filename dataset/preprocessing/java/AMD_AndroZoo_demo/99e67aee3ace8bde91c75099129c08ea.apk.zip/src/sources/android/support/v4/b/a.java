package android.support.v4.b;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;

/* compiled from: ParcelableCompat.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public class a {
    public static <T> Parcelable.Creator<T> a(b<T> bVar) {
        if (Build.VERSION.SDK_INT >= 13) {
            d.a(bVar);
        }
        return new C0001a(bVar);
    }

    /* compiled from: ParcelableCompat.java */
    /* renamed from: android.support.v4.b.a$a, reason: collision with other inner class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    static class C0001a<T> implements Parcelable.Creator<T> {
        final b<T> a;

        public C0001a(b<T> bVar) {
            this.a = bVar;
        }

        @Override // android.os.Parcelable.Creator
        public T createFromParcel(Parcel parcel) {
            return this.a.a(parcel, null);
        }

        @Override // android.os.Parcelable.Creator
        public T[] newArray(int i) {
            return this.a.a(i);
        }
    }
}
