package android.support.v4.app;

import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: BackStackRecord.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
public final class b extends f implements Runnable {
    static final int OP_ADD = 1;
    static final int OP_ATTACH = 7;
    static final int OP_DETACH = 6;
    static final int OP_HIDE = 4;
    static final int OP_NULL = 0;
    static final int OP_REMOVE = 3;
    static final int OP_REPLACE = 2;
    static final int OP_SHOW = 5;
    static final String TAG = "FragmentManager";
    final e a;
    a b;
    a c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    boolean k;
    String m;
    boolean n;
    int p;
    CharSequence q;
    int r;
    CharSequence s;
    boolean l = true;
    int o = -1;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* compiled from: BackStackRecord.java */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/99e67aee3ace8bde91c75099129c08ea.apk/classes.dex */
    public static final class a {
        a a;
        a b;
        int c;
        Fragment d;
        int e;
        int f;
        int g;
        int h;
        ArrayList<Fragment> i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.o >= 0) {
            sb.append(" #");
            sb.append(this.o);
        }
        if (this.m != null) {
            sb.append(" ");
            sb.append(this.m);
        }
        sb.append("}");
        return sb.toString();
    }

    public void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        a(str, printWriter, true);
    }

    public void a(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.m);
            printWriter.print(" mIndex=");
            printWriter.print(this.o);
            printWriter.print(" mCommitted=");
            printWriter.println(this.n);
            if (this.i != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.i));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.j));
            }
            if (this.e != 0 || this.f != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.e));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f));
            }
            if (this.g != 0 || this.h != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.g));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.h));
            }
            if (this.p != 0 || this.q != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.p));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.q);
            }
            if (this.r != 0 || this.s != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.r));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.s);
            }
        }
        if (this.b != null) {
            printWriter.print(str);
            printWriter.println("Operations:");
            String str3 = str + "    ";
            int i = 0;
            a aVar = this.b;
            while (aVar != null) {
                switch (aVar.c) {
                    case 0:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case 4:
                        str2 = "HIDE";
                        break;
                    case 5:
                        str2 = "SHOW";
                        break;
                    case 6:
                        str2 = "DETACH";
                        break;
                    case 7:
                        str2 = "ATTACH";
                        break;
                    default:
                        str2 = "cmd=" + aVar.c;
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println(aVar.d);
                if (z) {
                    if (aVar.e != 0 || aVar.f != 0) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.e));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f));
                    }
                    if (aVar.g != 0 || aVar.h != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.g));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.h));
                    }
                }
                if (aVar.i != null && aVar.i.size() > 0) {
                    for (int i2 = 0; i2 < aVar.i.size(); i2++) {
                        printWriter.print(str3);
                        if (aVar.i.size() == 1) {
                            printWriter.print("Removed: ");
                        } else {
                            if (i2 == 0) {
                                printWriter.println("Removed:");
                            }
                            printWriter.print(str3);
                            printWriter.print("  #");
                            printWriter.print(i2);
                            printWriter.print(": ");
                        }
                        printWriter.println(aVar.i.get(i2));
                    }
                }
                aVar = aVar.a;
                i++;
            }
        }
    }

    public b(e eVar) {
        this.a = eVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(a aVar) {
        if (this.b == null) {
            this.c = aVar;
            this.b = aVar;
        } else {
            aVar.b = this.c;
            this.c.a = aVar;
            this.c = aVar;
        }
        aVar.e = this.e;
        aVar.f = this.f;
        aVar.g = this.g;
        aVar.h = this.h;
        this.d++;
    }

    @Override // android.support.v4.app.f
    public f a(int i, Fragment fragment, String str) {
        a(i, fragment, str, 1);
        return this;
    }

    private void a(int i, Fragment fragment, String str, int i2) {
        fragment.mFragmentManager = this.a;
        if (str != null) {
            if (fragment.mTag != null && !str.equals(fragment.mTag)) {
                throw new IllegalStateException("Can't change tag of fragment " + fragment + ": was " + fragment.mTag + " now " + str);
            }
            fragment.mTag = str;
        }
        if (i != 0) {
            if (fragment.mFragmentId != 0 && fragment.mFragmentId != i) {
                throw new IllegalStateException("Can't change container ID of fragment " + fragment + ": was " + fragment.mFragmentId + " now " + i);
            }
            fragment.mFragmentId = i;
            fragment.mContainerId = i;
        }
        a aVar = new a();
        aVar.c = i2;
        aVar.d = fragment;
        a(aVar);
    }

    @Override // android.support.v4.app.f
    public f a(Fragment fragment) {
        a aVar = new a();
        aVar.c = 6;
        aVar.d = fragment;
        a(aVar);
        return this;
    }

    @Override // android.support.v4.app.f
    public f b(Fragment fragment) {
        a aVar = new a();
        aVar.c = 7;
        aVar.d = fragment;
        a(aVar);
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(int i) {
        if (this.k) {
            if (e.a) {
                Log.v(TAG, "Bump nesting in " + this + " by " + i);
            }
            for (a aVar = this.b; aVar != null; aVar = aVar.a) {
                if (aVar.d != null) {
                    aVar.d.mBackStackNesting += i;
                    if (e.a) {
                        Log.v(TAG, "Bump nesting of " + aVar.d + " to " + aVar.d.mBackStackNesting);
                    }
                }
                if (aVar.i != null) {
                    for (int size = aVar.i.size() - 1; size >= 0; size--) {
                        Fragment fragment = aVar.i.get(size);
                        fragment.mBackStackNesting += i;
                        if (e.a) {
                            Log.v(TAG, "Bump nesting of " + fragment + " to " + fragment.mBackStackNesting);
                        }
                    }
                }
            }
        }
    }

    @Override // android.support.v4.app.f
    public int a() {
        return a(false);
    }

    int a(boolean z) {
        if (this.n) {
            throw new IllegalStateException("commit already called");
        }
        if (e.a) {
            Log.v(TAG, "Commit: " + this);
            a("  ", (FileDescriptor) null, new PrintWriter(new android.support.v4.c.b(TAG)), (String[]) null);
        }
        this.n = true;
        if (this.k) {
            this.o = this.a.a(this);
        } else {
            this.o = -1;
        }
        this.a.a(this, z);
        return this.o;
    }

    @Override // java.lang.Runnable
    public void run() {
        Fragment fragment;
        if (e.a) {
            Log.v(TAG, "Run: " + this);
        }
        if (this.k && this.o < 0) {
            throw new IllegalStateException("addToBackStack() called after commit()");
        }
        a(1);
        for (a aVar = this.b; aVar != null; aVar = aVar.a) {
            switch (aVar.c) {
                case 1:
                    Fragment fragment2 = aVar.d;
                    fragment2.mNextAnim = aVar.e;
                    this.a.a(fragment2, false);
                    break;
                case 2:
                    Fragment fragment3 = aVar.d;
                    if (this.a.f != null) {
                        fragment = fragment3;
                        for (int i = 0; i < this.a.f.size(); i++) {
                            Fragment fragment4 = this.a.f.get(i);
                            if (e.a) {
                                Log.v(TAG, "OP_REPLACE: adding=" + fragment + " old=" + fragment4);
                            }
                            if (fragment == null || fragment4.mContainerId == fragment.mContainerId) {
                                if (fragment4 == fragment) {
                                    fragment = null;
                                    aVar.d = null;
                                } else {
                                    if (aVar.i == null) {
                                        aVar.i = new ArrayList<>();
                                    }
                                    aVar.i.add(fragment4);
                                    fragment4.mNextAnim = aVar.f;
                                    if (this.k) {
                                        fragment4.mBackStackNesting++;
                                        if (e.a) {
                                            Log.v(TAG, "Bump nesting of " + fragment4 + " to " + fragment4.mBackStackNesting);
                                        }
                                    }
                                    this.a.a(fragment4, this.i, this.j);
                                }
                            }
                        }
                    } else {
                        fragment = fragment3;
                    }
                    if (fragment != null) {
                        fragment.mNextAnim = aVar.e;
                        this.a.a(fragment, false);
                        break;
                    } else {
                        break;
                    }
                case 3:
                    Fragment fragment5 = aVar.d;
                    fragment5.mNextAnim = aVar.f;
                    this.a.a(fragment5, this.i, this.j);
                    break;
                case 4:
                    Fragment fragment6 = aVar.d;
                    fragment6.mNextAnim = aVar.f;
                    this.a.b(fragment6, this.i, this.j);
                    break;
                case 5:
                    Fragment fragment7 = aVar.d;
                    fragment7.mNextAnim = aVar.e;
                    this.a.c(fragment7, this.i, this.j);
                    break;
                case 6:
                    Fragment fragment8 = aVar.d;
                    fragment8.mNextAnim = aVar.f;
                    this.a.d(fragment8, this.i, this.j);
                    break;
                case 7:
                    Fragment fragment9 = aVar.d;
                    fragment9.mNextAnim = aVar.e;
                    this.a.e(fragment9, this.i, this.j);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + aVar.c);
            }
        }
        this.a.a(this.a.m, this.i, this.j, true);
        if (this.k) {
            this.a.b(this);
        }
    }

    public void b(boolean z) {
        if (e.a) {
            Log.v(TAG, "popFromBackStack: " + this);
            a("  ", (FileDescriptor) null, new PrintWriter(new android.support.v4.c.b(TAG)), (String[]) null);
        }
        a(-1);
        for (a aVar = this.c; aVar != null; aVar = aVar.b) {
            switch (aVar.c) {
                case 1:
                    Fragment fragment = aVar.d;
                    fragment.mNextAnim = aVar.h;
                    this.a.a(fragment, e.c(this.i), this.j);
                    break;
                case 2:
                    Fragment fragment2 = aVar.d;
                    if (fragment2 != null) {
                        fragment2.mNextAnim = aVar.h;
                        this.a.a(fragment2, e.c(this.i), this.j);
                    }
                    if (aVar.i != null) {
                        for (int i = 0; i < aVar.i.size(); i++) {
                            Fragment fragment3 = aVar.i.get(i);
                            fragment3.mNextAnim = aVar.g;
                            this.a.a(fragment3, false);
                        }
                        break;
                    } else {
                        break;
                    }
                case 3:
                    Fragment fragment4 = aVar.d;
                    fragment4.mNextAnim = aVar.g;
                    this.a.a(fragment4, false);
                    break;
                case 4:
                    Fragment fragment5 = aVar.d;
                    fragment5.mNextAnim = aVar.g;
                    this.a.c(fragment5, e.c(this.i), this.j);
                    break;
                case 5:
                    Fragment fragment6 = aVar.d;
                    fragment6.mNextAnim = aVar.h;
                    this.a.b(fragment6, e.c(this.i), this.j);
                    break;
                case 6:
                    Fragment fragment7 = aVar.d;
                    fragment7.mNextAnim = aVar.g;
                    this.a.e(fragment7, e.c(this.i), this.j);
                    break;
                case 7:
                    Fragment fragment8 = aVar.d;
                    fragment8.mNextAnim = aVar.g;
                    this.a.d(fragment8, e.c(this.i), this.j);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + aVar.c);
            }
        }
        if (z) {
            this.a.a(this.a.m, e.c(this.i), this.j, true);
        }
        if (this.o >= 0) {
            this.a.b(this.o);
            this.o = -1;
        }
    }

    public String b() {
        return this.m;
    }
}
