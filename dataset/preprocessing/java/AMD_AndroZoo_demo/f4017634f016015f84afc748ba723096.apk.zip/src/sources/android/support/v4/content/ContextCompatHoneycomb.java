package android.support.v4.content;

import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
class ContextCompatHoneycomb {
    ContextCompatHoneycomb() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void startActivities(Context context, Intent[] intents) {
        context.startActivities(intents);
    }
}
