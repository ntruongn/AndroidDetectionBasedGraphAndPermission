package com.feiwoone.banner.c;

import java.io.Serializable;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class a implements Serializable {
    private String a;
    private ArrayList b;
    private int c;
    private int d;
    private int e;
    private ArrayList f;
    private int g;
    private int h;
    private double i;
    private double j;
    private int k;
    private String l;
    private String m;
    private String n;
    private Boolean o;
    private boolean p;
    private boolean q;

    public a() {
        this.l = "";
    }

    public a(JSONObject jSONObject) {
        this.l = "";
        try {
            if (jSONObject.has("image")) {
                this.a = jSONObject.getString("image");
            }
            if (jSONObject.has("text")) {
                JSONArray jSONArray = jSONObject.getJSONArray("text");
                if (this.b == null) {
                    this.b = new ArrayList();
                } else {
                    this.b.clear();
                }
                for (int i = 0; i < jSONArray.length(); i++) {
                    this.b.add(jSONArray.optString(i));
                }
            }
            this.c = jSONObject.getInt("adid");
            this.d = jSONObject.getInt("showtype");
            this.e = jSONObject.getInt("clicktype");
            JSONArray jSONArray2 = jSONObject.getJSONArray("typevalue");
            for (int i2 = 0; i2 < jSONArray2.length(); i2++) {
                if (this.f == null) {
                    this.f = new ArrayList();
                }
                this.f.add(jSONArray2.optString(i2));
            }
            if (jSONObject.has("width")) {
                this.g = jSONObject.getInt("width");
            }
            if (jSONObject.has("height")) {
                this.h = jSONObject.getInt("height");
            }
            if (jSONObject.has("lat")) {
                this.i = jSONObject.getDouble("lat");
            }
            if (jSONObject.has("lon")) {
                this.j = jSONObject.getDouble("lon");
            }
            if (jSONObject.has("pushstring")) {
                this.l = jSONObject.getString("pushstring");
            }
            if (jSONObject.has("pushstringdesc")) {
                jSONObject.getString("pushstringdesc");
            }
            if (jSONObject.has("pushimage")) {
                jSONObject.getString("pushimage");
            }
            this.k = jSONObject.getInt("refreshtime");
            if (jSONObject.has("distance")) {
                jSONObject.getInt("distance");
            }
            if (jSONObject.has("isclick")) {
                this.o = Boolean.valueOf(jSONObject.getBoolean("isclick"));
            }
            if (!jSONObject.has("wapurl") || jSONObject.optString("wapurl") == null) {
                this.m = null;
            } else {
                this.m = jSONObject.optString("wapurl");
            }
            if (jSONObject.has("packagename")) {
                this.n = jSONObject.optString("packagename");
            }
            jSONObject.optInt("clickcount", 3);
            this.p = "true".equals(jSONObject.optString("notifiKeep", "false").trim());
            this.q = "true".equals(jSONObject.optString("gprsDown", "false").trim());
        } catch (JSONException e) {
        }
    }

    public final Boolean a() {
        return this.o;
    }

    public final void a(int i) {
        this.k = i;
    }

    public final String b() {
        return this.l;
    }

    public final String c() {
        return this.m;
    }

    public final String d() {
        return this.a;
    }

    public final ArrayList e() {
        return this.b;
    }

    public final int f() {
        return this.d;
    }

    public final int g() {
        return this.e;
    }

    public final ArrayList h() {
        return this.f;
    }

    public final int i() {
        return this.c;
    }

    public final int j() {
        return this.g;
    }

    public final int k() {
        return this.h;
    }

    public final double l() {
        return this.i;
    }

    public final double m() {
        return this.j;
    }

    public final int n() {
        return this.k;
    }

    public final String o() {
        return this.n;
    }

    public final boolean p() {
        return this.p;
    }

    public final boolean q() {
        return this.q;
    }
}
