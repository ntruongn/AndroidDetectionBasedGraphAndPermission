package com.feiwothree.coverscreen;

/* JADX INFO: Access modifiers changed from: package-private */
/* renamed from: com.feiwothree.coverscreen.a, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class C0004a extends Thread {
    private /* synthetic */ AdComponent a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public C0004a(AdComponent adComponent) {
        this.a = adComponent;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        try {
            if (!this.a.e().getSharedPreferences("coverscreen", 0).getBoolean("isFirstRun", true)) {
                AdComponent.b(this.a);
            } else {
                try {
                    Thread.sleep(60000L);
                } catch (InterruptedException e) {
                }
                AdComponent.a(this.a);
            }
        } catch (Exception e2) {
        }
    }
}
