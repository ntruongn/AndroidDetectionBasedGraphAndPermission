package com.baidu.mobstat;

import android.app.Activity;
import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class StatActivity extends Activity {
    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        com.baidu.mobstat.a.c.a("stat", "StatActivity.OnResume()");
        StatService.onPause((Context) this);
    }

    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        com.baidu.mobstat.a.c.a("stat", "StatActivity.OnResume()");
        StatService.onResume((Context) this);
    }
}
