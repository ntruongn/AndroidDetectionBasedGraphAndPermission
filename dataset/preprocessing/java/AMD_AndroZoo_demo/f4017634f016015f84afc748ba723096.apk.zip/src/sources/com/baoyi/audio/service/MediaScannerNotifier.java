package com.baoyi.audio.service;

import android.content.Context;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.util.Log;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MediaScannerNotifier implements MediaScannerConnection.MediaScannerConnectionClient {
    private static int mScannedFilesInProgress = 0;
    private File file;
    private MediaScannerConnection mConnection;
    private Context mService;

    public MediaScannerNotifier(Context service, File file) {
        this.file = file;
        this.mService = service;
        this.mConnection = new MediaScannerConnection(this.mService, this);
        this.mConnection.connect();
    }

    @Override // android.media.MediaScannerConnection.MediaScannerConnectionClient
    public void onMediaScannerConnected() {
        if (this.mConnection.isConnected()) {
            this.mConnection.scanFile(this.file.getAbsolutePath(), null);
            mScannedFilesInProgress++;
        }
    }

    @Override // android.media.MediaScannerConnection.OnScanCompletedListener
    public void onScanCompleted(String text, Uri uri) {
        Log.i("ada", "Added to media library -> " + uri.toString());
        this.mConnection.disconnect();
    }
}
