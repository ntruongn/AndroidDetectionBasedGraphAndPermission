package com.baoyi.doamin;

import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class PlayList {
    private String bang_date;
    private String bang_img;
    private List<KoWoMusic> list;

    public List<KoWoMusic> getList() {
        return this.list;
    }

    public void setList(List<KoWoMusic> list) {
        this.list = list;
    }

    public String getBang_img() {
        return this.bang_img;
    }

    public void setBang_img(String bang_img) {
        this.bang_img = bang_img;
    }

    public String getBang_date() {
        return this.bang_date;
    }

    public void setBang_date(String bang_date) {
        this.bang_date = bang_date;
    }
}
