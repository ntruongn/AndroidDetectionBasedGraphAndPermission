package com.feiwoone.banner.c;

import java.io.Serializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class b implements Serializable {
    private int a;
    private String b;
    private String c;
    private String d;
    private String e;
    private boolean f;

    public b() {
    }

    public b(int i, String str, String str2, String str3, String str4, boolean z) {
        this.a = i;
        this.e = str;
        this.b = null;
        this.c = str3;
        this.d = str4;
        this.f = z;
    }

    public final int a() {
        return this.a;
    }

    public final void a(int i) {
    }

    public final void a(long j) {
    }

    public final String b() {
        return this.d;
    }

    public final void b(long j) {
    }

    public final String c() {
        return this.b;
    }

    public final String d() {
        return this.c;
    }

    public final boolean e() {
        return this.f;
    }

    public final String f() {
        return this.e;
    }
}
