package com.baoyi.audio.fragment;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.baoyi.audio.adapter.CommentItemListAdapter;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.entity.Comment;
import com.iring.rpc.RpcSerializable;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class CommentsFragment extends Fragment implements View.OnClickListener {
    private CommentItemListAdapter adapter;
    EditText editText;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    private int musicid;
    int page = 0;
    Button talk;

    public CommentsFragment(int musicid) {
        this.musicid = musicid;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.talk = (Button) getView().findViewById(R.id.talk);
        this.talk.setOnClickListener(this);
        this.editText = (EditText) getView().findViewById(R.id.editText);
        this.mPullRefreshListView = (PullToRefreshListView) getView().findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() { // from class: com.baoyi.audio.fragment.CommentsFragment.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener
            public void onRefresh(PullToRefreshBase<ListView> refreshView) {
                Log.i("ada", "加载");
                new HotTask(CommentsFragment.this, null).execute(Integer.valueOf(CommentsFragment.this.page));
            }
        });
        WidgetLoadling tv = new WidgetLoadling(getActivity());
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new CommentItemListAdapter(getActivity());
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setBackgroundColor(Color.parseColor("#00000000"));
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("com.iym.imusic_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(getActivity());
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
        new HotTask(this, null).execute(Integer.valueOf(this.page));
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_comments, container, false);
        return view;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Comment>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(CommentsFragment commentsFragment, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Comment> doInBackground(Integer... params) {
            long time = System.currentTimeMillis();
            List<Comment> temp = null;
            try {
                temp = RpcUtils2.getCommentRpc().pageByMusicId(CommentsFragment.this.musicid, content.showsize, params[0].intValue()).getDatas();
                if (System.currentTimeMillis() - time < 1000) {
                    Thread.sleep(1500L);
                }
            } catch (Exception e) {
            }
            return temp;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Comment> result) {
            CommentsFragment.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.PULL_UP_TO_REFRESH);
            if (result != null) {
                for (Comment music : result) {
                    CommentsFragment.this.adapter.addLast(music);
                }
                CommentsFragment.this.adapter.notifyDataSetChanged();
                CommentsFragment.this.mPullRefreshListView.onRefreshComplete();
                CommentsFragment.this.page++;
                return;
            }
            if (CommentsFragment.this.page == 0) {
                CommentsFragment.this.mPullRefreshListView.setEmptyView(null);
            }
            CommentsFragment.this.mPullRefreshListView.onRefreshComplete();
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        Comment ommentc = new Comment();
        String commentss = this.editText.getEditableText().toString();
        if (commentss == null || commentss.length() < 2) {
            this.editText.setError("请留下你现在的心情");
            return;
        }
        ommentc.setMusicid(this.musicid);
        ommentc.setContent(commentss);
        ommentc.setName(getname());
        new TalkTask(this, null).execute(ommentc);
    }

    private String getname() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("apps", 0);
        return sharedPreferences.getString(UpdateService.NAME, "游客");
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class TalkTask extends AsyncTask<Comment, Void, RpcSerializable> {
        private TalkTask() {
        }

        /* synthetic */ TalkTask(CommentsFragment commentsFragment, TalkTask talkTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public RpcSerializable doInBackground(Comment... params) {
            RpcSerializable rpcSerializable = new RpcSerializable();
            System.currentTimeMillis();
            try {
                Comment comment = params[0];
                RpcUtils2.getCommentRpc().comment(comment.getName(), comment.getMusicid(), comment.getContent());
                rpcSerializable.setCode(1);
                comment.setTime(System.currentTimeMillis());
                CommentsFragment.this.adapter.addLast(comment);
            } catch (Exception e) {
            }
            return rpcSerializable;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(RpcSerializable result) {
            CommentsFragment.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.PULL_UP_TO_REFRESH);
            if (result.getCode() == 1) {
                Toast.makeText(CommentsFragment.this.getActivity(), "留心情成功", 0).show();
                CommentsFragment.this.editText.getText().clear();
                CommentsFragment.this.listView.setSelection(0);
                CommentsFragment.this.adapter.notifyDataSetChanged();
                return;
            }
            Toast.makeText(CommentsFragment.this.getActivity(), "留心情失败", 0).show();
        }
    }
}
