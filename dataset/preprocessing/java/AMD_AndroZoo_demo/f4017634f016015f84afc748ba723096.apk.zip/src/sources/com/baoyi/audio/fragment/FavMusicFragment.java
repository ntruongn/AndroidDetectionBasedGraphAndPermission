package com.baoyi.audio.fragment;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.baoyi.audio.About;
import com.baoyi.audio.FeedBack;
import com.baoyi.audio.SettingsActivity;
import com.baoyi.audio.adapter.MusicItemListAdapter;
import com.baoyi.audio.cache.DataCache;
import com.baoyi.audio.task.ClearCacheTask;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class FavMusicFragment extends Fragment implements View.OnClickListener {
    MusicItemListAdapter adapter;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    int page = 0;
    int userid;

    public FavMusicFragment(int userid) {
        this.userid = userid;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.mPullRefreshListView = (PullToRefreshListView) getView().findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() { // from class: com.baoyi.audio.fragment.FavMusicFragment.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            }

            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                new HotTask(FavMusicFragment.this, null).execute(Integer.valueOf(FavMusicFragment.this.page));
            }
        });
        WidgetLoadling tv = new WidgetLoadling(getActivity());
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new MusicItemListAdapter(getActivity());
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("com.iym.imusic_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(getActivity());
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        new HotTask(this, null).execute(Integer.valueOf(this.page));
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Music>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(FavMusicFragment favMusicFragment, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Music> doInBackground(Integer... params) {
            String key = String.valueOf(FavMusicFragment.this.userid) + "RpcUtils2.getUserRpc().pageringfav" + params[0];
            List<Music> temp = DataCache.datas.get(key);
            if (temp == null || temp.size() == 0) {
                try {
                    return RpcUtils2.getUserRpc().pageringfav(Integer.valueOf(FavMusicFragment.this.userid), 80, params[0].intValue()).getDatas();
                } catch (Exception e) {
                    e.printStackTrace();
                    return temp;
                }
            }
            return temp;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Music> result) {
            if (result != null) {
                for (Music music : result) {
                    FavMusicFragment.this.adapter.addLast(music);
                }
                FavMusicFragment.this.adapter.notifyDataSetChanged();
                FavMusicFragment.this.mPullRefreshListView.onRefreshComplete();
                FavMusicFragment.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + FavMusicFragment.this.adapter.getCount() + "首铃声");
                FavMusicFragment.this.page++;
                return;
            }
            if (FavMusicFragment.this.page == 0) {
                FavMusicFragment.this.mPullRefreshListView.setEmptyView(null);
                Activity a = FavMusicFragment.this.getActivity();
                if (a != null) {
                    Toast.makeText(FavMusicFragment.this.getActivity(), "获取数据失败，请稍候再试。", 0).show();
                }
            }
            FavMusicFragment.this.mPullRefreshListView.onRefreshComplete();
        }
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favmusic_list_new, container, false);
        return view;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        v.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.max));
        if (v.getId() == 2131296355) {
            new ClearCacheTask(getActivity()).execute(new Integer[0]);
        }
        if (v.getId() == 2131296356) {
            Intent intent = new Intent(getActivity(), (Class<?>) About.class);
            intent.putExtra("type", 3);
            startActivity(intent);
        }
        if (v.getId() == 2131296338) {
            startActivity(new Intent(getActivity(), (Class<?>) FeedBack.class));
        }
        if (v.getId() == 2131296357) {
            Intent intent2 = new Intent(getActivity(), (Class<?>) About.class);
            intent2.putExtra("type", 2);
            startActivity(intent2);
        }
        if (v.getId() == 2131296358) {
            rateApplication();
        }
        if (v.getId() == 2131296354) {
            setting();
        }
    }

    private void setting() {
        Intent rateIntent = new Intent(getActivity(), (Class<?>) SettingsActivity.class);
        startActivity(rateIntent);
    }

    protected void rateApplication() {
        Intent rateIntent = new Intent("android.intent.action.VIEW");
        rateIntent.setData(Uri.parse("market://details?id=" + getActivity().getPackageName()));
        startActivity(rateIntent);
    }
}
