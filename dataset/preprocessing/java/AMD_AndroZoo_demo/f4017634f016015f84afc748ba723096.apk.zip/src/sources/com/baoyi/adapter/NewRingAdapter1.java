package com.baoyi.adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.baoyi.audio.dialog.WorkDialog;
import com.baoyi.audio.service.DownloadService;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.task.DownTask;
import com.baoyi.audio.task.SetAudioTask;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.doamin.CheckWork;
import com.baoyi.utils.MusicUtils;
import com.baoyi.utils.Utils;
import com.baoyi.weight.ActionItem;
import com.baoyi.weight.QuickAction;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import com.iring.rpc.RpcSerializable;
import com.ringdroid.ChooseContactActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class NewRingAdapter1 extends BaseAdapter implements AdapterView.OnItemClickListener {
    public static final String ACTION_MEDIA_SCANNER_SCAN_DIR = "android.intent.action.MEDIA_SCANNER_SCAN_DIR";
    private static final int REQUEST_CODE_CHOOSE_CONTACT = 2;
    private static MediaPlayer myMediaPlayer;
    private ArrayList<Music> Musics;
    private Activity context;
    private int curDuration;
    private int failplaysize;
    ViewHolder holder;
    private LayoutInflater li;
    private Music m;
    private int maxDuration;
    private Music mmm;
    private int num;
    private int currentPosition = -1;
    private Handler myHandler = new Handler();
    CheckWork checked = new CheckWork();
    private int playposition = -1;
    private Runnable works = new Runnable() { // from class: com.baoyi.adapter.NewRingAdapter1.1
        @Override // java.lang.Runnable
        public void run() {
            NewRingAdapter1.this.countTime();
            NewRingAdapter1.this.holder.seekBar.setProgress(NewRingAdapter1.this.curDuration);
            NewRingAdapter1.this.myHandler.postDelayed(NewRingAdapter1.this.works, 1000L);
            NewRingAdapter1.this.notifyDataSetChanged();
        }
    };
    private String nowTime = "";

    public NewRingAdapter1(Activity context, ArrayList<Music> musics) {
        this.Musics = musics;
        this.li = LayoutInflater.from(context);
        this.context = context;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.Musics != null) {
            return this.Musics.size();
        }
        return 0;
    }

    @Override // android.widget.Adapter
    public Object getItem(int arg0) {
        if (this.Musics != null) {
            return this.Musics.get(arg0);
        }
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return position;
    }

    public void addLast(Music item) {
        this.Musics.add(item);
    }

    public void clean() {
        this.Musics.clear();
    }

    public int setcurrentPosition(int p) {
        this.currentPosition = p;
        return this.currentPosition;
    }

    @Override // android.widget.Adapter
    public View getView(final int position, View cv, ViewGroup parent) {
        if (cv == null) {
            this.holder = new ViewHolder();
            cv = this.li.inflate(R.layout.widget_ring_webmusic, (ViewGroup) null);
            this.holder.play = (ImageView) cv.findViewById(R.id.item_ring_playBtn);
            this.holder.stop = (ImageView) cv.findViewById(R.id.item_ring_puseBtn);
            this.holder.down = (ImageView) cv.findViewById(R.id.item_ring_downBtn);
            this.holder.share = (ImageView) cv.findViewById(R.id.item_ring_shareBtn);
            this.holder.useAs = (ImageView) cv.findViewById(R.id.item_ring_useAsBtn);
            this.holder.musicName = (TextView) cv.findViewById(R.id.item_ring_musicNameTv);
            this.holder.time = (TextView) cv.findViewById(R.id.item_ring_timeTv);
            this.holder.musicName = (TextView) cv.findViewById(R.id.item_ring_musicNameTv);
            this.holder.singer = (TextView) cv.findViewById(R.id.item_ring_singerNameTv);
            this.holder.hot = (TextView) cv.findViewById(R.id.item_ring_hotsTv);
            this.holder.downTimes = (TextView) cv.findViewById(R.id.item_ring_downloadtimesTv);
            this.holder.seekBar = (SeekBar) cv.findViewById(R.id.item_ring_SeekBar);
            this.holder.hid = (LinearLayout) cv.findViewById(R.id.item_ring_hidLl);
            cv.setTag(this.holder);
        } else {
            this.holder = (ViewHolder) cv.getTag();
        }
        this.m = this.Musics.get(position);
        if (this.playposition == position) {
            enablebuttons();
            this.holder.time.setText(this.nowTime);
            this.holder.seekBar.setMax(this.maxDuration);
            this.holder.seekBar.setProgress(this.curDuration);
        } else {
            disablebuttons();
        }
        this.holder.musicName.setText(new StringBuilder(String.valueOf(this.m.getName())).toString());
        this.holder.singer.setText(new StringBuilder(String.valueOf(this.m.getArtist())).toString());
        this.holder.hot.setText("试听：" + this.m.getHit());
        this.holder.downTimes.setText("下载：" + this.m.getDownload());
        if (position == this.currentPosition) {
            this.holder.hid.setVisibility(0);
        } else {
            this.holder.hid.setVisibility(8);
        }
        this.holder.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.baoyi.adapter.NewRingAdapter1.2
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && NewRingAdapter1.myMediaPlayer != null && NewRingAdapter1.myMediaPlayer.isPlaying()) {
                    NewRingAdapter1.myMediaPlayer.seekTo(progress);
                }
            }
        });
        this.holder.play.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.adapter.NewRingAdapter1.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (NewRingAdapter1.this.playposition != -1) {
                    NewRingAdapter1.this.doPauseResume();
                }
                Music m = (Music) NewRingAdapter1.this.Musics.get(position);
                NewRingAdapter1.this.doPauseResume();
                NewRingAdapter1.this.playAudio(m);
                NewRingAdapter1.this.playposition = position;
                NewRingAdapter1.this.setcurrentPosition(NewRingAdapter1.this.playposition);
                NewRingAdapter1.this.notifyDataSetChanged();
            }
        });
        final QuickAction paihangbangMenu = new QuickAction(this.context, 1);
        ActionItem item1 = new ActionItem(1, "设置为来电铃声", this.context.getResources().getDrawable(R.drawable.nothing_pic));
        ActionItem item2 = new ActionItem(2, "设置为短信铃声", this.context.getResources().getDrawable(R.drawable.nothing_pic));
        ActionItem item3 = new ActionItem(3, "设置为提示音", this.context.getResources().getDrawable(R.drawable.nothing_pic));
        ActionItem item4 = new ActionItem(4, "设置为闹铃", this.context.getResources().getDrawable(R.drawable.nothing_pic));
        ActionItem item5 = new ActionItem(5, "设置个性联系人", this.context.getResources().getDrawable(R.drawable.nothing_pic));
        paihangbangMenu.addActionItem(item1);
        paihangbangMenu.addActionItem(item2);
        paihangbangMenu.addActionItem(item3);
        paihangbangMenu.addActionItem(item4);
        paihangbangMenu.addActionItem(item5);
        this.holder.stop.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.adapter.NewRingAdapter1.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                NewRingAdapter1.this.doPauseResume();
                NewRingAdapter1.this.notifyDataSetChanged();
                NewRingAdapter1.this.playposition = -1;
            }
        });
        this.holder.useAs.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.adapter.NewRingAdapter1.5
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                System.out.println("useAs");
                final Music m = (Music) NewRingAdapter1.this.Musics.get(position);
                paihangbangMenu.show(v);
                paihangbangMenu.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() { // from class: com.baoyi.adapter.NewRingAdapter1.5.1
                    @Override // com.baoyi.weight.QuickAction.OnActionItemClickListener
                    public void onItemClick(QuickAction source, int pos, int actionId) {
                        switch (actionId) {
                            case 1:
                                new DownTask().execute(m.getId());
                                if (Utils.IsCanUseSdCard()) {
                                    NewRingAdapter1.this.checked = new CheckWork();
                                    NewRingAdapter1.this.checked.setIsringtones(true);
                                    new SetAudioTask(NewRingAdapter1.this.context, NewRingAdapter1.this.checked).execute(String.valueOf(content.mp3server) + m.getUrl(), m.getName());
                                    return;
                                }
                                Toast.makeText(NewRingAdapter1.this.context, "sd卡不可用,请检查你的sd卡", 1).show();
                                return;
                            case 2:
                                new DownTask().execute(m.getId());
                                if (Utils.IsCanUseSdCard()) {
                                    NewRingAdapter1.this.checked = new CheckWork();
                                    NewRingAdapter1.this.checked.setIsnotifications(true);
                                    new SetAudioTask(NewRingAdapter1.this.context, NewRingAdapter1.this.checked).execute(String.valueOf(content.mp3server) + m.getUrl(), m.getName());
                                    return;
                                }
                                Toast.makeText(NewRingAdapter1.this.context, "sd卡不可用,请检查你的sd卡", 1).show();
                                return;
                            case 3:
                                new DownTask().execute(m.getId());
                                if (Utils.IsCanUseSdCard()) {
                                    NewRingAdapter1.this.checked = new CheckWork();
                                    NewRingAdapter1.this.checked.setIspodcast(true);
                                    new SetAudioTask(NewRingAdapter1.this.context, NewRingAdapter1.this.checked).execute(String.valueOf(content.mp3server) + m.getUrl(), m.getName());
                                    return;
                                }
                                Toast.makeText(NewRingAdapter1.this.context, "sd卡不可用,请检查你的sd卡", 1).show();
                                return;
                            case 4:
                                new DownTask().execute(m.getId());
                                if (Utils.IsCanUseSdCard()) {
                                    NewRingAdapter1.this.checked = new CheckWork();
                                    NewRingAdapter1.this.checked.setIsalarms(true);
                                    new SetAudioTask(NewRingAdapter1.this.context, NewRingAdapter1.this.checked).execute(String.valueOf(content.mp3server) + m.getUrl(), m.getName());
                                    return;
                                }
                                Toast.makeText(NewRingAdapter1.this.context, "sd卡不可用,请检查你的sd卡", 1).show();
                                return;
                            case 5:
                                if (Utils.IsCanUseSdCard()) {
                                    NewRingAdapter1.this.checked = new CheckWork();
                                    NewRingAdapter1.this.checked.setIsalarms(true);
                                    new SetAudioTask121(NewRingAdapter1.this.context, NewRingAdapter1.this.checked).execute(String.valueOf(content.mp3server) + m.getUrl(), m.getName());
                                    return;
                                }
                                Toast.makeText(NewRingAdapter1.this.context, "sd卡不可用,请检查你的sd卡", 1).show();
                                return;
                            default:
                                return;
                        }
                    }
                });
            }
        });
        this.holder.share.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.adapter.NewRingAdapter1.6
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Music music = (Music) NewRingAdapter1.this.Musics.get(position);
                NewRingAdapter1.this.mmm = music;
                if (Utils.IsCanUseSdCard()) {
                    NewRingAdapter1.this.checked = new CheckWork();
                    NewRingAdapter1.this.checked.setIsalarms(true);
                    new shareTask(NewRingAdapter1.this.context, NewRingAdapter1.this.checked).execute(String.valueOf(content.mp3server) + music.getUrl(), music.getName());
                    return;
                }
                Toast.makeText(NewRingAdapter1.this.context, "sd卡不可用,请检查你的sd卡", 1).show();
            }
        });
        this.holder.down.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.adapter.NewRingAdapter1.7
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Music m = (Music) NewRingAdapter1.this.Musics.get(position);
                if (Utils.IsCanUseSdCard()) {
                    NewRingAdapter1.this.checked = new CheckWork();
                    NewRingAdapter1.this.checked.setIsalarms(true);
                    String mp3Url = String.valueOf(content.mp3server) + m.getUrl();
                    String ext = mp3Url.substring(mp3Url.lastIndexOf("."));
                    String path = String.valueOf(content.SAVEDIR) + m.getName() + ext;
                    File f = new File(path);
                    if (f.exists()) {
                        Utils.showMessage(NewRingAdapter1.this.context, "文件已存在");
                        return;
                    } else {
                        new downTask(NewRingAdapter1.this.context, NewRingAdapter1.this.checked).execute(String.valueOf(content.mp3server) + m.getUrl(), m.getName());
                        return;
                    }
                }
                Toast.makeText(NewRingAdapter1.this.context, "sd卡不可用,请检查你的sd卡", 1).show();
            }
        });
        return cv;
    }

    private boolean chooseContactForRingtone(MenuItem item) {
        try {
            Intent intent = new Intent("android.intent.action.EDIT", getUri());
            intent.setClass(this.context, ChooseContactActivity.class);
            this.context.startActivityForResult(intent, 2);
            return true;
        } catch (Exception e) {
            Log.e("Ringdroid", "Couldn't open Choose Contact window");
            return true;
        }
    }

    protected void sendRing(File file) {
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putSerializable("ring", file);
        intent.putExtras(bundle);
        intent.setAction("com.by.one.ring");
        this.context.sendBroadcast(intent);
    }

    private Uri getUri() {
        return Uri.parse(String.valueOf(content.mp3server) + this.m.getUrl());
    }

    public boolean onContextItemSelected(MenuItem item) {
        if (item.getItemId() == 7) {
            return chooseContactForRingtone(item);
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setOneRing(File file) {
        try {
            Intent intent = new Intent("android.intent.action.EDIT", getUri(file));
            intent.setClass(this.context, ChooseContactActivity.class);
            this.context.startActivityForResult(intent, 2);
        } catch (Exception e) {
            Log.e("Ringdroid", "Couldn't open Choose Contact window");
        }
    }

    private Uri getUri(File fileitem) {
        ContentValues cv = new ContentValues();
        Uri uri = MediaStore.Audio.Media.getContentUriForPath(fileitem.getAbsolutePath());
        Cursor cursor = this.context.getContentResolver().query(uri, null, "_data=?", new String[]{fileitem.getAbsolutePath()}, null);
        if (cursor.moveToFirst() && cursor.getCount() > 0) {
            String _id = cursor.getString(0);
            cv.put("is_ringtone", (Boolean) true);
            cv.put("is_notification", (Boolean) false);
            cv.put("is_alarm", (Boolean) false);
            cv.put("is_music", (Boolean) false);
            this.context.getContentResolver().update(uri, cv, "_data=?", new String[]{fileitem.getAbsolutePath()});
            Uri newUri = ContentUris.withAppendedId(uri, Long.valueOf(_id).longValue());
            return newUri;
        }
        cv.put("_data", fileitem.getAbsolutePath());
        Uri newUri2 = this.context.getContentResolver().insert(uri, cv);
        return newUri2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class ViewHolder {
        ImageView down;
        TextView downTimes;
        LinearLayout hid;
        TextView hot;
        TextView musicName;
        ImageView play;
        SeekBar seekBar;
        ImageView share;
        TextView singer;
        ImageView stop;
        TextView time;
        ImageView useAs;

        ViewHolder() {
        }
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        setcurrentPosition(arg2);
        notifyDataSetChanged();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doPauseResume() {
        try {
            if (myMediaPlayer != null) {
                if (myMediaPlayer.isPlaying()) {
                    myMediaPlayer.pause();
                } else {
                    myMediaPlayer.start();
                }
                setPauseButtonImage();
            }
        } catch (Exception e) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void playAudio(Music m) {
        String files = String.valueOf(content.SAVEDIR) + m.getName() + ".mp3";
        File file = new File(files);
        if (file.exists()) {
            String url = "file://" + files;
            setPath(url, m);
            return;
        }
        String url2 = m.getUrl();
        this.holder.seekBar.setSecondaryProgress(0);
        this.holder.seekBar.setProgress(0);
        this.holder.time.setText("0:00");
        setPath(String.valueOf(content.mp3server) + url2, m);
    }

    public void setPath(String uriString, final Music m) {
        try {
            disablebuttons();
            Uri uri = Uri.parse(uriString);
            relasePlayer();
            myMediaPlayer = new MediaPlayer();
            myMediaPlayer.setLooping(true);
            myMediaPlayer.setOnPreparedListener(new mediaPreparedListener(m));
            myMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.baoyi.adapter.NewRingAdapter1.8
                @Override // android.media.MediaPlayer.OnErrorListener
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    NewRingAdapter1.this.failplaysize++;
                    return false;
                }
            });
            myMediaPlayer.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() { // from class: com.baoyi.adapter.NewRingAdapter1.9
                @Override // android.media.MediaPlayer.OnBufferingUpdateListener
                public void onBufferingUpdate(MediaPlayer mp, int percent) {
                    int secondaryProgress = (int) ((percent / 100.0f) * NewRingAdapter1.this.holder.seekBar.getMax());
                    NewRingAdapter1.this.holder.seekBar.setSecondaryProgress(secondaryProgress);
                    if (percent <= 90) {
                        return;
                    }
                    NewRingAdapter1.this.downMusic(m);
                }
            });
            myMediaPlayer.setDataSource(this.context, uri);
            Runnable ting = new Runnable() { // from class: com.baoyi.adapter.NewRingAdapter1.10
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        NewRingAdapter1.myMediaPlayer.prepareAsync();
                    } catch (IllegalStateException e) {
                        e.printStackTrace();
                    }
                }
            };
            new Thread(ting).start();
            this.failplaysize = 0;
        } catch (Exception e) {
            this.failplaysize++;
        }
        notifyDataSetChanged();
    }

    public void init() {
        this.myHandler.postDelayed(this.works, 1000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void countTime() {
        if (myMediaPlayer != null) {
            if (myMediaPlayer.getCurrentPosition() != 0) {
                this.curDuration = myMediaPlayer.getCurrentPosition();
                this.maxDuration = myMediaPlayer.getDuration();
                this.nowTime = MusicUtils.makeTimeString(this.context, this.curDuration / 1000);
            }
            myMediaPlayer.isPlaying();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class mediaPreparedListener implements MediaPlayer.OnPreparedListener {
        private Music m;

        public mediaPreparedListener(Music m) {
            this.m = m;
        }

        @Override // android.media.MediaPlayer.OnPreparedListener
        public void onPrepared(MediaPlayer mp) {
            NewRingAdapter1.this.init();
            NewRingAdapter1.this.enablebuttons();
            NewRingAdapter1.this.holder.seekBar.setMax(NewRingAdapter1.myMediaPlayer.getDuration());
            Log.i("ddv", "duration::::" + NewRingAdapter1.myMediaPlayer.getDuration());
            NewRingAdapter1.this.myHandler.sendEmptyMessage(1);
            NewRingAdapter1.myMediaPlayer.start();
            NewRingAdapter1.this.setPauseButtonImage();
            SharedPreferences sharedPreferences = NewRingAdapter1.this.context.getSharedPreferences("com.iym.imusic_preferences", 0);
            boolean iscached = sharedPreferences.getBoolean("iscached", false);
            if (!iscached) {
                return;
            }
            NewRingAdapter1.this.downfile(this.m);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void downfile(Music m) {
        String files = String.valueOf(content.SAVEDIR) + m.getName() + ".mp3";
        File file = new File(files);
        if (!file.exists() && Utils.readSDCardMB() > 30) {
            Intent intent = new Intent(this.context, (Class<?>) DownloadService.class);
            intent.setAction(DownloadService.ACTION_ADD_TO_DOWNLOAD);
            intent.putExtra(UpdateService.NAME, m.getName());
            intent.putExtra("url", getmp3Path(m.getUrl()));
            intent.putExtra("isfront", false);
            this.context.startService(intent);
        }
    }

    public String getmp3Path(String url) {
        return String.valueOf(content.mp3server) + url;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setPauseButtonImage() {
        try {
            if (myMediaPlayer != null && myMediaPlayer.isPlaying()) {
                enablebuttons();
            } else {
                disablebuttons();
            }
        } catch (Exception e) {
        }
    }

    private void relasePlayer() {
        if (myMediaPlayer != null) {
            myMediaPlayer.reset();
            myMediaPlayer.release();
            myMediaPlayer = null;
        }
    }

    private Dialog buildDialog1(Context t, String fileurl1, String musicName, final Music m) {
        AlertDialog.Builder builder = new AlertDialog.Builder(t);
        builder.setTitle("确定重新下载" + musicName + "吗？");
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() { // from class: com.baoyi.adapter.NewRingAdapter1.11
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                NewRingAdapter1.this.downmp3(true, m);
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() { // from class: com.baoyi.adapter.NewRingAdapter1.12
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        return builder.create();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void downmp3(boolean isshowmsg, Music m) {
        if (Utils.IsCanUseSdCard()) {
            String str = Environment.getExternalStorageDirectory() + "/AndriodRing/" + m.getName() + ".mp3";
            Intent intent = new Intent(this.context, (Class<?>) DownloadService.class);
            intent.setAction(DownloadService.ACTION_ADD_TO_DOWNLOAD);
            intent.putExtra(UpdateService.NAME, m.getName());
            intent.putExtra("url", String.valueOf(content.mp3server) + m.getUrl());
            intent.putExtra("isfront", false);
            this.context.startService(intent);
            return;
        }
        if (isshowmsg) {
            Toast.makeText(this.context, "sd卡不可用,请检查你的sd卡", 1).show();
        }
    }

    public void stopMusic() {
        doPauseResume();
        relasePlayer();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void downMusic(Music m) {
        if (Environment.getExternalStorageState().equals("mounted")) {
            new DownTask().execute(m.getId());
            String url = m.getUrl();
            String ext = url.substring(url.lastIndexOf("."));
            String f = Environment.getExternalStorageDirectory() + "/Tangshi/" + m.getName() + ext;
            File file = new File(f);
            if (!file.exists()) {
                downmp3(true, m);
            }
        }
    }

    private void disablebuttons() {
        this.holder.seekBar.setVisibility(8);
        this.holder.stop.setVisibility(4);
        this.holder.play.setVisibility(0);
        this.holder.time.setVisibility(4);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void enablebuttons() {
        this.holder.seekBar.setVisibility(0);
        this.holder.stop.setVisibility(0);
        this.holder.play.setVisibility(4);
        this.holder.time.setVisibility(0);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class DownTask1 extends AsyncTask<Integer, Integer, RpcSerializable> {
        DownTask1() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public RpcSerializable doInBackground(Integer... params) {
            try {
                int id = params[0].intValue();
                if (id > 0) {
                    RpcUtils2.getMusicDao().downMusic(params[0].intValue());
                    Log.i("ada", "下载成功");
                    return null;
                }
                return null;
            } catch (Exception e) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(RpcSerializable result) {
            NewRingAdapter1.this.setOneRing(new File(String.valueOf(content.SAVEDIR) + NewRingAdapter1.this.m.getName()));
            System.out.println(String.valueOf(content.SAVEDIR) + NewRingAdapter1.this.m.getName());
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class SetAudioTask121 extends AsyncTask<String, String, Void> {
        CheckWork checked;
        Context curcontext;
        File fileitem;
        private int isdown;
        private WorkDialog progressDialog = null;

        public SetAudioTask121(Context context, CheckWork check) {
            this.curcontext = context;
            this.checked = check;
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            this.progressDialog = new WorkDialog(this.curcontext, this);
            this.progressDialog.show();
            this.progressDialog.setTitle("设置铃声");
            super.onPreExecute();
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            super.onCancelled();
        }

        @Override // android.os.AsyncTask
        public Void doInBackground(String... params) {
            try {
                this.isdown = -100;
                String mp3Url = params[0];
                String ext = mp3Url.substring(mp3Url.lastIndexOf("."));
                String path = String.valueOf(content.SAVEDIR) + params[1] + ext;
                publishProgress("正在为你准备铃声");
                String tempname = String.valueOf(content.SAVEDIR) + Utils.getMD5Str(path) + ".temp";
                Log.i("ada", path);
                Log.i("ada", tempname);
                File tempdown = new File(tempname);
                this.fileitem = new File(path);
                if (!this.fileitem.exists() || this.fileitem.length() < 100) {
                    URL url = new URL(mp3Url);
                    URLConnection conn = url.openConnection();
                    conn.setDoInput(true);
                    int length = conn.getContentLength();
                    InputStream is = conn.getInputStream();
                    if (length != -1) {
                        FileOutputStream output = new FileOutputStream(tempdown);
                        byte[] buffer = new byte[6144];
                        int downsize = 0;
                        while (true) {
                            int count = is.read(buffer);
                            if (count == -1) {
                                break;
                            }
                            output.write(buffer, 0, count);
                            downsize += count;
                            publishProgress("已经下载了" + ((int) ((downsize / length) * 100.0f)) + "%");
                        }
                        output.flush();
                        tempdown.renameTo(this.fileitem);
                        this.isdown = 100;
                    } else {
                        this.isdown = -100;
                    }
                    publishProgress("准备铃声完毕");
                    return null;
                }
                this.isdown = 100;
                return null;
            } catch (Exception e) {
                this.isdown = -100;
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... aa) {
            this.progressDialog.setTitle(aa[0]);
        }

        public InputStream getInputStreamFromUrl(String urlStr) throws IOException {
            URL url = new URL(urlStr);
            HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
            InputStream inputStream = urlConn.getInputStream();
            return inputStream;
        }

        @Override // android.os.AsyncTask
        public void onPostExecute(Void url) {
            super.onPostExecute((SetAudioTask121) url);
            if (this.fileitem != null) {
                NewRingAdapter1.this.scanFileAsync(NewRingAdapter1.this.context, this.fileitem.getAbsolutePath());
            }
            if (this.isdown > 0) {
                this.progressDialog.setTitle("正在为你设置铃声");
                NewRingAdapter1.this.setOneRing(this.fileitem);
            } else {
                Toast.makeText(this.curcontext, "下载铃声失败", 0).show();
            }
            this.progressDialog.dismiss();
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class downTask extends AsyncTask<String, String, Void> {
        CheckWork checked;
        Context curcontext;
        File fileitem;
        private int isdown;
        private WorkDialog progressDialog = null;

        public downTask(Context context, CheckWork check) {
            this.curcontext = context;
            this.checked = check;
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            this.progressDialog = new WorkDialog(this.curcontext, this);
            this.progressDialog.setTitle("下载铃声");
            this.progressDialog.show();
            super.onPreExecute();
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            super.onCancelled();
        }

        @Override // android.os.AsyncTask
        public Void doInBackground(String... params) {
            try {
                this.isdown = -100;
                String mp3Url = params[0];
                String ext = mp3Url.substring(mp3Url.lastIndexOf("."));
                String path = String.valueOf(content.SAVEDIR) + params[1] + ext;
                publishProgress("正在为你下载铃声");
                String tempname = String.valueOf(content.SAVEDIR) + Utils.getMD5Str(path) + ".temp";
                Log.i("ada", path);
                Log.i("ada", tempname);
                File tempdown = new File(tempname);
                this.fileitem = new File(path);
                if (!this.fileitem.exists() || this.fileitem.length() < 100) {
                    URL url = new URL(mp3Url);
                    URLConnection conn = url.openConnection();
                    conn.setDoInput(true);
                    int length = conn.getContentLength();
                    InputStream is = conn.getInputStream();
                    if (length != -1) {
                        FileOutputStream output = new FileOutputStream(tempdown);
                        byte[] buffer = new byte[6144];
                        int downsize = 0;
                        while (true) {
                            int count = is.read(buffer);
                            if (count == -1) {
                                break;
                            }
                            output.write(buffer, 0, count);
                            downsize += count;
                            publishProgress("已经下载了" + ((int) ((downsize / length) * 100.0f)) + "%");
                        }
                        output.flush();
                        tempdown.renameTo(this.fileitem);
                        this.isdown = 100;
                    } else {
                        publishProgress("铃声已存在");
                        this.isdown = -100;
                    }
                    publishProgress("下载铃声完毕");
                    return null;
                }
                this.isdown = 100;
                return null;
            } catch (Exception e) {
                this.isdown = -100;
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... aa) {
            this.progressDialog.setTitle(aa[0]);
        }

        public InputStream getInputStreamFromUrl(String urlStr) throws IOException {
            URL url = new URL(urlStr);
            HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
            InputStream inputStream = urlConn.getInputStream();
            return inputStream;
        }

        @Override // android.os.AsyncTask
        public void onPostExecute(Void url) {
            super.onPostExecute((downTask) url);
            if (this.fileitem != null) {
                NewRingAdapter1.this.scanFileAsync(NewRingAdapter1.this.context, this.fileitem.getAbsolutePath());
            }
            if (this.isdown <= 0) {
                Toast.makeText(this.curcontext, "下载铃声失败", 0).show();
            }
            this.progressDialog.dismiss();
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class shareTask extends AsyncTask<String, String, Void> {
        CheckWork checked;
        Context curcontext;
        File fileitem;
        private int isdown;
        private WorkDialog progressDialog = null;

        public shareTask(Context context, CheckWork check) {
            this.curcontext = context;
            this.checked = check;
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            this.progressDialog = new WorkDialog(this.curcontext, this);
            this.progressDialog.setTitle("下载铃声");
            this.progressDialog.show();
            super.onPreExecute();
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            super.onCancelled();
        }

        @Override // android.os.AsyncTask
        public Void doInBackground(String... params) {
            try {
                this.isdown = -100;
                String mp3Url = params[0];
                String ext = mp3Url.substring(mp3Url.lastIndexOf("."));
                String path = String.valueOf(content.SAVEDIR) + params[1] + ext;
                publishProgress("正在为你下载铃声");
                String tempname = String.valueOf(content.SAVEDIR) + Utils.getMD5Str(path) + ".temp";
                Log.i("ada", path);
                Log.i("ada", tempname);
                File tempdown = new File(tempname);
                this.fileitem = new File(path);
                if (!this.fileitem.exists() || this.fileitem.length() < 100) {
                    URL url = new URL(mp3Url);
                    URLConnection conn = url.openConnection();
                    conn.setDoInput(true);
                    int length = conn.getContentLength();
                    InputStream is = conn.getInputStream();
                    if (length != -1) {
                        FileOutputStream output = new FileOutputStream(tempdown);
                        byte[] buffer = new byte[6144];
                        int downsize = 0;
                        while (true) {
                            int count = is.read(buffer);
                            if (count == -1) {
                                break;
                            }
                            output.write(buffer, 0, count);
                            downsize += count;
                            publishProgress("已经下载了" + ((int) ((downsize / length) * 100.0f)) + "%");
                        }
                        output.flush();
                        tempdown.renameTo(this.fileitem);
                        this.isdown = 100;
                    } else {
                        publishProgress("铃声已存在");
                        this.isdown = -100;
                    }
                    publishProgress("下载铃声完毕");
                    return null;
                }
                this.isdown = 100;
                return null;
            } catch (Exception e) {
                this.isdown = -100;
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... aa) {
            this.progressDialog.setTitle(aa[0]);
        }

        public InputStream getInputStreamFromUrl(String urlStr) throws IOException {
            URL url = new URL(urlStr);
            HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
            InputStream inputStream = urlConn.getInputStream();
            return inputStream;
        }

        @Override // android.os.AsyncTask
        public void onPostExecute(Void url) {
            super.onPostExecute((shareTask) url);
            if (this.fileitem != null) {
                NewRingAdapter1.this.scanFileAsync(NewRingAdapter1.this.context, this.fileitem.getAbsolutePath());
            }
            if (this.isdown > 0) {
                Intent sendIntent = new Intent();
                sendIntent.setAction("android.intent.action.SEND");
                sendIntent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + content.SAVEDIR + NewRingAdapter1.this.mmm.getName() + ".mp3"));
                sendIntent.setType("audio/mp3");
                sendIntent.putExtra("android.intent.extra.SUBJECT", "微信铃声：铃声分享:" + NewRingAdapter1.this.mmm.getName());
                sendIntent.putExtra("android.intent.extra.TEXT", "我正在使用微信铃声，" + NewRingAdapter1.this.mmm.getName() + "不错,我把铃声分享给你,更多铃声请访问微信铃声网站:http://iring.wutianxia.com:8999/iringdata/");
                sendIntent.putExtra("android.intent.extra.SUBJECT", "微信铃声：铃声分享:" + NewRingAdapter1.this.mmm.getName());
                NewRingAdapter1.this.context.startActivity(Intent.createChooser(sendIntent, "分享铃声给好友!"));
            } else {
                Toast.makeText(this.curcontext, "下载铃声失败", 0).show();
            }
            this.progressDialog.dismiss();
        }
    }

    public void scanFileAsync(Context ctx, String filePath) {
        System.out.println("开始进行文件扫描工作");
        Intent scanIntent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        scanIntent.setData(Uri.fromFile(new File(filePath)));
        ctx.sendBroadcast(scanIntent);
    }
}
