package com.feiwothree.coverscreen;

import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
final class p extends Thread {
    private /* synthetic */ SR a;
    private final /* synthetic */ Intent b;
    private final /* synthetic */ Context c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(SR sr, Intent intent, Context context) {
        this.a = sr;
        this.b = intent;
        this.c = context;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        String substring = this.b.getDataString().substring(8);
        try {
            SR.a(this.a, this.c, substring);
            if (CoverAdComponent.getInstance() != null) {
                CoverAdComponent.getInstance().a(substring);
            }
        } catch (Exception e) {
            new StringBuilder("上传包安装信息失败：").append(e);
        }
    }
}
