package com.baoyi.ring.fragment;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Toast;
import com.baoyi.adapter.NewRingAdapter;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.WidgetLoadling;
import com.baoyi.utils.Utils;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class KindFragment extends Fragment implements View.OnClickListener {
    NewRingAdapter adapter;
    private Button b1;
    private Button b2;
    private Button b3;
    private ImageButton dj;
    private ImageButton dm;
    private ImageButton dx;
    Button goback;
    private ImageButton gx;
    private ImageButton jr;
    private int kind;
    private ImageButton left;
    private ListView listView;
    LinearLayout ll;
    private ImageButton lx;
    PullToRefreshListView mPullRefreshListView;
    private int page;
    private BackReceiver receiver;
    private ImageButton right;
    ScrollView scr;
    private ImageButton wy;
    private ImageButton yx;
    ArrayList<String> strs = null;
    int a = 0;
    int b = 1;
    int c = 2;
    private boolean work = false;
    private ArrayList<Music> all = new ArrayList<>();

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ring_kind, container, false);
        return view;
    }

    @Override // android.support.v4.app.Fragment
    public void onPause() {
        if (this.adapter != null) {
            this.adapter.stopMusic();
        }
        super.onStop();
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        if (this.adapter != null) {
            this.adapter.notifyDataSetChanged();
        }
        super.onResume();
    }

    @Override // android.support.v4.app.Fragment
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (this.adapter != null) {
                this.adapter.notifyDataSetChanged();
            }
        } else if (!isVisibleToUser) {
            Log.i("ada", "铃声本地不可见");
            if (this.adapter != null) {
                this.adapter.stopMusic();
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        content.ISKIND = 1;
        IntentFilter filter = new IntentFilter("com.weixinring.kindback");
        this.receiver = new BackReceiver();
        getActivity().registerReceiver(this.receiver, filter);
        this.lx = (ImageButton) getView().findViewById(R.id.ring_kind_lx_Btn);
        this.dj = (ImageButton) getView().findViewById(R.id.ring_kind_dj_Btn);
        this.dm = (ImageButton) getView().findViewById(R.id.ring_kind_dm_Btn);
        this.gx = (ImageButton) getView().findViewById(R.id.ring_kind_gx_Btn);
        this.jr = (ImageButton) getView().findViewById(R.id.ring_kind_jr_Btn);
        this.dx = (ImageButton) getView().findViewById(R.id.ring_kind_dx_Btn);
        this.wy = (ImageButton) getView().findViewById(R.id.ring_kind_wy_Btn);
        this.yx = (ImageButton) getView().findViewById(R.id.ring_kind_yx_Btn);
        this.goback = (Button) getView().findViewById(R.id.ring_kind_goback);
        this.scr = (ScrollView) getView().findViewById(R.id.ring_kind_scr);
        this.ll = (LinearLayout) getView().findViewById(R.id.ring_kind_musicLL);
        this.mPullRefreshListView = (PullToRefreshListView) getView().findViewById(R.id.ring_kind_prl);
        WidgetLoadling tv = new WidgetLoadling(getActivity());
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new NewRingAdapter(getActivity(), this.all);
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setBackgroundColor(Color.parseColor("#00000000"));
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        this.lx.setOnClickListener(this);
        this.dj.setOnClickListener(this);
        this.dm.setOnClickListener(this);
        this.gx.setOnClickListener(this);
        this.jr.setOnClickListener(this);
        this.dx.setOnClickListener(this);
        this.wy.setOnClickListener(this);
        this.yx.setOnClickListener(this);
        this.goback.setOnClickListener(this);
        this.left = (ImageButton) getView().findViewById(R.id.ring_kind_left);
        this.right = (ImageButton) getView().findViewById(R.id.ring_kind_right);
        this.b1 = (Button) getView().findViewById(R.id.ring_kind_1);
        this.b2 = (Button) getView().findViewById(R.id.ring_kind_2);
        this.b3 = (Button) getView().findViewById(R.id.ring_kind_3);
        this.strs = (ArrayList) getSString(1000);
        this.right.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.KindFragment.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (KindFragment.this.c < KindFragment.this.strs.size() - 3) {
                    KindFragment.this.a += 3;
                    KindFragment.this.b += 3;
                    KindFragment.this.c += 3;
                    KindFragment.this.b1.setText(KindFragment.this.strs.get(KindFragment.this.a).toString());
                    KindFragment.this.b2.setText(KindFragment.this.strs.get(KindFragment.this.b).toString());
                    KindFragment.this.b3.setText(KindFragment.this.strs.get(KindFragment.this.c).toString());
                    return;
                }
                Utils.showMessage(KindFragment.this.getActivity(), "抱歉，亲，木有下一页了");
            }
        });
        this.left.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.KindFragment.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (KindFragment.this.a - 3 >= 0) {
                    KindFragment kindFragment = KindFragment.this;
                    kindFragment.a -= 3;
                    KindFragment kindFragment2 = KindFragment.this;
                    kindFragment2.b -= 3;
                    KindFragment kindFragment3 = KindFragment.this;
                    kindFragment3.c -= 3;
                    KindFragment.this.b1.setText(KindFragment.this.strs.get(KindFragment.this.a).toString());
                    KindFragment.this.b2.setText(KindFragment.this.strs.get(KindFragment.this.b).toString());
                    KindFragment.this.b3.setText(KindFragment.this.strs.get(KindFragment.this.c).toString());
                    return;
                }
                Utils.showMessage(KindFragment.this.getActivity(), "抱歉，亲，木有下一页了");
            }
        });
        this.b1.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.KindFragment.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                KindFragment.this.adapter.stopMusic();
                KindFragment.this.adapter.clean();
                KindFragment.this.page = KindFragment.this.a;
                new HotTask(KindFragment.this, null).execute(new Integer[0]);
            }
        });
        this.b2.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.KindFragment.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                KindFragment.this.adapter.stopMusic();
                KindFragment.this.adapter.clean();
                KindFragment.this.page = KindFragment.this.b;
                new HotTask(KindFragment.this, null).execute(new Integer[0]);
            }
        });
        this.b3.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.KindFragment.5
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                KindFragment.this.adapter.stopMusic();
                KindFragment.this.adapter.clean();
                KindFragment.this.page = KindFragment.this.c;
                new HotTask(KindFragment.this, null).execute(new Integer[0]);
            }
        });
    }

    @Override // android.support.v4.app.Fragment
    public void onDestroy() {
        getActivity().unregisterReceiver(this.receiver);
        super.onDestroy();
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class BackReceiver extends BroadcastReceiver {
        BackReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context arg0, Intent arg1) {
            KindFragment.this.scr.setVisibility(0);
            KindFragment.this.ll.setVisibility(8);
            content.ISKIND = 0;
        }
    }

    public List<String> getSString(int count) {
        List<String> strs = new ArrayList<>();
        int a = 1;
        int b = 20;
        for (int j = 1; j < count && b < count - 20; j++) {
            if (j > 1) {
                a += 20;
                b += 20;
            }
            strs.add("<" + a + "~" + b + ">");
        }
        return strs;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        HotTask hotTask = null;
        content.ISKIND = 1;
        this.adapter.clean();
        this.a = 0;
        this.b = 1;
        this.c = 2;
        if (this.adapter != null) {
            this.adapter.stopMusic();
        }
        switch (v.getId()) {
            case R.id.ring_kind_lx_Btn /* 2131296364 */:
                this.page = 0;
                this.kind = 1;
                this.scr.setVisibility(8);
                this.ll.setVisibility(0);
                new HotTask(this, hotTask).execute(new Integer[0]);
                return;
            case R.id.ring_kind_yx_Btn /* 2131296365 */:
                this.page = 0;
                this.kind = 6;
                this.scr.setVisibility(8);
                this.ll.setVisibility(0);
                new HotTask(this, hotTask).execute(new Integer[0]);
                return;
            case R.id.ring_kind_dx_Btn /* 2131296366 */:
                this.page = 0;
                this.kind = 4;
                this.scr.setVisibility(8);
                this.ll.setVisibility(0);
                new HotTask(this, hotTask).execute(new Integer[0]);
                return;
            case R.id.ring_kind_gx_Btn /* 2131296367 */:
                this.page = 0;
                this.kind = 2;
                this.scr.setVisibility(8);
                this.ll.setVisibility(0);
                new HotTask(this, hotTask).execute(new Integer[0]);
                return;
            case R.id.ring_kind_jr_Btn /* 2131296368 */:
                this.page = 0;
                this.kind = 11;
                this.scr.setVisibility(8);
                this.ll.setVisibility(0);
                new HotTask(this, hotTask).execute(new Integer[0]);
                return;
            case R.id.ring_kind_dj_Btn /* 2131296369 */:
                this.page = 0;
                this.kind = 5;
                this.scr.setVisibility(8);
                this.ll.setVisibility(0);
                new HotTask(this, hotTask).execute(new Integer[0]);
                return;
            case R.id.ring_kind_dm_Btn /* 2131296370 */:
                this.page = 0;
                this.kind = 4;
                this.scr.setVisibility(8);
                this.ll.setVisibility(0);
                new HotTask(this, hotTask).execute(new Integer[0]);
                return;
            case R.id.ring_kind_wy_Btn /* 2131296371 */:
                this.page = 0;
                this.kind = 8;
                this.scr.setVisibility(8);
                this.ll.setVisibility(0);
                new HotTask(this, hotTask).execute(new Integer[0]);
                return;
            case R.id.ring_kind_musicLL /* 2131296372 */:
            default:
                return;
            case R.id.ring_kind_goback /* 2131296373 */:
                this.scr.setVisibility(0);
                this.ll.setVisibility(8);
                return;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Music>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(KindFragment kindFragment, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Music> doInBackground(Integer... params) {
            long time = System.currentTimeMillis();
            KindFragment.this.work = true;
            List<Music> temp = null;
            String str = "RpcUtils2.getMusicDao().pageByNew" + KindFragment.this.page;
            if (0 == 0 || temp.size() == 0) {
                try {
                    temp = RpcUtils2.getMusicDao().pageByType(KindFragment.this.kind, 20, KindFragment.this.page).getDatas();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (System.currentTimeMillis() - time < 1000) {
                try {
                    Thread.sleep(1500L);
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
            }
            return temp;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Music> result) {
            KindFragment.this.adapter.clean();
            KindFragment.this.adapter.notifyDataSetChanged();
            KindFragment.this.work = false;
            KindFragment.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
            if (result == null) {
                if (KindFragment.this.page == 0) {
                    KindFragment.this.mPullRefreshListView.setEmptyView(null);
                    Activity activity = KindFragment.this.getActivity();
                    if (activity != null) {
                        Toast.makeText(activity, "获取数据失败，请稍候再试。", 0).show();
                    }
                }
                KindFragment.this.mPullRefreshListView.onRefreshComplete();
                return;
            }
            for (Music music : result) {
                KindFragment.this.adapter.addLast(music);
            }
            KindFragment.this.adapter.notifyDataSetChanged();
            KindFragment.this.mPullRefreshListView.onRefreshComplete();
            KindFragment.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + KindFragment.this.adapter.getCount() + "首铃声");
            KindFragment.this.page++;
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            WidgetLoadling tv = new WidgetLoadling(KindFragment.this.getActivity());
            KindFragment.this.mPullRefreshListView.setEmptyView(tv);
        }
    }
}
