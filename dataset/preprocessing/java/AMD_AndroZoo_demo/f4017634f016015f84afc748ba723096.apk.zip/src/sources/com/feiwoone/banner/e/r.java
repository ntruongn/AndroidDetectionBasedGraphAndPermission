package com.feiwoone.banner.e;

import android.app.Notification;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import java.util.List;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class r implements d {
    private /* synthetic */ p a;
    private final /* synthetic */ String b;
    private final /* synthetic */ int c;
    private final /* synthetic */ String d;
    private final /* synthetic */ Notification e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public r(p pVar, String str, int i, String str2, Notification notification) {
        this.a = pVar;
        this.b = str;
        this.c = i;
        this.d = str2;
        this.e = notification;
    }

    @Override // com.feiwoone.banner.e.d
    public final void a(Drawable drawable) {
        List list;
        Context context;
        list = this.a.d;
        list.remove(this.b);
        if (BitmapFactory.decodeFile(this.b) != null) {
            this.a.a(this.c, this.d, this.e);
            return;
        }
        context = this.a.e;
        f.a(context);
        f.e(this.b);
    }
}
