package com.baoyi.service;

import android.util.Log;
import com.baidu.kirin.KirinConfig;
import com.baoyi.audio.BaoyiApplication;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.doamin.PlayList;
import com.baoyi.doamin.SoList;
import com.baoyi.doamin.Song;
import com.baoyi.utils.Utils;
import com.google.gson.Gson;
import java.io.IOException;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Mp3Service {
    public static PlayList list(String type) {
        String key = Utils.getMD5Str(String.valueOf("http://player.kuwo.cn/webmusic/gu/getwebbang") + type);
        String datas = BaoyiApplication.getInstance().getDiskTextCache().get((Object) key);
        if (datas != null) {
            Log.i("ali", "来之缓存");
        } else {
            try {
                datas = Jsoup.connect("http://player.kuwo.cn/webmusic/gu/getwebbang").timeout(KirinConfig.READ_TIME_OUT).header("User-Agent", "Mozilla/5.0 (Windows NT 5.1; rv:5.0.1) Gecko/20100101 Firefox/5.0.1").header("Referer", "http://player.kuwo.cn/").data("syId", type).method(Connection.Method.POST).execute().body();
                BaoyiApplication.getInstance().getDiskTextCache().put(key, datas);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Gson gson = new Gson();
        PlayList temp = (PlayList) gson.fromJson(datas, PlayList.class);
        return temp;
    }

    public static SoList search(String name) {
        String key = Utils.getMD5Str(String.valueOf("http://player.kuwo.cn/webmusic/webmusic2011/search.jsp") + name);
        String datas = BaoyiApplication.getInstance().getDiskTextCache().get((Object) key);
        if (datas != null) {
            Log.i("ali", "来之缓存");
        } else {
            try {
                datas = Jsoup.connect("http://player.kuwo.cn/webmusic/webmusic2011/search.jsp").timeout(KirinConfig.READ_TIME_OUT).header("User-Agent", "Mozilla/5.0 (Windows NT 5.1; rv:5.0.1) Gecko/20100101 Firefox/5.0.1").header("Referer", "http://player.kuwo.cn/").data("key", name).method(Connection.Method.POST).execute().body();
                BaoyiApplication.getInstance().getDiskTextCache().put(key, datas);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (datas == null) {
            return null;
        }
        String datas2 = datas.replace("result=", "");
        Gson gson = new Gson();
        SoList temp = (SoList) gson.fromJson(datas2, SoList.class);
        return temp;
    }

    public static Song findbyId(String name) {
        Song song = new Song();
        String ada = null;
        try {
            ada = Jsoup.connect("http://player.kuwo.cn/webmusic/st/getMuiseByRid").timeout(4000).header("User-Agent", "Mozilla/5.0 (Windows NT 5.1; rv:5.0.1) Gecko/20100101 Firefox/5.0.1").header("Referer", "http://player.kuwo.cn/").data("rid", name).method(Connection.Method.POST).execute().body();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (ada == null || ada.length() < 10) {
            return null;
        }
        Document datas = Jsoup.parse(ada);
        Elements es = datas.getElementsByTag("mp3path");
        if (es != null && es.size() > 0) {
            String temp = "http://" + datas.getElementsByTag("mp3dl").get(0).text() + es.get(0).text();
            song.setMp3path(temp);
        }
        Elements es2 = datas.getElementsByTag("aacpath");
        if (es2 != null && es2.size() > 0) {
            String temp2 = "http://" + datas.getElementsByTag("aacdl").get(0).text() + es2.get(0).text();
            song.setAacpath(temp2);
        }
        Elements es3 = datas.getElementsByTag("path");
        if (es3 != null && es3.size() > 0) {
            String temp3 = "http://" + datas.getElementsByTag("wmadl").get(0).text() + es3.get(0).text();
            song.setPath(temp3);
        }
        song.setMusic_id(datas.getElementsByTag("music_id").get(0).text());
        song.setMv_rid(datas.getElementsByTag("mv_rid").get(0).text());
        song.setName(datas.getElementsByTag(UpdateService.NAME).get(0).text());
        song.setSong_url(datas.getElementsByTag("song_url").get(0).text());
        song.setArtist(datas.getElementsByTag(UpdateService.ARTIST).get(0).text());
        song.setArtist_url(datas.getElementsByTag("artist_url").get(0).text());
        song.setAuther_url(datas.getElementsByTag("auther_url").get(0).text());
        song.setArtist_pic(datas.getElementsByTag("artist_pic").get(0).text());
        return song;
    }
}
