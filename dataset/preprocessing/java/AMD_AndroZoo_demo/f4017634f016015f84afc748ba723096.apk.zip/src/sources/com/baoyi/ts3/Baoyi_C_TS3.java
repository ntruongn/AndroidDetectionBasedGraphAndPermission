package com.baoyi.ts3;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Baoyi_C_TS3 {
    static Baoyi_C_TS3 instance;
    private b g;

    private Baoyi_C_TS3(Context ctx, String vid, String chlId) {
        this.g = b.a(ctx, vid, chlId);
    }

    public static synchronized Baoyi_C_TS3 getInitTs3(Context ctx, String vid, String chlId) {
        Baoyi_C_TS3 baoyi_C_TS3;
        synchronized (Baoyi_C_TS3.class) {
            if (instance == null) {
                instance = new Baoyi_C_TS3(ctx, vid, chlId);
            }
            baoyi_C_TS3 = instance;
        }
        return baoyi_C_TS3;
    }

    public void showts3() {
        this.g.a();
    }
}
