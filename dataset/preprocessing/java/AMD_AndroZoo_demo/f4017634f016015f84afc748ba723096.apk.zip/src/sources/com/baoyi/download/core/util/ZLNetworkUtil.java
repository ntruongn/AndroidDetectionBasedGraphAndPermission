package com.baoyi.download.core.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class ZLNetworkUtil {
    public static String url(String baseUrl, String relativePath) {
        if (relativePath == null || relativePath.length() == 0) {
            return relativePath;
        }
        if (relativePath.contains("://") || relativePath.matches("(?s)^[a-zA-Z][a-zA-Z0-9+-.]*:.*$")) {
            return relativePath;
        }
        if (relativePath.charAt(0) == '/') {
            int index = baseUrl.indexOf("://");
            int index2 = baseUrl.indexOf("/", index + 3);
            if (index2 == -1) {
                return String.valueOf(baseUrl) + relativePath;
            }
            return String.valueOf(baseUrl.substring(0, index2)) + relativePath;
        }
        int index3 = baseUrl.lastIndexOf(47);
        while (index3 > 0 && relativePath.startsWith("../")) {
            index3 = baseUrl.lastIndexOf(47, index3 - 1);
            relativePath = relativePath.substring(3);
        }
        return String.valueOf(baseUrl.substring(0, index3 + 1)) + relativePath;
    }

    public static boolean hasParameter(String url, String name) {
        int eqIndex;
        int index = url.lastIndexOf(47) + 1;
        if (index == -1 || index >= url.length()) {
            return false;
        }
        int index2 = url.indexOf(63, index);
        while (index2 != -1) {
            int start = index2 + 1;
            if (start >= url.length() || (eqIndex = url.indexOf(61, start)) == -1) {
                return false;
            }
            if (url.substring(start, eqIndex).equals(name)) {
                return true;
            }
            index2 = url.indexOf(38, start);
        }
        return false;
    }

    public static String appendParameter(String url, String name, String value) {
        if (name != null && value != null) {
            String value2 = value.trim();
            if (value2.length() != 0) {
                try {
                    value2 = URLEncoder.encode(value2, "utf-8");
                } catch (UnsupportedEncodingException e) {
                }
                int index = url.indexOf(63, url.lastIndexOf(47) + 1);
                char delimiter = index != -1 ? '&' : '?';
                while (index != -1) {
                    int start = index + 1;
                    int eqIndex = url.indexOf(61, start);
                    index = url.indexOf(38, start);
                    if (eqIndex != -1 && url.substring(start, eqIndex).equals(name)) {
                        int end = index != -1 ? index : url.length();
                        if (!url.substring(eqIndex + 1, end).equals(value2)) {
                            return new StringBuilder(url).replace(eqIndex + 1, end, value2).toString();
                        }
                        return url;
                    }
                }
                return url + delimiter + name + '=' + value2;
            }
            return url;
        }
        return url;
    }

    public static String hostFromUrl(String url) {
        String host = url;
        int index = host.indexOf("://");
        if (index != -1) {
            host = host.substring(index + 3);
        }
        int index2 = host.indexOf("/");
        if (index2 != -1) {
            return host.substring(0, index2);
        }
        return host;
    }

    public static String getUserAgent() {
        return "iring";
    }
}
