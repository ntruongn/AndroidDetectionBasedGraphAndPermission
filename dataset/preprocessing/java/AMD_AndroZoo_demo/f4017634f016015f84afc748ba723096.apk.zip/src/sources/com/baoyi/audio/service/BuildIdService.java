package com.baoyi.audio.service;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.util.Log;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.utils.Utils;
import com.iring.dao.MemberDao;
import com.iring.entity.Member;
import com.iring.rpc.MemberRpcSerializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class BuildIdService extends Service {
    private Runnable work = new Runnable() { // from class: com.baoyi.audio.service.BuildIdService.1
        @Override // java.lang.Runnable
        public void run() {
            String id = Utils.deviceid(BuildIdService.this);
            MemberDao dao = (MemberDao) RpcUtils2.getApi("memberDao", MemberDao.class);
            MemberRpcSerializable m = dao.login(id, 100);
            if (m != null && m.getCode() == 0) {
                int uid = m.getMemberid();
                SharedPreferences sharedPreferences = BuildIdService.this.getSharedPreferences("apps", 0);
                SharedPreferences.Editor edit = sharedPreferences.edit();
                edit.putInt(UpdateService.USERID, uid);
                edit.commit();
            }
        }
    };
    private Runnable work1 = new Runnable() { // from class: com.baoyi.audio.service.BuildIdService.2
        @Override // java.lang.Runnable
        public void run() {
            SharedPreferences sharedPreferences = BuildIdService.this.getSharedPreferences("apps", 0);
            int id = sharedPreferences.getInt(UpdateService.USERID, -1);
            MemberDao dao = (MemberDao) RpcUtils2.getApi("memberDao", MemberDao.class);
            Member member = dao.findById(id);
            if (member != null) {
                if (member.getPicture() != null) {
                    sharedPreferences.edit().putString("bigpic", member.getPicture()).commit();
                }
                if (member.getMinpicture() != null) {
                    sharedPreferences.edit().putString("minipic", member.getMinpicture()).commit();
                }
                if (member.getNickname() != null) {
                    sharedPreferences.edit().putString("minipic", member.getMinpicture()).commit();
                }
            }
        }
    };

    @Override // android.app.Service
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
    }

    @Override // android.app.Service
    public void onStart(Intent intent, int startId) {
        Log.i("ada", "BuildIdService onStart");
        super.onStart(intent, startId);
        SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
        int id = sharedPreferences.getInt(UpdateService.USERID, -1);
        if (id > 0) {
            new Thread(this.work1).start();
        } else {
            new Thread(this.work).start();
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        Log.i("ada", "BuildIdService onDestroy");
        super.onDestroy();
    }
}
