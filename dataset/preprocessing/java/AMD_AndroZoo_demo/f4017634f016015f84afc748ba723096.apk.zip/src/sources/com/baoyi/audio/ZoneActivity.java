package com.baoyi.audio;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.baoyi.audio.fragment.FavMusicFragment;
import com.baoyi.audio.fragment.FollowFragment;
import com.baoyi.audio.fragment.UserRingRecommendFragment;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.utils.Utils;
import com.hope.leyuan.R;
import com.iring.dao.FollowDao;
import com.iring.dao.MemberDao;
import com.iring.entity.Member;
import com.iring.rpc.RpcSerializable;
import com.wrapp.android.webimage.WebImageView;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class ZoneActivity extends FragmentActivity implements View.OnClickListener {
    private ImageButton editBtn;
    private CheckBox followCb;
    private TextView memberName;
    private TextView member_message;
    private WebImageView member_pic;
    private LinearLayout my_commendLl;
    private LinearLayout my_favLl;
    private LinearLayout my_followLl;
    private ViewPager.OnPageChangeListener pageChangeListener = new ViewPager.OnPageChangeListener() { // from class: com.baoyi.audio.ZoneActivity.1
        @Override // android.support.v4.view.ViewPager.OnPageChangeListener
        public void onPageSelected(int arg0) {
            switch (arg0) {
                case 0:
                    ZoneActivity.this.my_commendLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                    ZoneActivity.this.my_followLl.setBackgroundColor(ZoneActivity.this.getResources().getColor(R.color.transparent));
                    ZoneActivity.this.my_favLl.setBackgroundColor(ZoneActivity.this.getResources().getColor(R.color.transparent));
                    return;
                case 1:
                    ZoneActivity.this.my_followLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                    ZoneActivity.this.my_commendLl.setBackgroundColor(ZoneActivity.this.getResources().getColor(R.color.transparent));
                    ZoneActivity.this.my_favLl.setBackgroundColor(ZoneActivity.this.getResources().getColor(R.color.transparent));
                    return;
                case 2:
                    ZoneActivity.this.my_favLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                    ZoneActivity.this.my_followLl.setBackgroundColor(ZoneActivity.this.getResources().getColor(R.color.transparent));
                    ZoneActivity.this.my_commendLl.setBackgroundColor(ZoneActivity.this.getResources().getColor(R.color.transparent));
                    return;
                default:
                    return;
            }
        }

        @Override // android.support.v4.view.ViewPager.OnPageChangeListener
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        @Override // android.support.v4.view.ViewPager.OnPageChangeListener
        public void onPageScrollStateChanged(int arg0) {
        }
    };
    private TextView point;
    private int userid;
    private ViewPager viewpager;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.activity_zone);
        this.userid = getIntent().getIntExtra(UpdateService.USERID, -1);
        initWidget();
        new LoadMemberData(this, null).execute(new Void[0]);
    }

    private void initWidget() {
        this.member_pic = (WebImageView) findViewById(R.id.member_pic);
        this.editBtn = (ImageButton) findViewById(R.id.edit_btn);
        this.memberName = (TextView) findViewById(R.id.memberName);
        this.followCb = (CheckBox) findViewById(R.id.follow_cb);
        this.point = (TextView) findViewById(R.id.point);
        this.member_message = (TextView) findViewById(R.id.member_message);
        this.my_followLl = (LinearLayout) findViewById(R.id.my_follow_ll);
        this.my_commendLl = (LinearLayout) findViewById(R.id.my_recommend_ll);
        this.my_favLl = (LinearLayout) findViewById(R.id.my_fav_ll);
        this.viewpager = (ViewPager) findViewById(R.id.pager);
        this.editBtn.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.ZoneActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Utils.showMessage(ZoneActivity.this, "edit");
            }
        });
        this.my_followLl.setOnClickListener(this);
        this.my_commendLl.setOnClickListener(this);
        this.my_favLl.setOnClickListener(this);
        ZoneFragmentPagerAdapter pagerAdapter = new ZoneFragmentPagerAdapter(getSupportFragmentManager());
        pagerAdapter.add(new UserRingRecommendFragment(this.userid));
        pagerAdapter.add(new FollowFragment(this.userid));
        pagerAdapter.add(new FavMusicFragment(this.userid));
        this.viewpager.setAdapter(pagerAdapter);
        this.viewpager.setOnPageChangeListener(this.pageChangeListener);
        this.followCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.baoyi.audio.ZoneActivity.3
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    ZoneActivity.this.follow();
                } else {
                    ZoneActivity.this.unfollow();
                }
            }
        });
    }

    void follow() {
        new FollowTask(this, null).execute(new Integer[0]);
    }

    void unfollow() {
        new UnFollowTask(this, null).execute(new Integer[0]);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setData(Member member) {
        this.member_pic.setBackgroundResource(R.drawable.member_pic1);
        this.memberName.setText(member.getNickname());
        this.point.setText("积分:" + member.getMoney());
        this.member_message.setText(member.getMessages());
        this.member_pic.setImageUrl(String.valueOf(content.picserver) + member.getPicture());
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class ZoneFragmentPagerAdapter extends FragmentPagerAdapter {
        public List<Fragment> fragments;

        public ZoneFragmentPagerAdapter(FragmentManager fm) {
            super(fm);
            this.fragments = new ArrayList();
        }

        @Override // android.support.v4.app.FragmentPagerAdapter
        public Fragment getItem(int arg0) {
            if (this.fragments != null) {
                return this.fragments.get(arg0);
            }
            return null;
        }

        @Override // android.support.v4.view.PagerAdapter
        public int getCount() {
            if (this.fragments != null) {
                return this.fragments.size();
            }
            return 0;
        }

        public void add(Fragment fragment) {
            this.fragments.add(fragment);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class LoadMemberData extends AsyncTask<Void, Boolean, Member> {
        private LoadMemberData() {
        }

        /* synthetic */ LoadMemberData(ZoneActivity zoneActivity, LoadMemberData loadMemberData) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Member doInBackground(Void... params) {
            if (ZoneActivity.this.userid == -1) {
                publishProgress(false);
                return null;
            }
            MemberDao mDao = (MemberDao) RpcUtils2.getDao("memberDao", MemberDao.class);
            if (mDao != null) {
                Member member = mDao.findById(ZoneActivity.this.userid);
                return member;
            }
            return null;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Member result) {
            if (result != null) {
                ZoneActivity.this.setData(result);
            } else {
                Toast.makeText(ZoneActivity.this, "网络信号不好，无法获取用户信息", 0).show();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(Boolean... values) {
            if (!values[0].booleanValue()) {
                Toast.makeText(ZoneActivity.this, "您没有登陆", 0).show();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class FollowTask extends AsyncTask<Integer, Boolean, RpcSerializable> {
        private ProgressDialog progressDialog;

        private FollowTask() {
        }

        /* synthetic */ FollowTask(ZoneActivity zoneActivity, FollowTask followTask) {
            this();
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            this.progressDialog = ProgressDialog.show(ZoneActivity.this, "关注他人", "正在关注他人,请稍候！", true);
            this.progressDialog.setCancelable(true);
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public RpcSerializable doInBackground(Integer... params) {
            RpcSerializable member = new RpcSerializable();
            int uid = Utils.getUserid(ZoneActivity.this);
            try {
                FollowDao dao = (FollowDao) RpcUtils2.getDao("followDao", FollowDao.class);
                return dao.follow(ZoneActivity.this.userid, uid, 0);
            } catch (Exception e) {
                member.setCode(-100);
                return member;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(RpcSerializable result) {
            this.progressDialog.dismiss();
            if (result != null) {
                if (result.getCode() == 1) {
                    Toast.makeText(ZoneActivity.this, "关注成功", 0).show();
                }
                if (result.getCode() == 100) {
                    Toast.makeText(ZoneActivity.this, "你已关注该人", 0).show();
                }
                if (result.getCode() == -100) {
                    Toast.makeText(ZoneActivity.this, "关注该人失败", 0).show();
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class UnFollowTask extends AsyncTask<Integer, Boolean, RpcSerializable> {
        private ProgressDialog progressDialog;

        private UnFollowTask() {
        }

        /* synthetic */ UnFollowTask(ZoneActivity zoneActivity, UnFollowTask unFollowTask) {
            this();
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            this.progressDialog = ProgressDialog.show(ZoneActivity.this, "取消关注", "正在取消关注,请稍候！", true);
            this.progressDialog.setCancelable(true);
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public RpcSerializable doInBackground(Integer... params) {
            RpcSerializable member = new RpcSerializable();
            int uid = Utils.getUserid(ZoneActivity.this);
            try {
                FollowDao dao = (FollowDao) RpcUtils2.getDao("followDao", FollowDao.class);
                dao.unfollow(ZoneActivity.this.userid, uid, 0);
            } catch (Exception e) {
                member.setCode(-100);
            }
            return member;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(RpcSerializable result) {
            this.progressDialog.dismiss();
            if (result != null && result.getCode() == 0) {
                Toast.makeText(ZoneActivity.this, "取消关注成功", 0).show();
            }
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.my_recommend_ll /* 2131296299 */:
                this.viewpager.setCurrentItem(0);
                this.my_commendLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                this.my_followLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                this.my_favLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                return;
            case R.id.my_follow_ll /* 2131296300 */:
                this.viewpager.setCurrentItem(1);
                this.my_commendLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                this.my_followLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                this.my_favLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                return;
            case R.id.my_fav_ll /* 2131296301 */:
                this.my_commendLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                this.my_followLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                this.my_favLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                this.viewpager.setCurrentItem(2);
                return;
            default:
                return;
        }
    }
}
