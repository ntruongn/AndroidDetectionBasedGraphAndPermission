package com.feiwoone.banner.d;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.view.View;
import java.io.InputStream;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class c extends View implements a {
    private static /* synthetic */ int[] j;
    private b a;
    private Bitmap b;
    private boolean c;
    private boolean d;
    private int e;
    private Rect f;
    private e g;
    private f h;
    private Handler i;

    public c(Context context) {
        super(context);
        this.a = null;
        this.b = null;
        this.c = true;
        this.d = false;
        this.e = -1;
        this.f = null;
        this.g = null;
        this.h = f.SYNC_DECODER;
        this.i = new d(this);
    }

    private void a() {
        if (this.i != null) {
            this.i.sendMessage(this.i.obtainMessage());
        }
    }

    private static /* synthetic */ int[] b() {
        int[] iArr = j;
        if (iArr == null) {
            iArr = new int[f.valuesCustom().length];
            try {
                iArr[f.COVER.ordinal()] = 3;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[f.SYNC_DECODER.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[f.WAIT_FINISH.ordinal()] = 1;
            } catch (NoSuchFieldError e3) {
            }
            j = iArr;
        }
        return iArr;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ boolean c(c cVar) {
        return false;
    }

    public final void a(InputStream inputStream) {
        if (this.a != null) {
            this.a.a();
            this.a = null;
        }
        this.a = new b(inputStream, this);
        this.a.start();
    }

    @Override // com.feiwoone.banner.d.a
    public final void a(boolean z, int i) {
        if (!z || this.a == null) {
            return;
        }
        switch (b()[this.h.ordinal()]) {
            case 1:
                if (i == -1) {
                    if (this.a.b() > 1) {
                        new e(this).start();
                        return;
                    } else {
                        a();
                        return;
                    }
                }
                return;
            case 2:
                if (i == 1) {
                    this.b = this.a.c();
                    a();
                    return;
                } else if (i == -1) {
                    a();
                    return;
                } else {
                    if (this.g == null) {
                        this.g = new e(this);
                        this.g.start();
                        return;
                    }
                    return;
                }
            case 3:
                if (i == 1) {
                    this.b = this.a.c();
                    a();
                    return;
                } else {
                    if (i == -1) {
                        if (this.a.b() <= 1) {
                            a();
                            return;
                        } else {
                            if (this.g == null) {
                                this.g = new e(this);
                                this.g.start();
                                return;
                            }
                            return;
                        }
                    }
                    return;
                }
            default:
                return;
        }
    }

    @Override // android.view.View
    protected final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.a == null) {
            return;
        }
        if (this.b == null) {
            this.b = this.a.c();
        }
        if (this.b != null) {
            int saveCount = canvas.getSaveCount();
            canvas.save();
            canvas.translate(getPaddingLeft(), getPaddingTop());
            if (this.e == -1) {
                canvas.drawBitmap(this.b, 0.0f, 0.0f, (Paint) null);
            } else {
                canvas.drawBitmap(this.b, (Rect) null, (Rect) null, (Paint) null);
            }
            canvas.restoreToCount(saveCount);
        }
    }

    @Override // android.view.View
    protected final void onMeasure(int i, int i2) {
        int i3;
        int i4 = 1;
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        if (this.a == null) {
            i3 = 1;
        } else {
            i3 = this.a.a;
            i4 = this.a.b;
        }
        setMeasuredDimension(resolveSize(Math.max(i3 + paddingLeft + paddingRight, getSuggestedMinimumWidth()), i), resolveSize(Math.max(i4 + paddingTop + paddingBottom, getSuggestedMinimumHeight()), i2));
    }
}
