package com.baoyi.audio.utils;

import android.os.Environment;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class content {
    public static String picserver = "http://iring.wutianxia.com:9900/iringdata/uploads/pics/";
    public static String dataserver = "http://iring.wutianxia.com:9900/";
    public static String dataserver1 = "http://iring.wutianxia.com:9900/";
    public static String aliserver = "http://iring.wutianxia.com:9900/";
    public static String mp3server = "http://iring.wutianxia.com:9900/";
    public static String SAVEDIR = Environment.getExternalStorageDirectory() + "/suibianring/";
    public static int showsize = 20;
    public static int ISKIND = 0;
}
