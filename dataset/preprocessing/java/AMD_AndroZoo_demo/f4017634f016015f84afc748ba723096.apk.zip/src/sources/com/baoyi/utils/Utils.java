package com.baoyi.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.StatFs;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.Toast;
import com.baoyi.audio.service.UpdateService;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.UUID;
import org.apache.commons.io.FileUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Utils {
    public static int getUserid(Context c) {
        SharedPreferences sharedPreferences = c.getSharedPreferences("apps", 0);
        return sharedPreferences.getInt(UpdateService.USERID, -1);
    }

    public static boolean IsCanUseSdCard() {
        try {
            if (!Environment.getExternalStorageState().equals("mounted")) {
                return false;
            }
            if (readSDCardMB() <= 30) {
                return false;
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void showMessage(Context context, String message) {
        Toast.makeText(context, message, 0).show();
    }

    public static boolean isWifi(Context mContext) {
        ConnectivityManager connectivityManager = (ConnectivityManager) mContext.getSystemService("connectivity");
        NetworkInfo activeNetInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetInfo != null && activeNetInfo.getType() == 1;
    }

    public static boolean getHeight(Context mContext) {
        new DisplayMetrics();
        DisplayMetrics dm = mContext.getApplicationContext().getResources().getDisplayMetrics();
        int i = dm.widthPixels;
        int i2 = dm.heightPixels;
        return false;
    }

    public static long getLength(String mp3Url) {
        int length = -1;
        try {
            URL url = new URL(mp3Url);
            URLConnection conn = url.openConnection();
            conn.setReadTimeout(1500);
            conn.setDoInput(true);
            length = conn.getContentLength();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return length;
    }

    public void i(Bitmap bitmap, Context mContext) {
        new DisplayMetrics();
        DisplayMetrics dm = mContext.getApplicationContext().getResources().getDisplayMetrics();
        int screenHeight = dm.heightPixels;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        int be = (int) (options.outHeight / screenHeight);
        if (be <= 0) {
            be = 1;
        }
        options.inSampleSize = be;
        ByteArrayInputStream os = new ByteArrayInputStream(null);
        Rect outPadding = new Rect();
        Bitmap bitmap2 = BitmapFactory.decodeStream(os, outPadding, options);
        int w = bitmap2.getWidth();
        int h = bitmap2.getHeight();
        System.out.println(String.valueOf(w) + "   " + h);
    }

    public static void intiMediaDisk() {
        String sdk = new StringBuilder().append(Environment.getExternalStorageDirectory()).toString();
        String sdkdir = String.valueOf(sdk) + "/media/";
        checkFile(sdkdir);
        String audiodir = String.valueOf(sdk) + "/media/audio/";
        checkFile(audiodir);
        String ringtonesdir = String.valueOf(sdk) + "/media/audio/ringtones";
        checkFile(ringtonesdir);
        String alarmsdir = String.valueOf(sdk) + "/media/audio/alarms";
        checkFile(alarmsdir);
        String notificationsdir = String.valueOf(sdk) + "/media/audio/notifications";
        checkFile(notificationsdir);
    }

    private static void checkFile(File ringtones) {
        if (!ringtones.exists() && !ringtones.isDirectory()) {
            boolean creadok = ringtones.mkdir();
            if (creadok) {
                System.out.println(" ok:创建文件夹成功！ ");
            } else {
                System.out.println(" err:创建文件夹失败！ ");
            }
        }
    }

    private static void checkFile(String ringtonesdir) {
        File ringtones = new File(ringtonesdir);
        checkFile(ringtones);
    }

    public static String getLocalIpAddress() {
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en.hasMoreElements()) {
                NetworkInterface intf = en.nextElement();
                Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses();
                while (enumIpAddr.hasMoreElements()) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        return inetAddress.getHostAddress().toString();
                    }
                }
            }
        } catch (SocketException ex) {
            Log.e("WifiPreference IpAddress", ex.toString());
        }
        return null;
    }

    public static String getMD5Str(String str) {
        MessageDigest messageDigest = null;
        try {
            messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.reset();
            messageDigest.update(str.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e2) {
            System.out.println("NoSuchAlgorithmException caught!");
            System.exit(-1);
        }
        byte[] byteArray = messageDigest.digest();
        StringBuffer md5StrBuff = new StringBuffer();
        for (int i = 0; i < byteArray.length; i++) {
            if (Integer.toHexString(byteArray[i] & 255).length() == 1) {
                md5StrBuff.append("0").append(Integer.toHexString(byteArray[i] & 255));
            } else {
                md5StrBuff.append(Integer.toHexString(byteArray[i] & 255));
            }
        }
        return md5StrBuff.substring(8, 24).toString().toUpperCase();
    }

    public static void readSDCard() {
        String state = Environment.getExternalStorageState();
        if ("mounted".equals(state)) {
            File sdcardDir = Environment.getExternalStorageDirectory();
            StatFs sf = new StatFs(sdcardDir.getPath());
            long blockSize = sf.getBlockSize();
            long blockCount = sf.getBlockCount();
            long availCount = sf.getAvailableBlocks();
            Log.d("", "block大小:" + blockSize + ",block数目:" + blockCount + ",总大小:" + ((blockSize * blockCount) / FileUtils.ONE_KB) + "KB");
            Log.d("", "可用的block数目：:" + availCount + ",剩余空间:" + ((availCount * blockSize) / FileUtils.ONE_KB) + "KB");
        }
    }

    public static long readSDCardMB() {
        String state = Environment.getExternalStorageState();
        if (!"mounted".equals(state)) {
            return 0L;
        }
        File sdcardDir = Environment.getExternalStorageDirectory();
        StatFs sf = new StatFs(sdcardDir.getPath());
        long blockSize = sf.getBlockSize();
        long blockCount = sf.getBlockCount();
        long availCount = sf.getAvailableBlocks();
        Log.d("", "block大小:" + blockSize + ",block数目:" + blockCount + ",总大小:" + ((blockSize * blockCount) / FileUtils.ONE_KB) + "KB");
        Log.d("", "可用的block数目：:" + availCount + ",剩余空间:" + ((availCount * blockSize) / FileUtils.ONE_KB) + "KB");
        long size = (availCount * blockSize) / FileUtils.ONE_MB;
        return size;
    }

    public static void readSystem() {
        File root = Environment.getRootDirectory();
        StatFs sf = new StatFs(root.getPath());
        long blockSize = sf.getBlockSize();
        long blockCount = sf.getBlockCount();
        long availCount = sf.getAvailableBlocks();
        Log.d("", "block大小:" + blockSize + ",block数目:" + blockCount + ",总大小:" + ((blockSize * blockCount) / FileUtils.ONE_KB) + "KB");
        Log.d("", "可用的block数目：:" + availCount + ",可用大小:" + ((availCount * blockSize) / FileUtils.ONE_KB) + "KB");
    }

    public static boolean checkPermission(Context context, String paramString) {
        PackageManager localPackageManager = context.getPackageManager();
        return localPackageManager.checkPermission(paramString, context.getPackageName()) == 0;
    }

    public static String getImsi(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService("phone");
        StringBuffer ImsiStr = new StringBuffer();
        try {
            if (checkPermission(context, "android.permission.READ_PHONE_STATE")) {
                ImsiStr.append(tm.getSubscriberId() == null ? "" : tm.getSubscriberId());
            }
            while (ImsiStr.length() < 15) {
                ImsiStr.append("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
            ImsiStr.append("000000000000000");
        }
        return ImsiStr.toString();
    }

    public static String getImei(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService("phone");
        StringBuffer tmDevice = new StringBuffer();
        try {
            if (checkPermission(context, "android.permission.READ_PHONE_STATE")) {
                tmDevice.append(tm.getDeviceId());
            }
            while (tmDevice.length() < 15) {
                tmDevice.append("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tmDevice.toString().replace("null", "0000");
    }

    public static String getIDByMAC(Context context) {
        try {
            WifiManager localWifiManager = (WifiManager) context.getSystemService("wifi");
            WifiInfo localWifiInfo = localWifiManager.getConnectionInfo();
            String str = localWifiInfo.getMacAddress();
            return str;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String deviceid(Context context) {
        StringBuffer tmDevice = new StringBuffer();
        try {
            WifiManager localWifiManager = (WifiManager) context.getSystemService("wifi");
            WifiInfo localWifiInfo = localWifiManager.getConnectionInfo();
            String str = localWifiInfo.getMacAddress();
            tmDevice.append(str);
            if (str != null && str.length() > 5) {
                TelephonyManager tm = (TelephonyManager) context.getSystemService("phone");
                if (checkPermission(context, "android.permission.READ_PHONE_STATE")) {
                    tmDevice.append(tm.getSubscriberId() == null ? "" : tm.getSubscriberId());
                    if (tmDevice.length() < 5) {
                        tmDevice.append(tm.getDeviceId() == null ? "" : tm.getDeviceId());
                    }
                    if (tmDevice.length() < 5) {
                        tmDevice.append("ring" + UUID.randomUUID().toString());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tmDevice.toString();
    }
}
