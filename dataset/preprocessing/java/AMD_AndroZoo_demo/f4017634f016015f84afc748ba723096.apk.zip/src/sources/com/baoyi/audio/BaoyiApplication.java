package com.baoyi.audio;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.baoyi.audio.utils.content;
import com.baoyi.download.DownloadProvider;
import com.baoyi.download.DownloadProviderImpl;
import com.baoyi.utils.DiskTextCache;
import com.baoyi.utils.Utils;
import com.webimageloader.ext.ImageLoaderApplication;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class BaoyiApplication extends ImageLoaderApplication {
    public static String TAG = "baoyi";
    private static BaoyiApplication instance;
    private DiskTextCache diskTextCache;
    DownloadProvider downloadProvider;

    public static BaoyiApplication getInstance() {
        return instance;
    }

    public DiskTextCache getDiskTextCache() {
        return this.diskTextCache;
    }

    public DownloadProvider getProvider() {
        return this.downloadProvider;
    }

    public String getVersion() {
        String version = "0.0.0";
        PackageManager packageManager = getPackageManager();
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(getPackageName(), 0);
            version = packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return "imusic" + version;
    }

    private void inticacheDisk() {
        File disk = new File(content.SAVEDIR);
        if (!disk.exists() && !disk.isDirectory()) {
            boolean creadok = disk.mkdir();
            if (creadok) {
                System.out.println(" ok:创建文件夹成功！ ");
            } else {
                System.out.println(" err:创建文件夹失败！ ");
            }
        }
    }

    @Override // com.webimageloader.ext.ImageLoaderApplication, android.app.Application
    public void onCreate() {
        super.onCreate();
        inticacheDisk();
        instance = this;
        this.diskTextCache = new DiskTextCache();
        this.downloadProvider = new DownloadProviderImpl();
        Utils.intiMediaDisk();
    }

    public boolean isonline() {
        ConnectivityManager cManager = (ConnectivityManager) getSystemService("connectivity");
        NetworkInfo info = cManager.getActiveNetworkInfo();
        return info != null && info.isAvailable();
    }
}
