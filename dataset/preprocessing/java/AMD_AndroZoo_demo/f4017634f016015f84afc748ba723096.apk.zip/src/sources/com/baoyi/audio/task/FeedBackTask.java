package com.baoyi.audio.task;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;
import com.baoyi.audio.utils.RpcUtils2;
import com.iring.entity.ApkComment;
import com.iring.rpc.RpcSerializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class FeedBackTask extends AsyncTask<RpcSerializable, Integer, RpcSerializable> {
    private ApkComment apkComment;
    private Context context;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onPostExecute(RpcSerializable result) {
        super.onPostExecute((FeedBackTask) result);
        if (result != null && result.getCode() == 0) {
            Toast.makeText(this.context, "感谢你的反馈，我们的进步离不开你的支持", 0).show();
        }
    }

    public FeedBackTask(ApkComment apkComment, Context context) {
        this.apkComment = apkComment;
        this.context = context;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public RpcSerializable doInBackground(RpcSerializable... params) {
        RpcSerializable rpc = null;
        try {
            rpc = RpcUtils2.getApkCommentDao().save(this.apkComment);
            Log.i("ada", "反馈成功");
            Activity a = (Activity) this.context;
            a.finish();
            return rpc;
        } catch (Exception e) {
            return rpc;
        }
    }
}
