package com.baoyi.cp3;

import android.content.Context;
import java.lang.reflect.Method;

/* compiled from: Utils.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class b {
    public static Object a(Context ctx, String clzName, String methodName, Class<?>[] clsArr, Object[] args) {
        try {
            Class clz = a.a(ctx, null, null).c(ctx).loadClass(clzName);
            Method m = clz.getMethod(methodName, clsArr);
            return m.invoke(null, args);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
