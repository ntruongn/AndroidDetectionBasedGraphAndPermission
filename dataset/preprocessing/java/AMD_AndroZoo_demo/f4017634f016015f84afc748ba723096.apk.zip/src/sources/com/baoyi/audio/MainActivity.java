package com.baoyi.audio;

import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.ad.Banner;
import com.ad.CP;
import com.ad.TS;
import com.baoyi.audio.adapter.MainFragmentPagerAdapter;
import com.baoyi.audio.dao.Word;
import com.baoyi.audio.dao.WordDao;
import com.baoyi.audio.fragment.InfoFragment;
import com.baoyi.audio.fragment.NewFragment;
import com.baoyi.audio.fragment.RingRecommendFragment;
import com.baoyi.audio.fragment.TypeFragment;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.utils.Utils;
import com.hope.leyuan.R;
import com.iflytek.speech.RecognizerResult;
import com.iflytek.speech.SpeechConfig;
import com.iflytek.speech.SpeechError;
import com.iflytek.ui.RecognizerDialog;
import com.iflytek.ui.RecognizerDialogListener;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MainActivity extends AnalyticsFrameUI implements RecognizerDialogListener {
    private static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;
    RecognizerDialog iatDialog;
    private SharedPreferences mSharedPreferences;
    private LinearLayout more_ll;
    private LinearLayout newring_ll;
    ViewPager pager;
    private LinearLayout recommend_ll;
    private long time;
    private TextView tvtitle;
    private LinearLayout type_ll;
    private ImageView voice_img;
    protected NotificationManager mNotificationManager = null;
    private Handler handler = new Handler();
    private ViewPager.OnPageChangeListener pageChangeListener = new ViewPager.OnPageChangeListener() { // from class: com.baoyi.audio.MainActivity.1
        @Override // android.support.v4.view.ViewPager.OnPageChangeListener
        public void onPageSelected(int arg0) {
            switch (arg0) {
                case 0:
                    MainActivity.this.recommend_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.newring_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.bottom_sel));
                    MainActivity.this.type_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.more_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.tvtitle.setText("最新铃声");
                    return;
                case 1:
                    MainActivity.this.recommend_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.newring_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.type_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.bottom_sel));
                    MainActivity.this.more_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.tvtitle.setText("铃声分类");
                    return;
                case 2:
                    MainActivity.this.recommend_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.bottom_sel));
                    MainActivity.this.newring_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.type_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.more_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.tvtitle.setText("铃声推推");
                    return;
                case 3:
                    MainActivity.this.recommend_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.newring_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.type_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                    MainActivity.this.more_ll.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.bottom_sel));
                    MainActivity.this.tvtitle.setText("更多功能");
                    return;
                default:
                    return;
            }
        }

        @Override // android.support.v4.view.ViewPager.OnPageChangeListener
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        @Override // android.support.v4.view.ViewPager.OnPageChangeListener
        public void onPageScrollStateChanged(int arg0) {
        }
    };
    private View.OnClickListener changePager = new View.OnClickListener() { // from class: com.baoyi.audio.MainActivity.2
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.newRing_layout /* 2131296287 */:
                    MainActivity.this.pager.setCurrentItem(0);
                    return;
                case R.id.typeRing_layout /* 2131296288 */:
                    MainActivity.this.pager.setCurrentItem(1);
                    return;
                case R.id.recommendRing_layout /* 2131296289 */:
                    MainActivity.this.pager.setCurrentItem(2);
                    return;
                case R.id.more_layout /* 2131296290 */:
                    MainActivity.this.pager.setCurrentItem(3);
                    return;
                default:
                    return;
            }
        }
    };
    private boolean use_back_key = true;

    @Override // com.baoyi.audio.AnalyticsFrameUI, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        overridePendingTransition(R.anim.anim_fromright_toup6, R.anim.anim_down_toleft6);
        this.tvtitle = (TextView) findViewById(R.id.tvtitle);
        this.voice_img = (ImageView) findViewById(R.id.img_clear_input);
        MainFragmentPagerAdapter adaptera = new MainFragmentPagerAdapter(getSupportFragmentManager());
        adaptera.add("最新铃声", new NewFragment());
        adaptera.add("铃声分类", new TypeFragment());
        adaptera.add("铃声推推", new RingRecommendFragment());
        adaptera.add("更多功能", new InfoFragment());
        this.pager = (ViewPager) findViewById(R.id.pager);
        this.pager.setAdapter(adaptera);
        this.pager.setOnPageChangeListener(this.pageChangeListener);
        loadBottomMenu();
        this.mNotificationManager = (NotificationManager) getSystemService("notification");
        this.voice_img.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.MainActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                MainActivity.this.gopersonal();
            }
        });
        this.iatDialog = new RecognizerDialog(this, "appid=4f5aeadb");
        this.iatDialog.setListener(this);
        Banner.banner_AD(this);
        CP.cp_AD(this);
        TS.ts_AD(this);
    }

    private void loadBottomMenu() {
        this.recommend_ll = (LinearLayout) findViewById(R.id.recommendRing_layout);
        this.newring_ll = (LinearLayout) findViewById(R.id.newRing_layout);
        this.type_ll = (LinearLayout) findViewById(R.id.typeRing_layout);
        this.more_ll = (LinearLayout) findViewById(R.id.more_layout);
        this.recommend_ll.setOnClickListener(this.changePager);
        this.newring_ll.setOnClickListener(this.changePager);
        this.type_ll.setOnClickListener(this.changePager);
        this.more_ll.setOnClickListener(this.changePager);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void gopersonal() {
        Intent intent = new Intent(this, (Class<?>) MyZoneActivity.class);
        Bundle bundle = new Bundle();
        bundle.putInt(UpdateService.USERID, Utils.getUserid(this));
        intent.putExtras(bundle);
        startActivity(intent);
    }

    private void startVoiceRecognitionActivity() {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        intent.putExtra("android.speech.extra.PROMPT", "请说出你要搜索的歌曲");
        startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
    }

    @Override // com.baoyi.audio.AnalyticsFrameUI, android.support.v4.app.FragmentActivity, android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>" + resultCode);
        if (requestCode == VOICE_RECOGNITION_REQUEST_CODE && resultCode == -1) {
            ArrayList<String> matches = data.getStringArrayListExtra("android.speech.extra.RESULTS");
            if (matches != null) {
                matches.size();
            }
        } else if (resultCode == -1 && requestCode == 0) {
            Uri uri = (Uri) data.getParcelableExtra("android.intent.extra.ringtone.PICKED_URI");
            RingtoneManager.setActualDefaultRingtoneUri(this, 1, uri);
            Toast.makeText(this, "设置手机铃声成功", 0).show();
        } else if (resultCode == -1 && requestCode == 1) {
            Uri uri2 = (Uri) data.getParcelableExtra("android.intent.extra.ringtone.PICKED_URI");
            RingtoneManager.setActualDefaultRingtoneUri(this, 4, uri2);
            Toast.makeText(this, "设置闹钟铃声成功", 0).show();
        } else if (resultCode == -1 && requestCode == 2) {
            Uri uri3 = (Uri) data.getParcelableExtra("android.intent.extra.ringtone.PICKED_URI");
            RingtoneManager.setActualDefaultRingtoneUri(this, 2, uri3);
            Toast.makeText(this, "设置短信铃声成功", 0).show();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void work(View v) {
        if (v.getId() == 2131296294) {
            gopersonal();
        } else {
            searchmusic();
        }
    }

    @Override // android.support.v4.app.FragmentActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keycode, KeyEvent event) {
        if (keycode == 4) {
            finish();
            return false;
        }
        return false;
    }

    @Override // com.baoyi.audio.AnalyticsFrameUI, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        this.use_back_key = true;
    }

    private void searchmusic() {
        if ("铃声" != 0 && "铃声".length() > 0) {
            WordDao dao = new WordDao(this);
            Word word = new Word();
            word.setName("铃声");
            word.setSearchtime(System.currentTimeMillis());
            dao.addToTrack(word);
            SharedPreferences sharedPreferences = getSharedPreferences("defalutdata", 0);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("lastkey", "铃声");
            editor.commit();
            Intent intent = new Intent(this, (Class<?>) SearchListUI.class);
            intent.putExtra(UpdateService.NAME, "铃声");
            startActivityForResult(intent, 0);
        }
    }

    @Override // com.iflytek.ui.RecognizerDialogListener
    public void onEnd(SpeechError arg0) {
    }

    @Override // com.iflytek.ui.RecognizerDialogListener
    public void onResults(ArrayList<RecognizerResult> results, boolean arg1) {
        StringBuilder builder = new StringBuilder();
        Iterator<RecognizerResult> it = results.iterator();
        if (it.hasNext()) {
            RecognizerResult recognizerResult = it.next();
            builder.append(recognizerResult.text);
            System.out.println(recognizerResult.text);
        }
    }

    private String remove(StringBuilder builder) {
        String m = builder.toString();
        if (m == null) {
            m = "铃声";
        }
        return m.replace("。", "").replace(".", "").replace(",", "").replace("，", "");
    }

    public void showIatDialog() {
        this.iatDialog.setEngine("video", null, null);
        if (!"rate16k".equals("rate8k")) {
            if (!"rate16k".equals("rate11k")) {
                if (!"rate16k".equals("rate16k")) {
                    if ("rate16k".equals("rate22k")) {
                        this.iatDialog.setSampleRate(SpeechConfig.RATE.rate22k);
                    }
                } else {
                    this.iatDialog.setSampleRate(SpeechConfig.RATE.rate16k);
                }
            } else {
                this.iatDialog.setSampleRate(SpeechConfig.RATE.rate11k);
            }
        } else {
            this.iatDialog.setSampleRate(SpeechConfig.RATE.rate8k);
        }
        this.iatDialog.show();
    }
}
