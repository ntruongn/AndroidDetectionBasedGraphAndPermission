package com.feiwothree.coverscreen.a;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class s {
    private static s a = null;
    private ExecutorService b;

    private s() {
        this.b = null;
        this.b = Executors.newFixedThreadPool(5);
    }

    public static s a() {
        if (a == null) {
            a = new s();
        }
        return a;
    }

    public final void a(u uVar) {
        this.b.submit(uVar);
    }
}
