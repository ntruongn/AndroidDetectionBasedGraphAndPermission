package com.baoyi.audio.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import com.baoyi.audio.About;
import com.baoyi.audio.FeedBack;
import com.baoyi.audio.SettingsActivity;
import com.baoyi.audio.task.ClearCacheTask;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class InfoFragment extends Fragment implements View.OnClickListener {
    ImageView clear;
    ImageView contactus;
    ImageView good;
    ImageView help;
    ImageView info;
    ImageView setting;

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.setting = (ImageView) getView().findViewById(R.id.setting);
        this.clear = (ImageView) getView().findViewById(R.id.clear);
        this.help = (ImageView) getView().findViewById(R.id.help);
        this.info = (ImageView) getView().findViewById(R.id.info);
        this.good = (ImageView) getView().findViewById(R.id.good);
        this.contactus = (ImageView) getView().findViewById(R.id.contactus);
        this.setting.setOnClickListener(this);
        this.clear.setOnClickListener(this);
        this.help.setOnClickListener(this);
        this.info.setOnClickListener(this);
        this.contactus.setOnClickListener(this);
        this.good.setOnClickListener(this);
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_info, container, false);
        return view;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        v.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.max));
        if (v.getId() == 2131296355) {
            new ClearCacheTask(getActivity()).execute(new Integer[0]);
        }
        if (v.getId() == 2131296356) {
            Intent intent = new Intent(getActivity(), (Class<?>) About.class);
            intent.putExtra("type", 3);
            startActivity(intent);
        }
        if (v.getId() == 2131296338) {
            startActivity(new Intent(getActivity(), (Class<?>) FeedBack.class));
        }
        if (v.getId() == 2131296357) {
            Intent intent2 = new Intent(getActivity(), (Class<?>) About.class);
            intent2.putExtra("type", 2);
            startActivity(intent2);
        }
        if (v.getId() == 2131296358) {
            rateApplication();
        }
        if (v.getId() == 2131296354) {
            setting();
        }
    }

    private void setting() {
        Intent rateIntent = new Intent(getActivity(), (Class<?>) SettingsActivity.class);
        startActivity(rateIntent);
    }

    protected void rateApplication() {
        Intent rateIntent = new Intent("android.intent.action.VIEW");
        rateIntent.setData(Uri.parse("market://details?id=" + getActivity().getPackageName()));
        startActivity(rateIntent);
    }
}
