package com.feiwothree.coverscreen;

import android.content.Intent;
import android.net.Uri;
import android.webkit.DownloadListener;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
final class C implements DownloadListener {
    private /* synthetic */ WA a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public C(WA wa) {
        this.a = wa;
    }

    @Override // android.webkit.DownloadListener
    public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
        this.a.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
    }
}
