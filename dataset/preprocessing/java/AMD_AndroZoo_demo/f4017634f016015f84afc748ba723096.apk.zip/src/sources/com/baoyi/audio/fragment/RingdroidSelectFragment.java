package com.baoyi.audio.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.MergeCursor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ListFragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.baoyi.audio.service.UpdateService;
import com.hope.leyuan.R;
import com.ringdroid.ChooseContactActivity;
import com.ringdroid.RingdroidEditActivity;
import com.ringdroid.soundfile.CheapSoundFile;
import java.io.File;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RingdroidSelectFragment extends ListFragment implements TextWatcher {
    private static final int CMD_ABOUT = 1;
    private static final int CMD_DELETE = 5;
    private static final int CMD_EDIT = 4;
    private static final int CMD_PRIVACY = 2;
    private static final int CMD_SET_AS_ALERT = 1000;
    private static final int CMD_SET_AS_CONTACT = 7;
    private static final int CMD_SET_AS_DEFAULT = 6;
    private static final int CMD_SET_AS_NOTICE = 2000;
    private static final int CMD_SET_AS_UP = 3000;
    private static final int CMD_SHOW_ALL = 3;
    private static final int REQUEST_CODE_CHOOSE_CONTACT = 2;
    private static final int REQUEST_CODE_EDIT = 1;
    private SimpleCursorAdapter mAdapter;
    private TextView mFilter;
    private boolean mShowAll;
    private boolean mWasGetContentIntent;
    private static final String[] INTERNAL_COLUMNS = {"_id", "_data", "title", UpdateService.ARTIST, "album", "is_ringtone", "is_alarm", "is_notification", "is_music", "\"" + MediaStore.Audio.Media.INTERNAL_CONTENT_URI + "\""};
    private static final String[] EXTERNAL_COLUMNS = {"_id", "_data", "title", UpdateService.ARTIST, "album", "is_ringtone", "is_alarm", "is_notification", "is_music", "\"" + MediaStore.Audio.Media.EXTERNAL_CONTENT_URI + "\""};

    @Override // android.support.v4.app.ListFragment, android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_media_select, container, false);
        return view;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle icicle) {
        super.onCreate(icicle);
        this.mShowAll = true;
        String status = Environment.getExternalStorageState();
        if (status.equals("mounted_ro")) {
            showFinalAlert(getResources().getText(R.string.sdcard_readonly));
            return;
        }
        if (status.equals("shared")) {
            showFinalAlert(getResources().getText(R.string.sdcard_shared));
            return;
        }
        if (!status.equals("mounted")) {
            showFinalAlert(getResources().getText(R.string.no_sdcard));
            return;
        }
        try {
            this.mAdapter = new SimpleCursorAdapter(getActivity(), R.layout.media_select_row, createCursor(""), new String[]{UpdateService.ARTIST, "album", "title", "_id", "_id"}, new int[]{R.id.row_artist, R.id.row_album, R.id.row_title, R.id.row_icon, R.id.row_options_button});
            setListAdapter(this.mAdapter);
            getListView().setItemsCanFocus(true);
            getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.baoyi.audio.fragment.RingdroidSelectFragment.1
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView parent, View view, int position, long id) {
                    RingdroidSelectFragment.this.startRingdroidEditor();
                }
            });
            this.mAdapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() { // from class: com.baoyi.audio.fragment.RingdroidSelectFragment.2
                @Override // android.widget.SimpleCursorAdapter.ViewBinder
                public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
                    if (view.getId() == 2131296434) {
                        ImageView iv = (ImageView) view;
                        iv.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.fragment.RingdroidSelectFragment.2.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View v) {
                                RingdroidSelectFragment.this.getActivity().openContextMenu(v);
                            }
                        });
                        return true;
                    }
                    if (view.getId() != 2131296430) {
                        return false;
                    }
                    RingdroidSelectFragment.this.setSoundIconFromCursor((ImageView) view, cursor);
                    return true;
                }
            });
            registerForContextMenu(getListView());
        } catch (IllegalArgumentException e) {
            Log.e("Ringdroid", e.toString());
        } catch (SecurityException e2) {
            Log.e("Ringdroid", e2.toString());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setSoundIconFromCursor(ImageView view, Cursor cursor) {
        if (cursor.getInt(cursor.getColumnIndexOrThrow("is_ringtone")) != 0) {
            view.setImageResource(R.drawable.type_ringtone);
        } else if (cursor.getInt(cursor.getColumnIndexOrThrow("is_alarm")) != 0) {
            view.setImageResource(R.drawable.type_alarm);
        } else if (cursor.getInt(cursor.getColumnIndexOrThrow("is_notification")) != 0) {
            view.setImageResource(R.drawable.type_notification);
        } else if (cursor.getInt(cursor.getColumnIndexOrThrow("is_music")) != 0) {
            view.setImageResource(R.drawable.type_music);
        }
        String filename = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
        CheapSoundFile.isFilenameSupported(filename);
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                RingdroidEditActivity.onAbout(getActivity());
                return true;
            case 2:
                showPrivacyDialog();
                return true;
            case 3:
                this.mShowAll = true;
                refreshListView();
                return true;
            default:
                return false;
        }
    }

    @Override // android.support.v4.app.Fragment, android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        Cursor c = this.mAdapter.getCursor();
        String title = c.getString(c.getColumnIndexOrThrow("title"));
        menu.setHeaderTitle(title);
        menu.add(0, 4, 0, R.string.context_menu_edit);
        menu.add(0, 5, 0, R.string.context_menu_delete);
        if (c.getInt(c.getColumnIndexOrThrow("is_ringtone")) != 0) {
            menu.add(0, 6, 0, "设置为手机铃声");
            menu.add(0, 7, 0, R.string.context_menu_contact);
        } else if (c.getInt(c.getColumnIndexOrThrow("is_notification")) != 0) {
            menu.add(0, CMD_SET_AS_NOTICE, 0, "设置为短信铃声");
        } else if (c.getInt(c.getColumnIndexOrThrow("is_alarm")) != 0) {
            menu.add(0, CMD_SET_AS_ALERT, 0, "设置为闹钟铃声");
        }
        int dataIndex = c.getColumnIndexOrThrow("_data");
        String filename = c.getString(dataIndex);
        if (filename.endsWith(".mp3")) {
            menu.add(0, 3000, 0, "上传铃声");
        }
    }

    @Override // android.support.v4.app.Fragment
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 4:
                startRingdroidEditor();
                return true;
            case 5:
                confirmDelete();
                return true;
            case 6:
                setAsDefaultRingtoneOrNotification();
                return true;
            case 7:
                return chooseContactForRingtone(item);
            case CMD_SET_AS_ALERT /* 1000 */:
                setAsDefaultAlert();
                return true;
            case CMD_SET_AS_NOTICE /* 2000 */:
                setAsDefaultNOTIFICATION();
                return true;
            case 3000:
                upfile(item);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    private void upfile(MenuItem item) {
        Cursor c = this.mAdapter.getCursor();
        int dataIndex = c.getColumnIndexOrThrow("_data");
        String filename = c.getString(dataIndex);
        System.out.println(filename);
    }

    private void showPrivacyDialog() {
        try {
            Intent intent = new Intent("android.intent.action.EDIT", Uri.parse(""));
            intent.putExtra("privacy", true);
            intent.setClass(getActivity(), RingdroidEditActivity.class);
            startActivityForResult(intent, 1);
        } catch (Exception e) {
            Log.e("Ringdroid", "Couldn't show privacy dialog");
        }
    }

    private void setAsDefaultRingtoneOrNotification() {
        Cursor c = this.mAdapter.getCursor();
        if (c.getInt(c.getColumnIndexOrThrow("is_ringtone")) != 0) {
            RingtoneManager.setActualDefaultRingtoneUri(getActivity(), 1, getUri());
            Toast.makeText(getActivity(), (int) R.string.default_ringtone_success_message, 0).show();
        } else {
            RingtoneManager.setActualDefaultRingtoneUri(getActivity(), 2, getUri());
            Toast.makeText(getActivity(), (int) R.string.default_notification_success_message, 0).show();
        }
    }

    private void setAsDefaultAlert() {
        Cursor c = this.mAdapter.getCursor();
        if (c.getInt(c.getColumnIndexOrThrow("is_alarm")) != 0) {
            RingtoneManager.setActualDefaultRingtoneUri(getActivity(), 4, getUri());
            Toast.makeText(getActivity(), "设置闹钟铃声成功", 0).show();
        } else {
            RingtoneManager.setActualDefaultRingtoneUri(getActivity(), 4, getUri());
            Toast.makeText(getActivity(), "设置闹钟铃声成功", 0).show();
        }
    }

    private void setAsDefaultNOTIFICATION() {
        Cursor c = this.mAdapter.getCursor();
        if (c.getInt(c.getColumnIndexOrThrow("is_notification")) != 0) {
            RingtoneManager.setActualDefaultRingtoneUri(getActivity(), 2, getUri());
            Toast.makeText(getActivity(), "设置短信铃声成功", 0).show();
        } else {
            RingtoneManager.setActualDefaultRingtoneUri(getActivity(), 2, getUri());
            Toast.makeText(getActivity(), "设置短信铃声成功", 0).show();
        }
    }

    private Uri getUri() {
        Cursor c = this.mAdapter.getCursor();
        int uriIndex = c.getColumnIndex("\"" + MediaStore.Audio.Media.INTERNAL_CONTENT_URI + "\"");
        if (uriIndex == -1) {
            uriIndex = c.getColumnIndex("\"" + MediaStore.Audio.Media.EXTERNAL_CONTENT_URI + "\"");
        }
        String itemUri = String.valueOf(c.getString(uriIndex)) + "/" + c.getString(c.getColumnIndexOrThrow("_id"));
        return Uri.parse(itemUri);
    }

    private boolean chooseContactForRingtone(MenuItem item) {
        try {
            Intent intent = new Intent("android.intent.action.EDIT", getUri());
            intent.setClass(getActivity(), ChooseContactActivity.class);
            startActivityForResult(intent, 2);
            return true;
        } catch (Exception e) {
            Log.e("Ringdroid", "Couldn't open Choose Contact window");
            return true;
        }
    }

    private void confirmDelete() {
        CharSequence message;
        CharSequence title;
        Cursor c = this.mAdapter.getCursor();
        c.getColumnIndexOrThrow(UpdateService.ARTIST);
        String artist = c.getString(c.getColumnIndexOrThrow(UpdateService.ARTIST));
        CharSequence ringdroidArtist = getResources().getText(R.string.artist_name);
        if (artist.equals(ringdroidArtist)) {
            message = getResources().getText(R.string.confirm_delete_ringdroid);
        } else {
            message = getResources().getText(R.string.confirm_delete_non_ringdroid);
        }
        if (c.getInt(c.getColumnIndexOrThrow("is_ringtone")) != 0) {
            title = getResources().getText(R.string.delete_ringtone);
        } else if (c.getInt(c.getColumnIndexOrThrow("is_alarm")) != 0) {
            title = getResources().getText(R.string.delete_alarm);
        } else if (c.getInt(c.getColumnIndexOrThrow("is_notification")) != 0) {
            title = getResources().getText(R.string.delete_notification);
        } else if (c.getInt(c.getColumnIndexOrThrow("is_music")) != 0) {
            title = getResources().getText(R.string.delete_music);
        } else {
            title = getResources().getText(R.string.delete_audio);
        }
        new AlertDialog.Builder(getActivity()).setTitle(title).setMessage(message).setPositiveButton(R.string.delete_ok_button, new DialogInterface.OnClickListener() { // from class: com.baoyi.audio.fragment.RingdroidSelectFragment.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                RingdroidSelectFragment.this.onDelete();
            }
        }).setNegativeButton(R.string.delete_cancel_button, new DialogInterface.OnClickListener() { // from class: com.baoyi.audio.fragment.RingdroidSelectFragment.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        }).setCancelable(true).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDelete() {
        Cursor c = this.mAdapter.getCursor();
        int dataIndex = c.getColumnIndexOrThrow("_data");
        String filename = c.getString(dataIndex);
        int uriIndex = c.getColumnIndex("\"" + MediaStore.Audio.Media.INTERNAL_CONTENT_URI + "\"");
        if (uriIndex == -1) {
            uriIndex = c.getColumnIndex("\"" + MediaStore.Audio.Media.EXTERNAL_CONTENT_URI + "\"");
        }
        if (uriIndex == -1) {
            showFinalAlert(getResources().getText(R.string.delete_failed));
            return;
        }
        if (!new File(filename).delete()) {
            showFinalAlert(getResources().getText(R.string.delete_failed));
        }
        String itemUri = String.valueOf(c.getString(uriIndex)) + "/" + c.getString(c.getColumnIndexOrThrow("_id"));
        getActivity().getContentResolver().delete(Uri.parse(itemUri), null, null);
    }

    private void showFinalAlert(CharSequence message) {
        new AlertDialog.Builder(getActivity()).setTitle(getResources().getText(R.string.alert_title_failure)).setMessage(message).setPositiveButton(R.string.alert_ok_button, new DialogInterface.OnClickListener() { // from class: com.baoyi.audio.fragment.RingdroidSelectFragment.5
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        }).setCancelable(false).show();
    }

    private void onRecord() {
        try {
            Intent intent = new Intent("android.intent.action.EDIT", Uri.parse("record"));
            intent.putExtra("was_get_content_intent", this.mWasGetContentIntent);
            intent.setClass(getActivity(), RingdroidEditActivity.class);
            startActivityForResult(intent, 1);
        } catch (Exception e) {
            Log.e("Ringdroid", "Couldn't start editor");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startRingdroidEditor() {
        Cursor c = this.mAdapter.getCursor();
        int dataIndex = c.getColumnIndexOrThrow("_data");
        String filename = c.getString(dataIndex);
        try {
            Intent intent = new Intent("android.intent.action.EDIT", Uri.parse(filename));
            intent.putExtra("was_get_content_intent", this.mWasGetContentIntent);
            intent.setClass(getActivity(), RingdroidEditActivity.class);
            startActivityForResult(intent, 1);
        } catch (Exception e) {
            Log.e("Ringdroid", "Couldn't start editor");
        }
    }

    private Cursor getInternalAudioCursor(String selection, String[] selectionArgs) {
        return getActivity().managedQuery(MediaStore.Audio.Media.INTERNAL_CONTENT_URI, INTERNAL_COLUMNS, selection, selectionArgs, "title_key");
    }

    private Cursor getExternalAudioCursor(String selection, String[] selectionArgs) {
        return getActivity().managedQuery(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, EXTERNAL_COLUMNS, selection, selectionArgs, "title_key");
    }

    Cursor createCursor(String filter) {
        String selection;
        ArrayList<String> args = new ArrayList<>();
        if (this.mShowAll) {
            selection = "(_DATA LIKE ?)";
            args.add("%");
        } else {
            String selection2 = "(";
            for (String extension : CheapSoundFile.getSupportedExtensions()) {
                args.add("%." + extension);
                if (selection2.length() > 1) {
                    selection2 = String.valueOf(selection2) + " OR ";
                }
                selection2 = String.valueOf(selection2) + "(_DATA LIKE ?)";
            }
            selection = "(" + (String.valueOf(selection2) + ")") + ") AND (_DATA NOT LIKE ?)";
            args.add("%espeak-data/scratch%");
        }
        if (filter != null && filter.length() > 0) {
            String filter2 = "%" + filter + "%";
            selection = "(" + selection + " AND ((TITLE LIKE ?) OR (ARTIST LIKE ?) OR (ALBUM LIKE ?)))";
            args.add(filter2);
            args.add(filter2);
            args.add(filter2);
        }
        String[] argsArray = (String[]) args.toArray(new String[args.size()]);
        getExternalAudioCursor(selection, argsArray);
        getInternalAudioCursor(selection, argsArray);
        Cursor c = new MergeCursor(new Cursor[]{getExternalAudioCursor(selection, argsArray), getInternalAudioCursor(selection, argsArray)});
        getActivity().startManagingCursor(c);
        return c;
    }

    @Override // android.text.TextWatcher
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override // android.text.TextWatcher
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override // android.text.TextWatcher
    public void afterTextChanged(Editable s) {
        refreshListView();
    }

    private void refreshListView() {
        String filterStr = this.mFilter.getText().toString();
        this.mAdapter.changeCursor(createCursor(filterStr));
    }
}
