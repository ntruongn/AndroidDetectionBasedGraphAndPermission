package com.baoyi.audio.task;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;
import com.baoyi.audio.AsyncMusicPlayer;
import com.baoyi.audio.BaoyiApplication;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.SearchWidget;
import com.baoyi.doamin.KoWoMusic;
import com.baoyi.doamin.Song;
import com.baoyi.service.Mp3Service;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class LoadingMp3 extends AsyncTask<SearchWidget, Void, Song> {
    private Context context;
    private ProgressDialog progressDialog = null;

    public LoadingMp3(Context c) {
        this.context = c;
    }

    @Override // android.os.AsyncTask
    public void onPreExecute() {
        this.progressDialog = ProgressDialog.show(this.context, "选择音频服务器", "正在选择音频服务器,请稍候！", true);
        this.progressDialog.setCancelable(true);
        super.onPreExecute();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public Song doInBackground(SearchWidget... params) {
        SearchWidget item = params[0];
        KoWoMusic kowo = item.getWorkItem();
        if (kowo.getType() == 100) {
            Song song = new Song();
            song.setPath(kowo.getUrl());
            song.setAacpath(kowo.getUrl());
            song.setMp3path(kowo.getUrl());
            song.setName(kowo.getName());
            return song;
        }
        Song song2 = Mp3Service.findbyId(item.getWorkItem().getRid());
        int time = 0;
        while (true) {
            if ((song2 == null || song2.getPath().length() < 10) && time <= 4) {
                time++;
                song2 = Mp3Service.findbyId(item.getWorkItem().getRid());
            } else {
                return song2;
            }
        }
    }

    public String geturl(Song song) {
        if (song.getAacpath() != null && song.getAacpath().startsWith("http")) {
            String url = song.getAacpath();
            return url;
        }
        if (song.getMp3path() != null && song.getMp3path().startsWith("http")) {
            String url2 = song.getMp3path();
            return url2;
        }
        String url3 = song.getPath();
        return url3;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onPostExecute(Song result) {
        if (result != null) {
            String mp3Url = geturl(result);
            Intent intent = new Intent(this.context, (Class<?>) AsyncMusicPlayer.class);
            intent.putExtra(UpdateService.NAME, result.getName());
            intent.putExtra("fileurl", mp3Url);
            intent.putExtra("nextid", 0);
            intent.putExtra("preid", 0);
            if (result.getMid() > 1) {
                intent.putExtra("musicid", result.getMid());
            } else {
                int code = 100000 + result.getName().hashCode();
                intent.putExtra("musicid", code);
            }
            String ext = mp3Url.substring(mp3Url.lastIndexOf("."));
            String files = String.valueOf(content.SAVEDIR) + result.getName() + ext;
            File file = new File(files);
            if (!BaoyiApplication.getInstance().isonline()) {
                if (!file.exists()) {
                    Toast.makeText(this.context, "请检查你的网络,该铃声不存在", 0).show();
                } else {
                    this.context.startActivity(intent);
                }
            } else {
                this.context.startActivity(intent);
            }
        } else {
            Toast.makeText(this.context, "选着服务器失败,请稍后再试！", 0).show();
        }
        this.progressDialog.dismiss();
    }
}
