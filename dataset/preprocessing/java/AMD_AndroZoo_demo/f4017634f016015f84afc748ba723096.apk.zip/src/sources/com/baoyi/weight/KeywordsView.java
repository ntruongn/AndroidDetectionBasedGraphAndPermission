package com.baoyi.weight;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.util.LinkedList;
import java.util.Random;
import java.util.Vector;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class KeywordsView extends FrameLayout implements ViewTreeObserver.OnGlobalLayoutListener {
    public static final int ANIMATION_IN = 1;
    public static final int ANIMATION_OUT = 2;
    public static final long ANIM_DURATION = 800;
    public static final int CENTER_TO_LOCATION = 3;
    public static final int IDX_DIS_Y = 3;
    public static final int IDX_TXT_LENGTH = 2;
    public static final int IDX_X = 0;
    public static final int IDX_Y = 1;
    public static final int LOCATION_TO_CENTER = 4;
    public static final int LOCATION_TO_OUTSIDE = 2;
    public static final int MAX = 10;
    public static final int OUTSIDE_TO_LOCATION = 1;
    public static final int TEXT_SIZE_MAX = 25;
    public static final int TEXT_SIZE_MIN = 15;
    private static AlphaAnimation animAlpha2Opaque;
    private static AlphaAnimation animAlpha2Transparent;
    private static ScaleAnimation animScaleLarge2Normal;
    private static ScaleAnimation animScaleNormal2Large;
    private static ScaleAnimation animScaleNormal2Zero;
    private static ScaleAnimation animScaleZero2Normal;
    private static Interpolator interpolator;
    private long animDuration;
    private boolean enableShow;
    private int height;
    private View.OnClickListener itemClickListener;
    private long lastStartAnimationTime;
    private Random random;
    private int txtAnimInType;
    private int txtAnimOutType;
    private Vector<String> vecKeywords;
    private int width;

    public KeywordsView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    public KeywordsView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public KeywordsView(Context context) {
        super(context);
        init();
    }

    private void init() {
        this.lastStartAnimationTime = 0L;
        this.animDuration = 800L;
        this.random = new Random();
        this.vecKeywords = new Vector<>(10);
        getViewTreeObserver().addOnGlobalLayoutListener(this);
        interpolator = AnimationUtils.loadInterpolator(getContext(), 17432582);
        animAlpha2Opaque = new AlphaAnimation(0.0f, 1.0f);
        animAlpha2Transparent = new AlphaAnimation(1.0f, 0.0f);
        animScaleLarge2Normal = new ScaleAnimation(2.0f, 1.0f, 2.0f, 1.0f);
        animScaleNormal2Large = new ScaleAnimation(1.0f, 2.0f, 1.0f, 2.0f);
        animScaleZero2Normal = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f);
        animScaleNormal2Zero = new ScaleAnimation(1.0f, 0.0f, 1.0f, 0.0f);
    }

    public long getDuration() {
        return this.animDuration;
    }

    public void setDuration(long duration) {
        this.animDuration = duration;
    }

    public boolean feedKeyword(String keyword) {
        if (this.vecKeywords.size() >= 10) {
            return false;
        }
        boolean result = this.vecKeywords.add(keyword);
        return result;
    }

    public boolean go2Shwo(int animType) {
        if (System.currentTimeMillis() - this.lastStartAnimationTime > this.animDuration) {
            this.enableShow = true;
            if (animType == 1) {
                this.txtAnimInType = 1;
                this.txtAnimOutType = 4;
            } else if (animType == 2) {
                this.txtAnimInType = 3;
                this.txtAnimOutType = 2;
            }
            disapper();
            return show();
        }
        return false;
    }

    private void disapper() {
        int size = getChildCount();
        for (int i = size - 1; i >= 0; i--) {
            final TextView txt = (TextView) getChildAt(i);
            if (txt.getVisibility() == 8) {
                removeView(txt);
            } else {
                FrameLayout.LayoutParams layParams = (FrameLayout.LayoutParams) txt.getLayoutParams();
                int[] xy = {layParams.leftMargin, layParams.topMargin, txt.getWidth()};
                AnimationSet animSet = getAnimationSet(xy, this.width >> 1, this.height >> 1, this.txtAnimOutType);
                txt.startAnimation(animSet);
                animSet.setAnimationListener(new Animation.AnimationListener() { // from class: com.baoyi.weight.KeywordsView.1
                    @Override // android.view.animation.Animation.AnimationListener
                    public void onAnimationStart(Animation animation) {
                    }

                    @Override // android.view.animation.Animation.AnimationListener
                    public void onAnimationRepeat(Animation animation) {
                    }

                    @Override // android.view.animation.Animation.AnimationListener
                    public void onAnimationEnd(Animation animation) {
                        txt.setOnClickListener(null);
                        txt.setClickable(true);
                        txt.setVisibility(8);
                    }
                });
            }
        }
    }

    private boolean show() {
        if (this.width > 0 && this.height > 0 && this.vecKeywords != null && this.vecKeywords.size() > 0 && this.enableShow) {
            this.enableShow = false;
            this.lastStartAnimationTime = System.currentTimeMillis();
            int xCenter = this.width >> 1;
            int yCenter = this.height >> 1;
            int size = this.vecKeywords.size();
            int xItem = this.width / size;
            int yItem = this.height / size;
            Log.d("ANDROID_LAB", "--------------------------width=" + this.width + " height=" + this.height + "  xItem=" + xItem + " yItem=" + yItem + "---------------------------");
            LinkedList<Integer> listX = new LinkedList<>();
            LinkedList<Integer> listY = new LinkedList<>();
            for (int i = 0; i < size; i++) {
                listX.add(Integer.valueOf(i * xItem));
                listY.add(Integer.valueOf((i * yItem) + (yItem >> 2)));
                Log.e("Search", "ListX:" + (i * xItem) + "#listY:" + ((i * yItem) + (yItem >> 2)));
            }
            LinkedList<TextView> listTxtTop = new LinkedList<>();
            LinkedList<TextView> listTxtBottom = new LinkedList<>();
            for (int i2 = 0; i2 < size; i2++) {
                String keyword = this.vecKeywords.get(i2);
                int color = this.random.nextInt(4);
                int ranColor = Color.parseColor("#e61939");
                if (color == 0) {
                    ranColor = Color.parseColor("#d519e6");
                } else if (color == 1) {
                    ranColor = Color.parseColor("#1966e6");
                } else if (color == 2) {
                    ranColor = Color.parseColor("#24b819");
                } else if (color == 3) {
                    ranColor = Color.parseColor("#ece90d");
                }
                int[] xy = randomXY(this.random, listX, listY, xItem);
                int txtSize = this.random.nextInt(11) + 15;
                TextView txt = new TextView(getContext());
                txt.setOnClickListener(this.itemClickListener);
                txt.setText(keyword);
                txt.setTextColor(ranColor);
                txt.setTextSize(2, txtSize);
                txt.setShadowLayer(1.0f, 1.0f, 1.0f, -580294295);
                txt.setGravity(17);
                Paint paint = txt.getPaint();
                int strWidth = (int) Math.ceil(paint.measureText(keyword));
                xy[2] = strWidth;
                if (xy[0] + strWidth > this.width - (xItem >> 1)) {
                    int baseX = this.width - strWidth;
                    xy[0] = (baseX - xItem) + this.random.nextInt(xItem >> 1);
                } else if (xy[0] == 0) {
                    xy[0] = Math.max(this.random.nextInt(xItem), xItem / 3);
                }
                xy[3] = Math.abs(xy[1] - yCenter);
                txt.setTag(xy);
                if (xy[1] > yCenter) {
                    listTxtBottom.add(txt);
                } else {
                    listTxtTop.add(txt);
                }
            }
            attach2Screen(listTxtTop, xCenter, yCenter, yItem);
            attach2Screen(listTxtBottom, xCenter, yCenter, yItem);
            return true;
        }
        return false;
    }

    private void attach2Screen(LinkedList<TextView> listTxt, int xCenter, int yCenter, int yItem) {
        int size = listTxt.size();
        sortXYList(listTxt, size);
        for (int i = 0; i < size; i++) {
            TextView txt = listTxt.get(i);
            int[] iXY = (int[]) txt.getTag();
            int yDistance = iXY[1] - yCenter;
            int yMove = Math.abs(yDistance);
            int k = i - 1;
            while (true) {
                if (k < 0) {
                    break;
                }
                int[] kXY = (int[]) listTxt.get(k).getTag();
                int startX = kXY[0];
                int endX = startX + kXY[2];
                if ((kXY[1] - yCenter) * yDistance <= 0 || !isXMixed(startX, endX, iXY[0], iXY[0] + iXY[2])) {
                    k--;
                } else {
                    int tmpMove = Math.abs(iXY[1] - kXY[1]);
                    if (tmpMove > yItem) {
                        yMove = tmpMove;
                    } else if (yMove > 0) {
                        yMove = 0;
                    }
                }
            }
            if (yMove > yItem) {
                int maxMove = yMove - yItem;
                int randomMove = this.random.nextInt(maxMove);
                int realMove = (Math.max(randomMove, maxMove >> 1) * yDistance) / Math.abs(yDistance);
                iXY[1] = iXY[1] - realMove;
                iXY[3] = Math.abs(iXY[1] - yCenter);
                sortXYList(listTxt, i + 1);
            }
            FrameLayout.LayoutParams layParams = new FrameLayout.LayoutParams(-2, -2);
            layParams.gravity = 51;
            layParams.leftMargin = iXY[0];
            layParams.topMargin = iXY[1];
            addView(txt, layParams);
            AnimationSet animSet = getAnimationSet(iXY, xCenter, yCenter, this.txtAnimInType);
            txt.startAnimation(animSet);
        }
    }

    public AnimationSet getAnimationSet(int[] xy, int xCenter, int yCenter, int type) {
        AnimationSet animSet = new AnimationSet(true);
        animSet.setInterpolator(interpolator);
        if (type == 1) {
            animSet.addAnimation(animAlpha2Opaque);
            animSet.addAnimation(animScaleLarge2Normal);
            TranslateAnimation translate = new TranslateAnimation(((xy[0] + (xy[2] >> 1)) - xCenter) << 1, 0.0f, (xy[1] - yCenter) << 1, 0.0f);
            animSet.addAnimation(translate);
        } else if (type == 2) {
            animSet.addAnimation(animAlpha2Transparent);
            animSet.addAnimation(animScaleNormal2Large);
            TranslateAnimation translate2 = new TranslateAnimation(0.0f, ((xy[0] + (xy[2] >> 1)) - xCenter) << 1, 0.0f, (xy[1] - yCenter) << 1);
            animSet.addAnimation(translate2);
        } else if (type == 4) {
            animSet.addAnimation(animAlpha2Transparent);
            animSet.addAnimation(animScaleNormal2Zero);
            TranslateAnimation translate3 = new TranslateAnimation(0.0f, (-xy[0]) + xCenter, 0.0f, (-xy[1]) + yCenter);
            animSet.addAnimation(translate3);
        } else if (type == 3) {
            animSet.addAnimation(animAlpha2Opaque);
            animSet.addAnimation(animScaleZero2Normal);
            TranslateAnimation translate4 = new TranslateAnimation((-xy[0]) + xCenter, 0.0f, (-xy[1]) + yCenter, 0.0f);
            animSet.addAnimation(translate4);
        }
        animSet.setDuration(this.animDuration);
        return animSet;
    }

    private void sortXYList(LinkedList<TextView> listTxt, int endIdx) {
        for (int i = 0; i < endIdx; i++) {
            for (int k = i + 1; k < endIdx; k++) {
                if (((int[]) listTxt.get(k).getTag())[3] < ((int[]) listTxt.get(i).getTag())[3]) {
                    TextView iTmp = listTxt.get(i);
                    TextView kTmp = listTxt.get(k);
                    listTxt.set(i, kTmp);
                    listTxt.set(k, iTmp);
                }
            }
        }
    }

    private boolean isXMixed(int startA, int endA, int startB, int endB) {
        if (startB >= startA && startB <= endA) {
            return true;
        }
        if (endB >= startA && endB <= endA) {
            return true;
        }
        if (startA >= startB && startA <= endB) {
            return true;
        }
        if (endA < startB || endA > endB) {
            return false;
        }
        return true;
    }

    private int[] randomXY(Random ran, LinkedList<Integer> listX, LinkedList<Integer> listY, int xItem) {
        int[] arr = {listX.remove(ran.nextInt(listX.size())).intValue(), listY.remove(ran.nextInt(listY.size())).intValue()};
        return arr;
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public void onGlobalLayout() {
        int tmpW = getWidth();
        int tmpH = getHeight();
        if (this.width != tmpW || this.height != tmpH) {
            this.width = tmpW;
            this.height = tmpH;
            show();
        }
    }

    public Vector<String> getKeywords() {
        return this.vecKeywords;
    }

    public void rubKeywords() {
        this.vecKeywords.clear();
    }

    public void rubAllViews() {
        removeAllViews();
    }

    public void setOnItemClickListener(View.OnClickListener listener) {
        this.itemClickListener = listener;
    }
}
