package com.feiwothree.coverscreen.a;

import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class y {
    public static int a(String str, int i) {
        if (str == null || str.equals("")) {
            return 0;
        }
        try {
            return Integer.parseInt(str.trim());
        } catch (NumberFormatException e) {
            Log.w("NumberUtil.java", "errorMessage > " + e);
            return 0;
        }
    }
}
