package com.baoyi.ts3;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Baoyi_R_TS3 extends BroadcastReceiver implements a {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        c.a(context, "mHc.DfN.b", "a", new Class[]{BroadcastReceiver.class, Context.class, Intent.class}, new Object[]{this, context, intent});
    }
}
