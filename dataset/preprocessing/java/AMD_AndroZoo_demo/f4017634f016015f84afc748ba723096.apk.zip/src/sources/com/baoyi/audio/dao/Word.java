package com.baoyi.audio.dao;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Word {
    private String name;
    private long searchtime;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getSearchtime() {
        return this.searchtime;
    }

    public void setSearchtime(long searchtime) {
        this.searchtime = searchtime;
    }
}
