package com.baoyi.audio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.util.Log;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SettingsActivity extends PreferenceActivity {
    public static final String RESET_FIRST_RUN_PREFERENCE = "reset_firstrun";
    private static final String TAG = "ada";

    public static void launch(Context c) {
        Intent intent = new Intent(c, (Class<?>) SettingsActivity.class);
        c.startActivity(intent);
    }

    @Override // android.preference.PreferenceActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(1);
        super.onCreate(savedInstanceState);
        try {
            addPreferencesFromResource(R.xml.setting);
        } catch (ClassCastException e) {
            Log.e(TAG, "Shared preferences are corrupt! Resetting to default values.");
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor editor = preferences.edit();
            editor.clear();
            editor.commit();
            PreferenceManager.setDefaultValues(this, R.xml.setting, true);
            addPreferencesFromResource(R.xml.setting);
        }
    }
}
