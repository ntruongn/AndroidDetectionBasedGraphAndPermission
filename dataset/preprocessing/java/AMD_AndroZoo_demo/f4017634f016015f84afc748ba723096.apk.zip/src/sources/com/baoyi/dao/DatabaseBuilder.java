package com.baoyi.dao;

import android.content.ContentValues;
import android.database.Cursor;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public abstract class DatabaseBuilder<T> {
    public abstract T build(Cursor cursor);

    public abstract ContentValues deconstruct(T t);

    public long getLong(String key, Cursor query) {
        int indexid = query.getColumnIndex(key);
        long resutl = query.getLong(indexid);
        return resutl;
    }

    public long getLongOrThrow(String key, Cursor query) {
        int indexid = query.getColumnIndexOrThrow(key);
        long resutl = query.getLong(indexid);
        return resutl;
    }

    public int getInt(String key, Cursor query) {
        int indexid = query.getColumnIndex(key);
        int resutl = query.getInt(indexid);
        return resutl;
    }

    public int getIntOrThrow(String key, Cursor query) {
        int indexid = query.getColumnIndexOrThrow(key);
        int resutl = query.getInt(indexid);
        return resutl;
    }

    public String getString(String key, Cursor query) {
        int indexid = query.getColumnIndex(key);
        String resutl = query.getString(indexid);
        return resutl;
    }

    public String getStringOrThrow(String key, Cursor query) {
        int indexid = query.getColumnIndexOrThrow(key);
        String resutl = query.getString(indexid);
        return resutl;
    }
}
