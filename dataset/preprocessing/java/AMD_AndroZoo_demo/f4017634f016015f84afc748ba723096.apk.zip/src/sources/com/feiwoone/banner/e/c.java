package com.feiwoone.banner.e;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import java.lang.ref.SoftReference;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class c implements Runnable {
    private /* synthetic */ a a;
    private final /* synthetic */ Context b;
    private final /* synthetic */ String c;
    private final /* synthetic */ Handler d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(a aVar, Context context, String str, Handler handler) {
        this.a = aVar;
        this.b = context;
        this.c = str;
        this.d = handler;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Map map;
        Drawable a = f.a(this.b, this.c);
        if (a == null) {
            try {
                Thread.sleep(500L);
            } catch (InterruptedException e) {
            }
            a = f.a(this.b, this.c);
        }
        if (a != null) {
            map = this.a.d;
            map.put(this.c, new SoftReference(a));
            this.d.sendMessage(this.d.obtainMessage(0, a));
        }
    }
}
