package com.baoyi.download.core.network;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class NetworkNotifications {
    private static final int BOOK_DOWNLOADING_END = 536870911;
    private static final int BOOK_DOWNLOADING_START = 268435456;
    private static NetworkNotifications ourInstance;
    private volatile int myBookDownloadingId = BOOK_DOWNLOADING_START;

    public static NetworkNotifications Instance() {
        if (ourInstance == null) {
            ourInstance = new NetworkNotifications();
        }
        return ourInstance;
    }

    private NetworkNotifications() {
    }

    public synchronized int getBookDownloadingId() {
        int id;
        id = this.myBookDownloadingId;
        if (this.myBookDownloadingId == BOOK_DOWNLOADING_END) {
            this.myBookDownloadingId = BOOK_DOWNLOADING_START;
        } else {
            this.myBookDownloadingId++;
        }
        return id;
    }
}
