package com.baoyi.ring.adapter;

import android.content.Context;
import android.view.View;
import com.baoyi.adapter.ItemListHolderAdapter;
import com.baoyi.ring.entity.LocalMusic;
import com.baoyi.ring.fragment.LocalFragment;
import com.baoyi.ring.widget.LocalMusicWidget;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class LocalMusicAdapter extends ItemListHolderAdapter<LocalMusic> {
    LocalFragment localFragment;

    public LocalMusicAdapter(Context context) {
        super(context);
    }

    public LocalMusicAdapter(Context context, LocalFragment locatl) {
        super(context);
        this.localFragment = locatl;
    }

    @Override // com.baoyi.adapter.ItemListHolderAdapter
    protected void otherwork(int position, View view) {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListHolderAdapter
    public View updateView(int position, View view, LocalMusic item) {
        LocalMusicWidget w = (LocalMusicWidget) view;
        w.setLocalFragment(this.localFragment);
        w.setLocalMusic(item);
        return w;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListHolderAdapter
    public View creatView(int position, LocalMusic item) {
        LocalMusicWidget w = new LocalMusicWidget(this.context);
        w.setLocalMusic(item);
        w.setLocalFragment(this.localFragment);
        return w;
    }
}
