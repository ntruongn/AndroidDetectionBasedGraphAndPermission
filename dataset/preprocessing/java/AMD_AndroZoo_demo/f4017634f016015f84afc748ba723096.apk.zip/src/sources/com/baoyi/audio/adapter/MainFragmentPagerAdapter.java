package com.baoyi.audio.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MainFragmentPagerAdapter extends FragmentPagerAdapter {
    public List<Fragment> fragments;
    public List<String> titles;

    public MainFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
        this.fragments = new ArrayList();
        this.titles = new ArrayList();
    }

    @Override // android.support.v4.app.FragmentPagerAdapter
    public Fragment getItem(int arg0) {
        return this.fragments.get(arg0);
    }

    @Override // android.support.v4.view.PagerAdapter
    public int getCount() {
        return this.fragments.size();
    }

    @Override // android.support.v4.view.PagerAdapter
    public CharSequence getPageTitle(int position) {
        return this.titles.get(position);
    }

    public void add(String title, Fragment fragment) {
        this.fragments.add(fragment);
        this.titles.add(title);
    }
}
