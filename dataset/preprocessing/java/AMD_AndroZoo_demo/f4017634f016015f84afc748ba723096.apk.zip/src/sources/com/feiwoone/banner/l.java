package com.feiwoone.banner;

import android.os.Handler;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class l implements Runnable {
    private /* synthetic */ k a;
    private final /* synthetic */ AdBanner b;
    private final /* synthetic */ Handler c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(k kVar, AdBanner adBanner, Handler handler) {
        this.a = kVar;
        this.b = adBanner;
        this.c = handler;
    }

    @Override // java.lang.Runnable
    public final void run() {
        k kVar;
        kVar = k.a;
        synchronized (kVar) {
            k.a(this.a, this.b, this.c);
        }
    }
}
