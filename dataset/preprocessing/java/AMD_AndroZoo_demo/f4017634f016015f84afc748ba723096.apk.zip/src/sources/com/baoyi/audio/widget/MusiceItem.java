package com.baoyi.audio.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.hope.leyuan.R;
import com.iring.entity.Music;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MusiceItem extends LinearLayout {
    private ImageView bf;
    Context curactivity;
    private TextView geshou;
    private TextView text;
    private TextView tingsize;
    Music workItem;

    public Music getWorkItem() {
        return this.workItem;
    }

    public void setWorkItem(Music v) {
        this.workItem = v;
        this.text.setText(v.getName());
        this.text.setText(v.getName());
        if (v.getArtist() == null || v.getArtist().length() <= 1) {
            this.geshou.setText("安卓铃声");
        } else {
            this.geshou.setText(v.getArtist());
        }
        this.tingsize.setText("试听:" + v.getHit());
    }

    public MusiceItem(Context context, Music v) {
        super(context);
        this.curactivity = context;
        LayoutInflater.from(getContext()).inflate(R.layout.widget_music_item, this);
        this.bf = (ImageView) findViewById(R.id.bf);
        this.text = (TextView) findViewById(R.id.textView1);
        this.geshou = (TextView) findViewById(R.id.geshou);
        this.tingsize = (TextView) findViewById(R.id.tingsize);
        this.text.setText(v.getName());
        if (v.getArtist() == null || v.getArtist().length() <= 1) {
            this.geshou.setText("安卓铃声");
        } else {
            this.geshou.setText(v.getArtist());
        }
        this.tingsize.setText("试听:" + v.getHit());
        this.workItem = v;
    }
}
