package com.baoyi.audio.task;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;
import com.baoyi.audio.utils.content;
import java.io.File;
import java.io.FilenameFilter;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class ClearCacheTask extends AsyncTask<Integer, String, Void> {
    Context curcontext;
    private ProgressDialog progressDialog = null;

    public ClearCacheTask(Context context) {
        this.curcontext = context;
    }

    @Override // android.os.AsyncTask
    public void onPreExecute() {
        this.progressDialog = ProgressDialog.show(this.curcontext, "清理缓存", "正在清理缓存,请稍候！", true, true);
        super.onPreExecute();
    }

    @Override // android.os.AsyncTask
    public void onPostExecute(Void url) {
        super.onPostExecute((ClearCacheTask) url);
        Toast.makeText(this.curcontext, "清理缓存成功", 0).show();
        this.progressDialog.dismiss();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onProgressUpdate(String... aa) {
        this.progressDialog.setMessage("正在清理:" + aa[0]);
    }

    @Override // android.os.AsyncTask
    public Void doInBackground(Integer... params) {
        try {
            File file = new File(content.SAVEDIR);
            File[] fs = file.listFiles(new FilenameFilter() { // from class: com.baoyi.audio.task.ClearCacheTask.1
                @Override // java.io.FilenameFilter
                public boolean accept(File dir, String filename) {
                    return filename.endsWith(".txt");
                }
            });
            if (fs != null) {
                for (File item : fs) {
                    publishProgress(item.getName());
                    item.delete();
                }
                return null;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
