package com.feiwothree.coverscreen.a;

import android.content.Context;
import android.os.Environment;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class r {
    private static r a;

    public static r a() {
        if (a == null) {
            a = new r();
        }
        return a;
    }

    public static String a(Context context, String str, String str2) {
        String stringBuffer;
        a();
        String substring = str2.substring(str2.lastIndexOf("/") + 1, str2.length());
        a();
        if (!b()) {
            a();
            StringBuffer stringBuffer2 = new StringBuffer();
            stringBuffer2.append(context.getFilesDir().getAbsolutePath());
            if (!"".startsWith("/") && !context.getFilesDir().getAbsolutePath().endsWith("/")) {
                stringBuffer2.append("/");
            }
            stringBuffer2.append("");
            File file = new File(stringBuffer2.toString());
            if (!file.exists()) {
                file.mkdirs();
            }
            return String.valueOf(stringBuffer2.toString()) + substring;
        }
        a();
        if (b()) {
            StringBuffer stringBuffer3 = new StringBuffer();
            stringBuffer3.append(Environment.getExternalStorageDirectory());
            if (!str.startsWith("/") && !Environment.getExternalStorageDirectory().toString().endsWith("/")) {
                stringBuffer3.append("/");
            }
            stringBuffer3.append(str);
            File file2 = new File(stringBuffer3.toString());
            if (!file2.exists()) {
                new StringBuilder("创建文件夹: ").append((Object) stringBuffer3).append(", 是否成功：").append(file2.mkdirs());
            }
            stringBuffer = stringBuffer3.toString();
        } else {
            stringBuffer = null;
        }
        return String.valueOf(stringBuffer) + "/" + substring;
    }

    private static boolean b() {
        return Environment.getExternalStorageState().equals("mounted");
    }
}
