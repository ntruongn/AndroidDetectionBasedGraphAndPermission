package com.feiwoone.banner;

import android.content.Context;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class o implements Runnable {
    private /* synthetic */ k a;
    private final /* synthetic */ com.feiwoone.banner.c.a b;
    private final /* synthetic */ AdBanner c;
    private final /* synthetic */ int d;
    private final /* synthetic */ String e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(k kVar, com.feiwoone.banner.c.a aVar, AdBanner adBanner, int i, String str) {
        this.a = kVar;
        this.b = aVar;
        this.c = adBanner;
        this.d = i;
        this.e = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        k kVar;
        Context context;
        Context context2;
        kVar = k.a;
        synchronized (kVar) {
            context = this.a.b;
            int a = com.feiwoone.banner.f.e.a(context, "ADFEIWO", "list_click", new StringBuilder(String.valueOf(this.b.i())).toString(), 0);
            context2 = this.a.b;
            String sb = new StringBuilder().append(this.b.i()).toString();
            String sb2 = new StringBuilder(String.valueOf(a + 1)).toString();
            JSONObject b = com.feiwoone.banner.f.e.b(context2, "ADFEIWO", "list_click");
            try {
                b.put(sb, sb2);
            } catch (JSONException e) {
                System.out.println(">> error " + e.getMessage());
            }
            com.feiwoone.banner.f.e.b(context2, "ADFEIWO", "list_click", b.toString(), "12345678");
            k.a(this.a, this.c, this.d, this.b, this.e);
        }
    }
}
