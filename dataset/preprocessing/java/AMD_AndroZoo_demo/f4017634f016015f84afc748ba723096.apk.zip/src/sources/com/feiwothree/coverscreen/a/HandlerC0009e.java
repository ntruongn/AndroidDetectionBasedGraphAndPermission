package com.feiwothree.coverscreen.a;

import android.os.Handler;
import android.os.Message;

/* renamed from: com.feiwothree.coverscreen.a.e, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
final class HandlerC0009e extends Handler {
    private final /* synthetic */ InterfaceC0011g a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public HandlerC0009e(C0008d c0008d, InterfaceC0011g interfaceC0011g, String str) {
        this.a = interfaceC0011g;
        this.b = str;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        if (message.obj == null || this.a == null) {
            return;
        }
        InterfaceC0011g interfaceC0011g = this.a;
        Object obj = message.obj;
        String str = this.b;
    }
}
