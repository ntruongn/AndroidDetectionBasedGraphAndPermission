package com.baoyi.audio.adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Toast;
import com.baoyi.adapter.ItemListAdapter;
import com.baoyi.audio.AsyncMusicPlayer;
import com.baoyi.audio.BaoyiApplication;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.RingRecommendItem;
import com.hope.leyuan.R;
import com.iring.entity.RingRecommend;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RingRecommendListAdapter extends ItemListAdapter<RingRecommend> implements AdapterView.OnItemClickListener {
    long time;
    private boolean zoneFlag;

    public RingRecommendListAdapter(Context context) {
        super(context);
    }

    public RingRecommendListAdapter(Context context, boolean zoneFlag) {
        super(context);
        this.zoneFlag = zoneFlag;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        if (arg1 instanceof RingRecommendItem) {
            Animation animation = AnimationUtils.loadAnimation(this.context, R.anim.showanimationitem);
            arg1.setAnimation(animation);
            RingRecommendItem item = (RingRecommendItem) arg1;
            AsyncHttpClient client = new AsyncHttpClient();
            RequestParams params = new RequestParams();
            params.put("id", new StringBuilder(String.valueOf(item.getRingRecommend().getMusicid())).toString());
            client.get("http://iring.wutianxia.com:8999/iringdata/apimusic.php", params, new AsyncHttpResponseHandler() { // from class: com.baoyi.audio.adapter.RingRecommendListAdapter.1
                @Override // com.loopj.android.http.AsyncHttpResponseHandler
                public void onSuccess(String response) {
                    if (response != null) {
                        Log.i("ada", response);
                    }
                }
            });
            String files = String.valueOf(content.SAVEDIR) + item.getRingRecommend().getMusicname() + ".mp3";
            File file = new File(files);
            Intent intent = new Intent(this.context, (Class<?>) AsyncMusicPlayer.class);
            intent.putExtra(UpdateService.NAME, item.getRingRecommend().getMusicname());
            intent.putExtra("fileurl", getMusicUrl(item));
            intent.putExtra("arc", item.getRingRecommend().getMusicname());
            intent.putExtra("musicid", item.getRingRecommend().getMusicid());
            if (file.exists() && file.length() > 1000) {
                this.context.startActivity(intent);
            } else if (BaoyiApplication.getInstance().isonline()) {
                this.context.startActivity(intent);
            } else {
                Toast.makeText(this.context, "请检查你的网络,该铃声不存在", 0).show();
            }
        }
    }

    private String getMusicUrl(RingRecommendItem item) {
        String url = item.getRingRecommend().getMusicpath();
        if (url != null && !url.startsWith("http")) {
            return String.valueOf(content.mp3server) + url;
        }
        return url;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListAdapter
    public View update(int position, View view, RingRecommend item) {
        RingRecommendItem ringRecommendItem = (RingRecommendItem) view;
        ringRecommendItem.setRingRecommend(item);
        ringRecommendItem.setTag(ringRecommendItem);
        return ringRecommendItem;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListAdapter
    public View creatView(int position, RingRecommend item) {
        RingRecommendItem ringRecommendItem = new RingRecommendItem(this.context, item, this.zoneFlag);
        ringRecommendItem.setTag(ringRecommendItem);
        return ringRecommendItem;
    }

    @Override // com.baoyi.adapter.ItemListAdapter
    protected void updateView(int position, View view) {
        int i = position % 2;
    }
}
