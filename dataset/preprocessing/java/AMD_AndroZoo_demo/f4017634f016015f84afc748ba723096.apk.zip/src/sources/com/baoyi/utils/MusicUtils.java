package com.baoyi.utils;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;
import com.baoyi.audio.BaoyiApplication;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.doamin.CheckWork;
import com.hope.leyuan.R;
import java.io.File;
import java.io.IOException;
import java.util.Formatter;
import java.util.Locale;
import org.apache.commons.io.FileUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MusicUtils {
    private static final Object[] sTimeArgs = new Object[5];
    private static StringBuilder sFormatBuilder = new StringBuilder();
    private static Formatter sFormatter = new Formatter(sFormatBuilder, Locale.getDefault());

    public static String makeTimeString(Context context, long secs) {
        String durationformat = context.getString(secs < 3600 ? R.string.durationformatshort : R.string.durationformatlong);
        sFormatBuilder.setLength(0);
        Object[] timeArgs = sTimeArgs;
        timeArgs[0] = Long.valueOf(secs / 3600);
        timeArgs[1] = Long.valueOf(secs / 60);
        timeArgs[2] = Long.valueOf((secs / 60) % 60);
        timeArgs[3] = Long.valueOf(secs);
        timeArgs[4] = Long.valueOf(secs % 60);
        return sFormatter.format(durationformat, timeArgs).toString();
    }

    public static void setring(Context context, File file) {
        File destfile = copytoring(file);
        ContentValues values = new ContentValues();
        if (destfile.exists()) {
            values.put("_data", destfile.getAbsolutePath());
            values.put("title", extname(destfile));
        } else {
            values.put("_data", file.getAbsolutePath());
            values.put("title", extname(destfile));
        }
        values.put("mime_type", "audio/mp3");
        values.put(UpdateService.ARTIST, context.getString(2131165184));
        values.put("is_ringtone", (Boolean) true);
        values.put("is_notification", (Boolean) false);
        values.put("is_alarm", (Boolean) false);
        values.put("is_music", (Boolean) false);
        Uri uri = null;
        try {
            uri = MediaStore.Audio.Media.getContentUriForPath(file.getAbsolutePath());
            String[] selectionArgs = {extname(file)};
            context.getContentResolver().delete(uri, "title=?", selectionArgs);
            Log.i("ada", "清理铃声成功");
        } catch (Exception e) {
            e.printStackTrace();
        }
        Uri newUri = context.getContentResolver().insert(uri, values);
        if (newUri != null) {
            RingtoneManager.setActualDefaultRingtoneUri(context, 1, newUri);
            Toast.makeText(context, "设置手机铃声成功", 0).show();
        } else {
            Toast.makeText(context, "设置铃声失败", 0).show();
        }
    }

    public static void setalarms(Context context, File file) {
        File destfile = copytoalarms(file);
        ContentValues values = new ContentValues();
        if (destfile.exists()) {
            values.put("_data", destfile.getAbsolutePath());
            values.put("title", extname(destfile));
        } else {
            values.put("_data", file.getAbsolutePath());
            values.put("title", extname(destfile));
        }
        values.put("mime_type", "audio/mp3");
        values.put(UpdateService.ARTIST, context.getString(2131165184));
        values.put("is_ringtone", (Boolean) false);
        values.put("is_notification", (Boolean) false);
        values.put("is_alarm", (Boolean) true);
        values.put("is_music", (Boolean) false);
        Uri uri = null;
        try {
            uri = MediaStore.Audio.Media.getContentUriForPath(file.getAbsolutePath());
            String[] selectionArgs = {extname(file)};
            int size = context.getContentResolver().delete(uri, "title=?", selectionArgs);
            Log.i("ada", "清理铃声成功:" + size);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Uri newUri = context.getContentResolver().insert(uri, values);
        if (newUri != null) {
            RingtoneManager.setActualDefaultRingtoneUri(context, 4, newUri);
            Toast.makeText(context, "设置闹钟铃声成功", 0).show();
        } else {
            Toast.makeText(context, "设置铃声失败", 0).show();
        }
    }

    public static void setpodcast(Context context, File file) {
        File destfile = copytoalarms(file);
        ContentValues values = new ContentValues();
        if (destfile.exists()) {
            values.put("_data", destfile.getAbsolutePath());
            values.put("title", extname(destfile));
        } else {
            values.put("_data", file.getAbsolutePath());
            values.put("title", extname(destfile));
        }
        values.put("mime_type", "audio/mp3");
        values.put(UpdateService.ARTIST, context.getString(2131165184));
        values.put("is_ringtone", (Boolean) false);
        values.put("is_notification", (Boolean) false);
        values.put("is_alarm", (Boolean) false);
        values.put("is_music", (Boolean) false);
        values.put("is_podcast", (Boolean) true);
        Uri uri = null;
        try {
            uri = MediaStore.Audio.Media.getContentUriForPath(file.getAbsolutePath());
            String[] selectionArgs = {extname(file)};
            int size = context.getContentResolver().delete(uri, "title=?", selectionArgs);
            Log.i("ada", "清理铃声成功:" + size);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Uri newUri = context.getContentResolver().insert(uri, values);
        if (newUri != null) {
            RingtoneManager.setActualDefaultRingtoneUri(context, 4, newUri);
            Toast.makeText(context, "设置提示铃声成功", 0).show();
        } else {
            Toast.makeText(context, "设置铃声失败", 0).show();
        }
    }

    public static void setnotifications(Context context, File file) {
        File destfile = copytonotifications(file);
        ContentValues values = new ContentValues();
        if (destfile.exists()) {
            values.put("_data", destfile.getAbsolutePath());
            values.put("title", extname(destfile));
        } else {
            values.put("_data", file.getAbsolutePath());
            values.put("title", extname(destfile));
        }
        values.put("mime_type", "audio/mp3");
        values.put(UpdateService.ARTIST, context.getString(2131165184));
        values.put("is_ringtone", (Boolean) false);
        values.put("is_notification", (Boolean) true);
        values.put("is_alarm", (Boolean) false);
        values.put("is_music", (Boolean) false);
        Uri uri = null;
        try {
            uri = MediaStore.Audio.Media.getContentUriForPath(file.getAbsolutePath());
            String[] selectionArgs = {extname(file)};
            context.getContentResolver().delete(uri, "title=?", selectionArgs);
            Log.i("ada", "清理铃声成功");
        } catch (Exception e) {
            e.printStackTrace();
        }
        Uri newUri = context.getContentResolver().insert(uri, values);
        if (newUri != null) {
            RingtoneManager.setActualDefaultRingtoneUri(context, 2, newUri);
            Toast.makeText(context, "设置短信铃声成功", 0).show();
        } else {
            Toast.makeText(context, "设置铃声失败", 0).show();
        }
    }

    public static void setMyRingtone1(Context context, File file, CheckWork check) {
        if (check.isIsalarms()) {
            setalarms(context, file);
        }
        if (check.isIsnotifications()) {
            setnotifications(context, file);
        }
        if (check.isIsringtones()) {
            setring(context, file);
        }
        if (check.isIspodcast()) {
            setpodcast(context, file);
        }
    }

    private static String extname(File destfile) {
        try {
            String name = destfile.getName();
            String result = name.substring(0, name.lastIndexOf("."));
            return result;
        } catch (Exception e) {
            return "";
        }
    }

    public static void setMyRingtone(Context context, File file) {
        File destfile = copytoring(file);
        Uri uri = null;
        if (destfile.exists()) {
            uri = Uri.fromFile(destfile);
        }
        try {
            String path = uri.getPath();
            Log.i("ada", path);
            RingtoneManager.setActualDefaultRingtoneUri(context, 4, uri);
            Ringtone one = RingtoneManager.getRingtone(context, uri);
            one.play();
            Toast.makeText(context, "设置铃声成功", 0).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "设置铃声失败", 0).show();
        }
    }

    public static File copytoring(File file) {
        File destfile = docopy(file, "/media/audio/ringtones/");
        return destfile;
    }

    private static File copytoalarms(File file) {
        File destfile = docopy(file, "/media/audio/alarms/");
        return destfile;
    }

    private static File copytonotifications(File file) {
        File destfile = docopy(file, "/media/audio/notifications");
        return destfile;
    }

    private static File docopy(File file, String dir) {
        String dsr = Environment.getExternalStorageDirectory() + dir;
        File destfile = new File(dsr, file.getName());
        File destDir = new File(dsr);
        if (!destDir.exists()) {
            destDir.mkdirs();
        }
        try {
            FileUtils.copyFileToDirectory(file, destDir);
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return destfile;
    }

    public static void setRingtone(Context context, long id, CheckWork work) {
        ContentResolver resolver = context.getContentResolver();
        String message = "";
        Uri ringUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
        try {
            ContentValues values = new ContentValues(2);
            if (work.isIsalarms()) {
                values.put("is_alarm", "1");
                message = "设置闹钟成功！";
            } else if (work.isIsnotifications()) {
                values.put("is_notification", "1");
                message = "设置短信成功！";
            } else if (work.isIspodcast()) {
                values.put("is_podcast", "1");
                message = "设置提示音成功！";
            } else if (work.isIsringtones()) {
                values.put("is_ringtone", "1");
                message = "设置铃声成功！";
            }
            resolver.update(ringUri, values, null, null);
            String[] cols = {"_id", "_data", "title"};
            String where = "_id=" + id;
            Cursor cursor = query(context, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols, where, null, null);
            if (cursor != null) {
                try {
                    if (cursor.getCount() == 1) {
                        cursor.moveToFirst();
                        if (work.isIsalarms()) {
                            Settings.System.putString(resolver, "alarm_alert", ringUri.toString());
                        } else if (work.isIsnotifications()) {
                            Settings.System.putString(resolver, "notification_sound", ringUri.toString());
                        } else if (work.isIspodcast()) {
                            RingtoneManager.setActualDefaultRingtoneUri(context, 4, ringUri);
                        } else if (work.isIsringtones()) {
                            Settings.System.putString(resolver, "ringtone", ringUri.toString());
                        }
                        Toast.makeText(context, message, 0).show();
                    }
                } finally {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
        } catch (UnsupportedOperationException e) {
            Log.e(BaoyiApplication.TAG, "couldn't set ringtone flag for id " + id);
        }
    }

    public static Cursor query(Context context, Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder, int limit) {
        try {
            ContentResolver resolver = context.getContentResolver();
            if (resolver == null) {
                return null;
            }
            if (limit > 0) {
                uri = uri.buildUpon().appendQueryParameter("limit", new StringBuilder().append(limit).toString()).build();
            }
            return resolver.query(uri, projection, selection, selectionArgs, sortOrder);
        } catch (UnsupportedOperationException e) {
            return null;
        }
    }

    public static Cursor query(Context context, Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return query(context, uri, projection, selection, selectionArgs, sortOrder, 0);
    }
}
