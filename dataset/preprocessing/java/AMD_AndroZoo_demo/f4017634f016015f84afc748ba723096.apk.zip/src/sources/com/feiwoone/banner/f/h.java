package com.feiwoone.banner.f;

import java.net.HttpURLConnection;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class h {
    private static h a;
    private HttpURLConnection b;

    private h() {
    }

    public static final synchronized h a() {
        h hVar;
        synchronized (h.class) {
            if (a == null) {
                a = new h();
            }
            hVar = a;
        }
        return hVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0026 A[Catch: MalformedURLException -> 0x010e, IOException -> 0x0131, TryCatch #3 {MalformedURLException -> 0x010e, IOException -> 0x0131, blocks: (B:3:0x0006, B:5:0x000a, B:6:0x000f, B:8:0x0019, B:10:0x001f, B:12:0x00c6, B:16:0x00d0, B:18:0x00de, B:20:0x00e4, B:24:0x0026, B:25:0x0047, B:27:0x0099, B:28:0x009f, B:47:0x0121, B:48:0x00ff, B:14:0x00fb), top: B:2:0x0006 }] */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0099 A[Catch: MalformedURLException -> 0x010e, IOException -> 0x0131, TryCatch #3 {MalformedURLException -> 0x010e, IOException -> 0x0131, blocks: (B:3:0x0006, B:5:0x000a, B:6:0x000f, B:8:0x0019, B:10:0x001f, B:12:0x00c6, B:16:0x00d0, B:18:0x00de, B:20:0x00e4, B:24:0x0026, B:25:0x0047, B:27:0x0099, B:28:0x009f, B:47:0x0121, B:48:0x00ff, B:14:0x00fb), top: B:2:0x0006 }] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0129 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00b9 A[Catch: IOException -> 0x0144, MalformedURLException -> 0x0146, TRY_LEAVE, TryCatch #4 {MalformedURLException -> 0x0146, IOException -> 0x0144, blocks: (B:40:0x00b4, B:42:0x00b9, B:31:0x0129), top: B:30:0x0129 }] */
    /* JADX WARN: Removed duplicated region for block: B:45:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0121 A[Catch: MalformedURLException -> 0x010e, IOException -> 0x0131, TRY_ENTER, TRY_LEAVE, TryCatch #3 {MalformedURLException -> 0x010e, IOException -> 0x0131, blocks: (B:3:0x0006, B:5:0x000a, B:6:0x000f, B:8:0x0019, B:10:0x001f, B:12:0x00c6, B:16:0x00d0, B:18:0x00de, B:20:0x00e4, B:24:0x0026, B:25:0x0047, B:27:0x0099, B:28:0x009f, B:47:0x0121, B:48:0x00ff, B:14:0x00fb), top: B:2:0x0006 }] */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00ff A[Catch: MalformedURLException -> 0x010e, IOException -> 0x0131, TRY_LEAVE, TryCatch #3 {MalformedURLException -> 0x010e, IOException -> 0x0131, blocks: (B:3:0x0006, B:5:0x000a, B:6:0x000f, B:8:0x0019, B:10:0x001f, B:12:0x00c6, B:16:0x00d0, B:18:0x00de, B:20:0x00e4, B:24:0x0026, B:25:0x0047, B:27:0x0099, B:28:0x009f, B:47:0x0121, B:48:0x00ff, B:14:0x00fb), top: B:2:0x0006 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.String a(android.content.Context r11, java.lang.String r12, java.lang.String r13, java.lang.String r14) {
        /*
            Method dump skipped, instructions count: 328
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.feiwoone.banner.f.h.a(android.content.Context, java.lang.String, java.lang.String, java.lang.String):java.lang.String");
    }
}
