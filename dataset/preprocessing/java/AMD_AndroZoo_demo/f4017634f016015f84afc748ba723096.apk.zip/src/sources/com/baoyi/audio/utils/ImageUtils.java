package com.baoyi.audio.utils;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class ImageUtils {
    public static final int REQUEST_CODE_GETIMAGE_BYCAMERA = 1;
    public static final int REQUEST_CODE_GETIMAGE_BYCROP = 2;
    public static final int REQUEST_CODE_GETIMAGE_BYSDCARD = 0;
    public static final String SDCARD = "/sdcard";
    public static final String SDCARD_MNT = "/mnt/sdcard";

    public static void saveImage(Context context, String fileName, Bitmap bitmap) throws IOException {
        saveImage(context, fileName, bitmap, 100);
    }

    public static void saveImage(Context context, String fileName, Bitmap bitmap, int quality) throws IOException {
        if (bitmap != null) {
            FileOutputStream fos = context.openFileOutput(fileName, 0);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream);
            byte[] bytes = stream.toByteArray();
            fos.write(bytes);
            fos.close();
        }
    }

    public static void saveImageToSD(String filePath, Bitmap bitmap, int quality) throws IOException {
        if (bitmap != null) {
            FileOutputStream fos = new FileOutputStream(filePath);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream);
            byte[] bytes = stream.toByteArray();
            fos.write(bytes);
            fos.close();
        }
    }

    public static Bitmap getBitmap(Context context, String fileName) {
        FileInputStream fis = null;
        Bitmap bitmap = null;
        try {
            try {
                try {
                    fis = context.openFileInput(fileName);
                    bitmap = BitmapFactory.decodeStream(fis);
                    try {
                        fis.close();
                    } catch (Exception e) {
                    }
                } catch (FileNotFoundException e2) {
                    e2.printStackTrace();
                }
            } catch (OutOfMemoryError e3) {
                e3.printStackTrace();
                try {
                    fis.close();
                } catch (Exception e4) {
                }
            }
            return bitmap;
        } finally {
            try {
                fis.close();
            } catch (Exception e5) {
            }
        }
    }

    public static Bitmap getBitmapByPath(String filePath) {
        return getBitmapByPath(filePath, null);
    }

    public static Bitmap getBitmapByPath(String filePath, BitmapFactory.Options opts) {
        FileInputStream fis;
        FileInputStream fis2 = null;
        Bitmap bitmap = null;
        try {
            try {
                File file = new File(filePath);
                fis = new FileInputStream(file);
            } catch (Throwable th) {
                th = th;
            }
        } catch (FileNotFoundException e) {
            e = e;
        } catch (OutOfMemoryError e2) {
            e = e2;
        }
        try {
            bitmap = BitmapFactory.decodeStream(fis, null, opts);
            try {
                fis.close();
                fis2 = fis;
            } catch (Exception e3) {
                fis2 = fis;
            }
        } catch (FileNotFoundException e4) {
            e = e4;
            fis2 = fis;
            e.printStackTrace();
            try {
                fis2.close();
            } catch (Exception e5) {
            }
            return bitmap;
        } catch (OutOfMemoryError e6) {
            e = e6;
            fis2 = fis;
            e.printStackTrace();
            try {
                fis2.close();
            } catch (Exception e7) {
            }
            return bitmap;
        } catch (Throwable th2) {
            th = th2;
            fis2 = fis;
            try {
                fis2.close();
            } catch (Exception e8) {
            }
            throw th;
        }
        return bitmap;
    }

    public static Bitmap getBitmapByFile(File file) {
        FileInputStream fis;
        FileInputStream fis2 = null;
        Bitmap bitmap = null;
        try {
            try {
                fis = new FileInputStream(file);
            } catch (Throwable th) {
                th = th;
            }
        } catch (FileNotFoundException e) {
            e = e;
        } catch (OutOfMemoryError e2) {
            e = e2;
        }
        try {
            bitmap = BitmapFactory.decodeStream(fis);
            try {
                fis.close();
                fis2 = fis;
            } catch (Exception e3) {
                fis2 = fis;
            }
        } catch (FileNotFoundException e4) {
            e = e4;
            fis2 = fis;
            e.printStackTrace();
            try {
                fis2.close();
            } catch (Exception e5) {
            }
            return bitmap;
        } catch (OutOfMemoryError e6) {
            e = e6;
            fis2 = fis;
            e.printStackTrace();
            try {
                fis2.close();
            } catch (Exception e7) {
            }
            return bitmap;
        } catch (Throwable th2) {
            th = th2;
            fis2 = fis;
            try {
                fis2.close();
            } catch (Exception e8) {
            }
            throw th;
        }
        return bitmap;
    }

    public static String getTempFileName() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss_SS");
        String fileName = format.format((Date) new Timestamp(System.currentTimeMillis()));
        return fileName;
    }

    public static String getCamerPath() {
        return Environment.getExternalStorageDirectory() + File.separator + "FounderNews" + File.separator;
    }

    public static String getAbsolutePathFromNoStandardUri(Uri mUri) {
        String mUriString = Uri.decode(mUri.toString());
        String pre1 = "file:///sdcard" + File.separator;
        String pre2 = "file:///mnt/sdcard" + File.separator;
        if (mUriString.startsWith(pre1)) {
            String filePath = String.valueOf(Environment.getExternalStorageDirectory().getPath()) + File.separator + mUriString.substring(pre1.length());
            return filePath;
        }
        if (!mUriString.startsWith(pre2)) {
            return null;
        }
        String filePath2 = String.valueOf(Environment.getExternalStorageDirectory().getPath()) + File.separator + mUriString.substring(pre2.length());
        return filePath2;
    }

    public static String getAbsoluteImagePath(Activity context, Uri uri) {
        String[] proj = {"_data"};
        Cursor cursor = context.managedQuery(uri, proj, null, null, null);
        if (cursor == null) {
            return "";
        }
        int column_index = cursor.getColumnIndexOrThrow("_data");
        if (cursor.getCount() <= 0 || !cursor.moveToFirst()) {
            return "";
        }
        String imagePath = cursor.getString(column_index);
        return imagePath;
    }

    public static Bitmap loadImgThumbnail(Activity context, String imgName, int kind) {
        String[] proj = {"_id", "_display_name"};
        Cursor cursor = context.managedQuery(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, "_display_name='" + imgName + "'", null, null);
        if (cursor == null || cursor.getCount() <= 0 || !cursor.moveToFirst()) {
            return null;
        }
        ContentResolver crThumb = context.getContentResolver();
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 1;
        Bitmap bitmap = MethodsCompat.getThumbnail(crThumb, cursor.getInt(0), kind, options);
        return bitmap;
    }

    public static Bitmap loadImgThumbnail(String filePath, int w, int h) {
        Bitmap bitmap = getBitmapByPath(filePath);
        return zoomBitmap(bitmap, w, h);
    }

    public static String getLatestImage(Activity context) {
        String[] items = {"_id", "_data"};
        Cursor cursor = context.managedQuery(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, items, null, null, "_id desc");
        if (cursor == null || cursor.getCount() <= 0) {
            return null;
        }
        cursor.moveToFirst();
        cursor.moveToFirst();
        if (cursor.isAfterLast()) {
            return null;
        }
        String latestImage = cursor.getString(1);
        return latestImage;
    }

    public static int[] scaleImageSize(int[] img_size, int square_size) {
        if (img_size[0] > square_size || img_size[1] > square_size) {
            double ratio = square_size / Math.max(img_size[0], img_size[1]);
            return new int[]{(int) (img_size[0] * ratio), (int) (img_size[1] * ratio)};
        }
        return img_size;
    }

    public static void createImageThumbnail(Context context, String largeImagePath, String thumbfilePath, int square_size, int quality) throws IOException {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = 1;
        Bitmap cur_bitmap = getBitmapByPath(largeImagePath, opts);
        if (cur_bitmap != null) {
            int[] cur_img_size = {cur_bitmap.getWidth(), cur_bitmap.getHeight()};
            int[] new_img_size = scaleImageSize(cur_img_size, square_size);
            Bitmap thb_bitmap = zoomBitmap(cur_bitmap, new_img_size[0], new_img_size[1]);
            saveImageToSD(thumbfilePath, thb_bitmap, quality);
        }
    }

    public static Bitmap zoomBitmap(Bitmap bitmap, int w, int h) {
        if (bitmap == null) {
            return null;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Matrix matrix = new Matrix();
        float scaleWidht = w / width;
        float scaleHeight = h / height;
        matrix.postScale(scaleWidht, scaleHeight);
        Bitmap newbmp = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
        return newbmp;
    }

    public static Bitmap scaleBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float scaleWidth = ((float) PullToRefreshBase.SMOOTH_SCROLL_DURATION_MS) / width;
        float scaleHeight = ((float) PullToRefreshBase.SMOOTH_SCROLL_DURATION_MS) / height;
        Matrix matrix = new Matrix();
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
        return resizedBitmap;
    }

    public static Bitmap reDrawBitMap(Activity context, Bitmap bitmap) {
        float zoomScale;
        DisplayMetrics dm = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(dm);
        int i = dm.heightPixels;
        int rWidth = dm.widthPixels;
        bitmap.getHeight();
        int width = bitmap.getWidth();
        if (width >= rWidth) {
            zoomScale = rWidth / width;
        } else {
            zoomScale = 1.0f;
        }
        Matrix matrix = new Matrix();
        matrix.postScale(zoomScale, zoomScale);
        Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        return resizedBitmap;
    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        int width = drawable.getIntrinsicWidth();
        int height = drawable.getIntrinsicHeight();
        Bitmap bitmap = Bitmap.createBitmap(width, height, drawable.getOpacity() != -1 ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, width, height);
        drawable.draw(canvas);
        return bitmap;
    }

    public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, float roundPx) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Paint paint = new Paint();
        Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        RectF rectF = new RectF(rect);
        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(-12434878);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }

    public static Bitmap createReflectionImageWithOrigin(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Matrix matrix = new Matrix();
        matrix.preScale(1.0f, -1.0f);
        Bitmap reflectionImage = Bitmap.createBitmap(bitmap, 0, height / 2, width, height / 2, matrix, false);
        Bitmap bitmapWithReflection = Bitmap.createBitmap(width, (height / 2) + height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapWithReflection);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, (Paint) null);
        Paint deafalutPaint = new Paint();
        canvas.drawRect(0.0f, height, width, height + 4, deafalutPaint);
        canvas.drawBitmap(reflectionImage, 0.0f, height + 4, (Paint) null);
        Paint paint = new Paint();
        LinearGradient shader = new LinearGradient(0.0f, bitmap.getHeight(), 0.0f, bitmapWithReflection.getHeight() + 4, 1895825407, 16777215, Shader.TileMode.CLAMP);
        paint.setShader(shader);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        canvas.drawRect(0.0f, height, width, bitmapWithReflection.getHeight() + 4, paint);
        return bitmapWithReflection;
    }

    public static Drawable bitmapToDrawable(Bitmap bitmap) {
        Drawable drawable = new BitmapDrawable(bitmap);
        return drawable;
    }

    public static String getImageType(File file) {
        InputStream in;
        String str = null;
        if (file != null && file.exists()) {
            InputStream in2 = null;
            try {
                in = new FileInputStream(file);
            } catch (IOException e) {
            } catch (Throwable th) {
                th = th;
            }
            try {
                str = getImageType(in);
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e2) {
                    }
                }
            } catch (IOException e3) {
                in2 = in;
                if (in2 != null) {
                    try {
                        in2.close();
                    } catch (IOException e4) {
                    }
                }
                return str;
            } catch (Throwable th2) {
                th = th2;
                in2 = in;
                if (in2 != null) {
                    try {
                        in2.close();
                    } catch (IOException e5) {
                    }
                }
                throw th;
            }
        }
        return str;
    }

    public static String getImageType(InputStream in) {
        if (in == null) {
            return null;
        }
        try {
            byte[] bytes = new byte[8];
            in.read(bytes);
            return getImageType(bytes);
        } catch (IOException e) {
            return null;
        }
    }

    public static String getImageType(byte[] bytes) {
        if (isJPEG(bytes)) {
            return "image/jpeg";
        }
        if (isGIF(bytes)) {
            return "image/gif";
        }
        if (isPNG(bytes)) {
            return "image/png";
        }
        if (isBMP(bytes)) {
            return "application/x-bmp";
        }
        return null;
    }

    private static boolean isJPEG(byte[] b) {
        return b.length >= 2 && b[0] == -1 && b[1] == -40;
    }

    private static boolean isGIF(byte[] b) {
        if (b.length >= 6 && b[0] == 71 && b[1] == 73 && b[2] == 70 && b[3] == 56) {
            return (b[4] == 55 || b[4] == 57) && b[5] == 97;
        }
        return false;
    }

    private static boolean isPNG(byte[] b) {
        return b.length >= 8 && b[0] == -119 && b[1] == 80 && b[2] == 78 && b[3] == 71 && b[4] == 13 && b[5] == 10 && b[6] == 26 && b[7] == 10;
    }

    private static boolean isBMP(byte[] b) {
        return b.length >= 2 && b[0] == 66 && b[1] == 77;
    }
}
