package com.feiwothree.coverscreen.a;

/* renamed from: com.feiwothree.coverscreen.a.b, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class C0006b {
    private static final String a = k.a("H8Zno4EBTQx9HFCC0rcAQqd931fYhjBLaFEZBiEdBCo=", k.a("123456"));

    public static String a() {
        return String.valueOf(a) + "/webviewAdClick";
    }

    public static String b() {
        return String.valueOf(a) + "/showCount";
    }

    public static String c() {
        return String.valueOf(a) + "/clientinfo";
    }

    public static String d() {
        return String.valueOf(a) + "/installCount";
    }

    public static String e() {
        return String.valueOf(a) + "/getCoverScreenAdList";
    }
}
