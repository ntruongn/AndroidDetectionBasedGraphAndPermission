package com.baoyi.utils;

import android.util.Log;
import com.baoyi.audio.BaoyiApplication;
import com.baoyi.audio.utils.content;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.WeakHashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class DiskTextCache extends WeakHashMap<String, String> {
    private static final String charset = "utf-8";
    private static final long time = 900000;

    @Override // java.util.WeakHashMap, java.util.AbstractMap, java.util.Map
    public String get(Object key) {
        String pic = key.toString();
        String filess = Utils.getMD5Str(pic);
        File fileitem = new File(String.valueOf(content.SAVEDIR) + filess + ".txt");
        String image = null;
        if (!fileitem.exists()) {
            Log.d(BaoyiApplication.TAG, "缓存中没有图片");
        } else {
            try {
                FileInputStream inputStream = new FileInputStream(fileitem);
                ByteBuffer buffers = DataUtil.readToByteBuffer(inputStream);
                if (charset == 0) {
                    image = Charset.forName("UTF-8").decode(buffers).toString();
                } else {
                    image = Charset.forName(charset).decode(buffers).toString();
                }
                buffers.rewind();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return image;
    }

    public String putOverride(String key, String value) {
        String filess = Utils.getMD5Str(key);
        File fileitem = new File(String.valueOf(content.SAVEDIR) + filess + ".txt");
        if (key.startsWith("http")) {
            downfiles(key, value, fileitem);
        } else {
            writeText(value, fileitem);
        }
        return value;
    }

    @Override // java.util.WeakHashMap, java.util.AbstractMap, java.util.Map
    public String put(String key, String value) {
        String filess = Utils.getMD5Str(key);
        File fileitem = new File(String.valueOf(content.SAVEDIR) + filess + ".txt");
        long times = System.currentTimeMillis() - fileitem.lastModified();
        if (fileitem.exists() && fileitem.length() > 20) {
            Log.d(BaoyiApplication.TAG, "磁盘中存在该文件");
            if (times > time) {
                writeText(value, fileitem);
            }
        } else if (key.startsWith("http")) {
            downfiles(key, value, fileitem);
        } else {
            writeText(value, fileitem);
        }
        return value;
    }

    private void writeText(String value, File fileitem) {
        FileOutputStream output = null;
        OutputStreamWriter os = null;
        try {
            try {
                FileOutputStream output2 = new FileOutputStream(fileitem);
                try {
                    OutputStreamWriter os2 = new OutputStreamWriter(output2, "UTF-8");
                    try {
                        os2.write(value);
                        if (os2 != null) {
                            try {
                                os2.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        if (output2 != null) {
                            try {
                                output2.close();
                            } catch (IOException e2) {
                                e2.printStackTrace();
                            }
                        }
                    } catch (Exception e3) {
                        e = e3;
                        os = os2;
                        output = output2;
                        e.printStackTrace();
                        if (os != null) {
                            try {
                                os.close();
                            } catch (IOException e4) {
                                e4.printStackTrace();
                            }
                        }
                        if (output != null) {
                            try {
                                output.close();
                            } catch (IOException e5) {
                                e5.printStackTrace();
                            }
                        }
                    } catch (Throwable th) {
                        th = th;
                        os = os2;
                        output = output2;
                        if (os != null) {
                            try {
                                os.close();
                            } catch (IOException e6) {
                                e6.printStackTrace();
                            }
                        }
                        if (output != null) {
                            try {
                                output.close();
                            } catch (IOException e7) {
                                e7.printStackTrace();
                            }
                        }
                        throw th;
                    }
                } catch (Exception e8) {
                    e = e8;
                    output = output2;
                } catch (Throwable th2) {
                    th = th2;
                    output = output2;
                }
            } catch (Exception e9) {
                e = e9;
            }
        } catch (Throwable th3) {
            th = th3;
        }
    }

    public static void writeByFileOutputStream(String _sDestFile, String _sContent) throws IOException {
        FileOutputStream fos;
        FileOutputStream fos2 = null;
        try {
            try {
                fos = new FileOutputStream(_sDestFile);
            } catch (Exception e) {
                ex = e;
            }
        } catch (Throwable th) {
            th = th;
        }
        try {
            fos.write(_sContent.getBytes());
            if (fos != null) {
                fos.close();
            }
        } catch (Exception e2) {
            ex = e2;
            fos2 = fos;
            ex.printStackTrace();
            if (fos2 != null) {
                fos2.close();
            }
        } catch (Throwable th2) {
            th = th2;
            fos2 = fos;
            if (fos2 != null) {
                fos2.close();
            }
            throw th;
        }
    }

    public static void writeByOutputStreamWrite(String _sDestFile, String _sContent) throws IOException {
        OutputStreamWriter os = null;
        FileOutputStream fos = null;
        try {
            try {
                FileOutputStream fos2 = new FileOutputStream(_sDestFile);
                try {
                    OutputStreamWriter os2 = new OutputStreamWriter(fos2, "UTF-8");
                    try {
                        os2.write(_sContent);
                        if (os2 != null) {
                            os2.close();
                        }
                        if (fos2 != null) {
                            fos2.close();
                        }
                    } catch (Exception e) {
                        ex = e;
                        fos = fos2;
                        os = os2;
                        ex.printStackTrace();
                        if (os != null) {
                            os.close();
                        }
                        if (fos != null) {
                            fos.close();
                        }
                    } catch (Throwable th) {
                        th = th;
                        fos = fos2;
                        os = os2;
                        if (os != null) {
                            os.close();
                        }
                        if (fos != null) {
                            fos.close();
                        }
                        throw th;
                    }
                } catch (Exception e2) {
                    ex = e2;
                    fos = fos2;
                } catch (Throwable th2) {
                    th = th2;
                    fos = fos2;
                }
            } catch (Exception e3) {
                ex = e3;
            }
        } catch (Throwable th3) {
            th = th3;
        }
    }

    private void downfiles(String key, String value, File fileitem) {
        Log.d(BaoyiApplication.TAG, "网络图片" + key);
        Log.d(BaoyiApplication.TAG, "缓存文件到磁盘");
        try {
            URL url = new URL(key);
            URLConnection conn = url.openConnection();
            conn.setDoInput(true);
            int length = conn.getContentLength();
            InputStream is = conn.getInputStream();
            if (length != -1) {
                FileOutputStream output = new FileOutputStream(fileitem);
                byte[] buffer = new byte[6144];
                while (true) {
                    int temp1 = is.read(buffer);
                    if (temp1 != -1) {
                        output.write(buffer, 0, temp1);
                    } else {
                        output.flush();
                        return;
                    }
                }
            }
        } catch (MalformedURLException e) {
            super.put((DiskTextCache) key, value);
        } catch (IOException e2) {
            super.put((DiskTextCache) key, value);
        }
    }
}
