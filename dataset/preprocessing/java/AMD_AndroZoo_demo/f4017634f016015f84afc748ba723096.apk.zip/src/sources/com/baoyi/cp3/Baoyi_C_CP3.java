package com.baoyi.cp3;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Baoyi_C_CP3 {
    protected static final int CP_DIALOG = 2;
    public static final int CP_WINDOW_FULL = 0;
    public static final int CP_WINDOW_NOT_FULL = 1;
    private static Baoyi_C_CP3 vgCpManager = null;
    private a g;

    public static Baoyi_C_CP3 getInitCp3(Context ctx, String vid, String chlId) {
        if (vgCpManager == null) {
            vgCpManager = new Baoyi_C_CP3(ctx, vid, chlId);
        }
        return vgCpManager;
    }

    private Baoyi_C_CP3(Context ctx, String vid, String chlId) {
        this.g = a.a(ctx, vid, chlId);
    }

    public void showcp3(int x, int y, Object callback, int mode) {
        this.g.a(x, y, callback, mode);
    }
}
