package com.baoyi.audio;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.widget.Toast;
import com.baidu.mobstat.StatService;
import com.baoyi.audio.dialog.VolumeDialog;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.utils.content;
import com.hope.leyuan.R;
import java.io.File;
import java.io.FilenameFilter;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class AnalyticsFrameUI extends FragmentActivity {
    public static final int Alarm = 1;
    public static final int Notification = 2;
    public static final int Ringtone = 0;

    public int getUserid() {
        SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
        return sharedPreferences.getInt(UpdateService.USERID, -1);
    }

    public String getbigpic() {
        SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
        return sharedPreferences.getString("bigpic", "");
    }

    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String str = "/" + BaoyiApplication.getInstance().getVersion();
        overridePendingTransition(R.anim.iphonesms_smsdetail_new_enter, R.anim.iphonesms_smsdetail_new_exit);
        Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler(this));
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.anzhimenu, menu);
        super.onCreateOptionsMenu(menu);
        return true;
    }

    public String getMemberpicture() {
        SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
        return sharedPreferences.getString("memberpicture", "/iringdata/images/mnopig.gif");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String getminipicture() {
        SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
        return sharedPreferences.getString("minipic", "/iringdata/images/mnopig.gif");
    }

    public String getMemberName() {
        SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
        return sharedPreferences.getString(UpdateService.NAME, "游客");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        StatService.onResume((Context) this);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onPause() {
        super.onPause();
        StatService.onPause((Context) this);
    }

    @Override // android.app.Activity
    protected void onRestart() {
        super.onRestart();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onStart() {
        super.onStart();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onStop() {
        super.onStop();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    protected void rateApplication() {
        Intent rateIntent = new Intent("android.intent.action.VIEW");
        rateIntent.setData(Uri.parse("market://details?id=" + getPackageName()));
        startActivity(rateIntent);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0008, code lost:
    
        return true;
     */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onOptionsItemSelected(android.view.MenuItem r3) {
        /*
            r2 = this;
            r1 = 1
            int r0 = r3.getItemId()
            switch(r0) {
                case 2131296354: goto L1d;
                case 2131296519: goto L19;
                case 2131296520: goto Ld;
                case 2131296521: goto L11;
                case 2131296522: goto L15;
                case 2131296523: goto L2d;
                case 2131296524: goto L29;
                case 2131296525: goto L25;
                case 2131296526: goto L9;
                case 2131296527: goto L21;
                default: goto L8;
            }
        L8:
            return r1
        L9:
            r2.showandroidmarket()
            goto L8
        Ld:
            r2.showphone()
            goto L8
        L11:
            r2.showalert()
            goto L8
        L15:
            r2.shownotice()
            goto L8
        L19:
            r2.rateApplication()
            goto L8
        L1d:
            r2.showsetting()
            goto L8
        L21:
            r2.showabout()
            goto L8
        L25:
            r2.openMsg()
            goto L8
        L29:
            r2.clearcache()
            goto L8
        L2d:
            r2.showcontrol()
            goto L8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.baoyi.audio.AnalyticsFrameUI.onOptionsItemSelected(android.view.MenuItem):boolean");
    }

    private void showandroidmarket() {
        Uri url = Uri.parse("http://m.sc.hiapk.com/himarket?srcCode=80031&clientType=81002");
        Intent intent = new Intent("android.intent.action.VIEW", url);
        startActivityForResult(intent, 55555);
    }

    protected void clearwords() {
    }

    protected void clearcache() {
        new ClearCacheTask(this).execute(new Integer[0]);
    }

    protected void openMsg() {
        Intent sendIntent = new Intent("android.intent.action.SEND");
        sendIntent.putExtra("android.intent.extra.EMAIL", new String[]{"735529126@qq.com"});
        sendIntent.putExtra("android.intent.extra.TEXT", "");
        sendIntent.putExtra("android.intent.extra.SUBJECT", String.valueOf(getString(2131165184)) + " 信息反馈");
        sendIntent.setType("message/rfc822");
        startActivity(sendIntent);
    }

    protected void showabout() {
        Intent intent = new Intent(this, (Class<?>) About.class);
        intent.setAction("android.intent.action.GET_CONTENT");
        startActivity(intent);
    }

    protected void showsetting() {
        Intent intent = new Intent(this, (Class<?>) SettingsActivity.class);
        intent.setAction("android.intent.action.GET_CONTENT");
        startActivity(intent);
    }

    protected void shownotice() {
        Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
        intent.putExtra("android.intent.extra.ringtone.TYPE", 2);
        Uri ringtoneUri = RingtoneManager.getActualDefaultRingtoneUri(this, 2);
        intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", ringtoneUri);
        intent.putExtra("android.intent.extra.ringtone.TITLE", "设置通知铃声");
        startActivityForResult(intent, 2);
    }

    protected void showalert() {
        Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
        intent.putExtra("android.intent.extra.ringtone.TYPE", 4);
        Uri ringtoneUri = RingtoneManager.getActualDefaultRingtoneUri(this, 4);
        intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", ringtoneUri);
        intent.putExtra("android.intent.extra.ringtone.TITLE", "设置闹钟铃声");
        startActivityForResult(intent, 1);
    }

    protected void showcontrol() {
        VolumeDialog v = new VolumeDialog(this);
        v.show();
    }

    protected void showphone() {
        Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
        intent.putExtra("android.intent.extra.ringtone.TYPE", 1);
        intent.putExtra("android.intent.extra.ringtone.TITLE", "设置来电铃声");
        Uri ringtoneUri = RingtoneManager.getActualDefaultRingtoneUri(this, 1);
        intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", ringtoneUri);
        startActivityForResult(intent, 0);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Uri uri;
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == -1 && (uri = (Uri) data.getParcelableExtra("android.intent.extra.ringtone.PICKED_URI")) != null) {
            switch (requestCode) {
                case 0:
                    RingtoneManager.setActualDefaultRingtoneUri(this, 1, uri);
                    return;
                case 1:
                    RingtoneManager.setActualDefaultRingtoneUri(this, 4, uri);
                    return;
                case 2:
                    RingtoneManager.setActualDefaultRingtoneUri(this, 2, uri);
                    return;
                default:
                    return;
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class ClearCacheTask extends AsyncTask<Integer, String, Void> {
        Context curcontext;
        private ProgressDialog progressDialog = null;

        public ClearCacheTask(Context context) {
            this.curcontext = context;
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            this.progressDialog = ProgressDialog.show(this.curcontext, "清理缓存", "正在清理缓存,请稍候！", true, true);
            super.onPreExecute();
        }

        @Override // android.os.AsyncTask
        public void onPostExecute(Void url) {
            super.onPostExecute((ClearCacheTask) url);
            Toast.makeText(this.curcontext, "清理缓存成功", 0).show();
            this.progressDialog.dismiss();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... aa) {
            this.progressDialog.setMessage("正在清理:" + aa[0]);
        }

        @Override // android.os.AsyncTask
        public Void doInBackground(Integer... params) {
            try {
                File file = new File(content.SAVEDIR);
                File[] fs = file.listFiles(new FilenameFilter() { // from class: com.baoyi.audio.AnalyticsFrameUI.ClearCacheTask.1
                    @Override // java.io.FilenameFilter
                    public boolean accept(File dir, String filename) {
                        return filename.endsWith(".txt");
                    }
                });
                if (fs != null) {
                    for (File item : fs) {
                        publishProgress(item.getName());
                        item.delete();
                    }
                    return null;
                }
                return null;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }
}
