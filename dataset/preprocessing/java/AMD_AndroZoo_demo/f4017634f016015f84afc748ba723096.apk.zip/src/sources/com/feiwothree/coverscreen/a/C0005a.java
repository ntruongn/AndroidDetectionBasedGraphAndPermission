package com.feiwothree.coverscreen.a;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.feiwothree.coverscreen.a.a, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class C0005a {
    private int a;
    private String b;
    private String c;
    private String d;
    private String e;

    public C0005a() {
    }

    public C0005a(int i, String str, String str2, String str3, String str4) {
        this.a = i;
        this.b = str;
        this.c = str2;
        this.d = str3;
        this.e = str4;
    }

    public static JSONObject a(Context context, double d, double d2, String str, int i, String str2, String str3) {
        String a = B.a(context);
        String c = C0007c.a(context).c();
        String d3 = C0007c.a(context).d();
        String b = C0007c.a(context).b();
        String a2 = C0007c.a(context).a();
        String c2 = B.c(context);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("devid", a);
            jSONObject.put("adid", str2);
            jSONObject.put("appkey", str);
            jSONObject.put("type", 0);
            jSONObject.put("lat", 0.0d);
            jSONObject.put("lon", 0.0d);
            jSONObject.put("cellid", c);
            jSONObject.put("lac", d3);
            jSONObject.put("mcc", a2);
            jSONObject.put("mnc", b);
            jSONObject.put("wifi", c2);
            jSONObject.put("url", str3);
            jSONObject.put("adsdkversion", "1.9");
            jSONObject.put("sdktype", "COVERSCREEN");
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public static JSONObject a(Context context, int i) {
        String a = B.a(context);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("devid", a);
            jSONObject.put("adid", i);
            jSONObject.put("adsdkversion", "1.9");
            jSONObject.put("sdktype", "COVERSCREEN");
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public static JSONObject a(Context context, String str) {
        String a = B.a(context);
        String b = C0007c.a(context).b();
        String a2 = B.a();
        H d = B.d(context);
        A.a();
        boolean a3 = A.a(context, "com.tencent.mm");
        int b2 = C0013i.b(context);
        String str2 = String.valueOf(v.c().a()) + ":" + v.c().b();
        String c = C0007c.a(context).c();
        String d2 = C0007c.a(context).d();
        String str3 = (J.a(c) || J.a(d2)) ? "" : String.valueOf(c) + ":" + d2;
        String c2 = B.c(context);
        String b3 = B.b();
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("adsdkversion", str);
            jSONObject.put("devid", a);
            jSONObject.put("brand", a2);
            jSONObject.put("model", b3);
            jSONObject.put("latlon", str2);
            jSONObject.put("cidlac", str3);
            jSONObject.put("wifi", c2);
            jSONObject.put("mnc", b);
            jSONObject.put("width", d.a);
            jSONObject.put("weixinflag", a3);
            jSONObject.put("networktype", b2);
            jSONObject.put("sdktype", "COVERSCREEN");
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public static JSONObject a(Context context, String str, String str2) {
        JSONObject jSONObject = new JSONObject();
        String a = B.a(context);
        String b = B.b();
        A.a();
        String a2 = A.a(context, false);
        String str3 = String.valueOf(B.d(context).a) + "*" + B.d(context).b;
        String a3 = B.a();
        String d = B.d();
        String c = B.c();
        String c2 = C0007c.a(context).c();
        String b2 = C0007c.a(context).b();
        String e = C0007c.a(context).e();
        H d2 = B.d(context);
        String str4 = String.valueOf(d2.a) + "*" + d2.b;
        String b3 = B.b(context);
        String c3 = B.c(context);
        try {
            jSONObject.put("devid", a);
            jSONObject.put("model", b);
            jSONObject.put("packagenames", a2);
            jSONObject.put("resolution", str3);
            jSONObject.put("brand", a3);
            jSONObject.put("versionrelease", d);
            jSONObject.put("versioncode", c);
            jSONObject.put("appkey", str);
            jSONObject.put("adsdkversion", str2);
            jSONObject.put("sdktype", "COVERSCREEN");
            jSONObject.put("wifi", c3);
            jSONObject.put("call_id", c2);
            jSONObject.put("mac", b3);
            jSONObject.put("screen_size", str4);
            jSONObject.put("mobile_num", e);
            jSONObject.put("mnc", b2);
        } catch (JSONException e2) {
        }
        return jSONObject;
    }

    public static JSONObject a(Context context, String str, JSONArray jSONArray) {
        String a = B.a(context);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("adsdkversion", str);
            jSONObject.put("devid", a);
            jSONObject.put("installCount", jSONArray);
            jSONObject.put("sdktype", "COVERSCREEN");
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public String a() {
        return this.b;
    }

    public String b() {
        return this.c;
    }

    public String c() {
        return this.d;
    }

    public String d() {
        return this.e;
    }

    public int e() {
        return this.a;
    }
}
