package com.baoyi.audio.fragment;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.baoyi.audio.adapter.RingRecommendListAdapter;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.dao.RingRecommendDao;
import com.iring.entity.RingRecommend;
import com.iring.rpc.RingRecommendRpc;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RingRecommendFragment extends Fragment {
    RingRecommendListAdapter adapter;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    private int newid;
    int type;
    private boolean work = false;
    int page = 0;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.page = 0;
        this.type = 1;
        this.mPullRefreshListView = (PullToRefreshListView) getView().findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() { // from class: com.baoyi.audio.fragment.RingRecommendFragment.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                new NewTask(RingRecommendFragment.this, null).execute(new Integer[0]);
            }

            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                new HotTask(RingRecommendFragment.this, null).execute(Integer.valueOf(RingRecommendFragment.this.page));
            }
        });
        WidgetLoadling tv = new WidgetLoadling(getActivity());
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new RingRecommendListAdapter(getActivity());
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setBackgroundColor(17170445);
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("com.iym.iRingRecommend_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(getActivity());
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
        new HotTask(this, null).execute(Integer.valueOf(this.page));
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<RingRecommend>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(RingRecommendFragment ringRecommendFragment, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<RingRecommend> doInBackground(Integer... params) {
            RingRecommendRpc rpc;
            long time = System.currentTimeMillis();
            RingRecommendFragment.this.work = true;
            List<RingRecommend> data = null;
            RingRecommendDao dao = (RingRecommendDao) RpcUtils2.getNoCacheDao("ringRecommendDao", RingRecommendDao.class);
            if (dao != null && (rpc = dao.pageTop(4, 20, RingRecommendFragment.this.page)) != null) {
                data = rpc.getDatas();
            }
            if (System.currentTimeMillis() - time < 1000) {
                try {
                    Thread.sleep(1500L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return data;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<RingRecommend> result) {
            RingRecommendFragment.this.work = false;
            RingRecommendFragment.this.mPullRefreshListView.onRefreshComplete();
            if (result != null) {
                RingRecommendFragment.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.BOTH);
                for (RingRecommend RingRecommend : result) {
                    RingRecommendFragment.this.adapter.addLast(RingRecommend);
                }
                RingRecommendFragment.this.adapter.notifyDataSetChanged();
                RingRecommendFragment.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + RingRecommendFragment.this.adapter.getCount() + "条数据");
                RingRecommendFragment.this.page++;
            } else if (RingRecommendFragment.this.page == 0) {
                RingRecommendFragment.this.mPullRefreshListView.setEmptyView(null);
                Toast.makeText(RingRecommendFragment.this.getActivity(), "获取数据失败，请稍候再试。", 0).show();
            }
            if (RingRecommendFragment.this.adapter.getCount() > 0) {
                RingRecommendFragment.this.newid = RingRecommendFragment.this.adapter.getFirst().getId();
                Log.i("ada", "id:" + RingRecommendFragment.this.newid);
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class NewTask extends AsyncTask<Integer, Void, List<RingRecommend>> {
        private NewTask() {
        }

        /* synthetic */ NewTask(RingRecommendFragment ringRecommendFragment, NewTask newTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<RingRecommend> doInBackground(Integer... params) {
            RingRecommendRpc rpc;
            long time = System.currentTimeMillis();
            RingRecommendFragment.this.work = true;
            List<RingRecommend> data = null;
            RingRecommendDao dao = (RingRecommendDao) RpcUtils2.getNoCacheDao("ringRecommendDao", RingRecommendDao.class);
            if (dao != null && RingRecommendFragment.this.newid > 10 && (rpc = dao.pageNew(4, RingRecommendFragment.this.newid, 20, 0)) != null) {
                data = rpc.getDatas();
            }
            if (System.currentTimeMillis() - time < 1000) {
                try {
                    Thread.sleep(1500L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return data;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<RingRecommend> result) {
            RingRecommendFragment.this.work = false;
            RingRecommendFragment.this.mPullRefreshListView.onRefreshComplete();
            if (result != null) {
                for (RingRecommend RingRecommend : result) {
                    RingRecommendFragment.this.adapter.addFirst(RingRecommend);
                }
                RingRecommendFragment.this.adapter.notifyDataSetChanged();
                RingRecommendFragment.this.mPullRefreshListView.onRefreshComplete();
                RingRecommendFragment.this.page++;
                RingRecommendFragment.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + RingRecommendFragment.this.adapter.getCount() + "条数据");
            }
            if (RingRecommendFragment.this.adapter.getCount() > 0) {
                RingRecommendFragment.this.newid = RingRecommendFragment.this.adapter.getFirst().getId();
                Log.i("ada", "id:" + RingRecommendFragment.this.newid);
            }
        }
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_new, container, false);
        return view;
    }
}
