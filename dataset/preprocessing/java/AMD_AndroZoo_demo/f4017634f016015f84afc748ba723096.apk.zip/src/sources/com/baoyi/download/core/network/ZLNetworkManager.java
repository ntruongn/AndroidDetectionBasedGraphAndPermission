package com.baoyi.download.core.network;

import com.baoyi.download.core.util.ZLMiscUtil;
import com.baoyi.download.core.util.ZLNetworkUtil;
import com.iflytek.speech.SpeechError;
import com.webimageloader.Constants;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class ZLNetworkManager {
    private static ZLNetworkManager ourManager;
    private final CookieStore myCookieStore = new CookieStore() { // from class: com.baoyi.download.core.network.ZLNetworkManager.1
        private HashMap<Key, Cookie> myCookies;

        @Override // org.apache.http.client.CookieStore
        public synchronized void addCookie(Cookie cookie) {
            if (this.myCookies == null) {
                getCookies();
            }
            this.myCookies.put(new Key(cookie), cookie);
            CookieDatabase db = CookieDatabase.getInstance();
            if (db != null) {
                db.saveCookies(Collections.singletonList(cookie));
            }
        }

        @Override // org.apache.http.client.CookieStore
        public synchronized void clear() {
            CookieDatabase db = CookieDatabase.getInstance();
            if (db != null) {
                db.removeAll();
            }
            if (this.myCookies != null) {
                this.myCookies.clear();
            }
        }

        @Override // org.apache.http.client.CookieStore
        public synchronized boolean clearExpired(Date date) {
            boolean z;
            this.myCookies = null;
            CookieDatabase db = CookieDatabase.getInstance();
            if (db != null) {
                db.removeObsolete(date);
                z = true;
            } else {
                z = false;
            }
            return z;
        }

        @Override // org.apache.http.client.CookieStore
        public synchronized List<Cookie> getCookies() {
            if (this.myCookies == null) {
                this.myCookies = new HashMap<>();
                CookieDatabase db = CookieDatabase.getInstance();
                if (db != null) {
                    for (Cookie c : db.loadCookies()) {
                        this.myCookies.put(new Key(c), c);
                    }
                }
            }
            return new ArrayList(this.myCookies.values());
        }
    };

    public static ZLNetworkManager Instance() {
        if (ourManager == null) {
            ourManager = new ZLNetworkManager();
        }
        return ourManager;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public static class Key {
        final String Domain;
        final String Name;
        final String Path;

        Key(Cookie c) {
            this.Domain = c.getDomain();
            this.Path = c.getPath();
            this.Name = c.getName();
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof Key)) {
                return false;
            }
            Key k = (Key) o;
            return ZLMiscUtil.equals(this.Domain, k.Domain) && ZLMiscUtil.equals(this.Path, k.Path) && ZLMiscUtil.equals(this.Name, k.Name);
        }

        public int hashCode() {
            return ZLMiscUtil.hashCode(this.Domain) + ZLMiscUtil.hashCode(this.Path) + ZLMiscUtil.hashCode(this.Name);
        }
    }

    public void perform(ZLNetworkRequest request) throws ZLNetworkException {
        String code;
        HttpContext httpContext;
        DefaultHttpClient httpClient;
        HttpRequestBase httpRequest;
        InputStream stream;
        InputStream stream2;
        DefaultHttpClient httpClient2 = null;
        HttpEntity entity = null;
        try {
            try {
                httpContext = new BasicHttpContext();
                httpContext.setAttribute("http.cookie-store", this.myCookieStore);
                request.doBefore();
                HttpParams params = new BasicHttpParams();
                HttpConnectionParams.setSoTimeout(params, SpeechError.UNKNOWN);
                HttpConnectionParams.setConnectionTimeout(params, Constants.DEFAULT_READ_TIMEOUT);
                httpClient = new DefaultHttpClient(params);
            } catch (Throwable th) {
                th = th;
            }
        } catch (ZLNetworkException e) {
            throw e;
        } catch (IOException e2) {
            e = e2;
        } catch (Exception e3) {
            e = e3;
        }
        try {
            try {
                if (request.PostData != null) {
                    httpRequest = new HttpPost(request.URL);
                    ((HttpPost) httpRequest).setEntity(new StringEntity(request.PostData, "utf-8"));
                } else if (!request.PostParameters.isEmpty()) {
                    httpRequest = new HttpPost(request.URL);
                    List<BasicNameValuePair> list = new ArrayList<>(request.PostParameters.size());
                    for (Map.Entry<String, String> entry : request.PostParameters.entrySet()) {
                        list.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                    }
                    ((HttpPost) httpRequest).setEntity(new UrlEncodedFormEntity(list, "utf-8"));
                } else {
                    httpRequest = new HttpGet(request.URL);
                }
                httpRequest.setHeader("User-Agent", ZLNetworkUtil.getUserAgent());
                httpRequest.setHeader("Accept-Encoding", "gzip");
                httpRequest.setHeader("Accept-Language", Locale.getDefault().getLanguage());
                HttpResponse response = null;
                IOException lastException = null;
                for (int retryCounter = 0; retryCounter < 3 && entity == null; retryCounter++) {
                    try {
                        response = httpClient.execute(httpRequest, httpContext);
                        entity = response.getEntity();
                        lastException = null;
                        if (response.getStatusLine().getStatusCode() == 401) {
                        }
                    } catch (IOException e4) {
                        lastException = e4;
                    }
                }
                if (lastException != null) {
                    throw lastException;
                }
                int responseCode = response.getStatusLine().getStatusCode();
                if (entity == null || responseCode != 200) {
                    stream = null;
                } else {
                    InputStream stream3 = entity.getContent();
                    stream = stream3;
                }
                if (stream != null) {
                    try {
                        Header encoding = entity.getContentEncoding();
                        stream2 = (encoding == null || !"gzip".equalsIgnoreCase(encoding.getValue())) ? stream : new GZIPInputStream(stream);
                        try {
                            request.handleStream(stream2, (int) entity.getContentLength());
                            stream2.close();
                            request.doAfter(true);
                            if (httpClient != null) {
                                httpClient.getConnectionManager().shutdown();
                            }
                            if (entity != null) {
                                try {
                                    entity.consumeContent();
                                } catch (IOException e5) {
                                }
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            stream2.close();
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        stream2 = stream;
                    }
                } else {
                    if (responseCode == 401) {
                        throw new ZLNetworkException(ZLNetworkException.ERROR_AUTHENTICATION_FAILED);
                    }
                    throw new ZLNetworkException(true, response.getStatusLine().toString());
                }
            } catch (IOException e6) {
                e = e6;
                e.printStackTrace();
                if (e instanceof UnknownHostException) {
                    code = ZLNetworkException.ERROR_RESOLVE_HOST;
                } else {
                    code = ZLNetworkException.ERROR_CONNECT_TO_HOST;
                }
                throw new ZLNetworkException(code, ZLNetworkUtil.hostFromUrl(request.URL), e);
            }
        } catch (ZLNetworkException e7) {
            throw e7;
        } catch (Exception e8) {
            e = e8;
            e.printStackTrace();
            throw new ZLNetworkException(true, e.getMessage(), (Throwable) e);
        } catch (Throwable th4) {
            th = th4;
            httpClient2 = httpClient;
            request.doAfter(false);
            if (httpClient2 != null) {
                httpClient2.getConnectionManager().shutdown();
            }
            if (0 != 0) {
                try {
                    entity.consumeContent();
                } catch (IOException e9) {
                }
            }
            throw th;
        }
    }

    public void perform(List<ZLNetworkRequest> requests) throws ZLNetworkException {
        if (requests.size() != 0) {
            if (requests.size() == 1) {
                perform(requests.get(0));
                return;
            }
            HashSet<String> errors = new HashSet<>();
            for (ZLNetworkRequest r : requests) {
                try {
                    perform(r);
                } catch (ZLNetworkException e) {
                    e.printStackTrace();
                    errors.add(e.getMessage());
                }
            }
            if (errors.size() > 0) {
                StringBuilder message = new StringBuilder();
                Iterator<String> it = errors.iterator();
                while (it.hasNext()) {
                    String e2 = it.next();
                    if (message.length() != 0) {
                        message.append(", ");
                    }
                    message.append(e2);
                }
                throw new ZLNetworkException(true, message.toString());
            }
        }
    }

    public final void downloadToFile(String url, File outFile) throws ZLNetworkException {
        downloadToFile(url, null, outFile, 8192);
    }

    public final void downloadToFile(String url, String sslCertificate, File outFile) throws ZLNetworkException {
        downloadToFile(url, sslCertificate, outFile, 8192);
    }

    public final void downloadToFile(String url, String sslCertificate, final File outFile, final int bufferSize) throws ZLNetworkException {
        perform(new ZLNetworkRequest(url, sslCertificate, null) { // from class: com.baoyi.download.core.network.ZLNetworkManager.2
            @Override // com.baoyi.download.core.network.ZLNetworkRequest
            public void handleStream(InputStream inputStream, int length) throws IOException, ZLNetworkException {
                OutputStream outStream = new FileOutputStream(outFile);
                try {
                    byte[] buffer = new byte[bufferSize];
                    while (true) {
                        int size = inputStream.read(buffer);
                        if (size > 0) {
                            outStream.write(buffer, 0, size);
                        } else {
                            return;
                        }
                    }
                } finally {
                    outStream.close();
                }
            }
        });
    }
}
