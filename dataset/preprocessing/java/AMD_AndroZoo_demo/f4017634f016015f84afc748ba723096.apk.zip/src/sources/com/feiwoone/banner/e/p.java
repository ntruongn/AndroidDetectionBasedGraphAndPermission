package com.feiwoone.banner.e;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class p {
    private static p b;
    private NotificationManager a;
    private Notification c;
    private List d;
    private Context e;
    private Bitmap f;
    private boolean g;

    public p() {
    }

    private p(Context context) {
        "NotificationManagerTool_placeholder".replace("_placeholder", "");
        this.a = null;
        this.c = null;
        this.d = null;
        this.g = false;
        this.e = context;
        if (this.a == null) {
            this.a = (NotificationManager) context.getSystemService("notification");
        }
    }

    private ImageView a(View view) {
        if (!(view instanceof ViewGroup)) {
            if (view instanceof ImageView) {
                return (ImageView) view;
            }
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        for (int childCount = viewGroup.getChildCount(); childCount > 0; childCount--) {
            ImageView a = a(viewGroup.getChildAt(childCount - 1));
            if (a != null && a.getId() == 16908294) {
                return a;
            }
        }
        return null;
    }

    public static p a(Context context) {
        if (b == null) {
            b = new p(context);
        }
        return b;
    }

    public final void a(int i) {
        this.a.cancel(i);
    }

    public final void a(int i, String str, Notification notification) {
        try {
            if (this.d == null) {
                this.d = new ArrayList();
            }
            StringBuilder sb = new StringBuilder(String.valueOf(f.a(this.e).b(this.e, "/adfeiwo/image/")));
            f.a(this.e);
            String sb2 = sb.append(f.c(str)).toString();
            if (str != null && str.length() > 0 && !this.d.contains(sb2) && notification != null) {
                f.a(this.e);
                if (f.d(sb2)) {
                    Bitmap decodeFile = BitmapFactory.decodeFile(sb2);
                    if (decodeFile == null) {
                        f.a(this.e);
                        f.e(sb2);
                    } else {
                        notification.contentView.setImageViewBitmap(a(View.inflate(this.e, notification.contentView.getLayoutId(), null)).getId(), decodeFile);
                    }
                } else if (!this.d.contains(sb2)) {
                    this.d.add(sb2);
                    a.a().a(this.e, str, new r(this, sb2, i, str, notification));
                }
            }
        } catch (Exception e) {
        }
        this.a.notify(i, notification);
        this.a.notify(i, notification);
    }

    public final void a(int i, String str, String str2, String str3, Intent intent, int i2) {
        if (this.c == null) {
            this.c = new Notification();
        }
        this.c.icon = 17301586;
        this.c.tickerText = "正在为您下载_placeholder".replace("_placeholder", "");
        this.c.flags = i2;
        this.c.setLatestEventInfo(this.e, str2, str3, PendingIntent.getActivity(this.e, 0, intent, 67108864));
        this.a.notify(i, this.c);
    }
}
