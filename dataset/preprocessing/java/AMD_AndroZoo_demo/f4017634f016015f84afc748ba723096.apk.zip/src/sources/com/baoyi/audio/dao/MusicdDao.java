package com.baoyi.audio.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.iring.entity.Music;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MusicdDao {
    private static final String DB_NAME = "baoyinovels";
    private static final String TABLE_TRACK = "music";
    private Context mActivity;

    private void create() {
        SQLiteDatabase db = this.mActivity.openOrCreateDatabase(DB_NAME, 0, null);
        StringBuffer buffer = new StringBuffer();
        buffer.append("CREATE TABLE IF NOT EXISTS music");
        buffer.append(" ([id] INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,");
        buffer.append(" [name] VARCHAR(100)  NULL,");
        buffer.append(" [url] VARCHAR(300)  NULL,");
        buffer.append(" [artist] VARCHAR(50)  NULL,");
        buffer.append("[addtime] Long  NULL,");
        buffer.append("[hit] INTEGER  NULL)");
        db.execSQL(buffer.toString());
        db.close();
    }

    public List<Music> all() {
        SQLiteDatabase db = getDb();
        List<Music> all = new ArrayList<>();
        Cursor result = db.rawQuery("SELECT * FROM music order by addtime desc", null);
        result.moveToFirst();
        MusicBuilder b = new MusicBuilder();
        int i = 0;
        while (!result.isAfterLast()) {
            all.add(b.build(result));
            result.moveToNext();
            i++;
            if (i > 150) {
                break;
            }
        }
        result.close();
        db.close();
        return all;
    }

    public boolean findByName(Music entry) {
        SQLiteDatabase db = getDb();
        String[] columns = {"id"};
        String idd = new StringBuilder().append(entry.getId()).toString();
        String[] parms = {idd};
        Cursor result = db.query(TABLE_TRACK, columns, "id=?", parms, null, null, null);
        boolean isadd = result.moveToFirst();
        db.close();
        return isadd;
    }

    public void deleteall() {
        SQLiteDatabase db = null;
        try {
            try {
                db = getDb();
                int size = db.delete(TABLE_TRACK, null, null);
                Log.i("ada", "删除数据条数:" + size);
                if (db != null) {
                    db.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
                if (db != null) {
                    db.close();
                }
            }
        } catch (Throwable th) {
            if (db != null) {
                db.close();
            }
            throw th;
        }
    }

    public boolean addToMusic(Music entry) {
        boolean isadd = findByName(entry);
        if (!isadd) {
            SQLiteDatabase db = getDb();
            ContentValues values = new ContentValues();
            values.putAll(new MusicBuilder().deconstruct(entry));
            db.insert(TABLE_TRACK, null, values);
            db.close();
            return true;
        }
        SQLiteDatabase db2 = getDb();
        ContentValues values2 = new ContentValues();
        values2.putAll(new MusicBuilder().deconstruct(entry));
        String[] whereArgs = {new StringBuilder().append(entry.getId()).toString()};
        int row_count = db2.update(TABLE_TRACK, values2, "id=?", whereArgs);
        if (row_count == 0) {
            Log.e("ada", "Failed to update ");
        }
        db2.close();
        return false;
    }

    public MusicdDao(Context activity) {
        this.mActivity = activity;
        create();
    }

    private SQLiteDatabase getDb() {
        return this.mActivity.openOrCreateDatabase(DB_NAME, 0, null);
    }
}
