package com.baoyi.audio;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.baoyi.audio.adapter.MusicItemListAdapter;
import com.baoyi.audio.cache.DataCache;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class FavMusicListUI extends AnalyticsUI {
    MusicItemListAdapter adapter;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    int page = 0;
    private TextView title;
    private int userid;

    public FavMusicListUI(int userid) {
        this.userid = userid;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.baoyi.audio.AnalyticsUI, com.baoyi.audio.BugActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_list_hot);
        this.title = (TextView) findViewById(R.id.typetitle);
        this.title.setText("我的收藏");
        if (getUserid() < 1) {
            Intent intent = new Intent(this, (Class<?>) LoginActivity.class);
            startActivity(intent);
            Toast.makeText(this, "你没有不登陆，请登陆", 0).show();
            finish();
        }
        this.mPullRefreshListView = (PullToRefreshListView) findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() { // from class: com.baoyi.audio.FavMusicListUI.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            }

            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                new HotTask(FavMusicListUI.this, null).execute(Integer.valueOf(FavMusicListUI.this.page));
            }
        });
        WidgetLoadling tv = new WidgetLoadling(this);
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new MusicItemListAdapter(this);
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getSharedPreferences("com.iym.imusic_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(this);
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        new HotTask(this, null).execute(Integer.valueOf(this.page));
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Music>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(FavMusicListUI favMusicListUI, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Music> doInBackground(Integer... params) {
            String key = String.valueOf(FavMusicListUI.this.getUserid()) + "RpcUtils2.getUserRpc().pageringfav" + params[0];
            List<Music> temp = DataCache.datas.get(key);
            if (temp == null || temp.size() == 0) {
                try {
                    return RpcUtils2.getUserRpc().pageringfav(Integer.valueOf(FavMusicListUI.this.getUserid()), 80, params[0].intValue()).getDatas();
                } catch (Exception e) {
                    e.printStackTrace();
                    return temp;
                }
            }
            return temp;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Music> result) {
            if (result != null) {
                for (Music music : result) {
                    FavMusicListUI.this.adapter.addLast(music);
                }
                FavMusicListUI.this.adapter.notifyDataSetChanged();
                FavMusicListUI.this.mPullRefreshListView.onRefreshComplete();
                FavMusicListUI.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + FavMusicListUI.this.adapter.getCount() + "首铃声");
                FavMusicListUI.this.page++;
                return;
            }
            if (FavMusicListUI.this.page == 0) {
                FavMusicListUI.this.mPullRefreshListView.setEmptyView(null);
                Toast.makeText(FavMusicListUI.this, "获取数据失败，请稍候再试。", 0).show();
            }
            FavMusicListUI.this.mPullRefreshListView.onRefreshComplete();
        }
    }
}
