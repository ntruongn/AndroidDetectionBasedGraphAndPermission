package com.feiwoone.banner.f;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class k {
    public static String a() {
        try {
            return m.a("") ? Build.MANUFACTURER : "";
        } catch (Exception e) {
            return "";
        }
    }

    public static String a(Context context) {
        String str;
        try {
            str = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
        } catch (Exception e) {
            str = "";
        }
        return m.a(str) ? b(context) : str;
    }

    public static String b() {
        try {
            return Build.VERSION.SDK;
        } catch (Exception e) {
            return "";
        }
    }

    public static String b(Context context) {
        try {
            return ((WifiManager) context.getSystemService("wifi")).getConnectionInfo().getMacAddress();
        } catch (Exception e) {
            return "";
        }
    }

    public static String c(Context context) {
        try {
            return ((WifiManager) context.getSystemService("wifi")).getConnectionInfo().getBSSID();
        } catch (Exception e) {
            return "";
        }
    }

    public static com.feiwoone.banner.c.c d(Context context) {
        com.feiwoone.banner.c.c cVar = new com.feiwoone.banner.c.c();
        if (com.feiwoone.banner.b.a.b > 0 && com.feiwoone.banner.b.a.c > 0) {
            cVar.a(com.feiwoone.banner.b.a.b);
            cVar.b(com.feiwoone.banner.b.a.c);
            return cVar;
        }
        try {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
            cVar.a(displayMetrics.widthPixels);
            cVar.b(displayMetrics.heightPixels);
        } catch (Exception e) {
        }
        return cVar;
    }
}
