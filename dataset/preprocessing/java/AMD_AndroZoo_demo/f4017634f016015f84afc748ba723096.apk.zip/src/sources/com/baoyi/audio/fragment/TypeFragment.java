package com.baoyi.audio.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ListAdapter;
import com.baoyi.audio.adapter.ButtonsAdapter;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class TypeFragment extends Fragment {
    ButtonsAdapter buttonsAdapter;
    GridView gridView;

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.gridView = (GridView) getView().findViewById(R.id.gridView);
        this.buttonsAdapter = new ButtonsAdapter(getActivity());
        this.gridView.setAdapter((ListAdapter) this.buttonsAdapter);
        this.gridView.setOnItemClickListener(this.buttonsAdapter);
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_typelist, container, false);
        return view;
    }
}
