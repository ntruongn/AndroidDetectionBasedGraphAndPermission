package com.feiwoone.banner.e;

import android.app.Notification;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import android.widget.ImageView;
import android.widget.RemoteViews;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class q implements d {
    private /* synthetic */ p a;
    private final /* synthetic */ ImageView b;

    public static Object a(String str) {
        ObjectInputStream objectInputStream;
        Throwable th;
        ByteArrayInputStream byteArrayInputStream;
        Object obj = null;
        try {
            byteArrayInputStream = new ByteArrayInputStream(Base64.decode(str.getBytes(), 0));
            try {
                objectInputStream = new ObjectInputStream(byteArrayInputStream);
            } catch (StreamCorruptedException e) {
                objectInputStream = null;
            } catch (IOException e2) {
                objectInputStream = null;
            } catch (ClassNotFoundException e3) {
                objectInputStream = null;
            } catch (Throwable th2) {
                objectInputStream = null;
                th = th2;
            }
            try {
                obj = objectInputStream.readObject();
                try {
                    objectInputStream.close();
                    byteArrayInputStream.close();
                } catch (IOException e4) {
                }
            } catch (StreamCorruptedException e5) {
                if (objectInputStream != null) {
                    try {
                        objectInputStream.close();
                    } catch (IOException e6) {
                    }
                }
                if (byteArrayInputStream != null) {
                    byteArrayInputStream.close();
                }
                return obj;
            } catch (IOException e7) {
                if (objectInputStream != null) {
                    try {
                        objectInputStream.close();
                    } catch (IOException e8) {
                    }
                }
                if (byteArrayInputStream != null) {
                    byteArrayInputStream.close();
                }
                return obj;
            } catch (ClassNotFoundException e9) {
                if (objectInputStream != null) {
                    try {
                        objectInputStream.close();
                    } catch (IOException e10) {
                    }
                }
                if (byteArrayInputStream != null) {
                    byteArrayInputStream.close();
                }
                return obj;
            } catch (Throwable th3) {
                th = th3;
                if (objectInputStream != null) {
                    try {
                        objectInputStream.close();
                    } catch (IOException e11) {
                        throw th;
                    }
                }
                if (byteArrayInputStream != null) {
                    byteArrayInputStream.close();
                }
                throw th;
            }
        } catch (StreamCorruptedException e12) {
            byteArrayInputStream = null;
            objectInputStream = null;
        } catch (IOException e13) {
            byteArrayInputStream = null;
            objectInputStream = null;
        } catch (ClassNotFoundException e14) {
            byteArrayInputStream = null;
            objectInputStream = null;
        } catch (Throwable th4) {
            objectInputStream = null;
            th = th4;
            byteArrayInputStream = null;
        }
        return obj;
    }

    public static String a(Object obj) {
        ObjectOutputStream objectOutputStream;
        ByteArrayOutputStream byteArrayOutputStream;
        Throwable th;
        ByteArrayOutputStream byteArrayOutputStream2;
        ObjectOutputStream objectOutputStream2 = null;
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();
            try {
                objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
                try {
                    objectOutputStream.writeObject(obj);
                    String str = new String(Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0));
                    try {
                        objectOutputStream.close();
                        byteArrayOutputStream.close();
                        return str;
                    } catch (IOException e) {
                        return str;
                    }
                } catch (IOException e2) {
                    objectOutputStream2 = objectOutputStream;
                    byteArrayOutputStream2 = byteArrayOutputStream;
                    if (objectOutputStream2 != null) {
                        try {
                            objectOutputStream2.close();
                        } catch (IOException e3) {
                            return "";
                        }
                    }
                    if (byteArrayOutputStream2 == null) {
                        return "";
                    }
                    byteArrayOutputStream2.close();
                    return "";
                } catch (Throwable th2) {
                    th = th2;
                    if (objectOutputStream != null) {
                        try {
                            objectOutputStream.close();
                        } catch (IOException e4) {
                            throw th;
                        }
                    }
                    if (byteArrayOutputStream != null) {
                        byteArrayOutputStream.close();
                    }
                    throw th;
                }
            } catch (IOException e5) {
                byteArrayOutputStream2 = byteArrayOutputStream;
            } catch (Throwable th3) {
                objectOutputStream = null;
                th = th3;
            }
        } catch (IOException e6) {
            byteArrayOutputStream2 = null;
        } catch (Throwable th4) {
            objectOutputStream = null;
            byteArrayOutputStream = null;
            th = th4;
        }
    }

    @Override // com.feiwoone.banner.e.d
    public final void a(Drawable drawable) {
        Notification notification;
        Bitmap bitmap;
        if (drawable != null) {
            this.a.f = ((BitmapDrawable) drawable).getBitmap();
            notification = this.a.c;
            RemoteViews remoteViews = notification.contentView;
            int id = this.b.getId();
            bitmap = this.a.f;
            remoteViews.setImageViewBitmap(id, bitmap);
        }
    }
}
