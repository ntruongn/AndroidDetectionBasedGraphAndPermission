package com.baoyi.audio.dao;

import android.content.ContentValues;
import android.database.Cursor;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.dao.DatabaseBuilder;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class FavInfoBuilder extends DatabaseBuilder<FavInfo> {
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.baoyi.dao.DatabaseBuilder
    public FavInfo build(Cursor query) {
        FavInfo word = new FavInfo();
        int columnName = query.getColumnIndex(UpdateService.NAME);
        int columnId = query.getColumnIndex("searchtime");
        int msgId = query.getColumnIndex("album");
        int idId = query.getColumnIndex("id");
        int imgurlId = query.getColumnIndex("url");
        word.setName(query.getString(columnName));
        word.setSearchtime(query.getLong(columnId));
        word.setId(Integer.valueOf(query.getInt(idId)));
        word.setAlbum(query.getString(msgId));
        word.setUrl(query.getString(imgurlId));
        return word;
    }

    @Override // com.baoyi.dao.DatabaseBuilder
    public ContentValues deconstruct(FavInfo t) {
        ContentValues values = new ContentValues();
        values.put(UpdateService.NAME, t.getName());
        values.put("searchtime", Long.valueOf(t.getSearchtime()));
        values.put("url", t.getUrl());
        values.put("album", t.getAlbum());
        values.put("id", t.getId());
        return values;
    }
}
