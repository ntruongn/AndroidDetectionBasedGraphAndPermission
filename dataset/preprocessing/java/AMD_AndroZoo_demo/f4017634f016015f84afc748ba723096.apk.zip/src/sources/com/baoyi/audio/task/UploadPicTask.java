package com.baoyi.audio.task;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.widget.Toast;
import com.baoyi.audio.utils.RpcUtils2;
import com.iring.rpc.RpcSerializable;
import java.io.File;
import java.nio.charset.Charset;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class UploadPicTask extends AsyncTask<String, Void, RpcSerializable> {
    private Context context;
    private ProgressDialog progressDialog = null;

    public UploadPicTask(Context c) {
        this.context = c;
    }

    @Override // android.os.AsyncTask
    public void onPreExecute() {
        this.progressDialog = ProgressDialog.show(this.context, "上传图片", "正在选择图片服务器,请稍候！", true);
        this.progressDialog.setCancelable(true);
        super.onPreExecute();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public RpcSerializable doInBackground(String... params) {
        RpcSerializable result = new RpcSerializable();
        String picture = uppic(params[0], params[1], "picture");
        SharedPreferences sharedPreferences = this.context.getSharedPreferences("apps", 0);
        if (picture != null) {
            sharedPreferences.edit().putString("bigpic", picture).commit();
        }
        String minpicture = uppic(params[2], params[1], "minpicture");
        if (minpicture != null) {
            sharedPreferences.edit().putString("minipic", minpicture).commit();
        }
        return result;
    }

    private String uppic(String pic, String idd, String type) {
        String result = "";
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
        try {
            try {
                HttpPost httppost = new HttpPost(RpcUtils2.picurl);
                FileBody bin = new FileBody(new File(pic));
                MultipartEntity reqEntity = new MultipartEntity();
                reqEntity.addPart("upload", bin);
                ContentBody contentBody = new StringBody(type, Charset.forName("UTF-8"));
                reqEntity.addPart("work", contentBody);
                ContentBody id = new StringBody(idd, Charset.forName("UTF-8"));
                reqEntity.addPart("id", id);
                httppost.setEntity(reqEntity);
                HttpResponse response = defaultHttpClient.execute(httppost);
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode == 200) {
                    HttpEntity resEntity = response.getEntity();
                    result = EntityUtils.toString(resEntity);
                }
                try {
                    defaultHttpClient.getConnectionManager().shutdown();
                } catch (Exception e) {
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            return result;
        } finally {
            try {
                defaultHttpClient.getConnectionManager().shutdown();
            } catch (Exception e3) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onPostExecute(RpcSerializable result) {
        if (result != null && result.getCode() == 0) {
            Toast.makeText(this.context, "上传头像成功", 0).show();
        } else {
            Toast.makeText(this.context, "选着服务器失败,请稍后再试！", 0).show();
        }
        this.progressDialog.dismiss();
    }
}
