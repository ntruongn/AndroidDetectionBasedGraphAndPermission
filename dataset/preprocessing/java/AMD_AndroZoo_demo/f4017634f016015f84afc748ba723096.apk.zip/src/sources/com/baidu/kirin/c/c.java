package com.baidu.kirin.c;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class c extends a {
    public c(Context context, String str) {
        super(context, str);
        this.c = getClass().getName();
    }

    @Override // com.baidu.kirin.c.a
    protected void b() {
        try {
            this.d.put("logID", com.baidu.kirin.b.a.a(this.a).d());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
