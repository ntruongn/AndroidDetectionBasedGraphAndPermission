package com.baoyi.ring.widget;

import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.baoyi.doamin.CheckWork;
import com.baoyi.ring.entity.LocalMusic;
import com.baoyi.ring.fragment.LocalFragment;
import com.baoyi.utils.MusicUtils;
import com.baoyi.weight.ActionItem;
import com.baoyi.weight.QuickAction;
import com.hope.leyuan.R;
import com.ringdroid.ChooseContactActivity;
import java.io.File;
import java.io.IOException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class LocalMusicWidget extends LinearLayout implements View.OnClickListener {
    private static LocalMusic localMusicold;
    public static MediaPlayer mediaPlayer;
    TextView artist;
    CheckBox checkBox;
    LocalFragment localFragment;
    private LocalMusic localMusic;
    QuickAction paihangbangMenu;
    LinearLayout selectwork;
    ImageView set;
    ImageView share;
    private boolean show;
    TextView time;
    TextView title;
    LinearLayout works;

    public LocalFragment getLocalFragment() {
        return this.localFragment;
    }

    public void setLocalFragment(LocalFragment localFragment) {
        this.localFragment = localFragment;
    }

    public LocalMusicWidget(Context context) {
        super(context);
        this.show = false;
        LayoutInflater.from(context).inflate(R.layout.widget_local_music, this);
        this.title = (TextView) findViewById(R.id.title);
        this.artist = (TextView) findViewById(R.id.artist);
        this.checkBox = (CheckBox) findViewById(R.id.checkBox);
        this.time = (TextView) findViewById(R.id.time);
        this.selectwork = (LinearLayout) findViewById(R.id.selectwork);
        this.works = (LinearLayout) findViewById(R.id.works);
        this.share = (ImageView) findViewById(R.id.share);
        this.set = (ImageView) findViewById(R.id.set);
        this.set.setOnClickListener(this);
        this.share.setOnClickListener(this);
        this.selectwork.setOnClickListener(this);
        this.paihangbangMenu = new QuickAction(context, 1);
        ActionItem item1 = new ActionItem(1, "设置为来电铃声", context.getResources().getDrawable(R.drawable.nothing_pic));
        ActionItem item2 = new ActionItem(2, "设置为短信铃声", context.getResources().getDrawable(R.drawable.nothing_pic));
        ActionItem item3 = new ActionItem(3, "设置为提示音", context.getResources().getDrawable(R.drawable.nothing_pic));
        ActionItem item4 = new ActionItem(4, "设置为闹铃", context.getResources().getDrawable(R.drawable.nothing_pic));
        ActionItem item5 = new ActionItem(5, "设置为个性联系人", context.getResources().getDrawable(R.drawable.nothing_pic));
        this.paihangbangMenu.addActionItem(item1);
        this.paihangbangMenu.addActionItem(item2);
        this.paihangbangMenu.addActionItem(item3);
        this.paihangbangMenu.addActionItem(item4);
        this.paihangbangMenu.addActionItem(item5);
        this.paihangbangMenu.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() { // from class: com.baoyi.ring.widget.LocalMusicWidget.1
            @Override // com.baoyi.weight.QuickAction.OnActionItemClickListener
            public void onItemClick(QuickAction source, int pos, int actionId) {
                if (actionId == 1) {
                    CheckWork work = new CheckWork();
                    work.setIsringtones(true);
                    MusicUtils.setRingtone(LocalMusicWidget.this.getContext(), LocalMusicWidget.this.localMusic.getId().intValue(), work);
                    return;
                }
                if (actionId == 2) {
                    CheckWork work2 = new CheckWork();
                    work2.setIsnotifications(true);
                    MusicUtils.setRingtone(LocalMusicWidget.this.getContext(), LocalMusicWidget.this.localMusic.getId().intValue(), work2);
                } else if (actionId == 3) {
                    CheckWork work3 = new CheckWork();
                    work3.setIspodcast(true);
                    MusicUtils.setRingtone(LocalMusicWidget.this.getContext(), LocalMusicWidget.this.localMusic.getId().intValue(), work3);
                } else if (actionId == 4) {
                    CheckWork work4 = new CheckWork();
                    work4.setIsalarms(true);
                    MusicUtils.setRingtone(LocalMusicWidget.this.getContext(), LocalMusicWidget.this.localMusic.getId().intValue(), work4);
                } else {
                    if (actionId != 5) {
                        return;
                    }
                    LocalMusicWidget.this.setOneRing(new File(LocalMusicWidget.this.localMusic.getUrl()));
                }
            }
        });
        this.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.baoyi.ring.widget.LocalMusicWidget.2
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                LocalMusicWidget.this.localMusic.setIsselect(isChecked);
            }
        });
        this.show = false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setOneRing(File file) {
        try {
            Intent intent = new Intent("android.intent.action.EDIT", getUri(file));
            intent.setClass(getContext(), ChooseContactActivity.class);
            getContext().startActivity(intent);
        } catch (Exception e) {
            Log.e("Ringdroid", "Couldn't open Choose Contact window");
        }
    }

    private Uri getUri(File fileitem) {
        ContentValues cv = new ContentValues();
        Uri uri = MediaStore.Audio.Media.getContentUriForPath(fileitem.getAbsolutePath());
        Cursor cursor = getContext().getContentResolver().query(uri, null, "_data=?", new String[]{fileitem.getAbsolutePath()}, null);
        if (cursor.moveToFirst() && cursor.getCount() > 0) {
            String _id = cursor.getString(0);
            cv.put("is_ringtone", (Boolean) true);
            cv.put("is_notification", (Boolean) false);
            cv.put("is_alarm", (Boolean) false);
            cv.put("is_music", (Boolean) false);
            getContext().getContentResolver().update(uri, cv, "_data=?", new String[]{fileitem.getAbsolutePath()});
            Uri newUri = ContentUris.withAppendedId(uri, Long.valueOf(_id).longValue());
            return newUri;
        }
        cv.put("_data", fileitem.getAbsolutePath());
        Uri newUri2 = getContext().getContentResolver().insert(uri, cv);
        return newUri2;
    }

    public void setChecked(boolean checked) {
        this.checkBox.setChecked(checked);
    }

    public LocalMusic getLocalMusic() {
        return this.localMusic;
    }

    public void setLocalMusic(LocalMusic localMusic) {
        this.localMusic = localMusic;
        this.title.setText(localMusic.getTitle());
        this.artist.setText(localMusic.getArtist());
        this.time.setText(localMusic.getDuration());
        this.checkBox.setChecked(localMusic.isIsselect());
        if (localMusic.isShow()) {
            this.works.setVisibility(0);
        } else {
            this.works.setVisibility(8);
        }
    }

    public void hiden() {
        this.works.setVisibility(8);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        if (v.getId() == 2131296484) {
            if (localMusicold != null) {
                localMusicold.setShow(false);
            }
            if (this.works.getVisibility() == 8) {
                this.show = true;
                this.localMusic.setShow(true);
                this.works.setVisibility(0);
                try {
                    if (mediaPlayer != null) {
                        mediaPlayer.pause();
                        mediaPlayer.stop();
                        mediaPlayer.release();
                        mediaPlayer = null;
                    }
                    mediaPlayer = new MediaPlayer();
                    mediaPlayer.setDataSource(getContext(), Uri.fromFile(new File(this.localMusic.getUrl())));
                    mediaPlayer.prepareAsync();
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.baoyi.ring.widget.LocalMusicWidget.3
                        @Override // android.media.MediaPlayer.OnPreparedListener
                        public void onPrepared(MediaPlayer mp) {
                            mp.start();
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (IllegalArgumentException e2) {
                    e2.printStackTrace();
                } catch (IllegalStateException e3) {
                    e3.printStackTrace();
                } catch (SecurityException e4) {
                    e4.printStackTrace();
                }
            } else {
                this.show = false;
                this.localMusic.setShow(false);
                this.works.setVisibility(8);
            }
            localMusicold = this.localMusic;
            this.localFragment.resh();
            return;
        }
        if (v.getId() == 2131296489) {
            share();
        } else if (v.getId() == 2131296490) {
            setring();
        }
    }

    private void share() {
        Intent sendIntent = new Intent();
        sendIntent.setAction("android.intent.action.SEND");
        sendIntent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + this.localMusic.getUrl()));
        sendIntent.setType("audio/mp3");
        sendIntent.putExtra("android.intent.extra.SUBJECT", "安卓铃声：铃声分享:" + this.localMusic.getTitle());
        sendIntent.putExtra("android.intent.extra.TEXT", "我正在使用安卓铃声，" + this.localMusic.getTitle() + "不错,我把铃声分享给你,更多铃声请访问安卓铃声网站:http://iring.wutianxia.com:8999/iringdata/");
        sendIntent.putExtra("android.intent.extra.SUBJECT", "安卓铃声：铃声分享:" + this.localMusic.getTitle());
        getContext().startActivity(Intent.createChooser(sendIntent, "分享铃声给好友!"));
    }

    private void setring() {
        this.paihangbangMenu.show(this.set);
    }

    private void confirmDelete() {
        new AlertDialog.Builder(getContext()).setTitle("删除音乐").setMessage("你确定要删除" + this.localMusic.getTitle() + "吗?").setPositiveButton("确定", new DialogInterface.OnClickListener() { // from class: com.baoyi.ring.widget.LocalMusicWidget.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                LocalMusicWidget.this.onDelete();
            }
        }).setNegativeButton("取消", new DialogInterface.OnClickListener() { // from class: com.baoyi.ring.widget.LocalMusicWidget.5
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        }).setCancelable(true).show();
    }

    private void showFinalAlert(CharSequence message) {
        new AlertDialog.Builder(getContext()).setTitle(getResources().getText(R.string.alert_title_failure)).setMessage(message).setPositiveButton(R.string.alert_ok_button, new DialogInterface.OnClickListener() { // from class: com.baoyi.ring.widget.LocalMusicWidget.6
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        }).setCancelable(false).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDelete() {
        if (!new File(this.localMusic.getUrl()).delete()) {
            showFinalAlert(getResources().getText(R.string.delete_failed));
        }
        Uri itemUri = Uri.parse(String.valueOf(MediaStore.Audio.Media.getContentUriForPath(this.localMusic.getUrl()).toString()) + "/" + this.localMusic.getId());
        getContext().getContentResolver().delete(itemUri, null, null);
        if (this.localFragment != null) {
            this.localFragment.resh();
        }
    }

    public boolean isShow() {
        return this.show;
    }
}
