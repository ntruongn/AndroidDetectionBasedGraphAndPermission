package com.baoyi.audio.task;

import android.os.AsyncTask;
import android.util.Log;
import com.baoyi.audio.utils.RpcUtils2;
import com.iring.rpc.RpcSerializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class DownTask extends AsyncTask<Integer, Integer, RpcSerializable> {
    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public RpcSerializable doInBackground(Integer... params) {
        try {
            int id = params[0].intValue();
            if (id > 0) {
                RpcUtils2.getMusicDao().downMusic(params[0].intValue());
                Log.i("ada", "下载成功");
                return null;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }
}
