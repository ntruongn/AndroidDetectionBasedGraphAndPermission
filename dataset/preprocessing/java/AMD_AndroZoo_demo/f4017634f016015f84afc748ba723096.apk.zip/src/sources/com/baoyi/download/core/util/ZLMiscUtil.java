package com.baoyi.download.core.util;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public abstract class ZLMiscUtil {
    public static <T> boolean equals(T o0, T o1) {
        return o0 == null ? o1 == null : o0.equals(o1);
    }

    public static boolean isEmptyString(String s) {
        return s == null || "".equals(s);
    }

    public static int hashCode(Object o) {
        if (o != null) {
            return o.hashCode();
        }
        return 0;
    }

    public static <T> boolean listsEquals(List<T> list1, List<T> list2) {
        if (list1 == null) {
            return list2 == null || list2.isEmpty();
        }
        if (list1.size() == list2.size()) {
            return list1.containsAll(list2);
        }
        return false;
    }

    public static <KeyT, ValueT> boolean mapsEquals(Map<KeyT, ValueT> map1, Map<KeyT, ValueT> map2) {
        if (map1 == null) {
            return map2 == null || map2.isEmpty();
        }
        if (map1.size() != map2.size() || !map1.keySet().containsAll(map2.keySet())) {
            return false;
        }
        for (KeyT key : map1.keySet()) {
            ValueT value1 = map1.get(key);
            ValueT value2 = map2.get(key);
            if (!equals(value1, value2)) {
                return false;
            }
        }
        return true;
    }

    public static boolean matchesIgnoreCase(String text, String lowerCasePattern) {
        return text.length() >= lowerCasePattern.length() && text.toLowerCase().indexOf(lowerCasePattern) >= 0;
    }

    public static String listToString(List<String> list, String delimiter) {
        if (list == null || list.isEmpty()) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        boolean first = true;
        for (String s : list) {
            if (first) {
                first = false;
            } else {
                builder.append(delimiter);
            }
            builder.append(s);
        }
        return builder.toString();
    }

    public static List<String> stringToList(String str, String delimiter) {
        return (str == null || "".equals(str)) ? Collections.emptyList() : Arrays.asList(str.split(delimiter));
    }
}
