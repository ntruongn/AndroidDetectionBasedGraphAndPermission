package com.baoyi.audio;

import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Messages {
    private static Map<Integer, String> datas = new HashMap();

    static {
        datas.put(2, "搞怪另类");
        datas.put(1, "流行铃声");
        datas.put(4, "动漫游戏");
        datas.put(5, "dj舞曲");
        datas.put(6, "影视广告");
        datas.put(3, "短信信息");
        datas.put(10, "天真童声");
        datas.put(11, "节日铃声");
        datas.put(-1, "推荐铃声");
        datas.put(-2, "最新铃声");
    }

    public static String getMessage(Integer index) {
        return datas.get(index);
    }
}
