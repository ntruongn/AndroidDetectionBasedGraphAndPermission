package com.baoyi.audio.adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Toast;
import com.baoyi.adapter.ItemListAdapter;
import com.baoyi.audio.AsyncMusicPlayer;
import com.baoyi.audio.BaoyiApplication;
import com.baoyi.audio.dao.MusicdDao;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.MusiceItem;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MusicItemListAdapter extends ItemListAdapter<Music> implements AdapterView.OnItemClickListener {
    long time;

    public MusicItemListAdapter(Context context) {
        super(context);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        if (arg1 instanceof MusiceItem) {
            Animation animation = AnimationUtils.loadAnimation(this.context, R.anim.showanimationitem);
            arg1.setAnimation(animation);
            MusiceItem item = (MusiceItem) arg1;
            AsyncHttpClient client = new AsyncHttpClient();
            RequestParams params = new RequestParams();
            params.put("id", new StringBuilder().append(item.getWorkItem().getId()).toString());
            client.get("http://iring.wutianxia.com:8999/iringdata/apimusic.php", params, new AsyncHttpResponseHandler() { // from class: com.baoyi.audio.adapter.MusicItemListAdapter.1
                @Override // com.loopj.android.http.AsyncHttpResponseHandler
                public void onSuccess(String response) {
                    if (response != null) {
                        Log.i("ada", response);
                    }
                }
            });
            String files = String.valueOf(content.SAVEDIR) + item.getWorkItem().getName() + ".mp3";
            File file = new File(files);
            Intent intent = new Intent(this.context, (Class<?>) AsyncMusicPlayer.class);
            intent.putExtra(UpdateService.NAME, item.getWorkItem().getName());
            intent.putExtra("fileurl", geturl(item));
            intent.putExtra("arc", item.getWorkItem().getName());
            intent.putExtra("musicid", item.getWorkItem().getId());
            MusicdDao dao = new MusicdDao(this.context);
            dao.addToMusic(item.getWorkItem());
            if (file.exists() && file.length() > 1000) {
                this.context.startActivity(intent);
            } else if (BaoyiApplication.getInstance().isonline()) {
                this.context.startActivity(intent);
            } else {
                Toast.makeText(this.context, "请检查你的网络,该铃声不存在", 0).show();
            }
        }
    }

    private String geturl(MusiceItem item) {
        String url = item.getWorkItem().getUrl();
        if (url != null && !url.startsWith("http")) {
            return String.valueOf(content.mp3server) + url;
        }
        return url;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListAdapter
    public View update(int position, View view, Music item) {
        MusiceItem musiceItem = (MusiceItem) view;
        musiceItem.setWorkItem(item);
        musiceItem.setTag(musiceItem);
        return musiceItem;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListAdapter
    public View creatView(int position, Music item) {
        MusiceItem musiceItem = new MusiceItem(this.context, item);
        musiceItem.setTag(musiceItem);
        return musiceItem;
    }

    @Override // com.baoyi.adapter.ItemListAdapter
    protected void updateView(int position, View view) {
        int i = position % 2;
    }
}
