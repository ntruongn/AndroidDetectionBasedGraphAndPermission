package com.baoyi.audio;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;
import com.baoyi.audio.task.FeedBackTask;
import com.hope.leyuan.R;
import com.iring.entity.ApkComment;
import com.iring.rpc.RpcSerializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class FeedBack extends Activity {
    private EditText infos;
    private float ratingscre;
    private RatingBar score;

    private String getVersionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    private String getVersion() {
        try {
            return new StringBuilder(String.valueOf(getPackageManager().getPackageInfo(getPackageName(), 0).versionCode)).toString();
        } catch (Exception e) {
            return "";
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.ui_feedback);
        this.infos = (EditText) findViewById(R.id.infos);
        this.score = (RatingBar) findViewById(R.id.score);
        this.score.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() { // from class: com.baoyi.audio.FeedBack.1
            @Override // android.widget.RatingBar.OnRatingBarChangeListener
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (fromUser) {
                    FeedBack.this.ratingscre = rating;
                }
            }
        });
    }

    public void work(View v) {
        String contents = this.infos.getEditableText().toString();
        if (contents != null && contents.length() > 3) {
            Toast.makeText(this, "正在向服务器提交数据，太感谢了，我们的进步，离不开你们的支持！", 1).show();
            ApkComment apkComment = new ApkComment();
            apkComment.setAppname("随便换铃声");
            apkComment.setApppackage(getPackageName());
            apkComment.setVersion(getVersion());
            apkComment.setClientname("安卓");
            apkComment.setContents(contents);
            apkComment.setScore((int) this.ratingscre);
            new FeedBackTask(apkComment, this).execute(new RpcSerializable[0]);
            return;
        }
        this.infos.setError("请输入反馈给我们的内容");
    }
}
