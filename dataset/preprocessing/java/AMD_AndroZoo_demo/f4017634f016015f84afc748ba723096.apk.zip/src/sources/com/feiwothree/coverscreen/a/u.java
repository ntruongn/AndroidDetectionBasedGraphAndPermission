package com.feiwothree.coverscreen.a;

import android.content.Context;
import android.net.Proxy;
import android.util.Log;
import com.iflytek.speech.SpeechError;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class u implements Runnable {
    private URL a = null;
    private t b;
    private String c;
    private String d;
    private Context e;

    public final void a(Context context, String str, String str2, String str3) {
        this.e = context;
        this.c = str2;
        this.d = str3;
        try {
            this.a = new URL(str);
        } catch (MalformedURLException e) {
            new StringBuilder().append(e);
        }
        new StringBuilder("setBaseRequestInfo, url: ").append(str);
    }

    public final void a(t tVar) {
        this.b = tVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        HttpURLConnection httpURLConnection;
        int b = C0013i.b(this.e);
        if (b == 0) {
            return;
        }
        Context context = this.e;
        new StringBuilder("\nG_获取数据  > ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(System.currentTimeMillis())));
        Context context2 = this.e;
        new StringBuilder("\nG_JSON      ").append(this.d);
        if (this.a == null) {
            Context context3 = this.e;
            throw new IllegalArgumentException("URL must be init!");
        }
        if (J.a(this.c)) {
            Context context4 = this.e;
            throw new IllegalArgumentException("password must be init!");
        }
        HttpURLConnection httpURLConnection2 = null;
        try {
            try {
                try {
                    String defaultHost = Proxy.getDefaultHost();
                    int defaultPort = Proxy.getDefaultPort();
                    new StringBuilder("proxyHost: ").append(defaultHost).append(", port: ").append(defaultPort);
                    if (2 != b || defaultHost == null || defaultPort <= 0) {
                        httpURLConnection = (HttpURLConnection) this.a.openConnection();
                    } else {
                        Log.i("D", "user Proxy, proxyHost: " + defaultHost + ", port: " + defaultPort);
                        httpURLConnection = (HttpURLConnection) this.a.openConnection(new java.net.Proxy(Proxy.Type.HTTP, new InetSocketAddress(defaultHost, defaultPort)));
                    }
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    httpURLConnection.addRequestProperty("appkey", this.c);
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setConnectTimeout(60000);
                    httpURLConnection.setReadTimeout(SpeechError.UNKNOWN);
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(httpURLConnection.getOutputStream()));
                    bufferedWriter.write(k.a(this.d, k.a(this.c), false));
                    bufferedWriter.close();
                    int responseCode = httpURLConnection.getResponseCode();
                    new StringBuilder("get url response code: ").append(responseCode).append(", ").append(this.a);
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(responseCode != 200 ? httpURLConnection.getErrorStream() : httpURLConnection.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    while (true) {
                        String readLine = bufferedReader.readLine();
                        if (readLine == null) {
                            break;
                        } else {
                            sb.append(readLine);
                        }
                    }
                    bufferedReader.close();
                    if (responseCode == 200) {
                        this.b.a(true, k.a(sb.toString(), k.a(this.c)));
                    } else {
                        this.b.a(false, k.a(sb.toString(), k.a(this.c)));
                    }
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                } catch (SocketTimeoutException e) {
                    Context context5 = this.e;
                    new StringBuilder("\nG_error > SocketTimeoutException > ").append(e).append(" > ");
                    this.b.a(false, "SocketTimeoutException " + e);
                    if (0 != 0) {
                        httpURLConnection2.disconnect();
                    }
                } catch (Exception e2) {
                    this.b.a(false, "Exception: " + e2);
                    Context context6 = this.e;
                    new StringBuilder("\nG_error Exception > ").append(e2).append(" > ");
                    if (0 != 0) {
                        httpURLConnection2.disconnect();
                    }
                }
            } catch (SocketException e3) {
                Context context7 = this.e;
                new StringBuilder("\nG_error SocketException > ").append(e3).append(" > ");
                this.b.a(false, "SocketException " + e3);
                if (0 != 0) {
                    httpURLConnection2.disconnect();
                }
            } catch (IOException e4) {
                Context context8 = this.e;
                new StringBuilder("\nG_error IOException > ").append(e4).append(" > ");
                this.b.a(false, "IOException: " + e4);
                if (0 != 0) {
                    httpURLConnection2.disconnect();
                }
            }
        } catch (Throwable th) {
            if (0 != 0) {
                httpURLConnection2.disconnect();
            }
            throw th;
        }
    }
}
