package com.baoyi.audio.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.RemoteViews;
import android.widget.Toast;
import com.baoyi.download.core.network.NetworkNotifications;
import com.baoyi.download.core.network.ZLNetworkException;
import com.baoyi.download.core.network.ZLNetworkManager;
import com.baoyi.download.core.network.ZLNetworkRequest;
import com.baoyi.utils.MusicUtils;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Mp3DownloaderService extends Service {
    private static final String CLEAN_URL_KEY = "CLEAN_URL_KEY";
    private static final String SHOW_NOTIFICATIONS_KEY = "cancle";
    private static final String TITLE_KEY = "title";
    private Set<String> myDownloadingURLs = Collections.synchronizedSet(new HashSet());
    private Set<Integer> myOngoingNotifications = new HashSet();
    private volatile int myServiceCounter;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public interface Notifications {
        public static final int ALL = 3;
        public static final int ALREADY_DOWNLOADING = 2;
        public static final int DOWNLOADING_STARTED = 1;
    }

    private void doStart() {
        this.myServiceCounter++;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doStop() {
        int i = this.myServiceCounter - 1;
        this.myServiceCounter = i;
        if (i == 0) {
            stopSelf();
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        Iterator<Integer> it = this.myOngoingNotifications.iterator();
        while (it.hasNext()) {
            int notificationId = it.next().intValue();
            notificationManager.cancel(notificationId);
        }
        this.myOngoingNotifications.clear();
        super.onDestroy();
    }

    @Override // android.app.Service
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        doStart();
        try {
            work(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void work(Intent intent) {
        String url = intent.getStringExtra("url");
        if (this.myDownloadingURLs.contains(url)) {
            showMessage("正在下载,客官请稍候!!");
            return;
        }
        String fileName = intent.getStringExtra(UpdateService.FILENAME);
        if (fileName == null) {
            doStop();
            return;
        }
        int index = fileName.lastIndexOf(File.separator);
        if (index != -1) {
            String dir = fileName.substring(0, index);
            File dirFile = new File(dir);
            if (!dirFile.exists() && !dirFile.mkdirs()) {
                showMessage("不能创建文件夹", dirFile.getPath());
                doStop();
                return;
            } else if (!dirFile.exists() || !dirFile.isDirectory()) {
                showMessage("不能创建文件夹", dirFile.getPath());
                doStop();
                return;
            }
        }
        File fileFile = new File(fileName);
        if (fileFile.exists()) {
            if (!fileFile.isFile()) {
                showMessage("不能创建文件", fileFile.getPath());
                doStop();
                return;
            } else {
                doStop();
                return;
            }
        }
        String title = intent.getStringExtra(TITLE_KEY);
        if (title == null || title.length() == 0) {
            title = fileFile.getName();
        }
        startFileDownload(url, fileFile, title);
    }

    private void showMessage(String key) {
        Toast.makeText(getApplicationContext(), key, 0).show();
    }

    private void showMessage(String key, String parameter) {
        Toast.makeText(getApplicationContext(), key.replace("%s", parameter), 0).show();
    }

    private Intent getFBReaderIntent(File file) {
        return new Intent();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Notification createDownloadFinishNotification(File file, String title, boolean success) {
        String tickerText = success ? "下载成功" : "下载错误";
        String contentText = success ? "下载成功" : "下载错误";
        Notification notification = new Notification(17301634, tickerText, System.currentTimeMillis());
        notification.flags |= 16;
        Intent intent = success ? getFBReaderIntent(file) : new Intent();
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, intent, 0);
        notification.setLatestEventInfo(getApplicationContext(), title, contentText, contentIntent);
        return notification;
    }

    private Notification createDownloadProgressNotification(String title) {
        RemoteViews contentView = new RemoteViews(getPackageName(), 2130903060);
        contentView.setTextViewText(2131296332, title);
        contentView.setTextViewText(2131296331, "");
        contentView.setProgressBar(2131296333, 100, 0, true);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, new Intent(), 0);
        Notification notification = new Notification();
        notification.icon = 17301633;
        notification.flags |= 16;
        notification.contentView = contentView;
        notification.contentIntent = contentIntent;
        return notification;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendDownloaderCallback() {
    }

    private void startFileDownload(final String urlString, final File file, final String title) {
        this.myDownloadingURLs.add(urlString);
        sendDownloaderCallback();
        final int notificationId = NetworkNotifications.Instance().getBookDownloadingId();
        final Notification progressNotification = createDownloadProgressNotification(title);
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        this.myOngoingNotifications.add(Integer.valueOf(notificationId));
        notificationManager.notify(notificationId, progressNotification);
        final Handler progressHandler = new Handler() { // from class: com.baoyi.audio.service.Mp3DownloaderService.1
            @Override // android.os.Handler
            public void handleMessage(Message message) {
                int progress = message.what;
                RemoteViews contentView = progressNotification.contentView;
                if (progress < 0) {
                    contentView.setTextViewText(2131296331, "");
                    contentView.setProgressBar(2131296333, 100, 0, true);
                } else {
                    contentView.setTextViewText(2131296331, progress + "%");
                    contentView.setProgressBar(2131296333, 100, progress, false);
                }
                NotificationManager notificationManager2 = (NotificationManager) Mp3DownloaderService.this.getSystemService("notification");
                notificationManager2.notify(notificationId, progressNotification);
            }
        };
        final Handler downloadFinishHandler = new Handler() { // from class: com.baoyi.audio.service.Mp3DownloaderService.2
            @Override // android.os.Handler
            public void handleMessage(Message message) {
                Mp3DownloaderService.this.myDownloadingURLs.remove(urlString);
                NotificationManager notificationManager2 = (NotificationManager) Mp3DownloaderService.this.getSystemService("notification");
                notificationManager2.cancel(notificationId);
                Mp3DownloaderService.this.myOngoingNotifications.remove(Integer.valueOf(notificationId));
                notificationManager2.notify(notificationId, Mp3DownloaderService.this.createDownloadFinishNotification(file, title, message.what != 0));
                Mp3DownloaderService.this.sendDownloaderCallback();
                Mp3DownloaderService.this.doStop();
            }
        };
        final ZLNetworkRequest request = new ZLNetworkRequest(urlString, null, null) { // from class: com.baoyi.audio.service.Mp3DownloaderService.3
            @Override // com.baoyi.download.core.network.ZLNetworkRequest
            public void handleStream(InputStream inputStream, int length) throws IOException, ZLNetworkException {
                int downloadedPart = 0;
                long progressTime = System.currentTimeMillis() + 1000;
                if (length <= 0) {
                    progressHandler.sendEmptyMessage(-1);
                }
                try {
                    OutputStream outStream = new FileOutputStream(file);
                    try {
                        byte[] buffer = new byte[8192];
                        while (true) {
                            int size = inputStream.read(buffer);
                            if (size > 0) {
                                downloadedPart += size;
                                if (length > 0) {
                                    long currentTime = System.currentTimeMillis();
                                    if (currentTime > progressTime) {
                                        progressTime = currentTime + 1000;
                                        progressHandler.sendEmptyMessage((downloadedPart * 100) / length);
                                    }
                                }
                                outStream.write(buffer, 0, size);
                            } else {
                                return;
                            }
                        }
                    } finally {
                        outStream.close();
                    }
                } catch (FileNotFoundException e) {
                    throw new ZLNetworkException(ZLNetworkException.ERROR_CREATE_FILE, file.getPath());
                }
            }
        };
        Thread downloader = new Thread(new Runnable() { // from class: com.baoyi.audio.service.Mp3DownloaderService.4
            @Override // java.lang.Runnable
            public void run() {
                boolean success = false;
                try {
                    try {
                        ZLNetworkManager.Instance().perform(request);
                        success = true;
                        MusicUtils.copytoring(file);
                        downloadFinishHandler.sendEmptyMessage(1 == 0 ? 0 : 1);
                    } catch (ZLNetworkException e) {
                        e.printStackTrace();
                        file.delete();
                        downloadFinishHandler.sendEmptyMessage(success ? 1 : 0);
                    }
                } catch (Throwable th) {
                    downloadFinishHandler.sendEmptyMessage(success ? 1 : 0);
                    throw th;
                }
            }
        });
        downloader.setPriority(10);
        downloader.start();
    }

    @Override // android.app.Service
    public IBinder onBind(Intent arg0) {
        return null;
    }
}
