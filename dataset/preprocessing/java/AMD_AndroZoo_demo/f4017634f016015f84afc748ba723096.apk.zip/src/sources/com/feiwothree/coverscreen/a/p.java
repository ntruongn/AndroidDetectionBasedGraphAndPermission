package com.feiwothree.coverscreen.a;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import java.io.File;
import java.util.Date;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class p implements Runnable {
    private /* synthetic */ n a;
    private final /* synthetic */ boolean b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(n nVar, boolean z) {
        this.a = nVar;
        this.b = z;
    }

    @Override // java.lang.Runnable
    public final void run() {
        C0013i c0013i;
        C0013i c0013i2;
        C0013i c0013i3;
        C0013i c0013i4;
        if (!this.b) {
            c0013i4 = this.a.h;
            x.a(c0013i4.d).a(this.a.b.e() + 12345, 17301586, this.a.b.a(), this.a.b.a(), "下载失败", new Intent(), 16, this.a.b.b(), this.a.d);
            return;
        }
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(268435456);
        intent.setDataAndType(Uri.fromFile(new File(this.a.c)), "application/vnd.android.package-archive");
        c0013i = this.a.h;
        x.a(c0013i.d).a(this.a.b.e() + 12345, 17301586, this.a.b.a(), this.a.b.a(), "下载完成，点击安装", intent, 18, this.a.b.b(), this.a.d);
        c0013i2 = this.a.h;
        I.b(c0013i2.d, "DP_FEIWO", this.a.b.c().replace(".", ""), String.valueOf(this.a.b.e()) + "," + new Date().getTime());
        try {
            z.a();
            c0013i3 = this.a.h;
            z.a(c0013i3.d, this.a.c);
        } catch (Exception e) {
            Log.e("D", new StringBuilder().append(e).toString());
        }
    }
}
