package com.baoyi.audio.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.baoyi.audio.service.DownloadService;
import com.baoyi.audio.service.Mp3DownloaderService;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.task.DownTask;
import com.baoyi.audio.task.RecommendPubTask;
import com.baoyi.audio.task.SetAudioTask;
import com.baoyi.audio.utils.content;
import com.baoyi.db.MessageShowManager;
import com.baoyi.doamin.CheckWork;
import com.baoyi.utils.MusicUtils;
import com.baoyi.utils.Utils;
import com.hope.leyuan.R;
import com.iring.entity.Message;
import com.iring.entity.RingRecommend;
import com.iring.rpc.RpcSerializable;
import java.io.File;
import java.io.IOException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class AsyncMusicPlayerFragment extends Fragment {
    private static final int REQUEST_CODE_EDIT = 1;
    private static final long maxtimeout = 4000;
    private int curPosition;
    private TextView currenttime;
    private int failplaysize;
    ImageButton mPauseButton;
    private boolean mWasGetContentIntent;
    private TextView message;
    private MediaPlayer myMediaPlayer;
    private String name;
    private SeekBar progress;
    private long selecttime;
    private Button setdown;
    private Button setmessage;
    private Button setnotice;
    private Button setring;
    private TextView totaltime;
    private Uri uri;
    CheckWork checked = new CheckWork();
    private String url = "";
    private int musicid = 0;
    private MediaPlayer.OnPreparedListener mediaPreparedListener = new MediaPlayer.OnPreparedListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.1
        @Override // android.media.MediaPlayer.OnPreparedListener
        public void onPrepared(MediaPlayer mp) {
            AsyncMusicPlayerFragment.this.init();
            AsyncMusicPlayerFragment.this.enablebuttons();
            AsyncMusicPlayerFragment.this.progress.setMax(AsyncMusicPlayerFragment.this.myMediaPlayer.getDuration());
            AsyncMusicPlayerFragment.this.myHandler.sendEmptyMessage(1);
            AsyncMusicPlayerFragment.this.myMediaPlayer.start();
            AsyncMusicPlayerFragment.this.message.setVisibility(0);
            AsyncMusicPlayerFragment.this.setPauseButtonImage();
            AsyncMusicPlayerFragment.this.totaltime.setText(MusicUtils.makeTimeString(AsyncMusicPlayerFragment.this.getActivity(), AsyncMusicPlayerFragment.this.myMediaPlayer.getDuration() / 1000));
            SharedPreferences sharedPreferences = AsyncMusicPlayerFragment.this.getActivity().getSharedPreferences("com.iym.imusic_preferences", 0);
            boolean iscached = sharedPreferences.getBoolean("iscached", false);
            if (!iscached) {
                return;
            }
            AsyncMusicPlayerFragment.this.downfile();
        }
    };
    int failsizee = 0;
    private SeekBar.OnSeekBarChangeListener seekbarChangeListener = new SeekBar.OnSeekBarChangeListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.2
        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            if (fromUser && AsyncMusicPlayerFragment.this.myMediaPlayer != null && AsyncMusicPlayerFragment.this.myMediaPlayer.isPlaying()) {
                AsyncMusicPlayerFragment.this.myMediaPlayer.seekTo(progress);
            }
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    };
    private Handler myHandler = new Handler();
    private Runnable works = new Runnable() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.3
        @Override // java.lang.Runnable
        public void run() {
            AsyncMusicPlayerFragment.this.countTime();
            AsyncMusicPlayerFragment.this.progress.setProgress(AsyncMusicPlayerFragment.this.curPosition);
            AsyncMusicPlayerFragment.this.myHandler.postDelayed(AsyncMusicPlayerFragment.this.works, 1000L);
        }
    };

    /* JADX INFO: Access modifiers changed from: private */
    public void downring() {
        RingRecommend ringRecommend = new RingRecommend();
        ringRecommend.setAddtime(System.currentTimeMillis());
        ringRecommend.setCatalog(2);
        ringRecommend.setCatalogname("下载");
        ringRecommend.setMusicname(this.name);
        ringRecommend.setMusicid(this.musicid);
        ringRecommend.setMusicpath(this.url);
        ringRecommend.setMemberid(getUserid());
        ringRecommend.setMembername(getMemberName());
        ringRecommend.setMemberpicture(getMemberpicture());
        new RecommendPubTask(ringRecommend, getActivity()).execute(new RpcSerializable[0]);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setring() {
        RingRecommend ringRecommend = new RingRecommend();
        ringRecommend.setAddtime(System.currentTimeMillis());
        ringRecommend.setCatalog(5);
        ringRecommend.setCatalogname("设置了铃声");
        ringRecommend.setMusicname(this.name);
        ringRecommend.setMusicid(this.musicid);
        ringRecommend.setMusicpath(this.url);
        ringRecommend.setMemberid(getUserid());
        ringRecommend.setMembername(getMemberName());
        ringRecommend.setMemberpicture(getMemberpicture());
        new RecommendPubTask(ringRecommend, getActivity()).execute(new RpcSerializable[0]);
    }

    private String getMemberpicture() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("apps", 0);
        return sharedPreferences.getString("memberpicture", "/iringdata/images/mnopig.gif");
    }

    private String getMemberName() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("apps", 0);
        return sharedPreferences.getString(UpdateService.NAME, "游客");
    }

    @Override // android.support.v4.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        relasePlayer();
    }

    public int getUserid() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("apps", 0);
        return sharedPreferences.getInt(UpdateService.USERID, -1);
    }

    @Override // android.support.v4.app.Fragment
    public void onPause() {
        try {
            if (this.myHandler != null) {
                Log.i("ada", "停止更新时间线程");
                this.myHandler.removeCallbacks(this.works);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onPause();
    }

    @Override // android.support.v4.app.Fragment
    public void onStop() {
        super.onStop();
        if (this.myMediaPlayer != null && this.myMediaPlayer.isPlaying()) {
            this.myMediaPlayer.pause();
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        init();
        super.onResume();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void downfile() {
        String files = String.valueOf(content.SAVEDIR) + this.name + ".mp3";
        File file = new File(files);
        if (!file.exists() && Utils.readSDCardMB() > 30) {
            Intent intent = new Intent(getActivity(), (Class<?>) DownloadService.class);
            intent.setAction(DownloadService.ACTION_ADD_TO_DOWNLOAD);
            intent.putExtra(UpdateService.NAME, this.name);
            intent.putExtra("url", getmp3Path());
            intent.putExtra("isfront", false);
            getActivity().startService(intent);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doPauseResume() {
        try {
            if (this.myMediaPlayer != null) {
                if (this.myMediaPlayer.isPlaying()) {
                    this.myMediaPlayer.pause();
                } else {
                    this.myMediaPlayer.start();
                }
                setPauseButtonImage();
            }
        } catch (Exception e) {
        }
    }

    public void init() {
        this.myHandler.postDelayed(this.works, 1000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void countTime() {
        if (this.myMediaPlayer != null) {
            if (this.myMediaPlayer.getCurrentPosition() != 0) {
                this.curPosition = this.myMediaPlayer.getCurrentPosition();
                this.currenttime.setText(MusicUtils.makeTimeString(getActivity(), this.curPosition / 1000));
            }
            if (this.myMediaPlayer.isPlaying()) {
                this.currenttime.setVisibility(0);
            } else {
                int vis = this.currenttime.getVisibility();
                this.currenttime.setVisibility(vis != 4 ? 4 : 0);
            }
        }
    }

    private void bindevents() {
        this.setring.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                AsyncMusicPlayerFragment.this.setring();
                new DownTask().execute(Integer.valueOf(AsyncMusicPlayerFragment.this.musicid));
                if (Utils.IsCanUseSdCard()) {
                    AsyncMusicPlayerFragment.this.checked = new CheckWork();
                    AsyncMusicPlayerFragment.this.checked.setIsringtones(true);
                    AsyncMusicPlayerFragment.this.setring.setBackgroundResource(R.drawable.music_play_settting_select);
                    new SetAudioTask(AsyncMusicPlayerFragment.this.getActivity(), AsyncMusicPlayerFragment.this.checked).execute(AsyncMusicPlayerFragment.this.getmp3Path(), AsyncMusicPlayerFragment.this.name);
                    return;
                }
                Toast.makeText(AsyncMusicPlayerFragment.this.getActivity(), "sd卡不可用,请检查你的sd卡", 1).show();
            }
        });
        this.setmessage.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.5
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                AsyncMusicPlayerFragment.this.setring();
                new DownTask().execute(Integer.valueOf(AsyncMusicPlayerFragment.this.musicid));
                if (Utils.IsCanUseSdCard()) {
                    AsyncMusicPlayerFragment.this.setmessage.setBackgroundResource(R.drawable.music_play_settting_select);
                    AsyncMusicPlayerFragment.this.checked = new CheckWork();
                    AsyncMusicPlayerFragment.this.checked.setIsnotifications(true);
                    new SetAudioTask(AsyncMusicPlayerFragment.this.getActivity(), AsyncMusicPlayerFragment.this.checked).execute(AsyncMusicPlayerFragment.this.getmp3Path(), AsyncMusicPlayerFragment.this.name);
                    return;
                }
                Toast.makeText(AsyncMusicPlayerFragment.this.getActivity(), "sd卡不可用,请检查你的sd卡", 1).show();
            }
        });
        this.setnotice.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.6
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                AsyncMusicPlayerFragment.this.setring();
                new DownTask().execute(Integer.valueOf(AsyncMusicPlayerFragment.this.musicid));
                if (Utils.IsCanUseSdCard()) {
                    AsyncMusicPlayerFragment.this.setnotice.setBackgroundResource(R.drawable.music_play_settting_select);
                    AsyncMusicPlayerFragment.this.checked = new CheckWork();
                    AsyncMusicPlayerFragment.this.checked.setIsalarms(true);
                    new SetAudioTask(AsyncMusicPlayerFragment.this.getActivity(), AsyncMusicPlayerFragment.this.checked).execute(AsyncMusicPlayerFragment.this.getmp3Path(), AsyncMusicPlayerFragment.this.name);
                    return;
                }
                Toast.makeText(AsyncMusicPlayerFragment.this.getActivity(), "sd卡不可用,请检查你的sd卡", 1).show();
            }
        });
        this.mPauseButton.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.7
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                AsyncMusicPlayerFragment.this.doPauseResume();
            }
        });
        this.progress.setOnSeekBarChangeListener(this.seekbarChangeListener);
        this.setdown.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.8
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                new DownTask().execute(Integer.valueOf(AsyncMusicPlayerFragment.this.musicid));
                AsyncMusicPlayerFragment.this.downring();
                String ext = AsyncMusicPlayerFragment.this.url.substring(AsyncMusicPlayerFragment.this.url.lastIndexOf("."));
                String files = String.valueOf(content.SAVEDIR) + AsyncMusicPlayerFragment.this.name + ext;
                File file = new File(files);
                if (file.exists()) {
                    AsyncMusicPlayerFragment.this.setdown.setBackgroundResource(R.drawable.music_play_settting_select);
                    AsyncMusicPlayerFragment.this.buildDialog1(AsyncMusicPlayerFragment.this.getActivity(), AsyncMusicPlayerFragment.this.url, AsyncMusicPlayerFragment.this.name).show();
                } else {
                    AsyncMusicPlayerFragment.this.downmp3(true);
                }
            }
        });
    }

    private void disablebuttons() {
        this.mPauseButton.setEnabled(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void enablebuttons() {
        this.mPauseButton.setEnabled(true);
    }

    public String getmp3Path() {
        return this.url;
    }

    private void playAudio() {
        String files = String.valueOf(content.SAVEDIR) + this.name + ".mp3";
        File file = new File(files);
        if (file.exists()) {
            this.url = "file://" + files;
            setPath(this.url);
        } else {
            this.progress.setSecondaryProgress(0);
            this.progress.setProgress(0);
            this.currenttime.setText("0:00");
            setPath(this.url);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Dialog buildDialog1(Context t, String fileurl1, String musicName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(t);
        builder.setIcon(R.drawable.download);
        builder.setTitle("确定重新下载" + musicName + "吗？");
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.9
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                AsyncMusicPlayerFragment.this.downmp3(true);
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.10
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        return builder.create();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void downmp3(boolean isshowmsg) {
        if (Utils.IsCanUseSdCard()) {
            String files = String.valueOf(content.SAVEDIR) + this.name + ".mp3";
            Intent intent = new Intent(getActivity(), (Class<?>) Mp3DownloaderService.class);
            intent.setAction(DownloadService.ACTION_ADD_TO_DOWNLOAD);
            intent.putExtra(UpdateService.FILENAME, files);
            intent.putExtra("url", getmp3Path());
            intent.putExtra("title", this.name);
            getActivity().startService(intent);
            return;
        }
        if (isshowmsg) {
            Toast.makeText(getActivity(), "sd卡不可用,请检查你的sd卡", 1).show();
        }
    }

    private void bindViews() {
        this.progress = (SeekBar) getView().findViewById(R.id.progress);
        this.currenttime = (TextView) getView().findViewById(R.id.currenttime);
        this.totaltime = (TextView) getView().findViewById(R.id.totaltime);
        this.mPauseButton = (ImageButton) getView().findViewById(R.id.pause);
        this.setdown = (Button) getView().findViewById(R.id.setdown);
        this.setmessage = (Button) getView().findViewById(R.id.setmessage);
        this.setnotice = (Button) getView().findViewById(R.id.setnotice);
        this.setring = (Button) getView().findViewById(R.id.setring);
        this.message = (TextView) getView().findViewById(R.id.message);
    }

    private void relasePlayer() {
        if (this.myMediaPlayer != null) {
            this.myMediaPlayer.reset();
            this.myMediaPlayer.release();
            this.myMediaPlayer = null;
        }
    }

    public void setPath(String uriString) {
        try {
            disablebuttons();
            this.uri = Uri.parse(uriString);
            relasePlayer();
            this.myMediaPlayer = new MediaPlayer();
            this.myMediaPlayer.setLooping(true);
            this.myMediaPlayer.setOnPreparedListener(this.mediaPreparedListener);
            this.myMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.11
                @Override // android.media.MediaPlayer.OnErrorListener
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    AsyncMusicPlayerFragment.this.url = null;
                    AsyncMusicPlayerFragment.this.failplaysize++;
                    return false;
                }
            });
            this.myMediaPlayer.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.12
                @Override // android.media.MediaPlayer.OnBufferingUpdateListener
                public void onBufferingUpdate(MediaPlayer mp, int percent) {
                    int secondaryProgress = (int) ((percent / 100.0f) * AsyncMusicPlayerFragment.this.progress.getMax());
                    AsyncMusicPlayerFragment.this.progress.setSecondaryProgress(secondaryProgress);
                }
            });
            this.myMediaPlayer.setDataSource(getActivity(), this.uri);
            Runnable ting = new Runnable() { // from class: com.baoyi.audio.fragment.AsyncMusicPlayerFragment.13
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        AsyncMusicPlayerFragment.this.myMediaPlayer.prepare();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (IllegalStateException e2) {
                        e2.printStackTrace();
                    }
                }
            };
            new Thread(ting).start();
            this.failplaysize = 0;
        } catch (Exception e) {
            this.failplaysize++;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setPauseButtonImage() {
        try {
            if (this.myMediaPlayer != null && this.myMediaPlayer.isPlaying()) {
                this.mPauseButton.setImageResource(R.drawable.play);
            } else {
                this.mPauseButton.setImageResource(R.drawable.stop);
            }
        } catch (Exception e) {
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        bindViews();
        bindevents();
        this.name = getArguments().getString(UpdateService.NAME);
        this.url = getArguments().getString("fileurl");
        this.musicid = getArguments().getInt("musicid", -1);
        this.message.setText(getOneMessage());
        playAudio();
    }

    public String getOneMessage() {
        String str = "好铃声，天天好心情。";
        MessageShowManager manger = new MessageShowManager(getActivity());
        int a = getNum();
        int p = ((int) (Math.random() * a)) + 1;
        for (int i = 0; i < 5; i++) {
            try {
                Message msg = manger.getMessage(p);
                str = msg.getMessage();
                if (msg != null) {
                    break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return str;
    }

    public int getNum() {
        MessageShowManager manger = new MessageShowManager(getActivity());
        int a = manger.getNum();
        return a;
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.ui_audioplay, container, false);
        return view;
    }
}
