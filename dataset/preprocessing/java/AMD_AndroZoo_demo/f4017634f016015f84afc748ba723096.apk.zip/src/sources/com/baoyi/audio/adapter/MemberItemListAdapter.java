package com.baoyi.audio.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import com.baoyi.adapter.ItemListAdapter;
import com.baoyi.audio.ZoneActivity;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.widget.MemberItem;
import com.hope.leyuan.R;
import com.iring.entity.Member;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MemberItemListAdapter extends ItemListAdapter<Member> implements AdapterView.OnItemClickListener {
    long time;

    public MemberItemListAdapter(Context context) {
        super(context);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        if (arg1 instanceof MemberItem) {
            Animation animation = AnimationUtils.loadAnimation(this.context, R.anim.showanimationitem);
            arg1.setAnimation(animation);
            MemberItem item = (MemberItem) arg1;
            Member member = item.getMember();
            if (member != null) {
                Intent intent = new Intent(this.context, (Class<?>) ZoneActivity.class);
                intent.putExtra(UpdateService.USERID, member.getId());
                this.context.startActivity(intent);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListAdapter
    public View update(int position, View view, Member item) {
        MemberItem memberItem = (MemberItem) view;
        memberItem.setMember(item);
        memberItem.setTag(memberItem);
        return memberItem;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListAdapter
    public View creatView(int position, Member item) {
        MemberItem memberItem = new MemberItem(this.context);
        memberItem.setMember(item);
        memberItem.setTag(memberItem);
        return memberItem;
    }

    @Override // com.baoyi.adapter.ItemListAdapter
    protected void updateView(int position, View view) {
        int i = position % 2;
    }
}
