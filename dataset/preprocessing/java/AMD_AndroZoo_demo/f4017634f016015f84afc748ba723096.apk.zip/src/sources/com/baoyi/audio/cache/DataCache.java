package com.baoyi.audio.cache;

import android.support.v4.util.LruCache;
import com.iring.entity.Music;
import java.util.HashMap;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class DataCache {
    public static final HashMap<String, List<Music>> datas = new HashMap<>();
    LruCache<String, List<Music>> LRU = new LruCache<>(1000);
}
