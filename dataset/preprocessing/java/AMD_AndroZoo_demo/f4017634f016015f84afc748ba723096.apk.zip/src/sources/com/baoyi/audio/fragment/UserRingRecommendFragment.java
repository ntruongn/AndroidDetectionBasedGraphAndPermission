package com.baoyi.audio.fragment;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.baoyi.audio.adapter.RingRecommendListAdapter;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.dao.RingRecommendDao;
import com.iring.entity.RingRecommend;
import com.iring.rpc.RingRecommendRpc;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class UserRingRecommendFragment extends Fragment {
    RingRecommendListAdapter adapter;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    int type;
    private int userid;
    private boolean work = false;
    int page = 0;

    public UserRingRecommendFragment(int userid) {
        this.userid = userid;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.page = 0;
        this.type = 1;
        this.mPullRefreshListView = (PullToRefreshListView) getView().findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() { // from class: com.baoyi.audio.fragment.UserRingRecommendFragment.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener
            public void onRefresh(PullToRefreshBase<ListView> refreshView) {
                Log.i("ada", "加载");
                if (!UserRingRecommendFragment.this.work) {
                    new HotTask(UserRingRecommendFragment.this, null).execute(Integer.valueOf(UserRingRecommendFragment.this.page));
                }
            }
        });
        WidgetLoadling tv = new WidgetLoadling(getActivity());
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new RingRecommendListAdapter(getActivity(), true);
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setBackgroundColor(17170445);
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("com.iym.iRingRecommend_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(getActivity());
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
        new HotTask(this, null).execute(Integer.valueOf(this.page));
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<RingRecommend>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(UserRingRecommendFragment userRingRecommendFragment, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<RingRecommend> doInBackground(Integer... params) {
            RingRecommendRpc rpc;
            long time = System.currentTimeMillis();
            UserRingRecommendFragment.this.work = true;
            List<RingRecommend> data = null;
            RingRecommendDao dao = (RingRecommendDao) RpcUtils2.getNoCacheDao("ringRecommendDao", RingRecommendDao.class);
            if (dao != null && (rpc = dao.findUserRingRecommend(UserRingRecommendFragment.this.userid, 20, UserRingRecommendFragment.this.page)) != null) {
                data = rpc.getDatas();
            }
            if (System.currentTimeMillis() - time < 1000) {
                try {
                    Thread.sleep(1500L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return data;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<RingRecommend> result) {
            UserRingRecommendFragment.this.work = false;
            UserRingRecommendFragment.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.PULL_UP_TO_REFRESH);
            if (result != null) {
                for (RingRecommend RingRecommend : result) {
                    UserRingRecommendFragment.this.adapter.addLast(RingRecommend);
                }
                UserRingRecommendFragment.this.adapter.notifyDataSetChanged();
                UserRingRecommendFragment.this.mPullRefreshListView.onRefreshComplete();
                UserRingRecommendFragment.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + UserRingRecommendFragment.this.adapter.getCount() + "条数据");
                UserRingRecommendFragment.this.page++;
                return;
            }
            if (UserRingRecommendFragment.this.page == 0) {
                UserRingRecommendFragment.this.mPullRefreshListView.setEmptyView(null);
                Activity activity = UserRingRecommendFragment.this.getActivity();
                if (activity != null) {
                    Toast.makeText(activity, "获取数据失败，请稍候再试。", 0).show();
                }
            }
            UserRingRecommendFragment.this.mPullRefreshListView.onRefreshComplete();
        }
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_new, container, false);
        return view;
    }
}
