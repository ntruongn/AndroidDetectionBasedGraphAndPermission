package com.baoyi.audio.cache;

import android.support.v4.util.LruCache;
import com.baidu.kirin.KirinConfig;
import org.json.rpc.cache.RpcStringCache;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MyCache implements RpcStringCache {
    public static MyCache myCache;
    private LruCache<String, String> cache = new LruCache<>(KirinConfig.READ_TIME_OUT);

    private MyCache() {
    }

    public static MyCache getMyCache() {
        if (myCache == null) {
            myCache = new MyCache();
        }
        return myCache;
    }

    @Override // org.json.rpc.cache.RpcStringCache
    public void clearall() {
    }

    @Override // org.json.rpc.cache.RpcStringCache
    public String get(String arg0) {
        return this.cache.get(arg0);
    }

    @Override // org.json.rpc.cache.RpcStringCache
    public void put(String arg0, String arg1) {
        this.cache.put(arg0, arg1);
    }
}
