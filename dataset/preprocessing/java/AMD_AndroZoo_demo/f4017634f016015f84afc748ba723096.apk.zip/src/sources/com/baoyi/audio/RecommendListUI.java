package com.baoyi.audio;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.baoyi.audio.adapter.MusicItemListAdapter;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RecommendListUI extends AnalyticsUI {
    MusicItemListAdapter adapter;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    int page = 0;
    private TextView title;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.baoyi.audio.AnalyticsUI, com.baoyi.audio.BugActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_list_hot);
        this.title = (TextView) findViewById(R.id.typetitle);
        this.title.setText("推荐铃声");
        this.mPullRefreshListView = (PullToRefreshListView) findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() { // from class: com.baoyi.audio.RecommendListUI.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            }

            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                new HotTask(RecommendListUI.this, null).execute(Integer.valueOf(RecommendListUI.this.page));
            }
        });
        WidgetLoadling tv = new WidgetLoadling(this);
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new MusicItemListAdapter(this);
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getSharedPreferences("com.iym.imusic_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(this);
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        new HotTask(this, null).execute(Integer.valueOf(this.page));
        this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Music>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(RecommendListUI recommendListUI, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Music> doInBackground(Integer... params) {
            try {
                List<Music> temp = RpcUtils2.getMusicDao().pageByRecommend(content.showsize, params[0].intValue()).getDatas();
                return temp;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Music> result) {
            RecommendListUI.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.PULL_UP_TO_REFRESH);
            if (result != null) {
                for (Music music : result) {
                    RecommendListUI.this.adapter.addLast(music);
                }
                RecommendListUI.this.adapter.notifyDataSetChanged();
                RecommendListUI.this.mPullRefreshListView.onRefreshComplete();
                RecommendListUI.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + RecommendListUI.this.adapter.getCount() + "首铃声");
                RecommendListUI.this.page++;
                return;
            }
            if (RecommendListUI.this.page == 0) {
                RecommendListUI.this.mPullRefreshListView.setEmptyView(null);
                Toast.makeText(RecommendListUI.this, "获取数据失败，请稍候再试。", 0).show();
            }
            RecommendListUI.this.mPullRefreshListView.onRefreshComplete();
        }
    }
}
