package com.baoyi.audio.widget;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class TabPageIndicator1 extends HorizontalScrollView implements ViewPager.OnPageChangeListener, View.OnClickListener {
    private ViewPager.OnPageChangeListener mListener;
    private int mSelectedTabIndex;
    private final LinearLayout mTabLayout;
    Runnable mTabSelector;
    private ViewPager mViewPager;

    public TabPageIndicator1(Context context) {
        this(context, null);
    }

    public TabPageIndicator1(Context context, AttributeSet attrs) {
        super(context, attrs);
        setHorizontalScrollBarEnabled(false);
        this.mTabLayout = new LinearLayout(getContext());
        addView(this.mTabLayout, new ViewGroup.LayoutParams(-2, -1));
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int widthMode = View.MeasureSpec.getMode(widthMeasureSpec);
        boolean lockedExpanded = widthMode == 1073741824;
        setFillViewport(lockedExpanded);
        int oldWidth = getMeasuredWidth();
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int newWidth = getMeasuredWidth();
        if (lockedExpanded && oldWidth != newWidth) {
            setCurrentItem(this.mSelectedTabIndex);
        }
    }

    private void animateToTab(int position) {
        final View tabView = this.mTabLayout.getChildAt(position);
        if (this.mTabSelector != null) {
            removeCallbacks(this.mTabSelector);
        }
        this.mTabSelector = new Runnable() { // from class: com.baoyi.audio.widget.TabPageIndicator1.1
            @Override // java.lang.Runnable
            public void run() {
                int scrollPos = tabView.getLeft() - ((TabPageIndicator1.this.getWidth() - tabView.getWidth()) / 2);
                TabPageIndicator1.this.smoothScrollTo(scrollPos, 0);
                TabPageIndicator1.this.mTabSelector = null;
            }
        };
        post(this.mTabSelector);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.mTabSelector != null) {
            post(this.mTabSelector);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.mTabSelector != null) {
            removeCallbacks(this.mTabSelector);
        }
    }

    private void addTab(CharSequence text, int index) {
        Context context = getContext();
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        int padX = (int) TypedValue.applyDimension(1, 3.0f, dm);
        int padY = (int) TypedValue.applyDimension(1, 2.0f, dm);
        TextView tabView = new TextView(context);
        tabView.setPadding(padX, padY, padX, padY);
        tabView.setGravity(17);
        tabView.setTextColor(-789517);
        tabView.setTextSize(2, 18.0f);
        tabView.setTypeface(tabView.getTypeface(), 1);
        tabView.setSingleLine();
        tabView.setTag(Integer.valueOf(index));
        tabView.setFocusable(true);
        tabView.setOnClickListener(this);
        tabView.setText(text);
        ViewGroup.LayoutParams pas = new LinearLayout.LayoutParams(-2, -1, 0.0f);
        ViewGroup.MarginLayoutParams params = new ViewGroup.MarginLayoutParams(pas);
        params.setMargins(0, 2, 0, 0);
        tabView.setLayoutParams(params);
        tabView.setPadding(20, 0, 20, 0);
        LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(params);
        this.mTabLayout.addView(tabView, params2);
    }

    @Override // android.support.v4.view.ViewPager.OnPageChangeListener
    public void onPageScrollStateChanged(int arg0) {
        if (this.mListener != null) {
            this.mListener.onPageScrollStateChanged(arg0);
        }
    }

    @Override // android.support.v4.view.ViewPager.OnPageChangeListener
    public void onPageScrolled(int arg0, float arg1, int arg2) {
        if (this.mListener != null) {
            this.mListener.onPageScrolled(arg0, arg1, arg2);
        }
    }

    @Override // android.support.v4.view.ViewPager.OnPageChangeListener
    public void onPageSelected(int arg0) {
        setCurrentItem(arg0);
        if (this.mListener != null) {
            this.mListener.onPageSelected(arg0);
        }
    }

    public void setViewPager(ViewPager view) {
        PagerAdapter adapter = view.getAdapter();
        if (adapter == null) {
            throw new IllegalStateException("ViewPager does not have adapter instance.");
        }
        this.mViewPager = view;
        view.setOnPageChangeListener(this);
        notifyDataSetChanged();
    }

    public void notifyDataSetChanged() {
        this.mTabLayout.removeAllViews();
        PagerAdapter adapter = this.mViewPager.getAdapter();
        int count = adapter.getCount();
        for (int i = 0; i < count; i++) {
            addTab(adapter.getPageTitle(i), i);
        }
        if (this.mSelectedTabIndex > count) {
            this.mSelectedTabIndex = count - 1;
        }
        setCurrentItem(this.mSelectedTabIndex);
        requestLayout();
    }

    public void setCurrentItem(int item) {
        if (this.mViewPager == null) {
            throw new IllegalStateException("ViewPager has not been bound.");
        }
        this.mSelectedTabIndex = item;
        int tabCount = this.mTabLayout.getChildCount();
        int i = 0;
        while (i < tabCount) {
            TextView child = (TextView) this.mTabLayout.getChildAt(i);
            boolean isSelected = i == item;
            child.setSelected(isSelected);
            child.setBackgroundResource(R.drawable.music_play_select_normal);
            child.setTextColor(-16777216);
            if (isSelected) {
                int c = getResources().getColor(R.color.frame_button_text_select);
                child.setTextColor(c);
                animateToTab(item);
                child.setBackgroundResource(R.drawable.music_play_select);
            }
            i++;
        }
    }

    public void setOnPageChangeListener(ViewPager.OnPageChangeListener listener) {
        this.mListener = listener;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        this.mViewPager.setCurrentItem(((Integer) view.getTag()).intValue());
    }
}
