package com.baoyi.audio.adapter;

import android.content.Context;
import android.view.View;
import android.widget.AdapterView;
import com.baoyi.adapter.ItemListAdapter;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.CommentsItem;
import com.baoyi.audio.widget.MusiceItem;
import com.iring.entity.Comment;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class CommentItemListAdapter extends ItemListAdapter<Comment> implements AdapterView.OnItemClickListener {
    long time;

    public CommentItemListAdapter(Context context) {
        super(context);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
    }

    private String geturl(MusiceItem item) {
        String url = item.getWorkItem().getUrl();
        if (url != null && !url.startsWith("http")) {
            return String.valueOf(content.mp3server) + url;
        }
        return url;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListAdapter
    public View update(int position, View view, Comment item) {
        CommentsItem commentsItem = (CommentsItem) view;
        commentsItem.setComment(item);
        commentsItem.setTag(commentsItem);
        return commentsItem;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.adapter.ItemListAdapter
    public View creatView(int position, Comment item) {
        CommentsItem commentsItem = new CommentsItem(this.context);
        commentsItem.setComment(item);
        commentsItem.setTag(commentsItem);
        return commentsItem;
    }

    @Override // com.baoyi.adapter.ItemListAdapter
    protected void updateView(int position, View view) {
        int i = position % 2;
    }
}
