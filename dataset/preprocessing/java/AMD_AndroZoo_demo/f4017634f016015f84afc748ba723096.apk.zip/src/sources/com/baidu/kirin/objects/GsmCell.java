package com.baidu.kirin.objects;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class GsmCell extends SCell {
    public int CID;
    public int LAC;

    @Override // com.baidu.kirin.objects.SCell
    public String toString() {
        return this.cellType + "," + this.MCCMNC + "," + this.MCC + "," + this.MNC + "" + this.LAC + "," + this.CID;
    }
}
