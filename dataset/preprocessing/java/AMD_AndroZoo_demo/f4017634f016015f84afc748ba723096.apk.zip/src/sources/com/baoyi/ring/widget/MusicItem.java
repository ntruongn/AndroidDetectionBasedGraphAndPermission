package com.baoyi.ring.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import com.hope.leyuan.R;
import com.iring.entity.Music;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MusicItem extends LinearLayout {
    private TextView downTimes;
    private LinearLayout hid;
    private TextView hot;
    private Music m;
    private TextView musicName;
    private ImageView play;
    private SeekBar seekBar;
    private ImageView share;
    private TextView singer;
    private ImageView stop;
    private TextView time;
    private ImageView useAs;

    public MusicItem(Context context) {
        super(context);
        LayoutInflater.from(context).inflate(R.layout.widget_ring_webmusic, (ViewGroup) null);
        this.play = (ImageView) findViewById(R.id.item_ring_playBtn);
        this.stop = (ImageView) findViewById(R.id.item_ring_puseBtn);
        this.share = (ImageView) findViewById(R.id.item_ring_shareBtn);
        this.useAs = (ImageView) findViewById(R.id.item_ring_useAsBtn);
        this.musicName = (TextView) findViewById(R.id.item_ring_musicNameTv);
        this.time = (TextView) findViewById(R.id.item_ring_timeTv);
        this.musicName = (TextView) findViewById(R.id.item_ring_musicNameTv);
        this.singer = (TextView) findViewById(R.id.item_ring_singerNameTv);
        this.hot = (TextView) findViewById(R.id.item_ring_hotsTv);
        this.downTimes = (TextView) findViewById(R.id.item_ring_downloadtimesTv);
        this.seekBar = (SeekBar) findViewById(R.id.item_ring_SeekBar);
        this.hid = (LinearLayout) findViewById(R.id.item_ring_hidLl);
    }

    public void setMusic(Music music) {
        this.musicName.setText(new StringBuilder(String.valueOf(this.m.getName())).toString());
        this.time.setText("00:00");
        this.singer.setText(new StringBuilder(String.valueOf(this.m.getArtist())).toString());
        this.hot.setText("试听" + this.m.getHit());
        this.downTimes.setText("下载" + this.m.getDownload());
    }
}
