package com.baoyi.audio.cache;

import com.baoyi.audio.BaoyiApplication;
import org.json.rpc.cache.RpcStringCache;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MyDiskCach implements RpcStringCache {
    public static MyDiskCach myCache;

    private MyDiskCach() {
    }

    public static MyDiskCach getMyDiskCach() {
        if (myCache == null) {
            myCache = new MyDiskCach();
        }
        return myCache;
    }

    @Override // org.json.rpc.cache.RpcStringCache
    public void clearall() {
    }

    @Override // org.json.rpc.cache.RpcStringCache
    public String get(String arg0) {
        return BaoyiApplication.getInstance().getDiskTextCache().get((Object) arg0);
    }

    @Override // org.json.rpc.cache.RpcStringCache
    public void put(String arg0, String arg1) {
        BaoyiApplication.getInstance().getDiskTextCache().put(arg0, arg1);
    }
}
