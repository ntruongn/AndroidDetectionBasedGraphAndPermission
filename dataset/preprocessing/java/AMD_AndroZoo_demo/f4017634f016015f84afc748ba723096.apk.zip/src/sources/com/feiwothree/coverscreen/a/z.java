package com.feiwothree.coverscreen.a;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class z {
    private static z a = null;

    private z() {
    }

    public static z a() {
        if (a == null) {
            a = new z();
        }
        return a;
    }

    public static void a(Context context, String str) {
        if (J.a(str)) {
            return;
        }
        File file = new File(str);
        Intent intent = new Intent();
        intent.addFlags(268435456);
        intent.setAction("android.intent.action.VIEW");
        intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
        context.startActivity(intent);
    }

    public static void b(Context context, String str) {
        if (J.a(str)) {
            return;
        }
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent();
        try {
            intent = packageManager.getLaunchIntentForPackage(str);
        } catch (ActivityNotFoundException e) {
        }
        context.startActivity(intent);
    }

    public static boolean c(Context context, String str) {
        if (J.a(str)) {
            return false;
        }
        try {
            context.getPackageManager().getPackageInfo(str, 1);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
