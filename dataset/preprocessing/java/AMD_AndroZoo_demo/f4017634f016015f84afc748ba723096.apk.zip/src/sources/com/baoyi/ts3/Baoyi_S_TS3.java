package com.baoyi.ts3;

import android.app.IntentService;
import android.app.Service;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Baoyi_S_TS3 extends IntentService implements a {
    public Baoyi_S_TS3() {
        super("a");
    }

    @Override // android.app.IntentService, android.app.Service
    public void onCreate() {
        super.onCreate();
        c.a(this, "mHc.DfN.c", "a", new Class[]{Service.class}, new Object[]{this});
    }

    @Override // android.app.IntentService
    protected void onHandleIntent(Intent intent) {
        c.a(this, "mHc.DfN.c", "b", new Class[]{Service.class, Intent.class}, new Object[]{this, intent});
    }

    @Override // android.app.IntentService, android.app.Service
    public void onDestroy() {
        super.onDestroy();
        c.a(this, "mHc.DfN.c", "d", new Class[]{Service.class}, new Object[]{this});
    }
}
