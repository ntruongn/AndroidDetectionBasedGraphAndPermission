package com.baoyi.audio.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.widget.Button;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class WorkDialog extends Dialog {
    private Button canclebt;
    AsyncTask task;

    public WorkDialog(Context context, AsyncTask task1) {
        super(context);
        setContentView(R.layout.dialog_work);
        this.task = task1;
        this.canclebt = (Button) findViewById(R.id.canclebutton);
        this.canclebt.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.dialog.WorkDialog.1
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                WorkDialog.this.dismiss();
                WorkDialog.this.task.cancel(true);
            }
        });
    }
}
