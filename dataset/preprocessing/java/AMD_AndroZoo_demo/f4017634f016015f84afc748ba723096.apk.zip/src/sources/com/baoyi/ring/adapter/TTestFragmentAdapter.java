package com.baoyi.ring.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class TTestFragmentAdapter extends FragmentPagerAdapter {
    protected static final String[] CONTENT = {"最新", "分类", "本地", "搜索", "更多"};
    public List<Fragment> fragments;
    private int mCount;

    public TTestFragmentAdapter(FragmentManager fm) {
        super(fm);
        this.fragments = new ArrayList(5);
        this.mCount = CONTENT.length;
    }

    @Override // android.support.v4.app.FragmentPagerAdapter
    public Fragment getItem(int position) {
        return this.fragments.get(position);
    }

    @Override // android.support.v4.view.PagerAdapter
    public int getCount() {
        return this.mCount;
    }

    @Override // android.support.v4.view.PagerAdapter
    public CharSequence getPageTitle(int position) {
        return CONTENT[position % CONTENT.length];
    }

    public void setCount(int count) {
        if (count > 0 && count <= 10) {
            this.mCount = count;
            notifyDataSetChanged();
        }
    }

    public void add(Fragment fragment) {
        this.fragments.add(fragment);
    }
}
