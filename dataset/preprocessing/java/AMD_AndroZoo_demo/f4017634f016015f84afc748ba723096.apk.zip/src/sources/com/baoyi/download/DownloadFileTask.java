package com.baoyi.download;

import android.os.AsyncTask;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class DownloadFileTask extends AsyncTask<Void, Integer, Boolean> {
    DownloadJob mJob;

    public DownloadFileTask(DownloadJob job) {
        this.mJob = job;
    }

    @Override // android.os.AsyncTask
    public void onPreExecute() {
        this.mJob.notifyDownloadStarted();
        super.onPreExecute();
    }

    @Override // android.os.AsyncTask
    public Boolean doInBackground(Void... params) {
        try {
            return downloadFile(this.mJob);
        } catch (IOException e) {
            return false;
        }
    }

    @Override // android.os.AsyncTask
    public void onPostExecute(Boolean result) {
        this.mJob.notifyDownloadEnded();
        super.onPostExecute((DownloadFileTask) result);
    }

    public static Boolean downloadFile(DownloadJob job) throws IOException {
        String mp3Url = job.getUrl();
        String ext = mp3Url.substring(mp3Url.lastIndexOf("."));
        String path = String.valueOf(job.getPath()) + job.getName() + ext;
        String tempname = String.valueOf(job.getPath()) + job.getName() + ".temp";
        Log.i("ada", path);
        Log.i("ada", tempname);
        File tempdown = new File(tempname);
        URL url = new URL(mp3Url);
        URLConnection conn = url.openConnection();
        conn.setDoInput(true);
        int length = conn.getContentLength();
        InputStream is = conn.getInputStream();
        if (length != -1) {
            File fileitem = new File(path);
            FileOutputStream output = new FileOutputStream(tempdown);
            byte[] buffer = new byte[6144];
            int downsize = 0;
            while (true) {
                int count = is.read(buffer);
                if (count == -1) {
                    break;
                }
                output.write(buffer, 0, count);
                downsize += count;
            }
            output.flush();
            tempdown.renameTo(fileitem);
        }
        return true;
    }
}
