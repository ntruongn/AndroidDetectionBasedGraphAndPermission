package com.baoyi.audio.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.hope.leyuan.R;
import com.iring.entity.Comment;
import java.text.SimpleDateFormat;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class CommentsItem extends LinearLayout {
    Comment comment;
    private TextView comments;
    Context curactivity;
    SimpleDateFormat format;
    private TextView putime;
    private TextView username;

    public Comment getComment() {
        return this.comment;
    }

    public void setComment(Comment comment) {
        this.comment = comment;
        if (comment.getName() != null) {
            this.username.setText(comment.getName());
        } else {
            this.username.setText("游客");
        }
        this.comments.setText(comment.getContent());
        try {
            Date date = new Date(comment.getTime());
            this.putime.setText(this.format.format(date));
        } catch (Exception e) {
            Date date2 = new Date();
            this.putime.setText(this.format.format(date2));
        }
    }

    public CommentsItem(Context context) {
        super(context);
        this.format = new SimpleDateFormat("yyyy-MM-dd");
        this.curactivity = context;
        LayoutInflater.from(getContext()).inflate(R.layout.widget_music_comment, this);
        this.username = (TextView) findViewById(R.id.username);
        this.putime = (TextView) findViewById(R.id.putime);
        this.comments = (TextView) findViewById(R.id.comments);
    }
}
