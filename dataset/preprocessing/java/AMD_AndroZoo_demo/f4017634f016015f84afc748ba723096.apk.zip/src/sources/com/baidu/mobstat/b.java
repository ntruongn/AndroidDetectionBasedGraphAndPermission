package com.baidu.mobstat;

import android.content.Context;
import android.telephony.TelephonyManager;
import org.json.JSONException;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class b {
    static String a = "Android";
    String b;
    String f;
    String g;
    int h;
    int i;
    String k;
    String l;
    String m;
    String n;
    String o;
    String p;
    String c = null;
    String d = null;
    int e = -1;
    String j = null;

    public synchronized void a(Context context) {
        if (this.e == -1) {
            com.baidu.mobstat.a.b.d(context, "android.permission.READ_PHONE_STATE");
            com.baidu.mobstat.a.b.d(context, "android.permission.INTERNET");
            com.baidu.mobstat.a.b.d(context, "android.permission.ACCESS_NETWORK_STATE");
            com.baidu.mobstat.a.b.d(context, "android.permission.WRITE_SETTINGS");
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            this.b = CooperService.getOSVersion();
            this.l = CooperService.getPhoneModel();
            this.g = CooperService.getDeviceId(telephonyManager, context);
            this.d = CooperService.getCIUD(context);
            try {
                this.k = CooperService.getOperator(telephonyManager);
            } catch (Exception e) {
                com.baidu.mobstat.a.c.a(e);
            }
            try {
                this.h = x.a(context);
                this.i = x.b(context);
                if (context.getResources().getConfiguration().orientation == 2) {
                    com.baidu.mobstat.a.c.a("stat", "Configuration.ORIENTATION_LANDSCAPE");
                    this.h ^= this.i;
                    this.i = this.h ^ this.i;
                    this.h ^= this.i;
                }
            } catch (Exception e2) {
                com.baidu.mobstat.a.c.a(e2);
            }
            this.j = CooperService.getAppChannel(context);
            this.c = CooperService.getAppKey(context);
            try {
                this.e = CooperService.getAppVersionCode(context);
                this.f = CooperService.getAppVersionName(context);
            } catch (Exception e3) {
                com.baidu.mobstat.a.c.a(e3);
            }
            try {
                if (CooperService.checkCellLocationSetting(context)) {
                    this.m = x.e(context);
                } else {
                    this.m = "0_0_0";
                }
            } catch (Exception e4) {
                com.baidu.mobstat.a.c.a(e4);
            }
            try {
                if (CooperService.checkGPSLocationSetting(context)) {
                    this.n = x.f(context);
                } else {
                    this.n = "";
                }
            } catch (Exception e5) {
                com.baidu.mobstat.a.c.a(e5);
            }
            try {
                if (CooperService.checkWifiLocationSetting(context)) {
                    this.o = x.h(context);
                } else {
                    this.o = "";
                }
            } catch (Exception e6) {
                com.baidu.mobstat.a.c.a(e6);
            }
            try {
                this.p = CooperService.getLinkedWay(context);
            } catch (Exception e7) {
                com.baidu.mobstat.a.c.a(e7);
            }
        }
    }

    public synchronized void b(Context context) {
        if (DataCore.a().length() <= 0) {
            a(context);
            try {
                DataCore.a().put("o", a == null ? "" : a);
                DataCore.a().put("s", this.b == null ? "" : this.b);
                DataCore.a().put("k", this.c == null ? "" : this.c);
                DataCore.a().put("i", this.d == null ? "" : this.d);
                DataCore.a().put("v", "3.4");
                DataCore.a().put("a", this.e);
                DataCore.a().put("n", this.f == null ? "" : this.f);
                DataCore.a().put("d", this.g == null ? "" : this.g);
                DataCore.a().put("w", this.h);
                DataCore.a().put("h", this.i);
                DataCore.a().put("c", this.j == null ? "" : this.j);
                DataCore.a().put("op", this.k == null ? "" : this.k);
                DataCore.a().put("m", this.l == null ? "" : this.l);
                DataCore.a().put("cl", this.m);
                DataCore.a().put("gl", this.n == null ? "" : this.n);
                DataCore.a().put("wl", this.o == null ? "" : this.o);
                DataCore.a().put("l", this.p == null ? "" : this.p);
                DataCore.a().put("t", System.currentTimeMillis());
                DataCore.a().put("sq", 0);
                com.baidu.mobstat.a.c.a("stat", DataCore.a().toString());
            } catch (JSONException e) {
                com.baidu.mobstat.a.c.a("stat", "header ini error");
                throw new RuntimeException("header ini error");
            }
        }
    }
}
