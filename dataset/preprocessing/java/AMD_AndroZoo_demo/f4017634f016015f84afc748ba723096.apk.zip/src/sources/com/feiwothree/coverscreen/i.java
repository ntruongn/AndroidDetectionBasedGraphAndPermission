package com.feiwothree.coverscreen;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
final class i extends BroadcastReceiver {
    private /* synthetic */ SA a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public i(SA sa) {
        this.a = sa;
    }

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        this.a.finish();
    }
}
