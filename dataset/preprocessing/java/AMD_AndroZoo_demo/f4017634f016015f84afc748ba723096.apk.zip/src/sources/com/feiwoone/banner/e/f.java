package com.feiwoone.banner.e;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import com.webimageloader.Constants;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class f {
    private static f b;
    private Context a;

    public f() {
    }

    public f(Context context) {
        this.a = context;
    }

    /* JADX WARN: Not initialized variable reg: 3, insn: 0x0114: MOVE (r1 I:??[OBJECT, ARRAY]) = (r3 I:??[OBJECT, ARRAY]), block:B:125:0x0114 */
    public static Drawable a(Context context, String str) {
        HttpURLConnection httpURLConnection;
        InputStream inputStream;
        ByteArrayOutputStream byteArrayOutputStream;
        BufferedInputStream bufferedInputStream;
        ByteArrayOutputStream byteArrayOutputStream2;
        BufferedInputStream bufferedInputStream2;
        Drawable drawable;
        BufferedInputStream bufferedInputStream3 = null;
        try {
            try {
                URL url = new URL(str);
                httpURLConnection = e.a(context) == 12 ? (HttpURLConnection) url.openConnection(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(android.net.Proxy.getDefaultHost(), android.net.Proxy.getDefaultPort()))) : (HttpURLConnection) url.openConnection();
                try {
                    httpURLConnection.setConnectTimeout(Constants.DEFAULT_CONNECTION_TIMEOUT);
                    httpURLConnection.setReadTimeout(Constants.DEFAULT_CONNECTION_TIMEOUT);
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    inputStream = httpURLConnection.getInputStream();
                } catch (Exception e) {
                    e = e;
                    bufferedInputStream = null;
                    inputStream = null;
                    byteArrayOutputStream2 = null;
                } catch (OutOfMemoryError e2) {
                    bufferedInputStream = null;
                    inputStream = null;
                    byteArrayOutputStream2 = null;
                } catch (Throwable th) {
                    th = th;
                    inputStream = null;
                    byteArrayOutputStream = null;
                }
            } catch (Throwable th2) {
                th = th2;
                bufferedInputStream3 = bufferedInputStream2;
            }
        } catch (Exception e3) {
            e = e3;
            httpURLConnection = null;
            bufferedInputStream = null;
            inputStream = null;
            byteArrayOutputStream2 = null;
        } catch (OutOfMemoryError e4) {
            httpURLConnection = null;
            bufferedInputStream = null;
            inputStream = null;
            byteArrayOutputStream2 = null;
        } catch (Throwable th3) {
            th = th3;
            httpURLConnection = null;
            inputStream = null;
            byteArrayOutputStream = null;
        }
        if (inputStream == null) {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e5) {
                }
            }
            httpURLConnection.disconnect();
            return null;
        }
        try {
            bufferedInputStream = new BufferedInputStream(inputStream, 16384);
        } catch (Exception e6) {
            e = e6;
            bufferedInputStream = null;
            byteArrayOutputStream2 = null;
        } catch (OutOfMemoryError e7) {
            bufferedInputStream = null;
            byteArrayOutputStream2 = null;
        } catch (Throwable th4) {
            th = th4;
            byteArrayOutputStream = null;
        }
        try {
            byteArrayOutputStream2 = new ByteArrayOutputStream(16384);
            try {
                byte[] bArr = new byte[16384];
                for (int read = bufferedInputStream.read(bArr); read != -1; read = bufferedInputStream.read(bArr)) {
                    byteArrayOutputStream2.write(bArr, 0, read);
                }
                drawable = Drawable.createFromStream(new ByteArrayInputStream(byteArrayOutputStream2.toByteArray()), "src");
                try {
                    byteArrayOutputStream2.close();
                } catch (IOException e8) {
                }
                try {
                    bufferedInputStream.close();
                } catch (IOException e9) {
                }
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e10) {
                    }
                }
                httpURLConnection.disconnect();
            } catch (Exception e11) {
                e = e11;
                new StringBuilder("error > ").append(e.getMessage());
                if (byteArrayOutputStream2 != null) {
                    try {
                        byteArrayOutputStream2.close();
                    } catch (IOException e12) {
                    }
                }
                if (bufferedInputStream != null) {
                    try {
                        bufferedInputStream.close();
                    } catch (IOException e13) {
                    }
                }
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e14) {
                    }
                }
                httpURLConnection.disconnect();
                drawable = null;
                return drawable;
            } catch (OutOfMemoryError e15) {
                if (byteArrayOutputStream2 != null) {
                    try {
                        byteArrayOutputStream2.close();
                    } catch (IOException e16) {
                    }
                }
                if (bufferedInputStream != null) {
                    try {
                        bufferedInputStream.close();
                    } catch (IOException e17) {
                    }
                }
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e18) {
                    }
                }
                httpURLConnection.disconnect();
                drawable = null;
                return drawable;
            }
        } catch (Exception e19) {
            e = e19;
            byteArrayOutputStream2 = null;
        } catch (OutOfMemoryError e20) {
            byteArrayOutputStream2 = null;
        } catch (Throwable th5) {
            th = th5;
            byteArrayOutputStream = null;
            bufferedInputStream3 = bufferedInputStream;
            if (byteArrayOutputStream != null) {
                try {
                    byteArrayOutputStream.close();
                } catch (IOException e21) {
                }
            }
            if (bufferedInputStream3 != null) {
                try {
                    bufferedInputStream3.close();
                } catch (IOException e22) {
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e23) {
                }
            }
            httpURLConnection.disconnect();
            throw th;
        }
        return drawable;
    }

    public static f a(Context context) {
        if (b == null) {
            b = new f(context);
        }
        return b;
    }

    public static boolean b() {
        return Environment.getExternalStorageState().equals("mounted");
    }

    public static String c(String str) {
        return str.replace(":", "_").replace("/", "_");
    }

    public static boolean d(String str) {
        return new File(str).exists();
    }

    public static void e(String str) {
        File file = new File(str);
        if (file.exists()) {
            file.delete();
        }
    }

    public String a() {
        String absolutePath = this.a.getCacheDir().getAbsolutePath();
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        return absolutePath;
    }

    public String a(String str) {
        if (!b()) {
            return a();
        }
        String str2 = Environment.getExternalStorageDirectory() + str;
        File file = new File(str2);
        if (file.exists()) {
            return str2;
        }
        file.mkdirs();
        return str2;
    }

    public boolean a(String str, String str2) {
        HttpURLConnection httpURLConnection;
        HttpURLConnection httpURLConnection2;
        FileOutputStream fileOutputStream;
        InputStream inputStream;
        FileOutputStream fileOutputStream2;
        FileOutputStream fileOutputStream3 = null;
        r3 = null;
        fileOutputStream3 = null;
        HttpURLConnection httpURLConnection3 = null;
        FileOutputStream fileOutputStream4 = null;
        String str3 = String.valueOf(b(str)) + c(str2);
        if (!d(str3)) {
            File file = new File(str3);
            try {
                httpURLConnection2 = (HttpURLConnection) new URL(str2).openConnection();
                try {
                    httpURLConnection2.setConnectTimeout(20000);
                    httpURLConnection2.setReadTimeout(Constants.DEFAULT_CONNECTION_TIMEOUT);
                    httpURLConnection2.setRequestMethod("GET");
                    httpURLConnection2.connect();
                    inputStream = httpURLConnection2.getInputStream();
                    fileOutputStream2 = new FileOutputStream(file);
                } catch (FileNotFoundException e) {
                    httpURLConnection3 = httpURLConnection2;
                    fileOutputStream = null;
                } catch (IOException e2) {
                } catch (Throwable th) {
                    httpURLConnection = httpURLConnection2;
                    th = th;
                }
            } catch (FileNotFoundException e3) {
                fileOutputStream = null;
            } catch (IOException e4) {
                httpURLConnection2 = null;
            } catch (Throwable th2) {
                th = th2;
                httpURLConnection = null;
            }
            try {
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = inputStream.read(bArr);
                    if (read == -1) {
                        break;
                    }
                    fileOutputStream2.write(bArr, 0, read);
                }
                fileOutputStream2.flush();
                fileOutputStream2.close();
                try {
                    fileOutputStream2.close();
                    if (httpURLConnection2 != null) {
                        httpURLConnection2.disconnect();
                    }
                } catch (IOException e5) {
                }
            } catch (FileNotFoundException e6) {
                httpURLConnection3 = httpURLConnection2;
                fileOutputStream = fileOutputStream2;
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e7) {
                        return false;
                    }
                }
                if (httpURLConnection3 != null) {
                    httpURLConnection3.disconnect();
                }
                return false;
            } catch (IOException e8) {
                fileOutputStream4 = fileOutputStream2;
                if (fileOutputStream4 != null) {
                    try {
                        fileOutputStream4.close();
                    } catch (IOException e9) {
                        return false;
                    }
                }
                if (httpURLConnection2 != null) {
                    httpURLConnection2.disconnect();
                }
                return false;
            } catch (Throwable th3) {
                fileOutputStream3 = fileOutputStream2;
                httpURLConnection = httpURLConnection2;
                th = th3;
                if (fileOutputStream3 != null) {
                    try {
                        fileOutputStream3.close();
                    } catch (IOException e10) {
                        throw th;
                    }
                }
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                throw th;
            }
        }
        return true;
    }

    public InputStream b(String str, String str2) {
        FileInputStream fileInputStream;
        String str3 = String.valueOf(b(str)) + c(str2);
        if (d(str3)) {
            try {
                fileInputStream = new FileInputStream(new File(str3));
            } catch (FileNotFoundException e) {
                return null;
            }
        } else {
            fileInputStream = null;
        }
        return fileInputStream;
    }

    public String b(Context context, String str) {
        if (b()) {
            return a(str);
        }
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(context.getFilesDir().getAbsolutePath());
        if (!str.startsWith("/")) {
            stringBuffer.append("/");
        }
        stringBuffer.append(str);
        File file = new File(stringBuffer.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        return stringBuffer.toString();
    }

    public String b(String str) {
        return a(str) != null ? a(str) : a();
    }
}
