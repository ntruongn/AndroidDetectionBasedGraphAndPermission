package com.feiwoone.banner;

import android.content.Context;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
final class q implements com.feiwoone.banner.e.n {
    private final /* synthetic */ Context a;
    private final /* synthetic */ JSONObject b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public q(p pVar, Context context, JSONObject jSONObject) {
        this.a = context;
        this.b = jSONObject;
    }

    @Override // com.feiwoone.banner.e.n
    public final void a(boolean z, String str) {
        if (str == null || !z) {
            com.feiwoone.banner.f.e.b(this.a, "ADFEIWO", "list_install", this.b.toString(), "12345678");
        } else {
            com.feiwoone.banner.f.e.b(this.a, "ADFEIWO", "list_install", new JSONObject().toString(), "12345678");
        }
    }
}
