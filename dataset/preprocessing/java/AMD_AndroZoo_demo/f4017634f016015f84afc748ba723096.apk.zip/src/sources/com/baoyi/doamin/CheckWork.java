package com.baoyi.doamin;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class CheckWork {
    private boolean isalarms;
    private boolean isnotifications;
    private boolean ispodcast;
    private boolean isringtones;

    public boolean isIsringtones() {
        return this.isringtones;
    }

    public void setIsringtones(boolean isringtones) {
        this.isringtones = isringtones;
    }

    public boolean isIsalarms() {
        return this.isalarms;
    }

    public void setIsalarms(boolean isalarms) {
        this.isalarms = isalarms;
    }

    public boolean isIsnotifications() {
        return this.isnotifications;
    }

    public void setIsnotifications(boolean isnotifications) {
        this.isnotifications = isnotifications;
    }

    public boolean isIspodcast() {
        return this.ispodcast;
    }

    public void setIspodcast(boolean ispodcast) {
        this.ispodcast = ispodcast;
    }
}
