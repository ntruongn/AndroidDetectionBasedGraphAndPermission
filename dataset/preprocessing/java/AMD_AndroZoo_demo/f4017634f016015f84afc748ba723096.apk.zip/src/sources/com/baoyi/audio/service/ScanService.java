package com.baoyi.audio.service;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import com.baoyi.audio.utils.content;
import java.io.File;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class ScanService extends IntentService {
    public ScanService() {
        super("ScanService");
    }

    @Override // android.app.IntentService
    protected void onHandleIntent(Intent intent) {
        Log.i("ada", "扫描铃声。。。");
        scanFileAsync(this, content.SAVEDIR);
    }

    public void scanFileAsync(Context ctx, String filePath) {
        Intent scanIntent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        scanIntent.setData(Uri.fromFile(new File(filePath)));
        ctx.sendBroadcast(scanIntent);
    }
}
