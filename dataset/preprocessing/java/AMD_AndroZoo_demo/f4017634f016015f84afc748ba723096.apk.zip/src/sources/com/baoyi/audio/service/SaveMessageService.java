package com.baoyi.audio.service;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.db.MessageShowManager;
import com.iring.dao.MessageDao;
import com.iring.entity.Message;
import com.iring.rpc.MessageRpc;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SaveMessageService extends Service {
    @Override // android.app.Service
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        new getMessageAsync().execute(new Void[0]);
    }

    public int getNum() {
        MessageShowManager manger = new MessageShowManager(this);
        int a = manger.getNum();
        return a;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class getMessageAsync extends AsyncTask<Void, Void, Void> {
        getMessageAsync() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void... params) {
            List<Message> all;
            MessageShowManager manger = new MessageShowManager(SaveMessageService.this);
            MessageDao dao = RpcUtils2.getMessageDao();
            MessageRpc rpc = dao.getMessages(SaveMessageService.this.getNum(), 20);
            if (rpc != null && rpc.getCode() == 0 && (all = rpc.getDatas()) != null) {
                manger.addMessage(all);
                for (Message message : all) {
                    System.out.println(String.valueOf(message.getId()) + message.getShot() + message.getAuthor() + message.getMessage());
                }
                return null;
            }
            return null;
        }
    }
}
