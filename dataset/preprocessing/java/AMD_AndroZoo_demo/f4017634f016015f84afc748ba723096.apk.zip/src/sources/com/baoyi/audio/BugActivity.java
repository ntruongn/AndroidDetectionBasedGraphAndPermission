package com.baoyi.audio;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import com.baidu.mobstat.StatService;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class BugActivity extends Activity {
    public void trackEvent(String envent, int size) {
        StatService.onEvent(this, envent, "pass", size);
    }

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler(this));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        StatService.onResume((Context) this);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        StatService.onPause((Context) this);
    }
}
