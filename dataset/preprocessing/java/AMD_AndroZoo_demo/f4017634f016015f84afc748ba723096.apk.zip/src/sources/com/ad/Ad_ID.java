package com.ad;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Ad_ID {
    public static String anzhi_banner = "muGWETATO5KRu0oM1240skQ8";
    public static String dm_1_banner = "56OJyGSouMOY1lswL6";
    public static String dm_2_banner = "16TLwM0vAc0zHY71eBZnSKwz";
    public static int dj_1_banner = 41473;
    public static String dj_2_banner = "7a0e40da5e28590a7d4dc8d883a1eb28";
    public static String vg_anzhi = "6545dc010a5946e98f5929bcf9c3c8b8";
    public static String vg_baidu = "398d1432518e41728a8762d639d6acb6";
    public static String dyd_ts = "25d4ec28efacbd32d24425a5d99ab156";
}
