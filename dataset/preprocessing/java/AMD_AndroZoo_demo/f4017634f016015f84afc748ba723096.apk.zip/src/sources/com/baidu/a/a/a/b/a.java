package com.baidu.a.a.a.b;

import android.content.Context;
import android.text.TextUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class a {
    private static final String a = a.class.getSimpleName();

    public static String a(Context context) {
        String b = b(context);
        String b2 = b.b(context);
        if (TextUtils.isEmpty(b2)) {
            b2 = "0";
        }
        return b + "|" + new StringBuffer(b2).reverse().toString();
    }

    private static String b(Context context) {
        return b.a(context);
    }
}
