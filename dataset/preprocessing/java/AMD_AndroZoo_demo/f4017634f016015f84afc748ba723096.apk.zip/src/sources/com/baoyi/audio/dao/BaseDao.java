package com.baoyi.audio.dao;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public abstract class BaseDao {
    private Activity mActivity;

    protected abstract String getDbName();

    public BaseDao(Activity activity) {
        this.mActivity = activity;
        create();
    }

    protected SQLiteDatabase getDb() {
        return this.mActivity.openOrCreateDatabase(getDbName(), 0, null);
    }

    protected void create() {
    }
}
