package com.baoyi.audio;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import com.baoyi.audio.utils.GoogleFormSender;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class BugReportActivity extends Activity {
    static final String STACKTRACE = "fbreader.stacktrace";

    private String getVersionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getVersion() {
        try {
            return new StringBuilder(String.valueOf(getPackageManager().getPackageInfo(getPackageName(), 0).versionCode)).toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static String getDisplayDetails(Context context) {
        try {
            WindowManager windowManager = (WindowManager) context.getSystemService("window");
            Display display = windowManager.getDefaultDisplay();
            DisplayMetrics metrics = new DisplayMetrics();
            display.getMetrics(metrics);
            StringBuilder result = new StringBuilder();
            result.append("width=").append(display.getWidth()).append('\n');
            result.append("height=").append(display.getHeight()).append('\n');
            result.append("pixelFormat=").append(display.getPixelFormat()).append('\n');
            result.append("refreshRate=").append(display.getRefreshRate()).append("fps").append('\n');
            result.append("metrics.density=x").append(metrics.density).append('\n');
            result.append("metrics.scaledDensity=x").append(metrics.scaledDensity).append('\n');
            result.append("metrics.widthPixels=").append(metrics.widthPixels).append('\n');
            result.append("metrics.heightPixels=").append(metrics.heightPixels).append('\n');
            result.append("metrics.xdpi=").append(metrics.xdpi).append('\n');
            result.append("metrics.ydpi=").append(metrics.ydpi);
            return result.toString();
        } catch (RuntimeException e) {
            return "Couldn't retrieve Display Details";
        }
    }

    public String getphoneinfo() {
        StringBuffer result = new StringBuffer();
        result.append("\n手机类型:" + Build.MODEL);
        result.append("\n手机系统版本:" + Build.VERSION.SDK);
        result.append("\n手机TYPE:" + Build.TYPE);
        result.append("\n手机DEVICE:" + Build.DEVICE);
        result.append("\n手机CPU_ABI:" + Build.CPU_ABI);
        result.append("\n手机DISPLAY:" + Build.DISPLAY);
        result.append(getDisplayDetails(this));
        return result.toString();
    }

    @Override // android.app.Activity
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.bug_report_view);
        final String stackTrace = getIntent().getStringExtra(STACKTRACE);
        TextView reportTextView = (TextView) findViewById(R.id.report_text);
        reportTextView.setMovementMethod(ScrollingMovementMethod.getInstance());
        reportTextView.setClickable(false);
        reportTextView.setLongClickable(false);
        String versionName = getVersionName();
        reportTextView.append(String.valueOf(getString(2131165184)) + versionName + " 信息反馈，感谢你的反馈\n\n");
        reportTextView.append(stackTrace);
        findViewById(R.id.send_report).setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.BugReportActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GoogleFormSender sender = new GoogleFormSender(BugReportActivity.this.getPackageName(), BugReportActivity.this.getVersion(), String.valueOf(BugReportActivity.this.getphoneinfo()) + stackTrace, BugReportActivity.this.getString(2131165184));
                sender.start();
                BugReportActivity.this.finish();
                BugReportActivity.this.gohome();
            }
        });
        findViewById(R.id.cancel_report).setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.BugReportActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GoogleFormSender sender = new GoogleFormSender(BugReportActivity.this.getPackageName(), BugReportActivity.this.getVersion(), String.valueOf(BugReportActivity.this.getphoneinfo()) + stackTrace, BugReportActivity.this.getString(2131165184));
                sender.start();
                BugReportActivity.this.finish();
                BugReportActivity.this.gohome();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void gohome() {
        Intent intent = new Intent(this, (Class<?>) MainActivity.class);
        startActivity(intent);
    }
}
