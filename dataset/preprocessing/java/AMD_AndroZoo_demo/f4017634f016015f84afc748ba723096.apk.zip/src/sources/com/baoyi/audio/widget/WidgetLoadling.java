package com.baoyi.audio.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class WidgetLoadling extends LinearLayout {
    public WidgetLoadling(Context context) {
        super(context);
        LayoutInflater.from(getContext()).inflate(R.layout.widget_loading, this);
    }
}
