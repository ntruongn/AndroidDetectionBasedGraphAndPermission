package com.baoyi.audio.utils;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class FileUtils {
    public static void write(Context context, String fileName, String content) {
        if (content == null) {
            content = "";
        }
        try {
            FileOutputStream fos = context.openFileOutput(fileName, 0);
            fos.write(content.getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String read(Context context, String fileName) {
        try {
            FileInputStream in = context.openFileInput(fileName);
            return readInStream(in);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private static String readInStream(FileInputStream inStream) {
        try {
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[512];
            while (true) {
                int length = inStream.read(buffer);
                if (length != -1) {
                    outStream.write(buffer, 0, length);
                } else {
                    outStream.close();
                    inStream.close();
                    return outStream.toString();
                }
            }
        } catch (IOException e) {
            Log.i("FileTest", e.getMessage());
            return null;
        }
    }

    public static File createFile(String folderPath, String fileName) {
        File destDir = new File(folderPath);
        if (!destDir.exists()) {
            destDir.mkdirs();
        }
        return new File(folderPath, String.valueOf(fileName) + fileName);
    }

    public static boolean writeFile(byte[] buffer, String folder, String fileName) {
        FileOutputStream out;
        boolean writeSucc = false;
        boolean sdCardExist = Environment.getExternalStorageState().equals("mounted");
        String folderPath = "";
        if (sdCardExist) {
            folderPath = Environment.getExternalStorageDirectory() + File.separator + folder + File.separator;
        } else {
            writeSucc = false;
        }
        File fileDir = new File(folderPath);
        if (!fileDir.exists()) {
            fileDir.mkdirs();
        }
        File file = new File(String.valueOf(folderPath) + fileName);
        FileOutputStream out2 = null;
        try {
            try {
                out = new FileOutputStream(file);
            } catch (Throwable th) {
                th = th;
            }
        } catch (Exception e) {
            e = e;
        }
        try {
            out.write(buffer);
            writeSucc = true;
            try {
                out.close();
                out2 = out;
            } catch (IOException e2) {
                e2.printStackTrace();
                out2 = out;
            }
        } catch (Exception e3) {
            e = e3;
            out2 = out;
            e.printStackTrace();
            try {
                out2.close();
            } catch (IOException e4) {
                e4.printStackTrace();
            }
            return writeSucc;
        } catch (Throwable th2) {
            th = th2;
            out2 = out;
            try {
                out2.close();
            } catch (IOException e5) {
                e5.printStackTrace();
            }
            throw th;
        }
        return writeSucc;
    }

    public static String getFileName(String filePath) {
        return StringUtils.isEmpty(filePath) ? "" : filePath.substring(filePath.lastIndexOf(File.separator) + 1);
    }

    public static String getFileNameNoFormat(String filePath) {
        if (StringUtils.isEmpty(filePath)) {
            return "";
        }
        int point = filePath.lastIndexOf(46);
        return filePath.substring(filePath.lastIndexOf(File.separator) + 1, point);
    }

    public static String getFileFormat(String fileName) {
        if (StringUtils.isEmpty(fileName)) {
            return "";
        }
        int point = fileName.lastIndexOf(46);
        return fileName.substring(point + 1);
    }

    public static long getFileSize(String filePath) {
        File file = new File(filePath);
        if (file == null || !file.exists()) {
            return 0L;
        }
        long size = file.length();
        return size;
    }

    public static String getFileSize(long size) {
        if (size <= 0) {
            return "0";
        }
        DecimalFormat df = new DecimalFormat("##.##");
        float temp = ((float) size) / 1024.0f;
        if (temp >= 1024.0f) {
            return String.valueOf(df.format(temp / 1024.0f)) + "M";
        }
        return String.valueOf(df.format(temp)) + "K";
    }

    public static String formatFileSize(long fileS) {
        DecimalFormat df = new DecimalFormat("#.00");
        if (fileS < org.apache.commons.io.FileUtils.ONE_KB) {
            String fileSizeString = String.valueOf(df.format(fileS)) + "B";
            return fileSizeString;
        }
        if (fileS < org.apache.commons.io.FileUtils.ONE_MB) {
            String fileSizeString2 = String.valueOf(df.format(fileS / 1024.0d)) + "KB";
            return fileSizeString2;
        }
        if (fileS < org.apache.commons.io.FileUtils.ONE_GB) {
            String fileSizeString3 = String.valueOf(df.format(fileS / 1048576.0d)) + "MB";
            return fileSizeString3;
        }
        String fileSizeString4 = String.valueOf(df.format(fileS / 1.073741824E9d)) + "G";
        return fileSizeString4;
    }

    public static long getDirSize(File dir) {
        long dirSize = 0;
        if (dir != null && dir.isDirectory()) {
            dirSize = 0;
            File[] files = dir.listFiles();
            for (File file : files) {
                if (file.isFile()) {
                    dirSize += file.length();
                } else if (file.isDirectory()) {
                    dirSize = dirSize + file.length() + getDirSize(file);
                }
            }
        }
        return dirSize;
    }

    public long getFileList(File dir) {
        File[] files = dir.listFiles();
        long count = files.length;
        for (File file : files) {
            if (file.isDirectory()) {
                count = (count + getFileList(file)) - 1;
            }
        }
        return count;
    }

    public static byte[] toBytes(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        while (true) {
            int ch = in.read();
            if (ch != -1) {
                out.write(ch);
            } else {
                byte[] buffer = out.toByteArray();
                out.close();
                return buffer;
            }
        }
    }

    public static boolean checkFileExists(String name) {
        if (!name.equals("")) {
            File path = Environment.getExternalStorageDirectory();
            File newPath = new File(String.valueOf(path.toString()) + name);
            boolean status = newPath.exists();
            return status;
        }
        return false;
    }

    public static long getFreeDiskSpace() {
        String status = Environment.getExternalStorageState();
        long freeSpace = 0;
        if (status.equals("mounted")) {
            try {
                File path = Environment.getExternalStorageDirectory();
                StatFs stat = new StatFs(path.getPath());
                long blockSize = stat.getBlockSize();
                long availableBlocks = stat.getAvailableBlocks();
                freeSpace = (availableBlocks * blockSize) / org.apache.commons.io.FileUtils.ONE_KB;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return freeSpace;
        }
        return -1L;
    }

    public static boolean createDirectory(String directoryName) {
        if (!directoryName.equals("")) {
            File path = Environment.getExternalStorageDirectory();
            File newPath = new File(String.valueOf(path.toString()) + directoryName);
            newPath.mkdir();
            return true;
        }
        return false;
    }

    public static boolean checkSaveLocationExists() {
        String sDCardStatus = Environment.getExternalStorageState();
        if (sDCardStatus.equals("mounted")) {
            return true;
        }
        return false;
    }

    public static boolean deleteDirectory(String fileName) {
        SecurityManager checker = new SecurityManager();
        if (!fileName.equals("")) {
            File path = Environment.getExternalStorageDirectory();
            File newPath = new File(String.valueOf(path.toString()) + fileName);
            checker.checkDelete(newPath.toString());
            if (newPath.isDirectory()) {
                String[] listfile = newPath.list();
                for (String str : listfile) {
                    try {
                        File deletedFile = new File(String.valueOf(newPath.toString()) + "/" + str.toString());
                        deletedFile.delete();
                    } catch (Exception e) {
                        e.printStackTrace();
                        return false;
                    }
                }
                newPath.delete();
                Log.i("DirectoryManager deleteDirectory", fileName);
                return true;
            }
            return false;
        }
        return false;
    }

    public static boolean deleteFile(String fileName) {
        SecurityManager checker = new SecurityManager();
        if (!fileName.equals("")) {
            File path = Environment.getExternalStorageDirectory();
            File newPath = new File(String.valueOf(path.toString()) + fileName);
            checker.checkDelete(newPath.toString());
            if (newPath.isFile()) {
                try {
                    Log.i("DirectoryManager deleteFile", fileName);
                    newPath.delete();
                    return true;
                } catch (SecurityException se) {
                    se.printStackTrace();
                    return false;
                }
            }
            return false;
        }
        return false;
    }
}
