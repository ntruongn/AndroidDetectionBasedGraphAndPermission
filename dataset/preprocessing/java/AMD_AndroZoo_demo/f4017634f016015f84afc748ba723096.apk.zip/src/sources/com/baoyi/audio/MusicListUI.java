package com.baoyi.audio;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.baoyi.audio.adapter.MusicItemListAdapter;
import com.baoyi.audio.cache.DataCache;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MusicListUI extends AnalyticsUI {
    MusicItemListAdapter adapter;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    private TextView title;
    private int type;
    boolean work = false;
    int page = 0;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.baoyi.audio.AnalyticsUI, com.baoyi.audio.BugActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_list_hot);
        Intent intent = getIntent();
        this.title = (TextView) findViewById(R.id.typetitle);
        this.type = intent.getExtras().getInt("type");
        this.title.setText(Messages.getMessage(Integer.valueOf(this.type)));
        this.mPullRefreshListView = (PullToRefreshListView) findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() { // from class: com.baoyi.audio.MusicListUI.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            }

            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                if (!MusicListUI.this.work) {
                    new HotTask(MusicListUI.this, null).execute(Integer.valueOf(MusicListUI.this.page));
                }
            }
        });
        WidgetLoadling tv = new WidgetLoadling(this);
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new MusicItemListAdapter(this);
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getSharedPreferences("com.iym.imusic_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(this);
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        new HotTask(this, null).execute(Integer.valueOf(this.page));
        this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Music>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(MusicListUI musicListUI, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Music> doInBackground(Integer... params) {
            MusicListUI.this.work = true;
            String key = String.valueOf(MusicListUI.this.type) + "RpcUtils2.getMusicDao().pageByType" + params[0];
            List<Music> temp = DataCache.datas.get(key);
            if (temp == null || temp.size() == 0) {
                try {
                    temp = RpcUtils2.getMusicDao().pageByType(MusicListUI.this.type, 80, params[0].intValue()).getDatas();
                    DataCache.datas.put(key, temp);
                    return temp;
                } catch (Exception e) {
                    e.printStackTrace();
                    return temp;
                }
            }
            return temp;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Music> result) {
            MusicListUI.this.work = false;
            MusicListUI.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.PULL_UP_TO_REFRESH);
            if (result != null) {
                for (Music music : result) {
                    MusicListUI.this.adapter.addLast(music);
                }
                MusicListUI.this.adapter.notifyDataSetChanged();
                MusicListUI.this.mPullRefreshListView.onRefreshComplete();
                MusicListUI.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + MusicListUI.this.adapter.getCount() + "首铃声");
                MusicListUI.this.page++;
                return;
            }
            if (MusicListUI.this.page == 0) {
                MusicListUI.this.mPullRefreshListView.setEmptyView(null);
                Toast.makeText(MusicListUI.this, "获取数据失败，请稍候再试。", 0).show();
            }
            MusicListUI.this.mPullRefreshListView.onRefreshComplete();
        }
    }
}
