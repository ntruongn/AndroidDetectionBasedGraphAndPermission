package com.baoyi.ts3;

import android.content.Context;
import java.lang.reflect.Method;

/* compiled from: Utils.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class c {
    public static void a(Context ctx, String clzName, String methodName, Class<?>[] clsArr, Object[] args) {
        try {
            Class clz = b.a(ctx, null, null).c(ctx).loadClass(clzName);
            Method m = clz.getMethod(methodName, clsArr);
            m.invoke(null, args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
