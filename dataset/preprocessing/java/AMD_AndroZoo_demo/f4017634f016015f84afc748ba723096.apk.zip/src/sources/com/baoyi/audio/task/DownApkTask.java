package com.baoyi.audio.task;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import com.baoyi.audio.utils.content;
import com.baoyi.utils.MD5Utility;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class DownApkTask extends AsyncTask<String, String, File> {
    Context curcontext;
    private ProgressDialog progressDialog = null;

    public DownApkTask(Context context) {
        this.curcontext = context;
    }

    @Override // android.os.AsyncTask
    public void onPreExecute() {
        this.progressDialog = ProgressDialog.show(this.curcontext, "下载软件", "正在为你下载软件,请稍候！", true, true);
        super.onPreExecute();
    }

    @Override // android.os.AsyncTask
    public void onPostExecute(File url) {
        super.onPostExecute((DownApkTask) url);
        this.progressDialog.dismiss();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onProgressUpdate(String... aa) {
        this.progressDialog.setMessage(aa[0]);
    }

    @Override // android.os.AsyncTask
    public File doInBackground(String... params) {
        File fileitem;
        int length;
        InputStream is;
        String savePath;
        String apkfile;
        boolean sdCardExist;
        try {
            URL url = new URL(params[0]);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.connect();
            length = conn.getContentLength();
            is = conn.getInputStream();
            savePath = String.valueOf(content.SAVEDIR) + MD5Utility.md5Appkey(params[0]) + ".temp";
            apkfile = String.valueOf(content.SAVEDIR) + MD5Utility.md5Appkey(params[0]) + ".apk";
            sdCardExist = Environment.getExternalStorageState().equals("mounted");
        } catch (MalformedURLException e) {
            e = e;
        } catch (IOException e2) {
            e = e2;
        }
        if (!sdCardExist) {
            return null;
        }
        File ApkFile = new File(savePath);
        File fileitem2 = new File(apkfile);
        if (length != -1) {
            try {
                FileOutputStream output = new FileOutputStream(ApkFile);
                byte[] buffer = new byte[6144];
                int downsize = 0;
                while (true) {
                    int count = is.read(buffer);
                    if (count == -1) {
                        break;
                    }
                    output.write(buffer, 0, count);
                    downsize += count;
                    publishProgress("下载了" + ((downsize * 100) / length) + "%");
                }
                output.flush();
                output.close();
                is.close();
                ApkFile.renameTo(fileitem2);
                fileitem = fileitem2;
            } catch (MalformedURLException e3) {
                e = e3;
                e.printStackTrace();
                fileitem = null;
                return fileitem;
            } catch (IOException e4) {
                e = e4;
                e.printStackTrace();
                fileitem = null;
                return fileitem;
            }
        } else {
            fileitem = fileitem2;
        }
        return fileitem;
    }
}
