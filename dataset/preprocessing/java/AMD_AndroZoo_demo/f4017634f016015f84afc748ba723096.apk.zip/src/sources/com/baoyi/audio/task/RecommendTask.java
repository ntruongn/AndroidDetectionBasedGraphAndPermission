package com.baoyi.audio.task;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;
import com.baoyi.audio.utils.RpcUtils2;
import com.iring.dao.RingRecommendDao;
import com.iring.entity.RingRecommend;
import com.iring.rpc.RpcSerializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RecommendTask extends AsyncTask<RpcSerializable, Integer, RpcSerializable> {
    private Context context;
    private RingRecommend ringRecommend;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onPostExecute(RpcSerializable result) {
        super.onPostExecute((RecommendTask) result);
        if (result != null) {
            Toast.makeText(this.context, "推荐成功", 0).show();
        }
    }

    public RecommendTask(RingRecommend ringRecommend, Context context) {
        this.ringRecommend = ringRecommend;
        this.context = context;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public RpcSerializable doInBackground(RpcSerializable... params) {
        RpcSerializable rpc = null;
        try {
            RingRecommendDao dao = (RingRecommendDao) RpcUtils2.getDao("ringRecommendDao", RingRecommendDao.class);
            rpc = dao.addRingRecommend(this.ringRecommend);
            Log.i("ada", "反馈成功");
            return rpc;
        } catch (Exception e) {
            e.printStackTrace();
            return rpc;
        }
    }
}
