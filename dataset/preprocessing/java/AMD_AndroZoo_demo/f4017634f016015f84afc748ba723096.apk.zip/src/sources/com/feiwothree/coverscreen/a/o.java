package com.feiwothree.coverscreen.a;

import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
final class o implements Runnable {
    private /* synthetic */ n a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(n nVar) {
        this.a = nVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        C0013i c0013i;
        c0013i = this.a.h;
        x.a(c0013i.d).a(this.a.b.e() + 12345, 17301586, this.a.b.a(), this.a.b.a(), "开始下载 ", new Intent(), 18, this.a.b.b(), this.a.d);
    }
}
