package com.feiwoone.banner.e;

import android.content.Context;
import android.content.Intent;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class k implements Runnable {
    private /* synthetic */ i a;
    private final /* synthetic */ Intent b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(i iVar, Intent intent) {
        this.a = iVar;
        this.b = intent;
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.feiwoone.banner.c.b bVar;
        Context context;
        com.feiwoone.banner.c.b bVar2;
        com.feiwoone.banner.c.b bVar3;
        Context context2;
        Context context3;
        com.feiwoone.banner.c.b bVar4;
        com.feiwoone.banner.c.b bVar5;
        bVar = this.a.h;
        if (bVar.e()) {
            context3 = this.a.i;
            p a = p.a(context3);
            bVar4 = this.a.h;
            int a2 = bVar4.a();
            bVar5 = this.a.h;
            a.a(a2, null, bVar5.d(), "下载完成，点击安装", this.b, 32);
        } else {
            context = this.a.i;
            p a3 = p.a(context);
            bVar2 = this.a.h;
            int a4 = bVar2.a();
            bVar3 = this.a.h;
            a3.a(a4, null, bVar3.d(), "下载完成，点击安装", this.b, 16);
        }
        Intent intent = new Intent(this.b);
        intent.setFlags(268435456);
        context2 = this.a.i;
        context2.startActivity(intent);
    }
}
