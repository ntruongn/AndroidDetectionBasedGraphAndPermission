package com.baoyi.audio.fragment;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.baoyi.audio.adapter.MusicItemListAdapter;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class HotFragment extends Fragment implements View.OnClickListener {
    MusicItemListAdapter adapter;
    int bttype;
    Button frame_btn_all;
    Button frame_btn_day;
    Button frame_btn_month;
    Button frame_btn_week;
    private View last;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    int type;
    int page = 0;
    private boolean work = false;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.type = 1;
        this.frame_btn_all = (Button) getView().findViewById(R.id.frame_btn_all);
        this.frame_btn_day = (Button) getView().findViewById(R.id.frame_btn_day);
        this.frame_btn_week = (Button) getView().findViewById(R.id.frame_btn_week);
        this.frame_btn_month = (Button) getView().findViewById(R.id.frame_btn_month);
        this.frame_btn_all.setOnClickListener(this);
        this.frame_btn_day.setOnClickListener(this);
        this.frame_btn_week.setOnClickListener(this);
        this.frame_btn_month.setOnClickListener(this);
        this.mPullRefreshListView = (PullToRefreshListView) getView().findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() { // from class: com.baoyi.audio.fragment.HotFragment.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            }

            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                if (!HotFragment.this.work) {
                    new HotTask(HotFragment.this, null).execute(Integer.valueOf(HotFragment.this.page));
                }
            }
        });
        WidgetLoadling tv = new WidgetLoadling(getActivity());
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new MusicItemListAdapter(getActivity());
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        this.listView.setBackgroundColor(17170445);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("com.iym.imusic_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(getActivity());
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
        this.page = 0;
        this.bttype = 2;
        new HotTask(this, null).execute(Integer.valueOf(this.page));
        this.frame_btn_all.setEnabled(true);
        this.frame_btn_day.setEnabled(false);
        this.frame_btn_week.setEnabled(true);
        this.frame_btn_month.setEnabled(true);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Music>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(HotFragment hotFragment, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Music> doInBackground(Integer... params) {
            HotFragment.this.work = true;
            List<Music> temp = null;
            try {
                if (HotFragment.this.bttype == 1) {
                    temp = RpcUtils2.getMusicDao().pageByHot(content.showsize, params[0].intValue()).getDatas();
                }
                if (HotFragment.this.bttype == 2) {
                    temp = RpcUtils2.getMusicDao().pageByHotDay(content.showsize, params[0].intValue()).getDatas();
                }
                if (HotFragment.this.bttype == 3) {
                    temp = RpcUtils2.getMusicDao().pageByHotWeek(content.showsize, params[0].intValue()).getDatas();
                }
                if (HotFragment.this.bttype == 4) {
                    List<Music> temp2 = RpcUtils2.getMusicDao().pageByHotMonth(content.showsize, params[0].intValue()).getDatas();
                    return temp2;
                }
                return temp;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Music> result) {
            HotFragment.this.work = false;
            HotFragment.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.PULL_UP_TO_REFRESH);
            if (result != null) {
                for (Music music : result) {
                    HotFragment.this.adapter.addLast(music);
                }
                HotFragment.this.adapter.notifyDataSetChanged();
                HotFragment.this.mPullRefreshListView.onRefreshComplete();
                HotFragment.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + HotFragment.this.adapter.getCount() + "首铃声");
                HotFragment.this.page++;
                return;
            }
            if (HotFragment.this.page == 0) {
                HotFragment.this.mPullRefreshListView.setEmptyView(null);
                Toast.makeText(HotFragment.this.getActivity(), "获取数据失败，请稍候再试。", 0).show();
            }
            HotFragment.this.mPullRefreshListView.onRefreshComplete();
        }
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_hot, container, false);
        return view;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        HotTask hotTask = null;
        if (this.last == null || this.last != v) {
            this.last = v;
            this.adapter.clear();
            this.adapter.notifyDataSetChanged();
            if (v.getId() == 2131296359) {
                this.frame_btn_all.setEnabled(false);
                this.bttype = 1;
                this.page = 0;
                new HotTask(this, hotTask).execute(Integer.valueOf(this.page));
            } else {
                this.frame_btn_all.setEnabled(true);
            }
            if (v.getId() == 2131296360) {
                this.frame_btn_day.setEnabled(false);
                this.bttype = 2;
                this.page = 0;
                new HotTask(this, hotTask).execute(Integer.valueOf(this.page));
            } else {
                this.frame_btn_day.setEnabled(true);
            }
            if (v.getId() == 2131296361) {
                this.frame_btn_week.setEnabled(false);
                this.bttype = 3;
                this.page = 0;
                new HotTask(this, hotTask).execute(Integer.valueOf(this.page));
            } else {
                this.frame_btn_week.setEnabled(true);
            }
            if (v.getId() == 2131296362) {
                this.frame_btn_month.setEnabled(false);
                this.bttype = 4;
                this.page = 0;
                new HotTask(this, hotTask).execute(Integer.valueOf(this.page));
                return;
            }
            this.frame_btn_month.setEnabled(true);
        }
    }
}
