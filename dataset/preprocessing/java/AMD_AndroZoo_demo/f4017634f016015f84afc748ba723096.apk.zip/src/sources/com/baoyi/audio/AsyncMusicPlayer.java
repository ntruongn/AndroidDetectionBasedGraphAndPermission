package com.baoyi.audio;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.ad.Banner;
import com.ad.CP;
import com.baoyi.audio.adapter.MainFragmentPagerAdapter;
import com.baoyi.audio.fragment.AsyncMusicPlayerFragment;
import com.baoyi.audio.fragment.CommentsFragment;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.task.CutAudioTask;
import com.baoyi.audio.task.RecommendPubTask;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.widget.TabPageIndicator1;
import com.baoyi.qingsongring.TuiJianActivity;
import com.hope.leyuan.R;
import com.iring.entity.RingRecommend;
import com.iring.rpc.RpcSerializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class AsyncMusicPlayer extends AnalyticsFrameUI {
    private static final int REQUEST_CODE_EDIT = 1;
    private boolean mWasGetContentIntent;
    private int musicid;
    private String name;
    TextView titleTextView;
    private String url;

    public void work(View v) {
        if (v.getId() == 2131296480) {
            tuiring();
        }
        if (v.getId() == 2131296481) {
            favring();
            if (getUserid() < 1) {
                Intent intent = new Intent(this, (Class<?>) LoginActivity.class);
                startActivity(intent);
                Toast.makeText(this, "你没有登陆，请登陆", 0).show();
            } else if (this.musicid < 1) {
                Toast.makeText(this, "改首铃声不能被收藏", 0).show();
            } else {
                new HotTask(this, null).execute(Integer.valueOf(getUserid()), Integer.valueOf(this.musicid));
            }
        }
        if (v.getId() == 2131296479) {
            new CutAudioTask(this).execute(this.url, this.name);
        }
    }

    private void pubring() {
        RingRecommend ringRecommend = new RingRecommend();
        ringRecommend.setAddtime(System.currentTimeMillis());
        ringRecommend.setCatalog(1);
        ringRecommend.setCatalogname("试听");
        ringRecommend.setMusicname(this.name);
        ringRecommend.setMusicid(this.musicid);
        ringRecommend.setMusicpath(this.url);
        ringRecommend.setMemberid(getUserid());
        ringRecommend.setMembername(getMemberName());
        ringRecommend.setMemberpicture(getminipicture());
        new RecommendPubTask(ringRecommend, this).execute(new RpcSerializable[0]);
    }

    private void favring() {
        RingRecommend ringRecommend = new RingRecommend();
        ringRecommend.setAddtime(System.currentTimeMillis());
        ringRecommend.setCatalog(3);
        ringRecommend.setCatalogname("收藏");
        ringRecommend.setMusicname(this.name);
        ringRecommend.setMusicid(this.musicid);
        ringRecommend.setMusicpath(this.url);
        ringRecommend.setMemberid(getUserid());
        ringRecommend.setMembername(getMemberName());
        ringRecommend.setMemberpicture(getminipicture());
        new RecommendPubTask(ringRecommend, this).execute(new RpcSerializable[0]);
    }

    private void tuiring() {
        Intent intent = new Intent(this, (Class<?>) TuiJianActivity.class);
        intent.putExtra(UpdateService.NAME, this.name);
        intent.putExtra("fileurl", this.url);
        intent.putExtra("musicid", this.musicid);
        startActivity(intent);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, RpcSerializable> {
        private HotTask() {
        }

        /* synthetic */ HotTask(AsyncMusicPlayer asyncMusicPlayer, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public RpcSerializable doInBackground(Integer... params) {
            RpcSerializable result = new RpcSerializable();
            try {
                Integer temp = Integer.valueOf(RpcUtils2.getUserRpc().addringfav(params[0], params[1]));
                result.setCode(temp.intValue());
            } catch (Exception e) {
                e.printStackTrace();
                result.setCode(-1);
            }
            return result;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(RpcSerializable result) {
            if (result.getCode() > 0) {
                Toast.makeText(AsyncMusicPlayer.this, "收藏成功", 0).show();
            } else {
                Toast.makeText(AsyncMusicPlayer.this, "收藏失败", 0).show();
            }
        }
    }

    @Override // com.baoyi.audio.AnalyticsFrameUI, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
        this.titleTextView = (TextView) findViewById(R.id.titleTextView);
        Intent itent = getIntent();
        this.name = itent.getExtras().getString(UpdateService.NAME);
        this.url = itent.getExtras().getString("fileurl");
        this.musicid = itent.getExtras().getInt("musicid", -1);
        this.titleTextView.setText(this.name);
        MainFragmentPagerAdapter adaptera = new MainFragmentPagerAdapter(getSupportFragmentManager());
        AsyncMusicPlayerFragment play = new AsyncMusicPlayerFragment();
        play.setArguments(getIntent().getExtras());
        adaptera.add("铃声设置", play);
        adaptera.add("心  情  墙", new CommentsFragment(this.musicid));
        ViewPager pager = (ViewPager) findViewById(R.id.pager);
        pager.setAdapter(adaptera);
        TabPageIndicator1 indicator = (TabPageIndicator1) findViewById(R.id.indicator);
        indicator.setViewPager(pager);
        pager.setCurrentItem(0);
        Banner.banner_AD(this);
        CP.cp_AD(this);
    }
}
