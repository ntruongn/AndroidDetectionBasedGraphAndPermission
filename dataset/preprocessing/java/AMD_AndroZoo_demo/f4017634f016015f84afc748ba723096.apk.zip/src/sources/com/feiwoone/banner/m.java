package com.feiwoone.banner;

import android.content.Context;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class m implements com.feiwoone.banner.e.n {
    private /* synthetic */ k a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public m(k kVar) {
        this.a = kVar;
    }

    @Override // com.feiwoone.banner.e.n
    public final void a(boolean z, String str) {
        Context context;
        Context context2;
        if (str == null || !z) {
            context = this.a.b;
            com.feiwoone.banner.f.e.a(context, "ADFEIWO", "FIRST_USER", true, "12345678");
        } else {
            context2 = this.a.b;
            com.feiwoone.banner.f.e.a(context2, "ADFEIWO", "FIRST_USER", false, "12345678");
        }
    }
}
