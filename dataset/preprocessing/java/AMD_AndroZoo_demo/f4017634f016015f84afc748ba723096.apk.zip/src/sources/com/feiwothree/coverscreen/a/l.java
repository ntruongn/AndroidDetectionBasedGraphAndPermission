package com.feiwothree.coverscreen.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class l {
    public static String a = "/adfeiwo/c-cache/image";
    public static String b = "/adfeiwo/c-cache/apk";
    public static String c = "coverscreen_close2.png";
    public static String d = "coverscreen_download2.png";
    public static String e = "coverscreen_clickshow2.png";
}
