package com.feiwothree.coverscreen;

import com.feiwothree.coverscreen.a.C0005a;
import com.feiwothree.coverscreen.a.C0014j;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class l extends com.feiwothree.coverscreen.a.m {
    final /* synthetic */ SA a;
    private final /* synthetic */ C0014j b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(SA sa, C0014j c0014j) {
        this.a = sa;
        this.b = c0014j;
    }

    @Override // com.feiwothree.coverscreen.a.m
    public final void a(C0005a c0005a, String str, boolean z) {
        super.a(c0005a, str, z);
        if ("true".equals(this.b.o()) && z) {
            this.a.a.post(new m(this, str, c0005a));
        }
    }
}
