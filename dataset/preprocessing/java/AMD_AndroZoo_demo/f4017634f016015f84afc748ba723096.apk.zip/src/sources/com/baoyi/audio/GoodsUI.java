package com.baoyi.audio;

import android.os.Bundle;
import android.view.Menu;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.baoyi.audio.adapter.GoodsAdapter;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class GoodsUI extends AnalyticsUI {
    private ListView listView;

    @Override // com.baoyi.audio.AnalyticsUI, android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        super.onCreateOptionsMenu(menu);
        return true;
    }

    @Override // com.baoyi.audio.AnalyticsUI, com.baoyi.audio.BugActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_goods);
        this.listView = (ListView) findViewById(R.id.goods);
        GoodsAdapter adapert = new GoodsAdapter(this);
        this.listView.setAdapter((ListAdapter) adapert);
        this.listView.setOnItemClickListener(adapert);
        this.listView.setDividerHeight(0);
        BaoyiApplication.getInstance().isonline();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.audio.BugActivity, android.app.Activity
    public void onResume() {
        System.out.println("fff");
        super.onResume();
    }
}
