package com.baoyi.qingsongring;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.baoyi.audio.AnalyticsUI;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.task.UploadPicTask;
import com.baoyi.audio.utils.FileUtils;
import com.baoyi.audio.utils.ImageUtils;
import com.baoyi.audio.utils.MediaUtils;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.StringUtils;
import com.baoyi.audio.utils.content;
import com.baoyi.utils.Utils;
import com.hope.leyuan.R;
import com.iring.dao.MemberDao;
import com.iring.rpc.RpcSerializable;
import com.wrapp.android.webimage.WebImageView;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class EditInfoActivity extends AnalyticsUI {
    final Handler handler = new Handler() { // from class: com.baoyi.qingsongring.EditInfoActivity.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (msg.what == 1 && msg.obj != null) {
                EditInfoActivity.this.headimg.setImageBitmap((Bitmap) msg.obj);
                EditInfoActivity.this.headimg.setVisibility(0);
                EditInfoActivity.this.openOptionsMenu1();
            }
        }
    };
    private WebImageView headimg;
    private File imgFile;
    private EditText messages;
    private EditText nickname;
    private ImageButton saveBtn;
    private String theBigThumbnail;
    private String theLarge;
    private String theThumbnail;
    private RelativeLayout uploadimgRl;
    private int userid;

    @Override // com.baoyi.audio.AnalyticsUI
    public int getUserid() {
        SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
        return sharedPreferences.getInt(UpdateService.USERID, -1);
    }

    @Override // com.baoyi.audio.AnalyticsUI, com.baoyi.audio.BugActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_info);
        this.userid = getUserid();
        SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
        String name = sharedPreferences.getString(UpdateService.NAME, "游客");
        String message = sharedPreferences.getString("message", "好铃声,好心情");
        this.nickname = (EditText) findViewById(R.id.nickname);
        this.nickname.setText(name);
        this.messages = (EditText) findViewById(R.id.messages);
        this.messages.setText(message);
        this.uploadimgRl = (RelativeLayout) findViewById(R.id.upload_headimage);
        this.saveBtn = (ImageButton) findViewById(R.id.editor_save_btn);
        this.headimg = (WebImageView) findViewById(R.id.editor_headimg);
        this.headimg.setImageUrl(String.valueOf(content.picserver) + getminipicture());
        this.uploadimgRl.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.qingsongring.EditInfoActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                CharSequence[] items = {"手机相册", "手机拍照"};
                EditInfoActivity.this.imageChooseItem(items);
            }
        });
        this.saveBtn.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.qingsongring.EditInfoActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                EditInfoActivity.this.saveData();
                EditInfoActivity.this.finish();
            }
        });
    }

    public void imageChooseItem(CharSequence[] items) {
        AlertDialog imageDialog = new AlertDialog.Builder(this).setTitle("选择图片").setIcon(17301514).setItems(items, new DialogInterface.OnClickListener() { // from class: com.baoyi.qingsongring.EditInfoActivity.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int item) {
                if (item == 0) {
                    Intent intent = new Intent("android.intent.action.GET_CONTENT");
                    intent.addCategory("android.intent.category.OPENABLE");
                    intent.setType("image/*");
                    EditInfoActivity.this.startActivityForResult(Intent.createChooser(intent, "选择图片"), 0);
                    return;
                }
                if (item == 1) {
                    String savePath = "";
                    String storageState = Environment.getExternalStorageState();
                    if (storageState.equals("mounted")) {
                        savePath = String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + "/OSChina/Camera/";
                        File savedir = new File(savePath);
                        if (!savedir.exists()) {
                            savedir.mkdirs();
                        }
                    }
                    if (StringUtils.isEmpty(savePath)) {
                        Utils.showMessage(EditInfoActivity.this, "无法保存照片，请检查SD卡是否挂载");
                        return;
                    }
                    String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
                    String fileName = "osc_" + timeStamp + ".jpg";
                    File out = new File(savePath, fileName);
                    Uri uri = Uri.fromFile(out);
                    EditInfoActivity.this.theLarge = String.valueOf(savePath) + fileName;
                    Intent intent2 = new Intent("android.media.action.IMAGE_CAPTURE");
                    intent2.putExtra("output", uri);
                    EditInfoActivity.this.startActivityForResult(intent2, 1);
                }
            }
        }).create();
        imageDialog.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void saveData() {
        HotTask hotTask = null;
        String name = this.nickname.getText().toString();
        if (name != null) {
            new HotTask(this, hotTask).execute("nickname", name);
            SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
            sharedPreferences.edit().putString(UpdateService.NAME, name).commit();
        }
        String message = this.messages.getText().toString();
        if (message != null) {
            new HotTask(this, hotTask).execute("messages", message);
            SharedPreferences sharedPreferences2 = getSharedPreferences("apps", 0);
            sharedPreferences2.edit().putString("message", message).commit();
        }
    }

    public void uploadpic() {
        String uid = new StringBuilder(String.valueOf(getUserid())).toString();
        new UploadPicTask(this).execute(this.theBigThumbnail, uid, this.theThumbnail);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Type inference failed for: r0v1, types: [com.baoyi.qingsongring.EditInfoActivity$5] */
    @Override // com.baoyi.audio.AnalyticsUI, android.app.Activity
    public void onActivityResult(final int requestCode, int resultCode, final Intent data) {
        if (resultCode == -1) {
            new Thread() { // from class: com.baoyi.qingsongring.EditInfoActivity.5
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    Bitmap bitmap = null;
                    if (requestCode == 0) {
                        if (data != null) {
                            Uri thisUri = data.getData();
                            String thePath = ImageUtils.getAbsolutePathFromNoStandardUri(thisUri);
                            if (!StringUtils.isEmpty(thePath)) {
                                EditInfoActivity.this.theLarge = thePath;
                            } else {
                                EditInfoActivity.this.theLarge = ImageUtils.getAbsoluteImagePath(EditInfoActivity.this, thisUri);
                            }
                            String attFormat = FileUtils.getFileFormat(EditInfoActivity.this.theLarge);
                            if (!"photo".equals(MediaUtils.getContentType(attFormat))) {
                                Toast.makeText(EditInfoActivity.this, "请选择图片", 0).show();
                                return;
                            }
                            if (EditInfoActivity.isMethodsCompat(7)) {
                                String imgName = FileUtils.getFileName(EditInfoActivity.this.theLarge);
                                bitmap = ImageUtils.loadImgThumbnail(EditInfoActivity.this, imgName, 3);
                            }
                            if (bitmap == null && !StringUtils.isEmpty(EditInfoActivity.this.theLarge)) {
                                bitmap = ImageUtils.loadImgThumbnail(EditInfoActivity.this.theLarge, 100, 100);
                            }
                        } else {
                            return;
                        }
                    } else if (requestCode == 1 && 0 == 0 && !StringUtils.isEmpty(EditInfoActivity.this.theLarge)) {
                        bitmap = ImageUtils.loadImgThumbnail(EditInfoActivity.this.theLarge, 100, 100);
                    }
                    if (bitmap != null) {
                        String savePath = String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + "/androidring/Camera/";
                        File savedir = new File(savePath);
                        if (!savedir.exists()) {
                            savedir.mkdirs();
                        }
                        String largeFileName = FileUtils.getFileName(EditInfoActivity.this.theLarge);
                        String largeFilePath = String.valueOf(savePath) + largeFileName;
                        if (largeFileName.startsWith("thumb_") && new File(largeFilePath).exists()) {
                            EditInfoActivity.this.theThumbnail = largeFilePath;
                            EditInfoActivity.this.imgFile = new File(EditInfoActivity.this.theThumbnail);
                        } else {
                            String thumbFileName1 = "bigthumb_" + largeFileName;
                            EditInfoActivity.this.theBigThumbnail = String.valueOf(savePath) + thumbFileName1;
                            if (new File(EditInfoActivity.this.theBigThumbnail).exists()) {
                                EditInfoActivity.this.imgFile = new File(EditInfoActivity.this.theBigThumbnail);
                            } else {
                                try {
                                    ImageUtils.createImageThumbnail(EditInfoActivity.this, EditInfoActivity.this.theLarge, EditInfoActivity.this.theBigThumbnail, 800, 100);
                                    EditInfoActivity.this.imgFile = new File(EditInfoActivity.this.theBigThumbnail);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                            String thumbFileName = "thumb_" + largeFileName;
                            EditInfoActivity.this.theThumbnail = String.valueOf(savePath) + thumbFileName;
                            if (new File(EditInfoActivity.this.theThumbnail).exists()) {
                                EditInfoActivity.this.imgFile = new File(EditInfoActivity.this.theThumbnail);
                            } else {
                                try {
                                    ImageUtils.createImageThumbnail(EditInfoActivity.this, EditInfoActivity.this.theLarge, EditInfoActivity.this.theThumbnail, 100, 100);
                                    EditInfoActivity.this.imgFile = new File(EditInfoActivity.this.theThumbnail);
                                } catch (IOException e2) {
                                    e2.printStackTrace();
                                }
                            }
                        }
                        Message msg = new Message();
                        msg.what = 1;
                        msg.obj = bitmap;
                        EditInfoActivity.this.handler.sendMessage(msg);
                    }
                }
            }.start();
        }
    }

    public static boolean isMethodsCompat(int VersionCode) {
        int currentVersion = Build.VERSION.SDK_INT;
        return currentVersion >= VersionCode;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void openOptionsMenu1() {
        new AlertDialog.Builder(this).setTitle("上传头像").setPositiveButton("上传", new DialogInterface.OnClickListener() { // from class: com.baoyi.qingsongring.EditInfoActivity.6
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                EditInfoActivity.this.uploadpic();
            }
        }).setNegativeButton("取消", new DialogInterface.OnClickListener() { // from class: com.baoyi.qingsongring.EditInfoActivity.7
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                dialog.dismiss();
            }
        }).create().show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class HotTask extends AsyncTask<String, Void, RpcSerializable> {
        private HotTask() {
        }

        /* synthetic */ HotTask(EditInfoActivity editInfoActivity, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public RpcSerializable doInBackground(String... params) {
            try {
                MemberDao dao = RpcUtils2.getMemberDao();
                RpcSerializable temp = dao.updateKey(EditInfoActivity.this.userid, params[0], params[1]);
                return temp;
            } catch (Exception e) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(RpcSerializable result) {
        }
    }
}
