package com.baoyi.audio.dao;

import android.content.ContentValues;
import android.database.Cursor;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.dao.DatabaseBuilder;
import com.iring.entity.Music;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MusicBuilder extends DatabaseBuilder<Music> {
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.baoyi.dao.DatabaseBuilder
    public Music build(Cursor query) {
        Music word = new Music();
        int columnName = query.getColumnIndex(UpdateService.NAME);
        int idId = query.getColumnIndex("id");
        int imgurlId = query.getColumnIndex("url");
        int artistid = query.getColumnIndex(UpdateService.ARTIST);
        int hitid = query.getColumnIndex("hit");
        word.setName(query.getString(columnName));
        word.setId(Integer.valueOf(query.getInt(idId)));
        word.setUrl(query.getString(imgurlId));
        word.setArtist(query.getString(artistid));
        word.setHit(query.getInt(hitid));
        return word;
    }

    @Override // com.baoyi.dao.DatabaseBuilder
    public ContentValues deconstruct(Music t) {
        ContentValues values = new ContentValues();
        values.put(UpdateService.NAME, t.getName());
        values.put("url", t.getUrl());
        values.put("id", t.getId());
        values.put(UpdateService.ARTIST, t.getArtist());
        values.put("hit", Integer.valueOf(t.getHit()));
        values.put("addtime", Long.valueOf(System.currentTimeMillis()));
        return values;
    }
}
