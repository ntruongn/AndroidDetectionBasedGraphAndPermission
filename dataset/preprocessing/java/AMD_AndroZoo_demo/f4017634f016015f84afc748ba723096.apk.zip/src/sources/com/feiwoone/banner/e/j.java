package com.feiwoone.banner.e;

import android.app.Notification;
import android.content.Context;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class j implements Runnable {
    private /* synthetic */ i a;
    private final /* synthetic */ Notification b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(i iVar, Notification notification) {
        this.a = iVar;
        this.b = notification;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Context context;
        com.feiwoone.banner.c.b bVar;
        com.feiwoone.banner.c.b bVar2;
        context = this.a.i;
        p a = p.a(context);
        bVar = this.a.h;
        int a2 = bVar.a();
        bVar2 = this.a.h;
        a.a(a2, bVar2.c(), this.b);
    }
}
