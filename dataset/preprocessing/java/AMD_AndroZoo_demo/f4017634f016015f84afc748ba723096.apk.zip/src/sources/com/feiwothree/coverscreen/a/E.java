package com.feiwothree.coverscreen.a;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import java.lang.ref.WeakReference;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class E implements Runnable {
    private /* synthetic */ C a;
    private final /* synthetic */ Context b;
    private final /* synthetic */ String c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public E(C c, Context context, String str) {
        this.a = c;
        this.b = context;
        this.c = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ConcurrentHashMap concurrentHashMap;
        Handler handler;
        Handler handler2;
        r.a();
        String a = r.a(this.b, l.a, this.c);
        concurrentHashMap = this.a.e;
        WeakReference weakReference = (WeakReference) concurrentHashMap.get(this.c);
        Bitmap bitmap = weakReference != null ? (Bitmap) weakReference.get() : null;
        if (bitmap == null) {
            try {
                C c = this.a;
                bitmap = C.a(this.b, a);
            } catch (Exception e) {
            }
        }
        if (bitmap == null) {
            try {
                C.a(this.a, this.b, this.c);
            } catch (Exception e2) {
            }
        }
        if (bitmap == null) {
            try {
                C c2 = this.a;
                bitmap = C.a(this.b, a);
            } catch (Exception e3) {
            }
        }
        new StringBuilder("loadDrawable complete, bitmap: ").append(bitmap).append(", url: ").append(this.c);
        handler = this.a.b;
        handler2 = this.a.b;
        handler.sendMessage(handler2.obtainMessage(0, new Object[]{this.c, bitmap}));
    }
}
