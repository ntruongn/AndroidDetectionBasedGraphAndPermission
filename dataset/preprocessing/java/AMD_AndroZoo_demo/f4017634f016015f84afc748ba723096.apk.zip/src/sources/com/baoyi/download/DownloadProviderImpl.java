package com.baoyi.download;

import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class DownloadProviderImpl implements DownloadProvider {
    private static final String DB_PATH = "/jamendroid2.db";
    private ArrayList<DownloadJob> mQueuedJobs = new ArrayList<>();
    private ArrayList<DownloadJob> mCompletedJobs = new ArrayList<>();

    private void loadOldDownloads() {
    }

    @Override // com.baoyi.download.DownloadProvider
    public ArrayList<DownloadJob> getAllDownloads() {
        ArrayList<DownloadJob> allDownloads = new ArrayList<>();
        allDownloads.addAll(this.mCompletedJobs);
        allDownloads.addAll(this.mQueuedJobs);
        return allDownloads;
    }

    @Override // com.baoyi.download.DownloadProvider
    public ArrayList<DownloadJob> getCompletedDownloads() {
        return this.mCompletedJobs;
    }

    @Override // com.baoyi.download.DownloadProvider
    public ArrayList<DownloadJob> getQueuedDownloads() {
        return this.mQueuedJobs;
    }

    @Override // com.baoyi.download.DownloadProvider
    public void downloadCompleted(DownloadJob job) {
        this.mQueuedJobs.remove(job);
        this.mCompletedJobs.add(job);
    }

    @Override // com.baoyi.download.DownloadProvider
    public boolean queueDownload(DownloadJob downloadJob) {
        Iterator<DownloadJob> it = this.mCompletedJobs.iterator();
        while (it.hasNext()) {
            DownloadJob dJob = it.next();
            if (dJob.getUrl().equals(downloadJob.getUrl())) {
                return false;
            }
        }
        Iterator<DownloadJob> it2 = this.mQueuedJobs.iterator();
        while (it2.hasNext()) {
            DownloadJob dJob2 = it2.next();
            if (dJob2.getUrl().equals(downloadJob.getUrl())) {
                return false;
            }
        }
        this.mQueuedJobs.add(downloadJob);
        return true;
    }

    @Override // com.baoyi.download.DownloadProvider
    public void removeDownload(DownloadJob job) {
        if (job.getProgress() < 100) {
            job.cancel();
            this.mQueuedJobs.remove(job);
        } else {
            this.mCompletedJobs.remove(job);
        }
    }
}
