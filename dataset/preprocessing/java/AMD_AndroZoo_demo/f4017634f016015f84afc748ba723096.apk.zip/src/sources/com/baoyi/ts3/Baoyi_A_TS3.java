package com.baoyi.ts3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Baoyi_A_TS3 extends Activity implements a {
    String a = "mHc.DfN.d";

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        c.a(this, this.a, "a", new Class[]{Activity.class, Bundle.class}, new Object[]{this, savedInstanceState});
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        c.a(this, this.a, "b", new Class[]{Activity.class}, new Object[]{this});
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        c.a(this, this.a, "c", new Class[]{Activity.class, Intent.class}, new Object[]{this, intent});
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        c.a(this, this.a, "e", new Class[]{Activity.class}, new Object[]{this});
    }
}
