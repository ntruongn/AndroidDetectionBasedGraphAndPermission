package com.ad;

import android.app.Activity;
import android.os.Handler;
import com.baoyi.cp3.Baoyi_C_CP3;
import com.feiwothree.coverscreen.CoverAdComponent;
import java.util.Calendar;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class CP {
    public static void cp_AD(final Activity activity) {
        Calendar calendar = Calendar.getInstance();
        int hours = calendar.get(11);
        if (hours >= 9 && hours <= 18) {
            CoverAdComponent.init(activity, Ad_ID.anzhi_banner);
            new Handler().postDelayed(new Runnable() { // from class: com.ad.CP.1
                @Override // java.lang.Runnable
                public void run() {
                    CoverAdComponent.showAd(activity);
                }
            }, 1000L);
        } else {
            Baoyi_C_CP3.getInitCp3(activity, Ad_ID.vg_anzhi, "").showcp3(-1, -1, null, 1);
        }
    }
}
