package com.feiwoone.banner.e;

import android.content.Context;
import android.os.Handler;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class g {
    private static g b = null;
    private ExecutorService a;
    private Handler c = new h(this);
    private Map d = new ConcurrentHashMap();

    private g() {
        this.a = null;
        if (this.a == null) {
            this.a = Executors.newFixedThreadPool(5);
        }
    }

    public static g a() {
        if (b == null) {
            b = new g();
        }
        return b;
    }

    public final void a(Context context, com.feiwoone.banner.c.b bVar) {
        a(context, bVar, new e(this));
    }

    public final void a(Context context, com.feiwoone.banner.c.b bVar, l lVar) {
        if (this.d.containsKey(bVar.f())) {
            return;
        }
        f.a(context);
        String b2 = f.b() ? f.a(context).b(context, "/adfeiwo/apk/") : f.a(context).b(context, "");
        i iVar = new i(this);
        iVar.a(context, bVar, b2);
        iVar.a(lVar);
        this.d.put(bVar.f(), iVar);
        this.a.submit(iVar);
    }

    public final void a(com.feiwoone.banner.c.b bVar) {
        this.d.remove(bVar.f());
    }
}
