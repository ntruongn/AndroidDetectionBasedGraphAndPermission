package com.feiwoone.banner.f;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class a {
    private static a a;
    private String b;
    private String c;
    private String d;
    private String e;

    public a() {
    }

    private a(Context context) {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            String networkOperator = telephonyManager.getNetworkOperator();
            this.b = networkOperator.substring(0, 3);
            this.c = networkOperator.substring(3);
            GsmCellLocation gsmCellLocation = (GsmCellLocation) telephonyManager.getCellLocation();
            this.d = String.valueOf(gsmCellLocation.getCid());
            this.e = String.valueOf(gsmCellLocation.getLac());
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    public static a a(Context context) {
        if (a == null) {
            a = new a(context);
        }
        return a;
    }

    public static JSONObject a(Context context, String str, String str2) {
        JSONObject jSONObject = new JSONObject();
        String a2 = j.a(context);
        String b = j.b();
        i.a();
        String a3 = i.a(context, false);
        String str3 = String.valueOf(j.b(context).a()) + "*" + j.b(context).b();
        String a4 = j.a();
        String d = j.d();
        String c = j.c();
        try {
            jSONObject.put("devid", a2);
            jSONObject.put("model", b);
            jSONObject.put("packagenames", a3);
            jSONObject.put("resolution", str3);
            jSONObject.put("brand", a4);
            jSONObject.put("versionrelease", d);
            jSONObject.put("versioncode", c);
            jSONObject.put("appkey", str);
            jSONObject.put("adsdkversion", str2);
            jSONObject.put("sdktype", "BANNER");
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public String a() {
        return this.b;
    }

    public String b() {
        return this.c;
    }

    public String c() {
        return this.d;
    }

    public String d() {
        return this.e;
    }
}
