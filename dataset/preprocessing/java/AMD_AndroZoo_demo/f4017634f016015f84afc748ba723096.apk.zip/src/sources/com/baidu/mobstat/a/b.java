package com.baidu.mobstat.a;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class b {
    private static final Proxy a = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.0.0.172", 80));
    private static final Proxy b = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.0.0.200", 80));

    public static String a(Context context, String str) {
        c.a("MoUtil.read", str);
        try {
            byte[] b2 = b(context, str);
            if (b2 != null) {
                return new String(b2, "utf-8");
            }
        } catch (Exception e) {
            Log.w("sdkstat", "MoUtil.read", e);
        }
        return "";
    }

    public static String a(boolean z, Context context, String str) {
        return z ? b(str) : a(context, str);
    }

    public static HttpURLConnection a(Context context, String str, int i, int i2) {
        HttpURLConnection httpURLConnection;
        URL url = new URL(str);
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        NetworkInfo networkInfo = connectivityManager.getNetworkInfo(0);
        NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(1);
        if (networkInfo2 != null && networkInfo2.isAvailable()) {
            c.a("", "WIFI is available");
            httpURLConnection = (HttpURLConnection) url.openConnection();
        } else if (networkInfo == null || !networkInfo.isAvailable()) {
            c.a("", "getConnection:not wifi and mobile");
            httpURLConnection = (HttpURLConnection) url.openConnection();
        } else {
            String extraInfo = networkInfo.getExtraInfo();
            String lowerCase = extraInfo != null ? extraInfo.toLowerCase() : "";
            c.a("current APN", lowerCase);
            httpURLConnection = (lowerCase.startsWith("cmwap") || lowerCase.startsWith("uniwap") || lowerCase.startsWith("3gwap")) ? (HttpURLConnection) url.openConnection(a) : lowerCase.startsWith("ctwap") ? (HttpURLConnection) url.openConnection(b) : (HttpURLConnection) url.openConnection();
        }
        httpURLConnection.setConnectTimeout(i);
        httpURLConnection.setReadTimeout(i2);
        return httpURLConnection;
    }

    public static void a(Context context, String str, String str2, boolean z) {
        FileOutputStream fileOutputStream = null;
        try {
            try {
                FileOutputStream openFileOutput = context.openFileOutput(str, z ? 32768 : 0);
                if (openFileOutput != null) {
                    openFileOutput.write(str2.getBytes("utf-8"));
                } else {
                    Log.w("sdkstat", "MoUtil.write fout is null:" + (openFileOutput == null));
                }
                if (openFileOutput != null) {
                    try {
                        openFileOutput.close();
                    } catch (Exception e) {
                        Log.w("sdkstat", "MoUtil.write", e);
                    }
                }
            } catch (Exception e2) {
                Log.w("sdkstat", "MoUtil.write", e2);
                if (0 != 0) {
                    try {
                        fileOutputStream.close();
                    } catch (Exception e3) {
                        Log.w("sdkstat", "MoUtil.write", e3);
                    }
                }
            }
        } catch (Throwable th) {
            if (0 != 0) {
                try {
                    fileOutputStream.close();
                } catch (Exception e4) {
                    Log.w("sdkstat", "MoUtil.write", e4);
                }
            }
            throw th;
        }
    }

    public static void a(String str, String str2, boolean z) {
        FileOutputStream fileOutputStream;
        if ("mounted".equals(Environment.getExternalStorageState())) {
            FileOutputStream fileOutputStream2 = null;
            try {
                try {
                    File file = new File(Environment.getExternalStorageDirectory() + File.separator + str);
                    if (!file.exists()) {
                        file.getParentFile().mkdirs();
                        file.createNewFile();
                    }
                    fileOutputStream = new FileOutputStream(file, z);
                } catch (Throwable th) {
                    th = th;
                }
            } catch (FileNotFoundException e) {
                e = e;
            } catch (IOException e2) {
                e = e2;
            }
            try {
                fileOutputStream.write(str2.getBytes("utf-8"));
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e3) {
                        Log.w("sdkstat", "MoUtil.writeExt", e3);
                    }
                }
            } catch (FileNotFoundException e4) {
                e = e4;
                fileOutputStream2 = fileOutputStream;
                Log.e("sdkstat", "MoUtil.writeExt", e);
                if (fileOutputStream2 != null) {
                    try {
                        fileOutputStream2.close();
                    } catch (IOException e5) {
                        Log.w("sdkstat", "MoUtil.writeExt", e5);
                    }
                }
            } catch (IOException e6) {
                e = e6;
                fileOutputStream2 = fileOutputStream;
                Log.e("sdkstat", "MoUtil.writeExt", e);
                if (fileOutputStream2 != null) {
                    try {
                        fileOutputStream2.close();
                    } catch (IOException e7) {
                        Log.w("sdkstat", "MoUtil.writeExt", e7);
                    }
                }
            } catch (Throwable th2) {
                th = th2;
                fileOutputStream2 = fileOutputStream;
                if (fileOutputStream2 != null) {
                    try {
                        fileOutputStream2.close();
                    } catch (IOException e8) {
                        Log.w("sdkstat", "MoUtil.writeExt", e8);
                    }
                }
                throw th;
            }
        }
    }

    public static void a(boolean z, Context context, String str, String str2, boolean z2) {
        if (z) {
            a(str, str2, z2);
        } else {
            a(context, str, str2, z2);
        }
    }

    public static boolean a(String str) {
        c.a("MoUtil.deleteExt", str);
        if (!"mounted".equals(Environment.getExternalStorageState())) {
            return false;
        }
        File file = new File(Environment.getExternalStorageDirectory() + File.separator + str);
        if (file.exists()) {
            return file.delete();
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00a2 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r2v12, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v7, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v9, types: [java.lang.String] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String b(java.lang.String r5) {
        /*
            java.lang.String r0 = "MoUtil.readExt"
            com.baidu.mobstat.a.c.a(r0, r5)
            java.lang.String r0 = android.os.Environment.getExternalStorageState()
            java.lang.String r1 = "mounted"
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L1c
            java.lang.String r1 = "mounted_ro"
            boolean r0 = r1.equals(r0)
            if (r0 != 0) goto L1c
            java.lang.String r1 = ""
        L1b:
            return r1
        L1c:
            java.io.File r0 = android.os.Environment.getExternalStorageDirectory()
            java.io.File r4 = new java.io.File
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.StringBuilder r0 = r1.append(r0)
            java.lang.String r1 = java.io.File.separator
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.StringBuilder r0 = r0.append(r5)
            java.lang.String r0 = r0.toString()
            r4.<init>(r0)
            java.lang.String r1 = ""
            boolean r0 = r4.exists()
            if (r0 == 0) goto L1b
            r3 = 0
            java.io.FileInputStream r2 = new java.io.FileInputStream     // Catch: java.io.FileNotFoundException -> L6a java.io.IOException -> L84 java.lang.Throwable -> L9e
            r2.<init>(r4)     // Catch: java.io.FileNotFoundException -> L6a java.io.IOException -> L84 java.lang.Throwable -> L9e
            int r0 = r2.available()     // Catch: java.lang.Throwable -> Laf java.io.IOException -> Lb1 java.io.FileNotFoundException -> Lb3
            byte[] r3 = new byte[r0]     // Catch: java.lang.Throwable -> Laf java.io.IOException -> Lb1 java.io.FileNotFoundException -> Lb3
            r2.read(r3)     // Catch: java.lang.Throwable -> Laf java.io.IOException -> Lb1 java.io.FileNotFoundException -> Lb3
            java.lang.String r0 = new java.lang.String     // Catch: java.lang.Throwable -> Laf java.io.IOException -> Lb1 java.io.FileNotFoundException -> Lb3
            java.lang.String r4 = "utf-8"
            r0.<init>(r3, r4)     // Catch: java.lang.Throwable -> Laf java.io.IOException -> Lb1 java.io.FileNotFoundException -> Lb3
            if (r2 == 0) goto L5f
            r2.close()     // Catch: java.io.IOException -> L61
        L5f:
            r1 = r0
            goto L1b
        L61:
            r1 = move-exception
            java.lang.String r2 = "sdkstat"
            java.lang.String r3 = "MoUtil.readExt"
            android.util.Log.w(r2, r3, r1)
            goto L5f
        L6a:
            r0 = move-exception
            r2 = r3
        L6c:
            java.lang.String r3 = "sdkstat"
            java.lang.String r4 = "MoUtil.readExt"
            android.util.Log.e(r3, r4, r0)     // Catch: java.lang.Throwable -> Laf
            if (r2 == 0) goto L78
            r2.close()     // Catch: java.io.IOException -> L7a
        L78:
            r0 = r1
            goto L5f
        L7a:
            r0 = move-exception
            java.lang.String r2 = "sdkstat"
            java.lang.String r3 = "MoUtil.readExt"
            android.util.Log.w(r2, r3, r0)
            r0 = r1
            goto L5f
        L84:
            r0 = move-exception
            r2 = r3
        L86:
            java.lang.String r3 = "sdkstat"
            java.lang.String r4 = "MoUtil.readExt"
            android.util.Log.e(r3, r4, r0)     // Catch: java.lang.Throwable -> Laf
            if (r2 == 0) goto L92
            r2.close()     // Catch: java.io.IOException -> L94
        L92:
            r0 = r1
            goto L5f
        L94:
            r0 = move-exception
            java.lang.String r2 = "sdkstat"
            java.lang.String r3 = "MoUtil.readExt"
            android.util.Log.w(r2, r3, r0)
            r0 = r1
            goto L5f
        L9e:
            r0 = move-exception
            r2 = r3
        La0:
            if (r2 == 0) goto La5
            r2.close()     // Catch: java.io.IOException -> La6
        La5:
            throw r0
        La6:
            r1 = move-exception
            java.lang.String r2 = "sdkstat"
            java.lang.String r3 = "MoUtil.readExt"
            android.util.Log.w(r2, r3, r1)
            goto La5
        Laf:
            r0 = move-exception
            goto La0
        Lb1:
            r0 = move-exception
            goto L86
        Lb3:
            r0 = move-exception
            goto L6c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.baidu.mobstat.a.b.b(java.lang.String):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v0 */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v15 */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v18, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v19 */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.io.FileInputStream] */
    /* JADX WARN: Type inference failed for: r2v20 */
    /* JADX WARN: Type inference failed for: r2v21 */
    /* JADX WARN: Type inference failed for: r2v22 */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.io.FileInputStream] */
    /* JADX WARN: Type inference failed for: r2v5, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.io.FileInputStream] */
    /* JADX WARN: Type inference failed for: r2v7, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v8 */
    static byte[] b(Context context, String str) {
        IOException iOException;
        byte[] bArr;
        FileNotFoundException fileNotFoundException;
        byte[] bArr2;
        ?? r2 = 0;
        r2 = 0;
        r2 = 0;
        r2 = 0;
        try {
            try {
                FileInputStream openFileInput = context.openFileInput(str);
                if (openFileInput != null) {
                    try {
                        try {
                            bArr2 = new byte[openFileInput.available()];
                        } catch (Throwable th) {
                            th = th;
                            r2 = openFileInput;
                            if (r2 != 0) {
                                try {
                                    r2.close();
                                } catch (IOException e) {
                                    Log.e("sdkstat", "MoUtil.readBinary", e);
                                }
                            }
                            throw th;
                        }
                    } catch (FileNotFoundException e2) {
                        bArr = null;
                        r2 = openFileInput;
                        fileNotFoundException = e2;
                    } catch (IOException e3) {
                        bArr = null;
                        r2 = openFileInput;
                        iOException = e3;
                    }
                    try {
                        openFileInput.read(bArr2);
                        bArr = bArr2;
                        r2 = bArr2;
                    } catch (FileNotFoundException e4) {
                        bArr = bArr2;
                        r2 = openFileInput;
                        fileNotFoundException = e4;
                        Log.e("sdkstat", "MoUtil.readBinary", fileNotFoundException);
                        if (r2 != 0) {
                            try {
                                r2.close();
                            } catch (IOException e5) {
                                r2 = "sdkstat";
                                Log.e("sdkstat", "MoUtil.readBinary", e5);
                            }
                        }
                        return bArr;
                    } catch (IOException e6) {
                        bArr = bArr2;
                        r2 = openFileInput;
                        iOException = e6;
                        Log.e("sdkstat", "MoUtil.readBinary", iOException);
                        if (r2 != 0) {
                            try {
                                r2.close();
                            } catch (IOException e7) {
                                r2 = "sdkstat";
                                Log.e("sdkstat", "MoUtil.readBinary", e7);
                            }
                        }
                        return bArr;
                    }
                } else {
                    bArr = null;
                }
                if (openFileInput != null) {
                    try {
                        openFileInput.close();
                    } catch (IOException e8) {
                        r2 = "sdkstat";
                        Log.e("sdkstat", "MoUtil.readBinary", e8);
                    }
                }
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (FileNotFoundException e9) {
            fileNotFoundException = e9;
            bArr = null;
        } catch (IOException e10) {
            iOException = e10;
            bArr = null;
        }
        return bArr;
    }

    public static void c(String str) {
        c.c("sdkstat", str);
        Log.e("sdkstat", "SDK install error:" + str);
    }

    public static boolean c(Context context, String str) {
        boolean exists = context.getFileStreamPath(str).exists();
        c.a("MoUtil.exists", exists + " " + str);
        return exists;
    }

    public static void d(Context context, String str) {
        if (e(context, str)) {
            return;
        }
        c("You need the " + str + " permission. Open AndroidManifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"" + str + "\" />");
    }

    public static boolean e(Context context, String str) {
        boolean z = context.checkCallingOrSelfPermission(str) != -1;
        c.a("hasPermission ", z + " | " + str);
        return z;
    }
}
