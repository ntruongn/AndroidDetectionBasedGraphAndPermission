package com.baoyi.download.core.network;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public abstract class ZLNetworkRequest {
    public final String PostData;
    public final Map<String, String> PostParameters;
    public final String SSLCertificate;
    String URL;
    private final boolean myIsQuiet;

    public abstract void handleStream(InputStream inputStream, int i) throws IOException, ZLNetworkException;

    /* JADX INFO: Access modifiers changed from: protected */
    public ZLNetworkRequest(String url) {
        this(url, null, null, false);
    }

    protected ZLNetworkRequest(String url, boolean quiet) {
        this(url, null, null, quiet);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public ZLNetworkRequest(String url, String sslCertificate, String postData) {
        this(url, null, null, false);
    }

    protected ZLNetworkRequest(String url, String sslCertificate, String postData, boolean quiet) {
        this.PostParameters = new HashMap();
        this.URL = url;
        this.SSLCertificate = sslCertificate;
        this.PostData = postData;
        this.myIsQuiet = quiet;
    }

    public void addPostParameter(String name, String value) {
        this.PostParameters.put(name, value);
    }

    public String getURL() {
        return this.URL;
    }

    public boolean isQuiet() {
        return this.myIsQuiet;
    }

    public void doBefore() throws ZLNetworkException {
    }

    public void doAfter(boolean success) throws ZLNetworkException {
    }
}
