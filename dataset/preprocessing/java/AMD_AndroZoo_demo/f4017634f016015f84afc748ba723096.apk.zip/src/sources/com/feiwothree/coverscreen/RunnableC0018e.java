package com.feiwothree.coverscreen;

import android.content.Context;
import com.feiwothree.coverscreen.a.F;

/* JADX INFO: Access modifiers changed from: package-private */
/* renamed from: com.feiwothree.coverscreen.e, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class RunnableC0018e implements Runnable {
    private /* synthetic */ AdComponent a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public RunnableC0018e(AdComponent adComponent, String str) {
        this.a = adComponent;
        this.b = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Context context;
        com.feiwothree.coverscreen.a.C a = com.feiwothree.coverscreen.a.C.a();
        context = this.a.d;
        a.a(context, this.b, (F) null);
    }
}
