package com.feiwoone.banner.e;

import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
final class b extends Handler {
    private final /* synthetic */ d a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(a aVar, d dVar, String str) {
        this.a = dVar;
        this.b = str;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        if (message.obj != null) {
            d dVar = this.a;
            Drawable drawable = (Drawable) message.obj;
            String str = this.b;
            dVar.a(drawable);
        }
    }
}
