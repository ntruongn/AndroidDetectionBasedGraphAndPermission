package com.baoyi.adapter;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.provider.ContactsContract;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class aa extends Activity {
    private int RINGTONE_PICKED = 1;
    private int mContactId;
    private String mCustomRingtone;

    private void doPickRingtone() {
        Uri ringtoneUri;
        Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
        intent.putExtra("android.intent.extra.ringtone.SHOW_DEFAULT", true);
        intent.putExtra("android.intent.extra.ringtone.TYPE", 1);
        intent.putExtra("android.intent.extra.ringtone.SHOW_SILENT", false);
        if (this.mCustomRingtone != null) {
            ringtoneUri = Uri.parse(this.mCustomRingtone);
        } else {
            ringtoneUri = RingtoneManager.getDefaultUri(1);
        }
        intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", ringtoneUri);
        startActivityForResult(intent, this.RINGTONE_PICKED);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != -1) {
        }
    }

    private void handleRingtonePicked(Uri pickedUri) {
        if (pickedUri == null || RingtoneManager.isDefault(pickedUri)) {
            this.mCustomRingtone = null;
        } else {
            this.mCustomRingtone = pickedUri.toString();
        }
        saveData();
    }

    private void saveData() {
        ContentValues values = new ContentValues();
        values.put("custom_ringtone", this.mCustomRingtone);
        getContentResolver().update(ContactsContract.Contacts.CONTENT_URI, values, "_id = " + this.mContactId, null);
    }
}
