package com.baoyi.ring.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.utils.content;
import com.baoyi.doamin.CheckWork;
import com.baoyi.ring.adapter.LocalMusicAdapter;
import com.baoyi.ring.builder.LocalMusicBuilder;
import com.baoyi.ring.entity.LocalMusic;
import com.baoyi.ring.widget.LocalMusicWidget;
import com.hope.leyuan.R;
import com.ringdroid.soundfile.CheapSoundFile;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class LocalFragment extends Fragment implements View.OnClickListener {
    LocalMusicAdapter adapter;
    CheckBox checkBox;
    ImageButton deletework;
    ListView listView;
    private SimpleCursorAdapter mAdapter;
    ImageButton playwork;
    SeekBar seekBar;
    private static final String[] INTERNAL_COLUMNS = {"_id", "_data", "title", UpdateService.ARTIST, "album", "is_ringtone", "is_alarm", "is_notification", "is_music", "\"" + MediaStore.Audio.Media.INTERNAL_CONTENT_URI + "\"", "duration"};
    private static final String[] EXTERNAL_COLUMNS = {"_id", "_data", "title", UpdateService.ARTIST, "album", "is_ringtone", "is_alarm", "is_notification", "is_music", "\"" + MediaStore.Audio.Media.EXTERNAL_CONTENT_URI + "\"", "duration"};
    public Handler handler = new Handler();
    public Runnable work = new Runnable() { // from class: com.baoyi.ring.fragment.LocalFragment.1
        @Override // java.lang.Runnable
        public void run() {
            if (LocalMusicWidget.mediaPlayer != null) {
                if (LocalMusicWidget.mediaPlayer.isPlaying()) {
                    int cp = LocalMusicWidget.mediaPlayer.getCurrentPosition();
                    int duration = LocalMusicWidget.mediaPlayer.getDuration();
                    LocalFragment.this.seekBar.setMax(duration);
                    LocalFragment.this.seekBar.setProgress(cp);
                    LocalFragment.this.playwork.setImageResource(R.drawable.ring_music_stop_selector);
                } else {
                    LocalFragment.this.playwork.setImageResource(R.drawable.ring_music_play_selector);
                }
            }
            LocalFragment.this.handler.postDelayed(this, 1000L);
        }
    };

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ring_local, container, false);
        return view;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        content.ISKIND = 0;
        this.listView = (ListView) getView().findViewById(R.id.listView);
        this.checkBox = (CheckBox) getView().findViewById(R.id.checkBox);
        this.deletework = (ImageButton) getView().findViewById(R.id.deletework);
        this.playwork = (ImageButton) getView().findViewById(R.id.playwork);
        this.seekBar = (SeekBar) getView().findViewById(R.id.seekBar);
        this.deletework.setOnClickListener(this);
        this.playwork.setOnClickListener(this);
        this.adapter = new LocalMusicAdapter(getActivity(), this);
        initdatas();
        this.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.baoyi.ring.fragment.LocalFragment.2
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    int size = LocalFragment.this.adapter.getCount();
                    for (int j = 0; j < size; j++) {
                        LocalFragment.this.adapter.getData(j).setIsselect(true);
                    }
                    LocalFragment.this.adapter.notifyDataSetChanged();
                    return;
                }
                int size2 = LocalFragment.this.adapter.getCount();
                for (int j2 = 0; j2 < size2; j2++) {
                    LocalFragment.this.adapter.getData(j2).setIsselect(false);
                }
                LocalFragment.this.adapter.notifyDataSetChanged();
            }
        });
        this.listView.setItemsCanFocus(true);
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.baoyi.ring.fragment.LocalFragment.3
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && LocalMusicWidget.mediaPlayer != null && LocalMusicWidget.mediaPlayer.isPlaying()) {
                    LocalMusicWidget.mediaPlayer.seekTo(progress);
                    LocalMusicWidget.mediaPlayer.start();
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initdatas() {
        this.adapter.clear();
        Cursor result = createCursor(null);
        List<LocalMusic> all = new ArrayList<>();
        LocalMusicBuilder b = new LocalMusicBuilder();
        int i = 0;
        if (result != null) {
            result.moveToFirst();
            while (!result.isAfterLast()) {
                LocalMusic music = b.build(result);
                String musicpath = music.getUrl();
                if (musicpath.startsWith(content.SAVEDIR)) {
                    all.add(b.build(result));
                    this.adapter.add(b.build(result));
                    result.moveToNext();
                    i++;
                    if (i <= 150) {
                    }
                } else {
                    result.moveToNext();
                }
            }
            try {
                result.close();
            } catch (Exception e) {
            }
        }
    }

    Cursor createCursor(String filter) {
        String selection;
        ArrayList<String> args = new ArrayList<>();
        if (filter == null) {
            selection = "(_DATA LIKE ?)";
            args.add("%");
        } else {
            String selection2 = "(";
            for (String extension : CheapSoundFile.getSupportedExtensions()) {
                args.add("%." + extension);
                if (selection2.length() > 1) {
                    selection2 = String.valueOf(selection2) + " OR ";
                }
                selection2 = String.valueOf(selection2) + "(_DATA LIKE ?)";
            }
            selection = "(" + (String.valueOf(selection2) + ")") + ") AND (_DATA NOT LIKE ?)";
            args.add("%espeak-data/scratch%");
        }
        if (filter != null && filter.length() > 0) {
            String filter2 = "%" + filter + "%";
            selection = "(" + selection + " AND ((TITLE LIKE ?) OR (ARTIST LIKE ?) OR (ALBUM LIKE ?)))";
            args.add(filter2);
            args.add(filter2);
            args.add(filter2);
        }
        String[] argsArray = (String[]) args.toArray(new String[args.size()]);
        Cursor external = getExternalAudioCursor(selection, argsArray);
        return external;
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        super.onResume();
        Log.i("ada", "铃声本地onResume");
    }

    @Override // android.support.v4.app.Fragment
    public void onStop() {
        super.onStop();
        Log.i("ada", "铃声本地onStop");
    }

    @Override // android.support.v4.app.Fragment
    public void onStart() {
        super.onStart();
        Log.i("ada", "铃声本地onStart");
    }

    @Override // android.support.v4.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        Log.i("ada", "铃声本地onDestroy");
    }

    @Override // android.support.v4.app.Fragment
    public void onDetach() {
        super.onDetach();
        Log.i("ada", "铃声本地onDetach");
    }

    @Override // android.support.v4.app.Fragment
    public void onPause() {
        super.onPause();
        Log.i("ada", "铃声本地暂停");
        stopmusic();
    }

    @Override // android.support.v4.app.Fragment
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            this.handler.postDelayed(this.work, 1000L);
            resh();
        } else if (!isVisibleToUser) {
            this.handler.removeCallbacks(this.work);
            Log.i("ada", "铃声本地不可见");
            stopmusic();
        }
    }

    private void stopmusic() {
        if (LocalMusicWidget.mediaPlayer != null) {
            LocalMusicWidget.mediaPlayer.pause();
        }
    }

    private Cursor getInternalAudioCursor(String selection, String[] selectionArgs) {
        return managedQuery(MediaStore.Audio.Media.INTERNAL_CONTENT_URI, INTERNAL_COLUMNS, selection, selectionArgs, "title_key");
    }

    private Cursor managedQuery(Uri internalContentUri, String[] internalColumns, String selection, String[] selectionArgs, String defaultSortOrder) {
        FragmentActivity activity = getActivity();
        ContentResolver c = activity.getContentResolver();
        return c.query(internalContentUri, internalColumns, selection, selectionArgs, defaultSortOrder);
    }

    private Cursor getExternalAudioCursor(String selection, String[] selectionArgs) {
        return managedQuery(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, EXTERNAL_COLUMNS, selection, selectionArgs, "title_key");
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        if (v.getId() == 2131296384) {
            if (LocalMusicWidget.mediaPlayer != null) {
                if (LocalMusicWidget.mediaPlayer.isPlaying()) {
                    LocalMusicWidget.mediaPlayer.pause();
                    this.playwork.setImageResource(R.drawable.ring_music_play_selector);
                    return;
                } else {
                    LocalMusicWidget.mediaPlayer.start();
                    this.playwork.setImageResource(R.drawable.ring_music_stop_selector);
                    return;
                }
            }
            return;
        }
        if (v.getId() == 2131296381) {
            final List<LocalMusic> datas = new ArrayList<>();
            int size = this.adapter.getCount();
            for (int j = 0; j < size; j++) {
                LocalMusic m = this.adapter.getData(j);
                if (m.isIsselect()) {
                    datas.add(m);
                }
            }
            if (datas.size() > 0) {
                new AlertDialog.Builder(getActivity()).setTitle("删除音乐").setMessage("你确定要所选删除吗?").setPositiveButton("确定", new DialogInterface.OnClickListener() { // from class: com.baoyi.ring.fragment.LocalFragment.4
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int whichButton) {
                        new DeleteTask(LocalFragment.this.getActivity(), null).execute(datas);
                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() { // from class: com.baoyi.ring.fragment.LocalFragment.5
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int whichButton) {
                    }
                }).setCancelable(true).show();
            } else {
                Toast.makeText(getActivity(), "请选择需要删除的数据", 0).show();
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class DeleteTask extends AsyncTask<List<LocalMusic>, String, Void> {
        CheckWork checked;
        Context curcontext;
        File fileitem;
        private int isdown;
        private Dialog progressDialog = null;

        public DeleteTask(Context context, CheckWork check) {
            this.curcontext = context;
            this.checked = check;
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            this.progressDialog = ProgressDialog.show(this.curcontext, "删除数据", "正在删除数据");
            this.progressDialog.setTitle("删除数据");
            super.onPreExecute();
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            super.onCancelled();
        }

        @Override // android.os.AsyncTask
        public Void doInBackground(List<LocalMusic>... listArr) {
            try {
                List<LocalMusic> datas = listArr[0];
                if (datas != null) {
                    for (LocalMusic localMusic : datas) {
                        if (!new File(localMusic.getUrl()).delete()) {
                            publishProgress("删除" + localMusic.getTitle() + "失败");
                        }
                        Uri itemUri = Uri.parse(String.valueOf(MediaStore.Audio.Media.getContentUriForPath(localMusic.getUrl()).toString()) + "/" + localMusic.getId());
                        int size = this.curcontext.getContentResolver().delete(itemUri, null, null);
                        if (size > 0) {
                            publishProgress("删除" + localMusic.getTitle() + "成功");
                        }
                    }
                }
            } catch (Exception e) {
                this.isdown = -100;
                e.printStackTrace();
            }
            return null;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... aa) {
            this.progressDialog.setTitle(aa[0]);
        }

        @Override // android.os.AsyncTask
        public void onPostExecute(Void url) {
            super.onPostExecute((DeleteTask) url);
            this.progressDialog.dismiss();
            LocalFragment.this.initdatas();
            LocalFragment.this.adapter.notifyDataSetChanged();
        }
    }

    public void resh() {
        this.adapter.notifyDataSetChanged();
    }
}
