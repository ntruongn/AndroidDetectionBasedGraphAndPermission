package com.baoyi.audio.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.media.AudioManager;
import android.provider.Settings;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class VolumeDialog implements DialogInterface.OnCancelListener, View.OnClickListener, SeekBar.OnSeekBarChangeListener, CompoundButton.OnCheckedChangeListener {
    public static final String NOTIFICATIONS_USE_RING_VOLUME = "notifications_use_ring_volume";
    private Activity mActivity;
    private boolean mChecked;
    private Dialog mDialog;
    private boolean mInitialChecked;
    private AudioManager mManager;
    private Holder mNotificationHolder;
    private Holder mRingerHolder;
    private static final int[] STREAM_TYPES = {2, 5, 3, 4, 0, 1};
    private static final int[] TEXT_IDS = {R.id.text1, R.id.text2, R.id.text3, R.id.text4, R.id.text5, R.id.text6};
    private static final int[] SLIDER_IDS = {R.id.slider1, R.id.slider2, R.id.slider3, R.id.slider4, R.id.slider5, R.id.slider6};

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class Holder {
        int index;
        int max;
        SeekBar seek;
        TextView text;

        Holder() {
        }
    }

    public VolumeDialog(Activity activity) {
        this.mActivity = activity;
    }

    public void show() {
        int value;
        Dialog dialog = this.mDialog;
        AudioManager manager = this.mManager;
        if (dialog == null) {
            manager = (AudioManager) this.mActivity.getSystemService("audio");
            this.mManager = manager;
            dialog = new Dialog(this.mActivity);
            dialog.requestWindowFeature(1);
            dialog.setContentView(R.layout.settings_volume_streams);
            dialog.setOnCancelListener(this);
            dialog.findViewById(R.id.button1).setOnClickListener(this);
            dialog.findViewById(R.id.button2).setOnClickListener(this);
            ((CheckBox) dialog.findViewById(R.id.checkbox1)).setOnCheckedChangeListener(this);
            this.mDialog = dialog;
        }
        boolean useRingerVolume = useRingerVolume();
        int size = STREAM_TYPES.length;
        for (int i = 0; i < size; i++) {
            if (useRingerVolume && i == 1) {
                value = manager.getStreamVolume(STREAM_TYPES[i - 1]);
            } else {
                value = manager.getStreamVolume(STREAM_TYPES[i]);
            }
            int max = manager.getStreamMaxVolume(STREAM_TYPES[i]);
            TextView text = (TextView) dialog.findViewById(TEXT_IDS[i]);
            SeekBar seek = (SeekBar) dialog.findViewById(SLIDER_IDS[i]);
            Holder holder = new Holder();
            holder.index = i;
            holder.text = text;
            holder.max = max;
            holder.seek = seek;
            seek.setTag(holder);
            seek.setMax(holder.max);
            seek.setProgress(value);
            seek.setOnSeekBarChangeListener(this);
            text.setText(String.valueOf(value) + "/" + max);
            if (i == 0) {
                this.mRingerHolder = holder;
            } else if (i == 1) {
                this.mNotificationHolder = holder;
            }
        }
        CheckBox checkbox = (CheckBox) dialog.findViewById(R.id.checkbox1);
        checkbox.setChecked(useRingerVolume);
        boolean isChecked = checkbox.isChecked();
        this.mChecked = isChecked;
        this.mInitialChecked = isChecked;
        dialog.show();
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialog) {
        hide();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button1 /* 2131296444 */:
                AudioManager manager = this.mManager;
                Dialog dialog = this.mDialog;
                int size = STREAM_TYPES.length;
                int i = size;
                while (true) {
                    int i2 = i;
                    i = i2 - 1;
                    if (i2 > 0) {
                        SeekBar seek = (SeekBar) dialog.findViewById(SLIDER_IDS[i]);
                        manager.setStreamVolume(STREAM_TYPES[i], seek.getProgress(), 0);
                    } else {
                        Activity activity = this.mActivity;
                        int ringerVolume = manager.getStreamVolume(2);
                        int notifVolume = manager.getStreamVolume(5);
                        int ringerMode = manager.getRingerMode();
                        if (ringerVolume > 0 && ringerMode == 0) {
                            Toast.makeText(activity, activity.getString(R.string.msg_not_silent_warning, new Object[]{Integer.valueOf(ringerVolume)}), 1).show();
                        } else if (ringerVolume == 0 && ringerMode == 2) {
                            Toast.makeText(activity, (int) R.string.msg_zero_ringer_warning, 1).show();
                        } else if (notifVolume == 0 && ringerMode == 2) {
                            Toast.makeText(activity, (int) R.string.msg_zero_notification_warning, 1).show();
                        }
                        Toast.makeText(this.mActivity, "设置成功", 0).show();
                        hide();
                        return;
                    }
                }
                break;
            case R.id.button2 /* 2131296445 */:
                if (this.mChecked != this.mInitialChecked) {
                    setUseRingerVolume(this.mInitialChecked);
                }
                hide();
                return;
            default:
                return;
        }
    }

    public void hide() {
        if (this.mDialog != null) {
            this.mDialog.hide();
        }
    }

    public void dismiss() {
        if (this.mDialog != null) {
            this.mDialog.dismiss();
        }
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (fromUser) {
            Holder holder = (Holder) seekBar.getTag();
            String text = String.valueOf(progress) + "/" + holder.max;
            holder.text.setText(text);
            if (this.mChecked && holder == this.mRingerHolder) {
                this.mNotificationHolder.seek.setProgress(this.mRingerHolder.seek.getProgress());
                this.mNotificationHolder.text.setText(this.mRingerHolder.text.getText());
            }
        }
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        this.mChecked = isChecked;
        setUseRingerVolume(this.mChecked);
        SeekBar seek = this.mNotificationHolder.seek;
        if (isChecked) {
            seek.setEnabled(false);
            seek.setProgress(this.mRingerHolder.seek.getProgress());
            this.mNotificationHolder.text.setText(this.mRingerHolder.text.getText());
            return;
        }
        seek.setEnabled(true);
    }

    private boolean useRingerVolume() {
        return Settings.System.getInt(this.mActivity.getContentResolver(), NOTIFICATIONS_USE_RING_VOLUME, 1) == 1;
    }

    private void setUseRingerVolume(boolean checked) {
        Settings.System.putInt(this.mActivity.getContentResolver(), NOTIFICATIONS_USE_RING_VOLUME, checked ? 1 : 0);
    }
}
