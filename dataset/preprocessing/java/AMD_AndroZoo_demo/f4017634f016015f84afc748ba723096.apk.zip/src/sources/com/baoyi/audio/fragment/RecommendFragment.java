package com.baoyi.audio.fragment;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.baoyi.audio.adapter.MusicItemListAdapter;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RecommendFragment extends Fragment {
    MusicItemListAdapter adapter;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    int type;
    private boolean work = false;
    int page = 0;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.page = 0;
        this.type = 1;
        this.mPullRefreshListView = (PullToRefreshListView) getView().findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() { // from class: com.baoyi.audio.fragment.RecommendFragment.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener
            public void onRefresh(PullToRefreshBase<ListView> refreshView) {
                Log.i("ada", "加载");
                if (!RecommendFragment.this.work) {
                    new HotTask(RecommendFragment.this, null).execute(Integer.valueOf(RecommendFragment.this.page));
                }
            }
        });
        WidgetLoadling tv = new WidgetLoadling(getActivity());
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new MusicItemListAdapter(getActivity());
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setBackgroundColor(17170445);
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setDividerHeight(2);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("com.iym.imusic_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(getActivity());
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
        new HotTask(this, null).execute(Integer.valueOf(this.page));
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Music>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(RecommendFragment recommendFragment, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Music> doInBackground(Integer... params) {
            long time = System.currentTimeMillis();
            RecommendFragment.this.work = true;
            List<Music> temp = null;
            try {
                temp = RpcUtils2.getMusicDao().pageByRecommend(content.showsize, params[0].intValue()).getDatas();
                if (System.currentTimeMillis() - time < 1000) {
                    try {
                        Thread.sleep(1500L);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e2) {
            }
            return temp;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Music> result) {
            RecommendFragment.this.work = false;
            RecommendFragment.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.PULL_UP_TO_REFRESH);
            if (result != null) {
                for (Music music : result) {
                    RecommendFragment.this.adapter.addLast(music);
                }
                RecommendFragment.this.adapter.notifyDataSetChanged();
                RecommendFragment.this.mPullRefreshListView.onRefreshComplete();
                RecommendFragment.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + RecommendFragment.this.adapter.getCount() + "首铃声");
                RecommendFragment.this.page++;
                return;
            }
            if (RecommendFragment.this.page == 0) {
                RecommendFragment.this.mPullRefreshListView.setEmptyView(null);
                Toast.makeText(RecommendFragment.this.getActivity(), "获取数据失败，请稍候再试。", 0).show();
            }
            RecommendFragment.this.mPullRefreshListView.onRefreshComplete();
        }
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_new, container, false);
        return view;
    }
}
