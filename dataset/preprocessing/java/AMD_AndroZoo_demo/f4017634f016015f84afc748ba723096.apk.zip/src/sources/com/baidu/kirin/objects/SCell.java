package com.baidu.kirin.objects;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SCell {
    public int MCC;
    public int MCCMNC;
    public int MNC;
    public String cellType;

    public String toString() {
        return null;
    }
}
