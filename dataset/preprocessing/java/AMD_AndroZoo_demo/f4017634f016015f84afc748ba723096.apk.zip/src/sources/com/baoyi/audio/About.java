package com.baoyi.audio;

import android.os.Bundle;
import android.webkit.WebView;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class About extends AnalyticsUI {
    int type;

    @Override // com.baoyi.audio.AnalyticsUI, com.baoyi.audio.BugActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
        this.type = getIntent().getIntExtra("type", 1);
        WebView wv = (WebView) findViewById(R.id.wv1);
        wv.setBackgroundColor(0);
        wv.getSettings().setAllowFileAccess(true);
        wv.getSettings().setJavaScriptEnabled(true);
        if (this.type == 1) {
            wv.loadUrl("http://iring.wutianxia.com:8999/iringdata/apps.html");
        }
        if (this.type == 2) {
            wv.loadUrl("file:///android_asset/a.html");
        }
        if (this.type == 3) {
            wv.loadUrl("file:///android_asset/b.html");
        }
    }
}
