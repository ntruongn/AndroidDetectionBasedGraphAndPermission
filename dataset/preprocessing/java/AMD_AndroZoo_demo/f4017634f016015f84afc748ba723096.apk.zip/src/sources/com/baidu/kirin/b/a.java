package com.baidu.kirin.b;

import android.content.Context;
import android.content.SharedPreferences;
import com.baidu.kirin.KirinConfig;
import com.baidu.kirin.d.d;
import java.lang.ref.SoftReference;
import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class a implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static SoftReference<a> a = null;
    private final Context b;
    private final SharedPreferences c = f().getSharedPreferences(f().getPackageName() + ".kirin_strategy_control_pref", 0);

    private a(Context context) {
        this.b = context.getApplicationContext();
    }

    public static synchronized a a(Context context) {
        a aVar;
        synchronized (a.class) {
            aVar = a == null ? null : a.get();
            if (aVar == null) {
                synchronized (a.class) {
                    aVar = a == null ? null : a.get();
                    if (aVar == null) {
                        aVar = new a(context);
                        a = new SoftReference<>(aVar);
                    }
                }
            }
        }
        return aVar;
    }

    private boolean a(String str, String str2) {
        return c(str) > c(str2);
    }

    private int c(String str) {
        return (Integer.parseInt(str.split(":")[0]) * 60 * 60) + (Integer.parseInt(str.split(":")[1]) * 60) + Integer.parseInt(str.split(":")[2]);
    }

    private Context f() {
        return this.b;
    }

    private boolean g() {
        long time = new Date().getTime();
        int i = this.c.getInt("kirin_update_freqency", -1);
        long j = this.c.getLong("kirin_strategy_record_time", -1L);
        if (j == -1) {
            return true;
        }
        if ((time - j) / 1000 >= i) {
            d.a(time + " --> exceed interval : " + i);
            return true;
        }
        d.a(time + " --> don't exceed interval : " + i);
        return false;
    }

    private boolean h() {
        long time = new Date().getTime();
        long j = this.c.getLong("kirin_strategy_record_time", -1L);
        if (j == -1) {
            return true;
        }
        if ((time - j) / 1000 > KirinConfig.DEFAULT_UPDATE_INTERVAL) {
            d.a(time + " --> exceed interval : " + KirinConfig.DEFAULT_UPDATE_INTERVAL);
            return true;
        }
        d.a(time + " --> don't exceed interval : " + KirinConfig.DEFAULT_UPDATE_INTERVAL);
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x00b5  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x00ca  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private boolean i() {
        /*
            r14 = this;
            r4 = 0
            r2 = 1
            r3 = 0
            java.lang.String r0 = r14.e()
            r5 = 86400000(0x5265c00, float:7.82218E-36)
            java.lang.String r1 = "\\|"
            java.lang.String[] r1 = r0.split(r1)
            r6 = r1[r3]
            java.lang.String r1 = "\\|"
            java.lang.String[] r0 = r0.split(r1)
            r7 = r0[r2]
            java.io.PrintStream r0 = java.lang.System.out
            r0.println(r6)
            java.io.PrintStream r0 = java.lang.System.out
            r0.println(r7)
            java.util.Date r0 = new java.util.Date
            r0.<init>()
            long r8 = r0.getTime()
            java.text.SimpleDateFormat r0 = new java.text.SimpleDateFormat
            java.lang.String r1 = "yyyy-MM-dd"
            r0.<init>(r1)
            java.lang.Long r1 = java.lang.Long.valueOf(r8)
            java.lang.String r0 = r0.format(r1)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.StringBuilder r1 = r1.append(r0)
            java.lang.String r10 = " "
            java.lang.StringBuilder r1 = r1.append(r10)
            java.lang.StringBuilder r1 = r1.append(r6)
            java.lang.String r1 = r1.toString()
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            java.lang.StringBuilder r0 = r10.append(r0)
            java.lang.String r10 = " "
            java.lang.StringBuilder r0 = r0.append(r10)
            java.lang.StringBuilder r0 = r0.append(r7)
            java.lang.String r0 = r0.toString()
            java.io.PrintStream r10 = java.lang.System.out
            r10.println(r1)
            java.io.PrintStream r10 = java.lang.System.out
            r10.println(r0)
            java.text.SimpleDateFormat r10 = new java.text.SimpleDateFormat
            java.lang.String r11 = "yyyy-MM-dd HH:mm:ss"
            r10.<init>(r11)
            java.util.Date r1 = r10.parse(r1)     // Catch: java.text.ParseException -> Lbf
            java.util.Date r0 = r10.parse(r0)     // Catch: java.text.ParseException -> Ld9
            java.io.PrintStream r4 = java.lang.System.out     // Catch: java.text.ParseException -> Lde
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch: java.text.ParseException -> Lde
            r10.<init>()     // Catch: java.text.ParseException -> Lde
            long r11 = r1.getTime()     // Catch: java.text.ParseException -> Lde
            java.lang.StringBuilder r10 = r10.append(r11)     // Catch: java.text.ParseException -> Lde
            java.lang.String r11 = " - "
            java.lang.StringBuilder r10 = r10.append(r11)     // Catch: java.text.ParseException -> Lde
            long r11 = r0.getTime()     // Catch: java.text.ParseException -> Lde
            java.lang.StringBuilder r10 = r10.append(r11)     // Catch: java.text.ParseException -> Lde
            java.lang.String r10 = r10.toString()     // Catch: java.text.ParseException -> Lde
            r4.println(r10)     // Catch: java.text.ParseException -> Lde
        La7:
            long r10 = r1.getTime()
            long r0 = r0.getTime()
            boolean r4 = r14.a(r7, r6)
            if (r4 == 0) goto Lca
            int r4 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r4 < 0) goto Lc8
            int r0 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
            if (r0 > 0) goto Lc8
            r0 = r2
        Lbe:
            return r0
        Lbf:
            r0 = move-exception
            r1 = r4
            r13 = r4
            r4 = r0
            r0 = r13
        Lc4:
            r4.printStackTrace()
            goto La7
        Lc8:
            r0 = r3
            goto Lbe
        Lca:
            long r4 = (long) r5
            long r4 = r10 - r4
            int r4 = (r8 > r4 ? 1 : (r8 == r4 ? 0 : -1))
            if (r4 < 0) goto Ld7
            int r0 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
            if (r0 > 0) goto Ld7
        Ld5:
            r0 = r2
            goto Lbe
        Ld7:
            r2 = r3
            goto Ld5
        Ld9:
            r0 = move-exception
            r13 = r0
            r0 = r4
            r4 = r13
            goto Lc4
        Lde:
            r4 = move-exception
            goto Lc4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.baidu.kirin.b.a.i():boolean");
    }

    public void a(boolean z, JSONObject jSONObject) {
        long time = new Date().getTime();
        SharedPreferences.Editor edit = this.c.edit();
        if (z) {
            try {
                int i = jSONObject.getInt("updateSwitch");
                int i2 = jSONObject.getInt("updateFrequency");
                int i3 = jSONObject.getInt("popFrequency");
                String string = jSONObject.getString("openPeriod");
                d.a("write to strategy controller data is  :  success : " + z + "; updateSwith : " + i + "; updateFrequency : " + i2 + "; popFrequency : " + i3);
                edit.putLong("kirin_strategy_record_time", time);
                edit.putInt("kirin_update_switcher", i);
                edit.putInt("kirin_update_freqency", i2 * 86400);
                edit.putInt("kirin_update_remind_freqency", i3 * 86400);
                edit.putString("kirin_open_peroid", string);
            } catch (JSONException e) {
                e.printStackTrace();
                edit.putLong("kirin_strategy_record_time", time);
                edit.putInt("kirin_update_switcher", 0);
                edit.putInt("kirin_update_freqency", KirinConfig.DEFAULT_UPDATE_INTERVAL);
                edit.putInt("kirin_update_remind_freqency", KirinConfig.DEFAULT_POP_INTERVAL);
                edit.putString("kirin_open_peroid", KirinConfig.DEFAULT_OPEN_PEROID);
            }
        } else {
            edit.putLong("kirin_strategy_record_time", time);
            edit.putInt("kirin_update_switcher", 0);
            edit.putInt("kirin_update_freqency", KirinConfig.DEFAULT_UPDATE_INTERVAL);
            edit.putInt("kirin_update_remind_freqency", KirinConfig.DEFAULT_POP_INTERVAL);
            edit.putString("kirin_open_peroid", KirinConfig.DEFAULT_OPEN_PEROID);
        }
        edit.commit();
    }

    public boolean a() {
        if (!i()) {
            return false;
        }
        int i = this.c.getInt("kirin_update_switcher", -1);
        if (!g() && i == 1) {
            d.a("!isExceedServerUpdateInterval() && switcher == 1");
            return false;
        }
        if (i == 0) {
            d.a("else if(switcher == 0)");
            return h();
        }
        d.a("else!");
        return true;
    }

    public boolean a(String str) {
        if (!i()) {
            return false;
        }
        if (str.equals(KirinConfig.ATSTART)) {
            return a();
        }
        if (str.equals(KirinConfig.ATSETTING)) {
            return b();
        }
        return false;
    }

    public void b(String str) {
        SharedPreferences.Editor edit = this.c.edit();
        edit.putString("kirin_log_id", str);
        edit.commit();
    }

    public boolean b() {
        return i();
    }

    public boolean c() {
        if (!i()) {
            return false;
        }
        int i = this.c.getInt("kirin_update_switcher", -1);
        return i == -1 || i == 1;
    }

    public String d() {
        return this.c.getString("kirin_log_id", "0");
    }

    public String e() {
        return this.c.getString("kirin_open_peroid", KirinConfig.DEFAULT_OPEN_PEROID);
    }

    @Override // android.content.SharedPreferences.OnSharedPreferenceChangeListener
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String str) {
        if (sharedPreferences == this.c) {
            d.a(str + " : has changed");
        }
    }
}
