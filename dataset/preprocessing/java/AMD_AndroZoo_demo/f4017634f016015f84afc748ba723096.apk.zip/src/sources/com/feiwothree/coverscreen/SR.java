package com.feiwothree.coverscreen;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.feiwothree.coverscreen.a.C0005a;
import com.feiwothree.coverscreen.a.C0006b;
import com.feiwothree.coverscreen.a.C0013i;
import com.feiwothree.coverscreen.a.I;
import com.feiwothree.coverscreen.a.J;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SR extends BroadcastReceiver {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(SR sr, Context context, String str) {
        String str2;
        String a = I.a(context, "DP_FEIWO", str.replace(".", ""));
        new StringBuilder("根据包名查询广告ID, [").append(str).append(",").append(a).append("]");
        long j = 0;
        if (a == null || a.split(",").length != 2) {
            str2 = null;
        } else {
            String str3 = a.split(",")[0];
            try {
                j = Long.parseLong(a.split(",")[1]);
            } catch (Exception e) {
            }
            str2 = new Date().getTime() - j > 1800000 ? null : str3;
        }
        String a2 = I.a(context, "DP_FEIWO", "appkey");
        if (J.a(a2)) {
            return;
        }
        JSONArray jSONArray = new JSONArray();
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("packageName", str);
        jSONObject.put("adid", str2);
        jSONArray.put(jSONObject);
        if (str2 != null) {
            com.feiwothree.coverscreen.a.x.a(context).a(com.feiwothree.coverscreen.a.y.a(str2, 0) + 12345);
            I.b(context, "DP_FEIWO", str.replace(".", ""));
        }
        com.feiwothree.coverscreen.a.z.a();
        if (com.feiwothree.coverscreen.a.z.c(context, str)) {
            if (str2 == null) {
                Thread.sleep(1000L);
            } else {
                com.feiwothree.coverscreen.a.z.a();
                com.feiwothree.coverscreen.a.z.b(context, str);
            }
            JSONObject a3 = C0005a.a(context, "1.9", jSONArray);
            com.feiwothree.coverscreen.a.u uVar = new com.feiwothree.coverscreen.a.u();
            uVar.a(context, C0006b.d(), a2, a3.toString());
            uVar.a(new q(sr, context, str));
            com.feiwothree.coverscreen.a.s.a().a(uVar);
        }
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (C0013i.a(context)) {
            if (intent.getAction().equalsIgnoreCase("android.intent.action.PACKAGE_ADDED")) {
                new p(this, intent, context).start();
                return;
            }
            if (!intent.getAction().equalsIgnoreCase("broadcast.route.control")) {
                if (intent.getAction().equalsIgnoreCase("android.net.conn.CONNECTIVITY_CHANGE")) {
                    try {
                        C0013i.a().b();
                        return;
                    } catch (Exception e) {
                        return;
                    }
                }
                return;
            }
            switch (intent.getIntExtra("type", 0)) {
                case 1:
                    String stringExtra = intent.getStringExtra("packageName");
                    if (stringExtra == null || stringExtra.length() <= 0) {
                        return;
                    }
                    I.b(context, "DP_FEIWO", stringExtra.replace(".", ""));
                    new StringBuilder("清理包名对应的广告ID：").append(stringExtra);
                    return;
                default:
                    return;
            }
        }
    }
}
