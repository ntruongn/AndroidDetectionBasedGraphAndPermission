package com.baoyi.ring.fragment;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import java.io.IOException;
import java.util.LinkedList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class AsyncPlayer {
    private static final int PLAY = 1;
    private static final int STOP = 2;
    private static final boolean mDebug = false;
    private MediaPlayer mPlayer;
    private String mTag;
    private Thread mThread;
    private PowerManager.WakeLock mWakeLock;
    private LinkedList<Command> mCmdQueue = new LinkedList<>();
    private int mState = 2;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public static final class Command {
        int code;
        Context context;
        boolean looping;
        long requestTime;
        int stream;
        String uri;

        private Command() {
        }

        /* synthetic */ Command(Command command) {
            this();
        }

        public String toString() {
            return "{ code=" + this.code + " looping=" + this.looping + " stream=" + this.stream + " uri=" + this.uri + " }";
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startSound(Command cmd) {
        try {
            MediaPlayer player = new MediaPlayer();
            player.setAudioStreamType(cmd.stream);
            player.setDataSource(cmd.uri);
            player.setLooping(cmd.looping);
            player.prepare();
            player.start();
            if (this.mPlayer != null) {
                this.mPlayer.release();
            }
            this.mPlayer = player;
        } catch (IOException e) {
            Log.w(this.mTag, "error loading sound for " + cmd.uri, e);
        } catch (IllegalStateException e2) {
            Log.w(this.mTag, "IllegalStateException (content provider died?) " + cmd.uri, e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public final class Thread extends java.lang.Thread {
        Thread() {
            super("AsyncPlayer-" + AsyncPlayer.this.mTag);
        }

        /* JADX WARN: Removed duplicated region for block: B:11:0x0024 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        @Override // java.lang.Thread, java.lang.Runnable
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void run() {
            /*
                r5 = this;
                r4 = 0
            L1:
                r1 = 0
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this
                java.util.LinkedList r3 = com.baoyi.ring.fragment.AsyncPlayer.access$1(r2)
                monitor-enter(r3)
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this     // Catch: java.lang.Throwable -> L3d
                java.util.LinkedList r2 = com.baoyi.ring.fragment.AsyncPlayer.access$1(r2)     // Catch: java.lang.Throwable -> L3d
                java.lang.Object r2 = r2.removeFirst()     // Catch: java.lang.Throwable -> L3d
                r0 = r2
                com.baoyi.ring.fragment.AsyncPlayer$Command r0 = (com.baoyi.ring.fragment.AsyncPlayer.Command) r0     // Catch: java.lang.Throwable -> L3d
                r1 = r0
                monitor-exit(r3)     // Catch: java.lang.Throwable -> L3d
                int r2 = r1.code
                switch(r2) {
                    case 1: goto L40;
                    case 2: goto L46;
                    default: goto L1d;
                }
            L1d:
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this
                java.util.LinkedList r3 = com.baoyi.ring.fragment.AsyncPlayer.access$1(r2)
                monitor-enter(r3)
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this     // Catch: java.lang.Throwable -> L74
                java.util.LinkedList r2 = com.baoyi.ring.fragment.AsyncPlayer.access$1(r2)     // Catch: java.lang.Throwable -> L74
                int r2 = r2.size()     // Catch: java.lang.Throwable -> L74
                if (r2 != 0) goto L72
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this     // Catch: java.lang.Throwable -> L74
                r4 = 0
                com.baoyi.ring.fragment.AsyncPlayer.access$5(r2, r4)     // Catch: java.lang.Throwable -> L74
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this     // Catch: java.lang.Throwable -> L74
                com.baoyi.ring.fragment.AsyncPlayer.access$6(r2)     // Catch: java.lang.Throwable -> L74
                monitor-exit(r3)     // Catch: java.lang.Throwable -> L74
                return
            L3d:
                r2 = move-exception
                monitor-exit(r3)     // Catch: java.lang.Throwable -> L3d
                throw r2
            L40:
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this
                com.baoyi.ring.fragment.AsyncPlayer.access$2(r2, r1)
                goto L1d
            L46:
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this
                android.media.MediaPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.access$3(r2)
                if (r2 == 0) goto L66
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this
                android.media.MediaPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.access$3(r2)
                r2.stop()
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this
                android.media.MediaPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.access$3(r2)
                r2.release()
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this
                com.baoyi.ring.fragment.AsyncPlayer.access$4(r2, r4)
                goto L1d
            L66:
                com.baoyi.ring.fragment.AsyncPlayer r2 = com.baoyi.ring.fragment.AsyncPlayer.this
                java.lang.String r2 = com.baoyi.ring.fragment.AsyncPlayer.access$0(r2)
                java.lang.String r3 = "STOP command without a player"
                android.util.Log.w(r2, r3)
                goto L1d
            L72:
                monitor-exit(r3)     // Catch: java.lang.Throwable -> L74
                goto L1
            L74:
                r2 = move-exception
                monitor-exit(r3)     // Catch: java.lang.Throwable -> L74
                throw r2
            */
            throw new UnsupportedOperationException("Method not decompiled: com.baoyi.ring.fragment.AsyncPlayer.Thread.run():void");
        }
    }

    public AsyncPlayer(String tag) {
        if (tag != null) {
            this.mTag = tag;
        } else {
            this.mTag = "AsyncPlayer";
        }
    }

    public void play(Context context, String uri, boolean looping, int stream) {
        MediaPlayer md = new MediaPlayer();
        try {
            md.setDataSource(uri);
            md.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e2) {
            e2.printStackTrace();
        } catch (IllegalStateException e3) {
            e3.printStackTrace();
        } catch (SecurityException e4) {
            e4.printStackTrace();
        }
        md.start();
    }

    public void stop() {
        synchronized (this.mCmdQueue) {
            if (this.mState != 2) {
                Command cmd = new Command(null);
                cmd.requestTime = SystemClock.uptimeMillis();
                cmd.code = 2;
                enqueueLocked(cmd);
                this.mState = 2;
            }
        }
    }

    private void enqueueLocked(Command cmd) {
        this.mCmdQueue.add(cmd);
        if (this.mThread == null) {
            acquireWakeLock();
            this.mThread = new Thread();
            this.mThread.start();
        }
    }

    public void setUsesWakeLock(Context context) {
        if (this.mWakeLock != null || this.mThread != null) {
            throw new RuntimeException("assertion failed mWakeLock=" + this.mWakeLock + " mThread=" + this.mThread);
        }
        PowerManager pm = (PowerManager) context.getSystemService("power");
        this.mWakeLock = pm.newWakeLock(1, this.mTag);
    }

    private void acquireWakeLock() {
        if (this.mWakeLock != null) {
            this.mWakeLock.acquire();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void releaseWakeLock() {
        if (this.mWakeLock != null) {
            this.mWakeLock.release();
        }
    }
}
