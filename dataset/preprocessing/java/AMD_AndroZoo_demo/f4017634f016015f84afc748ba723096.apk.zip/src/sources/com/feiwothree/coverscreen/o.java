package com.feiwothree.coverscreen;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class o implements com.feiwothree.coverscreen.a.t {
    /* JADX INFO: Access modifiers changed from: package-private */
    public o(SA sa) {
    }

    @Override // com.feiwothree.coverscreen.a.t
    public final void a(boolean z, String str) {
        new StringBuilder("服务器返回（sendShowRequest）：").append(str);
    }
}
