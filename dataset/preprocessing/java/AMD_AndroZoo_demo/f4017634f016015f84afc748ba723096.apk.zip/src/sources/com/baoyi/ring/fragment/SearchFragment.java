package com.baoyi.ring.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.baoyi.adapter.NewRingAdapter1;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.utils.Utils;
import com.baoyi.weight.KeywordsView;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import com.iring.rpc.MusicRpc;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SearchFragment extends Fragment implements View.OnClickListener {
    private static final int Msg_Load_End = 515;
    private static final int Msg_Start_Load = 258;
    private NewRingAdapter1 adapter;
    private ImageButton del;
    private EditText et;
    private boolean isOutter;
    private ListView lv;
    private GestureDetector mggd;
    private ImageButton serch;
    private KeywordsView showKeywords = null;
    private String[] key_words = new String[15];
    private String[] totalKeys = {"轻音乐", "铃声", "好听", "短信", "非主流", "优美", "中国风", "领悟", "春晚", "可爱", "小孩", "2013", "轻音乐", "好听", "闹铃"};
    private LoadKeywordsTask task = null;
    private Handler handler = new Handler() { // from class: com.baoyi.ring.fragment.SearchFragment.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SearchFragment.Msg_Start_Load /* 258 */:
                    SearchFragment.this.task = new LoadKeywordsTask(SearchFragment.this, null);
                    new Thread(SearchFragment.this.task).start();
                    return;
                case SearchFragment.Msg_Load_End /* 515 */:
                    SearchFragment.this.showKeywords.rubKeywords();
                    SearchFragment.this.feedKeywordsFlow(SearchFragment.this.showKeywords, SearchFragment.this.key_words);
                    SearchFragment.this.showKeywords.go2Shwo(1);
                    return;
                default:
                    return;
            }
        }
    };

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ring_search, container, false);
        return view;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        content.ISKIND = 0;
        this.showKeywords = (KeywordsView) getView().findViewById(R.id.ring_search_flyword);
        this.et = (EditText) getView().findViewById(R.id.ring_search_et);
        this.del = (ImageButton) getView().findViewById(R.id.ring_search_del);
        this.serch = (ImageButton) getView().findViewById(R.id.ring_search_btn);
        this.lv = (ListView) getView().findViewById(R.id.ring_search_lv);
        this.del.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.SearchFragment.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                SearchFragment.this.et.setText("");
                SearchFragment.this.showKeywords.setVisibility(0);
                SearchFragment.this.lv.setVisibility(8);
            }
        });
        this.serch.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.SearchFragment.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                System.out.println("开始搜索了");
                SearchFragment.this.searchmusic();
            }
        });
        this.showKeywords.setDuration(2000L);
        this.showKeywords.setOnItemClickListener(this);
        this.mggd = new GestureDetector(new Mygdlinseter());
        this.showKeywords.setOnTouchListener(new View.OnTouchListener() { // from class: com.baoyi.ring.fragment.SearchFragment.4
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View v, MotionEvent event) {
                return SearchFragment.this.mggd.onTouchEvent(event);
            }
        });
        this.isOutter = true;
        this.handler.sendEmptyMessage(Msg_Start_Load);
        this.et.addTextChangedListener(new TextWatcher() { // from class: com.baoyi.ring.fragment.SearchFragment.5
            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (SearchFragment.this.et != null) {
                    if (SearchFragment.this.et.getText().length() != 0) {
                        SearchFragment.this.showKeywords.setVisibility(8);
                        SearchFragment.this.lv.setVisibility(0);
                    } else {
                        SearchFragment.this.showKeywords.setVisibility(0);
                        SearchFragment.this.lv.setVisibility(8);
                        SearchFragment.this.isOutter = true;
                    }
                }
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
                if (SearchFragment.this.et != null) {
                    if (SearchFragment.this.et.getText().length() != 0) {
                        SearchFragment.this.showKeywords.setVisibility(8);
                        SearchFragment.this.lv.setVisibility(0);
                    } else {
                        SearchFragment.this.showKeywords.setVisibility(0);
                        SearchFragment.this.lv.setVisibility(8);
                        SearchFragment.this.isOutter = true;
                    }
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String[] getRandomArray() {
        if (this.totalKeys != null && this.totalKeys.length > 0) {
            String[] keys = new String[15];
            List<String> ks = new ArrayList<>();
            for (int i = 0; i < this.totalKeys.length; i++) {
                ks.add(this.totalKeys[i]);
            }
            for (int i2 = 0; i2 < keys.length; i2++) {
                int k = (int) (ks.size() * Math.random());
                keys[i2] = ks.remove(k);
                if (keys[i2] == null) {
                    System.out.println("nulnulnulnulnul");
                }
            }
            System.out.println("result's length = " + keys.length);
            return keys;
        }
        return new String[]{"美女", "电影", "英雄联盟", "嘿嘿", "性感", "LOL", "苍井空", "情侣", "骚年", "刘艳玲", "孟菲菲", "心情", "找力宏", "优", "楚汉传奇"};
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class LoadKeywordsTask implements Runnable {
        private LoadKeywordsTask() {
        }

        /* synthetic */ LoadKeywordsTask(SearchFragment searchFragment, LoadKeywordsTask loadKeywordsTask) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                SearchFragment.this.key_words = SearchFragment.this.getRandomArray();
                if (SearchFragment.this.key_words.length <= 0) {
                    return;
                }
                SearchFragment.this.handler.sendEmptyMessage(SearchFragment.Msg_Load_End);
            } catch (Exception e) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void feedKeywordsFlow(KeywordsView keyworldFlow, String[] arr) {
        for (int i = 0; i < 10; i++) {
            String tmp = arr[i];
            keyworldFlow.feedKeyword(tmp);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class Mygdlinseter implements GestureDetector.OnGestureListener {
        Mygdlinseter() {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent e) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent e) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent e) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            if (e2.getY() - e1.getY() < -100.0f) {
                SearchFragment.this.key_words = SearchFragment.this.getRandomArray();
                SearchFragment.this.showKeywords.rubKeywords();
                SearchFragment.this.feedKeywordsFlow(SearchFragment.this.showKeywords, SearchFragment.this.key_words);
                SearchFragment.this.showKeywords.go2Shwo(1);
                return true;
            }
            if (e2.getY() - e1.getY() > 100.0f) {
                SearchFragment.this.key_words = SearchFragment.this.getRandomArray();
                SearchFragment.this.showKeywords.rubKeywords();
                SearchFragment.this.feedKeywordsFlow(SearchFragment.this.showKeywords, SearchFragment.this.key_words);
                SearchFragment.this.showKeywords.go2Shwo(2);
                return true;
            }
            return false;
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        if (v instanceof TextView) {
            String kw = ((TextView) v).getText().toString();
            this.et.setText(kw);
            new SearcTask().execute(kw);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void searchmusic() {
        String key = this.et.getText().toString();
        if (key != null && key.length() > 0) {
            new SearcTask().execute(key);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class SearcTask extends AsyncTask<String, Integer, MusicRpc> {
        SearcTask() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public MusicRpc doInBackground(String... params) {
            MusicRpc rpc = null;
            try {
                rpc = RpcUtils2.getMusicDao().search(params[0], 20, 0);
                Log.i("ada", "搜索成功");
                return rpc;
            } catch (Exception e) {
                e.printStackTrace();
                return rpc;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(MusicRpc result) {
            if (result != null) {
                SearchFragment.this.lv.setVisibility(0);
                SearchFragment.this.showKeywords.setVisibility(8);
                ArrayList<Music> all = (ArrayList) result.getDatas();
                if (all != null && all.size() > 0) {
                    SearchFragment.this.adapter = new NewRingAdapter1(SearchFragment.this.getActivity(), all);
                    SearchFragment.this.lv.setAdapter((ListAdapter) SearchFragment.this.adapter);
                    SearchFragment.this.lv.setOnItemClickListener(SearchFragment.this.adapter);
                    return;
                }
                Utils.showMessage(SearchFragment.this.getActivity(), "没有搜索到哦，换个关键字搜吧。");
                SearchFragment.this.lv.setVisibility(8);
                SearchFragment.this.showKeywords.setVisibility(0);
                return;
            }
            Utils.showMessage(SearchFragment.this.getActivity(), "网络连接失败，请稍后再试。");
            SearchFragment.this.lv.setVisibility(8);
            SearchFragment.this.showKeywords.setVisibility(0);
        }
    }

    @Override // android.support.v4.app.Fragment
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!isVisibleToUser && !isVisibleToUser) {
            Log.i("ada", "铃声本地不可见");
            if (this.adapter != null) {
                this.adapter.stopMusic();
            }
        }
    }
}
