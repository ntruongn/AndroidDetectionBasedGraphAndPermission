package com.baoyi.doamin;

import com.baoyi.audio.utils.content;
import com.iring.entity.Music;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class KoWoMusicToMusic {
    public static KoWoMusic convert(Music music) {
        KoWoMusic koWoMusic = new KoWoMusic();
        koWoMusic.setName(music.getName());
        koWoMusic.setArt(music.getArtist());
        koWoMusic.setType(100);
        koWoMusic.setUrl(geturl(music));
        koWoMusic.setMid(music.getId().intValue());
        return koWoMusic;
    }

    private static String geturl(Music item) {
        String url = item.getUrl();
        if (url != null && !url.startsWith("http")) {
            return String.valueOf(content.mp3server) + url;
        }
        return url;
    }
}
