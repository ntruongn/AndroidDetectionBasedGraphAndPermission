package com.feiwothree.coverscreen;

import android.content.Context;
import com.feiwothree.coverscreen.a.I;

/* JADX INFO: Access modifiers changed from: package-private */
/* renamed from: com.feiwothree.coverscreen.c, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class C0016c implements com.feiwothree.coverscreen.a.t {
    private /* synthetic */ AdComponent a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public C0016c(AdComponent adComponent) {
        this.a = adComponent;
    }

    @Override // com.feiwothree.coverscreen.a.t
    public final void a(boolean z, String str) {
        Context context;
        new StringBuilder("服务器返回（uploadClientInfo）：").append(str);
        context = this.a.d;
        I.a(context, "coverscreen", "isFirstRun", false);
    }
}
