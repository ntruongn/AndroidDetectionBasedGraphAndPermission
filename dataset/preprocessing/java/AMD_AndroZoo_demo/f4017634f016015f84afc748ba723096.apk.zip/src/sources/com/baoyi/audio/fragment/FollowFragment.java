package com.baoyi.audio.fragment;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.baoyi.audio.About;
import com.baoyi.audio.FeedBack;
import com.baoyi.audio.SettingsActivity;
import com.baoyi.audio.adapter.MemberItemListAdapter;
import com.baoyi.audio.task.ClearCacheTask;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.dao.MemberDao;
import com.iring.entity.Member;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class FollowFragment extends Fragment implements View.OnClickListener {
    MemberItemListAdapter adapter;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    int page = 0;
    int userid;

    public FollowFragment(int userid) {
        this.userid = userid;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.mPullRefreshListView = (PullToRefreshListView) getView().findViewById(R.id.pull_refresh_list);
        this.mPullRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() { // from class: com.baoyi.audio.fragment.FollowFragment.1
            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            }

            @Override // com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                new HotTask(FollowFragment.this, null).execute(Integer.valueOf(FollowFragment.this.page));
            }
        });
        WidgetLoadling tv = new WidgetLoadling(getActivity());
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new MemberItemListAdapter(getActivity());
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("com.iym.imusic_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(getActivity());
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        new HotTask(this, null).execute(Integer.valueOf(this.page));
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Member>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(FollowFragment followFragment, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Member> doInBackground(Integer... params) {
            try {
                MemberDao dao = (MemberDao) RpcUtils2.getNoCacheDao("memberDao", MemberDao.class);
                List<Member> temp = dao.pageByMemberId(FollowFragment.this.userid, 20, FollowFragment.this.page).getDatas();
                return temp;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Member> result) {
            if (result != null) {
                for (Member music : result) {
                    FollowFragment.this.adapter.addLast(music);
                }
                FollowFragment.this.adapter.notifyDataSetChanged();
                FollowFragment.this.mPullRefreshListView.onRefreshComplete();
                FollowFragment.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + FollowFragment.this.adapter.getCount() + "首铃声");
                FollowFragment.this.page++;
                return;
            }
            if (FollowFragment.this.page == 0) {
                FollowFragment.this.mPullRefreshListView.setEmptyView(null);
                Activity activity = FollowFragment.this.getActivity();
                if (activity != null) {
                    Toast.makeText(activity, "获取数据失败，请稍候再试。", 0).show();
                }
            }
            FollowFragment.this.mPullRefreshListView.onRefreshComplete();
        }
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favmusic_list_new, container, false);
        return view;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        v.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.max));
        if (v.getId() == 2131296355) {
            new ClearCacheTask(getActivity()).execute(new Integer[0]);
        }
        if (v.getId() == 2131296356) {
            Intent intent = new Intent(getActivity(), (Class<?>) About.class);
            intent.putExtra("type", 3);
            startActivity(intent);
        }
        if (v.getId() == 2131296338) {
            startActivity(new Intent(getActivity(), (Class<?>) FeedBack.class));
        }
        if (v.getId() == 2131296357) {
            Intent intent2 = new Intent(getActivity(), (Class<?>) About.class);
            intent2.putExtra("type", 2);
            startActivity(intent2);
        }
        if (v.getId() == 2131296358) {
            rateApplication();
        }
        if (v.getId() == 2131296354) {
            setting();
        }
    }

    private void setting() {
        Intent rateIntent = new Intent(getActivity(), (Class<?>) SettingsActivity.class);
        startActivity(rateIntent);
    }

    protected void rateApplication() {
        Intent rateIntent = new Intent("android.intent.action.VIEW");
        rateIntent.setData(Uri.parse("market://details?id=" + getActivity().getPackageName()));
        startActivity(rateIntent);
    }
}
