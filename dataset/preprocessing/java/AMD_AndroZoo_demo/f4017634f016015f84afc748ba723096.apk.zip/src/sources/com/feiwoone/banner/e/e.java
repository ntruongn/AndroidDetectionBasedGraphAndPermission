package com.feiwoone.banner.e;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class e implements l {
    public e() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(g gVar) {
    }

    public static int a(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivityManager == null) {
            return 0;
        }
        NetworkInfo[] allNetworkInfo = connectivityManager.getAllNetworkInfo();
        if (allNetworkInfo != null) {
            int length = allNetworkInfo.length;
            for (int i = 0; i < length; i++) {
                if (allNetworkInfo[i].getState() == NetworkInfo.State.CONNECTED) {
                    if (allNetworkInfo[i].getTypeName().equalsIgnoreCase("MOBILE")) {
                        return (Proxy.getDefaultHost() == null || Proxy.getDefaultHost().equals("")) ? 11 : 12;
                    }
                    return 10;
                }
            }
        }
        return 0;
    }
}
