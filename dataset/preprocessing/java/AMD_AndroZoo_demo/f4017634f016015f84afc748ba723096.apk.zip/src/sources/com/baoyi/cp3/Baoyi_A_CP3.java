package com.baoyi.cp3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Baoyi_A_CP3 extends Activity implements c {
    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        b.a(this, "qSG.bzE.a", "b", new Class[]{Activity.class, Bundle.class}, new Object[]{this, null});
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        b.a(this, "qSG.bzE.a", "c", new Class[]{Activity.class, Intent.class}, new Object[]{this, intent});
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        boolean b;
        return (keyCode == 4 && (b = ((Boolean) b.a(this, "qSG.bzE.a", "d", new Class[]{Integer.TYPE, KeyEvent.class}, new Object[]{Integer.valueOf(keyCode), event})).booleanValue())) ? b : super.onKeyDown(keyCode, event);
    }
}
