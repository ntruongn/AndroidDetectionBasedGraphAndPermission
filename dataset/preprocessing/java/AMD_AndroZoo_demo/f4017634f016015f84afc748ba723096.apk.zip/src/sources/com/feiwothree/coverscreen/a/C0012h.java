package com.feiwothree.coverscreen.a;

import java.util.Arrays;

/* renamed from: com.feiwothree.coverscreen.a.h, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class C0012h {
    private static final char[] a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
    private static final int[] b;
    private static final byte[] c;

    static {
        int[] iArr = new int[256];
        b = iArr;
        Arrays.fill(iArr, -1);
        int length = a.length;
        for (int i = 0; i < length; i++) {
            b[a[i]] = i;
        }
        b[61] = 0;
        byte[] bArr = {65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47};
        c = new byte[128];
        for (int i2 = 0; i2 < 128; i2++) {
            c[i2] = -1;
        }
        for (int i3 = 65; i3 <= 90; i3++) {
            c[i3] = (byte) (i3 - 65);
        }
        for (int i4 = 97; i4 <= 122; i4++) {
            c[i4] = (byte) ((i4 - 97) + 26);
        }
        for (int i5 = 48; i5 <= 57; i5++) {
            c[i5] = (byte) ((i5 - 48) + 52);
        }
        c[43] = 62;
        c[47] = 63;
    }

    public static final String a(byte[] bArr, boolean z) {
        return new String(b(bArr, z));
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x007a  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0081 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final byte[] a(java.lang.String r10) {
        /*
            Method dump skipped, instructions count: 420
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.feiwothree.coverscreen.a.C0012h.a(java.lang.String):byte[]");
    }

    private static char[] b(byte[] bArr, boolean z) {
        int length = bArr != null ? bArr.length : 0;
        if (length == 0) {
            return new char[0];
        }
        int i = (length / 3) * 3;
        int i2 = (((length - 1) / 3) + 1) << 2;
        int i3 = i2 + (z ? ((i2 - 1) / 76) << 1 : 0);
        char[] cArr = new char[i3];
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        while (i6 < i) {
            int i7 = i6 + 1;
            int i8 = i7 + 1;
            int i9 = ((bArr[i7] & 255) << 8) | ((bArr[i6] & 255) << 16);
            i6 = i8 + 1;
            int i10 = i9 | (bArr[i8] & 255);
            int i11 = i5 + 1;
            cArr[i5] = a[(i10 >>> 18) & 63];
            int i12 = i11 + 1;
            cArr[i11] = a[(i10 >>> 12) & 63];
            int i13 = i12 + 1;
            cArr[i12] = a[(i10 >>> 6) & 63];
            i5 = i13 + 1;
            cArr[i13] = a[i10 & 63];
            if (z && (i4 = i4 + 1) == 19 && i5 < i3 - 2) {
                int i14 = i5 + 1;
                cArr[i5] = '\r';
                cArr[i14] = '\n';
                i5 = i14 + 1;
                i4 = 0;
            }
        }
        int i15 = length - i;
        if (i15 > 0) {
            int i16 = (i15 == 2 ? (bArr[length - 1] & 255) << 2 : 0) | ((bArr[i] & 255) << 10);
            cArr[i3 - 4] = a[i16 >> 12];
            cArr[i3 - 3] = a[(i16 >>> 6) & 63];
            cArr[i3 - 2] = i15 == 2 ? a[i16 & 63] : '=';
            cArr[i3 - 1] = '=';
        }
        return cArr;
    }
}
