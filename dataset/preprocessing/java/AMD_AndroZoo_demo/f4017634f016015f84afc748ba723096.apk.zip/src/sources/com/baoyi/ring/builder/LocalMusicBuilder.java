package com.baoyi.ring.builder;

import android.content.ContentValues;
import android.database.Cursor;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.dao.DatabaseBuilder;
import com.baoyi.ring.entity.LocalMusic;
import java.util.Formatter;
import java.util.Locale;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class LocalMusicBuilder extends DatabaseBuilder<LocalMusic> {
    private static final Object[] sTimeArgs = new Object[5];
    private static StringBuilder sFormatBuilder = new StringBuilder();
    private static Formatter sFormatter = new Formatter(sFormatBuilder, Locale.getDefault());

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.baoyi.dao.DatabaseBuilder
    public LocalMusic build(Cursor c) {
        LocalMusic result = new LocalMusic();
        result.setArtist(getStringOrThrow(UpdateService.ARTIST, c));
        result.setId(Integer.valueOf(getIntOrThrow("_id", c)));
        result.setTitle(getStringOrThrow("title", c));
        result.setUrl(getStringOrThrow("_data", c));
        int time = getInt("duration", c);
        result.setDuration(makeTimeString(time / 1000));
        return result;
    }

    public static String makeTimeString(int secs) {
        String durationformat = secs < 3600 ? "%2$d:%5$02d" : "%1$d:%3$02d:%5$02d";
        sFormatBuilder.setLength(0);
        Object[] timeArgs = sTimeArgs;
        timeArgs[0] = Integer.valueOf(secs / 3600);
        timeArgs[1] = Integer.valueOf(secs / 60);
        timeArgs[2] = Integer.valueOf((secs / 60) % 60);
        timeArgs[3] = Integer.valueOf(secs);
        timeArgs[4] = Integer.valueOf(secs % 60);
        return sFormatter.format(durationformat, timeArgs).toString();
    }

    @Override // com.baoyi.dao.DatabaseBuilder
    public ContentValues deconstruct(LocalMusic t) {
        return null;
    }
}
