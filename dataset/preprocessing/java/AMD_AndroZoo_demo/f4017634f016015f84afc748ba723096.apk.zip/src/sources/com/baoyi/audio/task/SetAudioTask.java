package com.baoyi.audio.task;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;
import com.baoyi.audio.dialog.WorkDialog;
import com.baoyi.audio.utils.content;
import com.baoyi.doamin.CheckWork;
import com.baoyi.utils.MusicUtils;
import com.baoyi.utils.Utils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SetAudioTask extends AsyncTask<String, String, Void> {
    CheckWork checked;
    Context curcontext;
    File fileitem;
    private int isdown;
    private WorkDialog progressDialog = null;

    public SetAudioTask(Context context, CheckWork check) {
        this.curcontext = context;
        this.checked = check;
    }

    @Override // android.os.AsyncTask
    public void onPreExecute() {
        this.progressDialog = new WorkDialog(this.curcontext, this);
        this.progressDialog.show();
        this.progressDialog.setTitle("设置铃声");
        super.onPreExecute();
    }

    @Override // android.os.AsyncTask
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override // android.os.AsyncTask
    public Void doInBackground(String... params) {
        try {
            this.isdown = -100;
            String mp3Url = params[0];
            String ext = mp3Url.substring(mp3Url.lastIndexOf("."));
            String path = String.valueOf(content.SAVEDIR) + params[1] + ext;
            publishProgress("正在为你准备铃声");
            String tempname = String.valueOf(content.SAVEDIR) + Utils.getMD5Str(path) + ".temp";
            Log.i("ada", path);
            Log.i("ada", tempname);
            File tempdown = new File(tempname);
            this.fileitem = new File(path);
            if (!this.fileitem.exists() || this.fileitem.length() < 100) {
                URL url = new URL(mp3Url);
                URLConnection conn = url.openConnection();
                conn.setDoInput(true);
                int length = conn.getContentLength();
                InputStream is = conn.getInputStream();
                if (length != -1) {
                    FileOutputStream output = new FileOutputStream(tempdown);
                    byte[] buffer = new byte[6144];
                    int downsize = 0;
                    while (true) {
                        int count = is.read(buffer);
                        if (count == -1) {
                            break;
                        }
                        output.write(buffer, 0, count);
                        downsize += count;
                        publishProgress("已经下载了" + ((int) ((downsize / length) * 100.0f)) + "%");
                    }
                    output.flush();
                    tempdown.renameTo(this.fileitem);
                    this.isdown = 100;
                } else {
                    this.isdown = -100;
                }
                publishProgress("准备铃声完毕");
                return null;
            }
            this.isdown = 100;
            return null;
        } catch (Exception e) {
            this.isdown = -100;
            e.printStackTrace();
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onProgressUpdate(String... aa) {
        this.progressDialog.setTitle(aa[0]);
    }

    public InputStream getInputStreamFromUrl(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
        InputStream inputStream = urlConn.getInputStream();
        return inputStream;
    }

    @Override // android.os.AsyncTask
    public void onPostExecute(Void url) {
        super.onPostExecute((SetAudioTask) url);
        if (this.fileitem != null) {
            scanFileAsync(this.curcontext, this.fileitem.getAbsolutePath());
        }
        if (this.isdown > 0) {
            this.progressDialog.setTitle("正在为你设置铃声");
            MusicUtils.setMyRingtone1(this.curcontext, this.fileitem, this.checked);
        } else {
            Toast.makeText(this.curcontext, "下载铃声失败", 0).show();
        }
        this.progressDialog.dismiss();
    }

    public void scanFileAsync(Context ctx, String filePath) {
        System.out.println("开始进行文件扫描工作");
        Intent scanIntent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        scanIntent.setData(Uri.fromFile(new File(filePath)));
        ctx.sendBroadcast(scanIntent);
    }
}
