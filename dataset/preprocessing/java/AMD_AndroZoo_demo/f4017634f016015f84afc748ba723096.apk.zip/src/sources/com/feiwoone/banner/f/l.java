package com.feiwoone.banner.f;

import java.util.Random;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class l {
    public static String a(int i) {
        String[] strArr = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        while (i > 0) {
            sb.append(strArr[random.nextInt(10)]);
            i--;
        }
        return sb.toString();
    }

    public static boolean a(String str) {
        return str == null || str.length() == 0 || str.trim().length() == 0;
    }
}
