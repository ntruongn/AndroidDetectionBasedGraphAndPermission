package com.baoyi.audio.utils;

import java.net.URL;
import org.json.rpc.client.HttpJsonRpcClientTransport;
import org.json.rpc.client.JsonRpcInvoker;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RpcUtils {
    static String url = "http://wallpaper.xabaoyi.com:8080/youthfulness/v1";

    public static <T> T getDao(String str, Class<T> cls) {
        try {
            return (T) new JsonRpcInvoker().get(new HttpJsonRpcClientTransport(new URL(url)), str, cls);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
