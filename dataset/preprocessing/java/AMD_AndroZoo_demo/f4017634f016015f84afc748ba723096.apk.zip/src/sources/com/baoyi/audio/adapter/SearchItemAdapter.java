package com.baoyi.audio.adapter;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import com.baoyi.audio.task.LoadingMp3;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.widget.SearchWidget;
import com.baoyi.doamin.KoWoMusic;
import com.baoyi.doamin.KoWoMusicToMusic;
import com.baoyi.doamin.SoList;
import com.baoyi.service.Mp3Service;
import com.iring.entity.Music;
import com.iring.rpc.MusicRpc;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SearchItemAdapter extends BaseAdapter implements AdapterView.OnItemClickListener {
    private List<SearchWidget> items = new ArrayList();
    private Context mContext;
    private String name;

    public List<SearchWidget> getItems() {
        return this.items;
    }

    public void setItems(List<SearchWidget> items) {
        this.items = items;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.items != null) {
            return this.items.size();
        }
        return 0;
    }

    public SearchItemAdapter(Context context, String name1) {
        this.mContext = context;
        this.name = name1;
        new FindByNameTask(this, context, this, null).execute(this.name);
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return 0L;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        View b = this.items.get(position);
        int i = position % 2;
        return b;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class FindByNameTask extends AsyncTask<String, Void, List<KoWoMusic>> {
        SearchItemAdapter adapter;
        Context context;

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        private FindByNameTask(Context mContext, SearchItemAdapter a) {
            this.context = mContext;
            this.adapter = a;
        }

        /* synthetic */ FindByNameTask(SearchItemAdapter searchItemAdapter, Context context, SearchItemAdapter searchItemAdapter2, FindByNameTask findByNameTask) {
            this(context, searchItemAdapter2);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<KoWoMusic> doInBackground(String... params) {
            LinkedList<KoWoMusic> musicc = new LinkedList<>();
            try {
                SoList list = Mp3Service.search(params[0]);
                MusicRpc rcp = RpcUtils2.getMusicDaoTime().search(params[0], 10, 0);
                if (rcp != null && rcp.getDatas() != null) {
                    List<Music> ms = rcp.getDatas();
                    for (Music music : ms) {
                        KoWoMusic kowo = KoWoMusicToMusic.convert(music);
                        musicc.addFirst(kowo);
                    }
                }
                if (list != null) {
                    musicc.addAll(list.getList());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return musicc;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<KoWoMusic> result) {
            if (result != null) {
                List<SearchWidget> items = new ArrayList<>();
                for (KoWoMusic workItem : result) {
                    SearchWidget b = new SearchWidget(this.context, workItem);
                    items.add(b);
                }
                this.adapter.setItems(items);
                this.adapter.notifyDataSetChanged();
            }
        }
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        if (arg1 instanceof SearchWidget) {
            SearchWidget item = (SearchWidget) arg1;
            LoadingMp3 load = new LoadingMp3(this.mContext);
            load.execute(item);
        }
    }
}
