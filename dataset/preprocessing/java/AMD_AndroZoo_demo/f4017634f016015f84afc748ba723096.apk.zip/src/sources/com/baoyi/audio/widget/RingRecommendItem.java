package com.baoyi.audio.widget;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.baoyi.audio.ZoneActivity;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.utils.content;
import com.hope.leyuan.R;
import com.iring.entity.RingRecommend;
import com.webimageloader.ImageLoader;
import com.webimageloader.ext.ImageHelper;
import com.webimageloader.ext.ImageLoaderApplication;
import com.wrapp.android.webimage.WebImageView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RingRecommendItem extends LinearLayout {
    private TextView catalogName;
    Context curactivity;
    private WebImageView headimg;
    private TextView memberName;
    private TextView musicName;
    private RingRecommend ringRecommend;
    private boolean zoneFlag;

    public RingRecommend getRingRecommend() {
        return this.ringRecommend;
    }

    public void setRingRecommend(RingRecommend rringRecommend) {
        this.ringRecommend = rringRecommend;
        this.headimg.setImageDrawable(getResources().getDrawable(R.drawable.foot_touxiang));
        this.musicName.setText(Html.fromHtml(String.valueOf(this.ringRecommend.getCatalogname()) + "了\"<font color=blue>" + this.ringRecommend.getMusicname() + "</font>\"。"));
        if (this.ringRecommend.getCatalog() == 4) {
            if (this.ringRecommend.getComments() == null || this.ringRecommend.getComments().equals("")) {
                this.catalogName.setVisibility(8);
            } else {
                this.catalogName.setVisibility(0);
                this.catalogName.setText("推荐理由:" + this.ringRecommend.getComments());
            }
        } else {
            this.catalogName.setVisibility(8);
        }
        if (!this.zoneFlag) {
            this.memberName.setVisibility(0);
            this.memberName.setText(this.ringRecommend.getMembername());
            this.headimg.setVisibility(0);
            this.headimg.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.widget.RingRecommendItem.1
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    if (RingRecommendItem.this.ringRecommend != null) {
                        Intent intent = new Intent(RingRecommendItem.this.curactivity, (Class<?>) ZoneActivity.class);
                        intent.putExtra(UpdateService.USERID, RingRecommendItem.this.ringRecommend.getMemberid());
                        RingRecommendItem.this.curactivity.startActivity(intent);
                    }
                }
            });
            ImageLoader imageLoader = ImageLoaderApplication.getLoader(getContext());
            new ImageHelper(getContext(), imageLoader).setFadeIn(true).setLoadingResource(R.drawable.foot_touxiang).setErrorResource(R.drawable.foot_touxiang).load(this.headimg, String.valueOf(content.picserver) + rringRecommend.getMemberpicture());
            return;
        }
        this.headimg.setVisibility(8);
        this.memberName.setVisibility(8);
    }

    public void setBGImageResource(int resId) {
        setBackgroundResource(resId);
    }

    public RingRecommendItem(Context context, boolean zoneFlag) {
        super(context);
        this.zoneFlag = false;
        this.curactivity = context;
        this.zoneFlag = zoneFlag;
        LayoutInflater.from(getContext()).inflate(R.layout.widget_ringrecommend, this);
        this.headimg = (WebImageView) findViewById(R.id.headimg);
        this.memberName = (TextView) findViewById(R.id.member_name);
        this.musicName = (TextView) findViewById(R.id.music_name);
        this.catalogName = (TextView) findViewById(R.id.catalog_name);
    }

    public RingRecommendItem(Context context, RingRecommend ringRecommend, boolean zoneFlag) {
        super(context);
        this.zoneFlag = false;
        this.curactivity = context;
        this.zoneFlag = zoneFlag;
        LayoutInflater.from(getContext()).inflate(R.layout.widget_ringrecommend, this);
        this.headimg = (WebImageView) findViewById(R.id.headimg);
        this.memberName = (TextView) findViewById(R.id.member_name);
        this.musicName = (TextView) findViewById(R.id.music_name);
        this.catalogName = (TextView) findViewById(R.id.catalog_name);
        setRingRecommend(ringRecommend);
    }
}
