package com.baoyi.audio.dao;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.baoyi.audio.service.UpdateService;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class FavInfoDao {
    private static final String DB_NAME = "baoyinovels";
    private static final String TABLE_TRACK = "favInfo";
    private Activity mActivity;

    private void create() {
        SQLiteDatabase db = this.mActivity.openOrCreateDatabase(DB_NAME, 0, null);
        StringBuffer buffer = new StringBuffer();
        buffer.append("CREATE TABLE IF NOT EXISTS favInfo");
        buffer.append(" ([id] INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT ,");
        buffer.append(" [name] VARCHAR(100)  NULL,");
        buffer.append(" [album] VARCHAR(2000)  NULL,");
        buffer.append(" [url] VARCHAR(500)  NULL,");
        buffer.append("[searchtime] Long  NULL)");
        db.execSQL(buffer.toString());
        db.close();
    }

    public void remove(int id) {
        if (id != 0) {
            SQLiteDatabase db = getDb();
            String[] whereArgs = {new StringBuilder().append(id).toString()};
            db.delete(TABLE_TRACK, "id=?", whereArgs);
            db.close();
        }
    }

    public void removeByName(String id) {
        if (id != null) {
            SQLiteDatabase db = getDb();
            String[] whereArgs = {id};
            db.delete(TABLE_TRACK, "name=?", whereArgs);
            db.close();
        }
    }

    public ArrayList<FavInfo> all() {
        SQLiteDatabase db = getDb();
        ArrayList<FavInfo> all = new ArrayList<>();
        Cursor result = db.rawQuery("SELECT * FROM favInfo order by searchtime desc", null);
        result.moveToFirst();
        FavInfoBuilder b = new FavInfoBuilder();
        while (!result.isAfterLast()) {
            all.add(b.build(result));
            result.moveToNext();
        }
        result.close();
        db.close();
        return all;
    }

    public boolean findByName(FavInfo entry) {
        SQLiteDatabase db = getDb();
        String[] columns = {"id", UpdateService.NAME};
        String idd = entry.getName();
        String[] parms = {idd};
        Cursor result = db.query(TABLE_TRACK, columns, "name=?", parms, null, null, null);
        boolean isadd = result.moveToFirst();
        db.close();
        return isadd;
    }

    public boolean addToTrack(FavInfo entry) {
        boolean isadd = findByName(entry);
        if (!isadd) {
            entry.setSearchtime(System.currentTimeMillis());
            SQLiteDatabase db = getDb();
            ContentValues values = new ContentValues();
            values.putAll(new FavInfoBuilder().deconstruct(entry));
            db.insert(TABLE_TRACK, null, values);
            db.close();
            return true;
        }
        return false;
    }

    public FavInfoDao(Activity activity) {
        this.mActivity = activity;
        create();
    }

    private SQLiteDatabase getDb() {
        return this.mActivity.openOrCreateDatabase(DB_NAME, 0, null);
    }
}
