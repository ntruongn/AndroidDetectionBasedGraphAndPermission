package com.baidu.a.a.a.b;

import android.content.Context;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import org.apache.commons.io.IOUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class b {
    /* JADX WARN: Removed duplicated region for block: B:11:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x005c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String a(android.content.Context r7) {
        /*
            r2 = 1
            java.lang.String r0 = "android.permission.WRITE_SETTINGS"
            a(r7, r0)
            java.lang.String r0 = "android.permission.READ_PHONE_STATE"
            a(r7, r0)
            java.lang.String r0 = "android.permission.WRITE_EXTERNAL_STORAGE"
            a(r7, r0)
            r1 = 0
            java.lang.String r3 = ""
            android.content.ContentResolver r0 = r7.getContentResolver()     // Catch: java.lang.Exception -> L50
            java.lang.String r4 = "bd_setting_i"
            java.lang.String r3 = android.provider.Settings.System.getString(r0, r4)     // Catch: java.lang.Exception -> L50
            if (r3 != 0) goto L109
            java.lang.String r0 = b(r7)     // Catch: java.lang.Exception -> L50
        L23:
            android.content.ContentResolver r3 = r7.getContentResolver()     // Catch: java.lang.Exception -> L106
            java.lang.String r4 = "bd_setting_i"
            android.provider.Settings.System.putString(r3, r4, r0)     // Catch: java.lang.Exception -> L106
        L2c:
            java.lang.String r4 = c(r7)
            java.lang.String r3 = ""
            if (r1 == 0) goto L5c
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "com.baidu"
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.StringBuilder r0 = r0.append(r4)
            java.lang.String r0 = r0.toString()
            byte[] r0 = r0.getBytes()
            java.lang.String r3 = com.baidu.a.a.a.b.c.a(r0, r2)
        L4f:
            return r3
        L50:
            r0 = move-exception
            r1 = r0
            r0 = r3
        L53:
            java.lang.String r3 = "DeviceId"
            java.lang.String r4 = "Settings.System.getString or putString failed"
            android.util.Log.e(r3, r4, r1)
            r1 = r2
            goto L2c
        L5c:
            r1 = 0
            android.content.ContentResolver r3 = r7.getContentResolver()
            java.lang.String r5 = "com.baidu.deviceid"
            java.lang.String r3 = android.provider.Settings.System.getString(r3, r5)
            boolean r5 = android.text.TextUtils.isEmpty(r3)
            if (r5 == 0) goto La6
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = "com.baidu"
            java.lang.StringBuilder r1 = r1.append(r3)
            java.lang.StringBuilder r1 = r1.append(r0)
            java.lang.StringBuilder r1 = r1.append(r4)
            java.lang.String r1 = r1.toString()
            byte[] r1 = r1.getBytes()
            java.lang.String r1 = com.baidu.a.a.a.b.c.a(r1, r2)
            android.content.ContentResolver r3 = r7.getContentResolver()
            java.lang.String r3 = android.provider.Settings.System.getString(r3, r1)
            boolean r5 = android.text.TextUtils.isEmpty(r3)
            if (r5 != 0) goto La6
            android.content.ContentResolver r5 = r7.getContentResolver()
            java.lang.String r6 = "com.baidu.deviceid"
            android.provider.Settings.System.putString(r5, r6, r3)
            a(r0, r3)
        La6:
            boolean r5 = android.text.TextUtils.isEmpty(r3)
            if (r5 == 0) goto Lc6
            java.lang.String r3 = a(r0)
            boolean r5 = android.text.TextUtils.isEmpty(r3)
            if (r5 != 0) goto Lc6
            android.content.ContentResolver r5 = r7.getContentResolver()
            android.provider.Settings.System.putString(r5, r1, r3)
            android.content.ContentResolver r5 = r7.getContentResolver()
            java.lang.String r6 = "com.baidu.deviceid"
            android.provider.Settings.System.putString(r5, r6, r3)
        Lc6:
            boolean r5 = android.text.TextUtils.isEmpty(r3)
            if (r5 == 0) goto L4f
            java.util.UUID r3 = java.util.UUID.randomUUID()
            java.lang.String r3 = r3.toString()
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.StringBuilder r5 = r5.append(r0)
            java.lang.StringBuilder r4 = r5.append(r4)
            java.lang.StringBuilder r3 = r4.append(r3)
            java.lang.String r3 = r3.toString()
            byte[] r3 = r3.getBytes()
            java.lang.String r3 = com.baidu.a.a.a.b.c.a(r3, r2)
            android.content.ContentResolver r2 = r7.getContentResolver()
            android.provider.Settings.System.putString(r2, r1, r3)
            android.content.ContentResolver r1 = r7.getContentResolver()
            java.lang.String r2 = "com.baidu.deviceid"
            android.provider.Settings.System.putString(r1, r2, r3)
            a(r0, r3)
            goto L4f
        L106:
            r1 = move-exception
            goto L53
        L109:
            r0 = r3
            goto L23
        */
        throw new UnsupportedOperationException("Method not decompiled: com.baidu.a.a.a.b.b.a(android.content.Context):java.lang.String");
    }

    private static String a(String str) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(new File(Environment.getExternalStorageDirectory(), "baidu/.cuid")));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine);
                sb.append(IOUtils.LINE_SEPARATOR_WINDOWS);
            }
            bufferedReader.close();
            String[] split = new String(com.baidu.a.a.a.a.a.b("30212102dicudiab", "30212102dicudiab", com.baidu.a.a.a.a.b.a(sb.toString().getBytes()))).split("=");
            return (split != null && split.length == 2 && str.equals(split[0])) ? split[1] : "";
        } catch (FileNotFoundException e) {
            return "";
        } catch (IOException e2) {
            return "";
        } catch (Exception e3) {
            return "";
        }
    }

    private static void a(Context context, String str) {
        if (!(context.checkCallingOrSelfPermission(str) == 0)) {
            throw new SecurityException("Permission Denial: requires permission " + str);
        }
    }

    private static void a(String str, String str2) {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        File file = new File(Environment.getExternalStorageDirectory(), "baidu/.cuid");
        try {
            new File(file.getParent()).mkdirs();
            FileWriter fileWriter = new FileWriter(file, false);
            fileWriter.write(com.baidu.a.a.a.a.b.a(com.baidu.a.a.a.a.a.a("30212102dicudiab", "30212102dicudiab", (str + "=" + str2).getBytes()), "utf-8"));
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
        } catch (Exception e2) {
        }
    }

    public static String b(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
        if (telephonyManager == null) {
            return "";
        }
        String deviceId = telephonyManager.getDeviceId();
        return TextUtils.isEmpty(deviceId) ? "" : deviceId;
    }

    public static String c(Context context) {
        String string = Settings.Secure.getString(context.getContentResolver(), "android_id");
        return TextUtils.isEmpty(string) ? "" : string;
    }
}
