package com.feiwoone.banner.d;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class e extends Thread {
    private /* synthetic */ c a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ e(c cVar) {
        this(cVar, (byte) 0);
    }

    private e(c cVar, byte b) {
        this.a = cVar;
    }

    /* JADX WARN: Incorrect condition in loop: B:6:0x0049 */
    @Override // java.lang.Thread, java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            r4 = this;
            com.feiwoone.banner.d.c r0 = r4.a
            com.feiwoone.banner.d.b r0 = com.feiwoone.banner.d.c.a(r0)
            if (r0 != 0) goto L43
        L8:
            return
        L9:
            com.feiwoone.banner.d.c r0 = r4.a
            boolean r0 = com.feiwoone.banner.d.c.c(r0)
            if (r0 != 0) goto L4c
            com.feiwoone.banner.d.c r0 = r4.a
            com.feiwoone.banner.d.b r0 = com.feiwoone.banner.d.c.a(r0)
            com.feiwoone.banner.a.a r0 = r0.d()
            com.feiwoone.banner.d.c r1 = r4.a
            android.graphics.Bitmap r2 = r0.a
            com.feiwoone.banner.d.c.a(r1, r2)
            int r0 = r0.b
            long r0 = (long) r0
            com.feiwoone.banner.d.c r2 = r4.a
            android.os.Handler r2 = com.feiwoone.banner.d.c.d(r2)
            if (r2 == 0) goto L8
            com.feiwoone.banner.d.c r2 = r4.a
            android.os.Handler r2 = com.feiwoone.banner.d.c.d(r2)
            android.os.Message r2 = r2.obtainMessage()
            com.feiwoone.banner.d.c r3 = r4.a
            android.os.Handler r3 = com.feiwoone.banner.d.c.d(r3)
            r3.sendMessage(r2)
            android.os.SystemClock.sleep(r0)
        L43:
            com.feiwoone.banner.d.c r0 = r4.a
            boolean r0 = com.feiwoone.banner.d.c.b(r0)
            if (r0 != 0) goto L9
            goto L8
        L4c:
            r0 = 10
            android.os.SystemClock.sleep(r0)
            goto L43
        */
        throw new UnsupportedOperationException("Method not decompiled: com.feiwoone.banner.d.e.run():void");
    }
}
