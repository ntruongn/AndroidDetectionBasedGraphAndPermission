package com.baoyi.download;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class DownloadJob {
    private String extension;
    private boolean isfront;
    DownloadFileTask mDownloadTask;
    private int mDownloadedSize;
    private DownloadJobListener mListener;
    private int mProgress;
    private int mTotalSize;
    private String name;
    private String path;
    private String url;

    public boolean isIsfront() {
        return this.isfront;
    }

    public void setIsfront(boolean isfront) {
        this.isfront = isfront;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getExtension() {
        return this.extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public int getProgress() {
        return this.mProgress;
    }

    public void setProgress(int progress) {
        this.mProgress = progress;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void notifyDownloadStarted() {
        if (this.mListener != null) {
            this.mListener.downloadStarted();
        }
        this.mProgress = 0;
    }

    public void notifyDownloadEnded() {
        if (!this.mDownloadTask.isCancelled()) {
            if (this.mListener != null) {
                this.mListener.downloadEnded(this);
            }
            this.mProgress = 100;
        }
    }

    public void setListener(DownloadJobListener listener) {
        this.mListener = listener;
    }

    public void start() {
        this.mDownloadTask = new DownloadFileTask(this);
        this.mDownloadTask.execute(new Void[0]);
    }

    public void pause() {
    }

    public void resume() {
    }

    public void cancel() {
        this.mDownloadTask.cancel(true);
    }
}
