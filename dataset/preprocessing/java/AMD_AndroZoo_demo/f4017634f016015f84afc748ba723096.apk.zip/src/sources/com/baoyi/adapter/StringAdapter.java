package com.baoyi.adapter;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.hope.leyuan.R;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class StringAdapter extends BaseAdapter {
    private List<String> all;
    private Context context;
    private DisplayMetrics display;
    private LayoutInflater mLayoutInflater;

    public StringAdapter(Context context, List<String> all) {
        this.mLayoutInflater = LayoutInflater.from(context);
        this.all = all;
        this.context = context;
        this.display = new DisplayMetrics();
        this.display = context.getApplicationContext().getResources().getDisplayMetrics();
    }

    public boolean add(String object) {
        return this.all.add(object);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.all != null) {
            return this.all.size();
        }
        return 0;
    }

    public void clear() {
        this.all.clear();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        if (this.all != null) {
            return this.all.get(position);
        }
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return position;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class ViewHolder {
        private TextView tv;

        private ViewHolder() {
        }

        /* synthetic */ ViewHolder(StringAdapter stringAdapter, ViewHolder viewHolder) {
            this();
        }
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        ViewHolder viewHolder = null;
        if (convertView == null) {
            convertView = this.mLayoutInflater.inflate(R.layout.widget_text, (ViewGroup) null);
            holder = new ViewHolder(this, viewHolder);
            holder.tv = (TextView) convertView.findViewById(R.id.widget_text_tv);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        String m = this.all.get(position);
        holder.tv.setText(m);
        return convertView;
    }

    public String get(int arg2) {
        return this.all.get(arg2);
    }
}
