package com.baoyi.audio.task;

import android.os.AsyncTask;
import android.util.Log;
import com.baoyi.audio.utils.RpcUtils2;
import com.iring.rpc.RpcSerializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SearcTask extends AsyncTask<String, Integer, RpcSerializable> {
    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public RpcSerializable doInBackground(String... params) {
        try {
            RpcUtils2.getMusicDao().search(params[0], 2, 0);
            Log.i("ada", "搜索成功");
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
