package com.baoyi.audio.dao;

import android.content.ContentValues;
import android.database.Cursor;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.dao.DatabaseBuilder;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class WordBuilder extends DatabaseBuilder<Word> {
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.baoyi.dao.DatabaseBuilder
    public Word build(Cursor query) {
        Word word = new Word();
        int columnName = query.getColumnIndex(UpdateService.NAME);
        int columnId = query.getColumnIndex("searchtime");
        word.setName(query.getString(columnName));
        word.setSearchtime(query.getLong(columnId));
        return word;
    }

    public String buildString(Cursor query) {
        int columnName = query.getColumnIndex(UpdateService.NAME);
        String word = query.getString(columnName);
        return word;
    }

    @Override // com.baoyi.dao.DatabaseBuilder
    public ContentValues deconstruct(Word t) {
        ContentValues values = new ContentValues();
        values.put(UpdateService.NAME, t.getName());
        values.put("searchtime", Long.valueOf(t.getSearchtime()));
        return values;
    }
}
