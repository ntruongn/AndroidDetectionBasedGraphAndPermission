package com.feiwothree.coverscreen.a;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class x {
    private static x b = null;
    private static Context c;
    private NotificationManager a;

    private x(Context context) {
        this.a = null;
        if (this.a == null) {
            this.a = (NotificationManager) context.getSystemService("notification");
        }
    }

    private ImageView a(View view) {
        if (!(view instanceof ViewGroup)) {
            if (view instanceof ImageView) {
                return (ImageView) view;
            }
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        for (int childCount = viewGroup.getChildCount(); childCount > 0; childCount--) {
            ImageView a = a(viewGroup.getChildAt(childCount - 1));
            if (a != null && a.getId() == 16908294) {
                return a;
            }
        }
        return null;
    }

    public static x a(Context context) {
        c = context;
        if (b == null) {
            b = new x(c);
        }
        return b;
    }

    public final void a(int i) {
        this.a.cancel(i);
    }

    public final void a(int i, int i2, String str, String str2, String str3, Intent intent, int i3, String str4, long j) {
        Notification notification = new Notification();
        notification.icon = 17301586;
        notification.tickerText = str;
        notification.flags = i3;
        notification.when = j;
        notification.setLatestEventInfo(c, str2, str3, PendingIntent.getActivity(c, 0, intent, 134217728));
        if (str4 == null || str4.length() == 0 || notification == null) {
            return;
        }
        try {
            ImageView a = a(View.inflate(c, notification.contentView.getLayoutId(), null));
            r.a();
            Bitmap a2 = C0008d.a().a(c, r.a(c, l.a, str4));
            if (a2 != null) {
                notification.contentView.setImageViewBitmap(a.getId(), a2);
            }
            this.a.notify(i, notification);
        } catch (Exception e) {
            new StringBuilder("NotificationManagerTool >> ").append(e.getMessage());
        }
    }
}
