package com.baoyi.audio.utils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class GoogleFormSender extends Thread {
    String appname;
    String infos;
    String packname;
    private String url;
    String version;

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        super.run();
        this.url = "https://docs.google.com/spreadsheet/formResponse?formkey=dFZKaWFwY3VLb05RaEZ6dnhlZXV1M2c6MQ&theme=0AX42CRMsmRFbUy04ZWQwMDYwMS02YjZhLTQ2ZjMtYjcyNy0zYWNlMzlmYTAxNmY&ifq";
    }

    public GoogleFormSender(String packname, String version, String infos, String appname) {
        this.packname = packname;
        this.version = version;
        this.infos = infos;
        this.appname = appname;
    }
}
