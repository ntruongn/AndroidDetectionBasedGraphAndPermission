package com.baidu.mobstat;

import android.support.v4.app.Fragment;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class StatFragment extends Fragment {
    @Override // android.support.v4.app.Fragment
    public void onPause() {
        super.onPause();
        com.baidu.mobstat.a.c.a("stat", "StatFragment.OnResume()");
        StatService.onPause((Fragment) this);
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        super.onResume();
        com.baidu.mobstat.a.c.a("stat", "StatFragment.OnResume()");
        StatService.onResume((Fragment) this);
    }
}
