package com.baoyi.audio.task;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import com.baoyi.audio.utils.RpcUtils2;
import com.iring.dao.RingRecommendDao;
import com.iring.entity.RingRecommend;
import com.iring.rpc.RpcSerializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RecommendPubTask extends AsyncTask<RpcSerializable, Integer, RpcSerializable> {
    private Context context;
    private RingRecommend ringRecommend;

    public RecommendPubTask(RingRecommend ringRecommend, Context context) {
        this.ringRecommend = ringRecommend;
        this.context = context;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public RpcSerializable doInBackground(RpcSerializable... params) {
        try {
            RingRecommendDao dao = (RingRecommendDao) RpcUtils2.getDao("ringRecommendDao", RingRecommendDao.class);
            dao.addRingRecommend(this.ringRecommend);
            Log.i("ada", "反馈成功");
        } catch (Exception e) {
        }
        return null;
    }
}
