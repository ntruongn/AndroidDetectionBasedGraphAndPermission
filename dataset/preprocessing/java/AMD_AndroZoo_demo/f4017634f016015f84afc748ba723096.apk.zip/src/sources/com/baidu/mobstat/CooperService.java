package com.baidu.mobstat;

import android.content.Context;
import android.os.Build;
import android.telephony.TelephonyManager;
import java.util.Date;
import java.util.HashMap;
import java.util.regex.Pattern;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class CooperService extends BasicStoreToolsBase {
    private static b a = new b();
    private static JSONObject b = new JSONObject();
    private static String c = "activehead";
    private static HashMap<String, Object> d = new HashMap<>();

    /* JADX INFO: Access modifiers changed from: package-private */
    public static b a() {
        return a;
    }

    private static String a(String str, Context context) {
        if (str == null) {
            return null;
        }
        if (!str.equals("000000000000000")) {
            return str;
        }
        String macAddress = getMacAddress(context);
        com.baidu.mobstat.a.c.a("stat", "imei=null,mac=" + macAddress);
        return macAddress;
    }

    public static boolean checkCellLocationSetting(Context context) {
        String a2 = x.a(context, "BaiduMobAd_CELL_LOCATION");
        return a2 == null || !a2.toLowerCase().equals("false");
    }

    public static boolean checkGPSLocationSetting(Context context) {
        String a2 = x.a(context, "BaiduMobAd_GPS_LOCATION");
        return a2 == null || !a2.toLowerCase().equals("false");
    }

    public static boolean checkWifiLocationSetting(Context context) {
        String a2 = x.a(context, "BaiduMobAd_WIFI_LOCATION");
        return a2 == null || !a2.toLowerCase().equals("false");
    }

    public static String getAppChannel(Context context) {
        try {
            if (a.j == null || a.j.equals("")) {
                boolean loadAppChannelWithCode = BasicStoreTools.getInstance().loadAppChannelWithCode(context);
                if (loadAppChannelWithCode) {
                    a.j = BasicStoreTools.getInstance().loadAppChannelWithPreference(context);
                }
                if (!loadAppChannelWithCode || a.j == null || a.j.equals("")) {
                    a.j = x.a(context, "BaiduMobAd_CHANNEL");
                }
            }
        } catch (Exception e) {
            com.baidu.mobstat.a.c.a(e);
        }
        return a.j;
    }

    public static String getAppKey(Context context) {
        if (a.c == null) {
            a.c = x.a(context, "BaiduMobAd_STAT_ID");
        }
        return a.c;
    }

    public static int getAppVersionCode(Context context) {
        if (a.e == -1) {
            a.e = x.c(context);
        }
        return a.e;
    }

    public static String getAppVersionName(Context context) {
        if (a.f == null || "".equals(a.f)) {
            a.f = x.d(context);
        }
        return a.f;
    }

    public static String getCIUD(Context context) {
        if (a.d == null) {
            a.d = BasicStoreTools.getInstance().loadGenerateDeviceCUID(context);
            if (a.d == null || "".equalsIgnoreCase(a.d)) {
                try {
                    a.d = com.baidu.a.a.a.b.a.a(context);
                    BasicStoreTools.getInstance().setGenerateDeviceCUID(context, a.d);
                } catch (Exception e) {
                    com.baidu.mobstat.a.c.c("sdkstat", e.getMessage());
                }
            }
            try {
                a.d = Pattern.compile("\\s*|\t|\r|\n").matcher(a.d).replaceAll("");
            } catch (Exception e2) {
                a.d = com.baidu.a.a.a.b.a.a(context);
            }
        }
        return a.d;
    }

    public static String getDeviceId(TelephonyManager telephonyManager, Context context) {
        String str;
        if (telephonyManager == null) {
            return a.g;
        }
        String str2 = a.g;
        if (str2 == null || str2.equals("")) {
            try {
                str2 = Pattern.compile("\\s*|\t|\r|\n").matcher(telephonyManager.getDeviceId()).replaceAll("");
                str = a(str2, context);
            } catch (Exception e) {
                com.baidu.mobstat.a.c.a(e);
                str = str2;
            }
            if (str == null) {
                str = getMacAddress(context);
            }
            if (str == null || str.equals("000000000000000")) {
                str = BasicStoreTools.getInstance().loadGenerateDeviceId(context);
            }
            if (str == null || str.equals("000000000000000")) {
                str = "hol" + (new Date().getTime() + "").hashCode() + "mes";
                BasicStoreTools.getInstance().setGenerateDeviceId(context, str);
                com.baidu.mobstat.a.c.a("stat", "设备id为空，系统生成id =" + str);
            }
            a.g = str;
        }
        return a.g;
    }

    public static String getLinkedWay(Context context) {
        if (a.p == null || "".equals(a.p)) {
            a.p = x.i(context);
        }
        return a.p;
    }

    public static String getMTJSDKVersion() {
        return "3.4";
    }

    public static String getMacAddress(Context context) {
        String g = x.g(context);
        if (g != null) {
            return g.replaceAll(":", "");
        }
        return null;
    }

    public static String getOSVersion() {
        if (a.b == null || "".equals(a.b)) {
            a.b = Build.VERSION.SDK;
        }
        return a.b;
    }

    public static String getOperator(TelephonyManager telephonyManager) {
        if (a.k == null || "".equals(a.k)) {
            a.k = telephonyManager.getNetworkOperator();
        }
        return a.k;
    }

    public static String getPhoneModel() {
        if (a.l == null || "".equals(a.l)) {
            a.l = Build.MODEL;
        }
        return a.l;
    }
}
