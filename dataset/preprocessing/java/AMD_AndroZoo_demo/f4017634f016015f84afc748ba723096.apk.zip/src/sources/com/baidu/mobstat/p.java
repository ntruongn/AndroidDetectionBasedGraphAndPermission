package com.baidu.mobstat;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
class p {
    final /* synthetic */ o a;
    private String b;
    private long c;
    private long d;

    public p(o oVar, String str, long j, long j2) {
        this.a = oVar;
        this.b = str;
        this.c = j;
        this.d = j2;
    }

    public String a() {
        return this.b;
    }

    public long b() {
        return this.c;
    }

    public long c() {
        return this.d;
    }
}
