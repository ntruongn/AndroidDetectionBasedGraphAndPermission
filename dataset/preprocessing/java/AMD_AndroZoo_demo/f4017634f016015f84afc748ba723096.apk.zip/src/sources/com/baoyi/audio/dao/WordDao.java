package com.baoyi.audio.dao;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.baoyi.audio.service.UpdateService;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class WordDao {
    private static final String DB_NAME = "baoyinovels";
    private static final String TABLE_TRACK = "track";
    private Activity mActivity;

    private void create() {
        SQLiteDatabase db = this.mActivity.openOrCreateDatabase(DB_NAME, 0, null);
        StringBuffer buffer = new StringBuffer();
        buffer.append("CREATE TABLE IF NOT EXISTS track");
        buffer.append(" ([id] INTEGER  NOT NULL PRIMARY KEY,");
        buffer.append(" [name] VARCHAR(100)  NULL,");
        buffer.append("[searchtime] Long  NULL)");
        db.execSQL(buffer.toString());
        db.close();
    }

    public List<Word> all() {
        SQLiteDatabase db = getDb();
        List<Word> all = new ArrayList<>();
        Cursor result = db.rawQuery("SELECT * FROM Track order by searchtime desc", null);
        result.moveToFirst();
        WordBuilder b = new WordBuilder();
        while (!result.isAfterLast()) {
            all.add(b.build(result));
            result.moveToNext();
        }
        result.close();
        db.close();
        return all;
    }

    public List<String> allstring() {
        SQLiteDatabase db = getDb();
        List<String> all = new ArrayList<>();
        Cursor result = db.rawQuery("SELECT * FROM Track order by searchtime desc", null);
        result.moveToFirst();
        WordBuilder b = new WordBuilder();
        int i = 0;
        while (!result.isAfterLast()) {
            i++;
            all.add(b.buildString(result));
            result.moveToNext();
            if (i > 100) {
                break;
            }
        }
        result.close();
        db.close();
        return all;
    }

    public boolean findByName(Word entry) {
        SQLiteDatabase db = getDb();
        String[] columns = {"id", UpdateService.NAME};
        String idd = entry.getName();
        String[] parms = {idd};
        Cursor result = db.query(TABLE_TRACK, columns, "name=?", parms, null, null, null);
        boolean isadd = result.moveToFirst();
        db.close();
        return isadd;
    }

    public void deleteall() {
        SQLiteDatabase db = null;
        try {
            try {
                db = getDb();
                int size = db.delete(TABLE_TRACK, null, null);
                Log.i("ada", "删除数据条数:" + size);
                if (db != null) {
                    db.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
                if (db != null) {
                    db.close();
                }
            }
        } catch (Throwable th) {
            if (db != null) {
                db.close();
            }
            throw th;
        }
    }

    public boolean addToTrack(Word entry) {
        boolean isadd = findByName(entry);
        if (!isadd) {
            entry.setSearchtime(System.currentTimeMillis());
            SQLiteDatabase db = getDb();
            ContentValues values = new ContentValues();
            values.putAll(new WordBuilder().deconstruct(entry));
            db.insert(TABLE_TRACK, null, values);
            db.close();
            return true;
        }
        SQLiteDatabase db2 = getDb();
        ContentValues values2 = new ContentValues();
        entry.setSearchtime(System.currentTimeMillis());
        values2.putAll(new WordBuilder().deconstruct(entry));
        String[] whereArgs = {entry.getName()};
        int row_count = db2.update(TABLE_TRACK, values2, "name=?", whereArgs);
        if (row_count == 0) {
            Log.e("ada", "Failed to update ");
        }
        db2.close();
        return false;
    }

    public WordDao(Activity activity) {
        this.mActivity = activity;
        create();
    }

    private SQLiteDatabase getDb() {
        return this.mActivity.openOrCreateDatabase(DB_NAME, 0, null);
    }
}
