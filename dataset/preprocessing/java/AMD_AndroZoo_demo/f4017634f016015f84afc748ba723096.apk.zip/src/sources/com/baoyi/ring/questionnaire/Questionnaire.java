package com.baoyi.ring.questionnaire;

import java.io.Serializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Questionnaire implements Serializable {
    private String answer;
    private Integer id;
    private String packagename;
    private Long pubtime;
    private String question;

    public Questionnaire(Integer id, String packagename, String question, String answer, Long pubtime) {
        this.id = id;
        this.packagename = packagename;
        this.question = question;
        this.answer = answer;
        this.pubtime = pubtime;
    }

    public Questionnaire() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPackagename() {
        return this.packagename;
    }

    public void setPackagename(String packagename) {
        this.packagename = packagename;
    }

    public String getQuestion() {
        return this.question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return this.answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Long getPubtime() {
        return this.pubtime;
    }

    public void setPubtime(Long pubtime) {
        this.pubtime = pubtime;
    }
}
