package com.baoyi.download.core.network;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class ZLNetworkException extends Exception {
    public static final String ERROR_AUTHENTICATION_FAILED = "authenticationFailed";
    public static final String ERROR_CONNECTION_REFUSED = "connectionRefused";
    public static final String ERROR_CONNECT_TO_HOST = "couldntConnectMessage";
    public static final String ERROR_CONNECT_TO_NETWORK = "couldntConnectToNetworkMessage";
    public static final String ERROR_CREATE_DIRECTORY = "couldntCreateDirectoryMessage";
    public static final String ERROR_CREATE_FILE = "couldntCreateFileMessage";
    public static final String ERROR_HOST_CANNOT_BE_REACHED = "hostCantBeReached";
    public static final String ERROR_INVALID_URL = "invalidURL";
    public static final String ERROR_RESOLVE_HOST = "couldntResolveHostMessage";
    public static final String ERROR_SOMETHING_WRONG = "somethingWrongMessage";
    public static final String ERROR_TIMEOUT = "operationTimedOutMessage";
    public static final String ERROR_UNKNOWN_ERROR = "unknownErrorMessage";
    public static final String ERROR_UNSUPPORTED_PROTOCOL = "unsupportedProtocol";
    private static final long serialVersionUID = 4272384299121648643L;
    private final String myCode;

    private static String errorMessage(String key) {
        if (key == null) {
            return "null";
        }
        return key;
    }

    private static String errorMessage(String key, String arg) {
        if (key == null) {
            return "null";
        }
        if (arg == null) {
            arg = "null";
        }
        return key.replace("%s", arg);
    }

    public ZLNetworkException(boolean useAsMessage, String str, Throwable cause) {
        super(useAsMessage ? str : errorMessage(str), cause);
        this.myCode = useAsMessage ? null : str;
    }

    public ZLNetworkException(boolean useAsMessage, String str) {
        super(useAsMessage ? str : errorMessage(str));
        this.myCode = useAsMessage ? null : str;
    }

    public ZLNetworkException(String code, Throwable cause) {
        this(false, code, cause);
    }

    public ZLNetworkException(String code) {
        this(false, code);
    }

    public ZLNetworkException(String code, String arg, Throwable cause) {
        super(errorMessage(code, arg), cause);
        this.myCode = code;
    }

    public ZLNetworkException(String code, String arg) {
        super(errorMessage(code, arg));
        this.myCode = code;
    }

    public String getCode() {
        return this.myCode;
    }
}
