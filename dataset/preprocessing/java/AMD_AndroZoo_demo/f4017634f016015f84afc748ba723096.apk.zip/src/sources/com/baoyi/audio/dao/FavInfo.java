package com.baoyi.audio.dao;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class FavInfo {
    private String album;
    private Integer id;
    private String name;
    private long searchtime;
    private String url;

    public String getAlbum() {
        return this.album;
    }

    public Integer getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public long getSearchtime() {
        return this.searchtime;
    }

    public String getUrl() {
        return this.url;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSearchtime(long searchtime) {
        this.searchtime = searchtime;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
