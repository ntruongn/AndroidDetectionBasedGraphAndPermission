package com.baoyi.ring.fragment;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.baoyi.adapter.NewRingAdapter;
import com.baoyi.adapter.StringAdapter;
import com.baoyi.audio.cache.DataCache;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.audio.widget.WidgetLoadling;
import com.baoyi.utils.Utils;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.extras.SoundPullEventListener;
import com.hope.leyuan.R;
import com.iring.entity.Music;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class NewFragment extends TestFragment {
    NewRingAdapter adapter;
    private Button b1;
    private Button b2;
    private Button b3;
    private ImageButton left;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    private ImageButton right;
    int type;
    private boolean work = false;
    private ArrayList<Music> all = new ArrayList<>();
    int a = 0;
    int b = 1;
    int c = 2;
    StringAdapter adapter1 = null;
    ArrayList<String> strs = null;
    private int count = 1024;
    int page = 0;

    @Override // com.baoyi.ring.fragment.TestFragment, android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ring_new, container, false);
        return view;
    }

    @Override // android.support.v4.app.Fragment
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (this.adapter != null) {
                this.adapter.notifyDataSetChanged();
            }
        } else if (!isVisibleToUser) {
            Log.i("ada", "铃声本地不可见");
            if (this.adapter != null) {
                this.adapter.stopMusic();
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.page = 0;
        this.type = 1;
        content.ISKIND = 0;
        this.mPullRefreshListView = (PullToRefreshListView) getView().findViewById(R.id.ring_new_prl);
        this.left = (ImageButton) getView().findViewById(R.id.ring_new_left);
        this.right = (ImageButton) getView().findViewById(R.id.ring_new_right);
        this.b1 = (Button) getView().findViewById(R.id.ring_new_1);
        this.b2 = (Button) getView().findViewById(R.id.ring_new_2);
        this.b3 = (Button) getView().findViewById(R.id.ring_new_3);
        WidgetLoadling tv = new WidgetLoadling(getActivity());
        this.mPullRefreshListView.setEmptyView(tv);
        this.adapter = new NewRingAdapter(getActivity(), this.all);
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.listView.setBackgroundColor(Color.parseColor("#00000000"));
        this.listView.setAdapter((ListAdapter) this.adapter);
        this.listView.setItemsCanFocus(true);
        this.listView.setOnItemClickListener(this.adapter);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("com.iym.imusic_preferences", 0);
        boolean issoundenable = sharedPreferences.getBoolean("issoundenable", false);
        if (issoundenable) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<>(getActivity());
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull_event);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.reset_sound);
            soundListener.addSoundEvent(PullToRefreshBase.State.REFRESHING, R.raw.release_event);
            this.mPullRefreshListView.setOnPullEventListener(soundListener);
        }
        this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
        new HotTask(this, null).execute(Integer.valueOf(this.page));
        this.strs = (ArrayList) getSString(1000);
        this.right.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.NewFragment.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (NewFragment.this.c < NewFragment.this.strs.size() - 3) {
                    NewFragment.this.a += 3;
                    NewFragment.this.b += 3;
                    NewFragment.this.c += 3;
                    NewFragment.this.b1.setText(NewFragment.this.strs.get(NewFragment.this.a).toString());
                    NewFragment.this.b2.setText(NewFragment.this.strs.get(NewFragment.this.b).toString());
                    NewFragment.this.b3.setText(NewFragment.this.strs.get(NewFragment.this.c).toString());
                    return;
                }
                Utils.showMessage(NewFragment.this.getActivity(), "抱歉，亲，木有下一页了");
            }
        });
        this.left.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.NewFragment.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (NewFragment.this.a - 3 >= 0) {
                    NewFragment newFragment = NewFragment.this;
                    newFragment.a -= 3;
                    NewFragment newFragment2 = NewFragment.this;
                    newFragment2.b -= 3;
                    NewFragment newFragment3 = NewFragment.this;
                    newFragment3.c -= 3;
                    NewFragment.this.b1.setText(NewFragment.this.strs.get(NewFragment.this.a).toString());
                    NewFragment.this.b2.setText(NewFragment.this.strs.get(NewFragment.this.b).toString());
                    NewFragment.this.b3.setText(NewFragment.this.strs.get(NewFragment.this.c).toString());
                    return;
                }
                Utils.showMessage(NewFragment.this.getActivity(), "抱歉，亲，木有下一页了");
            }
        });
        this.b1.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.NewFragment.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                NewFragment.this.adapter.setcurrentPosition(-1);
                NewFragment.this.adapter.setPlayPosition(-1);
                NewFragment.this.adapter.stopMusic();
                NewFragment.this.adapter.clean();
                NewFragment.this.page = NewFragment.this.a;
                new HotTask(NewFragment.this, null).execute(Integer.valueOf(NewFragment.this.page));
            }
        });
        this.b2.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.NewFragment.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                NewFragment.this.adapter.setcurrentPosition(-1);
                NewFragment.this.adapter.setPlayPosition(-1);
                NewFragment.this.adapter.getItemId(-1);
                NewFragment.this.adapter.stopMusic();
                NewFragment.this.adapter.clean();
                NewFragment.this.page = NewFragment.this.b;
                new HotTask(NewFragment.this, null).execute(Integer.valueOf(NewFragment.this.page));
            }
        });
        this.b3.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.NewFragment.5
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                NewFragment.this.adapter.setcurrentPosition(-1);
                NewFragment.this.adapter.setPlayPosition(-1);
                NewFragment.this.adapter.stopMusic();
                NewFragment.this.adapter.clean();
                NewFragment.this.page = NewFragment.this.c;
                new HotTask(NewFragment.this, null).execute(Integer.valueOf(NewFragment.this.page));
            }
        });
    }

    public List<String> getSString(int count) {
        List<String> strs = new ArrayList<>();
        int a = 1;
        int b = 20;
        for (int j = 1; j < count && b < count - 20; j++) {
            if (j > 1) {
                a += 20;
                b += 20;
            }
            strs.add("<" + a + "~" + b + ">");
        }
        System.out.println(strs.get(0));
        System.out.println(strs.get(1));
        System.out.println(strs.get(2));
        System.out.println(strs.get(3));
        return strs;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class HotTask extends AsyncTask<Integer, Void, List<Music>> {
        private HotTask() {
        }

        /* synthetic */ HotTask(NewFragment newFragment, HotTask hotTask) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public List<Music> doInBackground(Integer... params) {
            long time = System.currentTimeMillis();
            NewFragment.this.work = true;
            String key = "RpcUtils2.getMusicDao().pageByNew" + params[0];
            List<Music> temp = DataCache.datas.get(key);
            if (temp == null || temp.size() == 0) {
                try {
                    temp = RpcUtils2.getMusicDao().pageByNew(content.showsize, params[0].intValue()).getDatas();
                    DataCache.datas.put(key, temp);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (System.currentTimeMillis() - time < 1000) {
                try {
                    Thread.sleep(1500L);
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
            }
            return temp;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(List<Music> result) {
            NewFragment.this.adapter.clean();
            NewFragment.this.work = false;
            NewFragment.this.mPullRefreshListView.setMode(PullToRefreshBase.Mode.DISABLED);
            if (result != null) {
                for (Music music : result) {
                    NewFragment.this.adapter.addLast(music);
                }
                NewFragment.this.adapter.notifyDataSetChanged();
                NewFragment.this.mPullRefreshListView.onRefreshComplete();
                NewFragment.this.mPullRefreshListView.setLastUpdatedLabel("已经加载了" + NewFragment.this.adapter.getCount() + "首铃声");
                NewFragment.this.page++;
                return;
            }
            if (NewFragment.this.page == 0) {
                NewFragment.this.mPullRefreshListView.setEmptyView(null);
                Activity activity = NewFragment.this.getActivity();
                if (activity != null) {
                    Toast.makeText(activity, "获取数据失败，请稍候再试。", 0).show();
                }
            }
            NewFragment.this.mPullRefreshListView.onRefreshComplete();
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            WidgetLoadling tv = new WidgetLoadling(NewFragment.this.getActivity());
            NewFragment.this.mPullRefreshListView.setEmptyView(tv);
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        if (this.adapter != null) {
            this.adapter.stopMusic();
            this.adapter.notifyDataSetChanged();
        }
        super.onResume();
    }
}
