package com.baoyi.audio;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.ad.Banner;
import com.ad.CP;
import com.baoyi.audio.adapter.SearchItemAdapter;
import com.baoyi.audio.dao.Word;
import com.baoyi.audio.dao.WordDao;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.task.SearcTask;
import com.baoyi.audio.widget.WidgetLoadling;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.hope.leyuan.R;
import com.iflytek.speech.RecognizerResult;
import com.iflytek.speech.SpeechConfig;
import com.iflytek.speech.SpeechError;
import com.iflytek.ui.RecognizerDialog;
import com.iflytek.ui.RecognizerDialogListener;
import com.way.chat.activity.KeywordsView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SearchListUI extends AnalyticsUI implements RecognizerDialogListener, View.OnClickListener {
    private static final int Msg_Load_End = 515;
    private static final int Msg_Start_Load = 258;
    protected static final String TAG = "SearchPage";
    private static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;
    RecognizerDialog iatDialog;
    private AutoCompleteTextView inputsearc;
    private boolean isOutter;
    private ListView listView;
    private PullToRefreshListView mPullRefreshListView;
    private SharedPreferences mSharedPreferences;
    private GestureDetector mggd;
    private ImageView voice_img;
    private ImageView work;
    private String[] totalKeys = null;
    private String[] key_words = new String[15];
    private KeywordsView showKeywords = null;
    private LinearLayout searchLayout = null;
    private LoadKeywordsTask task = null;
    private Handler handler = new Handler() { // from class: com.baoyi.audio.SearchListUI.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SearchListUI.Msg_Start_Load /* 258 */:
                    SearchListUI.this.task = new LoadKeywordsTask(SearchListUI.this, null);
                    new Thread(SearchListUI.this.task).start();
                    return;
                case SearchListUI.Msg_Load_End /* 515 */:
                    SearchListUI.this.showKeywords.rubKeywords();
                    SearchListUI.this.feedKeywordsFlow(SearchListUI.this.showKeywords, SearchListUI.this.key_words);
                    SearchListUI.this.showKeywords.go2Shwo(1);
                    return;
                default:
                    return;
            }
        }
    };

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.baoyi.audio.AnalyticsUI, com.baoyi.audio.BugActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_search_music_list);
        this.searchLayout = (LinearLayout) findViewById(R.id.searchContent);
        this.showKeywords = (KeywordsView) findViewById(R.id.word);
        this.showKeywords.setDuration(2000L);
        this.showKeywords.setOnClickListener(this);
        this.mggd = new GestureDetector(new Mygdlinseter());
        this.showKeywords.setOnTouchListener(new View.OnTouchListener() { // from class: com.baoyi.audio.SearchListUI.2
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View v, MotionEvent event) {
                return SearchListUI.this.mggd.onTouchEvent(event);
            }
        });
        this.isOutter = true;
        this.handler.sendEmptyMessage(Msg_Start_Load);
        Intent intent = getIntent();
        String type = intent.getExtras().getString(UpdateService.NAME);
        this.mPullRefreshListView = (PullToRefreshListView) findViewById(R.id.pull_refresh_list);
        WidgetLoadling tv = new WidgetLoadling(this);
        this.mPullRefreshListView.setEmptyView(tv);
        this.listView = (ListView) this.mPullRefreshListView.getRefreshableView();
        this.inputsearc = (AutoCompleteTextView) findViewById(R.id.inputsearc);
        this.voice_img = (ImageView) findViewById(R.id.img_clear_input);
        this.work = (ImageView) findViewById(R.id.imageView222222);
        SearchItemAdapter adapter = new SearchItemAdapter(this, type);
        this.listView.setAdapter((ListAdapter) adapter);
        this.listView.setOnItemClickListener(adapter);
        this.listView.setDividerHeight(0);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> activities = pm.queryIntentActivities(new Intent("android.speech.action.RECOGNIZE_SPEECH"), 0);
        if (activities.size() != 0) {
            this.voice_img.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.SearchListUI.3
                @Override // android.view.View.OnClickListener
                public void onClick(View arg0) {
                    SearchListUI.this.startVoiceRecognitionActivity();
                }
            });
        } else {
            this.voice_img.setEnabled(true);
            this.voice_img.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.SearchListUI.4
                @Override // android.view.View.OnClickListener
                public void onClick(View arg0) {
                    SearchListUI.this.showIatDialog();
                }
            });
        }
        this.iatDialog = new RecognizerDialog(this, "appid=4f5aeadb");
        this.iatDialog.setListener(this);
        this.inputsearc.addTextChangedListener(new TextWatcher() { // from class: com.baoyi.audio.SearchListUI.5
            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (SearchListUI.this.inputsearc != null) {
                    if (SearchListUI.this.inputsearc.getText().length() != 0) {
                        SearchListUI.this.searchLayout.setVisibility(8);
                        return;
                    }
                    SearchListUI.this.searchLayout.setVisibility(0);
                    SearchListUI.this.listView.setVisibility(8);
                    SearchListUI.this.isOutter = true;
                    SearchListUI.this.searchLayout.removeAllViews();
                    SearchListUI.this.searchLayout.addView(SearchListUI.this.showKeywords);
                }
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
                if (SearchListUI.this.inputsearc != null) {
                    if (SearchListUI.this.inputsearc.getText().length() != 0) {
                        SearchListUI.this.searchLayout.setVisibility(8);
                        return;
                    }
                    SearchListUI.this.searchLayout.setVisibility(0);
                    SearchListUI.this.listView.setVisibility(8);
                    SearchListUI.this.isOutter = true;
                    SearchListUI.this.searchLayout.removeAllViews();
                    SearchListUI.this.searchLayout.addView(SearchListUI.this.showKeywords);
                }
            }
        });
        this.work.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.SearchListUI.6
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (SearchListUI.this.inputsearc.getText() == null || SearchListUI.this.inputsearc.getText().toString().length() == 0) {
                    Toast.makeText(SearchListUI.this, "请输入关键字", 0).show();
                } else {
                    SearchListUI.this.searchmusic();
                }
            }
        });
        Banner.banner_AD(this);
        CP.cp_AD(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String[] getRandomArray() {
        if (this.totalKeys != null && this.totalKeys.length > 0) {
            String[] keys = new String[15];
            List<String> ks = new ArrayList<>();
            for (int i = 0; i < this.totalKeys.length; i++) {
                ks.add(this.totalKeys[i]);
            }
            for (int i2 = 0; i2 < keys.length; i2++) {
                int k = (int) (ks.size() * Math.random());
                keys[i2] = ks.remove(k);
                if (keys[i2] == null) {
                    System.out.println("nulnulnulnulnul");
                }
            }
            System.out.println("result's length = " + keys.length);
            return keys;
        }
        return new String[]{"好听", "3013", "江南", "短信", "想你的夜", "中国好声音", "李代沫", "经典", "英文", "铃声", "闹铃", "搞笑", "优美", "优", "非常"};
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class LoadKeywordsTask implements Runnable {
        private LoadKeywordsTask() {
        }

        /* synthetic */ LoadKeywordsTask(SearchListUI searchListUI, LoadKeywordsTask loadKeywordsTask) {
            this();
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                SearchListUI.this.key_words = SearchListUI.this.getRandomArray();
                if (SearchListUI.this.key_words.length > 0) {
                    SearchListUI.this.handler.sendEmptyMessage(SearchListUI.Msg_Load_End);
                }
            } catch (Exception e) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void feedKeywordsFlow(KeywordsView keyworldFlow, String[] arr) {
        for (int i = 0; i < 15; i++) {
            String tmp = arr[i];
            keyworldFlow.feedKeyword(tmp);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void searchmusic() {
        String key = this.inputsearc.getText().toString();
        if (key != null && key.length() > 0) {
            new SearcTask().execute(key);
            WordDao dao = new WordDao(this);
            Word word = new Word();
            word.setName(key);
            word.setSearchtime(System.currentTimeMillis());
            dao.addToTrack(word);
            SharedPreferences sharedPreferences = getSharedPreferences("defalutdata", 0);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("lastkey", key);
            editor.commit();
            SearchItemAdapter adapter = new SearchItemAdapter(this, key);
            if (this.listView != null) {
                this.listView.setAdapter((ListAdapter) adapter);
                this.listView.setOnItemClickListener(adapter);
                this.listView.setDividerHeight(0);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startVoiceRecognitionActivity() {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        intent.putExtra("android.speech.extra.PROMPT", "请说出你要搜索的歌曲");
        startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.baoyi.audio.AnalyticsUI, android.app.Activity
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        ArrayList<String> matches;
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>" + resultCode);
        if (requestCode == VOICE_RECOGNITION_REQUEST_CODE && resultCode == -1 && (matches = data.getStringArrayListExtra("android.speech.extra.RESULTS")) != null && matches.size() > 0) {
            this.inputsearc.setText(matches.get(0));
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override // com.iflytek.ui.RecognizerDialogListener
    public void onEnd(SpeechError arg0) {
    }

    @Override // com.iflytek.ui.RecognizerDialogListener
    public void onResults(ArrayList<RecognizerResult> results, boolean arg1) {
        StringBuilder builder = new StringBuilder();
        Iterator<RecognizerResult> it = results.iterator();
        if (it.hasNext()) {
            RecognizerResult recognizerResult = it.next();
            builder.append(recognizerResult.text);
            System.out.println(recognizerResult.text);
        }
        this.inputsearc.append(remove(builder));
        this.inputsearc.setSelection(this.inputsearc.length());
    }

    private String remove(StringBuilder builder) {
        String m = builder.toString();
        if (m == null) {
            m = "";
        }
        return m.replace("。", "").replace(".", "").replace(",", "").replace("，", "");
    }

    public void showIatDialog() {
        this.iatDialog.setEngine("video", null, null);
        if (!"rate16k".equals("rate8k")) {
            if (!"rate16k".equals("rate11k")) {
                if (!"rate16k".equals("rate16k")) {
                    if ("rate16k".equals("rate22k")) {
                        this.iatDialog.setSampleRate(SpeechConfig.RATE.rate22k);
                    }
                } else {
                    this.iatDialog.setSampleRate(SpeechConfig.RATE.rate16k);
                }
            } else {
                this.iatDialog.setSampleRate(SpeechConfig.RATE.rate11k);
            }
        } else {
            this.iatDialog.setSampleRate(SpeechConfig.RATE.rate8k);
        }
        this.iatDialog.show();
        this.inputsearc.setText("");
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class Mygdlinseter implements GestureDetector.OnGestureListener {
        Mygdlinseter() {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent e) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent e) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent e) {
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            if (e2.getX() - e1.getX() > 100.0f) {
                SearchListUI.this.key_words = SearchListUI.this.getRandomArray();
                SearchListUI.this.showKeywords.rubKeywords();
                SearchListUI.this.feedKeywordsFlow(SearchListUI.this.showKeywords, SearchListUI.this.key_words);
                SearchListUI.this.showKeywords.go2Shwo(2);
                return true;
            }
            if (e2.getX() - e1.getX() < -100.0f) {
                SearchListUI.this.key_words = SearchListUI.this.getRandomArray();
                SearchListUI.this.showKeywords.rubKeywords();
                SearchListUI.this.feedKeywordsFlow(SearchListUI.this.showKeywords, SearchListUI.this.key_words);
                SearchListUI.this.showKeywords.go2Shwo(1);
                return true;
            }
            if (e2.getY() - e1.getY() < -100.0f) {
                SearchListUI.this.key_words = SearchListUI.this.getRandomArray();
                SearchListUI.this.showKeywords.rubKeywords();
                SearchListUI.this.feedKeywordsFlow(SearchListUI.this.showKeywords, SearchListUI.this.key_words);
                SearchListUI.this.showKeywords.go2Shwo(1);
                return true;
            }
            if (e2.getY() - e1.getY() > 100.0f) {
                SearchListUI.this.key_words = SearchListUI.this.getRandomArray();
                SearchListUI.this.showKeywords.rubKeywords();
                SearchListUI.this.feedKeywordsFlow(SearchListUI.this.showKeywords, SearchListUI.this.key_words);
                SearchListUI.this.showKeywords.go2Shwo(2);
                return true;
            }
            return false;
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        System.out.println("V" + v);
        if (this.isOutter) {
            this.isOutter = false;
            String kw = ((TextView) v).getText().toString();
            Log.i(TAG, "keywords = " + kw);
            if (!kw.trim().equals("")) {
                this.searchLayout.removeAllViews();
            }
            Toast.makeText(this, ((TextView) v).getText().toString(), 1).show();
            String str = ((TextView) v).getText().toString();
            if (str != null) {
                this.inputsearc.setText(str);
                System.out.println("str" + str);
                if (this.searchLayout.getVisibility() == 0) {
                    this.searchLayout.setVisibility(8);
                }
                searchmusic();
            }
        }
    }
}
