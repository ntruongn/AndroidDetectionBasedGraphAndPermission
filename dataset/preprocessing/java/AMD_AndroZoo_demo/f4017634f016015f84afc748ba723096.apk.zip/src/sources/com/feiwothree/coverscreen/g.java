package com.feiwothree.coverscreen;

import android.content.Context;
import android.content.Intent;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class g implements Runnable {
    private /* synthetic */ AdComponent a;
    private final /* synthetic */ Intent b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(AdComponent adComponent, Intent intent) {
        this.a = adComponent;
        this.b = intent;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Context context;
        context = this.a.d;
        context.startActivity(this.b);
    }
}
