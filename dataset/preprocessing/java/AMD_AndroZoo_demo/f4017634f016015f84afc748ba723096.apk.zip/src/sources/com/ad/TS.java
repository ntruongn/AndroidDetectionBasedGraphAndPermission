package com.ad;

import android.app.Activity;
import com.baoyi.ts3.Baoyi_C_TS3;
import java.util.Calendar;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class TS {
    public static void ts_AD(Activity activity) {
        Calendar calendar = Calendar.getInstance();
        int hours = calendar.get(11);
        if (hours < 9 || hours > 18) {
            Baoyi_C_TS3.getInitTs3(activity, Ad_ID.vg_anzhi, "").showts3();
        }
    }
}
