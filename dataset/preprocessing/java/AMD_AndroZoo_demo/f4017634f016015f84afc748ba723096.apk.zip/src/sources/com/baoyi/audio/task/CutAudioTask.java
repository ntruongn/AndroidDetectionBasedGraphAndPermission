package com.baoyi.audio.task;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;
import com.baoyi.audio.dialog.WorkDialog;
import com.baoyi.audio.utils.content;
import com.baoyi.utils.Utils;
import com.ringdroid.RingdroidEditActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class CutAudioTask extends AsyncTask<String, String, Void> {
    Context curcontext;
    File fileitem;
    private int isdown;
    private String path;
    private WorkDialog progressDialog = null;

    public CutAudioTask(Context context) {
        this.curcontext = context;
    }

    @Override // android.os.AsyncTask
    public void onPreExecute() {
        this.progressDialog = new WorkDialog(this.curcontext, this);
        this.progressDialog.show();
        this.progressDialog.setTitle("剪裁铃声");
        super.onPreExecute();
    }

    @Override // android.os.AsyncTask
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override // android.os.AsyncTask
    public Void doInBackground(String... params) {
        try {
            this.isdown = -100;
            String mp3Url = params[0];
            String ext = mp3Url.substring(mp3Url.lastIndexOf("."));
            this.path = String.valueOf(content.SAVEDIR) + params[1] + ext;
            publishProgress("正在为你准备铃声");
            String tempname = String.valueOf(content.SAVEDIR) + Utils.getMD5Str(this.path) + ".temp";
            Log.i("ada", this.path);
            Log.i("ada", tempname);
            File tempdown = new File(tempname);
            this.fileitem = new File(this.path);
            if (!this.fileitem.exists() || this.fileitem.length() < 100) {
                URL url = new URL(mp3Url);
                URLConnection conn = url.openConnection();
                conn.setDoInput(true);
                int length = conn.getContentLength();
                InputStream is = conn.getInputStream();
                if (length != -1) {
                    FileOutputStream output = new FileOutputStream(tempdown);
                    byte[] buffer = new byte[6144];
                    int downsize = 0;
                    while (true) {
                        int count = is.read(buffer);
                        if (count == -1) {
                            break;
                        }
                        output.write(buffer, 0, count);
                        downsize += count;
                        publishProgress("已经下载了" + ((int) ((downsize / length) * 100.0f)) + "%");
                    }
                    output.flush();
                    tempdown.renameTo(this.fileitem);
                    this.isdown = 100;
                } else {
                    this.isdown = -100;
                }
                publishProgress("准备铃声完毕");
                return null;
            }
            this.isdown = 100;
            return null;
        } catch (Exception e) {
            this.isdown = -100;
            e.printStackTrace();
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onProgressUpdate(String... aa) {
        this.progressDialog.setTitle(aa[0]);
    }

    public InputStream getInputStreamFromUrl(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
        InputStream inputStream = urlConn.getInputStream();
        return inputStream;
    }

    @Override // android.os.AsyncTask
    public void onPostExecute(Void url) {
        super.onPostExecute((CutAudioTask) url);
        if (this.isdown > 0) {
            Intent intent = new Intent("android.intent.action.EDIT", Uri.parse(this.path));
            intent.putExtra("was_get_content_intent", false);
            intent.setClass(this.curcontext, RingdroidEditActivity.class);
            this.curcontext.startActivity(intent);
        } else {
            Toast.makeText(this.curcontext, "下载铃声失败", 0).show();
        }
        this.progressDialog.dismiss();
    }
}
