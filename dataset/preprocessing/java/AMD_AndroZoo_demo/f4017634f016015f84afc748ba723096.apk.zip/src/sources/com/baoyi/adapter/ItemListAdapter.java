package com.baoyi.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.LinkedList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public abstract class ItemListAdapter<I> extends BaseAdapter {
    protected Context context;
    protected LinkedList<I> datas = new LinkedList<>();

    protected abstract View creatView(int i, I i2);

    protected abstract View update(int i, View view, I i2);

    protected abstract void updateView(int i, View view);

    public ItemListAdapter(Context context) {
        this.context = context;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.datas.size();
    }

    public void clear() {
        this.datas.clear();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        return this.datas.get(position);
    }

    public I getData(int position) {
        return this.datas.get(position);
    }

    public I getFirst() {
        return this.datas.getFirst();
    }

    public I getLast() {
        return this.datas.getLast();
    }

    public void add(I item) {
        this.datas.add(item);
    }

    public void addFirst(I item) {
        this.datas.addFirst(item);
    }

    public void addLast(I item) {
        this.datas.addLast(item);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return position;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        View view2 = convertView != null ? (View) convertView.getTag() : null;
        if (view2 == null) {
            I item = getData(position);
            view = creatView(position, item);
        } else {
            I item2 = getData(position);
            view = update(position, view2, item2);
        }
        updateView(position, view);
        return view;
    }
}
