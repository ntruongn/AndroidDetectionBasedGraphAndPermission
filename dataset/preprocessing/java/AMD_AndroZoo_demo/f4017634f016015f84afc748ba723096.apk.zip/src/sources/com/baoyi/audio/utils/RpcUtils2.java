package com.baoyi.audio.utils;

import com.baoyi.audio.cache.MyCache;
import com.baoyi.audio.cache.MyDiskCach;
import com.iring.dao.ApkCommentDao;
import com.iring.dao.CommentDao;
import com.iring.dao.MemberDao;
import com.iring.dao.MessageDao;
import com.iring.dao.MusicDao;
import com.iring.dao.UserApi;
import java.net.URL;
import org.json.rpc.client.HttpJsonRpcClientTransport;
import org.json.rpc.client.JsonRpcInvoker;
import org.json.rpc.commons.AllowAllTypeChecker;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RpcUtils2 {
    public static final String picurl = "http://iring.wutianxia.com:8080/iringrpcv4/PicUploadWork";
    public static final String url = "http://iring.wutianxia.com:8080/iringrpcv4/v4";

    public static UserApi getUserRpc() {
        try {
            HttpJsonRpcClientTransport transport = new HttpJsonRpcClientTransport(new URL(url));
            JsonRpcInvoker invoker = new JsonRpcInvoker();
            UserApi result = (UserApi) invoker.get(transport, "userRpcImpl", UserApi.class);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static MusicDao getMusicDao() {
        try {
            HttpJsonRpcClientTransport transport = new HttpJsonRpcClientTransport(new URL(url));
            JsonRpcInvoker invoker = new JsonRpcInvoker();
            invoker.setCache(MyCache.getMyCache());
            invoker.setDiskCache(MyDiskCach.getMyDiskCach());
            MusicDao result = (MusicDao) invoker.get(transport, "musicDao", MusicDao.class);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static MusicDao getMusicDaoTime() {
        try {
            HttpJsonRpcClientTransport transport = new HttpJsonRpcClientTransport(new URL(url));
            JsonRpcInvoker invoker = new JsonRpcInvoker(new AllowAllTypeChecker(), 0);
            invoker.setCache(MyCache.getMyCache());
            invoker.setDiskCache(MyDiskCach.getMyDiskCach());
            MusicDao result = (MusicDao) invoker.get(transport, "musicDao", MusicDao.class);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static CommentDao getCommentRpc() {
        try {
            HttpJsonRpcClientTransport transport = new HttpJsonRpcClientTransport(new URL(url));
            JsonRpcInvoker invoker = new JsonRpcInvoker();
            CommentDao result = (CommentDao) invoker.get(transport, "commentDao", CommentDao.class);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static <T> T getApi(String str, Class<T> cls) {
        try {
            return (T) new JsonRpcInvoker().get(new HttpJsonRpcClientTransport(new URL(url)), str, cls);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static ApkCommentDao getApkCommentDao() {
        try {
            HttpJsonRpcClientTransport transport = new HttpJsonRpcClientTransport(new URL(url));
            JsonRpcInvoker invoker = new JsonRpcInvoker();
            ApkCommentDao result = (ApkCommentDao) invoker.get(transport, "apkCommentDao", ApkCommentDao.class);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static MemberDao getMemberDao() {
        try {
            HttpJsonRpcClientTransport transport = new HttpJsonRpcClientTransport(new URL(url));
            JsonRpcInvoker invoker = new JsonRpcInvoker();
            MemberDao result = (MemberDao) invoker.get(transport, "memberDao", MemberDao.class);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static MessageDao getMessageDao() {
        try {
            HttpJsonRpcClientTransport transport = new HttpJsonRpcClientTransport(new URL(url));
            JsonRpcInvoker invoker = new JsonRpcInvoker();
            MessageDao result = (MessageDao) invoker.get(transport, "messageDao", MessageDao.class);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static <T> T getDao(String str, Class<T> cls) {
        try {
            HttpJsonRpcClientTransport httpJsonRpcClientTransport = new HttpJsonRpcClientTransport(new URL(url));
            JsonRpcInvoker jsonRpcInvoker = new JsonRpcInvoker();
            jsonRpcInvoker.setCache(MyCache.getMyCache());
            return (T) jsonRpcInvoker.get(httpJsonRpcClientTransport, str, cls);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static <T> T getNoCacheDao(String str, Class<T> cls) {
        try {
            return (T) new JsonRpcInvoker().get(new HttpJsonRpcClientTransport(new URL(url)), str, cls);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
