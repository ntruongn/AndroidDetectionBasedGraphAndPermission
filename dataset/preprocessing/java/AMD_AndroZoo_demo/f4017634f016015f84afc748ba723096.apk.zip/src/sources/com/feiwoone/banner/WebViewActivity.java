package com.feiwoone.banner;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class WebViewActivity extends Activity implements View.OnClickListener {
    private WebView a;
    private RelativeLayout b;

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case 991:
                if (this.a != null) {
                    this.a.clearView();
                }
                finish();
                return;
            case 992:
                if (this.a == null || !this.a.canGoBack()) {
                    return;
                }
                this.a.goBack();
                return;
            case 993:
                if (this.a == null || !this.a.canGoForward()) {
                    return;
                }
                this.a.goForward();
                return;
            case 994:
                if (this.a.getUrl() == null || this.a.getUrl().equals("")) {
                    return;
                }
                try {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse(this.a.getUrl())));
                    return;
                } catch (Exception e) {
                    return;
                }
            default:
                return;
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.b = new RelativeLayout(this);
        requestWindowFeature(1);
        this.b.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        try {
            Intent intent = getIntent();
            try {
                this.a = new WebView(this);
            } catch (Exception e) {
                this.a = null;
                this.a = new WebView(this);
            }
            this.a.getSettings().setJavaScriptEnabled(true);
            this.a.getSettings().setUseWideViewPort(true);
            this.a.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
            this.a.getSettings().setCacheMode(0);
            this.a.getSettings().setBlockNetworkImage(true);
            this.a.getSettings().setSupportZoom(true);
            this.a.getSettings().setBuiltInZoomControls(true);
            this.a.setHorizontalScrollBarEnabled(false);
            this.a.setVerticalScrollBarEnabled(false);
            String string = intent.getExtras().getString("url");
            this.a.setWebChromeClient(new WebChromeClient());
            this.a.setWebViewClient(new WebViewClient() { // from class: com.feiwoone.banner.WebViewActivity.1
                @Override // android.webkit.WebViewClient
                public void onPageFinished(WebView webView, String str) {
                    WebViewActivity.this.a.getSettings().setBlockNetworkImage(false);
                    super.onPageFinished(webView, str);
                }
            });
            try {
                this.a.loadUrl(string);
            } catch (Exception e2) {
                finish();
            }
            (com.feiwoone.banner.f.k.d(this).b() > 480 ? new RelativeLayout.LayoutParams(-1, -2) : new RelativeLayout.LayoutParams(-1, 40)).addRule(12);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
            layoutParams.addRule(2, 100);
            this.b.addView(this.a, layoutParams);
        } catch (Exception e3) {
            finish();
        }
        setContentView(this.b);
    }

    public void onDestory() {
        super.onDestroy();
        if (this.a != null) {
            this.a.stopLoading();
            this.a.clearView();
        }
        this.a = null;
        this.b = null;
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 4 && this.a.canGoBack()) {
            this.a.goBack();
            return true;
        }
        if (i == 4 && this.a != null) {
            this.a.clearView();
        }
        return super.onKeyDown(i, keyEvent);
    }
}
