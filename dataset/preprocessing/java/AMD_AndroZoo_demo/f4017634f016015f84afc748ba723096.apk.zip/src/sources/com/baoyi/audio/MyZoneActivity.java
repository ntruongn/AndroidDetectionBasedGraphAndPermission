package com.baoyi.audio;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.baoyi.audio.fragment.FavMusicFragment;
import com.baoyi.audio.fragment.FollowFragment;
import com.baoyi.audio.fragment.UserRingRecommendFragment;
import com.baoyi.audio.utils.RpcUtils2;
import com.baoyi.audio.utils.content;
import com.baoyi.qingsongring.EditInfoActivity;
import com.baoyi.utils.Utils;
import com.hope.leyuan.R;
import com.iring.dao.MemberDao;
import com.iring.entity.Member;
import com.wrapp.android.webimage.WebImageView;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MyZoneActivity extends AnalyticsFrameUI implements View.OnClickListener {
    private ImageButton editBtn;
    private CheckBox followCb;
    private TextView memberName;
    private TextView member_message;
    private WebImageView member_pic;
    private LinearLayout my_commendLl;
    private LinearLayout my_favLl;
    private LinearLayout my_followLl;
    private TextView point;
    private int userid;
    private ViewPager viewpager;
    private View.OnClickListener gotoEditorActivity = new View.OnClickListener() { // from class: com.baoyi.audio.MyZoneActivity.1
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            Intent intent = new Intent(MyZoneActivity.this, (Class<?>) EditInfoActivity.class);
            MyZoneActivity.this.startActivity(intent);
        }
    };
    private ViewPager.OnPageChangeListener pageChangeListener = new ViewPager.OnPageChangeListener() { // from class: com.baoyi.audio.MyZoneActivity.2
        @Override // android.support.v4.view.ViewPager.OnPageChangeListener
        public void onPageSelected(int arg0) {
            switch (arg0) {
                case 0:
                    MyZoneActivity.this.my_commendLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                    MyZoneActivity.this.my_followLl.setBackgroundColor(MyZoneActivity.this.getResources().getColor(R.color.transparent));
                    MyZoneActivity.this.my_favLl.setBackgroundColor(MyZoneActivity.this.getResources().getColor(R.color.transparent));
                    return;
                case 1:
                    MyZoneActivity.this.my_followLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                    MyZoneActivity.this.my_commendLl.setBackgroundColor(MyZoneActivity.this.getResources().getColor(R.color.transparent));
                    MyZoneActivity.this.my_favLl.setBackgroundColor(MyZoneActivity.this.getResources().getColor(R.color.transparent));
                    return;
                case 2:
                    MyZoneActivity.this.my_favLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                    MyZoneActivity.this.my_followLl.setBackgroundColor(MyZoneActivity.this.getResources().getColor(R.color.transparent));
                    MyZoneActivity.this.my_commendLl.setBackgroundColor(MyZoneActivity.this.getResources().getColor(R.color.transparent));
                    return;
                default:
                    return;
            }
        }

        @Override // android.support.v4.view.ViewPager.OnPageChangeListener
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        @Override // android.support.v4.view.ViewPager.OnPageChangeListener
        public void onPageScrollStateChanged(int arg0) {
        }
    };

    @Override // com.baoyi.audio.AnalyticsFrameUI, android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.activity_myzone);
        this.userid = getUserid();
        initWidget();
        new LoadMemberData(this, null).execute(new Void[0]);
    }

    private void initWidget() {
        this.member_pic = (WebImageView) findViewById(R.id.member_pic);
        this.editBtn = (ImageButton) findViewById(R.id.edit_btn);
        this.memberName = (TextView) findViewById(R.id.memberName);
        this.followCb = (CheckBox) findViewById(R.id.follow_cb);
        this.point = (TextView) findViewById(R.id.point);
        this.member_message = (TextView) findViewById(R.id.member_message);
        this.my_followLl = (LinearLayout) findViewById(R.id.my_follow_ll);
        this.my_commendLl = (LinearLayout) findViewById(R.id.my_recommend_ll);
        this.my_favLl = (LinearLayout) findViewById(R.id.my_fav_ll);
        this.viewpager = (ViewPager) findViewById(R.id.pager);
        this.member_pic.setOnClickListener(this.gotoEditorActivity);
        this.editBtn.setOnClickListener(this.gotoEditorActivity);
        this.my_followLl.setOnClickListener(this);
        this.my_commendLl.setOnClickListener(this);
        this.my_favLl.setOnClickListener(this);
        ZoneFragmentPagerAdapter pagerAdapter = new ZoneFragmentPagerAdapter(getSupportFragmentManager());
        pagerAdapter.add(new UserRingRecommendFragment(this.userid));
        pagerAdapter.add(new FollowFragment(this.userid));
        pagerAdapter.add(new FavMusicFragment(this.userid));
        this.viewpager.setAdapter(pagerAdapter);
        this.viewpager.setOnPageChangeListener(this.pageChangeListener);
        this.member_pic.setErrorImage(getResources().getDrawable(R.drawable.member_pic1));
    }

    public static boolean isMethodsCompat(int VersionCode) {
        int currentVersion = Build.VERSION.SDK_INT;
        return currentVersion >= VersionCode;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setData(Member member) {
        SharedPreferences sharedPreferences = getSharedPreferences("apps", 0);
        this.memberName.setText(member.getNickname());
        this.point.setText("积分:" + member.getMoney());
        this.member_message.setText(member.getMessages());
        if (member.getPicture() != null) {
            sharedPreferences.edit().putString("bigpic", member.getPicture()).commit();
        }
        if (member.getMinpicture() != null) {
            sharedPreferences.edit().putString("minipic", member.getMinpicture()).commit();
        }
        this.member_pic.setImageUrl(String.valueOf(content.picserver) + member.getPicture());
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class ZoneFragmentPagerAdapter extends FragmentPagerAdapter {
        public List<Fragment> fragments;

        public ZoneFragmentPagerAdapter(FragmentManager fm) {
            super(fm);
            this.fragments = new ArrayList();
        }

        @Override // android.support.v4.app.FragmentPagerAdapter
        public Fragment getItem(int arg0) {
            if (this.fragments != null) {
                return this.fragments.get(arg0);
            }
            return null;
        }

        @Override // android.support.v4.view.PagerAdapter
        public int getCount() {
            if (this.fragments != null) {
                return this.fragments.size();
            }
            return 0;
        }

        public void add(Fragment fragment) {
            this.fragments.add(fragment);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    private class LoadMemberData extends AsyncTask<Void, Boolean, Member> {
        private LoadMemberData() {
        }

        /* synthetic */ LoadMemberData(MyZoneActivity myZoneActivity, LoadMemberData loadMemberData) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Member doInBackground(Void... params) {
            int userid = Utils.getUserid(MyZoneActivity.this);
            if (userid == -1) {
                publishProgress(false);
                return null;
            }
            MemberDao mDao = (MemberDao) RpcUtils2.getNoCacheDao("memberDao", MemberDao.class);
            if (mDao == null) {
                return null;
            }
            Member member = mDao.findById(userid);
            return member;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Member result) {
            if (result != null) {
                MyZoneActivity.this.setData(result);
            } else {
                Toast.makeText(MyZoneActivity.this, "网络信号不好，无法获取用户信息", 0).show();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(Boolean... values) {
            if (!values[0].booleanValue()) {
                Toast.makeText(MyZoneActivity.this, "您没有登陆", 0).show();
            }
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.my_recommend_ll /* 2131296299 */:
                this.viewpager.setCurrentItem(0);
                this.my_commendLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                this.my_followLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                this.my_favLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                return;
            case R.id.my_follow_ll /* 2131296300 */:
                this.viewpager.setCurrentItem(1);
                this.my_commendLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                this.my_followLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                this.my_favLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                return;
            case R.id.my_fav_ll /* 2131296301 */:
                this.my_commendLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                this.my_followLl.setBackgroundColor(getResources().getColor(R.color.transparent));
                this.my_favLl.setBackgroundResource(R.drawable.zone_mid_sel_bg);
                this.viewpager.setCurrentItem(2);
                return;
            default:
                return;
        }
    }

    @Override // com.baoyi.audio.AnalyticsFrameUI, android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_myzone, menu);
        return true;
    }

    @Override // com.baoyi.audio.AnalyticsFrameUI, android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menu) {
        if (menu.getItemId() == 2131296517) {
            Intent intent = new Intent(this, (Class<?>) LoginActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}
