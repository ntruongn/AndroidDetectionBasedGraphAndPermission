package com.baoyi.doamin;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Song {
    private String aacpath;
    private String artist;
    private String artist_pic;
    private String artist_url;
    private String auther_url;
    private int mid;
    private String mp3path;
    private String music_id;
    private String mv_rid;
    private String name;
    private String path;
    private String song_url;

    public int getMid() {
        return this.mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getMusic_id() {
        return this.music_id;
    }

    public void setMusic_id(String music_id) {
        this.music_id = music_id;
    }

    public String getMv_rid() {
        return this.mv_rid;
    }

    public void setMv_rid(String mv_rid) {
        this.mv_rid = mv_rid;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSong_url() {
        return this.song_url;
    }

    public void setSong_url(String song_url) {
        this.song_url = song_url;
    }

    public String getArtist() {
        return this.artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getArtist_url() {
        return this.artist_url;
    }

    public void setArtist_url(String artist_url) {
        this.artist_url = artist_url;
    }

    public String getAuther_url() {
        return this.auther_url;
    }

    public void setAuther_url(String auther_url) {
        this.auther_url = auther_url;
    }

    public String getArtist_pic() {
        return this.artist_pic;
    }

    public void setArtist_pic(String artist_pic) {
        this.artist_pic = artist_pic;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getMp3path() {
        return this.mp3path;
    }

    public void setMp3path(String mp3path) {
        this.mp3path = mp3path;
    }

    public String getAacpath() {
        return this.aacpath;
    }

    public void setAacpath(String aacpath) {
        this.aacpath = aacpath;
    }
}
