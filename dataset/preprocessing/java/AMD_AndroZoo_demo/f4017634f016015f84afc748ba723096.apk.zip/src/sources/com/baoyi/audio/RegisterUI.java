package com.baoyi.audio;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.utils.RpcUtils2;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class RegisterUI extends AnalyticsUI {
    private UserLoginTask mAuthTask = null;
    private String mEmail;
    private EditText mEmailView;
    private String mPassword;
    private EditText mPasswordView;
    private String name;
    private String password;

    @Override // com.baoyi.audio.AnalyticsUI, com.baoyi.audio.BugActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ui_register);
        this.mEmailView = (EditText) findViewById(R.id.username);
        this.mEmailView.setText(this.mEmail);
        this.mPasswordView = (EditText) findViewById(R.id.password);
        this.mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.baoyi.audio.RegisterUI.1
            @Override // android.widget.TextView.OnEditorActionListener
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                RegisterUI.this.attemptLogin();
                return true;
            }
        });
        findViewById(R.id.sign_in_button).setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.audio.RegisterUI.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                RegisterUI.this.attemptLogin();
            }
        });
    }

    public void attemptLogin() {
        if (this.mAuthTask == null) {
            this.mEmailView.setError(null);
            this.mPasswordView.setError(null);
            this.mEmail = this.mEmailView.getText().toString();
            this.mPassword = this.mPasswordView.getText().toString();
            boolean cancel = false;
            View focusView = null;
            if (TextUtils.isEmpty(this.mPassword)) {
                this.mPasswordView.setError("密码不能为空");
                focusView = this.mPasswordView;
                cancel = true;
            } else if (this.mPassword.length() < 4) {
                this.mPasswordView.setError("长度不够,长度必须大于等于4");
                focusView = this.mPasswordView;
                cancel = true;
            }
            if (TextUtils.isEmpty(this.mEmail)) {
                this.mEmailView.setError("用户名不能为空");
                focusView = this.mEmailView;
                cancel = true;
            }
            if (cancel) {
                focusView.requestFocus();
            } else {
                new UserLoginTask(this).execute(this.mEmail, this.mPassword);
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    public class UserLoginTask extends AsyncTask<String, Void, Integer> {
        private Context context;
        private ProgressDialog progressDialog = null;

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Integer doInBackground(String... params) {
            try {
                RegisterUI.this.name = params[0];
                RegisterUI.this.password = params[1];
                Integer r = Integer.valueOf(RpcUtils2.getUserRpc().register(params[0], params[1]));
                return r;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Integer success) {
            RegisterUI.this.mAuthTask = null;
            this.progressDialog.dismiss();
            if (success == null || success.intValue() != 1) {
                RegisterUI.this.mPasswordView.requestFocus();
                Toast.makeText(RegisterUI.this, "注册失败，请重新选择用户名", 0).show();
            } else {
                Toast.makeText(RegisterUI.this, "注册成功,请记住你的用户名和密码", 0).show();
                RegisterUI.this.login(success);
            }
        }

        @Override // android.os.AsyncTask
        protected void onCancelled() {
            RegisterUI.this.mAuthTask = null;
        }

        public UserLoginTask(Context context) {
            this.context = context;
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            this.progressDialog = ProgressDialog.show(this.context, "用户注册", "正在连接服务器,请稍候！", true);
            this.progressDialog.setCancelable(true);
            this.progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.baoyi.audio.RegisterUI.UserLoginTask.1
                @Override // android.content.DialogInterface.OnCancelListener
                public void onCancel(DialogInterface dialog) {
                    UserLoginTask.this.cancel(true);
                }
            });
            super.onPreExecute();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void login(Integer success) {
        Intent intent = new Intent();
        intent.putExtra(UpdateService.NAME, this.name);
        intent.putExtra("password", this.password);
        setResult(-1, intent);
        finish();
    }
}
