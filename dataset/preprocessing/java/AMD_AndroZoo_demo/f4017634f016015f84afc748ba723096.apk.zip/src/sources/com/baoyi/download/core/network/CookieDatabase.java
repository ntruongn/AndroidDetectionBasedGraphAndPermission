package com.baoyi.download.core.network;

import java.util.Date;
import java.util.List;
import org.apache.http.cookie.Cookie;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public abstract class CookieDatabase {
    private static CookieDatabase ourInstance;

    /* JADX INFO: Access modifiers changed from: protected */
    public abstract List<Cookie> loadCookies();

    /* JADX INFO: Access modifiers changed from: protected */
    public abstract void removeAll();

    /* JADX INFO: Access modifiers changed from: protected */
    public abstract void removeObsolete(Date date);

    /* JADX INFO: Access modifiers changed from: protected */
    public abstract void saveCookies(List<Cookie> list);

    public static CookieDatabase getInstance() {
        return ourInstance;
    }

    protected CookieDatabase() {
        ourInstance = this;
    }
}
