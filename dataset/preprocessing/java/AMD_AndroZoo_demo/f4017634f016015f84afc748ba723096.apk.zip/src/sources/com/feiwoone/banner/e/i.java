package com.feiwoone.banner.e;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class i implements Runnable {
    private long e;
    private l k;
    private /* synthetic */ g m;
    private long a = 0;
    private int b = -1;
    private long c = 0;
    private int d = 0;
    private String f = null;
    private String g = null;
    private com.feiwoone.banner.c.b h = null;
    private Context i = null;
    private URL j = null;
    private boolean l = false;

    public i(g gVar) {
        this.m = gVar;
    }

    private void a() {
        Handler handler;
        Notification notification = new Notification();
        notification.icon = 17301586;
        notification.tickerText = this.h.d();
        notification.flags = 16;
        notification.when = this.e;
        notification.setLatestEventInfo(this.i, this.h.d(), String.valueOf("正在下载，已下载 _placeholder".replace("_placeholder", "")) + (this.d + 1) + "%", PendingIntent.getActivity(this.i, 0, new Intent(), 0));
        handler = this.m.c;
        handler.post(new j(this, notification));
        this.h.a(this.d);
        this.h.a(this.a);
        this.i.getSharedPreferences(com.feiwoone.banner.b.a.d, 0).edit().putString(this.h.f(), q.a(this.h)).commit();
    }

    private void a(String str) {
        Handler handler;
        com.feiwoone.banner.f.e.a(this.i, "ADFEIWO", this.h.f(), this.h.a(), "12345678");
        Context context = this.i;
        String str2 = String.valueOf(this.h.f()) + "_time";
        context.getSharedPreferences("ADFEIWO", 0).edit().putLong(com.feiwoone.banner.f.f.a(str2, "12345678", true), System.currentTimeMillis()).commit();
        Uri fromFile = Uri.fromFile(new File(str));
        Intent intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        intent.setData(fromFile);
        intent.addFlags(268435456);
        intent.setClassName("com.android.packageinstaller", "com.android.packageinstaller.PackageInstallerActivity");
        handler = this.m.c;
        handler.post(new k(this, intent));
        this.i.getSharedPreferences(com.feiwoone.banner.b.a.d, 0).edit().remove(this.h.f()).commit();
        l lVar = this.k;
    }

    public final void a(Context context, com.feiwoone.banner.c.b bVar, String str) {
        this.i = context;
        this.f = str;
        this.h = bVar;
        this.g = bVar.b();
        try {
            this.j = new URL(this.g);
        } catch (MalformedURLException e) {
        }
    }

    public final void a(l lVar) {
        this.k = lVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [java.io.FileOutputStream] */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v4, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r1v9 */
    @Override // java.lang.Runnable
    public final void run() {
        InputStream inputStream;
        FileOutputStream fileOutputStream;
        HttpURLConnection httpURLConnection;
        InputStream inputStream2;
        FileOutputStream fileOutputStream2;
        ?? r1 = 0;
        HttpURLConnection httpURLConnection2 = null;
        if (this.j == null) {
            throw new IllegalArgumentException("URL must be init!_placeholder".replace("_placeholder", ""));
        }
        this.e = System.currentTimeMillis();
        this.a = 0L;
        this.b = -1;
        this.d = 0;
        File file = new File(this.f);
        if (!file.exists()) {
            file.mkdirs();
        }
        String str = String.valueOf(this.f) + this.g.substring(this.g.lastIndexOf("/") + 1);
        File file2 = new File(str);
        byte[] bArr = new byte[4096];
        try {
            httpURLConnection = (HttpURLConnection) this.j.openConnection();
            try {
                httpURLConnection.setConnectTimeout(20000);
                httpURLConnection.setReadTimeout(20000);
                if (file2.exists()) {
                    f.a(this.i);
                    if (f.b()) {
                        this.a = file2.length();
                        httpURLConnection.setRequestProperty("Range", "bytes=" + this.a + "-");
                        this.l = true;
                    }
                }
                httpURLConnection.connect();
                inputStream = httpURLConnection.getInputStream();
                try {
                    try {
                        this.c = httpURLConnection.getContentLength();
                        if (file.exists() && (-1 == this.c || file2.length() == this.c)) {
                            a(str);
                            if (inputStream != null) {
                                try {
                                    inputStream.close();
                                } catch (IOException e) {
                                }
                            }
                            if (httpURLConnection != null) {
                                httpURLConnection.disconnect();
                            }
                            this.m.a(this.h);
                            return;
                        }
                        int responseCode = httpURLConnection.getResponseCode();
                        if (responseCode == 200 && file2.exists()) {
                            file2.delete();
                            this.a = 0L;
                        }
                        if (responseCode == 206) {
                            this.c += this.a;
                        } else {
                            this.l = false;
                        }
                        f.a(this.i);
                        FileOutputStream fileOutputStream3 = f.b() ? new FileOutputStream(file2, this.l) : this.i.openFileOutput(this.g.substring(this.g.lastIndexOf("/") + 1), 1);
                        try {
                            this.h.b(this.c);
                            this.d = (int) ((this.a * 100) / this.c);
                            a();
                            while (true) {
                                int read = inputStream.read(bArr);
                                this.b = read;
                                if (read == -1) {
                                    break;
                                }
                                Thread.sleep(3L);
                                fileOutputStream3.write(bArr, 0, this.b);
                                this.a += this.b;
                                if (this.a < this.c && (this.a * 100) / this.c > this.d) {
                                    this.d = (int) ((this.a * 100) / this.c);
                                    if (this.d <= 100) {
                                        a();
                                    }
                                }
                            }
                            if (this.a == this.c) {
                                a(str);
                            }
                            fileOutputStream3.flush();
                            fileOutputStream3.close();
                            if (fileOutputStream3 != null) {
                                try {
                                    fileOutputStream3.close();
                                } catch (IOException e2) {
                                }
                            }
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            if (httpURLConnection != null) {
                                httpURLConnection.disconnect();
                            }
                            this.m.a(this.h);
                        } catch (FileNotFoundException e3) {
                            fileOutputStream2 = fileOutputStream3;
                            httpURLConnection2 = httpURLConnection;
                            inputStream2 = inputStream;
                            if (fileOutputStream2 != null) {
                                try {
                                    fileOutputStream2.close();
                                } catch (IOException e4) {
                                    this.m.a(this.h);
                                }
                            }
                            if (inputStream2 != null) {
                                inputStream2.close();
                            }
                            if (httpURLConnection2 != null) {
                                httpURLConnection2.disconnect();
                            }
                            this.m.a(this.h);
                        } catch (Throwable th) {
                            fileOutputStream = fileOutputStream3;
                            r1 = httpURLConnection;
                            th = th;
                            if (fileOutputStream != null) {
                                try {
                                    fileOutputStream.close();
                                } catch (IOException e5) {
                                    this.m.a(this.h);
                                    throw th;
                                }
                            }
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            if (r1 != 0) {
                                r1.disconnect();
                            }
                            this.m.a(this.h);
                            throw th;
                        }
                    } catch (FileNotFoundException e6) {
                        fileOutputStream2 = null;
                        httpURLConnection2 = httpURLConnection;
                        inputStream2 = inputStream;
                    } catch (Throwable th2) {
                        fileOutputStream = null;
                        r1 = httpURLConnection;
                        th = th2;
                    }
                } catch (IOException e7) {
                    if (0 != 0) {
                        try {
                            r1.close();
                        } catch (IOException e8) {
                            this.m.a(this.h);
                        }
                    }
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                    this.m.a(this.h);
                } catch (InterruptedException e9) {
                    if (0 != 0) {
                        try {
                            r1.close();
                        } catch (IOException e10) {
                            this.m.a(this.h);
                        }
                    }
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                    this.m.a(this.h);
                } catch (Exception e11) {
                    if (0 != 0) {
                        try {
                            r1.close();
                        } catch (IOException e12) {
                            this.m.a(this.h);
                        }
                    }
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                    this.m.a(this.h);
                }
            } catch (FileNotFoundException e13) {
                fileOutputStream2 = null;
                inputStream2 = null;
                httpURLConnection2 = httpURLConnection;
            } catch (IOException e14) {
                inputStream = null;
            } catch (InterruptedException e15) {
                inputStream = null;
            } catch (Exception e16) {
                inputStream = null;
            } catch (Throwable th3) {
                fileOutputStream = null;
                r1 = httpURLConnection;
                th = th3;
                inputStream = null;
            }
        } catch (FileNotFoundException e17) {
            inputStream2 = null;
            fileOutputStream2 = null;
        } catch (IOException e18) {
            inputStream = null;
            httpURLConnection = null;
        } catch (InterruptedException e19) {
            inputStream = null;
            httpURLConnection = null;
        } catch (Exception e20) {
            inputStream = null;
            httpURLConnection = null;
        } catch (Throwable th4) {
            th = th4;
            inputStream = null;
            fileOutputStream = null;
        }
    }
}
