package com.baoyi.audio.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import com.baoyi.audio.MusicListUI;
import com.baoyi.audio.RecommendListUI;
import com.baoyi.audio.widget.MainItem;
import com.hope.leyuan.R;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class ButtonsAdapter extends BaseAdapter implements AdapterView.OnItemClickListener {
    List<MainItem> bts = new ArrayList();
    Activity curactivity;

    public ButtonsAdapter(Activity activity) {
        this.curactivity = activity;
        MainItem zt = new MainItem(this.curactivity);
        zt.setType(-1);
        zt.setText("主题铃声");
        zt.setImageResource(R.drawable.zt);
        this.bts.add(zt);
        MainItem lx = new MainItem(this.curactivity);
        lx.setType(1);
        lx.setText("流行铃声");
        lx.setImageResource(R.drawable.lx);
        this.bts.add(lx);
        MainItem ys = new MainItem(this.curactivity);
        ys.setText("影视广告");
        ys.setType(6);
        ys.setImageResource(R.drawable.ys);
        this.bts.add(ys);
        MainItem jr = new MainItem(this.curactivity);
        jr.setType(11);
        jr.setText("节日铃声");
        jr.setImageResource(R.drawable.yx);
        this.bts.add(jr);
        MainItem dm = new MainItem(this.curactivity);
        dm.setType(4);
        dm.setText("动漫游戏");
        dm.setImageResource(R.drawable.dm);
        this.bts.add(dm);
        MainItem zx = new MainItem(this.curactivity);
        zx.setType(10);
        zx.setText("天真童声");
        zx.setImageResource(R.drawable.tz);
        this.bts.add(zx);
        MainItem gg = new MainItem(this.curactivity);
        gg.setType(2);
        gg.setText("搞怪另类");
        gg.setImageResource(R.drawable.gg);
        this.bts.add(gg);
        MainItem dj = new MainItem(this.curactivity);
        dj.setType(5);
        dj.setText("dj舞曲");
        dj.setImageResource(R.drawable.dj);
        this.bts.add(dj);
        MainItem wy = new MainItem(this.curactivity);
        wy.setType(3);
        wy.setText("短信信息");
        wy.setImageResource(R.drawable.dx);
        this.bts.add(wy);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.bts.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return 0L;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = this.bts.get(position);
        int i = position % 2;
        return v;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        MainItem bt = (MainItem) arg1;
        Animation animation = AnimationUtils.loadAnimation(this.curactivity, R.anim.showanimationitem);
        arg1.setAnimation(animation);
        if (bt.getType() < 0) {
            Intent intent1 = new Intent(this.curactivity, (Class<?>) RecommendListUI.class);
            this.curactivity.startActivity(intent1);
        } else {
            Intent intent = new Intent(this.curactivity, (Class<?>) MusicListUI.class);
            intent.putExtra("type", bt.getType());
            this.curactivity.startActivityForResult(intent, 0);
        }
    }
}
