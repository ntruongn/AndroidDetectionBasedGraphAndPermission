package com.feiwoone.banner;

import android.content.Context;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
final class p implements Runnable {
    private /* synthetic */ AdReceiver a;
    private final /* synthetic */ Context b;
    private final /* synthetic */ String c;
    private final /* synthetic */ String d;
    private final /* synthetic */ JSONObject e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(AdReceiver adReceiver, Context context, String str, String str2, JSONObject jSONObject) {
        this.a = adReceiver;
        this.b = context;
        this.c = str;
        this.d = str2;
        this.e = jSONObject;
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.feiwoone.banner.f.e.a(this.b, this.c, "12345678");
        com.feiwoone.banner.e.m a = com.feiwoone.banner.e.m.a();
        com.feiwoone.banner.e.o oVar = new com.feiwoone.banner.e.o();
        oVar.a(this.b, com.feiwoone.banner.f.b.d(), this.d, this.e.toString());
        oVar.a(new q(this, this.b, this.e));
        a.a(oVar);
        this.a.a.removeCallbacks(this);
    }
}
