package com.baoyi.download;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public interface DownloadProvider {
    void downloadCompleted(DownloadJob downloadJob);

    ArrayList<DownloadJob> getAllDownloads();

    ArrayList<DownloadJob> getCompletedDownloads();

    ArrayList<DownloadJob> getQueuedDownloads();

    boolean queueDownload(DownloadJob downloadJob);

    void removeDownload(DownloadJob downloadJob);
}
