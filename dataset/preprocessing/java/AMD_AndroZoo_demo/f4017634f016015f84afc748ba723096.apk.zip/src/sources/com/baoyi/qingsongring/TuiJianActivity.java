package com.baoyi.qingsongring;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import com.baoyi.audio.AnalyticsUI;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.task.RecommendTask;
import com.hope.leyuan.R;
import com.iring.entity.RingRecommend;
import com.iring.rpc.RpcSerializable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class TuiJianActivity extends AnalyticsUI {
    private EditText editText;
    String message;
    private int musicid;
    private String name;
    private String url;

    @Override // com.baoyi.audio.AnalyticsUI, com.baoyi.audio.BugActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tui_jian);
        Intent itent = getIntent();
        try {
            this.name = itent.getExtras().getString(UpdateService.NAME);
            this.url = itent.getExtras().getString("fileurl");
            this.musicid = itent.getExtras().getInt("musicid", -1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.editText = (EditText) findViewById(R.id.editText);
    }

    public void work(View v) {
        this.message = this.editText.getText().toString();
        if (this.message != null) {
            if (this.message.length() < 3) {
                this.editText.setError("亲，你输入的内容太短了，请输入3个字以上。");
                return;
            } else {
                tuiring();
                return;
            }
        }
        this.editText.setError("请输入推荐心情");
    }

    private void tuiring() {
        RingRecommend ringRecommend = new RingRecommend();
        ringRecommend.setAddtime(System.currentTimeMillis());
        ringRecommend.setCatalog(4);
        ringRecommend.setCatalogname("推荐");
        ringRecommend.setMusicname(this.name);
        ringRecommend.setMusicid(this.musicid);
        ringRecommend.setMusicpath(this.url);
        ringRecommend.setComments(this.message);
        ringRecommend.setMemberid(getUserid());
        ringRecommend.setMembername(getMemberName());
        ringRecommend.setMemberpicture(getminipicture());
        new RecommendTask(ringRecommend, this).execute(new RpcSerializable[0]);
        finish();
    }
}
