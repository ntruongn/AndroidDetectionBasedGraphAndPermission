package com.baoyi.audio.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import com.baoyi.audio.SearchListUI;
import com.baoyi.audio.service.UpdateService;
import com.baoyi.audio.widget.GoodsItem;
import com.hope.leyuan.R;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class GoodsAdapter extends BaseAdapter implements AdapterView.OnItemClickListener {
    List<GoodsItem> bts = new ArrayList();
    Activity curactivity;

    public GoodsAdapter(Activity activity) {
        this.curactivity = activity;
        GoodsItem temp = new GoodsItem(this.curactivity);
        temp.setText("郑源  铃声");
        this.bts.add(temp);
        GoodsItem temp2 = new GoodsItem(this.curactivity);
        temp2.setText("李代沫  铃声");
        this.bts.add(temp2);
        GoodsItem temp3 = new GoodsItem(this.curactivity);
        temp3.setText("刘德华 铃声");
        this.bts.add(temp3);
        GoodsItem temp4 = new GoodsItem(this.curactivity);
        temp4.setText("张学友 铃声");
        this.bts.add(temp4);
        GoodsItem temp5 = new GoodsItem(this.curactivity);
        temp5.setText("许巍 铃声");
        this.bts.add(temp5);
        GoodsItem temp6 = new GoodsItem(this.curactivity);
        temp6.setText("凤凰传奇  铃声");
        this.bts.add(temp6);
        GoodsItem temp7 = new GoodsItem(this.curactivity);
        temp7.setText("Beyond  铃声");
        this.bts.add(temp7);
        GoodsItem temp8 = new GoodsItem(this.curactivity);
        temp8.setText("五月天  铃声");
        this.bts.add(temp8);
        GoodsItem temp9 = new GoodsItem(this.curactivity);
        temp9.setText("冷漠 铃声");
        this.bts.add(temp9);
        GoodsItem temp10 = new GoodsItem(this.curactivity);
        temp10.setText("侃侃 铃声");
        this.bts.add(temp10);
        GoodsItem temp11 = new GoodsItem(this.curactivity);
        temp11.setText("孙燕姿  铃声");
        this.bts.add(temp11);
        GoodsItem temp12 = new GoodsItem(this.curactivity);
        temp12.setText("王麟  铃声");
        this.bts.add(temp12);
        GoodsItem temp13 = new GoodsItem(this.curactivity);
        temp13.setText("林俊杰  铃声");
        this.bts.add(temp13);
        GoodsItem temp14 = new GoodsItem(this.curactivity);
        temp14.setText("光良  铃声");
        this.bts.add(temp14);
        GoodsItem temp15 = new GoodsItem(this.curactivity);
        temp15.setText("陈奕迅  铃声");
        this.bts.add(temp15);
        GoodsItem temp16 = new GoodsItem(this.curactivity);
        temp16.setText("欢子  铃声");
        this.bts.add(temp16);
        GoodsItem temp17 = new GoodsItem(this.curactivity);
        temp17.setText("张杰  铃声");
        this.bts.add(temp17);
        GoodsItem temp18 = new GoodsItem(this.curactivity);
        temp18.setText("王力宏  铃声");
        this.bts.add(temp18);
        GoodsItem temp19 = new GoodsItem(this.curactivity);
        temp19.setText("张国荣   铃声");
        this.bts.add(temp19);
        GoodsItem temp20 = new GoodsItem(this.curactivity);
        temp20.setText("谭咏麟   铃声");
        this.bts.add(temp20);
        GoodsItem temp21 = new GoodsItem(this.curactivity);
        temp21.setText("闫旭   铃声");
        this.bts.add(temp21);
        GoodsItem temp22 = new GoodsItem(this.curactivity);
        temp22.setText("陈小春   铃声");
        this.bts.add(temp22);
        GoodsItem temp23 = new GoodsItem(this.curactivity);
        temp23.setText("张惠妹  铃声");
        this.bts.add(temp23);
        GoodsItem temp24 = new GoodsItem(this.curactivity);
        temp24.setText("范玮琪  铃声");
        this.bts.add(temp24);
        GoodsItem temp25 = new GoodsItem(this.curactivity);
        temp25.setText("周杰伦  铃声");
        this.bts.add(temp25);
        GoodsItem temp26 = new GoodsItem(this.curactivity);
        temp26.setText("苏打绿  铃声");
        this.bts.add(temp26);
        GoodsItem temp27 = new GoodsItem(this.curactivity);
        temp27.setText("周星驰");
        this.bts.add(temp27);
        GoodsItem bd = new GoodsItem(this.curactivity);
        bd.setText("葛优");
        this.bts.add(bd);
        GoodsItem zx = new GoodsItem(this.curactivity);
        GoodsItem temp28 = new GoodsItem(this.curactivity);
        temp28.setText("海贼王");
        this.bts.add(temp28);
        zx.setText("蜡笔小新");
        this.bts.add(zx);
        GoodsItem gg = new GoodsItem(this.curactivity);
        gg.setText("麦兜");
        this.bts.add(gg);
        GoodsItem lx = new GoodsItem(this.curactivity);
        lx.setText("宝宝");
        this.bts.add(lx);
        GoodsItem wy = new GoodsItem(this.curactivity);
        wy.setText("彪哥");
        this.bts.add(wy);
        GoodsItem ys = new GoodsItem(this.curactivity);
        ys.setText("机主");
        this.bts.add(ys);
        GoodsItem dm = new GoodsItem(this.curactivity);
        dm.setText("非主流");
        this.bts.add(dm);
        GoodsItem dj = new GoodsItem(this.curactivity);
        dj.setText("钢琴");
        this.bts.add(dj);
        GoodsItem temp29 = new GoodsItem(this.curactivity);
        temp29.setText("卡农");
        this.bts.add(temp29);
        Random random = new Random();
        int index = random.nextInt(5);
        GoodsItem bt = this.bts.get(index);
        Animation animation = AnimationUtils.loadAnimation(this.curactivity, R.anim.showanimation);
        bt.setAnimation(animation);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.bts.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return 0L;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        View b = this.bts.get(position);
        int i = position % 2;
        return b;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        GoodsItem bt = (GoodsItem) arg1;
        Animation animation = AnimationUtils.loadAnimation(this.curactivity, R.anim.showanimationitem);
        arg1.setAnimation(animation);
        Intent intent = new Intent(this.curactivity, (Class<?>) SearchListUI.class);
        intent.putExtra(UpdateService.NAME, bt.getName());
        this.curactivity.startActivityForResult(intent, 0);
    }
}
