package com.baoyi.audio.widget;

import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.Scroller;
import java.util.LinkedList;
import java.util.Queue;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class HorizontalListView extends AdapterView<ListAdapter> {
    private View childSelected;
    private boolean getEvent;
    private boolean isMove;
    protected ListAdapter mAdapter;
    public boolean mAlwaysOverrideTouch;
    protected int mCurrentX;
    private boolean mDataChanged;
    private DataSetObserver mDataObserver;
    private int mDisplayOffset;
    private GestureDetector mGesture;
    private int mLeftViewIndex;
    private int mMaxX;
    protected int mNextX;
    private GestureDetector.OnGestureListener mOnGesture;
    private AdapterView.OnItemClickListener mOnItemClicked;
    private AdapterView.OnItemLongClickListener mOnItemLongClickListener;
    private View.OnTouchListener mOnItemMoveListener;
    private View.OnTouchListener mOnItemOutListener;
    private AdapterView.OnItemSelectedListener mOnItemSelected;
    private Queue<View> mRemovedViewQueue;
    private int mRightViewIndex;
    protected Scroller mScroller;
    private boolean onMove;
    private boolean receive;

    public HorizontalListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.onMove = false;
        this.mAlwaysOverrideTouch = true;
        this.mLeftViewIndex = -1;
        this.mRightViewIndex = 0;
        this.mMaxX = Integer.MAX_VALUE;
        this.mDisplayOffset = 0;
        this.mRemovedViewQueue = new LinkedList();
        this.isMove = false;
        this.mDataChanged = false;
        this.getEvent = false;
        this.receive = false;
        this.mDataObserver = new DataSetObserver() { // from class: com.baoyi.audio.widget.HorizontalListView.1
            @Override // android.database.DataSetObserver
            public void onChanged() {
                synchronized (HorizontalListView.this) {
                    HorizontalListView.this.mDataChanged = true;
                }
                HorizontalListView.this.invalidate();
                HorizontalListView.this.requestLayout();
            }

            @Override // android.database.DataSetObserver
            public void onInvalidated() {
                HorizontalListView.this.reset();
                HorizontalListView.this.invalidate();
                HorizontalListView.this.requestLayout();
            }
        };
        this.mOnGesture = new GestureDetector.SimpleOnGestureListener() { // from class: com.baoyi.audio.widget.HorizontalListView.2
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onDown(MotionEvent e) {
                return HorizontalListView.this.onDown(e);
            }

            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                return HorizontalListView.this.onFling(e1, e2, velocityX, velocityY);
            }

            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                synchronized (HorizontalListView.this) {
                    HorizontalListView.this.mNextX += (int) distanceX;
                }
                HorizontalListView.this.requestLayout();
                return false;
            }

            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public void onLongPress(MotionEvent e) {
                Rect viewRect = new Rect();
                for (int i = 0; i < HorizontalListView.this.getChildCount(); i++) {
                    View child = HorizontalListView.this.getChildAt(i);
                    int left = child.getLeft();
                    int right = child.getRight();
                    int top = child.getTop();
                    int bottom = child.getBottom();
                    viewRect.set(left, top, right, bottom);
                    if (viewRect.contains((int) e.getX(), (int) e.getY())) {
                        if (HorizontalListView.this.mOnItemLongClickListener != null) {
                            HorizontalListView.this.mOnItemLongClickListener.onItemLongClick(HorizontalListView.this, child, HorizontalListView.this.mLeftViewIndex + 1 + i, HorizontalListView.this.mAdapter.getItemId(HorizontalListView.this.mLeftViewIndex + 1 + i));
                        }
                        if (HorizontalListView.this.mOnItemSelected != null) {
                            HorizontalListView.this.mOnItemSelected.onItemSelected(HorizontalListView.this, child, HorizontalListView.this.mLeftViewIndex + 1 + i, HorizontalListView.this.mAdapter.getItemId(HorizontalListView.this.mLeftViewIndex + 1 + i));
                            return;
                        }
                        return;
                    }
                }
            }

            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnDoubleTapListener
            public boolean onSingleTapConfirmed(MotionEvent e) {
                Rect viewRect = new Rect();
                for (int i = 0; i < HorizontalListView.this.getChildCount(); i++) {
                    View child = HorizontalListView.this.getChildAt(i);
                    int left = child.getLeft();
                    int right = child.getRight();
                    int top = child.getTop();
                    int bottom = child.getBottom();
                    viewRect.set(left, top, right, bottom);
                    if (viewRect.contains((int) e.getX(), (int) e.getY())) {
                        if (HorizontalListView.this.mOnItemClicked != null) {
                            HorizontalListView.this.mOnItemClicked.onItemClick(HorizontalListView.this, child, HorizontalListView.this.mLeftViewIndex + 1 + i, HorizontalListView.this.mAdapter.getItemId(HorizontalListView.this.mLeftViewIndex + 1 + i));
                        }
                        if (HorizontalListView.this.mOnItemSelected != null) {
                            HorizontalListView.this.mOnItemSelected.onItemSelected(HorizontalListView.this, child, HorizontalListView.this.mLeftViewIndex + 1 + i, HorizontalListView.this.mAdapter.getItemId(HorizontalListView.this.mLeftViewIndex + 1 + i));
                            return true;
                        }
                        return true;
                    }
                }
                return true;
            }
        };
        initView();
    }

    private synchronized void initView() {
        this.mLeftViewIndex = -1;
        this.mRightViewIndex = 0;
        this.mDisplayOffset = 0;
        this.mCurrentX = 0;
        this.mNextX = 0;
        this.mMaxX = Integer.MAX_VALUE;
        this.mScroller = new Scroller(getContext());
        this.mGesture = new GestureDetector(getContext(), this.mOnGesture);
    }

    @Override // android.widget.AdapterView
    public void setOnItemSelectedListener(AdapterView.OnItemSelectedListener listener) {
        this.mOnItemSelected = listener;
    }

    @Override // android.widget.AdapterView
    public void setOnItemClickListener(AdapterView.OnItemClickListener listener) {
        this.mOnItemClicked = listener;
    }

    @Override // android.widget.AdapterView
    public void setOnItemLongClickListener(AdapterView.OnItemLongClickListener listener) {
        this.mOnItemLongClickListener = listener;
    }

    public void setOnItemMoveListener(View.OnTouchListener listener) {
        this.mOnItemMoveListener = listener;
    }

    public void setOnItemOutListener(View.OnTouchListener listener) {
        this.mOnItemOutListener = listener;
    }

    @Override // android.widget.AdapterView
    public ListAdapter getAdapter() {
        return this.mAdapter;
    }

    @Override // android.widget.AdapterView
    public View getSelectedView() {
        return null;
    }

    @Override // android.widget.AdapterView
    public void setAdapter(ListAdapter adapter) {
        if (this.mAdapter != null) {
            this.mAdapter.unregisterDataSetObserver(this.mDataObserver);
        }
        this.mAdapter = adapter;
        this.mAdapter.registerDataSetObserver(this.mDataObserver);
        reset();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void reset() {
        initView();
        removeAllViewsInLayout();
        requestLayout();
    }

    @Override // android.widget.AdapterView
    public void setSelection(int position) {
    }

    private void addAndMeasureChild(View child, int viewPos) {
        ViewGroup.LayoutParams params = child.getLayoutParams();
        if (params == null) {
            params = new ViewGroup.LayoutParams(-1, -1);
        }
        addViewInLayout(child, viewPos, params, true);
        child.measure(View.MeasureSpec.makeMeasureSpec(getWidth(), Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec(getHeight(), Integer.MIN_VALUE));
    }

    @Override // android.widget.AdapterView, android.view.ViewGroup, android.view.View
    protected synchronized void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (this.mAdapter != null) {
            if (this.mDataChanged) {
                int oldCurrentX = this.mCurrentX;
                initView();
                removeAllViewsInLayout();
                this.mNextX = oldCurrentX;
                this.mDataChanged = false;
            }
            if (this.mScroller.computeScrollOffset()) {
                int scrollx = this.mScroller.getCurrX();
                this.mNextX = scrollx;
            }
            if (this.mNextX < 0) {
                this.mNextX = 0;
                this.mScroller.forceFinished(true);
            }
            if (this.mNextX > this.mMaxX) {
                this.mNextX = this.mMaxX;
                this.mScroller.forceFinished(true);
            }
            int dx = this.mCurrentX - this.mNextX;
            removeNonVisibleItems(dx);
            fillList(dx);
            positionItems(dx);
            this.mCurrentX = this.mNextX;
            if (!this.mScroller.isFinished()) {
                post(new Runnable() { // from class: com.baoyi.audio.widget.HorizontalListView.3
                    @Override // java.lang.Runnable
                    public void run() {
                        HorizontalListView.this.requestLayout();
                    }
                });
            }
        }
    }

    private void fillList(int dx) {
        int edge = 0;
        View child = getChildAt(getChildCount() - 1);
        if (child != null) {
            edge = child.getRight();
        }
        fillListRight(edge, dx);
        int edge2 = 0;
        View child2 = getChildAt(0);
        if (child2 != null) {
            edge2 = child2.getLeft();
        }
        fillListLeft(edge2, dx);
    }

    private void fillListRight(int rightEdge, int dx) {
        while (rightEdge + dx < getWidth() && this.mRightViewIndex < this.mAdapter.getCount()) {
            View child = this.mAdapter.getView(this.mRightViewIndex, this.mRemovedViewQueue.poll(), this);
            addAndMeasureChild(child, -1);
            rightEdge += child.getMeasuredWidth();
            if (this.mRightViewIndex == this.mAdapter.getCount() - 1) {
                this.mMaxX = (this.mCurrentX + rightEdge) - getWidth();
            }
            this.mRightViewIndex++;
        }
    }

    private void fillListLeft(int leftEdge, int dx) {
        while (leftEdge + dx > 0 && this.mLeftViewIndex >= 0) {
            View child = this.mAdapter.getView(this.mLeftViewIndex, this.mRemovedViewQueue.poll(), this);
            addAndMeasureChild(child, 0);
            leftEdge -= child.getMeasuredWidth();
            this.mLeftViewIndex--;
            this.mDisplayOffset -= child.getMeasuredWidth();
        }
    }

    private void removeNonVisibleItems(int dx) {
        View child = getChildAt(0);
        while (child != null && child.getRight() + dx <= 0) {
            this.mDisplayOffset += child.getMeasuredWidth();
            this.mRemovedViewQueue.offer(child);
            removeViewInLayout(child);
            this.mLeftViewIndex++;
            child = getChildAt(0);
        }
        View child2 = getChildAt(getChildCount() - 1);
        while (child2 != null && child2.getLeft() + dx >= getWidth()) {
            this.mRemovedViewQueue.offer(child2);
            removeViewInLayout(child2);
            this.mRightViewIndex--;
            child2 = getChildAt(getChildCount() - 1);
        }
    }

    private void positionItems(int dx) {
        if (getChildCount() > 0) {
            this.mDisplayOffset += dx;
            int left = this.mDisplayOffset;
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                int childWidth = child.getMeasuredWidth();
                child.layout(left, 0, left + childWidth, child.getMeasuredHeight());
                left += childWidth;
            }
        }
    }

    public synchronized void scrollTo(int x) {
        this.mScroller.startScroll(this.mNextX, 0, x - this.mNextX, 0);
        requestLayout();
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (this.onMove) {
            onTestMove(ev);
        }
        if (this.getEvent) {
            boolean handled = this.mOnItemMoveListener.onTouch(getEmptyView(), ev);
            return handled;
        }
        boolean handled2 = this.mGesture.onTouchEvent(ev);
        return handled2;
    }

    public void setGetEvent(boolean getEvent) {
        this.getEvent = getEvent;
    }

    public void setReceive(boolean receive) {
        this.receive = receive;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent ev) {
        if (this.receive) {
            onTestReceive(ev);
            return false;
        }
        return false;
    }

    protected boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        synchronized (this) {
            this.mScroller.fling(this.mNextX, 0, (int) (-velocityX), 0, 0, this.mMaxX, 0, 0);
        }
        requestLayout();
        return true;
    }

    protected boolean onDown(MotionEvent e) {
        this.isMove = false;
        this.mScroller.forceFinished(true);
        return true;
    }

    public boolean onTestMove(MotionEvent event) {
        float xInit = event.getHistoricalX(0);
        float yInit = event.getHistoricalY(0);
        float xNow = event.getX();
        float yNow = event.getY();
        Rect viewRect = new Rect();
        if (!this.isMove) {
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                int left = child.getLeft();
                int right = child.getRight();
                int top = child.getTop();
                int bottom = child.getBottom();
                viewRect.set(left, top, right, bottom);
                if (viewRect.contains((int) xInit, (int) yInit) && yNow > yInit) {
                    Log.d("relache", "pass\u008e in ");
                    if (this.mOnItemMoveListener != null) {
                        this.mOnItemMoveListener.onTouch(child, event);
                        this.childSelected = child;
                    }
                    if (this.mOnItemClicked != null) {
                        this.mOnItemClicked.onItemClick(this, child, this.mLeftViewIndex + 1 + i, this.mAdapter.getItemId(this.mLeftViewIndex + 1 + i));
                    }
                    this.isMove = true;
                    return true;
                }
            }
            return false;
        }
        this.mOnItemMoveListener.onTouch(this.childSelected, event);
        if (event.getAction() == 1) {
            int left2 = getLeft();
            int right2 = getRight();
            int top2 = getTop();
            int bottom2 = getBottom();
            Rect rect = new Rect(left2, top2, right2, bottom2);
            if (!rect.contains((int) xNow, (int) yNow) && this.mOnItemOutListener != null) {
                this.mOnItemOutListener.onTouch(this.childSelected, event);
            }
            this.isMove = false;
            return false;
        }
        return true;
    }

    public boolean onTestReceive(MotionEvent e) {
        if (e.getAction() == 1) {
            Rect viewRect = new Rect();
            int i = 0;
            while (true) {
                if (i >= getChildCount()) {
                    break;
                }
                View child = getChildAt(i);
                int left = child.getLeft();
                int right = child.getRight();
                int top = child.getTop() + getTop();
                int bottom = child.getBottom() + getBottom();
                int x = (int) e.getX();
                int y = (int) e.getY();
                viewRect.set(left, top, right, bottom);
                if (!viewRect.contains(x, y)) {
                    i++;
                } else {
                    if (this.mOnItemClicked != null) {
                        this.mOnItemClicked.onItemClick(this, child, this.mLeftViewIndex + 1 + i, this.mAdapter.getItemId(this.mLeftViewIndex + 1 + i));
                    }
                    if (this.mOnItemSelected != null) {
                        this.mOnItemSelected.onItemSelected(this, child, this.mLeftViewIndex + 1 + i, this.mAdapter.getItemId(this.mLeftViewIndex + 1 + i));
                    }
                }
            }
            return true;
        }
        return false;
    }

    public void setOnMove(Boolean onMoveListener) {
        this.onMove = true;
    }
}
