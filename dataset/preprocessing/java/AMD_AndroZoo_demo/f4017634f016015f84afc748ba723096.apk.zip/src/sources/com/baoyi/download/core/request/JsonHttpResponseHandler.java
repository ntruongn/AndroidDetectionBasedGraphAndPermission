package com.baoyi.download.core.request;

import com.baoyi.download.core.network.ZLNetworkException;
import com.baoyi.download.core.network.ZLNetworkRequest;
import com.baoyi.download.core.util.DataUtil;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class JsonHttpResponseHandler extends ZLNetworkRequest {
    String body;
    private String charset;

    protected JsonHttpResponseHandler(String url) {
        super(url);
    }

    public void onSuccess(JSONObject response) {
    }

    public void onSuccess(JSONArray response) {
    }

    protected void handleSuccessMessage(String responseBody) {
        try {
            Object jsonResponse = parseResponse(responseBody);
            if (jsonResponse instanceof JSONObject) {
                onSuccess((JSONObject) jsonResponse);
            } else if (jsonResponse instanceof JSONArray) {
                onSuccess((JSONArray) jsonResponse);
            }
        } catch (JSONException e) {
            onFailure(e, responseBody);
        }
    }

    private void onFailure(JSONException e, String responseBody) {
    }

    protected Object parseResponse(String responseBody) throws JSONException {
        return new JSONTokener(responseBody).nextValue();
    }

    @Override // com.baoyi.download.core.network.ZLNetworkRequest
    public void handleStream(InputStream inputStream, int length) throws IOException, ZLNetworkException {
        ByteBuffer byteBuffer = DataUtil.readToByteBuffer(inputStream);
        if (this.charset == null) {
            this.body = Charset.forName("UTF-8").decode(byteBuffer).toString();
        } else {
            this.body = Charset.forName(this.charset).decode(byteBuffer).toString();
        }
        byteBuffer.rewind();
    }
}
