package com.baoyi.audio.service;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class UpdateService extends IntentService {
    public static final String ARTIST = "artist";
    public static final String FILENAME = "filename";
    public static final String NAME = "name";
    public static final String USERID = "userid";

    public UpdateService() {
        super("UpdateService");
    }

    @Override // android.app.IntentService
    protected void onHandleIntent(Intent intent) {
        String photoPath = intent.getExtras().getString(FILENAME);
        String userid = intent.getExtras().getString(USERID);
        String name = intent.getExtras().getString(NAME);
        String artist = intent.getExtras().getString(NAME);
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost("");
        try {
            File aFile = new File(photoPath);
            FileBody file = new FileBody(aFile);
            MultipartEntity reqEntity = new MultipartEntity();
            reqEntity.addPart("file", file);
            reqEntity.addPart(USERID, new StringBody(userid, Charset.forName("utf-8")));
            reqEntity.addPart(NAME, new StringBody(name, Charset.forName("utf-8")));
            reqEntity.addPart(ARTIST, new StringBody(artist, Charset.forName("utf-8")));
            httppost.setEntity(reqEntity);
            HttpResponse response = defaultHttpClient.execute(httppost);
            if (200 == response.getStatusLine().getStatusCode()) {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    System.out.println(EntityUtils.toString(entity));
                }
                if (entity != null) {
                    entity.consumeContent();
                }
            }
        } catch (IOException e) {
            Log.e("exception", e.toString());
        } catch (UnsupportedEncodingException e2) {
            Log.e("exception", e2.toString());
        } catch (ClientProtocolException e3) {
            Log.e("exception", e3.toString());
        } finally {
            defaultHttpClient.getConnectionManager().shutdown();
        }
    }
}
