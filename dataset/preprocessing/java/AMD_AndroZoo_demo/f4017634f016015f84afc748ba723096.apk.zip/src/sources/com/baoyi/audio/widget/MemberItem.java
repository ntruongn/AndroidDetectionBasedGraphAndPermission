package com.baoyi.audio.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.hope.leyuan.R;
import com.iring.entity.Member;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MemberItem extends LinearLayout {
    Context curactivity;
    private ImageView headimg;
    private Member member;
    private TextView memberName;
    private TextView member_messages;

    public Member getMember() {
        return this.member;
    }

    public void setMember(Member member) {
        this.member = member;
        this.headimg.setBackgroundResource(R.drawable.foot_touxiang);
        if (member != null) {
            this.memberName.setText(member.getNickname());
            this.member_messages.setText(member.getMessages());
        }
    }

    public MemberItem(Context context) {
        super(context);
        this.curactivity = context;
        LayoutInflater.from(getContext()).inflate(R.layout.widget_member, this);
        this.headimg = (ImageView) findViewById(R.id.headimg);
        this.memberName = (TextView) findViewById(R.id.member_name);
        this.member_messages = (TextView) findViewById(R.id.member_messages);
    }
}
