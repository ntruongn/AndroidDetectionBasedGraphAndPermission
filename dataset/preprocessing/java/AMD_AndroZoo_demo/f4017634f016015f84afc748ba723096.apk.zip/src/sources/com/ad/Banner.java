package com.ad;

import android.app.Activity;
import android.widget.RelativeLayout;
import com.feiwoone.banner.AdBanner;
import com.feiwoone.banner.RecevieAdListener;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class Banner {
    public static String appKey = Ad_ID.anzhi_banner;
    private static AdBanner myAdView;
    private static RelativeLayout myAdonContainerView;

    public static void banner_AD(Activity activity) {
        myAdonContainerView = (RelativeLayout) activity.findViewById(R.id.adonContainerView);
        myAdView = new AdBanner(activity);
        myAdonContainerView.addView(myAdView);
        myAdView.setAppKey(appKey);
        new RecevieAdListener() { // from class: com.ad.Banner.1
            @Override // com.feiwoone.banner.RecevieAdListener
            public void onSucessedRecevieAd(AdBanner adView) {
                Banner.myAdonContainerView.setVisibility(0);
            }

            @Override // com.feiwoone.banner.RecevieAdListener
            public void onFailedToRecevieAd(AdBanner adView) {
                Banner.myAdonContainerView.setVisibility(8);
            }
        };
    }
}
