package com.baoyi.db;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import com.iring.entity.Message;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MessageShowManager {
    private SQLiteDatabase db;
    private DBhelper dbHelper;

    public MessageShowManager(Context context) {
        this.dbHelper = new DBhelper(context);
    }

    public void addMessage(List<Message> msgs) {
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        if (msgs != null) {
            try {
                for (Message message : msgs) {
                    if (message != null) {
                        this.db.execSQL("insert into MESSAGE values(?,?,?,?)", new Object[]{Integer.valueOf(message.getId()), Integer.valueOf(message.getShot()), message.getAuthor(), message.getMessage()});
                    }
                }
                this.db.setTransactionSuccessful();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                this.db.endTransaction();
                this.db.close();
            }
        }
    }

    public int getNum() {
        int id = 0;
        this.db = this.dbHelper.getReadableDatabase();
        Cursor cursor = this.db.rawQuery("select id from MESSAGE ORDER BY id desc", null);
        if (cursor.moveToFirst()) {
            id = cursor.getInt(cursor.getColumnIndex("id"));
        }
        cursor.close();
        this.db.close();
        return id;
    }

    public Message getMessage(int id) {
        this.db = this.dbHelper.getReadableDatabase();
        Cursor cursor = this.db.rawQuery("select * from MESSAGE where id=?", new String[]{new StringBuilder(String.valueOf(id)).toString()});
        if (cursor.moveToFirst()) {
            int _id = cursor.getInt(cursor.getColumnIndex("id"));
            int _shot = cursor.getInt(cursor.getColumnIndex("id"));
            String _author = cursor.getString(cursor.getColumnIndex("author"));
            String _message = cursor.getString(cursor.getColumnIndex("message"));
            if (_author != null && _message != null) {
                Message msg = new Message(_id, _shot, _author, _message);
                cursor.close();
                this.db.close();
                return msg;
            }
        }
        cursor.close();
        this.db.close();
        return null;
    }
}
