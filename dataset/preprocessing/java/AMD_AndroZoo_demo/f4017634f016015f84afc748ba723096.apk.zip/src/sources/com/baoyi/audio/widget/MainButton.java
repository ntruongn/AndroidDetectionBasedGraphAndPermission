package com.baoyi.audio.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MainButton extends LinearLayout {
    private ImageView bf;
    Context curactivity;
    private TextView text;
    private int type;

    public int getType() {
        return this.type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public void setText(String type) {
        this.text.setText(type);
    }

    public void setImageResource(int resId) {
        this.bf.setImageResource(resId);
    }

    public void setBGImageResource(int resId) {
        setBackgroundResource(resId);
    }

    public MainButton(Context context) {
        super(context);
        this.curactivity = context;
        LayoutInflater.from(getContext()).inflate(R.layout.widget_main_button, this);
        this.bf = (ImageView) findViewById(R.id.bf);
    }
}
