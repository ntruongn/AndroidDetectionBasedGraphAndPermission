package com.baoyi.audio.widget;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.baoyi.doamin.KoWoMusic;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class SearchWidget extends LinearLayout {
    private ImageView bf;
    Context curactivity;
    private TextView text;
    KoWoMusic workItem;

    public SearchWidget(Context context) {
        super(context);
    }

    public KoWoMusic getWorkItem() {
        return this.workItem;
    }

    public void setWorkItem(KoWoMusic workItem) {
        this.workItem = workItem;
    }

    public SearchWidget(Context context, KoWoMusic v) {
        super(context);
        this.curactivity = context;
        LayoutInflater.from(getContext()).inflate(R.layout.widget_search_item, this);
        this.bf = (ImageView) findViewById(R.id.bf);
        this.text = (TextView) findViewById(R.id.textView1);
        this.text.setText(v.getName());
        this.workItem = v;
    }
}
