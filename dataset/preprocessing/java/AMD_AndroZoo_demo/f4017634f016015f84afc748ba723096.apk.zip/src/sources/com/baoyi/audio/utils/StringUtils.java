package com.baoyi.audio.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class StringUtils {
    private static final Pattern emailer = Pattern.compile("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");
    private static final SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static final SimpleDateFormat dateFormater2 = new SimpleDateFormat("yyyy-MM-dd");

    public static Date toDate(String sdate) {
        try {
            return dateFormater.parse(sdate);
        } catch (ParseException e) {
            return null;
        }
    }

    public static String friendly_time(String sdate) {
        Date time = toDate(sdate);
        if (time == null) {
            return "Unknown";
        }
        Calendar cal = Calendar.getInstance();
        String curDate = dateFormater2.format(cal.getTime());
        String paramDate = dateFormater2.format(time);
        if (curDate.equals(paramDate)) {
            int hour = (int) ((cal.getTimeInMillis() - time.getTime()) / 3600000);
            if (hour == 0) {
                String ftime = String.valueOf(Math.max((cal.getTimeInMillis() - time.getTime()) / 60000, 1L)) + "分钟前";
                return ftime;
            }
            String ftime2 = String.valueOf(hour) + "小时前";
            return ftime2;
        }
        long lt = time.getTime() / 86400000;
        long ct = cal.getTimeInMillis() / 86400000;
        int days = (int) (ct - lt);
        if (days == 0) {
            int hour2 = (int) ((cal.getTimeInMillis() - time.getTime()) / 3600000);
            if (hour2 == 0) {
                String ftime3 = String.valueOf(Math.max((cal.getTimeInMillis() - time.getTime()) / 60000, 1L)) + "分钟前";
                return ftime3;
            }
            String ftime4 = String.valueOf(hour2) + "小时前";
            return ftime4;
        }
        if (days == 1) {
            return "昨天";
        }
        if (days == 2) {
            return "前天";
        }
        if (days > 2 && days <= 10) {
            String ftime5 = String.valueOf(days) + "天前";
            return ftime5;
        }
        if (days <= 10) {
            return "";
        }
        String ftime6 = dateFormater2.format(time);
        return ftime6;
    }

    public static boolean isToday(String sdate) {
        Date time = toDate(sdate);
        Date today = new Date();
        if (time == null) {
            return false;
        }
        String nowDate = dateFormater2.format(today);
        String timeDate = dateFormater2.format(time);
        if (!nowDate.equals(timeDate)) {
            return false;
        }
        return true;
    }

    public static boolean isEmpty(String input) {
        if (input == null || "".equals(input)) {
            return true;
        }
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c != ' ' && c != '\t' && c != '\r' && c != '\n') {
                return false;
            }
        }
        return true;
    }

    public static boolean isEmail(String email) {
        if (email == null || email.trim().length() == 0) {
            return false;
        }
        return emailer.matcher(email).matches();
    }

    public static int toInt(String str, int defValue) {
        try {
            int defValue2 = Integer.parseInt(str);
            return defValue2;
        } catch (Exception e) {
            return defValue;
        }
    }

    public static int toInt(Object obj) {
        if (obj == null) {
            return 0;
        }
        return toInt(obj.toString(), 0);
    }

    public static long toLong(String obj) {
        try {
            return Long.parseLong(obj);
        } catch (Exception e) {
            return 0L;
        }
    }

    public static boolean toBool(String b) {
        try {
            return Boolean.parseBoolean(b);
        } catch (Exception e) {
            return false;
        }
    }
}
