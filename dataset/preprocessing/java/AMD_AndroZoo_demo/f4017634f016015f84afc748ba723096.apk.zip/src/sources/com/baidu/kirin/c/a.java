package com.baidu.kirin.c;

import android.content.Context;
import com.baidu.kirin.KirinConfig;
import com.baidu.kirin.d.d;
import com.baidu.mobstat.CooperService;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class a {
    protected Context a;
    protected String b;
    protected String c;
    protected JSONObject d;
    protected JSONObject e;
    protected boolean f;
    private int g = -1;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(Context context, String str) {
        this.a = context;
        this.b = KirinConfig.PREURL + str;
        d.a("PostUrl: " + this.b);
        this.d = new JSONObject();
        try {
            this.d.put("appkey", com.baidu.kirin.a.a.b(this.a));
            this.d.put("version_code", com.baidu.kirin.a.a.d(this.a));
            this.d.put("version_name", com.baidu.kirin.a.a.c(this.a));
            this.d.put("deviceid", com.baidu.kirin.a.a.h(context));
            this.d.put("channel", com.baidu.kirin.a.a.a(context));
            this.d.put("sdk_version", CooperService.getMTJSDKVersion());
            this.d.put("sdk_tag", "mtj");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        b();
    }

    public JSONObject a() {
        return this.d;
    }

    public void a(String str, Object obj) {
        try {
            this.d.put(str, obj);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    protected void b() {
    }

    /* JADX WARN: Removed duplicated region for block: B:6:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x00ff  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public org.json.JSONObject c() {
        /*
            Method dump skipped, instructions count: 264
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.baidu.kirin.c.a.c():org.json.JSONObject");
    }

    public int d() {
        return this.g;
    }

    protected void e() {
    }

    protected void f() {
    }
}
