package com.feiwothree.coverscreen.a;

import com.baoyi.audio.service.UpdateService;
import java.io.Serializable;
import org.json.JSONObject;

/* renamed from: com.feiwothree.coverscreen.a.j, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class C0014j implements Serializable {
    private int a;
    private int b;
    private String c;
    private String d;
    private String e;
    private String f;
    private String g;
    private String h;
    private String i;
    private String j;
    private String k;
    private String l;
    private String m;
    private String n;
    private String o;
    private String p;

    public static C0014j a(JSONObject jSONObject) {
        if (jSONObject == null) {
            return null;
        }
        C0014j c0014j = new C0014j();
        c0014j.a = jSONObject.optInt("id");
        c0014j.b = jSONObject.optInt("adid", 0);
        c0014j.c = jSONObject.optString("image");
        c0014j.d = jSONObject.optString(UpdateService.NAME);
        c0014j.f = jSONObject.optString("icon");
        c0014j.n = jSONObject.optString("coverDownloadConfirm", "true");
        c0014j.o = jSONObject.optString("notifiKeep", "true");
        c0014j.p = jSONObject.optString("gprsDown", "true");
        c0014j.e = jSONObject.optString("clickType");
        c0014j.i = jSONObject.optString("appicon");
        c0014j.j = jSONObject.optString("appname");
        c0014j.k = jSONObject.optString("apppackage");
        c0014j.l = jSONObject.optString("appurl");
        c0014j.m = jSONObject.optString("appsize");
        c0014j.g = jSONObject.optString("wxurl");
        c0014j.h = jSONObject.optString("weburl");
        return c0014j;
    }

    public final int a() {
        return this.b;
    }

    public final String b() {
        return this.c;
    }

    public final String c() {
        return this.d;
    }

    public final String d() {
        return this.j;
    }

    public final String e() {
        return this.k;
    }

    public final String f() {
        return this.l;
    }

    public final String g() {
        return this.g;
    }

    public final String h() {
        return this.e;
    }

    public final String i() {
        return this.h;
    }

    public final String j() {
        return this.f;
    }

    public final String k() {
        return this.i;
    }

    public final String l() {
        return this.m;
    }

    public final int m() {
        return this.a;
    }

    public final String n() {
        return this.n;
    }

    public final String o() {
        return this.o;
    }

    public final String p() {
        return this.p;
    }
}
