package com.baoyi.ring.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;
import com.baoyi.audio.task.ClearCacheTask;
import com.baoyi.audio.utils.RpcUtils;
import com.baoyi.audio.utils.content;
import com.baoyi.ring.questionnaire.Questionnaire;
import com.baoyi.ring.questionnaire.QuestionnaireDao;
import com.hope.leyuan.R;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MoreFragment extends Fragment {
    private String a1;
    private String a2;
    private String a3;
    private String a4;
    private String a5;
    private ImageButton aboutusBtn;
    private LinearLayout ll;
    private LinearLayout ll2;
    private String q1;
    private String q2;
    private String q3;
    private String q4;
    private String q5;
    private QuestionnaireDao qd;
    private ImageButton qingli;
    Questionnaire qq1;
    Questionnaire qq2;
    Questionnaire qq3;
    Questionnaire qq4;
    Questionnaire qq5;
    private RadioButton rb11;
    private RadioButton rb12;
    private RadioButton rb13;
    private RadioButton rb21;
    private RadioButton rb22;
    private RadioButton rb23;
    private RadioButton rb31;
    private RadioButton rb32;
    private RadioButton rb33;
    private RadioButton rb41;
    private RadioButton rb42;
    private RadioButton rb43;
    private RadioButton rb51;
    private RadioButton rb52;
    private RadioButton rb53;
    private ImageButton tijiao;
    private ImageButton wenjuanBtn;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ring_more, container, false);
        return view;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        content.ISKIND = 0;
        this.qd = (QuestionnaireDao) RpcUtils.getDao("questionnaireDao", QuestionnaireDao.class);
        this.ll = (LinearLayout) getView().findViewById(R.id.ring_more_wenjuan);
        this.ll2 = (LinearLayout) getView().findViewById(R.id.ring_more_about);
        this.qingli = (ImageButton) getView().findViewById(R.id.ring_more_qingli);
        this.wenjuanBtn = (ImageButton) getView().findViewById(R.id.ring_more_wenjuanBtn);
        this.aboutusBtn = (ImageButton) getView().findViewById(R.id.ring_more_aboutusBtn);
        this.wenjuanBtn.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.MoreFragment.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (MoreFragment.this.ll.getVisibility() == 8) {
                    MoreFragment.this.ll.setVisibility(0);
                    MoreFragment.this.wenjuanBtn.setImageResource(R.drawable.ring_more_diaochatop);
                } else if (MoreFragment.this.ll.getVisibility() == 0) {
                    MoreFragment.this.ll.setVisibility(8);
                    MoreFragment.this.wenjuanBtn.setImageResource(R.drawable.ring_more_diaocha);
                }
            }
        });
        this.aboutusBtn.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.MoreFragment.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (MoreFragment.this.ll2.getVisibility() == 8) {
                    MoreFragment.this.ll2.setVisibility(0);
                    MoreFragment.this.aboutusBtn.setImageResource(R.drawable.ring_more_abouttop);
                } else if (MoreFragment.this.ll2.getVisibility() == 0) {
                    MoreFragment.this.ll2.setVisibility(8);
                    MoreFragment.this.aboutusBtn.setImageResource(R.drawable.ring_more_about);
                }
            }
        });
        this.qingli.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.MoreFragment.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                new ClearCacheTask(MoreFragment.this.getActivity()).execute(new Integer[0]);
            }
        });
        this.rb11 = (RadioButton) getView().findViewById(R.id.rb11);
        this.rb12 = (RadioButton) getView().findViewById(R.id.rb12);
        this.rb13 = (RadioButton) getView().findViewById(R.id.rb13);
        this.rb21 = (RadioButton) getView().findViewById(R.id.rb21);
        this.rb22 = (RadioButton) getView().findViewById(R.id.rb22);
        this.rb23 = (RadioButton) getView().findViewById(R.id.rb23);
        this.rb31 = (RadioButton) getView().findViewById(R.id.rb31);
        this.rb32 = (RadioButton) getView().findViewById(R.id.rb32);
        this.rb33 = (RadioButton) getView().findViewById(R.id.rb33);
        this.rb41 = (RadioButton) getView().findViewById(R.id.rb41);
        this.rb42 = (RadioButton) getView().findViewById(R.id.rb42);
        this.rb43 = (RadioButton) getView().findViewById(R.id.rb43);
        this.rb51 = (RadioButton) getView().findViewById(R.id.rb51);
        this.rb52 = (RadioButton) getView().findViewById(R.id.rb52);
        this.rb53 = (RadioButton) getView().findViewById(R.id.rb53);
        this.tijiao = (ImageButton) getView().findViewById(R.id.tijiaoBtn);
        this.q1 = getString(R.string.q1);
        this.q2 = getString(R.string.q2);
        this.q3 = getString(R.string.q3);
        this.q4 = getString(R.string.q4);
        this.q5 = getString(R.string.q5);
        this.tijiao.setOnClickListener(new View.OnClickListener() { // from class: com.baoyi.ring.fragment.MoreFragment.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (!MoreFragment.this.rb11.isChecked()) {
                    if (!MoreFragment.this.rb12.isChecked()) {
                        if (MoreFragment.this.rb13.isChecked()) {
                            MoreFragment.this.a1 = MoreFragment.this.getString(R.string.aa3);
                        }
                    } else {
                        MoreFragment.this.a1 = MoreFragment.this.getString(R.string.aa2);
                    }
                } else {
                    MoreFragment.this.a1 = MoreFragment.this.getString(R.string.aa1);
                }
                if (!MoreFragment.this.rb21.isChecked()) {
                    if (!MoreFragment.this.rb22.isChecked()) {
                        if (MoreFragment.this.rb23.isChecked()) {
                            MoreFragment.this.a2 = MoreFragment.this.getString(R.string.aa33);
                        }
                    } else {
                        MoreFragment.this.a2 = MoreFragment.this.getString(R.string.aa22);
                    }
                } else {
                    MoreFragment.this.a2 = MoreFragment.this.getString(R.string.aa11);
                }
                if (!MoreFragment.this.rb31.isChecked()) {
                    if (!MoreFragment.this.rb32.isChecked()) {
                        if (MoreFragment.this.rb33.isChecked()) {
                            MoreFragment.this.a3 = MoreFragment.this.getString(R.string.aa333);
                        }
                    } else {
                        MoreFragment.this.a3 = MoreFragment.this.getString(R.string.aa222);
                    }
                } else {
                    MoreFragment.this.a3 = MoreFragment.this.getString(R.string.aa111);
                }
                if (!MoreFragment.this.rb41.isChecked()) {
                    if (!MoreFragment.this.rb42.isChecked()) {
                        if (MoreFragment.this.rb43.isChecked()) {
                            MoreFragment.this.a4 = MoreFragment.this.getString(R.string.aa34);
                        }
                    } else {
                        MoreFragment.this.a4 = MoreFragment.this.getString(R.string.aa24);
                    }
                } else {
                    MoreFragment.this.a4 = MoreFragment.this.getString(R.string.aa14);
                }
                if (!MoreFragment.this.rb51.isChecked()) {
                    if (!MoreFragment.this.rb52.isChecked()) {
                        if (MoreFragment.this.rb53.isChecked()) {
                            MoreFragment.this.a5 = MoreFragment.this.getString(R.string.age3);
                        }
                    } else {
                        MoreFragment.this.a5 = MoreFragment.this.getString(R.string.age2);
                    }
                } else {
                    MoreFragment.this.a5 = MoreFragment.this.getString(R.string.age1);
                }
                String pagename = MoreFragment.this.getActivity().getPackageName();
                MoreFragment.this.qq1 = new Questionnaire(0, pagename, MoreFragment.this.q1, MoreFragment.this.a1, 0L);
                MoreFragment.this.qq2 = new Questionnaire(0, pagename, MoreFragment.this.q2, MoreFragment.this.a2, 0L);
                MoreFragment.this.qq3 = new Questionnaire(0, pagename, MoreFragment.this.q3, MoreFragment.this.a3, 0L);
                MoreFragment.this.qq4 = new Questionnaire(0, pagename, MoreFragment.this.q4, MoreFragment.this.a4, 0L);
                MoreFragment.this.qq5 = new Questionnaire(0, pagename, MoreFragment.this.q5, MoreFragment.this.a5, 0L);
                new Pust().execute(new Void[0]);
            }
        });
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
    class Pust extends AsyncTask<Void, Void, Void> {
        Pust() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void... params) {
            if (MoreFragment.this.qd != null) {
                MoreFragment.this.qd.AddQue(MoreFragment.this.qq1);
                MoreFragment.this.qd.AddQue(MoreFragment.this.qq2);
                MoreFragment.this.qd.AddQue(MoreFragment.this.qq3);
                MoreFragment.this.qd.AddQue(MoreFragment.this.qq4);
                MoreFragment.this.qd.AddQue(MoreFragment.this.qq5);
                return null;
            }
            return null;
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            Toast.makeText(MoreFragment.this.getActivity(), "感谢您的评分，我们会追求做到最好。", 0).show();
            MoreFragment.this.ll.setVisibility(8);
        }
    }
}
