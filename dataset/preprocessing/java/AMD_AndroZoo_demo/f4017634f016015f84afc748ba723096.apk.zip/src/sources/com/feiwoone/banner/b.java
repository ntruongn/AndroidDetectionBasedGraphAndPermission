package com.feiwoone.banner;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SlidingDrawer;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.commons.io.IOUtils;
import org.apache.http.client.ClientProtocolException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class b extends FrameLayout implements LocationListener, Serializable {
    private static b l;
    private static int m;
    private RelativeLayout a;
    private RelativeLayout b;
    private ImageView c;
    private ImageView d;
    private TextView e;
    private TextView f;
    private Context g;
    private com.feiwoone.banner.c.a h;
    private AdBanner i;
    private Timer j;
    private TimerTask k;
    private String n;
    private int o;
    private SlidingDrawer p;
    private Handler q;
    private LocationManager r;

    private b(Context context) {
        this(context, null, 0);
    }

    private b(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, 0);
        this.n = "";
        this.q = new c(this);
        com.feiwoone.banner.e.f.a(context);
        this.a = new RelativeLayout(context);
        this.b = new RelativeLayout(context);
    }

    private int a(Location location) {
        if (location == null || Double.isNaN(this.h.l()) || Double.isNaN(this.h.m())) {
            return 0;
        }
        if (this.h.l() == 0.0d && this.h.m() == 0.0d) {
            return 0;
        }
        double l2 = this.h.l() * 0.0174532925199433d;
        double m2 = this.h.m() * 0.0174532925199433d;
        double latitude = location.getLatitude() * 0.0174532925199433d;
        double longitude = location.getLongitude() * 0.0174532925199433d;
        return (int) (Math.acos((Math.cos(l2) * Math.cos(latitude) * Math.cos(longitude - m2)) + (Math.sin(l2) * Math.sin(latitude))) * 6371.0d * 1000.0d);
    }

    public static b a(Context context) {
        if (l == null) {
            l = new b(context);
        }
        l.g = context;
        m = com.feiwoone.banner.f.k.d(context).a();
        return l;
    }

    private static String a(int i) {
        StringBuffer stringBuffer = new StringBuffer();
        if (i > 1000) {
            stringBuffer.append(i / 1000);
            stringBuffer.append(IOUtils.LINE_SEPARATOR_UNIX);
            stringBuffer.append("Km");
        } else if (i > 0) {
            stringBuffer.append(i);
            stringBuffer.append(IOUtils.LINE_SEPARATOR_UNIX);
            stringBuffer.append("m");
        }
        return stringBuffer.toString();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(b bVar, Intent intent, com.feiwoone.banner.c.a aVar) {
        if (aVar.h() == null || aVar.h().size() == 0) {
            return;
        }
        Toast.makeText(bVar.g, "正在下载...", 0).show();
        com.feiwoone.banner.e.f.a(bVar.g);
        if (com.feiwoone.banner.e.f.b()) {
            com.feiwoone.banner.e.f.a(bVar.g).b(bVar.g, "/adfeiwo/apk/");
        } else {
            com.feiwoone.banner.e.f.a(bVar.g).b(bVar.g, "");
        }
        com.feiwoone.banner.f.e.a(bVar.getContext(), "ADFEIWO", aVar.o(), aVar.i(), "12345678");
        Context context = bVar.g;
        com.feiwoone.banner.e.g.a().a(bVar.g, new com.feiwoone.banner.c.b(aVar.i(), aVar.o(), null, aVar.b(), (String) aVar.h().get(0), aVar.p()), new g(bVar));
    }

    private Location b(Context context) {
        if (this.r != null) {
            this.r.removeUpdates(this);
        }
        this.r = (LocationManager) context.getSystemService("location");
        this.r.requestLocationUpdates("gps", 10000L, 10.0f, this);
        return this.r.getLastKnownLocation(this.r.getBestProvider(new Criteria(), true));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ com.feiwoone.banner.g.a d(b bVar) {
        return null;
    }

    public final void a() {
        this.p = null;
        this.d = null;
        this.e = null;
        this.f = null;
        if (this.j != null) {
            this.j.cancel();
            this.j = null;
        }
        if (this.k != null) {
            this.k.cancel();
            this.k = null;
        }
        l = null;
    }

    public final void a(AdBanner adBanner, com.feiwoone.banner.c.a aVar) {
        setVisibility(0);
        this.i = adBanner;
        this.h = aVar;
        if (this.r != null) {
            this.r.removeUpdates(this);
        }
        removeAllViewsInLayout();
        switch (aVar.f()) {
            case 1:
            case 7:
                try {
                    removeAllViews();
                    if (!aVar.d().endsWith(".gif")) {
                        this.a.removeAllViews();
                        int i = m;
                        int j = (int) ((m / this.h.j()) * this.h.k());
                        setLayoutParams(new FrameLayout.LayoutParams(i, j));
                        this.d = new ImageView(this.g);
                        this.d.setId(900);
                        this.d.setAdjustViewBounds(true);
                        this.d.setScaleType(ImageView.ScaleType.FIT_XY);
                        InputStream b = com.feiwoone.banner.e.f.a(this.g).b("/adfeiwo/image/", this.h.d());
                        this.d.setImageDrawable(Drawable.createFromStream(b, "is"));
                        if (b != null) {
                            b.close();
                        }
                        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i, j);
                        layoutParams.addRule(13);
                        this.a.addView(this.d, layoutParams);
                        this.f = new TextView(this.g);
                        this.f.setId(902);
                        if (!Double.isNaN(this.h.l()) && !Double.isNaN(this.h.m()) && this.h.l() != 0.0d && this.h.m() != 0.0d) {
                            this.f.setText(a(a(b(this.g))));
                        }
                        this.f.setTextColor(-16777216);
                        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
                        layoutParams2.addRule(11);
                        layoutParams2.setMargins(0, 6, 6, 0);
                        this.a.addView(this.f, layoutParams2);
                        ViewGroup.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(i, j);
                        addView(this.a, layoutParams3);
                        RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(j * 3, j);
                        layoutParams4.addRule(11);
                        layoutParams4.setMargins(0, 0, 0, 0);
                        this.b.removeAllViews();
                        this.c = new ImageView(this.g);
                        this.c.setAdjustViewBounds(true);
                        this.c.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        this.c.setMaxHeight(j);
                        this.c.setLayoutParams(layoutParams4);
                        this.c.setImageDrawable(com.feiwoone.banner.f.g.a(this.g, "adfeiwo_banner_download.png##".replace("##", "")));
                        this.b.addView(this.c);
                        this.b.setVisibility(8);
                        addView(this.b, layoutParams3);
                        break;
                    } else {
                        aVar.d();
                        int i2 = m;
                        int j2 = (int) ((m / this.h.j()) * this.h.k());
                        com.feiwoone.banner.d.c cVar = new com.feiwoone.banner.d.c(this.g);
                        cVar.setId(900);
                        InputStream b2 = com.feiwoone.banner.e.f.a(this.g).b("/adfeiwo/image/", this.h.d());
                        cVar.a(b2);
                        if (b2 != null) {
                            b2.close();
                        }
                        RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(i2, j2);
                        layoutParams5.addRule(13);
                        this.a.addView(cVar, layoutParams5);
                        this.f = new TextView(this.g);
                        this.f.setId(902);
                        if (!Double.isNaN(this.h.l()) && !Double.isNaN(this.h.m()) && this.h.l() != 0.0d && this.h.m() != 0.0d) {
                            this.f.setText(a(a(b(this.g))));
                        }
                        this.f.setTextColor(-16777216);
                        RelativeLayout.LayoutParams layoutParams6 = new RelativeLayout.LayoutParams(-2, -2);
                        layoutParams6.addRule(11);
                        layoutParams6.setMargins(0, 6, 6, 0);
                        this.a.addView(this.f, layoutParams6);
                        addView(this.a, new FrameLayout.LayoutParams(-2, -2));
                        RelativeLayout.LayoutParams layoutParams7 = new RelativeLayout.LayoutParams(-2, j2);
                        layoutParams7.addRule(11);
                        layoutParams7.setMargins(0, 0, 0, 0);
                        this.b.removeAllViews();
                        this.c = new ImageView(this.g);
                        this.c.setImageDrawable(com.feiwoone.banner.f.g.a(this.g, "adfeiwo_banner_download.png##".replace("##", "")));
                        this.b.addView(this.c, layoutParams7);
                        this.b.setVisibility(8);
                        addView(this.b);
                        break;
                    }
                } catch (IllegalStateException e) {
                    break;
                } catch (ClientProtocolException e2) {
                    break;
                } catch (IOException e3) {
                    break;
                } catch (Exception e4) {
                    break;
                }
                break;
            case 2:
                removeAllViews();
                this.e = new TextView(this.g);
                this.e.setId(901);
                this.e.setTextColor(-16777216);
                try {
                    if (this.j != null) {
                        this.j.cancel();
                    }
                    if (this.k != null) {
                        this.k.cancel();
                    }
                    this.j = new Timer();
                    this.k = new h(this);
                    this.j.schedule(this.k, 100L, 6000L);
                } catch (Exception e5) {
                }
                this.e.setTextColor(-16777216);
                int j3 = (int) ((m / this.h.j()) * this.h.k());
                RelativeLayout.LayoutParams layoutParams8 = new RelativeLayout.LayoutParams(m, j3);
                layoutParams8.addRule(15, -1);
                layoutParams8.setMargins(6, 6, 6, 6);
                this.a.addView(this.e, layoutParams8);
                this.f = new TextView(this.g);
                this.f.setId(902);
                try {
                    if (!Double.isNaN(this.h.l()) && !Double.isNaN(this.h.m()) && this.h.l() != 0.0d && this.h.m() != 0.0d) {
                        this.f.setText(a(a(b(this.g))));
                    }
                } catch (NullPointerException e6) {
                } catch (Exception e7) {
                }
                this.f.setTextColor(-16777216);
                RelativeLayout.LayoutParams layoutParams9 = new RelativeLayout.LayoutParams(-2, -2);
                layoutParams9.addRule(11);
                layoutParams9.setMargins(0, 6, 6, 0);
                this.a.addView(this.f, layoutParams9);
                addView(this.a, new FrameLayout.LayoutParams(this.h.j(), this.h.k()));
                RelativeLayout.LayoutParams layoutParams10 = new RelativeLayout.LayoutParams(-2, j3);
                layoutParams10.addRule(11);
                layoutParams10.setMargins(0, 0, 0, 0);
                this.b.removeAllViews();
                this.c = new ImageView(this.g);
                this.c.setImageDrawable(com.feiwoone.banner.f.g.a(this.g, "adfeiwo_banner_download.png##".replace("##", "")));
                this.b.addView(this.c, layoutParams10);
                this.b.setVisibility(8);
                addView(this.b);
                break;
            case 3:
                try {
                    try {
                        removeAllViews();
                        this.d = new ImageView(this.g);
                        this.d.setId(900);
                        com.feiwoone.banner.e.a.a().a(this.g, this.h.d(), new i(this));
                        int i3 = m;
                        int j4 = (int) ((m / this.h.j()) * this.h.k());
                        measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
                        RelativeLayout.LayoutParams layoutParams11 = new RelativeLayout.LayoutParams(i3, j4);
                        layoutParams11.addRule(15, -1);
                        layoutParams11.addRule(9);
                        layoutParams11.setMargins(2, 2, 0, 0);
                        this.a.addView(this.d, layoutParams11);
                        this.f = new TextView(this.g);
                        this.f.setId(902);
                        try {
                            if (!Double.isNaN(this.h.l()) && !Double.isNaN(this.h.m()) && this.h.l() != 0.0d && this.h.m() != 0.0d) {
                                this.f.setText(a(a(b(this.g))));
                            }
                        } catch (NullPointerException e8) {
                        } catch (Exception e9) {
                        }
                        this.f.setTextColor(-16777216);
                        RelativeLayout.LayoutParams layoutParams12 = new RelativeLayout.LayoutParams(-2, -2);
                        layoutParams12.addRule(11);
                        layoutParams12.setMargins(0, 6, 6, 0);
                        this.a.addView(this.f, layoutParams12);
                        this.e = new TextView(this.g);
                        this.e.setId(901);
                        this.e.setTextColor(-16777216);
                        try {
                            if (this.j != null) {
                                this.j.cancel();
                            }
                            if (this.k != null) {
                                this.k.cancel();
                            }
                            this.j = new Timer();
                            this.k = new j(this);
                            this.j.schedule(this.k, 100L, 6000L);
                        } catch (Exception e10) {
                        }
                        RelativeLayout.LayoutParams layoutParams13 = new RelativeLayout.LayoutParams(-2, -2);
                        layoutParams13.addRule(1, 900);
                        layoutParams13.addRule(0, 902);
                        layoutParams13.addRule(15, -1);
                        layoutParams13.setMargins(6, 6, 6, 6);
                        this.a.addView(this.e, layoutParams13);
                        addView(this.a, new FrameLayout.LayoutParams(this.h.j(), this.h.k()));
                        RelativeLayout.LayoutParams layoutParams14 = new RelativeLayout.LayoutParams(-2, j4);
                        layoutParams14.addRule(11);
                        layoutParams14.setMargins(0, 0, 0, 0);
                        this.b.removeAllViews();
                        this.c = new ImageView(this.g);
                        this.c.setImageDrawable(com.feiwoone.banner.f.g.a(this.g, "adfeiwo_banner_download.png##".replace("##", "")));
                        this.b.addView(this.c, layoutParams14);
                        this.b.setVisibility(8);
                        addView(this.b);
                        break;
                    } catch (Exception e11) {
                        break;
                    }
                } catch (ClientProtocolException e12) {
                    break;
                } catch (IOException e13) {
                    break;
                } catch (IllegalStateException e14) {
                    break;
                }
                break;
            case 4:
            case 5:
            case 6:
            default:
                setVisibility(8);
                break;
        }
        Intent intent = null;
        this.n = "";
        switch (this.h.g()) {
            case 1001:
            case 1005:
            case 1006:
                Intent intent2 = new Intent(this.g, (Class<?>) WebViewActivity.class);
                Bundle bundle = new Bundle();
                this.n = (String) this.h.h().get(0);
                bundle.putString("url", this.n);
                bundle.putSerializable("ad", this.h);
                intent2.putExtras(bundle);
                intent = intent2;
                break;
            case 1002:
                intent = new Intent("android.intent.action.DIAL", Uri.parse("tel:" + ((String) this.h.h().get(0))));
                break;
            case 1003:
                Intent intent3 = new Intent("android.intent.action.SENDTO", Uri.parse("sms:" + ((String) this.h.h().get(0))));
                intent3.putExtra("sms_body", (String) this.h.h().get(1));
                intent = intent3;
                break;
            case 1004:
                Intent intent4 = new Intent("android.intent.action.SENDTO", Uri.parse("mailto:"));
                intent4.setType("text/plain");
                intent4.putExtra("android.intent.extra.EMAIL", (String) this.h.h().get(0));
                intent4.putExtra("android.intent.extra.SUBJECT", (String) this.h.h().get(1));
                intent4.putExtra("android.intent.extra.TEXT", (String) this.h.h().get(2));
                intent = intent4;
                break;
            case 2003:
                this.n = (String) this.h.h().get(0);
                Uri parse = Uri.parse(this.n);
                intent = new Intent("android.intent.action.VIEW", parse);
                intent.setFlags(67108864);
                intent.setType("video/*");
                intent.setDataAndType(parse, "video/*");
                break;
        }
        RelativeLayout.LayoutParams layoutParams15 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams15.addRule(13);
        setLayoutParams(layoutParams15);
        setClickable(true);
        setFocusable(true);
        setOnClickListener(new d(this, intent));
    }

    @Override // android.location.LocationListener
    public final void onLocationChanged(Location location) {
        if (location == null || this.h == null || Double.isNaN(this.h.l()) || Double.isNaN(this.h.m())) {
            return;
        }
        if ((this.h.l() == 0.0d && this.h.m() == 0.0d) || this.f == null) {
            return;
        }
        this.f.setText(a(a(location)));
    }

    @Override // android.location.LocationListener
    public final void onProviderDisabled(String str) {
    }

    @Override // android.location.LocationListener
    public final void onProviderEnabled(String str) {
    }

    @Override // android.location.LocationListener
    public final void onStatusChanged(String str, int i, Bundle bundle) {
    }
}
