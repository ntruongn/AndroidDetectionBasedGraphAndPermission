package com.baidu.mobstat;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
class d implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ String b;
    final /* synthetic */ int c;
    final /* synthetic */ long d;
    final /* synthetic */ Context e;
    final /* synthetic */ c f;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(c cVar, String str, String str2, int i, long j, Context context) {
        this.f = cVar;
        this.a = str;
        this.b = str2;
        this.c = i;
        this.d = j;
        this.e = context;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (!j.a().c()) {
            synchronized (j.a()) {
                try {
                    j.a().wait();
                } catch (InterruptedException e) {
                    com.baidu.mobstat.a.c.a("stat", e);
                }
            }
        }
        DataCore.getInstance().putEvent(this.a, this.b, this.c, this.d, 0L);
        DataCore.getInstance().flush(this.e);
    }
}
