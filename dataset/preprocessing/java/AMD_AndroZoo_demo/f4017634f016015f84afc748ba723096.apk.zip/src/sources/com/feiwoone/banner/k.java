package com.feiwoone.banner;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import org.apache.http.ParseException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class k implements LocationListener {
    private static k a;
    private Context b;
    private double c;
    private double d;

    private k(Context context) {
        this.b = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static k a(Context context) {
        if (a == null) {
            a = new k(context);
        }
        return a;
    }

    private void a(AdBanner adBanner, Handler handler, com.feiwoone.banner.c.a aVar) {
        handler.post(new n(this, adBanner, aVar));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(k kVar, AdBanner adBanner, int i, com.feiwoone.banner.c.a aVar, String str) {
        try {
            Context context = kVar.b;
            double d = kVar.c;
            double d2 = kVar.d;
            String appKey = adBanner.getAppKey();
            String a2 = com.feiwoone.banner.f.k.a(context);
            String c = com.feiwoone.banner.f.a.a(context).c();
            String d3 = com.feiwoone.banner.f.a.a(context).d();
            String b = com.feiwoone.banner.f.a.a(context).b();
            String a3 = com.feiwoone.banner.f.a.a(context).a();
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("devid", a2);
            jSONObject.put("adid", aVar.i());
            jSONObject.put("appkey", appKey);
            jSONObject.put("type", i);
            jSONObject.put("lat", d);
            jSONObject.put("lon", d2);
            jSONObject.put("cellid", c);
            jSONObject.put("lac", d3);
            jSONObject.put("mcc", a3);
            jSONObject.put("mnc", b);
            jSONObject.put("url", str);
            jSONObject.put("adsdkversion", "2.6");
            jSONObject.put("sdktype", "BANNER");
            new StringBuilder("click json ").append(jSONObject.toString());
            com.feiwoone.banner.f.h.a().a(kVar.b, jSONObject.toString(), com.feiwoone.banner.f.b.b(), adBanner.getAppKey());
        } catch (ParseException e) {
        } catch (JSONException e2) {
        } catch (Exception e3) {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(k kVar, AdBanner adBanner, Handler handler) {
        JSONArray jSONArray;
        com.feiwoone.banner.f.e.b(kVar.b, "ADFEIWO", "APPKEY", adBanner.getAppKey(), "12345678");
        try {
            Context context = kVar.b;
            double d = kVar.c;
            double d2 = kVar.d;
            String appKey = adBanner.getAppKey();
            String a2 = com.feiwoone.banner.f.k.a(context);
            String b = com.feiwoone.banner.f.k.b(context);
            String c = com.feiwoone.banner.f.k.c(context);
            String a3 = com.feiwoone.banner.f.k.a();
            String b2 = com.feiwoone.banner.f.k.b();
            int i = com.feiwoone.banner.b.a.b;
            int i2 = com.feiwoone.banner.b.a.c;
            if (i <= 0 || i2 <= 0) {
                com.feiwoone.banner.c.c d3 = com.feiwoone.banner.f.k.d(context);
                i = d3.a();
                i2 = d3.b();
            }
            String c2 = com.feiwoone.banner.f.a.a(context).c();
            String d4 = com.feiwoone.banner.f.a.a(context).d();
            String b3 = com.feiwoone.banner.f.a.a(context).b();
            String a4 = com.feiwoone.banner.f.a.a(context).a();
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("os", "Android");
            jSONObject.put("devid", a2);
            jSONObject.put("appkey", appKey);
            jSONObject.put("lat", d);
            jSONObject.put("lon", d2);
            jSONObject.put("wifi", b);
            jSONObject.put("ip", c);
            jSONObject.put("direction", "");
            jSONObject.put("sound", "");
            jSONObject.put("keyword", "");
            jSONObject.put("width", String.valueOf(i));
            jSONObject.put("height", String.valueOf(i2));
            jSONObject.put("deviceosversion", b2);
            jSONObject.put("mcc", a4);
            jSONObject.put("mnc", b3);
            jSONObject.put("version", "2.6");
            jSONObject.put("adsdkversion", "2.6");
            jSONObject.put("devicename", a3);
            jSONObject.put("sdkname", "Android");
            jSONObject.put("cellid", c2);
            jSONObject.put("lac", d4);
            com.feiwoone.banner.f.i.a();
            jSONObject.put("weixinflag", com.feiwoone.banner.f.i.a(context, "com.tencent.mm"));
            jSONObject.put("adsdk", "4.0");
            jSONObject.put("sdktype", "BANNER");
            new StringBuilder("json ").append(jSONObject.toString());
            jSONArray = new JSONArray(com.feiwoone.banner.f.h.a().a(kVar.b, jSONObject.toString(), com.feiwoone.banner.f.b.a(), adBanner.getAppKey()));
            new StringBuilder(" return json ").append(jSONArray.toString());
        } catch (IllegalStateException e) {
            kVar.a(adBanner, handler, (com.feiwoone.banner.c.a) null);
        } catch (ParseException e2) {
            kVar.a(adBanner, handler, (com.feiwoone.banner.c.a) null);
        } catch (JSONException e3) {
            kVar.a(adBanner, handler, (com.feiwoone.banner.c.a) null);
        } catch (Exception e4) {
            kVar.a(adBanner, handler, (com.feiwoone.banner.c.a) null);
        }
        if (jSONArray.length() > 0) {
            Context context2 = kVar.b;
            com.feiwoone.banner.c.a aVar = new com.feiwoone.banner.c.a(jSONArray.optJSONObject(0));
            com.feiwoone.banner.f.e.a(kVar.b, "ADFEIWO", "list_click", new StringBuilder(String.valueOf(aVar.i())).toString(), 0);
            if (com.feiwoone.banner.e.f.a(kVar.b).a("/adfeiwo/image/", aVar.d())) {
                kVar.a(adBanner, handler, aVar);
                return;
            } else {
                kVar.a(adBanner, handler, (com.feiwoone.banner.c.a) null);
                return;
            }
        }
        kVar.a(adBanner, handler, (com.feiwoone.banner.c.a) null);
        Context context3 = kVar.b;
        if (context3.getSharedPreferences("ADFEIWO", 0).getBoolean(com.feiwoone.banner.f.f.a("FIRST_USER", "12345678", true), true)) {
            com.feiwoone.banner.e.m a5 = com.feiwoone.banner.e.m.a();
            String jSONObject2 = com.feiwoone.banner.f.a.a(kVar.b, adBanner.getAppKey(), "2.6").toString();
            com.feiwoone.banner.e.o oVar = new com.feiwoone.banner.e.o();
            oVar.a(kVar.b, com.feiwoone.banner.f.b.c(), adBanner.getAppKey(), jSONObject2);
            oVar.a(new m(kVar));
            a5.a(oVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(AdBanner adBanner, int i, com.feiwoone.banner.c.a aVar, String str) {
        new Thread(new o(this, aVar, adBanner, i, str)).start();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(AdBanner adBanner, Handler handler) {
        new Thread(new l(this, adBanner, handler)).start();
    }

    @Override // android.location.LocationListener
    public final void onLocationChanged(Location location) {
        this.c = location.getLatitude();
        this.d = location.getLongitude();
    }

    @Override // android.location.LocationListener
    public final void onProviderDisabled(String str) {
    }

    @Override // android.location.LocationListener
    public final void onProviderEnabled(String str) {
    }

    @Override // android.location.LocationListener
    public final void onStatusChanged(String str, int i, Bundle bundle) {
    }
}
