package com.feiwoone.banner;

import android.content.Intent;
import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
final class e implements View.OnClickListener {
    private /* synthetic */ d a;
    private final /* synthetic */ Intent b;
    private final /* synthetic */ com.feiwoone.banner.c.a c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(d dVar, Intent intent, com.feiwoone.banner.c.a aVar) {
        this.a = dVar;
        this.b = intent;
        this.c = aVar;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        b.a(this.a.a, this.b, this.c);
    }
}
