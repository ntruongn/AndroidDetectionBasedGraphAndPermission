package com.baoyi.audio.service;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;
import com.baoyi.audio.BaoyiApplication;
import com.baoyi.audio.utils.content;
import com.baoyi.download.DownloadJob;
import com.baoyi.download.DownloadJobListener;
import com.baoyi.download.DownloadProvider;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class DownloadService extends Service {
    public static final String ACTION_ADD_TO_DOWNLOAD = "add_to_download";
    private static final int DOWNLOAD_NOTIFY_ID = 667668;
    public static final String EXTRA_PLAYLIST_ENTRY = "playlist_entry";
    private DownloadProvider mDownloadProvider;
    private NotificationManager mNotificationManager = null;
    private DownloadJobListener mDownloadJobListener = new DownloadJobListener() { // from class: com.baoyi.audio.service.DownloadService.1
        @Override // com.baoyi.download.DownloadJobListener
        public void downloadEnded(DownloadJob job) {
            DownloadService.this.mDownloadProvider.downloadCompleted(job);
            DownloadService.this.displayNotifcation(job);
        }

        @Override // com.baoyi.download.DownloadJobListener
        public void downloadStarted() {
        }
    };

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.mNotificationManager = (NotificationManager) getSystemService("notification");
        this.mDownloadProvider = BaoyiApplication.getInstance().getProvider();
    }

    @Override // android.app.Service
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        if (intent != null) {
            String action = intent.getAction();
            if (action.equals(ACTION_ADD_TO_DOWNLOAD)) {
                String name = intent.getExtras().getString(UpdateService.NAME);
                String url = intent.getExtras().getString("url");
                boolean isfront = intent.getExtras().getBoolean("isfront");
                addToDownloadQueue(name, url, isfront);
            }
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void displayNotifcation(DownloadJob job) {
        if (job.isIsfront()) {
            String text = "下载:" + job.getName() + "  完成。";
            Toast toast = Toast.makeText(getApplicationContext(), text, 0);
            toast.show();
        }
    }

    public void addToDownloadQueue(String name, String url, boolean isfront) {
        DownloadJob downloadJob = new DownloadJob();
        downloadJob.setName(name);
        downloadJob.setUrl(url);
        downloadJob.setIsfront(isfront);
        downloadJob.setExtension(".mp3");
        downloadJob.setPath(content.SAVEDIR);
        if (this.mDownloadProvider.queueDownload(downloadJob)) {
            downloadJob.setListener(this.mDownloadJobListener);
            downloadJob.start();
        }
    }

    public void notifyScanCompleted() {
        if (this.mDownloadProvider.getQueuedDownloads().size() == 0) {
            stopSelf();
        }
    }
}
