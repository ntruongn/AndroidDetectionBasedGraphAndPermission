package com.feiwoone.banner.e;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public final class m {
    private static m a = null;
    private ExecutorService b;

    private m() {
        this.b = null;
        this.b = Executors.newFixedThreadPool(5);
    }

    public static m a() {
        if (a == null) {
            a = new m();
        }
        return a;
    }

    public final void a(o oVar) {
        this.b.submit(oVar);
    }
}
