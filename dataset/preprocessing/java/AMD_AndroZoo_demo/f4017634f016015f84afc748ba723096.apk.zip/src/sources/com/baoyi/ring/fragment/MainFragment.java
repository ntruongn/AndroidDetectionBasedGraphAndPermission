package com.baoyi.ring.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import com.baoyi.audio.utils.content;
import com.baoyi.ring.adapter.TestFragmentAdapter;
import com.baoyi.ring.base.BaseFragmentActivity;
import com.hope.leyuan.R;
import com.viewpagerindicator.TitlePageIndicator;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/f4017634f016015f84afc748ba723096.apk/classes.dex */
public class MainFragment extends BaseFragmentActivity {
    private List<Fragment> fragments;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.layout_main);
        this.fragments = new ArrayList();
        this.fragments.add(new NewFragment());
        this.fragments.add(new KindFragment());
        this.fragments.add(new LocalFragment());
        this.fragments.add(new SearchFragment());
        this.fragments.add(new MoreFragment());
        this.mAdapter = new TestFragmentAdapter(getSupportFragmentManager(), this.fragments);
        this.mPager = (ViewPager) findViewById(R.id.main_pager);
        this.mPager.setAdapter(this.mAdapter);
        TitlePageIndicator indicator = (TitlePageIndicator) findViewById(R.id.main_indicator);
        indicator.setViewPager(this.mPager);
        indicator.setFooterIndicatorStyle(TitlePageIndicator.IndicatorStyle.Triangle);
        this.mIndicator = indicator;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity, android.app.Activity
    public void onPause() {
        super.onPause();
    }

    @Override // android.support.v4.app.FragmentActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4 && content.ISKIND == 1) {
            Intent intent = new Intent();
            intent.setAction("com.weixinring.kindback");
            sendBroadcast(intent);
            return true;
        }
        if (keyCode == 4 && content.ISKIND == 0) {
            finish();
            return super.onKeyDown(keyCode, event);
        }
        return super.onKeyDown(keyCode, event);
    }
}
