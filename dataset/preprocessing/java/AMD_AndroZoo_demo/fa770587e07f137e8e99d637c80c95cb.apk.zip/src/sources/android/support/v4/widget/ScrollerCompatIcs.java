package android.support.v4.widget;

import android.widget.Scroller;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
class ScrollerCompatIcs {
    ScrollerCompatIcs() {
    }

    public static float getCurrVelocity(Scroller scroller) {
        return scroller.getCurrVelocity();
    }
}
