package com.example.fakesmstime;

import java.util.Calendar;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class CustomDate {
    public String AM_PM;
    public Calendar calendarSelected;
    public int date;
    public Date dateSelected;
    public int hour12;
    public int hour24;
    public int min;
    public String monthFullName;
    public int monthNumber;
    public String monthShortName;
    public int sec;
    public String weekDayFullName;
    public String weekDayShortName;
    public int year;

    public CustomDate(Calendar calendarSelected, Date dateSelected, int year, String monthFullName, String monthShortName, int monthNumber, int date, String weekDayFullName, String weekDayShortName, int hour24, int hour12, int min, int sec, String AM_PM) {
        this.calendarSelected = calendarSelected;
        this.dateSelected = dateSelected;
        this.year = year;
        this.monthFullName = monthFullName;
        this.monthShortName = monthShortName;
        this.monthNumber = monthNumber;
        this.date = date;
        this.weekDayFullName = weekDayFullName;
        this.weekDayShortName = weekDayShortName;
        this.hour24 = hour24;
        this.hour12 = hour12;
        this.min = min;
        this.sec = sec;
        this.AM_PM = AM_PM;
    }

    public String toString() {
        return String.valueOf(this.date) + "/" + this.monthShortName + "/" + this.year + "   " + this.hour24 + ":" + this.min + ":" + this.sec;
    }
}
