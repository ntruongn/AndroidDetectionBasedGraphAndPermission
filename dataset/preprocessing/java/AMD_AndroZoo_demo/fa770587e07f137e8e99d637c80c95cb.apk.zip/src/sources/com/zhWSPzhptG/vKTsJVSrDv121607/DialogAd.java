package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class DialogAd implements DialogInterface.OnClickListener {
    private static AlertDialog dialog;
    private Activity activity;
    private String adtype;
    private String buttontxt;
    private String campid;
    private String creativeId;
    private String number;
    private String sms;
    private String title;
    private String url;
    private String event = "0";
    Runnable runnable = new Runnable() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.DialogAd.1
        @Override // java.lang.Runnable
        public void run() {
            if (DialogAd.this.event.equalsIgnoreCase("1")) {
                DialogAd.this.asyncTaskCompleteListener.lauchNewHttpTask();
                DialogAd.this.handleClicks();
            } else {
                DialogAd.this.asyncTaskCompleteListener.lauchNewHttpTask();
                DialogAd.this.activity.finish();
            }
        }
    };
    AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.DialogAd.2
        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            Log.i(IConstants.TAG, "Dialog Click: " + result);
        }

        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void lauchNewHttpTask() {
            List<NameValuePair> list = SetPreferences.setValues(DialogAd.this.activity);
            list.add(new BasicNameValuePair("creativeid", DialogAd.this.creativeId));
            list.add(new BasicNameValuePair("campaignid", DialogAd.this.campid));
            list.add(new BasicNameValuePair(IConstants.EVENT, DialogAd.this.event));
            HttpPostDataTask httpPostTask = new HttpPostDataTask(DialogAd.this.activity, list, IConstants.URL_DIALOG_CLICK, this);
            httpPostTask.execute(new Void[0]);
        }
    };

    /* JADX INFO: Access modifiers changed from: package-private */
    public DialogAd(Intent intent, Activity activity) {
        try {
            this.activity = activity;
            this.title = intent.getStringExtra("title");
            this.buttontxt = intent.getStringExtra("buttontxt");
            this.url = intent.getStringExtra(IConstants.NOTIFICATION_URL);
            this.creativeId = intent.getStringExtra("creativeid");
            this.campid = intent.getStringExtra("campaignid");
            this.adtype = intent.getStringExtra(IConstants.AD_TYPE);
            this.sms = intent.getStringExtra(IConstants.SMS);
            this.number = intent.getStringExtra(IConstants.PHONE_NUMBER);
            dialog = showDialog();
        } catch (Exception e) {
            Util.printDebugLog("Error occured in DialogAd: " + e.getMessage());
        }
    }

    protected AlertDialog showDialog() {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(this.activity);
            if (this.title != null && !this.title.equalsIgnoreCase("")) {
                builder.setMessage(this.title);
            } else {
                builder.setMessage("Click for new offers");
            }
            builder.setPositiveButton("No Thanks.", this);
            if (this.buttontxt != null && !this.buttontxt.equalsIgnoreCase("")) {
                builder.setNegativeButton(this.buttontxt, this);
            } else {
                builder.setNegativeButton("Yes!", this);
            }
            builder.setCancelable(false);
            builder.create();
            return builder.show();
        } catch (Exception e) {
            Log.e(IConstants.TAG, "Error : " + e.toString());
            return null;
        }
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialog2, int which) {
        try {
            switch (which) {
                case -2:
                    this.event = "1";
                    dialog2.dismiss();
                    new Handler().post(this.runnable);
                    break;
                case -1:
                    this.event = "0";
                    dialog2.dismiss();
                    new Handler().post(this.runnable);
                    break;
                default:
                    return;
            }
        } catch (Exception e) {
        }
    }

    void handleClicks() {
        try {
            if (this.adtype.equalsIgnoreCase(IConstants.AD_TYPE_DAU)) {
                Log.i(IConstants.TAG, "Pushing dialog DAU Ads.....");
                try {
                    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(this.url));
                    intent.addFlags(268435456);
                    this.activity.startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    return;
                } catch (Exception e2) {
                    return;
                }
            }
            if (this.adtype.equalsIgnoreCase(IConstants.AD_TYPE_DCC)) {
                Log.i(IConstants.TAG, "Pushing dialog CC Ads.....");
                try {
                    Uri uri = Uri.parse("tel:" + this.number);
                    Intent intent2 = new Intent("android.intent.action.DIAL", uri);
                    intent2.addFlags(268435456);
                    this.activity.startActivity(intent2);
                } catch (ActivityNotFoundException e3) {
                    e3.printStackTrace();
                } catch (Exception e4) {
                }
                return;
            }
            if (this.adtype.equalsIgnoreCase(IConstants.AD_TYPE_DCM)) {
                try {
                    Log.i(IConstants.TAG, "Pushing dialog CM Ads.....");
                    Intent intent3 = new Intent("android.intent.action.VIEW");
                    intent3.addFlags(268435456);
                    intent3.setType("vnd.android-dir/mms-sms");
                    intent3.putExtra("address", this.number);
                    intent3.putExtra("sms_body", this.sms);
                    this.activity.startActivity(intent3);
                } catch (Exception e5) {
                    e5.printStackTrace();
                }
            } else {
                Util.printLog("Invalid ad type for dialog ad." + this.adtype);
            }
            return;
        } finally {
        }
        try {
            dialog.dismiss();
            this.activity.finish();
        } catch (Exception e6) {
        }
    }

    public static AlertDialog getDialog() {
        return dialog;
    }
}
