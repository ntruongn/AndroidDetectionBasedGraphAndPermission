package com.haawa.fakesms;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public final class R {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public static final class attr {
        public static final int childHeight = 0x7f010003;
        public static final int childWidth = 0x7f010002;
        public static final int labelerClass = 0x7f010000;
        public static final int labelerFormat = 0x7f010001;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public static final class drawable {
        public static final int big_bg = 0x7f020000;
        public static final int ch_checked = 0x7f020001;
        public static final int ch_unchecked = 0x7f020002;
        public static final int contacts = 0x7f020003;
        public static final int contacts_bg = 0x7f020004;
        public static final int contacts_selected = 0x7f020005;
        public static final int customdrawablecheckbox = 0x7f020006;
        public static final int date_bg = 0x7f020007;
        public static final int frame = 0x7f020008;
        public static final int header = 0x7f020009;
        public static final int header_long = 0x7f02000a;
        public static final int ic_action_search = 0x7f02000b;
        public static final int ic_launcher = 0x7f02000c;
        public static final int no_photo = 0x7f02000d;
        public static final int send = 0x7f02000e;
        public static final int send_bg = 0x7f02000f;
        public static final int send_letter = 0x7f020010;
        public static final int send_selected = 0x7f020011;
        public static final int stich = 0x7f020012;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public static final class id {
        public static final int ava = 0x7f070006;
        public static final int contact_lay = 0x7f070001;
        public static final int contacts = 0x7f070003;
        public static final int date_picker = 0x7f07000a;
        public static final int header = 0x7f070002;
        public static final int lay1 = 0x7f070005;
        public static final int menu_settings = 0x7f07000d;
        public static final int name_label = 0x7f070007;
        public static final int scrollView1 = 0x7f070000;
        public static final int send = 0x7f07000c;
        public static final int sep2 = 0x7f07000b;
        public static final int sms_body = 0x7f070008;
        public static final int smsfrom = 0x7f070004;
        public static final int unread = 0x7f070009;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public static final class layout {
        public static final int activity_main = 0x7f030000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public static final class menu {
        public static final int activity_main = 0x7f060000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public static final class string {
        public static final int app_name = 0x7f040000;
        public static final int hello_world = 0x7f040001;
        public static final int menu_settings = 0x7f040002;
        public static final int title_activity_main = 0x7f040003;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public static final class style {
        public static final int AppTheme = 0x7f050000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public static final class styleable {
        public static final int[] ScrollLayout = {R.attr.labelerClass, R.attr.labelerFormat, R.attr.childWidth, R.attr.childHeight};
        public static final int ScrollLayout_childHeight = 0x00000003;
        public static final int ScrollLayout_childWidth = 0x00000002;
        public static final int ScrollLayout_labelerClass = 0x00000000;
        public static final int ScrollLayout_labelerFormat = 0x00000001;
    }
}
