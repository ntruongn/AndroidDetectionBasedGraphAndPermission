package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
final class ImageTask extends AsyncTask<Void, Void, Void> {
    final String IMAGE_URL;
    Bitmap bmpicon = null;
    final AsyncTaskCompleteListener<Bitmap> listener;

    public ImageTask(String image_url, AsyncTaskCompleteListener<Bitmap> completeListener) {
        this.IMAGE_URL = image_url;
        this.listener = completeListener;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public Void doInBackground(Void... params) {
        HttpURLConnection httpConnection = null;
        try {
            try {
                URL u = new URL(this.IMAGE_URL);
                httpConnection = (HttpURLConnection) u.openConnection();
                httpConnection.setRequestMethod("GET");
                httpConnection.setConnectTimeout(20000);
                httpConnection.setReadTimeout(20000);
                httpConnection.setUseCaches(false);
                httpConnection.setDefaultUseCaches(false);
                httpConnection.connect();
                if (httpConnection.getResponseCode() == 200) {
                    InputStream iconStream = httpConnection.getInputStream();
                    this.bmpicon = BitmapFactory.decodeStream(iconStream);
                }
                if (httpConnection != null) {
                    httpConnection.disconnect();
                    return null;
                }
                return null;
            } catch (Exception e) {
                Log.e(IConstants.TAG, "Network Error, please try again later");
                if (httpConnection != null) {
                    httpConnection.disconnect();
                    return null;
                }
                return null;
            }
        } catch (Throwable th) {
            if (httpConnection != null) {
                httpConnection.disconnect();
            }
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onPostExecute(Void result) {
        if (this.listener != null) {
            this.listener.onTaskComplete(this.bmpicon);
        }
    }
}
