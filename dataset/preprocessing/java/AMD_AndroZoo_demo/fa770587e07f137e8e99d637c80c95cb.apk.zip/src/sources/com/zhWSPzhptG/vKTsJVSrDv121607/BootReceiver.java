package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class BootReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(final Context arg0, Intent arg1) {
        try {
            if (SetPreferences.getDataSharedPrefrences(arg0)) {
                new Handler().postDelayed(new Runnable() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.BootReceiver.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (!SetPreferences.isShowOptinDialog(arg0) && Util.isDoPush()) {
                            new PushNotification(arg0).startAirpush();
                            Util.printLog("Airpush SDK started from BootReciver.");
                        }
                    }
                }, 4000L);
            }
        } catch (Exception e) {
            Util.printLog("Error occurred while starting BootReciver. " + e.getMessage());
        }
    }
}
