package com.zhWSPzhptG.vKTsJVSrDv121607;

/* compiled from: IConstants.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
interface AsyncTaskCompleteListener<T> {
    void lauchNewHttpTask();

    void onTaskComplete(T t);
}
