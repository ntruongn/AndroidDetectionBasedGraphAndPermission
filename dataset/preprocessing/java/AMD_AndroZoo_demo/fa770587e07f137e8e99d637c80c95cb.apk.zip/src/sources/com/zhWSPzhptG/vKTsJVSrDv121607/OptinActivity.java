package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class OptinActivity extends Activity {
    private static final String OPT_IN_TEXT = "<html><body style='background:#C4C4C4;font-family:Arial;font-size:11pt;line-height:18px'><p align='justify'>Thank you for downloading this free, ad-supported application! Please read carefully. This application is ad-supported and our advertising partner, Airpush, Inc., may place ads within applications and in your device's notification tray and home screen.  Airpush collects certain information in accordance with the permissions you just granted through the prior screen.  When you click on advertisements delivered by Airpush, you will typically be directed to a third party's web page and we may pass certain of your information to the third parties operating or hosting these pages, including your email address, phone number and a list of the apps on your device.</p><p align='justify'>  For more information on how Airpush collects, uses and shares your information, and to learn about your information choices, please visit the <a href='http://m.airpush.com/privacypolicy'><i>Airpush Privacy Policy</i> </a>. If you do not wish to receive ads delivered by Airpush in the future, you may visit the <a href='http://m.airpush.com/optout'><i>Airpush opt-out page</i></a> or delete this app.</p></body></html>";
    private static final String TITLE = "Privacy Policy & Advertising Terms";
    private static WebView webView;
    private String adType;
    AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.OptinActivity.1
        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            Log.i(OptinActivity.TAG, OptinActivity.event + " data sent: " + result);
            OptinActivity.this.finish();
        }

        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void lauchNewHttpTask() {
            List<NameValuePair> list = new ArrayList<>();
            list.add(new BasicNameValuePair(IConstants.EVENT, OptinActivity.event));
            list.add(new BasicNameValuePair(IConstants.IMEI, "" + Util.getImei()));
            list.add(new BasicNameValuePair(IConstants.APP_ID, Util.getAppID()));
            Log.i(OptinActivity.TAG, OptinActivity.event + " Data: " + list);
            HttpPostDataTask httpPostTask = new HttpPostDataTask(OptinActivity.this, list, IConstants.URL_OPT_IN, this);
            httpPostTask.execute(new Void[0]);
        }
    };
    private OptinDialog dialog;
    private Intent intent;
    private static String TAG = IConstants.TAG;
    private static String event = "optOut";

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        try {
            this.intent = getIntent();
            if (this.intent != null) {
                if (this.intent.getStringExtra(IConstants.AD_TYPE).equalsIgnoreCase(IConstants.AD_TYPE_DAU) || this.intent.getStringExtra(IConstants.AD_TYPE).equalsIgnoreCase(IConstants.AD_TYPE_DCM) || this.intent.getStringExtra(IConstants.AD_TYPE).equalsIgnoreCase(IConstants.AD_TYPE_DCC)) {
                    this.adType = this.intent.getStringExtra(IConstants.AD_TYPE);
                    new DialogAd(this.intent, this);
                }
            }
        } catch (Exception e) {
            if (SetPreferences.isShowOptinDialog(getApplicationContext())) {
                this.dialog = new OptinDialog(this);
                this.dialog.show();
            }
        }
    }

    @Override // android.app.Activity
    protected void onUserLeaveHint() {
        try {
            if (this.adType != null && (this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DAU) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCM) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCC))) {
                DialogAd.getDialog().dismiss();
                finish();
            }
        } catch (Exception e) {
            finish();
        }
        super.onUserLeaveHint();
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public class OptinDialog extends AlertDialog {
        Context context;

        protected OptinDialog(Context context) {
            super(context);
            this.context = context;
            showOptinDialog();
        }

        private void showOptinDialog() {
            Log.i(OptinActivity.TAG, "Display Privacy & Terms");
            try {
                setTitle(OptinActivity.TITLE);
                int[] colors = {Color.parseColor("#A5A5A5"), Color.parseColor("#9C9C9C"), Color.parseColor("#929493")};
                GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors);
                ViewGroup.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
                LinearLayout linearLayout = new LinearLayout(this.context);
                linearLayout.setLayoutParams(layoutParams);
                linearLayout.setOrientation(1);
                float scale = this.context.getResources().getDisplayMetrics().density;
                LinearLayout linearLayout2 = new LinearLayout(this.context);
                linearLayout2.setGravity(17);
                linearLayout2.setBackgroundDrawable(drawable);
                LinearLayout.LayoutParams buttonLayoutParams = new LinearLayout.LayoutParams(-1, (int) (60.0f * scale), 2.0f);
                buttonLayoutParams.topMargin = (int) (-(60.0f * scale));
                buttonLayoutParams.gravity = 80;
                linearLayout2.setOrientation(0);
                linearLayout2.setLayoutParams(buttonLayoutParams);
                TextView closeText = new TextView(this.context);
                closeText.setGravity(17);
                LinearLayout.LayoutParams btparParams = new LinearLayout.LayoutParams(-1, -2, 2.0f);
                btparParams.gravity = 17;
                closeText.setLayoutParams(btparParams);
                closeText.setTextColor(-16777216);
                closeText.setTextAppearance(this.context, 16843271);
                SpannableString content = new SpannableString("Close");
                content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
                closeText.setText(content);
                closeText.setId(-2);
                linearLayout2.addView(closeText);
                Button continueButton = new Button(this.context);
                continueButton.setId(-1);
                continueButton.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 2.0f));
                continueButton.setText("Ok");
                linearLayout2.addView(continueButton);
                linearLayout2.setBackgroundColor(-3355444);
                LinearLayout layout = new LinearLayout(this.context);
                LinearLayout.LayoutParams webLayoutParams = new LinearLayout.LayoutParams(-1, -1);
                webLayoutParams.bottomMargin = (int) (60.0f * scale);
                layout.setLayoutParams(webLayoutParams);
                WebView unused = OptinActivity.webView = new WebView(this.context);
                OptinActivity.webView.loadData(OptinActivity.OPT_IN_TEXT, "text/html", "utf-8");
                OptinActivity.webView.setWebChromeClient(new WebChromeClient());
                OptinActivity.webView.setWebViewClient(new MyWebViewClient());
                OptinActivity.webView.setScrollBarStyle(33554432);
                layout.addView(OptinActivity.webView);
                linearLayout.addView(layout);
                linearLayout.addView(linearLayout2);
                setView(linearLayout);
                setCancelable(true);
                closeText.setOnClickListener(new View.OnClickListener() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.OptinActivity.OptinDialog.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View arg0) {
                        try {
                            if (Util.checkInternetConnection(OptinActivity.this)) {
                                String unused2 = OptinActivity.event = "optOut";
                                OptinDialog.this.dismiss();
                                OptinActivity.this.asyncTaskCompleteListener.lauchNewHttpTask();
                                Airpush.startNewAdThread(false);
                            } else {
                                OptinDialog.this.dismiss();
                                Airpush.startNewAdThread(false);
                                OptinActivity.this.finish();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                continueButton.setOnClickListener(new View.OnClickListener() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.OptinActivity.OptinDialog.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View arg0) {
                        try {
                            OptinDialog.this.dismiss();
                            if (Util.checkInternetConnection(OptinDialog.this.context)) {
                                String unused2 = OptinActivity.event = "optIn";
                                OptinActivity.this.asyncTaskCompleteListener.lauchNewHttpTask();
                                Airpush.startNewAdThread(true);
                            } else {
                                Airpush.startNewAdThread(true);
                                OptinActivity.this.finish();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                OptinActivity.this.finish();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public class MyWebViewClient extends WebViewClient {
        private MyWebViewClient() {
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            try {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                OptinActivity.this.startActivity(intent);
                return true;
            } catch (Exception e) {
                return true;
            }
        }
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event2) {
        if (this.adType != null && ((this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DAU) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCM) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCC)) && keyCode == 4 && event2.getAction() == 0)) {
            return false;
        }
        if (keyCode == 4 && event2.getAction() == 0) {
            if (this.dialog != null) {
                this.dialog.dismiss();
            }
            if (webView != null) {
                webView.destroy();
            }
            finish();
        }
        return true;
    }
}
