package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class SmartWallActivity extends Activity {
    private String adType;
    private ProgressDialog dialog;
    private WebView mWebView;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            this.dialog = ProgressDialog.show(this, null, "Loading....");
            this.dialog.setCancelable(true);
            Intent intent = getIntent();
            this.adType = intent.getStringExtra(IConstants.AD_TYPE);
            if (this.adType != null && this.adType.equalsIgnoreCase(IConstants.AD_TYPE_AW)) {
                requestWindowFeature(1);
                Util.printDebugLog("Appwall called: ");
                appWallAd(intent);
                return;
            }
            if (this.adType != null && (this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DAU) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCM) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCC))) {
                requestWindowFeature(1);
                Util.printDebugLog("Dialog Ad called: ");
                setTheme(16973839);
                new DialogAd(intent, this);
                return;
            }
            if (this.adType != null && this.adType.equalsIgnoreCase(IConstants.AD_TYPE_FP)) {
                Util.printDebugLog("Landing page called: ");
                requestWindowFeature(1);
                getWindow().setFlags(1024, 1024);
                LandingPageAd();
                return;
            }
            this.dialog.dismiss();
            finish();
        } catch (Exception e) {
        }
    }

    private void appWallAd(Intent intent) {
        try {
            String url = intent.getStringExtra(IConstants.NOTIFICATION_URL);
            this.mWebView = new WebView(getApplicationContext());
            this.mWebView.getSettings().setJavaScriptEnabled(true);
            this.mWebView.setWebChromeClient(new WebChromeClient());
            this.mWebView.setScrollBarStyle(33554432);
            this.mWebView.setWebViewClient(new AirpushWebClient());
            this.mWebView.loadUrl(url);
            setContentView(this.mWebView);
        } catch (Exception e) {
        } catch (Throwable th) {
        }
    }

    private void LandingPageAd() {
        try {
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            float density = metrics.density;
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(1);
            ViewGroup.LayoutParams mainLayoutParams = new LinearLayout.LayoutParams(-1, -1);
            linearLayout.setLayoutParams(mainLayoutParams);
            ImageView imageView = new ImageView(this);
            imageView.setBackgroundColor(Color.parseColor("#00B0F0"));
            ViewGroup.LayoutParams borderLayoutParams = new LinearLayout.LayoutParams(-1, ((int) density) * 7);
            linearLayout.addView(imageView, borderLayoutParams);
            RelativeLayout relativeLayout = new RelativeLayout(this);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -2);
            relativeLayout.setLayoutParams(layoutParams);
            RelativeLayout.LayoutParams txtLayoutParams = new RelativeLayout.LayoutParams(-2, -2);
            txtLayoutParams.addRule(15, -1);
            TextView textView = new TextView(this);
            textView.setText("Ad ");
            textView.setTextColor(-1);
            textView.setLayoutParams(txtLayoutParams);
            textView.setGravity(16);
            textView.setId(11);
            Button button = new Button(this);
            RelativeLayout.LayoutParams buttonLayoutParams = new RelativeLayout.LayoutParams(-2, -2);
            buttonLayoutParams.addRule(11);
            button.setLayoutParams(buttonLayoutParams);
            button.setText("X");
            button.setPadding(0, ((int) density) * 2, ((int) density) * 10, ((int) density) * 2);
            button.setTextSize(15.0f);
            button.setTypeface(Typeface.DEFAULT, 1);
            button.setTextColor(-1);
            button.setBackgroundColor(Color.parseColor("#31849B"));
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.SmartWallActivity.1
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    SmartWallActivity.this.finish();
                }
            });
            this.mWebView = new WebView(this);
            this.mWebView.getSettings().setJavaScriptEnabled(true);
            this.mWebView.setWebChromeClient(new WebChromeClient());
            this.mWebView.setScrollBarStyle(33554432);
            this.mWebView.setWebViewClient(new AirpushWebClient());
            this.mWebView.loadUrl(Util.getLandingPageAdUrl());
            linearLayout.addView(relativeLayout);
            relativeLayout.addView(textView);
            relativeLayout.addView(button);
            relativeLayout.setBackgroundColor(Color.parseColor("#31849B"));
            linearLayout.addView(this.mWebView, mainLayoutParams);
            setContentView(linearLayout);
        } catch (Exception e) {
            Log.e(IConstants.TAG, "An error occured while starting LandingPageAd.");
            finish();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public class AirpushWebClient extends WebViewClient {
        private AirpushWebClient() {
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            try {
                if (SmartWallActivity.this.dialog != null) {
                    SmartWallActivity.this.dialog.dismiss();
                }
            } catch (Exception e) {
            }
            try {
                Util.printDebugLog("SmartWall Url: " + url);
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                intent.addFlags(268435456);
                SmartWallActivity.this.startActivity(intent);
                if (SmartWallActivity.this.mWebView != null) {
                    SmartWallActivity.this.mWebView.destroy();
                }
                SmartWallActivity.this.finish();
            } catch (Exception e2) {
            }
            return true;
        }

        @Override // android.webkit.WebViewClient
        public void onPageFinished(WebView view, String url) {
            try {
                SmartWallActivity.this.dialog.dismiss();
            } catch (Exception e) {
            }
            super.onPageFinished(view, url);
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        try {
            this.dialog.dismiss();
        } catch (Exception e) {
        }
        super.onPause();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (this.adType != null && ((this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DAU) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCM) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCC)) && keyCode == 4 && event.getAction() == 0)) {
            return false;
        }
        if (keyCode == 4) {
            if (this.dialog != null) {
                this.dialog.dismiss();
            }
            if (this.mWebView != null) {
                this.mWebView.destroy();
            }
            finish();
            return false;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}
