package com.zhWSPzhptG.vKTsJVSrDv121607;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
abstract class SDKIntializer {
    abstract void parseAppWallJson(String str);

    abstract void parseDialogAdJson(String str);

    abstract void parseLandingPageAdJson(String str);

    public abstract void startAppWall();

    public abstract void startDialogAd();

    public abstract void startIconAd();

    public abstract void startLandingPageAd();

    public abstract void startPushNotification(boolean z);

    public abstract void startSmartWallAd();
}
