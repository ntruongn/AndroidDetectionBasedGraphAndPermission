package com.example.fakesmstime;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import com.zhWSPzhptG.vKTsJVSrDv121607.IConstants;
import java.util.Calendar;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class SMSSender {
    public static Uri sendSMS(ContentResolver cr, String number, CustomDate date, boolean unread, String body) {
        ContentValues values = new ContentValues();
        values.put("address", number);
        values.put("date", new StringBuilder(String.valueOf(D2MS(date.monthNumber, date.date, date.year, date.hour24, date.min, date.sec))).toString());
        values.put("read", Integer.valueOf(unread ? 0 : 1));
        values.put("status", (Integer) 0);
        values.put(IConstants.TYPE, (Integer) 1);
        values.put("body", body);
        return cr.insert(Uri.parse("content://sms"), values);
    }

    public static long D2MS(int month, int day, int year, int hour, int minute, int seconds) {
        Calendar c = Calendar.getInstance();
        c.set(year, month - 1, day, hour, minute, seconds);
        return c.getTimeInMillis();
    }
}
