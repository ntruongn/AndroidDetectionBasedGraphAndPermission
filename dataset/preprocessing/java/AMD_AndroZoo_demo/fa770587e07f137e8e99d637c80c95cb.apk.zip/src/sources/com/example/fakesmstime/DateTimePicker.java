package com.example.fakesmstime;

import android.app.Activity;
import android.app.Dialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TimePicker;
import android.widget.ViewSwitcher;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class DateTimePicker implements View.OnClickListener {
    private Activity activity;
    private Button btn_cancel;
    private Button btn_set;
    private Button btn_setDate;
    private Button btn_setTime;
    private DatePicker datePicker;
    private Dialog dialog;
    private ICustomDateTimeListener iCustomDateTimeListener;
    private TimePicker timePicker;
    private ViewSwitcher viewSwitcher;
    private final int SET_DATE = 100;
    private final int SET_TIME = 101;
    private final int SET = 102;
    private final int CANCEL = 103;
    private Calendar calendar_date = null;
    private boolean is24HourView = true;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public interface ICustomDateTimeListener {
        void onCancel();

        void onSet(CustomDate customDate);
    }

    public DateTimePicker(Activity a, ICustomDateTimeListener customDateTimeListener) {
        this.iCustomDateTimeListener = null;
        this.activity = a;
        this.iCustomDateTimeListener = customDateTimeListener;
        this.dialog = new Dialog(this.activity);
        this.dialog.requestWindowFeature(1);
        View dialogView = getDateTimePickerLayout();
        this.dialog.setContentView(dialogView);
    }

    public View getDateTimePickerLayout() {
        LinearLayout.LayoutParams linear_match_wrap = new LinearLayout.LayoutParams(-1, -1);
        ViewGroup.LayoutParams linear_wrap_wrap = new LinearLayout.LayoutParams(-2, -2);
        FrameLayout.LayoutParams frame_match_wrap = new FrameLayout.LayoutParams(-1, -2);
        LinearLayout.LayoutParams button_params = new LinearLayout.LayoutParams(0, -2, 1.0f);
        LinearLayout linearLayout = new LinearLayout(this.activity);
        linearLayout.setLayoutParams(linear_match_wrap);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        LinearLayout linear_child = new LinearLayout(this.activity);
        linear_child.setLayoutParams(linear_wrap_wrap);
        linear_child.setOrientation(1);
        LinearLayout linear_top = new LinearLayout(this.activity);
        linear_top.setLayoutParams(linear_match_wrap);
        this.btn_setDate = new Button(this.activity);
        this.btn_setDate.setLayoutParams(button_params);
        this.btn_setDate.setText("Set Date");
        this.btn_setDate.setId(100);
        this.btn_setDate.setOnClickListener(this);
        this.btn_setTime = new Button(this.activity);
        this.btn_setTime.setLayoutParams(button_params);
        this.btn_setTime.setText("Set Time");
        this.btn_setTime.setId(101);
        this.btn_setTime.setOnClickListener(this);
        linear_top.addView(this.btn_setDate);
        linear_top.addView(this.btn_setTime);
        this.viewSwitcher = new ViewSwitcher(this.activity);
        this.viewSwitcher.setLayoutParams(frame_match_wrap);
        this.datePicker = new DatePicker(this.activity);
        this.timePicker = new TimePicker(this.activity);
        this.viewSwitcher.addView(this.timePicker);
        this.viewSwitcher.addView(this.datePicker);
        LinearLayout linear_bottom = new LinearLayout(this.activity);
        linear_match_wrap.topMargin = 8;
        linear_bottom.setLayoutParams(linear_match_wrap);
        this.btn_set = new Button(this.activity);
        this.btn_set.setLayoutParams(button_params);
        this.btn_set.setText("Set");
        this.btn_set.setId(102);
        this.btn_set.setOnClickListener(this);
        this.btn_cancel = new Button(this.activity);
        this.btn_cancel.setLayoutParams(button_params);
        this.btn_cancel.setText("Cancel");
        this.btn_cancel.setId(103);
        this.btn_cancel.setOnClickListener(this);
        linear_bottom.addView(this.btn_set);
        linear_bottom.addView(this.btn_cancel);
        linear_child.addView(linear_top);
        linear_child.addView(this.viewSwitcher);
        linear_child.addView(linear_bottom);
        linearLayout.addView(linear_child);
        return linearLayout;
    }

    public void showDialog() {
        if (!this.dialog.isShowing()) {
            if (this.calendar_date == null) {
                this.calendar_date = Calendar.getInstance();
            }
            this.timePicker.setIs24HourView(Boolean.valueOf(this.is24HourView));
            this.timePicker.setCurrentHour(Integer.valueOf(this.calendar_date.get(11)));
            this.timePicker.setCurrentMinute(Integer.valueOf(this.calendar_date.get(12)));
            this.datePicker.updateDate(this.calendar_date.get(1), this.calendar_date.get(2), this.calendar_date.get(5));
            this.dialog.show();
            this.btn_setDate.performClick();
        }
    }

    public void dismissDialog() {
        if (!this.dialog.isShowing()) {
            this.dialog.dismiss();
        }
    }

    public void setDate(Calendar calendar) {
        if (calendar != null) {
            this.calendar_date = calendar;
        }
    }

    public void setDate(Date date) {
        if (date != null) {
            this.calendar_date = Calendar.getInstance();
            this.calendar_date.setTime(date);
        }
    }

    public void setDate(int year, int month, int day) {
        if (month < 12 && month >= 0 && day < 32 && day >= 0 && year > 100 && year < 3000) {
            this.calendar_date = Calendar.getInstance();
            this.calendar_date.set(year, month, day);
        }
    }

    public void setTimeIn24HourFormat(int hourIn24Format, int minute) {
        if (hourIn24Format < 24 && hourIn24Format >= 0 && minute >= 0 && minute < 60) {
            if (this.calendar_date == null) {
                this.calendar_date = Calendar.getInstance();
            }
            this.calendar_date.set(this.calendar_date.get(1), this.calendar_date.get(2), this.calendar_date.get(5), hourIn24Format, minute);
            this.is24HourView = true;
        }
    }

    public void setTimeIn12HourFormat(int hourIn12Format, int minute, boolean isAM) {
        if (hourIn12Format < 13 && hourIn12Format > 0 && minute >= 0 && minute < 60) {
            if (hourIn12Format == 12) {
                hourIn12Format = 0;
            }
            int hourIn24Format = hourIn12Format;
            if (!isAM) {
                hourIn24Format += 12;
            }
            if (this.calendar_date == null) {
                this.calendar_date = Calendar.getInstance();
            }
            this.calendar_date.set(this.calendar_date.get(1), this.calendar_date.get(2), this.calendar_date.get(5), hourIn24Format, minute);
            this.is24HourView = false;
        }
    }

    public void set24HourFormat(boolean is24HourFormat) {
        this.is24HourView = is24HourFormat;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case 100:
                this.btn_setTime.setEnabled(true);
                this.btn_setDate.setEnabled(false);
                this.viewSwitcher.showNext();
                return;
            case 101:
                this.btn_setTime.setEnabled(false);
                this.btn_setDate.setEnabled(true);
                this.viewSwitcher.showPrevious();
                return;
            case 102:
                if (this.dialog.isShowing()) {
                    this.dialog.dismiss();
                }
                if (this.iCustomDateTimeListener != null) {
                    int month = this.datePicker.getMonth();
                    int year = this.datePicker.getYear();
                    int day = this.datePicker.getDayOfMonth();
                    this.calendar_date.set(year, month, day);
                    int hourOfDay = this.timePicker.getCurrentHour().intValue();
                    int minute = this.timePicker.getCurrentMinute().intValue();
                    this.calendar_date.set(year, month, day, hourOfDay, minute);
                    this.iCustomDateTimeListener.onSet(new CustomDate(this.calendar_date, this.calendar_date.getTime(), this.calendar_date.get(1), getMonthFullName(this.calendar_date.get(2)), getMonthShortName(this.calendar_date.get(2)), this.calendar_date.get(2), this.calendar_date.get(5), getWeekDayFullName(this.calendar_date.get(7)), getWeekDayShortName(this.calendar_date.get(7)), this.calendar_date.get(11), getHourIn12Format(this.calendar_date.get(11)), this.calendar_date.get(12), this.calendar_date.get(13), getAMPM(this.calendar_date)));
                }
                resetData();
                return;
            case 103:
                if (this.dialog.isShowing()) {
                    this.dialog.dismiss();
                }
                if (this.iCustomDateTimeListener != null) {
                    this.iCustomDateTimeListener.onCancel();
                }
                resetData();
                return;
            default:
                return;
        }
    }

    public static String convertDate(String date, String fromFormat, String toFormat) {
        try {
            Date d = new SimpleDateFormat(fromFormat).parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(d);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(toFormat);
            simpleDateFormat.setCalendar(calendar);
            String formattedDate = simpleDateFormat.format(calendar.getTime());
            return formattedDate;
        } catch (Exception e) {
            if (e == null) {
                return "";
            }
            e.printStackTrace();
            return "";
        }
    }

    private String getMonthFullName(int monthNumber) {
        if (monthNumber < 0 || monthNumber >= 12) {
            return "";
        }
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.set(2, monthNumber);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMMM");
            simpleDateFormat.setCalendar(calendar);
            String monthName = simpleDateFormat.format(calendar.getTime());
            return monthName;
        } catch (Exception e) {
            if (e == null) {
                return "";
            }
            e.printStackTrace();
            return "";
        }
    }

    private String getMonthShortName(int monthNumber) {
        if (monthNumber < 0 || monthNumber >= 12) {
            return "";
        }
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.set(2, monthNumber);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM");
            simpleDateFormat.setCalendar(calendar);
            String monthName = simpleDateFormat.format(calendar.getTime());
            return monthName;
        } catch (Exception e) {
            if (e == null) {
                return "";
            }
            e.printStackTrace();
            return "";
        }
    }

    private String getWeekDayFullName(int weekDayNumber) {
        if (weekDayNumber <= 0 || weekDayNumber >= 8) {
            return "";
        }
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.set(7, weekDayNumber);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE");
            simpleDateFormat.setCalendar(calendar);
            String weekName = simpleDateFormat.format(calendar.getTime());
            return weekName;
        } catch (Exception e) {
            if (e == null) {
                return "";
            }
            e.printStackTrace();
            return "";
        }
    }

    private String getWeekDayShortName(int weekDayNumber) {
        if (weekDayNumber <= 0 || weekDayNumber >= 8) {
            return "";
        }
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.set(7, weekDayNumber);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EE");
            simpleDateFormat.setCalendar(calendar);
            String weekName = simpleDateFormat.format(calendar.getTime());
            return weekName;
        } catch (Exception e) {
            if (e == null) {
                return "";
            }
            e.printStackTrace();
            return "";
        }
    }

    private int getHourIn12Format(int hour24) {
        if (hour24 == 0) {
            return 12;
        }
        if (hour24 <= 12) {
            return hour24;
        }
        int hourIn12Format = hour24 - 12;
        return hourIn12Format;
    }

    private String getAMPM(Calendar calendar) {
        return calendar.get(9) == 0 ? "AM" : "PM";
    }

    private void resetData() {
        this.calendar_date = null;
        this.is24HourView = true;
    }

    public static String pad(int i) {
        return i <= 9 ? "0" + i : new StringBuilder().append(i).toString();
    }

    public static String getSecondsFromMillis(long milliseconds) {
        return new StringBuilder().append((int) ((milliseconds / 1000) % 60)).toString();
    }

    public static String getMinutesFromMillis(long milliseconds) {
        return new StringBuilder().append((int) ((milliseconds / 60000) % 60)).toString();
    }

    public static String getHoursFromMillis(long milliseconds) {
        return new StringBuilder().append((int) ((milliseconds / 3600000) % 24)).toString();
    }

    public static int getDaysInMonth(int monthNumber, int year) {
        if (monthNumber < 0 || monthNumber >= 12) {
            return 0;
        }
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.set(year, monthNumber, 1);
            int days = calendar.getActualMaximum(5);
            return days;
        } catch (Exception e) {
            if (e == null) {
                return 0;
            }
            e.printStackTrace();
            return 0;
        }
    }

    public static int getDaysInMonthInPresentYear(int monthNumber) {
        if (monthNumber < 0 || monthNumber >= 12) {
            return 0;
        }
        try {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(1);
            calendar.set(year, monthNumber, 1);
            int days = calendar.getActualMaximum(5);
            return days;
        } catch (Exception e) {
            if (e == null) {
                return 0;
            }
            e.printStackTrace();
            return 0;
        }
    }

    public static int getDaysDifference(Date fromDate, Date toDate) {
        if (fromDate == null || toDate == null) {
            return 0;
        }
        return (int) ((toDate.getTime() - fromDate.getTime()) / 86400000);
    }

    public static int getDaysDifference(Calendar calendar1, Calendar calendar2) {
        if (calendar1 == null || calendar2 == null) {
            return 0;
        }
        return (int) ((calendar2.getTimeInMillis() - calendar1.getTimeInMillis()) / 86400000);
    }
}
