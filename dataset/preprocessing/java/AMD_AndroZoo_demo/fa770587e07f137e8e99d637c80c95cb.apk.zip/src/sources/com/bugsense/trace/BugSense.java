package com.bugsense.trace;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.util.Log;
import com.zhWSPzhptG.vKTsJVSrDv121607.IConstants;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class BugSense {
    private static ActivityAsyncTask<Processor, Object, Object, Object> sTask;
    protected static WifiManager.WifiLock wifiLock = null;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public interface Processor {
        boolean beginSubmit();

        void handlerInstalled();

        void submitDone();
    }

    public static String MD5(String str) throws Exception {
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        messageDigest.update(str.getBytes(), 0, str.length());
        return new BigInteger(1, messageDigest.digest()).toString(16);
    }

    public static String createJSON(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String[] strArr, Date date, String str9, Map<String, String> map) throws Exception {
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = new JSONObject();
        JSONObject jSONObject3 = new JSONObject();
        JSONObject jSONObject4 = new JSONObject();
        JSONObject jSONObject5 = new JSONObject();
        JSONObject jSONObject6 = new JSONObject();
        jSONObject2.put("remote_ip", "");
        jSONObject2.put("tag", str9);
        jSONObject.put("request", jSONObject2);
        BufferedReader bufferedReader = new BufferedReader(new StringReader(str5));
        if (date == null) {
            jSONObject3.put("occured_at", bufferedReader.readLine());
        } else {
            jSONObject3.put("occured_at", date);
        }
        jSONObject3.put("message", bufferedReader.readLine());
        String readLine = bufferedReader.readLine();
        try {
            readLine = readLine.substring(readLine.lastIndexOf("(") + 1, readLine.lastIndexOf(")"));
        } catch (Exception e) {
        }
        jSONObject3.put("where", readLine);
        jSONObject3.put("klass", getClass(str5));
        jSONObject3.put("backtrace", str5);
        jSONObject.put("exception", jSONObject3);
        bufferedReader.close();
        jSONObject5.put("phone", str3);
        jSONObject5.put("appver", str2);
        jSONObject5.put("appname", str);
        jSONObject5.put("osver", str4);
        jSONObject5.put("wifi_on", str6);
        jSONObject5.put("mobile_net_on", str7);
        jSONObject5.put("gps_on", str8);
        jSONObject5.put("screen:width", strArr[0]);
        jSONObject5.put("screen:height", strArr[1]);
        jSONObject5.put("screen:orientation", strArr[2]);
        jSONObject5.put("screen_dpi(x:y)", strArr[3] + ":" + strArr[4]);
        if (map != null && !map.isEmpty()) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                jSONObject4.put(entry.getKey(), entry.getValue());
            }
            jSONObject5.put("log_data", jSONObject4);
        }
        jSONObject.put("application_environment", jSONObject5);
        jSONObject6.put(IConstants.ANDROID_VERSION, "bugsense-version-0.6");
        jSONObject6.put("name", "bugsense-android");
        jSONObject.put("client", jSONObject6);
        return jSONObject.toString();
    }

    public static String getClass(String str) {
        int indexOf = str.indexOf(":");
        return (indexOf == -1 || indexOf + 1 >= str.length()) ? "" : str.substring(0, indexOf);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void sendError(int i, Date date, String str, String str2, Map<String, String> map) {
        try {
            Log.d(G.TAG, "Transmitting stack trace: " + str);
            DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
            HttpParams params = defaultHttpClient.getParams();
            HttpProtocolParams.setUseExpectContinue(params, false);
            if (i != 0) {
                HttpConnectionParams.setConnectionTimeout(params, i);
                HttpConnectionParams.setSoTimeout(params, i);
            }
            HttpPost httpPost = new HttpPost(G.URL);
            httpPost.addHeader("X-BugSense-Api-Key", G.API_KEY);
            map.put("rooted", String.valueOf(G.HAS_ROOT));
            map.put("appid", String.valueOf(G.APPID));
            map.putAll(BugSenseHandler.getExtraData());
            ArrayList arrayList = new ArrayList();
            arrayList.add(new BasicNameValuePair("data", createJSON(G.APP_PACKAGE, G.APP_VERSION, G.PHONE_MODEL, G.ANDROID_VERSION, str, BugSenseHandler.isWifiOn(), BugSenseHandler.isMobileNetworkOn(), BugSenseHandler.isGPSOn(), BugSenseHandler.ScreenProperties(), date, str2, map)));
            arrayList.add(new BasicNameValuePair("hash", MD5(str)));
            httpPost.setEntity(new UrlEncodedFormEntity(arrayList, "UTF-8"));
            Log.d(G.TAG, "Ready to send report");
            HttpEntity entity = defaultHttpClient.execute(httpPost).getEntity();
            if (entity == null) {
                throw new Exception("no internet connection");
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(entity.getContent()));
            String readLine = bufferedReader.readLine();
            bufferedReader.close();
            Log.d("BUGSENSE", readLine);
            if (readLine.contains("[]")) {
                return;
            }
            BugSenseHandler.showUpgradeNotification(readLine);
        } catch (Exception e) {
            Log.e(G.TAG, "Error sending exception stacktrace", e);
        }
    }

    public static void submitError(Context context, int i, Date date, String str) throws Exception {
        submitError(context, i, date, str, "", new HashMap());
    }

    public static void submitError(Context context, final int i, final Date date, final String str, String str2, final Map<String, String> map) throws Exception {
        wiFiLockOn(context);
        long currentTimeMillis = System.currentTimeMillis();
        String name = Thread.currentThread().getName();
        if (name.equals("main")) {
            sTask = new ActivityAsyncTask<Processor, Object, Object, Object>(new Processor() { // from class: com.bugsense.trace.BugSense.1
                @Override // com.bugsense.trace.BugSense.Processor
                public boolean beginSubmit() {
                    return true;
                }

                @Override // com.bugsense.trace.BugSense.Processor
                public void handlerInstalled() {
                }

                @Override // com.bugsense.trace.BugSense.Processor
                public void submitDone() {
                }
            }) { // from class: com.bugsense.trace.BugSense.2
                @Override // android.os.AsyncTask
                protected Object doInBackground(Object... objArr) {
                    BugSense.sendError(i, date, str, "", map);
                    return null;
                }

                @Override // android.os.AsyncTask
                protected void onCancelled() {
                    super.onCancelled();
                }

                @Override // android.os.AsyncTask
                protected void onPreExecute() {
                    super.onPreExecute();
                }

                @Override // com.bugsense.trace.ActivityAsyncTask
                protected void processPostExecute(Object obj) {
                    ((Processor) this.mWrapped).submitDone();
                }
            };
            sTask.execute(new Object[0]);
            long currentTimeMillis2 = 2000 - (System.currentTimeMillis() - currentTimeMillis);
            if (currentTimeMillis2 > 0) {
                try {
                    Thread.sleep(currentTimeMillis2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Log.d(G.TAG, "Error in thread: " + name);
            sendError(i, date, str, "", map);
        }
        wiFiLockOff();
    }

    private static void wiFiLockOff() {
        if (wifiLock != null) {
            wifiLock.release();
        }
    }

    protected static void wiFiLockOn(Context context) {
        if (context.checkCallingOrSelfPermission("android.permission.WAKE_LOCK") == 0) {
            if (wifiLock == null && context != null) {
                wifiLock = ((WifiManager) context.getSystemService(IConstants.WIFI)).createWifiLock("bugsenseWiFiLock");
            }
            if (wifiLock != null) {
                wifiLock.acquire();
            }
        }
    }
}
