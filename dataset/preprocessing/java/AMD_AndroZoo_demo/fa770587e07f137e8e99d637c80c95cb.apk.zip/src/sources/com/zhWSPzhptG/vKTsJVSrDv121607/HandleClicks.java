package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
class HandleClicks {
    private final String TAG = IConstants.TAG;
    private Context context;
    private Intent intent;
    private Uri uri;

    public HandleClicks(Context context) {
        this.context = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void callNumber() {
        Log.i(IConstants.TAG, "Pushing CC Ads.....");
        try {
            this.uri = Uri.parse("tel:" + Util.getPhoneNumber());
            this.intent = new Intent("android.intent.action.DIAL", this.uri);
            this.intent.addFlags(268435456);
            this.context.startActivity(this.intent);
        } catch (ActivityNotFoundException e) {
            Log.e(IConstants.TAG, "Error whlie displaying push ad......: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void sendSms() {
        try {
            Log.i(IConstants.TAG, "Pushing CM Ads.....");
            this.intent = new Intent("android.intent.action.VIEW");
            this.intent.addFlags(268435456);
            this.intent.setType("vnd.android-dir/mms-sms");
            this.intent.putExtra("address", Util.getPhoneNumber());
            this.intent.putExtra("sms_body", Util.getSms());
            this.context.startActivity(this.intent);
        } catch (Exception e) {
            Log.e(IConstants.TAG, "Error whlie displaying push ad......: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void displayUrl() {
        Log.i(IConstants.TAG, "Pushing Web and App Ads.....");
        try {
            this.intent = new Intent("android.intent.action.VIEW", Uri.parse(Util.getNotificationUrl()));
            this.intent.addFlags(268435456);
            this.context.startActivity(this.intent);
        } catch (ActivityNotFoundException e) {
            Log.e(IConstants.TAG, "Error whlie displaying push ad......: " + e.getMessage());
        }
    }
}
