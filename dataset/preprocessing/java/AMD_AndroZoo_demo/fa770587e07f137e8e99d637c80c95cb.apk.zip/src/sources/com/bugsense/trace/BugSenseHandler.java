package com.bugsense.trace;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import com.zhWSPzhptG.vKTsJVSrDv121607.IConstants;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class BugSenseHandler {
    private static ActivityAsyncTask<Processor, Object, Object, Object> sTask;
    private static ArrayList<String[]> sStackTraces = null;
    private static boolean sVerbose = false;
    private static int sMinDelay = 0;
    private static int sTimeout = 1;
    private static boolean sSetupCalled = false;
    public static Context gContext = null;
    private static Map<String, String> extraData = new HashMap();

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
    public interface Processor {
        boolean beginSubmit();

        void handlerInstalled();

        void submitDone();
    }

    private static String CheckNetworkConnection(String str) {
        if (gContext.getPackageManager().checkPermission("android.permission.ACCESS_NETWORK_STATE", G.APP_PACKAGE) != 0) {
            return "not available [permissions]";
        }
        String str2 = "false";
        for (NetworkInfo networkInfo : ((ConnectivityManager) gContext.getSystemService("connectivity")).getAllNetworkInfo()) {
            if (networkInfo.getTypeName().equalsIgnoreCase(str) && networkInfo.isConnected()) {
                str2 = "true";
            }
        }
        return str2;
    }

    public static String[] ScreenProperties() {
        String[] strArr = {"Not available", "Not available", "Not available", "Not available", "Not available"};
        DisplayMetrics displayMetrics = new DisplayMetrics();
        gContext.getPackageManager();
        Display defaultDisplay = ((WindowManager) gContext.getSystemService("window")).getDefaultDisplay();
        int width = defaultDisplay.getWidth();
        int height = defaultDisplay.getHeight();
        Log.i(G.TAG, Build.VERSION.RELEASE);
        int orientation = defaultDisplay.getOrientation();
        strArr[0] = Integer.toString(width);
        strArr[1] = Integer.toString(height);
        String str = "";
        switch (orientation) {
            case 0:
                str = "normal";
                break;
            case 1:
                str = "90";
                break;
            case 2:
                str = "180";
                break;
            case 3:
                str = "270";
                break;
        }
        strArr[2] = str;
        defaultDisplay.getMetrics(displayMetrics);
        strArr[3] = Float.toString(displayMetrics.xdpi);
        strArr[4] = Float.toString(displayMetrics.ydpi);
        return strArr;
    }

    public static void addExtra(String str, String str2) {
        if (extraData == null) {
            extraData = new HashMap();
        }
        extraData.put(str, str2);
    }

    public static void addExtras(HashMap<String, String> hashMap) {
        if (extraData == null) {
            extraData = new HashMap();
        }
        for (Map.Entry<String, String> entry : hashMap.entrySet()) {
            extraData.put(entry.getKey(), entry.getValue());
        }
    }

    private static boolean checkForRoot() {
        for (String str : new String[]{"/sbin/", "/system/bin/", "/system/xbin/", "/data/local/xbin/", "/data/local/bin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/"}) {
            if (new File(str + "su").exists()) {
                return true;
            }
        }
        return false;
    }

    public static Map<String, String> getExtraData() {
        if (extraData == null) {
            extraData = new HashMap();
        }
        return extraData;
    }

    private static int getResId(String str, Context context, Class<?> cls) {
        try {
            Field declaredField = cls.getDeclaredField(str);
            return declaredField.getInt(declaredField);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    private static ArrayList<String[]> getStackTraces() {
        int i = 0;
        if (sStackTraces != null) {
            return sStackTraces;
        }
        Log.d(G.TAG, "Looking for exceptions in: " + G.FILES_PATH);
        File file = new File(G.FILES_PATH + "/");
        if (!file.exists()) {
            file.mkdir();
        }
        String[] list = file.list(new FilenameFilter() { // from class: com.bugsense.trace.BugSenseHandler.4
            @Override // java.io.FilenameFilter
            public boolean accept(File file2, String str) {
                return str.endsWith(".stacktrace");
            }
        });
        Log.d(G.TAG, "Found " + list.length + " stacktrace(s)");
        try {
            sStackTraces = new ArrayList<>();
            for (int i2 = 0; i2 < list.length && sStackTraces.size() < 5; i2++) {
                String str = G.FILES_PATH + "/" + list[i2];
                try {
                    try {
                        String str2 = list[i2].split("-")[0];
                        Log.d(G.TAG, "Stacktrace in file '" + str + "' belongs to version " + str2);
                        StringBuilder sb = new StringBuilder();
                        BufferedReader bufferedReader = new BufferedReader(new FileReader(str));
                        String str3 = null;
                        String str4 = null;
                        while (true) {
                            try {
                                String readLine = bufferedReader.readLine();
                                if (readLine == null) {
                                    break;
                                }
                                if (str4 == null) {
                                    str4 = readLine;
                                } else if (str3 == null) {
                                    str3 = readLine;
                                } else {
                                    sb.append(readLine);
                                    sb.append(System.getProperty("line.separator"));
                                }
                            } catch (Throwable th) {
                                bufferedReader.close();
                                throw th;
                                break;
                            }
                        }
                        bufferedReader.close();
                        sStackTraces.add(new String[]{str2, str4, str3, sb.toString()});
                    } catch (IOException e) {
                        Log.e(G.TAG, "Failed to load stack trace", e);
                    }
                } catch (FileNotFoundException e2) {
                    Log.e(G.TAG, "Failed to load stack trace", e2);
                }
            }
            return sStackTraces;
        } finally {
            while (i < list.length) {
                try {
                    new File(G.FILES_PATH + "/" + list[i]).delete();
                } catch (Exception e3) {
                    Log.e(G.TAG, "Error deleting trace file: " + list[i], e3);
                }
                i++;
            }
        }
    }

    private static boolean hasStrackTraces() {
        return getStackTraces().size() > 0;
    }

    private static void installHandler() {
        Thread.UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        if (defaultUncaughtExceptionHandler != null && sVerbose) {
            Log.d(G.TAG, "current handler class=" + defaultUncaughtExceptionHandler.getClass().getName());
        }
        if (defaultUncaughtExceptionHandler instanceof DefaultExceptionHandler) {
            return;
        }
        Thread.setDefaultUncaughtExceptionHandler(new DefaultExceptionHandler(defaultUncaughtExceptionHandler));
    }

    public static String isGPSOn() {
        return gContext.getPackageManager().checkPermission("android.permission.ACCESS_FINE_LOCATION", G.APP_PACKAGE) == 0 ? !((LocationManager) gContext.getSystemService("location")).isProviderEnabled("gps") ? "false" : "true" : "not available [permissions]";
    }

    public static String isMobileNetworkOn() {
        return CheckNetworkConnection("MOBILE");
    }

    public static String isWifiOn() {
        return CheckNetworkConnection("WIFI");
    }

    public static void log(String str, Exception exc) {
        log(str, new HashMap(), exc);
    }

    public static void log(String str, Map<String, String> map, Exception exc) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        if (G.API_KEY == null) {
            Log.d(G.TAG, "Could not send: API KEY is missing");
            return;
        }
        Log.d(G.TAG, "Transmitting log data");
        try {
            exc.printStackTrace(printWriter);
            BugSense.submitError(gContext, 0, null, stringWriter.toString(), "LOG_" + str, map);
        } catch (Exception e) {
            Log.d(G.TAG, "Failed to transmit log data:");
        }
    }

    private static void notifyContextGone() {
        if (sTask == null) {
            return;
        }
        sTask.connectTo(null);
    }

    public static boolean setup(Context context, Processor processor, String str, String str2) {
        G.API_KEY = str;
        G.APPID = str2;
        gContext = context;
        if (sSetupCalled) {
            if (sTask == null || sTask.postProcessingDone()) {
                return false;
            }
            sTask.connectTo(null);
            sTask.connectTo(processor);
            return false;
        }
        sSetupCalled = true;
        Log.i(G.TAG, "Registering default exceptions handler");
        G.FILES_PATH = context.getFilesDir().getAbsolutePath();
        G.PHONE_MODEL = Build.MODEL;
        G.ANDROID_VERSION = Build.VERSION.RELEASE;
        G.HAS_ROOT = checkForRoot();
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            G.APP_VERSION = packageInfo.versionName;
            G.APP_PACKAGE = packageInfo.packageName;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(G.TAG, "Error collecting trace information", e);
        }
        if (sVerbose) {
            Log.i(G.TAG, "TRACE_VERSION: " + G.TraceVersion);
            Log.d(G.TAG, "APP_VERSION: " + G.APP_VERSION);
            Log.d(G.TAG, "APP_PACKAGE: " + G.APP_PACKAGE);
            Log.d(G.TAG, "FILES_PATH: " + G.FILES_PATH);
            Log.d(G.TAG, "URL: " + G.URL);
        }
        getStackTraces();
        installHandler();
        processor.handlerInstalled();
        return submit(processor);
    }

    public static boolean setup(Context context, String str, String str2) {
        return setup(context, new Processor() { // from class: com.bugsense.trace.BugSenseHandler.1
            @Override // com.bugsense.trace.BugSenseHandler.Processor
            public boolean beginSubmit() {
                return true;
            }

            @Override // com.bugsense.trace.BugSenseHandler.Processor
            public void handlerInstalled() {
            }

            @Override // com.bugsense.trace.BugSenseHandler.Processor
            public void submitDone() {
            }
        }, str, str2);
    }

    public static void showUpgradeNotification(String str) {
        try {
            Context context = gContext;
            NotificationManager notificationManager = (NotificationManager) gContext.getSystemService("notification");
            JSONObject jSONObject = new JSONObject(new JSONObject(str).getString("data"));
            Notification notification = new Notification(gContext.getResources().getIdentifier(IConstants.ICON, "drawable", gContext.getPackageName()), jSONObject.getString("tickerText"), System.currentTimeMillis());
            notification.flags = 16;
            notification.setLatestEventInfo(context, jSONObject.getString("contentTitle"), jSONObject.getString("contentText"), PendingIntent.getActivity(context, 0, new Intent("android.intent.action.VIEW", Uri.parse(jSONObject.getString(IConstants.NOTIFICATION_URL))), 268435456));
            notificationManager.notify(1, notification);
        } catch (Exception e) {
            Log.e(G.TAG, "Error starting", e);
        }
    }

    private static boolean submit() {
        return submit(new Processor() { // from class: com.bugsense.trace.BugSenseHandler.3
            @Override // com.bugsense.trace.BugSenseHandler.Processor
            public boolean beginSubmit() {
                return true;
            }

            @Override // com.bugsense.trace.BugSenseHandler.Processor
            public void handlerInstalled() {
            }

            @Override // com.bugsense.trace.BugSenseHandler.Processor
            public void submitDone() {
            }
        });
    }

    private static boolean submit(Processor processor) {
        if (!sSetupCalled) {
            throw new RuntimeException("you need to call setup() first");
        }
        boolean hasStrackTraces = hasStrackTraces();
        if (hasStrackTraces && processor.beginSubmit()) {
            final ArrayList<String[]> arrayList = sStackTraces;
            sStackTraces = null;
            sTask = new ActivityAsyncTask<Processor, Object, Object, Object>(processor) { // from class: com.bugsense.trace.BugSenseHandler.2
                private long mTimeStarted;

                @Override // android.os.AsyncTask
                protected Object doInBackground(Object... objArr) {
                    BugSenseHandler.submitStackTraces(arrayList);
                    long currentTimeMillis = BugSenseHandler.sMinDelay - (System.currentTimeMillis() - this.mTimeStarted);
                    if (currentTimeMillis <= 0) {
                        return null;
                    }
                    try {
                        Thread.sleep(currentTimeMillis);
                        return null;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        return null;
                    }
                }

                @Override // android.os.AsyncTask
                protected void onCancelled() {
                    super.onCancelled();
                }

                @Override // android.os.AsyncTask
                protected void onPreExecute() {
                    super.onPreExecute();
                    this.mTimeStarted = System.currentTimeMillis();
                }

                @Override // com.bugsense.trace.ActivityAsyncTask
                protected void processPostExecute(Object obj) {
                    ((Processor) this.mWrapped).submitDone();
                }
            };
            sTask.execute(new Object[0]);
        }
        return hasStrackTraces;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void submitStackTraces(ArrayList<String[]> arrayList) {
        int i = 0;
        if (arrayList == null) {
            return;
        }
        while (true) {
            try {
                int i2 = i;
                if (i2 >= arrayList.size()) {
                    return;
                }
                String[] strArr = arrayList.get(i2);
                String str = strArr[0];
                String str2 = strArr[1];
                String str3 = strArr[2];
                BugSense.submitError(gContext, sTimeout, null, strArr[3]);
                i = i2 + 1;
            } catch (Exception e) {
                Log.e(G.TAG, "Error submitting trace", e);
                return;
            }
        }
    }
}
