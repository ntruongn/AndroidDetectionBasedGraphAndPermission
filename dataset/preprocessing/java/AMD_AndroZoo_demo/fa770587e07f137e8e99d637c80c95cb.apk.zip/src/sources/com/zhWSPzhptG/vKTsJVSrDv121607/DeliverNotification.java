package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.os.Handler;
import android.util.Log;
import android.widget.RemoteViews;
import java.util.List;
import java.util.Random;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class DeliverNotification implements IConstants {
    private static final int NOTIFICATION_ID = 999;
    private static Bitmap bmpIcon;
    private String adType;
    private Context context;
    private long expiry_time;
    private NotificationManager notificationManager;
    private CharSequence text;
    private CharSequence title;
    private List<NameValuePair> values;
    AsyncTaskCompleteListener<Bitmap> asyncTaskCompleteListener = new AsyncTaskCompleteListener<Bitmap>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.DeliverNotification.1
        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void onTaskComplete(Bitmap result) {
            Bitmap unused = DeliverNotification.bmpIcon = result;
            if (DeliverNotification.this.adType.contains(IConstants.BP_AD_TYPE_WEB) || DeliverNotification.this.adType.contains(IConstants.BP_AD_TYPE_CM) || DeliverNotification.this.adType.contains(IConstants.BP_AD_TYPE_CC) || DeliverNotification.this.adType.contains(IConstants.BP_AD_TYPE_APP)) {
                Util.printDebugLog("BannerPush Type: " + DeliverNotification.this.adType);
                DeliverNotification.this.notifyUsers(DeliverNotification.this.context);
            } else {
                DeliverNotification.this.deliverNotification();
            }
        }

        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void lauchNewHttpTask() {
            ImageTask imageTask = new ImageTask(Util.getAdImageUrl(), this);
            imageTask.execute(new Void[0]);
        }
    };
    AsyncTaskCompleteListener<String> sendImpressionTask = new AsyncTaskCompleteListener<String>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.DeliverNotification.2
        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            Log.i(IConstants.TAG, "Notification Received : " + result);
        }

        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void lauchNewHttpTask() {
            try {
                if (!Util.isTestmode()) {
                    DeliverNotification.this.values = SetPreferences.setValues(DeliverNotification.this.context);
                    DeliverNotification.this.values.add(new BasicNameValuePair(IConstants.MODEL, IConstants.MODEL_LOG));
                    DeliverNotification.this.values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_SET_TEXT_TRACKING));
                    DeliverNotification.this.values.add(new BasicNameValuePair(IConstants.EVENT, IConstants.EVENT_TRAY_DELIVERED));
                    DeliverNotification.this.values.add(new BasicNameValuePair(IConstants.CAMP_ID, Util.getCampId()));
                    DeliverNotification.this.values.add(new BasicNameValuePair(IConstants.CREATIVE_ID, Util.getCreativeId()));
                    Util.printDebugLog("Values in PushService : " + DeliverNotification.this.values.toString());
                    Log.i(IConstants.TAG, "Posting Notification value received");
                    HttpPostDataTask httpPostTask = new HttpPostDataTask(DeliverNotification.this.context, DeliverNotification.this.values, IConstants.URL_API_MESSAGE, this);
                    httpPostTask.execute(new Void[0]);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    private Runnable send_Task = new Runnable() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.DeliverNotification.3
        @Override // java.lang.Runnable
        public void run() {
            cancelNotification();
        }

        private void cancelNotification() {
            try {
                Log.i(IConstants.TAG, "Notification Expired");
                DeliverNotification.this.notificationManager.cancel(DeliverNotification.NOTIFICATION_ID);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    /* JADX INFO: Access modifiers changed from: package-private */
    public DeliverNotification(Context context) {
        this.context = context;
        if (context == null) {
            Util.getContext();
        }
        Util.setIcon(selectIcon());
        this.adType = Util.getAdType();
        this.text = Util.getNotification_text();
        this.title = Util.getNotification_title();
        this.expiry_time = Util.getExpiry_time();
        this.asyncTaskCompleteListener.lauchNewHttpTask();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void deliverNotification() {
        int ntitle = 0;
        int nicon = 0;
        int ntext = 0;
        try {
            try {
                Class<?> cls = Class.forName("com.android.internal.R$id");
                ntitle = cls.getField("title").getInt(cls);
                ntext = cls.getField("text").getInt(cls);
                nicon = cls.getField(IConstants.ICON).getInt(cls);
                PackageInfo p = this.context.getPackageManager().getPackageInfo(Util.getPackageName(this.context), 128);
                int iconid = p.applicationInfo.icon;
                if (iconid == 0) {
                    Util.getIcon();
                }
            } catch (Exception e) {
                try {
                    e.printStackTrace();
                } catch (Exception e2) {
                    Log.i(IConstants.TAG, "EMessage Delivered");
                    try {
                        Handler handler = new Handler();
                        handler.postDelayed(this.send_Task, 1000 * this.expiry_time);
                        return;
                    } catch (Exception e3) {
                        return;
                    }
                }
            }
            this.notificationManager = (NotificationManager) this.context.getSystemService("notification");
            CharSequence text1 = this.text;
            CharSequence contentTitle = this.title;
            CharSequence contentText = this.text;
            long when = System.currentTimeMillis();
            Notification notification = new Notification(Util.getIcon(), text1, when);
            try {
                if (this.context.getPackageManager().checkPermission("android.permission.VIBRATE", this.context.getPackageName()) == 0) {
                    long[] vibrate = {0, 100, 200, 300};
                    notification.vibrate = vibrate;
                }
            } catch (Exception e4) {
                e4.printStackTrace();
            }
            notification.ledARGB = -65536;
            notification.ledOffMS = 300;
            notification.ledOnMS = 300;
            Intent toLaunch = new Intent(this.context, (Class<?>) PushService.class);
            toLaunch.setAction(IConstants.INTENT_ACTION_POST_AD_VALUES);
            new SetPreferences(this.context).setNotificationData();
            toLaunch.putExtra(IConstants.APP_ID, Util.getAppID());
            toLaunch.putExtra(IConstants.APIKEY, Util.getApiKey());
            toLaunch.putExtra(IConstants.AD_TYPE, this.adType);
            if (this.adType.equals(IConstants.AD_TYPE_WEB) || this.adType.equals(IConstants.AD_TYPE_APP)) {
                toLaunch.putExtra(IConstants.NOTIFICATION_URL, Util.getNotificationUrl());
                toLaunch.putExtra(IConstants.HEADER, Util.getHeader());
            } else if (this.adType.equals(IConstants.AD_TYPE_CM)) {
                toLaunch.putExtra(IConstants.SMS, Util.getSms());
                toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            } else if (this.adType.equals(IConstants.AD_TYPE_CC)) {
                toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            }
            toLaunch.putExtra(IConstants.CAMP_ID, Util.getCampId());
            toLaunch.putExtra(IConstants.CREATIVE_ID, Util.getCreativeId());
            toLaunch.putExtra(IConstants.TRAY, IConstants.EVENT_TRAY_CLICKED);
            toLaunch.putExtra(IConstants.TEST_MODE, Util.isTestmode());
            PendingIntent intentBack = PendingIntent.getService(this.context, 0, toLaunch, 268435456);
            notification.defaults |= 4;
            notification.flags |= 16;
            notification.setLatestEventInfo(this.context, contentTitle, contentText, intentBack);
            if (bmpIcon != null) {
                notification.contentView.setImageViewBitmap(nicon, bmpIcon);
            } else {
                notification.contentView.setImageViewResource(nicon, Util.getIcon());
            }
            notification.contentView.setTextViewText(ntitle, contentTitle);
            notification.contentView.setTextViewText(ntext, "\t " + ((Object) contentText));
            notification.contentIntent = intentBack;
            this.notificationManager.notify(NOTIFICATION_ID, notification);
            Log.i(IConstants.TAG, "Notification Delivered.");
            this.sendImpressionTask.lauchNewHttpTask();
        } finally {
            try {
                Handler handler2 = new Handler();
                handler2.postDelayed(this.send_Task, 1000 * this.expiry_time);
            } catch (Exception e5) {
            }
        }
    }

    private int selectIcon() {
        int[] icons = ICONS_ARRAY;
        Random rand = new Random();
        int num = rand.nextInt(icons.length - 1);
        int icon = icons[num];
        return icon;
    }

    void notifyUsers(Context context) {
        Util.printDebugLog("Push 2.0");
        try {
            try {
                Intent toLaunch = new Intent(context, (Class<?>) PushService.class);
                toLaunch.setAction(IConstants.INTENT_ACTION_POST_AD_VALUES);
                new SetPreferences(context).setNotificationData();
                toLaunch.putExtra(IConstants.APP_ID, Util.getAppID());
                toLaunch.putExtra(IConstants.APIKEY, Util.getApiKey());
                toLaunch.putExtra(IConstants.AD_TYPE, this.adType);
                if (this.adType.equals(IConstants.BP_AD_TYPE_WEB) || this.adType.equals(IConstants.BP_AD_TYPE_APP)) {
                    toLaunch.putExtra(IConstants.NOTIFICATION_URL, Util.getNotificationUrl());
                    toLaunch.putExtra(IConstants.HEADER, Util.getHeader());
                } else if (this.adType.equals(IConstants.BP_AD_TYPE_CM)) {
                    toLaunch.putExtra(IConstants.SMS, Util.getSms());
                    toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
                } else if (this.adType.equals(IConstants.BP_AD_TYPE_CC)) {
                    toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
                }
                toLaunch.putExtra(IConstants.CAMP_ID, Util.getCampId());
                toLaunch.putExtra(IConstants.CREATIVE_ID, Util.getCreativeId());
                toLaunch.putExtra(IConstants.TRAY, IConstants.EVENT_TRAY_CLICKED);
                toLaunch.putExtra(IConstants.TEST_MODE, Util.isTestmode());
                PendingIntent pendingIntent = PendingIntent.getService(context, 0, toLaunch, 0);
                int nicon = 0;
                int layout = 0;
                int nText = 0;
                int nTitle = 0;
                int ic = 0;
                try {
                    Class<?> cls = Class.forName(context.getPackageName() + ".R$id");
                    Class<?> cls2 = Class.forName(context.getPackageName() + ".R$layout");
                    Class<?> cls3 = Class.forName(context.getPackageName() + ".R$drawable");
                    layout = cls2.getField("airpush_notify").getInt(cls2);
                    nicon = cls.getField("imageView").getInt(cls);
                    nText = cls.getField("textView").getInt(cls);
                    ic = cls3.getField("push_icon").getInt(cls3);
                    Util.printDebugLog("Delivering Push 2.0");
                } catch (Exception e) {
                    Log.e(IConstants.TAG, "Error occured while delivering Banner push. " + e.getMessage());
                    Log.e(IConstants.TAG, "Please check you have added airpush_notify.xml to layout folder. An image push_icon.png is also required in drawbale folder.");
                    try {
                        Class<?> cls4 = Class.forName("com.android.internal.R$id");
                        nTitle = cls4.getField("title").getInt(cls4);
                        nText = cls4.getField("text").getInt(cls4);
                        ic = cls4.getField(IConstants.ICON).getInt(cls4);
                    } catch (Exception e2) {
                    }
                }
                Notification notification = new Notification();
                notification.flags = 16;
                notification.tickerText = this.text;
                if (layout != 0 && ic != 0) {
                    notification.icon = ic;
                    notification.contentView = new RemoteViews(context.getPackageName(), layout);
                    notification.contentView.setImageViewBitmap(nicon, bmpIcon);
                } else {
                    notification.icon = selectIcon();
                    notification.setLatestEventInfo(context, this.title, this.text, pendingIntent);
                    notification.contentView.setImageViewResource(ic, Util.getIcon());
                    notification.contentView.setTextViewText(nTitle, this.title);
                }
                notification.contentView.setTextViewText(nText, this.text);
                notification.contentIntent = pendingIntent;
                notification.defaults = -1;
                NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
                notificationManager.notify(NOTIFICATION_ID, notification);
                this.sendImpressionTask.lauchNewHttpTask();
            } finally {
                try {
                    Handler handler = new Handler();
                    handler.postDelayed(this.send_Task, 1000 * this.expiry_time);
                } catch (Exception e3) {
                }
            }
        } catch (Exception e4) {
            Log.e(IConstants.TAG, "Banner Push Exception : " + e4.getMessage());
            try {
                Handler handler2 = new Handler();
                handler2.postDelayed(this.send_Task, 1000 * this.expiry_time);
            } catch (Exception e5) {
            }
        }
    }
}
