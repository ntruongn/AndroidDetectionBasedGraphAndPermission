package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class IconAds implements IConstants {
    private Intent addIntent;
    private Bitmap bmpicon;
    private String campaignId;
    private String creativeId;
    private String iconImage;
    private String[] iconImageArr;
    private String iconText;
    private String[] iconTextArr;
    private String iconUrl;
    private String[] iconUrlArr;
    private JSONObject jsonObject;
    private Context mContext;
    private JSONObject post;
    private String[] campaignArr = null;
    private String[] creativeArr = null;
    private boolean sendInstall = true;
    AsyncTaskCompleteListener<Bitmap> getIconImageListener = new AsyncTaskCompleteListener<Bitmap>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.IconAds.1
        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void onTaskComplete(Bitmap result) {
            if (result != null) {
                IconAds.this.bmpicon = result;
                IconAds.this.createShortcut();
            }
        }

        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void lauchNewHttpTask() {
            ImageTask imageTask = new ImageTask(IconAds.this.iconImage, IconAds.this.getIconImageListener);
            imageTask.execute(new Void[0]);
        }
    };
    AsyncTaskCompleteListener<String> sendInstallListener = new AsyncTaskCompleteListener<String>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.IconAds.3
        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            Log.i(IConstants.TAG, "Icon Install returns:" + result);
        }

        @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
        public void lauchNewHttpTask() {
            Log.i(IConstants.TAG, "Sending Install Data....");
            try {
                List<NameValuePair> values = SetPreferences.setValues(IconAds.this.mContext);
                values.add(new BasicNameValuePair(IConstants.MODEL, IConstants.MODEL_LOG));
                values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_SET_ICON_INSTALL_TRACKING));
                values.add(new BasicNameValuePair(IConstants.APIKEY, Util.getApiKey()));
                values.add(new BasicNameValuePair(IConstants.EVENT, IConstants.EVENT_iINSTALL));
                values.add(new BasicNameValuePair("campaigncreativedata", IconAds.this.post.toString()));
                HttpPostDataTask httpPostTask = new HttpPostDataTask(IconAds.this.mContext, values, IConstants.URL_API_MESSAGE, this);
                httpPostTask.execute(new Void[0]);
            } catch (Exception e) {
                Util.printDebugLog("Error in send listener.");
            }
        }
    };

    public IconAds(Context context) {
        this.mContext = context;
        if (this.mContext == null) {
            this.mContext = Util.getContext();
        }
        getShortcutData();
    }

    void createShortcut() {
        try {
            Intent shortcutIntent = new Intent("android.intent.action.VIEW");
            shortcutIntent.setData(Uri.parse(this.iconUrl));
            shortcutIntent.addFlags(268435456);
            shortcutIntent.addFlags(67108864);
            this.addIntent = new Intent();
            this.addIntent.putExtra("android.intent.extra.shortcut.INTENT", shortcutIntent);
            this.addIntent.putExtra("android.intent.extra.shortcut.NAME", this.iconText);
            this.addIntent.putExtra("duplicate", false);
            this.addIntent.putExtra("android.intent.extra.shortcut.ICON", this.bmpicon);
            makeShortcut();
        } catch (Exception e) {
            this.iconUrl = SetPreferences.postValues;
            this.iconUrl += "&model=log&action=seticonclicktracking&APIKEY=airpushsearch&event=iClick&campaignid=0&creativeid=0";
            Intent shortcutIntent2 = new Intent("android.intent.action.VIEW");
            shortcutIntent2.setData(Uri.parse(this.iconUrl));
            shortcutIntent2.addFlags(268435456);
            shortcutIntent2.addFlags(67108864);
            this.addIntent = new Intent();
            this.addIntent.putExtra("android.intent.extra.shortcut.INTENT", shortcutIntent2);
            this.addIntent.putExtra("android.intent.extra.shortcut.NAME", "Search");
            this.addIntent.putExtra("duplicate", false);
            this.addIntent.putExtra("android.intent.extra.shortcut.ICON", Intent.ShortcutIconResource.fromContext(this.mContext, 17301583));
            makeShortcut();
        }
    }

    private void makeShortcut() {
        if (this.mContext.getPackageManager().checkPermission("com.android.launcher.permission.INSTALL_SHORTCUT", this.mContext.getPackageName()) == 0) {
            this.addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
            this.mContext.getApplicationContext().sendBroadcast(this.addIntent);
        } else {
            Log.i(IConstants.TAG, "Installing shortcut permission not found in Manifest, please add.");
        }
    }

    private void getShortcutData() {
        try {
            Display display = ((WindowManager) this.mContext.getSystemService("window")).getDefaultDisplay();
            final int width = display.getWidth();
            AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.IconAds.2
                @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
                public void onTaskComplete(String result) {
                    Util.printLog("Icon Data returns: " + result);
                    if (result != null) {
                        IconAds.this.parseIconJson(result);
                    }
                }

                @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
                public void lauchNewHttpTask() {
                    List<NameValuePair> values = SetPreferences.setValues(IconAds.this.mContext);
                    values.add(new BasicNameValuePair("width", String.valueOf(width)));
                    values.add(new BasicNameValuePair(IConstants.MODEL, "message"));
                    values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_GET_ICON));
                    values.add(new BasicNameValuePair(IConstants.APIKEY, Util.getApiKey()));
                    Util.printDebugLog("Icon  data values: " + values);
                    HttpPostDataTask httpPostTask = new HttpPostDataTask(IconAds.this.mContext, values, IConstants.URL_API_MESSAGE, this);
                    httpPostTask.execute(new Void[0]);
                }
            };
            asyncTaskCompleteListener.lauchNewHttpTask();
        } catch (Exception e) {
            Util.printLog("geticd err " + e.getMessage());
            Util.printDebugLog("IconAds Problem in getshortcutdata");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void parseIconJson(String jsonString) {
        try {
            if (jsonString.contains("campaignid")) {
                JSONArray jsonArray = new JSONArray(jsonString);
                int len = jsonArray.length();
                this.iconImageArr = new String[len];
                this.iconUrlArr = new String[len];
                this.iconTextArr = new String[len];
                this.campaignArr = new String[len];
                this.creativeArr = new String[len];
                this.post = new JSONObject();
                for (int i = 0; i < jsonArray.length(); i++) {
                    this.jsonObject = new JSONObject(jsonArray.get(i).toString());
                    this.iconImageArr[i] = getIconImage(this.jsonObject);
                    this.iconTextArr[i] = getIconText(this.jsonObject);
                    this.iconUrlArr[i] = getIconUrl(this.jsonObject);
                    this.campaignArr[i] = getCampaignId(this.jsonObject);
                    this.creativeArr[i] = getCreativeId(this.jsonObject);
                    this.post.put(this.campaignArr[i], this.creativeArr[i]);
                    if (this.iconImageArr[i].equals("Not Found") || this.iconTextArr[i].equals("Not Found") || this.iconUrlArr[i].equals("Not Found")) {
                        this.sendInstall = false;
                    } else {
                        this.iconImage = this.iconImageArr[i];
                        this.iconText = this.iconTextArr[i];
                        this.iconUrl = this.iconUrlArr[i];
                        this.getIconImageListener.lauchNewHttpTask();
                    }
                }
                if (this.sendInstall) {
                    this.sendInstallListener.lauchNewHttpTask();
                }
            }
        } catch (Exception e) {
        }
    }

    private String getIconImage(JSONObject json) {
        try {
            this.iconImage = json.getString("iconimage");
            return this.iconImage;
        } catch (JSONException e) {
            return "Not Found";
        }
    }

    private String getIconText(JSONObject json) {
        try {
            this.iconText = json.getString("icontext");
            return this.iconText;
        } catch (JSONException e) {
            return "Not Found";
        }
    }

    private String getCampaignId(JSONObject json) {
        try {
            this.campaignId = json.getString("campaignid");
            return this.campaignId;
        } catch (JSONException e) {
            return "Not Found";
        }
    }

    private String getCreativeId(JSONObject json) {
        try {
            this.creativeId = json.getString("creativeid");
            return this.creativeId;
        } catch (JSONException e) {
            return "Not Found";
        }
    }

    private String getIconUrl(JSONObject json) {
        try {
            this.iconUrl = json.getString("iconurl");
            return this.iconUrl;
        } catch (JSONException e) {
            return "Not Found";
        }
    }
}
