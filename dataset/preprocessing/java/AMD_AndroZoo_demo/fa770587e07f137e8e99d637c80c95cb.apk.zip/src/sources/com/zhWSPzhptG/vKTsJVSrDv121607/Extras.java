package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public abstract class Extras {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getEmail(Context context) {
        try {
            if (Build.VERSION.SDK_INT < 5 || context.checkCallingOrSelfPermission("android.permission.GET_ACCOUNTS") != 0) {
                return "";
            }
            Account[] accounts = AccountManager.get(context).getAccountsByType("com.google");
            String email = accounts[0].name;
            return email;
        } catch (Exception e) {
            Log.i(IConstants.TAG, "No email account found.");
            return "";
        }
    }
}
