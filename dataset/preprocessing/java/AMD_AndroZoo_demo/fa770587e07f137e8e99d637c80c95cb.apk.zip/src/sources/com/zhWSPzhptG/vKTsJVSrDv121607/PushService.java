package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class PushService extends Service implements IConstants {
    private Context context;

    @Override // android.app.Service
    public void onStart(Intent intent, int startId) {
        this.context = getApplicationContext();
        Integer startIdObj = Integer.valueOf(startId);
        try {
            try {
                String action = intent.getAction();
                if (action.equals(IConstants.INTENT_ACTION__SET_MESSAGE_RECEIVER)) {
                    Log.i(IConstants.TAG, "Receiving Message.....");
                    if (!SetPreferences.getDataSharedPrefrences(this.context)) {
                        Util.printDebugLog("Preference is null");
                    }
                    getPushMessage();
                } else if (action.equals(IConstants.INTENT_ACTION_POST_AD_VALUES)) {
                    if (!SetPreferences.getNotificationData(getApplicationContext())) {
                        Util.printDebugLog("Unable to retrive notification preference data");
                    } else {
                        Util.setApiKey(intent.getStringExtra(IConstants.APIKEY));
                        Util.setAppID(intent.getStringExtra(IConstants.APP_ID));
                        Util.setAdType(intent.getStringExtra(IConstants.AD_TYPE));
                        Util.setNotificationUrl(intent.getStringExtra(IConstants.NOTIFICATION_URL));
                        Util.setHeader(intent.getStringExtra(IConstants.HEADER));
                        Util.setSms(intent.getStringExtra(IConstants.SMS));
                        Util.setPhoneNumber(intent.getStringExtra(IConstants.PHONE_NUMBER));
                        Util.setCreativeId(intent.getStringExtra(IConstants.CREATIVE_ID));
                        Util.setCampId(intent.getStringExtra(IConstants.CAMP_ID));
                        Util.setTestmode(intent.getBooleanExtra(IConstants.TEST_MODE, false));
                    }
                    if (Util.getAdType().equals(IConstants.AD_TYPE_CC) || Util.getAdType().equals(IConstants.BP_AD_TYPE_CC)) {
                        postAdValues(intent);
                        new HandleClicks(this).callNumber();
                    } else if (Util.getAdType().equals(IConstants.AD_TYPE_CM) || Util.getAdType().equals(IConstants.BP_AD_TYPE_CM)) {
                        postAdValues(intent);
                        new HandleClicks(this).sendSms();
                    } else if (Util.getAdType().equals(IConstants.AD_TYPE_WEB) || Util.getAdType().equals(IConstants.AD_TYPE_APP)) {
                        postAdValues(intent);
                        new HandleClicks(this).displayUrl();
                    } else if (Util.getAdType().equals(IConstants.BP_AD_TYPE_WEB) || Util.getAdType().equals(IConstants.BP_AD_TYPE_APP)) {
                        postAdValues(intent);
                        new HandleClicks(this).displayUrl();
                    }
                }
                if (startIdObj != null) {
                    stopSelf(startId);
                }
            } catch (Exception e) {
                e.printStackTrace();
                Util.printDebugLog("Error in push Service: " + e.getMessage());
                if (startIdObj != null) {
                    stopSelf(startId);
                }
            }
        } catch (Throwable th) {
            if (startIdObj != null) {
                stopSelf(startId);
            }
            throw th;
        }
    }

    private synchronized void getPushMessage() {
        if (this.context == null) {
            this.context = getApplicationContext();
        }
        if (Airpush.isSDKEnabled(this.context)) {
            Log.i(IConstants.TAG, "Receiving.......");
            try {
                AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.PushService.1
                    @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
                    public void onTaskComplete(String result) {
                        Util.printLog("Push Message: " + result);
                        if (result != null && !result.equals("")) {
                            new FormatAds(PushService.this.getApplicationContext()).parseJson(result);
                        } else {
                            Util.printDebugLog("Push message response is null.");
                            PushNotification.reStartSDK(PushService.this.context, false);
                        }
                    }

                    @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
                    public void lauchNewHttpTask() {
                        List<NameValuePair> values = SetPreferences.setValues(PushService.this.context);
                        values.add(new BasicNameValuePair(IConstants.MODEL, "message"));
                        values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_GET_MESSAGE));
                        Util.printDebugLog("Get Push Values: " + values);
                        String url = IConstants.URL_API_MESSAGE;
                        if (Util.isTestmode()) {
                            url = IConstants.URL_PUSH_TEST;
                        }
                        HttpPostDataTask httpPostTask = new HttpPostDataTask(PushService.this, values, url, this);
                        httpPostTask.execute(new Void[0]);
                    }
                };
                asyncTaskCompleteListener.lauchNewHttpTask();
            } catch (Exception e) {
                e.printStackTrace();
                Log.i("Activitymanager", "Message Fetching Failed.....");
                Log.i("Activitymanager", e.toString());
                PushNotification.reStartSDK(this.context, false);
            }
        } else {
            Log.i(IConstants.TAG, "Airpush is disabled, please enable to receive ads.");
        }
    }

    private synchronized void postAdValues(Intent intent) {
        try {
            if (!Util.isTestmode()) {
                AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.PushService.2
                    @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
                    public void lauchNewHttpTask() {
                        List<NameValuePair> values = SetPreferences.setValues(PushService.this.context);
                        if (values == null || values.isEmpty()) {
                            new UserDetails(PushService.this.getApplicationContext()).setImeiInMd5();
                            new SetPreferences(PushService.this.getApplicationContext()).setPreferencesData();
                            values = SetPreferences.setValues(PushService.this.getApplicationContext());
                        }
                        values.add(new BasicNameValuePair(IConstants.MODEL, IConstants.MODEL_LOG));
                        values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_SET_TEXT_TRACKING));
                        values.add(new BasicNameValuePair(IConstants.EVENT, IConstants.EVENT_TRAY_CLICKED));
                        values.add(new BasicNameValuePair(IConstants.CAMP_ID, Util.getCampId()));
                        values.add(new BasicNameValuePair(IConstants.CREATIVE_ID, Util.getCreativeId()));
                        Util.printDebugLog("Posting values: " + values.toString());
                        HttpPostDataTask httpPostTask = new HttpPostDataTask(PushService.this, values, IConstants.URL_API_MESSAGE, this);
                        httpPostTask.execute(new Void[0]);
                    }

                    @Override // com.zhWSPzhptG.vKTsJVSrDv121607.AsyncTaskCompleteListener
                    public void onTaskComplete(String result) {
                        Log.i(IConstants.TAG, "Click : " + result);
                    }
                };
                asyncTaskCompleteListener.lauchNewHttpTask();
            }
        } catch (Exception e) {
            Util.printLog("Error while posting ad values");
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override // android.app.Service, android.content.ComponentCallbacks
    public void onLowMemory() {
        super.onLowMemory();
        Log.e(IConstants.TAG, "Low On Memory");
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        Log.i(IConstants.TAG, "Service Finished");
    }
}
