package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class PushNotification {
    private static final String TAG = "AirpushSDK";
    private static Context context;
    private Runnable send_Task = new Runnable() { // from class: com.zhWSPzhptG.vKTsJVSrDv121607.PushNotification.1
        @Override // java.lang.Runnable
        public void run() {
            PushNotification.reStartSDK(PushNotification.context, true);
        }
    };

    public PushNotification(Context context2) {
        context = context2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void startAirpush() {
        if (!Airpush.checkRequiredPermission(context)) {
            Log.i("AirpushSDK", "Unable to start airpush.");
            return;
        }
        if (new UserDetails(context).setImeiInMd5()) {
            try {
                new SetPreferences(context).setPreferencesData();
                SetPreferences.getDataSharedPrefrences(context);
                if (Util.isTestmode()) {
                    Log.i("AirpushSDK", "Airpush push notification is running in test mode.");
                }
                Log.i("AirpushSDK", "Push Notification Service...." + Util.isDoPush());
                Log.i("AirpushSDK", "Initialising push.....");
                if (Util.checkInternetConnection(context)) {
                    new Handler().postDelayed(this.send_Task, 6000L);
                } else {
                    reStartSDK(context, false);
                }
            } catch (Exception e) {
                Util.printLog("" + e.getMessage());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void reStartSDK(Context context2, boolean connectivity) {
        context = context2;
        long timeDifference = 0;
        if (connectivity) {
            long startTime = SetPreferences.getSDKStartTime(context);
            if (startTime != 0) {
                long currentTime = System.currentTimeMillis();
                if (currentTime < startTime) {
                    long diff = startTime - currentTime;
                    Log.i("AirpushSDK", "SDK will restart after " + diff + " ms.");
                    timeDifference = diff;
                    Util.printDebugLog("time difference : " + (diff / 60000) + " minutes");
                }
            }
        } else {
            timeDifference = IConstants.TIME_DIFF;
            Util.printDebugLog("SDK will start after " + IConstants.TIME_DIFF + " ms.");
        }
        try {
            Intent messageIntent = new Intent(context2, (Class<?>) PushService.class);
            messageIntent.setAction(IConstants.INTENT_ACTION__SET_MESSAGE_RECEIVER);
            PendingIntent pendingIntent = PendingIntent.getService(context2, 0, messageIntent, 0);
            AlarmManager msgAlarmMgr = (AlarmManager) context2.getSystemService("alarm");
            msgAlarmMgr.setInexactRepeating(0, System.currentTimeMillis() + timeDifference + IConstants.INTERVAL_FIRST_TIME.intValue(), Util.getMessageIntervalTime(), pendingIntent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
