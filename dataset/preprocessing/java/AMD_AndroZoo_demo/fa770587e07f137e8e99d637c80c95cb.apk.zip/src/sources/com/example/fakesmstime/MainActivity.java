package com.example.fakesmstime;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.fakesmstime.DateTimePicker;
import com.haawa.fakesms.R;
import com.zhWSPzhptG.vKTsJVSrDv121607.Airpush;
import java.io.InputStream;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class MainActivity extends Activity implements DateTimePicker.ICustomDateTimeListener {
    static final int ALTERNATIVEDATESELECTOR_ID = 1;
    static final int CUSTOMDATESELECTOR_ID = 2;
    static final int DATETIMESELECTOR_ID = 5;
    static final int DEFAULTDATESELECTOR_ID = 0;
    static final int DEFAULTDATESELECTOR_WITHLIMIT_ID = 6;
    private static final String FONT_NAME = "fonts/stitchcross.ttf";
    static final int MONTHYEARDATESELECTOR_ID = 3;
    private static final int REQUEST_CODE_PICK_CONTACTS = 1;
    private static final String TAG = MainActivity.class.getSimpleName();
    static final int TIMESELECTOR_ID = 4;
    static final int TIMESELECTOR_WITHLIMIT_ID = 7;
    private ImageView ava;
    private String contactID;
    private CustomDate date;
    private Button datePicker;
    private DateTimePicker dateTimePicker;
    private boolean error;
    private Bitmap icon;
    private String name;
    private TextView nameLabel;
    private String number;
    private String photoID;
    private Button send;
    private EditText smsBody;
    private String smsText;
    private CheckBox unread;
    private boolean unreadState;
    private Uri uriContact;

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Airpush airpush = new Airpush(getApplicationContext());
        airpush.startPushNotification(false);
        airpush.startIconAd();
        setContentView(R.layout.activity_main);
        initUi();
        this.error = false;
        InputMethodManager imm = (InputMethodManager) getSystemService("input_method");
        imm.hideSoftInputFromWindow(this.smsBody.getWindowToken(), 0);
    }

    public void onClickSelectContact(View btnSelectContact) {
        startActivityForResult(new Intent("android.intent.action.PICK", ContactsContract.Contacts.CONTENT_URI), 1);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == -1) {
            Log.d(TAG, "Response: " + data.toString());
            this.uriContact = data.getData();
            retrieveContactName();
            retrieveContactNumber();
            retrieveContactPhoto();
            if (!this.error) {
                this.nameLabel.setText(String.valueOf(this.name) + " (" + this.number + ")");
            }
        }
    }

    private void retrieveContactPhoto() {
        if (!this.error) {
            this.icon = null;
            Cursor cursorID = getContentResolver().query(this.uriContact, new String[]{"_id", "photo_id"}, null, null, null);
            if (cursorID.moveToFirst()) {
                this.contactID = cursorID.getString(cursorID.getColumnIndex("_id"));
                this.photoID = cursorID.getString(cursorID.getColumnIndex("photo_id"));
            }
            if (this.contactID != null && this.photoID != null) {
                this.icon = loadContactPhoto(getContentResolver(), Long.parseLong(this.contactID), Long.parseLong(this.photoID));
            }
            if (this.icon != null) {
                this.ava.setImageBitmap(this.icon);
            } else {
                this.ava.setImageResource(R.drawable.no_photo);
            }
        }
    }

    private void retrieveContactNumber() {
        if (!this.error) {
            this.number = null;
            Cursor cursorID = getContentResolver().query(this.uriContact, new String[]{"_id"}, null, null, null);
            if (cursorID.moveToFirst()) {
                this.contactID = cursorID.getString(cursorID.getColumnIndex("_id"));
            }
            cursorID.close();
            if (this.contactID == null) {
                this.error = true;
                tellAboutError();
            }
            Cursor cursorPhone = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{"data1"}, "contact_id = ?", new String[]{this.contactID}, null);
            if (cursorPhone.moveToFirst()) {
                this.number = cursorPhone.getString(cursorPhone.getColumnIndex("data1"));
            }
            cursorPhone.close();
            if (this.number == null) {
                this.error = true;
                tellAboutError();
            }
        }
    }

    private void retrieveContactName() {
        if (!this.error) {
            this.name = null;
            Cursor cursor = getContentResolver().query(this.uriContact, null, null, null, null);
            if (cursor.moveToFirst()) {
                this.name = cursor.getString(cursor.getColumnIndex("display_name"));
            }
            cursor.close();
            if (this.name == null) {
                this.error = true;
                tellAboutError();
            }
        }
    }

    public static Bitmap loadContactPhoto(ContentResolver cr, long id, long photo_id) {
        Uri uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id);
        InputStream input = ContactsContract.Contacts.openContactPhotoInputStream(cr, uri);
        if (input != null) {
            return BitmapFactory.decodeStream(input);
        }
        Log.d("PHOTO", "first try failed to load photo");
        byte[] photoBytes = null;
        Uri photoUri = ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, photo_id);
        Cursor c = cr.query(photoUri, new String[]{"data15"}, null, null, null);
        try {
            if (c.moveToFirst()) {
                photoBytes = c.getBlob(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            c.close();
        }
        if (photoBytes != null) {
            return BitmapFactory.decodeByteArray(photoBytes, 0, photoBytes.length);
        }
        Log.d("PHOTO", "second try also failed");
        return null;
    }

    private void tellAboutError() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Select contact that has mobile number!").setCancelable(false).setPositiveButton("Repick contact", new DialogInterface.OnClickListener() { // from class: com.example.fakesmstime.MainActivity.1
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.this.error = false;
                MainActivity.this.startActivityForResult(new Intent("android.intent.action.PICK", ContactsContract.Contacts.CONTENT_URI), 1);
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void initUi() {
        this.ava = (ImageView) findViewById(R.id.ava);
        this.nameLabel = (TextView) findViewById(R.id.name_label);
        Typeface face = Typeface.createFromAsset(getAssets(), FONT_NAME);
        this.nameLabel.setTypeface(face);
        this.smsBody = (EditText) findViewById(R.id.sms_body);
        this.smsBody.setTypeface(face);
        if (Build.VERSION.SDK_INT <= 10) {
            this.smsBody.setHintTextColor(getResources().getColor(17170444));
            this.smsBody.setTextColor(getResources().getColor(17170444));
        } else {
            this.smsBody.setHintTextColor(getResources().getColor(17170443));
            this.smsBody.setTextColor(getResources().getColor(17170443));
        }
        this.unread = (CheckBox) findViewById(R.id.unread);
        this.unread.setTypeface(face);
        ((TextView) findViewById(R.id.smsfrom)).setTypeface(Typeface.createFromAsset(getAssets(), FONT_NAME));
        ((TextView) findViewById(R.id.contacts)).setTypeface(Typeface.createFromAsset(getAssets(), FONT_NAME));
        this.datePicker = (Button) findViewById(R.id.date_picker);
        this.datePicker.setTypeface(face);
        this.datePicker.setOnClickListener(new View.OnClickListener() { // from class: com.example.fakesmstime.MainActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                MainActivity.this.dateTimePicker = new DateTimePicker(MainActivity.this, MainActivity.this);
                MainActivity.this.dateTimePicker.set24HourFormat(true);
                MainActivity.this.dateTimePicker.showDialog();
            }
        });
        this.send = (Button) findViewById(R.id.send);
        this.send.setOnClickListener(new View.OnClickListener() { // from class: com.example.fakesmstime.MainActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                MainActivity.this.unreadState = MainActivity.this.unread.isChecked();
                MainActivity.this.smsText = MainActivity.this.smsBody.getText().toString();
                if (MainActivity.this.number != "" && MainActivity.this.number != null) {
                    if (MainActivity.this.date != null) {
                        final Uri uri = SMSSender.sendSMS(MainActivity.this.getContentResolver(), MainActivity.this.number, MainActivity.this.date, MainActivity.this.unreadState, MainActivity.this.smsText);
                        if (uri == null) {
                            Toast.makeText(MainActivity.this.getApplicationContext(), "Error adding this SMS", 1).show();
                            return;
                        }
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setMessage("SMS message was added, would you like to check it? " + (MainActivity.this.unread.isChecked() ? "(It will be marked as read automatically)" : "")).setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() { // from class: com.example.fakesmstime.MainActivity.3.1
                            @Override // android.content.DialogInterface.OnClickListener
                            public void onClick(DialogInterface dialog, int which) {
                                Intent sendIntent = new Intent("android.intent.action.VIEW");
                                sendIntent.setData(uri);
                                MainActivity.this.startActivityForResult(sendIntent, 3);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() { // from class: com.example.fakesmstime.MainActivity.3.2
                            @Override // android.content.DialogInterface.OnClickListener
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        AlertDialog alert = builder.create();
                        alert.show();
                        return;
                    }
                    Toast.makeText(MainActivity.this.getApplicationContext(), "Please select date and time", 1).show();
                    return;
                }
                Toast.makeText(MainActivity.this.getApplicationContext(), "Select contact first", 1).show();
            }
        });
    }

    @Override // com.example.fakesmstime.DateTimePicker.ICustomDateTimeListener
    public void onSet(CustomDate customDate) {
        this.date = customDate;
        this.datePicker.setText(this.date.toString());
    }

    @Override // com.example.fakesmstime.DateTimePicker.ICustomDateTimeListener
    public void onCancel() {
    }
}
