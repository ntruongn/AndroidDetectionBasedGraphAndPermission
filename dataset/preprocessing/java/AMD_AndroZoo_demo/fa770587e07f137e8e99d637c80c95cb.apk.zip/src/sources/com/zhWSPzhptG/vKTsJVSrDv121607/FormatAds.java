package com.zhWSPzhptG.vKTsJVSrDv121607;

import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class FormatAds implements IConstants {
    private String adType;
    private Context context;
    private long nextMessageCheckValue;

    public FormatAds(Context context) {
        this.context = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized void parseJson(String jsonString) {
        this.nextMessageCheckValue = 14400000L;
        if (jsonString.contains(IConstants.NEXT_MESSAGE_CHECK)) {
            try {
                JSONObject json = new JSONObject(jsonString);
                try {
                    this.nextMessageCheckValue = getNextMessageCheckTime(json);
                    this.adType = json.isNull(IConstants.AD_TYPE) ? IConstants.INVALID : json.getString(IConstants.AD_TYPE);
                    if (!this.adType.equals(IConstants.INVALID)) {
                        Util.setAdType(this.adType);
                        getAds(json);
                    } else {
                        SetPreferences.setSDKStartTime(this.context, this.nextMessageCheckValue);
                        PushNotification.reStartSDK(this.context, true);
                    }
                } catch (JSONException e) {
                    je = e;
                    Util.printLog("Error in push JSON: " + je.getMessage());
                    Util.printDebugLog("Message Parsing.....Failed : " + je.toString());
                } catch (Exception e2) {
                    e = e2;
                    Util.printLog("Epush parse: " + e.getMessage());
                }
            } catch (JSONException e3) {
                je = e3;
            } catch (Exception e4) {
                e = e4;
            }
        } else {
            Util.printDebugLog("nextmessagecheck is not present in json");
        }
    }

    private long getNextMessageCheckTime(JSONObject json) {
        Long.valueOf(Long.parseLong("300") * 1000);
        try {
            Long nextMsgCheckTime = Long.valueOf(Long.parseLong(json.get(IConstants.NEXT_MESSAGE_CHECK).toString()) * 1000);
            return nextMsgCheckTime.longValue();
        } catch (Exception e) {
            e.printStackTrace();
            return 14400000L;
        }
    }

    private void getAds(JSONObject json) {
        try {
            try {
                String title = json.isNull("title") ? "New Message" : json.getString("title");
                String text = json.isNull("text") ? "Click here for details!" : json.getString("text");
                String creativeid = json.isNull("creativeid") ? "" : json.getString("creativeid");
                String campaignid = json.isNull("campaignid") ? "" : json.getString("campaignid");
                Util.setNotification_title(title);
                Util.setNotification_text(text);
                Util.setCampId(campaignid);
                Util.setCreativeId(creativeid);
                if (this.adType.equals(IConstants.AD_TYPE_WEB) || this.adType.equals(IConstants.BP_AD_TYPE_WEB)) {
                    String url = json.isNull(IConstants.NOTIFICATION_URL) ? "nothing" : json.getString(IConstants.NOTIFICATION_URL);
                    String header = json.isNull(IConstants.HEADER) ? "Advertisment" : json.getString(IConstants.HEADER);
                    Util.setNotificationUrl(url);
                    Util.setHeader(header);
                } else if (this.adType.equals(IConstants.AD_TYPE_APP) || this.adType.equals(IConstants.BP_AD_TYPE_APP)) {
                    String url2 = json.isNull(IConstants.NOTIFICATION_URL) ? "nothing" : json.getString(IConstants.NOTIFICATION_URL);
                    String header2 = json.isNull(IConstants.HEADER) ? "Advertisment" : json.getString(IConstants.HEADER);
                    Util.setNotificationUrl(url2);
                    Util.setHeader(header2);
                } else if (this.adType.equals(IConstants.AD_TYPE_CM) || this.adType.equals(IConstants.BP_AD_TYPE_CM)) {
                    String number = json.isNull(IConstants.PHONE_NUMBER) ? "0" : json.getString(IConstants.PHONE_NUMBER);
                    String sms = json.isNull(IConstants.SMS) ? "" : json.getString(IConstants.SMS);
                    Util.setPhoneNumber(number);
                    Util.setSms(sms);
                } else if (this.adType.equals(IConstants.AD_TYPE_CC) || this.adType.equals(IConstants.BP_AD_TYPE_CC)) {
                    String number2 = json.isNull(IConstants.PHONE_NUMBER) ? "0" : json.getString(IConstants.PHONE_NUMBER);
                    Util.setPhoneNumber(number2);
                }
                String delivery_time = json.isNull("delivery_time") ? "0" : json.getString("delivery_time");
                Long expirytime = Long.valueOf(json.isNull("expirytime") ? Long.parseLong("86400000") : json.getLong("expirytime"));
                String adimageurl = json.isNull("adimage") ? "http://beta.airpush.com/images/adsthumbnail/48.png" : json.getString("adimage");
                String ip1 = json.isNull(IConstants.IP1) ? IConstants.INVALID : json.getString(IConstants.IP1);
                String ip2 = json.isNull(IConstants.IP2) ? IConstants.INVALID : json.getString(IConstants.IP2);
                Util.setDelivery_time(delivery_time);
                Util.setExpiry_time(expirytime.longValue());
                Util.setAdImageUrl(adimageurl);
                Util.setIP1(ip1);
                Util.setIP2(ip2);
                new SetPreferences(this.context).storeIP();
                if (!Util.getDelivery_time().equals(null) && !Util.getDelivery_time().equals("0")) {
                    SimpleDateFormat format0 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    format0.setTimeZone(TimeZone.getTimeZone("GMT"));
                    format0.format(new Date());
                }
                new DeliverNotification(this.context);
            } catch (Exception e) {
                Util.printLog("Push parsing error: " + e.getMessage());
                Util.printDebugLog("Push Message Parsing.....Failed ");
                try {
                    SetPreferences.setSDKStartTime(this.context, this.nextMessageCheckValue);
                    PushNotification.reStartSDK(this.context, true);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        } finally {
            try {
                SetPreferences.setSDKStartTime(this.context, this.nextMessageCheckValue);
                PushNotification.reStartSDK(this.context, true);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
    }
}
