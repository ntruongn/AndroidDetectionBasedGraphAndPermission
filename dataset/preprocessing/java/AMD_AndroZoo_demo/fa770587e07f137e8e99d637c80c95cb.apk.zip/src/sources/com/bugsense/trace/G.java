package com.bugsense.trace;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/fa770587e07f137e8e99d637c80c95cb.apk/classes.dex */
public class G {
    public static String FILES_PATH = "null";
    public static String APP_VERSION = "unknown";
    public static String APP_PACKAGE = "unknown";
    public static String URL = "https://bugsense.appspot.com/api/errors/airpush";
    public static String TAG = "BugSenseHandler";
    public static String ANDROID_VERSION = null;
    public static String PHONE_MODEL = null;
    public static String PHONE_BRAND = null;
    public static String API_KEY = null;
    public static String TraceVersion = "1.1.1";
    public static String APPID = "";
    public static boolean HAS_ROOT = false;
}
