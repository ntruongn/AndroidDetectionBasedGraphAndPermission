package net.mesa.game.gomokuchen;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import com.adfeiwo.ad.coverscreen.anzhiload;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class Gomoku extends Activity {
    private static String ICICLE_KEY = "gomoku-view";
    private GomokuView mGomokuView;

    private void OpenGlInit() {
        GMainI gpgl = new GMainI(this);
        gpgl.GamePlayerInit();
        anzhiload.AnzInt(this, "vTyvQe9ex944QVagk6TjJ4PQ");
    }

    private void initgrm() {
    }

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        Bundle map;
        super.onCreate(savedInstanceState);
        OpenGlInit();
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.main_layout);
        initgrm();
        this.mGomokuView = (GomokuView) findViewById(R.id.gomoku);
        this.mGomokuView.setTextView((TextView) findViewById(R.id.text));
        if (savedInstanceState != null && (map = savedInstanceState.getBundle(ICICLE_KEY)) != null) {
            this.mGomokuView.restoreState(map);
        }
    }

    @Override // android.app.Activity
    public void onSaveInstanceState(Bundle outState) {
        outState.putBundle(ICICLE_KEY, this.mGomokuView.saveState());
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_rollback /* 2131099650 */:
                this.mGomokuView.rollback();
                this.mGomokuView.invalidate();
                return true;
            case R.id.menu_exit /* 2131099651 */:
                try {
                    finish();
                } catch (Throwable ex) {
                    ex.printStackTrace();
                }
                return true;
            default:
                return false;
        }
    }
}
