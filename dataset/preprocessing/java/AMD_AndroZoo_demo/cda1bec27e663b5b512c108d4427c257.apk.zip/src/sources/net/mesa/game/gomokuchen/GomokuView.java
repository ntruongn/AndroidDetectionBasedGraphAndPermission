package net.mesa.game.gomokuchen;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.TextView;
import com.adfeiwo.ad.coverscreen.AdComponent;
import java.lang.reflect.Array;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Stack;
import java.util.Vector;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class GomokuView extends TileView {
    static final /* synthetic */ boolean $assertionsDisabled;
    private static final int CELL_BLACK = 10;
    private static final int CELL_BLACK_BOTTOM = 11;
    private static final int CELL_BLACK_BOTTOM_LEFT = 12;
    private static final int CELL_BLACK_BOTTOM_RIGHT = 13;
    private static final int CELL_BLACK_LEFT = 14;
    private static final int CELL_BLACK_RIGHT = 15;
    private static final int CELL_BLACK_TOP = 16;
    private static final int CELL_BLACK_TOP_LEFT = 17;
    private static final int CELL_BLACK_TOP_RIGHT = 18;
    private static final int CELL_EMPTY = 1;
    private static final int CELL_EMPTY_BOTTOM = 2;
    private static final int CELL_EMPTY_BOTTOM_LEFT = 3;
    private static final int CELL_EMPTY_BOTTOM_RIGHT = 4;
    private static final int CELL_EMPTY_LEFT = 5;
    private static final int CELL_EMPTY_RIGHT = 6;
    private static final int CELL_EMPTY_TOP = 7;
    private static final int CELL_EMPTY_TOP_LEFT = 8;
    private static final int CELL_EMPTY_TOP_RIGHT = 9;
    private static final int CELL_WHITE = 19;
    private static final int CELL_WHITE_BOTTOM = 20;
    private static final int CELL_WHITE_BOTTOM_LEFT = 21;
    private static final int CELL_WHITE_BOTTOM_RIGHT = 22;
    private static final int CELL_WHITE_LEFT = 23;
    private static final int CELL_WHITE_RIGHT = 24;
    private static final int CELL_WHITE_TOP = 25;
    private static final int CELL_WHITE_TOP_LEFT = 26;
    private static final int CELL_WHITE_TOP_RIGHT = 27;
    public static final int MODE_OVER_LOSE = 2;
    public static final int MODE_OVER_TIE = 3;
    public static final int MODE_OVER_WIN = 1;
    public static final int MODE_RUNNING = 0;
    private static final int STONE_BLACK = 1;
    private static final int STONE_NONE = 0;
    private static final int STONE_WHITE = 2;
    private static final int THREAT_BROKEN_FOUR = 9;
    private static final int THREAT_BROKEN_THREE = 6;
    private static final int THREAT_CAPPED_FOUR = 8;
    private static final int THREAT_CAPPED_FOUR_THREE = 13;
    private static final int THREAT_CAPPED_FOUR_TWO = 10;
    private static final int THREAT_CAPPED_THREE = 3;
    private static final int THREAT_CAPPED_TWO = 1;
    private static final int THREAT_DOUBLE_FOUR = 14;
    private static final int THREAT_DOUBLE_THREE = 11;
    private static final int THREAT_DOUBLE_TWO = 4;
    private static final int THREAT_FIVE = 15;
    private static final int THREAT_FOUR = 12;
    private static final int THREAT_NONE = 0;
    private static final int THREAT_THREE = 5;
    private static final int THREAT_THREE_TWO = 7;
    private static final int THREAT_TWO = 2;
    private Thread mAIThread;
    private int[][] mBoard;
    private int mFocusX;
    private int mFocusY;
    private GameOverHandler mGameOverHandler;
    private int mMode;
    private int mNextX;
    private int mNextY;
    private int mPlyDepth;
    private TextView mStatusText;
    Stack<Step> mStepSeq;
    private int mStone;
    private boolean mTouchScreen;
    private int[][] mWorkingBoard;

    static {
        $assertionsDisabled = !GomokuView.class.desiredAssertionStatus() ? true : $assertionsDisabled;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public class Step {
        int stone;
        int x;
        int y;

        Step() {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public class GameOverHandler extends Handler {
        GameOverHandler() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (GomokuView.this.mStatusText != null) {
                Resources res = GomokuView.this.getContext().getResources();
                if (GomokuView.this.mMode != 1) {
                    if (GomokuView.this.mMode != 2) {
                        if (GomokuView.this.mMode == 3) {
                            GomokuView.this.mStatusText.setText(res.getString(R.string.mode_over_tie));
                        }
                    } else {
                        GomokuView.this.mStatusText.setText(res.getString(R.string.mode_over_lose));
                    }
                } else {
                    GomokuView.this.mStatusText.setText(res.getString(R.string.mode_over_win));
                }
                GomokuView.this.mStatusText.setVisibility(0);
                GomokuView.this.postInvalidate();
            }
        }

        public void update() {
            removeMessages(0);
            sendMessageDelayed(obtainMessage(0), 0L);
        }
    }

    public GomokuView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mMode = 1;
        this.mStepSeq = new Stack<>();
        this.mPlyDepth = 3;
        this.mStone = 1;
        this.mTouchScreen = true;
        this.mGameOverHandler = new GameOverHandler();
        initGomokuView();
    }

    public GomokuView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mMode = 1;
        this.mStepSeq = new Stack<>();
        this.mPlyDepth = 3;
        this.mStone = 1;
        this.mTouchScreen = true;
        this.mGameOverHandler = new GameOverHandler();
        initGomokuView();
    }

    private void initGomokuView() {
        Resources r = getContext().getResources();
        if (r.getConfiguration().touchscreen == 1) {
            this.mTouchScreen = $assertionsDisabled;
        }
        resetTiles(28);
        loadTile(1, r.getDrawable(R.drawable.empty));
        loadTile(2, r.getDrawable(R.drawable.empty_bottom));
        loadTile(3, r.getDrawable(R.drawable.empty_bottom_left));
        loadTile(4, r.getDrawable(R.drawable.empty_bottom_right));
        loadTile(5, r.getDrawable(R.drawable.empty_left));
        loadTile(6, r.getDrawable(R.drawable.empty_right));
        loadTile(7, r.getDrawable(R.drawable.empty_top));
        loadTile(8, r.getDrawable(R.drawable.empty_top_left));
        loadTile(9, r.getDrawable(R.drawable.empty_top_right));
        loadTile(10, r.getDrawable(R.drawable.black));
        loadTile(11, r.getDrawable(R.drawable.black_bottom));
        loadTile(12, r.getDrawable(R.drawable.black_bottom_left));
        loadTile(13, r.getDrawable(R.drawable.black_bottom_right));
        loadTile(14, r.getDrawable(R.drawable.black_left));
        loadTile(15, r.getDrawable(R.drawable.black_right));
        loadTile(CELL_BLACK_TOP, r.getDrawable(R.drawable.black_top));
        loadTile(CELL_BLACK_TOP_LEFT, r.getDrawable(R.drawable.black_top_left));
        loadTile(CELL_BLACK_TOP_RIGHT, r.getDrawable(R.drawable.black_top_right));
        loadTile(CELL_WHITE, r.getDrawable(R.drawable.white));
        loadTile(CELL_WHITE_BOTTOM, r.getDrawable(R.drawable.white_bottom));
        loadTile(CELL_WHITE_BOTTOM_LEFT, r.getDrawable(R.drawable.white_bottom_left));
        loadTile(CELL_WHITE_BOTTOM_RIGHT, r.getDrawable(R.drawable.white_bottom_right));
        loadTile(CELL_WHITE_LEFT, r.getDrawable(R.drawable.white_left));
        loadTile(CELL_WHITE_RIGHT, r.getDrawable(R.drawable.white_right));
        loadTile(CELL_WHITE_TOP, r.getDrawable(R.drawable.white_top));
        loadTile(CELL_WHITE_TOP_LEFT, r.getDrawable(R.drawable.white_top_left));
        loadTile(CELL_WHITE_TOP_RIGHT, r.getDrawable(R.drawable.white_top_right));
    }

    public void initNewGame() {
        this.mStepSeq.clear();
        this.mBoard = (int[][]) Array.newInstance((Class<?>) Integer.TYPE, mXTileCount, mYTileCount);
        this.mWorkingBoard = (int[][]) Array.newInstance((Class<?>) Integer.TYPE, mXTileCount, mYTileCount);
        this.mFocusX = mXTileCount / 2;
        this.mFocusY = mYTileCount / 2;
        clearTiles();
        if (this.mStone != 1) {
            add(2, this.mFocusX, this.mFocusY);
        }
    }

    private static int[] intArray2DToArray(int[][] matrix) {
        if (matrix == null) {
            return null;
        }
        if (matrix.length == 0 || matrix[0].length == 0) {
            return new int[0];
        }
        int[] a = new int[matrix.length * matrix[0].length];
        int k = 0;
        for (int i = 0; i < matrix.length; i++) {
            int j = 0;
            while (j < matrix[i].length) {
                a[k] = matrix[i][j];
                j++;
                k++;
            }
        }
        return a;
    }

    public Bundle saveState() {
        Bundle map = new Bundle();
        map.putInt("mPlyDepth", Integer.valueOf(this.mPlyDepth).intValue());
        map.putInt("mStone", Integer.valueOf(this.mStone).intValue());
        map.putInt("mMode", Integer.valueOf(this.mMode).intValue());
        map.putInt("mFocusX", Integer.valueOf(this.mFocusX).intValue());
        map.putInt("mFocusY", Integer.valueOf(this.mFocusY).intValue());
        map.putIntArray("mBoard", intArray2DToArray(this.mBoard));
        return map;
    }

    private static int[][] intArray2DToArray(int[] vec, int nRow, int nColumn) {
        if (!$assertionsDisabled && vec.length != nRow * nColumn) {
            throw new AssertionError();
        }
        if (vec == null) {
            return null;
        }
        if (vec.length == 0) {
            return (int[][]) Array.newInstance((Class<?>) Integer.TYPE, 0, 0);
        }
        int[][] a = (int[][]) Array.newInstance((Class<?>) Integer.TYPE, nRow, nColumn);
        int k = 0;
        for (int i = 0; i < nRow; i++) {
            int j = 0;
            while (j < nColumn) {
                a[i][j] = vec[k];
                j++;
                k++;
            }
        }
        return a;
    }

    public void restoreState(Bundle icicle) {
        this.mPlyDepth = icicle.getInt("mPlyDepth");
        this.mStone = icicle.getInt("mStone");
        this.mMode = icicle.getInt("mMode");
        this.mFocusX = icicle.getInt("mFcousX");
        this.mFocusY = icicle.getInt("mFocusY");
        this.mBoard = intArray2DToArray(icicle.getIntArray("mBoard"), mXTileCount, mYTileCount);
        if (this.mMode == 1 || this.mMode == 2) {
            initNewGame();
            setMode(0);
            invalidate();
        }
    }

    public void rollback() {
        if (this.mMode == 0 && this.mAIThread == null && !this.mStepSeq.empty()) {
            if (this.mStone != 2 || this.mStepSeq.size() != 1) {
                while (this.mStepSeq.size() > 0) {
                    Step step = this.mStepSeq.pop();
                    this.mBoard[step.x][step.y] = 0;
                    clearTile(step.x, step.y);
                    if (step.stone == this.mStone) {
                        return;
                    }
                }
            }
        }
    }

    @Override // net.mesa.game.gomokuchen.TileView
    public void clearTile(int x, int y) {
        if (x > 0 && x < mXTileCount - 1 && y > 0 && y < mYTileCount - 1) {
            setTile(1, x, y);
            return;
        }
        if (x == 0) {
            if (y > 0 && y < mYTileCount - 1) {
                setTile(5, x, y);
                return;
            } else if (y == 0) {
                setTile(8, x, y);
                return;
            } else {
                if (y == mYTileCount - 1) {
                    setTile(3, x, y);
                    return;
                }
                return;
            }
        }
        if (x == mXTileCount - 1) {
            if (y > 0 && y < mYTileCount - 1) {
                setTile(6, x, y);
                return;
            } else if (y == 0) {
                setTile(9, x, y);
                return;
            } else {
                if (y == mYTileCount - 1) {
                    setTile(4, x, y);
                    return;
                }
                return;
            }
        }
        if (y == 0) {
            if (x > 0 && x < mXTileCount - 1) {
                setTile(7, x, y);
                return;
            } else if (x == 0) {
                setTile(8, x, y);
                return;
            } else {
                if (x == mXTileCount - 1) {
                    setTile(9, x, y);
                    return;
                }
                return;
            }
        }
        if (y == mYTileCount - 1) {
            if (x > 0 && x < mXTileCount - 1) {
                setTile(2, x, y);
            } else if (x == 0) {
                setTile(3, x, y);
            } else if (x == mXTileCount - 1) {
                setTile(4, x, y);
            }
        }
    }

    public void setStoneTile(int stone, int x, int y) {
        if (x > 0 && x < mXTileCount - 1 && y > 0 && y < mYTileCount - 1) {
            super.setTile(stone == 1 ? 10 : CELL_WHITE, x, y);
            return;
        }
        if (x == 0) {
            if (y > 0 && y < mYTileCount - 1) {
                super.setTile(stone == 1 ? 14 : CELL_WHITE_LEFT, x, y);
                return;
            } else if (y == 0) {
                super.setTile(stone == 1 ? CELL_BLACK_TOP_LEFT : CELL_WHITE_TOP_LEFT, x, y);
                return;
            } else {
                if (y == mYTileCount - 1) {
                    super.setTile(stone == 1 ? 12 : CELL_WHITE_BOTTOM_LEFT, x, y);
                    return;
                }
                return;
            }
        }
        if (x == mXTileCount - 1) {
            if (y > 0 && y < mYTileCount - 1) {
                super.setTile(stone == 1 ? 15 : CELL_WHITE_RIGHT, x, y);
                return;
            } else if (y == 0) {
                super.setTile(stone == 1 ? CELL_BLACK_TOP_RIGHT : CELL_WHITE_TOP_RIGHT, x, y);
                return;
            } else {
                if (y == mYTileCount - 1) {
                    super.setTile(stone == 1 ? 13 : CELL_WHITE_BOTTOM_RIGHT, x, y);
                    return;
                }
                return;
            }
        }
        if (y == 0) {
            if (x > 0 && x < mXTileCount - 1) {
                super.setTile(stone == 1 ? CELL_BLACK_TOP : CELL_WHITE_TOP, x, y);
                return;
            } else if (x == 0) {
                super.setTile(stone == 1 ? CELL_BLACK_TOP_LEFT : CELL_WHITE_TOP_LEFT, x, y);
                return;
            } else {
                if (x == mXTileCount - 1) {
                    super.setTile(stone == 1 ? CELL_BLACK_TOP_RIGHT : CELL_WHITE_TOP_RIGHT, x, y);
                    return;
                }
                return;
            }
        }
        if (y == mYTileCount - 1) {
            if (x > 0 && x < mXTileCount - 1) {
                super.setTile(stone == 1 ? 11 : CELL_WHITE_BOTTOM, x, y);
            } else if (x == 0) {
                super.setTile(stone == 1 ? 12 : CELL_WHITE_BOTTOM_LEFT, x, y);
            } else if (x == mXTileCount - 1) {
                super.setTile(stone == 1 ? 13 : CELL_WHITE_BOTTOM_RIGHT, x, y);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.mesa.game.gomokuchen.TileView, android.view.View
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        initNewGame();
        setMode(0);
        invalidate();
    }

    @Override // net.mesa.game.gomokuchen.TileView, android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int center = mTileSize / 2;
        int r = mTileSize / 4;
        this.mPaint.setColor(-65536);
        if (this.mStepSeq.size() > 0) {
            Step step = this.mStepSeq.peek();
            int x = mXOffset + (step.x * mTileSize) + center;
            int y = mYOffset + (step.y * mTileSize) + center;
            canvas.drawLine(x - r, y, x + r, y, this.mPaint);
            canvas.drawLine(x, y - r, x, y + r, this.mPaint);
        }
        if (this.mStepSeq.size() > 1) {
            Step step2 = this.mStepSeq.elementAt(this.mStepSeq.size() - 2);
            int x2 = mXOffset + (step2.x * mTileSize) + center;
            int y2 = mYOffset + (step2.y * mTileSize) + center;
            canvas.drawLine(x2 - r, y2, x2 + r, y2, this.mPaint);
            canvas.drawLine(x2, y2 - r, x2, y2 + r, this.mPaint);
        }
        if (!this.mTouchScreen) {
            this.mPaint.setColor(Color.rgb(0, 85, 227));
            int x3 = mXOffset + (this.mFocusX * mTileSize) + center;
            int y3 = mYOffset + (this.mFocusY * mTileSize) + center;
            canvas.drawLine(x3 - r, y3 - 3, x3 - 3, y3 - 3, this.mPaint);
            canvas.drawLine(x3 - 3, y3 - 3, x3 - 3, y3 - r, this.mPaint);
            canvas.drawLine(x3 + 3, y3 - 3, x3 + r, y3 - 3, this.mPaint);
            canvas.drawLine(x3 + 3, y3 - 3, x3 + 3, y3 - r, this.mPaint);
            canvas.drawLine(x3 - r, y3 + 3, x3 - 3, y3 + 3, this.mPaint);
            canvas.drawLine(x3 - 3, y3 + 3, x3 - 3, y3 + r, this.mPaint);
            canvas.drawLine(x3 + 3, y3 + 2, x3 + r, y3 + 3, this.mPaint);
            canvas.drawLine(x3 + 3, y3 + 2, x3 + 3, y3 + r, this.mPaint);
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != 0) {
            return $assertionsDisabled;
        }
        if (this.mMode == 1 || this.mMode == 2) {
            initNewGame();
            setMode(0);
            invalidate();
            return true;
        }
        int i = (((int) event.getX()) - mXOffset) / mTileSize;
        int j = (((int) event.getY()) - mYOffset) / mTileSize;
        if (i < 0 || i >= mXTileCount || j < 0 || j >= mYTileCount || this.mBoard[i][j] != 0 || (this.mStepSeq.size() != 0 && this.mStepSeq.peek().stone == this.mStone)) {
            return $assertionsDisabled;
        }
        add(this.mStone, i, j);
        invalidate();
        if (this.mMode == 0) {
            response();
        }
        return true;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent msg) {
        if (this.mMode == 1 || this.mMode == 2) {
            initNewGame();
            setMode(0);
            invalidate();
            return true;
        }
        if (keyCode == CELL_WHITE && this.mMode == 0) {
            if (this.mFocusY > 0) {
                this.mFocusY--;
            }
            invalidate();
            return true;
        }
        if (keyCode == CELL_WHITE_BOTTOM && this.mMode == 0) {
            if (this.mFocusY < mYTileCount - 1) {
                this.mFocusY++;
            }
            invalidate();
            return true;
        }
        if (keyCode == CELL_WHITE_BOTTOM_LEFT && this.mMode == 0) {
            if (this.mFocusX > 0) {
                this.mFocusX--;
            }
            invalidate();
            return true;
        }
        if (keyCode == CELL_WHITE_BOTTOM_RIGHT && this.mMode == 0) {
            if (this.mFocusX < mXTileCount - 1) {
                this.mFocusX++;
            }
            invalidate();
            return true;
        }
        if (keyCode == CELL_WHITE_LEFT && this.mMode == 0 && this.mBoard[this.mFocusX][this.mFocusY] == 0 && (this.mStepSeq.size() == 0 || this.mStepSeq.peek().stone != this.mStone)) {
            add(this.mStone, this.mFocusX, this.mFocusY);
            invalidate();
            response();
            return true;
        }
        return super.onKeyDown(keyCode, msg);
    }

    public void setTextView(TextView newView) {
        this.mStatusText = newView;
        Resources res = getContext().getResources();
        this.mStatusText.setText(res.getString(R.string.mode_over_win));
    }

    public void setMode(int newMode) {
        int oldMode = this.mMode;
        this.mMode = newMode;
        if (newMode == 0 && oldMode == 0) {
            initNewGame();
            postInvalidate();
        } else {
            if (newMode == 0 && oldMode != 0) {
                if (this.mStatusText != null) {
                    this.mStatusText.setVisibility(4);
                    postInvalidate();
                    return;
                }
                return;
            }
            this.mGameOverHandler.update();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void add(int stone, int x, int y) {
        if (this.mMode == 0 && this.mBoard[x][y] == 0) {
            this.mBoard[x][y] = stone;
            setStoneTile(stone, x, y);
            Step step = new Step();
            step.x = x;
            step.y = y;
            step.stone = stone;
            this.mStepSeq.push(step);
            if (getThreat(this.mBoard, x, y, null) == 15) {
                if (stone == this.mStone) {
                    setMode(1);
                    return;
                } else {
                    setMode(2);
                    return;
                }
            }
            boolean full = true;
            for (int i = 0; i < mXTileCount; i++) {
                int j = 0;
                while (true) {
                    if (j >= mYTileCount) {
                        break;
                    }
                    if (this.mBoard[i][j] != 0) {
                        j++;
                    } else {
                        full = $assertionsDisabled;
                        break;
                    }
                }
                if (!full) {
                    break;
                }
            }
            if (full) {
                setMode(3);
            }
        }
    }

    private void response() {
        this.mAIThread = new Thread(new Runnable() { // from class: net.mesa.game.gomokuchen.GomokuView.1
            @Override // java.lang.Runnable
            public void run() {
                for (int i = 0; i < GomokuView.mXTileCount; i++) {
                    for (int j = 0; j < GomokuView.mYTileCount; j++) {
                        GomokuView.this.mWorkingBoard[i][j] = GomokuView.this.mBoard[i][j];
                    }
                }
                Stack<Step> s = new Stack<>();
                s.addAll(GomokuView.this.mStepSeq);
                GomokuView.this.alphabeta(GomokuView.this.mWorkingBoard, s, GomokuView.this.mPlyDepth, -2147483647, Integer.MAX_VALUE);
                GomokuView.this.add(GomokuView.this.mStone == 1 ? 2 : 1, GomokuView.this.mNextX, GomokuView.this.mNextY);
                GomokuView.this.postInvalidate();
                GomokuView.this.mAIThread = null;
            }
        });
        this.mAIThread.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int alphabeta(int[][] board, Stack<Step> steps, int depth, int alpha, int beta) {
        Iterator<Integer> iter;
        int ret;
        if (depth == 0) {
            return eval(board, steps);
        }
        Vector<Integer> nodes = new Vector<>();
        HashSet<Integer> h = new HashSet<>();
        int s = getThreatSpace(nodes, board, steps);
        if (s >= 5) {
            iter = nodes.iterator();
        } else {
            Iterator<Integer> it = nodes.iterator();
            while (it.hasNext()) {
                int n = it.next().intValue();
                getSearchSpace(h, board, n >> CELL_BLACK_TOP, n & 255);
            }
            iter = h.iterator();
        }
        int stone = steps.peek().stone == 1 ? 2 : 1;
        while (iter.hasNext()) {
            int n2 = iter.next().intValue();
            int x = n2 >> CELL_BLACK_TOP;
            int y = n2 & 255;
            board[x][y] = stone;
            Step step = new Step();
            step.x = x;
            step.y = y;
            step.stone = stone;
            steps.push(step);
            if (getThreat(board, x, y, null) != 15) {
                ret = -alphabeta(board, steps, depth - 1, -beta, -alpha);
            } else {
                ret = (depth * 100) + 15;
            }
            board[x][y] = 0;
            steps.pop();
            if (alpha < ret) {
                alpha = ret;
                if (depth == this.mPlyDepth) {
                    this.mNextX = x;
                    this.mNextY = y;
                }
            }
            if (alpha >= beta) {
                return alpha;
            }
        }
        return alpha;
    }

    private int getThreatSpace(Vector<Integer> nodes, int[][] board, Vector<Step> steps) {
        int blackMax = -2147483647;
        Integer black = null;
        int whiteMax = -2147483647;
        Integer white = null;
        int score = -2147483647;
        Vector<Integer> nv = null;
        Iterator<Step> it = steps.iterator();
        while (it.hasNext()) {
            Step step = it.next();
            int x = step.x;
            int y = step.y;
            Vector<Integer> threats = new Vector<>();
            int threat = getThreat(board, x, y, threats);
            if (score <= threat) {
                score = threat;
                nv = threats;
            }
            if (board[x][y] == 1 && blackMax <= threat) {
                blackMax = threat;
                black = new Integer((x << CELL_BLACK_TOP) | y);
            }
            if (board[x][y] == 2 && whiteMax <= threat) {
                whiteMax = threat;
                white = new Integer((x << CELL_BLACK_TOP) | y);
            }
        }
        if (score < 5) {
            if (black != null) {
                nodes.addElement(black);
            }
            if (white != null) {
                nodes.addElement(white);
            }
        } else {
            nodes.addAll(nv);
        }
        return score;
    }

    private void getSearchSpace(HashSet<Integer> nodes, int[][] board, int x, int y) {
        if (x >= 0 && y >= 0 && x < mXTileCount && y < mYTileCount) {
            int i = 1;
            while (true) {
                if (i >= 5 || x - i < 0 || y - i < 0) {
                    break;
                }
                if (board[x - i][y - i] == 0) {
                    Integer obj = new Integer(((x - i) << CELL_BLACK_TOP) | (y - i));
                    nodes.add(obj);
                    break;
                } else if (board[x - i][y - i] != board[x][y]) {
                    break;
                } else {
                    i++;
                }
            }
            int i2 = 1;
            while (true) {
                if (i2 >= 5 || x + i2 >= mXTileCount || y + i2 >= mYTileCount) {
                    break;
                }
                if (board[x + i2][y + i2] == 0) {
                    Integer obj2 = new Integer(((x + i2) << CELL_BLACK_TOP) | (y + i2));
                    nodes.add(obj2);
                    break;
                } else if (board[x + i2][y + i2] != board[x][y]) {
                    break;
                } else {
                    i2++;
                }
            }
            int i3 = 1;
            while (true) {
                if (i3 >= 5 || x + i3 >= mXTileCount || y - i3 < 0) {
                    break;
                }
                if (board[x + i3][y - i3] == 0) {
                    Integer obj3 = new Integer(((x + i3) << CELL_BLACK_TOP) | (y - i3));
                    nodes.add(obj3);
                    break;
                } else if (board[x + i3][y - i3] != board[x][y]) {
                    break;
                } else {
                    i3++;
                }
            }
            int i4 = 1;
            while (true) {
                if (i4 >= 5 || x - i4 < 0 || y + i4 >= mYTileCount) {
                    break;
                }
                if (board[x - i4][y + i4] == 0) {
                    Integer obj4 = new Integer(((x - i4) << CELL_BLACK_TOP) | (y + i4));
                    nodes.add(obj4);
                    break;
                } else if (board[x - i4][y + i4] != board[x][y]) {
                    break;
                } else {
                    i4++;
                }
            }
            int i5 = 1;
            while (true) {
                if (i5 >= 5 || x - i5 < 0) {
                    break;
                }
                if (board[x - i5][y] == 0) {
                    Integer obj5 = new Integer(((x - i5) << CELL_BLACK_TOP) | y);
                    nodes.add(obj5);
                    break;
                } else if (board[x - i5][y] != board[x][y]) {
                    break;
                } else {
                    i5++;
                }
            }
            int i6 = 1;
            while (true) {
                if (i6 >= 5 || x + i6 >= mXTileCount) {
                    break;
                }
                if (board[x + i6][y] == 0) {
                    Integer obj6 = new Integer(((x + i6) << CELL_BLACK_TOP) | y);
                    nodes.add(obj6);
                    break;
                } else if (board[x + i6][y] != board[x][y]) {
                    break;
                } else {
                    i6++;
                }
            }
            int i7 = 1;
            while (true) {
                if (i7 >= 5 || y - i7 < 0) {
                    break;
                }
                if (board[x][y - i7] == 0) {
                    Integer obj7 = new Integer((x << CELL_BLACK_TOP) | (y - i7));
                    nodes.add(obj7);
                    break;
                } else if (board[x][y - i7] != board[x][y]) {
                    break;
                } else {
                    i7++;
                }
            }
            for (int i8 = 1; i8 < 5 && y + i8 < mYTileCount; i8++) {
                if (board[x][y + i8] == 0) {
                    Integer obj8 = new Integer((x << CELL_BLACK_TOP) | (y + i8));
                    nodes.add(obj8);
                    return;
                } else {
                    if (board[x][y + i8] != board[x][y]) {
                        return;
                    }
                }
            }
        }
    }

    private int eval(int[][] board, Vector<Step> steps) {
        int score = -2147483647;
        int color = 0;
        Step step = steps.elementAt(steps.size() - 1);
        int next = step.stone == 1 ? 2 : 1;
        int i = steps.size();
        while (true) {
            int i2 = i;
            i = i2 - 1;
            if (i2 <= 0) {
                break;
            }
            Step step2 = steps.elementAt(i);
            Step step3 = step2;
            int x = step3.x;
            int y = step3.y;
            int threat = getThreat(board, x, y, null);
            if (score < threat || ((score == threat || (score >= 8 && threat >= 8)) && board[x][y] == next)) {
                score = threat;
                color = board[x][y];
            }
        }
        if (color != next) {
            return -score;
        }
        return score;
    }

    private int getThreat(int[][] board, int x, int y, Vector<Integer> threats) {
        if (board[x][y] == 0) {
            return 0;
        }
        int two = 0;
        int cappedTwo = 0;
        int three = 0;
        int cappedThree = 0;
        int brokenThree = 0;
        int four = 0;
        int cappedFour = 0;
        int brokenFour = 0;
        int five = 0;
        int k = 1;
        int capped = 0;
        while (k < 5 && x - k >= 0 && y - k >= 0 && board[x - k][y - k] == board[x][y]) {
            k++;
        }
        Integer e1 = null;
        Integer e3 = null;
        int distantFriend = 0;
        if (x - k < 0 || y - k < 0 || board[x - k][y - k] != 0) {
            capped = 0 + 1;
        } else {
            e1 = new Integer(((x - k) << CELL_BLACK_TOP) | (y - k));
            if ((x - k) - 1 >= 0 && (y - k) - 1 >= 0 && board[(x - k) - 1][(y - k) - 1] == board[x][y]) {
                if (0 < 1) {
                    distantFriend = 1;
                }
                if ((x - k) - 2 >= 0 && (y - k) - 2 >= 0 && board[(x - k) - 2][(y - k) - 2] == 0) {
                    e3 = new Integer((((x - k) - 2) << CELL_BLACK_TOP) | ((y - k) - 2));
                }
                if ((x - k) - 2 >= 0 && (y - k) - 2 >= 0 && board[(x - k) - 2][(y - k) - 2] == board[x][y] && distantFriend < 2) {
                    distantFriend = 2;
                }
            }
        }
        int n = 0;
        int k2 = -(k - 1);
        while (k2 < 5 && x + k2 < mXTileCount && y + k2 < mYTileCount && board[x + k2][y + k2] == board[x][y]) {
            n++;
            k2++;
        }
        Integer e2 = null;
        Integer e4 = null;
        if (x + k2 == mXTileCount || y + k2 == mYTileCount || board[x + k2][y + k2] != 0) {
            capped++;
        } else {
            e2 = new Integer(((x + k2) << CELL_BLACK_TOP) | (y + k2));
            if (x + k2 + 1 < mXTileCount && y + k2 + 1 < mYTileCount && board[x + k2 + 1][y + k2 + 1] == board[x][y]) {
                if (distantFriend < 1) {
                    distantFriend = 1;
                }
                if (x + k2 + 2 < mXTileCount && y + k2 + 2 < mYTileCount && board[x + k2 + 2][y + k2 + 2] == 0) {
                    e4 = new Integer((((x + k2) + 2) << CELL_BLACK_TOP) | (y + k2 + 2));
                }
                if (x + k2 + 2 < mXTileCount && y + k2 + 2 < mYTileCount && board[x + k2 + 2][y + k2 + 2] == board[x][y] && distantFriend < 2) {
                    distantFriend = 2;
                }
            }
        }
        if (n >= 5) {
            five = 0 + 1;
        } else if (capped == 0 && n == 2 && (e3 != null || e4 != null)) {
            brokenThree = 0 + 1;
            if (threats != null) {
                if (e1 != null) {
                    threats.addElement(e1);
                }
                if (e2 != null) {
                    threats.addElement(e2);
                }
                if (e3 != null) {
                    threats.addElement(e3);
                }
                if (e4 != null) {
                    threats.addElement(e4);
                }
            }
        } else if (n == 2 && distantFriend == 2) {
            brokenFour = 0 + 1;
            if (threats != null) {
                if (e1 != null) {
                    threats.addElement(e1);
                }
                if (e2 != null) {
                    threats.addElement(e2);
                }
                if (e3 != null) {
                    threats.addElement(e3);
                }
                if (e4 != null) {
                    threats.addElement(e4);
                }
            }
        } else if (n == 3 && distantFriend > 0) {
            brokenFour = 0 + 1;
            if (threats != null) {
                if (e1 != null) {
                    threats.addElement(e1);
                }
                if (e2 != null) {
                    threats.addElement(e2);
                }
                if (e3 != null) {
                    threats.addElement(e3);
                }
                if (e4 != null) {
                    threats.addElement(e4);
                }
            }
        } else if (capped < 2) {
            switch (n) {
                case 2:
                    if (capped == 0) {
                        two = 0 + 1;
                        break;
                    } else {
                        cappedTwo = 0 + 1;
                        break;
                    }
                case 3:
                    if (capped == 0) {
                        three = 0 + 1;
                    } else {
                        cappedThree = 0 + 1;
                    }
                    cappedThree++;
                    if (threats != null && capped == 0) {
                        if (e1 != null) {
                            threats.addElement(e1);
                        }
                        if (e2 != null) {
                            threats.addElement(e2);
                            break;
                        }
                    }
                    break;
                case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                    if (capped == 0) {
                        four = 0 + 1;
                    } else {
                        cappedFour = 0 + 1;
                    }
                    cappedFour++;
                    if (threats != null) {
                        if (e1 != null) {
                            threats.addElement(e1);
                        }
                        if (e2 != null) {
                            threats.addElement(e2);
                            break;
                        }
                    }
                    break;
            }
        }
        int k3 = 1;
        int capped2 = 0;
        while (k3 < 5 && x + k3 < mXTileCount && y - k3 >= 0 && board[x + k3][y - k3] == board[x][y]) {
            k3++;
        }
        Integer e12 = null;
        Integer e32 = null;
        int distantFriend2 = 0;
        if (x + k3 == mXTileCount || y - k3 < 0 || board[x + k3][y - k3] != 0) {
            capped2 = 0 + 1;
        } else {
            e12 = new Integer(((x + k3) << CELL_BLACK_TOP) | (y - k3));
            if (x + k3 + 1 < mXTileCount && (y - k3) - 1 >= 0 && board[x + k3 + 1][(y - k3) - 1] == board[x][y]) {
                if (0 < 1) {
                    distantFriend2 = 1;
                }
                if (x + k3 + 2 < mXTileCount && (y - k3) - 2 >= 0 && board[x + k3 + 2][(y - k3) - 2] == 0) {
                    e32 = new Integer((((x + k3) + 2) << CELL_BLACK_TOP) | ((y - k3) - 2));
                }
                if (x + k3 + 2 < mXTileCount && (y - k3) - 2 >= 0 && board[x + k3 + 2][(y - k3) - 2] == board[x][y] && distantFriend2 < 2) {
                    distantFriend2 = 2;
                }
            }
        }
        int n2 = 0;
        int k4 = -(k3 - 1);
        while (k4 < 5 && x - k4 >= 0 && y + k4 < mYTileCount && board[x - k4][y + k4] == board[x][y]) {
            n2++;
            k4++;
        }
        Integer e22 = null;
        Integer e42 = null;
        if (x - k4 < 0 || y + k4 == mYTileCount || board[x - k4][y + k4] != 0) {
            capped2++;
        } else {
            e22 = new Integer(((x - k4) << CELL_BLACK_TOP) | (y + k4));
            if ((x - k4) - 1 >= 0 && y + k4 + 1 < mYTileCount && board[(x - k4) - 1][y + k4 + 1] == board[x][y]) {
                if (distantFriend2 < 1) {
                    distantFriend2 = 1;
                }
                if ((x - k4) - 2 >= 0 && y + k4 + 2 < mYTileCount && board[(x - k4) - 2][y + k4 + 2] == 0) {
                    e42 = new Integer((((x - k4) - 2) << CELL_BLACK_TOP) | (y + k4 + 2));
                }
                if ((x - k4) - 2 >= 0 && y + k4 + 2 < mYTileCount && board[(x - k4) - 2][y + k4 + 2] == board[x][y] && distantFriend2 < 2) {
                    distantFriend2 = 2;
                }
            }
        }
        if (n2 >= 5) {
            five++;
        } else if (capped2 == 0 && n2 == 2 && (e32 != null || e42 != null)) {
            brokenThree++;
            if (threats != null) {
                if (e12 != null) {
                    threats.addElement(e12);
                }
                if (e22 != null) {
                    threats.addElement(e22);
                }
                if (e32 != null) {
                    threats.addElement(e32);
                }
                if (e42 != null) {
                    threats.addElement(e42);
                }
            }
        } else if (n2 == 2 && distantFriend2 == 2) {
            brokenFour++;
            if (threats != null) {
                if (e12 != null) {
                    threats.addElement(e12);
                }
                if (e22 != null) {
                    threats.addElement(e22);
                }
                if (e32 != null) {
                    threats.addElement(e32);
                }
                if (e42 != null) {
                    threats.addElement(e42);
                }
            }
        } else if (n2 == 3 && distantFriend2 > 0) {
            brokenFour++;
            if (threats != null) {
                if (e12 != null) {
                    threats.addElement(e12);
                }
                if (e22 != null) {
                    threats.addElement(e22);
                }
                if (e32 != null) {
                    threats.addElement(e32);
                }
                if (e42 != null) {
                    threats.addElement(e42);
                }
            }
        } else if (capped2 < 2) {
            switch (n2) {
                case 2:
                    if (capped2 != 0) {
                        cappedTwo++;
                        break;
                    } else {
                        two++;
                        break;
                    }
                case 3:
                    if (capped2 == 0) {
                        three++;
                    } else {
                        cappedThree++;
                    }
                    cappedThree++;
                    if (threats != null && capped2 == 0) {
                        if (e12 != null) {
                            threats.addElement(e12);
                        }
                        if (e22 != null) {
                            threats.addElement(e22);
                            break;
                        }
                    }
                    break;
                case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                    if (capped2 == 0) {
                        four++;
                    } else {
                        cappedFour++;
                    }
                    cappedFour++;
                    if (threats != null) {
                        if (e12 != null) {
                            threats.addElement(e12);
                        }
                        if (e22 != null) {
                            threats.addElement(e22);
                            break;
                        }
                    }
                    break;
            }
        }
        int k5 = 1;
        int capped3 = 0;
        while (k5 <= 5 && y - k5 >= 0 && board[x][y - k5] == board[x][y]) {
            k5++;
        }
        Integer e13 = null;
        Integer e33 = null;
        int distantFriend3 = 0;
        if (y - k5 < 0 || board[x][y - k5] != 0) {
            capped3 = 0 + 1;
        } else {
            e13 = new Integer((x << CELL_BLACK_TOP) | (y - k5));
            if ((y - k5) - 1 >= 0 && board[x][(y - k5) - 1] == board[x][y]) {
                if (0 < 1) {
                    distantFriend3 = 1;
                }
                if ((y - k5) - 2 >= 0 && board[x][(y - k5) - 2] == 0) {
                    e33 = new Integer((x << CELL_BLACK_TOP) | ((y - k5) - 2));
                }
                if ((y - k5) - 2 >= 0 && board[x][(y - k5) - 2] == board[x][y] && distantFriend3 < 2) {
                    distantFriend3 = 2;
                }
            }
        }
        int n3 = 0;
        int k6 = -(k5 - 1);
        while (k6 < 5 && y + k6 < mYTileCount && board[x][y + k6] == board[x][y]) {
            n3++;
            k6++;
        }
        Integer e23 = null;
        Integer e43 = null;
        if (y + k6 == mYTileCount || board[x][y + k6] != 0) {
            capped3++;
        } else {
            e23 = new Integer((x << CELL_BLACK_TOP) | (y + k6));
            if (y + k6 + 1 < mYTileCount && board[x][y + k6 + 1] == board[x][y]) {
                if (distantFriend3 < 1) {
                    distantFriend3 = 1;
                }
                if (y + k6 + 2 < mYTileCount && board[x][y + k6 + 2] == 0) {
                    e43 = new Integer((x << CELL_BLACK_TOP) | (y + k6 + 2));
                }
                if (y + k6 + 2 < mYTileCount && board[x][y + k6 + 2] == board[x][y] && distantFriend3 < 2) {
                    distantFriend3 = 2;
                }
            }
        }
        if (n3 >= 5) {
            five++;
        } else if (capped3 == 0 && n3 == 2 && (e33 != null || e43 != null)) {
            brokenThree++;
            if (threats != null) {
                if (e13 != null) {
                    threats.addElement(e13);
                }
                if (e23 != null) {
                    threats.addElement(e23);
                }
                if (e33 != null) {
                    threats.addElement(e33);
                }
                if (e43 != null) {
                    threats.addElement(e43);
                }
            }
        } else if (n3 == 2 && distantFriend3 == 2) {
            brokenFour++;
            if (threats != null) {
                if (e13 != null) {
                    threats.addElement(e13);
                }
                if (e23 != null) {
                    threats.addElement(e23);
                }
                if (e33 != null) {
                    threats.addElement(e33);
                }
                if (e43 != null) {
                    threats.addElement(e43);
                }
            }
        } else if (n3 == 3 && distantFriend3 > 0) {
            brokenFour++;
            if (threats != null) {
                if (e13 != null) {
                    threats.addElement(e13);
                }
                if (e23 != null) {
                    threats.addElement(e23);
                }
                if (e33 != null) {
                    threats.addElement(e33);
                }
                if (e43 != null) {
                    threats.addElement(e43);
                }
            }
        } else if (capped3 < 2) {
            switch (n3) {
                case 2:
                    if (capped3 != 0) {
                        cappedTwo++;
                        break;
                    } else {
                        two++;
                        break;
                    }
                case 3:
                    if (capped3 == 0) {
                        three++;
                    } else {
                        cappedThree++;
                    }
                    cappedThree++;
                    if (threats != null && capped3 == 0) {
                        if (e13 != null) {
                            threats.addElement(e13);
                        }
                        if (e23 != null) {
                            threats.addElement(e23);
                            break;
                        }
                    }
                    break;
                case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                    if (capped3 == 0) {
                        four++;
                    } else {
                        cappedFour++;
                    }
                    cappedFour++;
                    if (threats != null) {
                        if (e13 != null) {
                            threats.addElement(e13);
                        }
                        if (e23 != null) {
                            threats.addElement(e23);
                            break;
                        }
                    }
                    break;
            }
        }
        int k7 = 1;
        int capped4 = 0;
        while (k7 <= 5 && x - k7 >= 0 && board[x - k7][y] == board[x][y]) {
            k7++;
        }
        Integer e14 = null;
        Integer e34 = null;
        int distantFriend4 = 0;
        if (x - k7 < 0 || board[x - k7][y] != 0) {
            capped4 = 0 + 1;
        } else {
            e14 = new Integer(((x - k7) << CELL_BLACK_TOP) | y);
            if ((x - k7) - 1 >= 0 && board[(x - k7) - 1][y] == board[x][y]) {
                if (0 < 1) {
                    distantFriend4 = 1;
                }
                if ((x - k7) - 2 >= 0 && board[(x - k7) - 2][y] == 0) {
                    e34 = new Integer((((x - k7) - 2) << CELL_BLACK_TOP) | y);
                }
                if ((x - k7) - 2 >= 0 && board[(x - k7) - 2][y] == board[x][y] && distantFriend4 < 2) {
                    distantFriend4 = 2;
                }
            }
        }
        int n4 = 0;
        int k8 = -(k7 - 1);
        while (k8 < 5 && x + k8 < mXTileCount && board[x + k8][y] == board[x][y]) {
            n4++;
            k8++;
        }
        Integer e24 = null;
        Integer e44 = null;
        if (x + k8 == mXTileCount || board[x + k8][y] != 0) {
            capped4++;
        } else {
            e24 = new Integer(((x + k8) << CELL_BLACK_TOP) | y);
            if (x + k8 + 1 < mXTileCount && board[x + k8 + 1][y] == board[x][y]) {
                if (distantFriend4 < 1) {
                    distantFriend4 = 1;
                }
                if (x + k8 + 2 < mXTileCount && board[x + k8 + 2][y] == 0) {
                    e44 = new Integer((((x + k8) + 2) << CELL_BLACK_TOP) | y);
                }
                if (x + k8 + 2 < mXTileCount && board[x + k8 + 2][y] == board[x][y] && distantFriend4 < 2) {
                    distantFriend4 = 2;
                }
            }
        }
        if (n4 >= 5) {
            five++;
        } else if (capped4 == 0 && n4 == 2 && (e34 != null || e44 != null)) {
            brokenThree++;
            if (threats != null) {
                if (e14 != null) {
                    threats.addElement(e14);
                }
                if (e24 != null) {
                    threats.addElement(e24);
                }
                if (e34 != null) {
                    threats.addElement(e34);
                }
                if (e44 != null) {
                    threats.addElement(e44);
                }
            }
        } else if (n4 == 2 && distantFriend4 == 2) {
            brokenFour++;
            if (threats != null) {
                if (e14 != null) {
                    threats.addElement(e14);
                }
                if (e24 != null) {
                    threats.addElement(e24);
                }
                if (e34 != null) {
                    threats.addElement(e34);
                }
                if (e44 != null) {
                    threats.addElement(e44);
                }
            }
        } else if (n4 == 3 && distantFriend4 > 0) {
            brokenFour++;
            if (threats != null) {
                if (e14 != null) {
                    threats.addElement(e14);
                }
                if (e24 != null) {
                    threats.addElement(e24);
                }
                if (e34 != null) {
                    threats.addElement(e34);
                }
                if (e44 != null) {
                    threats.addElement(e44);
                }
            }
        } else if (capped4 < 2) {
            switch (n4) {
                case 2:
                    if (capped4 != 0) {
                        cappedTwo++;
                        break;
                    } else {
                        two++;
                        break;
                    }
                case 3:
                    if (capped4 == 0) {
                        three++;
                    } else {
                        cappedThree++;
                    }
                    cappedThree++;
                    if (threats != null && capped4 == 0) {
                        if (e14 != null) {
                            threats.addElement(e14);
                        }
                        if (e24 != null) {
                            threats.addElement(e24);
                            break;
                        }
                    }
                    break;
                case AdComponent.FAIL_START_ACTIVITY /* 4 */:
                    if (capped4 == 0) {
                        four++;
                    } else {
                        cappedFour++;
                    }
                    cappedFour++;
                    if (threats != null) {
                        if (e14 != null) {
                            threats.addElement(e14);
                        }
                        if (e24 != null) {
                            threats.addElement(e24);
                            break;
                        }
                    }
                    break;
            }
        }
        int threat = 0;
        if (five > 0) {
            threat = 15;
        } else if (four > 0) {
            threat = 12;
            if (four > 1 || brokenFour > 0) {
                threat = 14;
            }
        } else if (brokenFour > 0) {
            threat = 9;
            if (three > 0) {
                threat = 11;
            }
        } else if (cappedFour > 0) {
            threat = 8;
            if (three > 0 || brokenThree > 0) {
                threat = 13;
            } else if (two > 0) {
                threat = 10;
            }
        } else if (brokenThree > 0) {
            threat = 6;
            if (three > 0) {
                threat = 11;
            } else if (two > 0) {
                threat = 7;
            }
        } else if (three > 0) {
            threat = 5;
            if (three > 1) {
                threat = 11;
            } else if (two > 0) {
                threat = 7;
            }
        } else if (cappedThree > 0) {
            threat = 3;
        } else if (two > 0) {
            threat = 2;
            if (two > 1) {
                threat = 4;
            }
        } else if (cappedTwo > 0) {
            threat = 1;
        }
        return threat;
    }
}
