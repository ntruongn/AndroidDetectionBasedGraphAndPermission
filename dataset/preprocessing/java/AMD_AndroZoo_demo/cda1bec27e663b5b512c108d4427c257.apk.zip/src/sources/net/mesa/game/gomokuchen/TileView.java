package net.mesa.game.gomokuchen;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import java.lang.reflect.Array;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class TileView extends View {
    protected static int mTileSize;
    protected static int mXOffset;
    protected static int mXTileCount;
    protected static int mYOffset;
    protected static int mYTileCount;
    protected final Paint mPaint;
    protected Bitmap[] mTileArray;
    protected int[][] mTileGrid;

    public TileView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mPaint = new Paint();
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.TileView);
        mTileSize = a.getInt(0, 32);
        a.recycle();
    }

    public TileView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mPaint = new Paint();
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.TileView);
        mTileSize = a.getInt(0, 32);
        a.recycle();
    }

    public void resetTiles(int tilecount) {
        this.mTileArray = new Bitmap[tilecount];
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.View
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        mXTileCount = (int) Math.floor(w / mTileSize);
        mYTileCount = (int) Math.floor(h / mTileSize);
        mXOffset = (w - (mTileSize * mXTileCount)) / 2;
        mYOffset = (h - (mTileSize * mYTileCount)) / 2;
        this.mTileGrid = (int[][]) Array.newInstance((Class<?>) Integer.TYPE, mXTileCount, mYTileCount);
    }

    public void loadTile(int key, Drawable tile) {
        Bitmap bitmap = Bitmap.createBitmap(tile.getMinimumWidth(), tile.getMinimumHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        tile.setBounds(0, 0, tile.getMinimumWidth(), tile.getMinimumHeight());
        tile.draw(canvas);
        this.mTileArray[key] = bitmap;
    }

    public void clearTile(int x, int y) {
        if (x >= 0 && x < mXTileCount && y >= 0 && y < mYTileCount) {
            setTile(0, x, y);
        }
    }

    public void clearTiles() {
        for (int x = 0; x < mXTileCount; x++) {
            for (int y = 0; y < mYTileCount; y++) {
                clearTile(x, y);
            }
        }
    }

    public void setTile(int tileindex, int x, int y) {
        if (this.mTileGrid != null) {
            this.mTileGrid[x][y] = tileindex;
        }
    }

    public int getTile(int x, int y) {
        if (this.mTileGrid != null) {
            return this.mTileGrid[x][y];
        }
        return 0;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (int x = 0; x < mXTileCount; x++) {
            for (int y = 0; y < mYTileCount; y++) {
                if (this.mTileGrid[x][y] > 0) {
                    canvas.drawBitmap(this.mTileArray[this.mTileGrid[x][y]], mXOffset + (mTileSize * x) + ((mTileSize - this.mTileArray[this.mTileGrid[x][y]].getWidth()) / 2), mYOffset + (mTileSize * y) + ((mTileSize - this.mTileArray[this.mTileGrid[x][y]].getHeight()) / 2), this.mPaint);
                }
            }
        }
    }
}
