package net.mesa.game.gomokuchen;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class R {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public static final class attr {
        public static final int tileSize = 0x7f010000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public static final class drawable {
        public static final int black = 0x7f020000;
        public static final int black_bottom = 0x7f020001;
        public static final int black_bottom_left = 0x7f020002;
        public static final int black_bottom_right = 0x7f020003;
        public static final int black_left = 0x7f020004;
        public static final int black_right = 0x7f020005;
        public static final int black_top = 0x7f020006;
        public static final int black_top_left = 0x7f020007;
        public static final int black_top_right = 0x7f020008;
        public static final int empty = 0x7f020009;
        public static final int empty_bottom = 0x7f02000a;
        public static final int empty_bottom_left = 0x7f02000b;
        public static final int empty_bottom_right = 0x7f02000c;
        public static final int empty_left = 0x7f02000d;
        public static final int empty_right = 0x7f02000e;
        public static final int empty_top = 0x7f02000f;
        public static final int empty_top_left = 0x7f020010;
        public static final int empty_top_right = 0x7f020011;
        public static final int exit32 = 0x7f020012;
        public static final int icon = 0x7f020013;
        public static final int options32 = 0x7f020014;
        public static final int rollback32 = 0x7f020015;
        public static final int white = 0x7f020016;
        public static final int white_bottom = 0x7f020017;
        public static final int white_bottom_left = 0x7f020018;
        public static final int white_bottom_right = 0x7f020019;
        public static final int white_left = 0x7f02001a;
        public static final int white_right = 0x7f02001b;
        public static final int white_top = 0x7f02001c;
        public static final int white_top_left = 0x7f02001d;
        public static final int white_top_right = 0x7f02001e;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public static final class id {
        public static final int gomoku = 0x7f060000;
        public static final int menu_exit = 0x7f060003;
        public static final int menu_rollback = 0x7f060002;
        public static final int text = 0x7f060001;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public static final class layout {
        public static final int main_layout = 0x7f030000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public static final class menu {
        public static final int menu = 0x7f050000;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public static final class string {
        public static final int gomoku_layout_text_text = 0x7f040000;
        public static final int menu_exit = 0x7f040006;
        public static final int menu_options = 0x7f040005;
        public static final int menu_rollback = 0x7f040004;
        public static final int mode_over_lose = 0x7f040002;
        public static final int mode_over_tie = 0x7f040003;
        public static final int mode_over_win = 0x7f040001;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public static final class styleable {
        public static final int[] TileView = {R.attr.tileSize};
        public static final int TileView_tileSize = 0;
    }
}
