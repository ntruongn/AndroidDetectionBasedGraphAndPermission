package com.adfeiwo.ad.coverscreen;

import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* renamed from: com.adfeiwo.ad.coverscreen.a, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class C0000a extends TimerTask {
    private /* synthetic */ AdComponent a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public C0000a(AdComponent adComponent) {
        this.a = adComponent;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public final void run() {
        this.a.c();
    }
}
