package com.adfeiwo.ad.coverscreen;

import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class x extends LinearLayout {
    boolean a;
    com.adfeiwo.ad.coverscreen.b.a b;
    SA c;

    public x(SA sa, com.adfeiwo.ad.coverscreen.b.a aVar, boolean z) {
        super(sa);
        new Handler();
        setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        setGravity(17);
        this.a = z;
        this.c = sa;
        this.b = aVar;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void b(View view) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(1000L);
        view.startAnimation(alphaAnimation);
    }

    protected void a() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(View view) {
        ScaleAnimation scaleAnimation = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setDuration(1000L);
        scaleAnimation.setAnimationListener(new B(this, view));
        view.startAnimation(scaleAnimation);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(ImageView imageView, String str) {
        imageView.setTag(str);
        com.adfeiwo.ad.coverscreen.c.e.e.a().a(getContext(), str, new A(this, imageView, str));
    }

    protected void b() {
    }

    protected View c() {
        return null;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public View d() {
        return null;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void e() {
        a();
        b();
        c().setOnClickListener(new y(this));
        d().setOnClickListener(new z(this));
        this.c.b(this.b);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void f() {
        this.c.finish();
    }
}
