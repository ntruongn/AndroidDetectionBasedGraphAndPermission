package com.unity3d.client;

import android.app.Notification;
import android.net.Uri;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class h {
    Notification a;
    String b;
    String c;
    int d;
    int e;
    Uri f;
    final /* synthetic */ Us g;

    public h(Us us) {
        this.g = us;
    }
}
