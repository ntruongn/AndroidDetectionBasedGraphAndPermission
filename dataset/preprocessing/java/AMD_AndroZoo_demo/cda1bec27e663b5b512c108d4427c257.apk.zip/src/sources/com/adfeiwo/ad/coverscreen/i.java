package com.adfeiwo.ad.coverscreen;

import android.graphics.Rect;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class i extends x {
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;
    private int i;
    private int j;
    private ImageView k;
    private RelativeLayout l;

    public i(SA sa, com.adfeiwo.ad.coverscreen.b.a aVar, boolean z) {
        super(sa, aVar, z);
        this.d = 5;
        this.e = 32;
        this.f = this.e / 2;
        this.g = 390;
        this.h = 250;
        this.i = this.g + this.e + (this.d << 1);
        this.j = this.h + this.e + (this.d << 1);
        e();
    }

    @Override // com.adfeiwo.ad.coverscreen.x
    protected final void a() {
        this.d = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.d);
        this.e = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.e);
        this.i = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.i);
        this.j = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.j);
        this.f = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.f);
        this.g = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.g);
        this.h = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.h);
        Rect rect = new Rect();
        this.c.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        com.adfeiwo.ad.coverscreen.c.g.a.a("initParam: [imageWidth: " + this.g + ",imageHeight: " + this.h + ",outContainerWidth: " + this.i + ",outContainerHeight: " + this.j + "]" + rect);
        int height = rect.height() - this.j;
        com.adfeiwo.ad.coverscreen.c.g.a.a("extraHeight: " + height + ",frame.height: " + rect.height() + ",outContainerHeight: " + this.j);
        if (height < 0 || Math.abs(height) > 10) {
            double height2 = ((double) (rect.height() - 10)) / this.j;
            double width = ((double) (rect.width() - 10)) / this.i;
            if (height2 <= width) {
                width = height2;
            }
            double d = width <= 2.0d ? width : 2.0d;
            this.d = (int) (this.d * d);
            this.e = (int) (this.e * d);
            this.i = (int) (this.i * d);
            this.j = (int) (this.j * d);
            this.f = (int) (this.f * d);
            this.g = (int) (this.g * d);
            this.h = (int) (this.h * d);
            com.adfeiwo.ad.coverscreen.c.g.a.a("initParam: [rate: " + d + ",imageWidth: " + this.g + ",imageHeight: " + this.h + ",outContainerWidth: " + this.i + ",outContainerHeight: " + this.j + "]");
        }
    }

    @Override // com.adfeiwo.ad.coverscreen.x
    protected final void b() {
        float f = this.d;
        ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(new float[]{f, f, f, f, f, f, f, f}, null, null));
        shapeDrawable.setPadding(this.d, this.d, this.d, this.d);
        shapeDrawable.getPaint().setColor(-1);
        this.l = new RelativeLayout(getContext());
        this.l.setLayoutParams(new LinearLayout.LayoutParams(this.i, this.j));
        addView(this.l);
        LinearLayout linearLayout = new LinearLayout(getContext());
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.setMargins(this.f, this.f, this.f, this.f);
        layoutParams.addRule(13, -1);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundDrawable(shapeDrawable);
        linearLayout.setOrientation(1);
        this.l.addView(linearLayout);
        this.k = new ImageView(getContext());
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(10, -1);
        layoutParams2.addRule(11, -1);
        int i = this.e;
        layoutParams2.width = i;
        layoutParams2.height = i;
        this.k.setLayoutParams(layoutParams2);
        this.k.setScaleType(ImageView.ScaleType.FIT_XY);
        ImageView imageView = this.k;
        getContext();
        imageView.setImageDrawable(com.adfeiwo.ad.coverscreen.c.d.b.a(com.adfeiwo.ad.coverscreen.a.a.c));
        this.l.addView(this.k);
        ImageView imageView2 = new ImageView(getContext());
        imageView2.setLayoutParams(new LinearLayout.LayoutParams(this.g, this.h));
        imageView2.setScaleType(ImageView.ScaleType.FIT_XY);
        a(imageView2, this.b.b());
        linearLayout.addView(imageView2);
        if (this.a) {
            a(this.l);
        } else {
            b(imageView2);
        }
    }

    @Override // com.adfeiwo.ad.coverscreen.x
    protected final View c() {
        return this.k;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.adfeiwo.ad.coverscreen.x
    public final View d() {
        return this.l;
    }
}
