package com.adfeiwo.ad.coverscreen;

import android.content.DialogInterface;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class l implements DialogInterface.OnClickListener {
    private /* synthetic */ SA a;
    private final /* synthetic */ com.adfeiwo.ad.coverscreen.b.a b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(SA sa, com.adfeiwo.ad.coverscreen.b.a aVar) {
        this.a = sa;
        this.b = aVar;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        this.a.c(this.b);
        if (this.a.b.isEmpty()) {
            this.a.finish();
        } else {
            this.a.a(false);
            this.a.c();
        }
    }
}
