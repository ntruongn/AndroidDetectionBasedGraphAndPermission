package com.adfeiwo.ad.coverscreen.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class a {
    private int a;
    private int b;
    private String c;
    private String d;
    private String e;
    private String f;
    private String g;
    private String h;
    private String i;
    private String j;
    private String k;
    private String l;
    private String m;

    public final int a() {
        return this.b;
    }

    public final void a(int i) {
        this.b = i;
    }

    public final void a(String str) {
        this.c = str;
    }

    public final String b() {
        return this.c;
    }

    public final void b(int i) {
        this.a = i;
    }

    public final void b(String str) {
        this.d = str;
    }

    public final String c() {
        return this.d;
    }

    public final void c(String str) {
        this.j = str;
    }

    public final String d() {
        return this.j;
    }

    public final void d(String str) {
        this.k = str;
    }

    public final String e() {
        return this.k;
    }

    public final void e(String str) {
        this.l = str;
    }

    public final String f() {
        return this.l;
    }

    public final void f(String str) {
        this.g = str;
    }

    public final String g() {
        return this.g;
    }

    public final void g(String str) {
        this.e = str;
    }

    public final String h() {
        return this.e;
    }

    public final void h(String str) {
        this.h = str;
    }

    public final String i() {
        return this.h;
    }

    public final void i(String str) {
        this.f = str;
    }

    public final String j() {
        return this.f;
    }

    public final void j(String str) {
        this.i = str;
    }

    public final String k() {
        return this.i;
    }

    public final void k(String str) {
        this.m = str;
    }

    public final String l() {
        return this.m;
    }

    public final int m() {
        return this.a;
    }
}
