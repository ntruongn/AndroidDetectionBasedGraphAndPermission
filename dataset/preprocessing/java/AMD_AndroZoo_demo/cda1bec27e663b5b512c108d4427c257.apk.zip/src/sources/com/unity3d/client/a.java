package com.unity3d.client;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class a {
    private String a;
    private String b;
    private String c;
    private String d;
    private String e;
    private String f;
    private String g;
    private String h;
    private String i;
    private String j;
    private String k;
    private int l;

    public String a() {
        return this.b;
    }

    public void a(int i) {
        this.l = i;
    }

    public void a(String str) {
        this.a = str;
    }

    public String b() {
        return this.d;
    }

    public void b(String str) {
        this.b = str;
    }

    public String c() {
        return this.e;
    }

    public void c(String str) {
        this.c = str;
    }

    public String d() {
        return this.f;
    }

    public void d(String str) {
        this.d = str;
    }

    public String e() {
        return this.g;
    }

    public void e(String str) {
        this.e = str;
    }

    public String f() {
        return this.h;
    }

    public void f(String str) {
        this.f = str;
    }

    public String g() {
        return this.i;
    }

    public void g(String str) {
        this.g = str;
    }

    public String h() {
        return this.j;
    }

    public void h(String str) {
        this.h = str;
    }

    public String i() {
        return this.k;
    }

    public void i(String str) {
        this.i = str;
    }

    public int j() {
        return this.l;
    }

    public void j(String str) {
        this.j = str;
    }

    public void k(String str) {
        this.k = str;
    }
}
