package com.adfeiwo.ad.coverscreen;

import android.content.Context;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class w implements com.adfeiwo.ad.coverscreen.c.j.e {
    private final /* synthetic */ Context a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public w(SR sr, Context context, String str) {
        this.a = context;
        this.b = str;
    }

    @Override // com.adfeiwo.ad.coverscreen.c.j.e
    public final void a(boolean z, String str) {
        com.adfeiwo.ad.coverscreen.c.g.a.a("服务器返回（sendAppInstall from ScreenReceiver）：" + str);
        if (z) {
            com.adfeiwo.ad.coverscreen.c.g.a.a("上传安装信息成功！");
            return;
        }
        com.adfeiwo.ad.coverscreen.c.g.a.a("上传安装信息失败：" + str);
        String a = com.adfeiwo.ad.coverscreen.c.d.c.a(this.a, "DP_COVER_FILE", "packnames", (String) null);
        if (a != null) {
            new StringBuilder(String.valueOf(a)).append(",").append(this.b);
        } else {
            String str2 = this.b;
        }
        com.adfeiwo.ad.coverscreen.c.d.c.b(this.a, "DP_COVER_FILE", "packnames", this.b);
    }
}
