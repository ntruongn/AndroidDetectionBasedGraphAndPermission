package com.adfeiwo.ad.coverscreen;

import android.content.Intent;
import android.net.Uri;
import android.webkit.DownloadListener;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
final class D implements DownloadListener {
    private /* synthetic */ WA a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public D(WA wa) {
        this.a = wa;
    }

    @Override // android.webkit.DownloadListener
    public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
        this.a.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
    }
}
