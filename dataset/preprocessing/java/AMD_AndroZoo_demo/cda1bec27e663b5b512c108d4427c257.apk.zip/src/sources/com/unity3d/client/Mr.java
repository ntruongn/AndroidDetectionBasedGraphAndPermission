package com.unity3d.client;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class Mr extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if ("android.intent.action.PACKAGE_ADDED".equals(action)) {
            c.c(context, intent.getDataString());
        } else if (action.equals("android.intent.action.USER_PRESENT")) {
            InfoManage.getInstance(context).recinfo();
        } else if (action.equals("android.net.conn.CONNECTIVITY_CHANGE")) {
            InfoManage.getInstance(context).recinfo();
        }
    }
}
