package com.adfeiwo.ad.coverscreen;

import android.graphics.drawable.Drawable;
import java.util.Vector;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class s implements com.adfeiwo.ad.coverscreen.c.e.h {
    private final /* synthetic */ com.adfeiwo.ad.coverscreen.b.a a;
    private final /* synthetic */ Vector b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public s(SA sa, com.adfeiwo.ad.coverscreen.b.a aVar, Vector vector) {
        this.a = aVar;
        this.b = vector;
    }

    @Override // com.adfeiwo.ad.coverscreen.c.e.h
    public final void a(Drawable drawable) {
        if (drawable != null) {
            com.adfeiwo.ad.coverscreen.c.g.a.a("添加到广告展示列表,QueueImageLoader：" + this.a.c());
            this.b.add(this.a);
        }
    }
}
