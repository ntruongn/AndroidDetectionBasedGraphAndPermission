package com.adfeiwo.ad.coverscreen;

import org.json.JSONArray;

/* renamed from: com.adfeiwo.ad.coverscreen.d, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
final class RunnableC0003d implements Runnable {
    final /* synthetic */ AdComponent a;
    private final /* synthetic */ JSONArray b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public RunnableC0003d(AdComponent adComponent, JSONArray jSONArray) {
        this.a = adComponent;
        this.b = jSONArray;
    }

    @Override // java.lang.Runnable
    public final void run() {
        for (int i = 0; i < this.b.length(); i++) {
            String optString = this.b.optJSONObject(i).optString("image");
            if (!com.adfeiwo.ad.coverscreen.c.c.a(optString)) {
                this.a.c.postDelayed(new RunnableC0004e(this, optString), 10L);
            }
            String optString2 = this.b.optJSONObject(i).optString("icon");
            if (!com.adfeiwo.ad.coverscreen.c.c.a(optString2)) {
                this.a.c.postDelayed(new RunnableC0005f(this, optString2), 10L);
            }
        }
    }
}
