package com.bving.img;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class Se extends Service {
    static String b = c.a;
    d a;

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.a = d.a(getApplicationContext(), b);
        this.a.a(c.m, getApplicationContext(), Context.class);
        this.a.a(c.j);
    }

    @Override // android.app.Service
    public void onStart(Intent intent, int i) {
        super.onStart(intent, i);
        this.a = d.a(getApplicationContext(), b);
        this.a.a(c.m, getApplicationContext(), Context.class);
        this.a.a(c.l, new Object[]{intent, Integer.valueOf(i)}, new Class[]{Intent.class, Integer.TYPE});
    }
}
