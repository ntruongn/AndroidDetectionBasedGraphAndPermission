package com.adfeiwo.ad.coverscreen.c.c;

import android.content.Context;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class a {
    private static a b = null;
    private ExecutorService a;

    private a() {
        this.a = null;
        if (this.a == null) {
            this.a = Executors.newFixedThreadPool(5);
        }
    }

    public static a a(Context context) {
        if (b == null) {
            b = new a();
        }
        return b;
    }

    public final void a(b bVar) {
        this.a.submit(bVar);
    }
}
