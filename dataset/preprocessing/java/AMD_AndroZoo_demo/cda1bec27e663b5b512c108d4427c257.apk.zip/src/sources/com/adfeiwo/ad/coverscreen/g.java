package com.adfeiwo.ad.coverscreen;

import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
final class g implements com.adfeiwo.ad.coverscreen.c.j.e {
    private /* synthetic */ CoverAdComponent a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(CoverAdComponent coverAdComponent) {
        this.a = coverAdComponent;
    }

    @Override // com.adfeiwo.ad.coverscreen.c.j.e
    public final void a(boolean z, String str) {
        this.a.f();
        com.adfeiwo.ad.coverscreen.c.g.a.b("获取广告的网络请求得到返回结果：" + str);
        if (z) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                int optInt = jSONObject.optInt("errorcode", 1);
                String optString = jSONObject.optString("errormessage");
                if (optInt != 0) {
                    this.a.f();
                    com.adfeiwo.ad.coverscreen.c.g.a.b("request failed: " + optString);
                } else {
                    int optInt2 = jSONObject.optInt("screenOnNum", -1);
                    int optInt3 = jSONObject.optInt("screenOnShowRate", -1);
                    int optInt4 = optInt2 == -1 ? jSONObject.optInt("screenNoNum", 3) : optInt2;
                    int optInt5 = optInt3 == -1 ? jSONObject.optInt("screenNoShowRate", 10) : optInt3;
                    int optInt6 = jSONObject.optInt("screenOnSwitchDelay", 10);
                    boolean optBoolean = jSONObject.optBoolean("screenOnShow", true);
                    boolean optBoolean2 = jSONObject.optBoolean("coverDownloadConfirm", false);
                    this.a.d = jSONObject.optJSONArray("ads");
                    this.a.e = new Date();
                    int i = optInt6 > 0 ? optInt6 : 10;
                    if (this.a.d != null) {
                        this.a.a(this.a.d);
                    }
                    this.a.f();
                    com.adfeiwo.ad.coverscreen.c.g.a.b("已获取到广告: " + this.a.d);
                    com.adfeiwo.ad.coverscreen.c.d.c.b(this.a.f(), "DP_COVER_FILE", "dpnum", optInt4);
                    com.adfeiwo.ad.coverscreen.c.d.c.b(this.a.f(), "DP_COVER_FILE", "dprate", optInt5);
                    com.adfeiwo.ad.coverscreen.c.d.c.b(this.a.f(), "DP_COVER_FILE", "dpswitchdelay", i * 1000);
                    com.adfeiwo.ad.coverscreen.c.d.c.b(this.a.f(), "DP_COVER_FILE", "showatscreenonplatform", optBoolean);
                    com.adfeiwo.ad.coverscreen.c.d.c.b(this.a.f(), "DP_COVER_FILE", "download_confirm", optBoolean2);
                    com.adfeiwo.ad.coverscreen.c.g.a.a("setContent, screenOnNum: " + optInt4 + ", screenOnShowRate: " + optInt5 + ", screenOnSwitchDelay: " + (i * 1000) + ", enableScreenOnShow: " + optBoolean + ", downloadConfirm: " + optBoolean2);
                }
            } catch (JSONException e) {
                this.a.f();
                com.adfeiwo.ad.coverscreen.c.g.a.b("error result: " + e);
            }
        }
        this.a.d();
        this.a.f();
        com.adfeiwo.ad.coverscreen.c.g.a.b("开启下次获取广告任务");
        this.a.a(false);
    }
}
