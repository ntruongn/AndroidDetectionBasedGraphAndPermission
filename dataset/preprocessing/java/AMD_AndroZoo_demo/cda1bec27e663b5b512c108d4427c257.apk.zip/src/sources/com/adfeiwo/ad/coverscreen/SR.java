package com.adfeiwo.ad.coverscreen;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class SR extends BroadcastReceiver {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void a(SR sr, Context context, String str) {
        String str2;
        String a = com.adfeiwo.ad.coverscreen.c.d.c.a(context, "DP_COVER_FILE", str.replace(".", ""));
        com.adfeiwo.ad.coverscreen.c.g.a.a("根据包名查询广告ID, [" + str + "," + a + "]");
        long j = 0;
        if (a == null || a.split(",").length != 2) {
            str2 = null;
        } else {
            String str3 = a.split(",")[0];
            try {
                j = Long.parseLong(a.split(",")[1]);
            } catch (Exception e) {
            }
            str2 = new Date().getTime() - j > 120000 ? null : str3;
        }
        String a2 = com.adfeiwo.ad.coverscreen.c.d.c.a(context, "DP_COVER_FILE", "appkey");
        if (com.adfeiwo.ad.coverscreen.c.c.a(a2)) {
            com.adfeiwo.ad.coverscreen.c.g.a.a("上传包安装信息失败：appkey为空");
            return;
        }
        JSONArray jSONArray = new JSONArray();
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("packageName", str);
        jSONObject.put("adid", str2);
        jSONArray.put(jSONObject);
        if (str2 != null) {
            com.adfeiwo.ad.coverscreen.c.d.c.b(context, "DP_COVER_FILE", str.replace(".", ""));
        }
        JSONObject a3 = com.adfeiwo.ad.coverscreen.c.a.a.a(context, "1.2", jSONArray);
        com.adfeiwo.ad.coverscreen.c.j.f fVar = new com.adfeiwo.ad.coverscreen.c.j.f();
        fVar.a(context, com.adfeiwo.ad.coverscreen.c.a.b.d(), a2, a3.toString());
        fVar.a(new w(sr, context, str));
        com.adfeiwo.ad.coverscreen.c.j.d.a().a(fVar);
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        com.adfeiwo.ad.coverscreen.c.g.a.a("接收到广播：" + intent.getAction());
        if (com.adfeiwo.ad.coverscreen.c.j.b.a(context) || intent.getAction().equalsIgnoreCase("android.intent.action.PACKAGE_ADDED")) {
            if (intent.getAction().equalsIgnoreCase("android.intent.action.PACKAGE_ADDED")) {
                new v(this, intent, context).start();
                return;
            }
            if (!intent.getAction().equalsIgnoreCase("android.intent.action.USER_PRESENT")) {
                if (intent.getAction().equalsIgnoreCase("broadcast.route.control")) {
                    switch (intent.getIntExtra("type", 0)) {
                        case 1:
                            String stringExtra = intent.getStringExtra("packageName");
                            if (stringExtra == null || stringExtra.length() <= 0) {
                                return;
                            }
                            com.adfeiwo.ad.coverscreen.c.d.c.b(context, "DP_COVER_FILE", stringExtra.replace(".", ""));
                            com.adfeiwo.ad.coverscreen.c.g.a.a("清理包名对应的广告ID：" + stringExtra);
                            return;
                        default:
                            return;
                    }
                }
                return;
            }
            String str = "show" + com.adfeiwo.ad.coverscreen.c.b.a.a(new Date(), "yyyyMMdd");
            int a = com.adfeiwo.ad.coverscreen.c.d.c.a(context, "DP_COVER_FILE", "dpnum", 0);
            int a2 = com.adfeiwo.ad.coverscreen.c.d.c.a(context, "DP_COVER_FILE", str, 0);
            boolean a3 = com.adfeiwo.ad.coverscreen.c.d.c.a(context, "DP_COVER_FILE", "showatscreenonplatform", true);
            boolean a4 = com.adfeiwo.ad.coverscreen.c.d.c.a(context, "DP_COVER_FILE", "showatscreenonuser", true);
            String a5 = com.adfeiwo.ad.coverscreen.c.d.c.a(context, "DP_COVER_FILE", "appkey", (String) null);
            if (com.adfeiwo.ad.coverscreen.c.c.a(a5)) {
                com.adfeiwo.ad.coverscreen.c.g.a.a("启动开屏广告失败：appkey为空");
                return;
            }
            if (!a4) {
                com.adfeiwo.ad.coverscreen.c.g.a.a("启动开屏广告失败：用户未启用");
                return;
            }
            if (CoverAdComponent.getInstance() == null) {
                CoverAdComponent.init(context, a5);
                CoverAdComponent.setShowAtScreenOn(true);
            }
            if (!a3) {
                com.adfeiwo.ad.coverscreen.c.g.a.a("启动开屏广告失败：平台未启用");
                return;
            }
            int a6 = com.adfeiwo.ad.coverscreen.c.d.c.a(context, "DP_COVER_FILE", "dprate", 10);
            if (a6 <= 0) {
                com.adfeiwo.ad.coverscreen.c.g.a.a("展示概率为：" + a6);
                return;
            }
            int a7 = com.adfeiwo.ad.coverscreen.c.b.a(100);
            com.adfeiwo.ad.coverscreen.c.g.a.a("随机概率值：" + a7 + ",展示概率为：" + a6);
            if (a7 <= a6) {
                com.adfeiwo.ad.coverscreen.c.g.a.a("最大开屏展示次数为：" + a + ", 当天已展示次数： " + a2);
                if (a != 0) {
                    if ((a <= 0 || a2 < a) && CoverAdComponent.showAd(context) == 0) {
                        com.adfeiwo.ad.coverscreen.c.d.c.b(context, "DP_COVER_FILE", str, a2 + 1);
                    }
                }
            }
        }
    }
}
