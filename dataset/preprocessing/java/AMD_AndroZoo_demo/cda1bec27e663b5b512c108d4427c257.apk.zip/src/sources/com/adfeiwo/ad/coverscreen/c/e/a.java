package com.adfeiwo.ad.coverscreen.c.e;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.io.File;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class a {
    private static a a = null;
    private ExecutorService b;
    private Map c = new HashMap();
    private int d = 0;
    private int e = 0;

    private a() {
        this.b = null;
        this.b = Executors.newFixedThreadPool(5);
    }

    public static a a() {
        if (a == null) {
            a = new a();
        }
        return a;
    }

    /* JADX WARN: Removed duplicated region for block: B:49:0x00af A[Catch: IOException -> 0x00b3, TRY_LEAVE, TryCatch #2 {IOException -> 0x00b3, blocks: (B:55:0x00aa, B:49:0x00af), top: B:54:0x00aa }] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00aa A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void a(java.lang.String r9, java.lang.String r10) {
        /*
            Method dump skipped, instructions count: 227
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.adfeiwo.ad.coverscreen.c.e.a.a(java.lang.String, java.lang.String):void");
    }

    public final Bitmap a(Context context, String str) {
        int i;
        Bitmap bitmap;
        int i2;
        if (!new File(str).exists()) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        int i3 = options.outWidth;
        int i4 = options.outHeight;
        int i5 = i3;
        int i6 = 1;
        while (true) {
            int i7 = i4;
            int i8 = i5 / 2;
            if (this.d > 0) {
                i = this.d;
            } else {
                DisplayMetrics displayMetrics = new DisplayMetrics();
                ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
                this.d = displayMetrics.widthPixels;
                i = displayMetrics.widthPixels;
            }
            if (i8 <= i) {
                break;
            }
            int i9 = i7 / 2;
            if (this.e > 0) {
                i2 = this.e;
            } else {
                DisplayMetrics displayMetrics2 = new DisplayMetrics();
                ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics2);
                this.e = displayMetrics2.heightPixels;
                i2 = this.e;
            }
            if (i9 <= i2) {
                break;
            }
            i5 /= 2;
            i4 = i7 / 2;
            i6 <<= 1;
        }
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inSampleSize = i6;
        options.inJustDecodeBounds = false;
        File file = new File(str);
        if (file.exists()) {
            bitmap = BitmapFactory.decodeFile(str, options);
            if (bitmap == null) {
                file.delete();
            }
        } else {
            bitmap = null;
        }
        return bitmap;
    }

    public final Drawable a(Context context, String str, String str2) {
        if (str == null || str.equals("")) {
            return null;
        }
        File file = new File(str2);
        if (!file.exists()) {
            return null;
        }
        try {
            file.setLastModified(System.currentTimeMillis());
            return new BitmapDrawable(a(context, str2));
        } catch (Exception e) {
            com.adfeiwo.ad.coverscreen.c.g.a.a(e);
            return null;
        } catch (OutOfMemoryError e2) {
            return null;
        }
    }

    public final Drawable a(Context context, String str, String str2, d dVar) {
        if (this.c.containsKey(str)) {
            SoftReference softReference = (SoftReference) this.c.get(str);
            if (softReference.get() != null) {
                if (0 != 0) {
                    softReference.get();
                }
                return (Drawable) softReference.get();
            }
        }
        this.b.submit(new c(this, context, str, str2, true, new b(this, null, str)));
        return null;
    }
}
