package com.adfeiwo.ad.coverscreen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class SA extends Activity {
    Vector b;
    private x d;
    private Timer h;
    private TimerTask i;
    Handler a = new Handler();
    int c = 0;
    private int e = 0;
    private int f = 0;
    private int g = 10000;
    private BroadcastReceiver j = new j(this);

    /* JADX INFO: Access modifiers changed from: private */
    public void a() {
        if (CoverAdComponent.getInstance() == null) {
            finish();
            return;
        }
        Vector b = b();
        if (b == null || b.isEmpty()) {
            com.adfeiwo.ad.coverscreen.c.g.a.a("no ad image ready, exit");
            finish();
            return;
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.e = displayMetrics.widthPixels;
        this.f = displayMetrics.heightPixels;
        this.g = com.adfeiwo.ad.coverscreen.c.d.c.a(this, "DP_COVER_FILE", "dpswitchdelay", 10000);
        this.b = b;
        if (this.c == 0) {
            this.c = com.adfeiwo.ad.coverscreen.c.b.a(this.b.size());
        }
        a(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(boolean z) {
        if (this.b.isEmpty()) {
            return;
        }
        if (this.c >= this.b.size()) {
            this.c = 0;
        }
        com.adfeiwo.ad.coverscreen.b.a aVar = (com.adfeiwo.ad.coverscreen.b.a) this.b.get(this.c);
        if (this.e > this.f) {
            this.d = new i(this, aVar, z);
        } else {
            this.d = new C(this, aVar, z);
        }
        setContentView(this.d, new ViewGroup.LayoutParams(-1, -1));
    }

    private Vector b() {
        com.adfeiwo.ad.coverscreen.b.a aVar;
        String stringExtra = getIntent().getStringExtra("ads");
        if (stringExtra == null) {
            return null;
        }
        Vector vector = new Vector();
        try {
            JSONArray jSONArray = new JSONArray(stringExtra);
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                if (jSONObject == null) {
                    aVar = null;
                } else {
                    aVar = new com.adfeiwo.ad.coverscreen.b.a();
                    aVar.b(jSONObject.optInt("id"));
                    aVar.a(jSONObject.optInt("adid", 0));
                    aVar.a(jSONObject.optString("image"));
                    aVar.b(jSONObject.optString("name"));
                    aVar.i(jSONObject.optString("icon"));
                    aVar.g(jSONObject.optString("clickType"));
                    aVar.j(jSONObject.optString("appicon"));
                    aVar.c(jSONObject.optString("appname"));
                    aVar.d(jSONObject.optString("apppackage"));
                    aVar.e(jSONObject.optString("appurl"));
                    aVar.k(jSONObject.optString("appsize"));
                    aVar.f(jSONObject.optString("wxurl"));
                    aVar.h(jSONObject.optString("weburl"));
                }
                if (aVar != null && aVar.a() > 0) {
                    com.adfeiwo.ad.coverscreen.c.d.a.a();
                    String a = com.adfeiwo.ad.coverscreen.c.d.a.a(getApplicationContext(), com.adfeiwo.ad.coverscreen.a.a.a, aVar.b());
                    com.adfeiwo.ad.coverscreen.c.e.e.a();
                    if (com.adfeiwo.ad.coverscreen.c.e.e.a(this, a) != null) {
                        com.adfeiwo.ad.coverscreen.c.g.a.a("添加到广告展示列表,CacheFromSdCard：" + aVar.c());
                        vector.add(aVar);
                    } else {
                        com.adfeiwo.ad.coverscreen.c.e.e.a().a(getApplicationContext(), aVar.b(), new s(this, aVar, vector));
                    }
                }
            }
            return vector;
        } catch (JSONException e) {
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c() {
        com.adfeiwo.ad.coverscreen.c.g.a.a("startRefreshTask");
        this.i = new t(this);
        this.h.schedule(this.i, this.g, this.g);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c(com.adfeiwo.ad.coverscreen.b.a aVar) {
        com.adfeiwo.ad.coverscreen.c.d.a.a();
        com.adfeiwo.ad.coverscreen.c.e.a.a().a(getApplicationContext(), aVar.k(), com.adfeiwo.ad.coverscreen.c.d.a.a(getApplicationContext(), com.adfeiwo.ad.coverscreen.a.a.a, aVar.k()), null);
        com.adfeiwo.ad.coverscreen.c.c.b bVar = new com.adfeiwo.ad.coverscreen.c.c.b();
        bVar.a(aVar.a());
        Context applicationContext = getApplicationContext();
        String f = aVar.f();
        com.adfeiwo.ad.coverscreen.c.d.a.a();
        bVar.a(applicationContext, f, com.adfeiwo.ad.coverscreen.c.d.a.a(getApplicationContext(), com.adfeiwo.ad.coverscreen.a.a.b, ""));
        bVar.a(new n(this, aVar));
        com.adfeiwo.ad.coverscreen.c.c.a.a(getApplicationContext()).a(bVar);
        Toast.makeText(getApplicationContext(), "正在下载  " + aVar.d() + " 可到通知栏查看", 0).show();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a(com.adfeiwo.ad.coverscreen.b.a aVar) {
        if (aVar == null) {
            return;
        }
        com.adfeiwo.ad.coverscreen.c.g.a.a("点击类型：" + aVar.h());
        if (!com.adfeiwo.ad.coverscreen.c.j.b.a(getApplicationContext())) {
            Log.w("LOG", "NO NETWORK");
            return;
        }
        if (!com.adfeiwo.ad.coverscreen.c.c.a(aVar.e())) {
            Intent intent = new Intent("broadcast.route.control");
            intent.putExtra("type", 1);
            intent.putExtra("packageName", aVar.e());
            sendBroadcast(intent);
        }
        JSONObject a = com.adfeiwo.ad.coverscreen.c.a.a.a(getApplicationContext(), 0.0d, 0.0d, CoverAdComponent.getInstance().e(), 0, new StringBuilder().append(aVar.m()).toString(), "");
        com.adfeiwo.ad.coverscreen.c.j.f fVar = new com.adfeiwo.ad.coverscreen.c.j.f();
        fVar.a(getApplicationContext(), com.adfeiwo.ad.coverscreen.c.a.b.a(), CoverAdComponent.getInstance().e(), a.toString());
        fVar.a(new q(this));
        com.adfeiwo.ad.coverscreen.c.j.d.a().a(fVar);
        this.b.remove(aVar);
        if ("download".equals(aVar.h())) {
            boolean a2 = com.adfeiwo.ad.coverscreen.c.d.c.a((Context) this, "DP_COVER_FILE", "download_confirm", false);
            int b = com.adfeiwo.ad.coverscreen.c.j.b.b(getApplicationContext());
            com.adfeiwo.ad.coverscreen.c.g.a.a("clickTypeDownLoadFile, NetWorkType: " + b + ", downloadConfirm: " + a2);
            if (b == 4 || !a2) {
                c(aVar);
                if (this.b.isEmpty()) {
                    finish();
                    return;
                } else {
                    a(false);
                    return;
                }
            }
            if (this.i != null) {
                this.i.cancel();
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false);
            builder.setTitle("提示");
            builder.setMessage("确定下载 " + aVar.d() + " ？");
            builder.setPositiveButton("确定", new l(this, aVar));
            builder.setNegativeButton("取消", new m(this));
            builder.show();
            return;
        }
        if (!"weixin".equals(aVar.h())) {
            if ("weburl".equals(aVar.h())) {
                Intent intent2 = new Intent(this, (Class<?>) WA.class);
                intent2.putExtra("url", aVar.i());
                startActivity(intent2);
                if (this.b.isEmpty()) {
                    finish();
                    return;
                } else {
                    a(false);
                    return;
                }
            }
            return;
        }
        com.adfeiwo.ad.coverscreen.c.g.a.a("打开微信关注：" + aVar.g());
        Intent intent3 = new Intent();
        intent3.setFlags(335544320);
        try {
            intent3.setClassName("com.tencent.mm", "com.tencent.mm.ui.qrcode.GetQRCodeInfoUI");
            intent3.setData(Uri.parse(aVar.g()));
            startActivity(intent3);
        } catch (ActivityNotFoundException e) {
            com.adfeiwo.ad.coverscreen.c.g.a.a("打开微信关注失败（weixin）：" + e);
            intent3.setAction("android.intent.action.VIEW");
            intent3.setData(Uri.parse(aVar.g()));
            startActivity(intent3);
        }
        if (this.b.isEmpty()) {
            finish();
        } else {
            a(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void b(com.adfeiwo.ad.coverscreen.b.a aVar) {
        if (aVar == null) {
            return;
        }
        JSONObject a = com.adfeiwo.ad.coverscreen.c.a.a.a(getApplicationContext(), aVar.m());
        com.adfeiwo.ad.coverscreen.c.j.f fVar = new com.adfeiwo.ad.coverscreen.c.j.f();
        fVar.a(getApplicationContext(), com.adfeiwo.ad.coverscreen.c.a.b.b(), CoverAdComponent.getInstance().e(), a.toString());
        fVar.a(new r(this));
        com.adfeiwo.ad.coverscreen.c.j.d.a().a(fVar);
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        CoverAdComponent.close(this);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        setContentView(frameLayout);
        if (bundle != null) {
            this.c = bundle.getInt("currentIndex", 0);
        }
        registerReceiver(this.j, new IntentFilter("com.screen.main.coverscreen.close"));
        this.h = new Timer();
        this.a.postDelayed(new k(this), 50L);
    }

    @Override // android.app.Activity
    protected final void onDestroy() {
        super.onDestroy();
        if (this.j != null) {
            unregisterReceiver(this.j);
        }
        this.h.cancel();
        com.adfeiwo.ad.coverscreen.c.g.a.a("TimerTask onDestroy");
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i, KeyEvent keyEvent) {
        com.adfeiwo.ad.coverscreen.c.g.a.a("Ad Activity onKeyDown: " + i);
        return true;
    }

    @Override // android.app.Activity
    protected final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        com.adfeiwo.ad.coverscreen.c.g.a.a("SA onNewIntent");
        this.c = 0;
        a();
    }

    @Override // android.app.Activity
    protected final void onPause() {
        super.onPause();
        this.i.cancel();
        com.adfeiwo.ad.coverscreen.c.g.a.a("TimerTask onPause");
    }

    @Override // android.app.Activity
    protected final void onResume() {
        super.onResume();
        c();
    }

    @Override // android.app.Activity
    protected final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("currentIndex", this.c);
    }

    @Override // android.app.Activity
    protected final void onStop() {
        super.onStop();
        this.i.cancel();
        com.adfeiwo.ad.coverscreen.c.g.a.a("TimerTask onStop");
    }
}
