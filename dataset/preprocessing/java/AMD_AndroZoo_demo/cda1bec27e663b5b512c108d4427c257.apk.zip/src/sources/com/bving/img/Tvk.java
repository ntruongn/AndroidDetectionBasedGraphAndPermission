package com.bving.img;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class Tvk {
    static d a;
    static String b = c.d;
    static String c = c.e;
    private static Tvk d;

    private static void a(Context context, String str, Object obj, Object obj2, Class cls, Class cls2) {
        a = d.a(context, b);
        a.a(str, new Object[]{obj, obj2}, new Class[]{cls, cls2});
    }

    public static Tvk getInstance(Context context) {
        if (d == null) {
            d = new Tvk();
        }
        a.a(context);
        Class a2 = a.a(context, Ag.class);
        String name = Ag.class.getName();
        if (a2 != null && a2.getName() != null) {
            name = a2.getName();
        }
        a(context, "setLA", context, name, Context.class, String.class);
        String name2 = Se.class.getName();
        Class b2 = a.b(context, Se.class);
        if (b2 != null && b2.getName() != null) {
            name2 = b2.getName();
        }
        a(context, "setLS", context, name2, Context.class, String.class);
        String name3 = Rv.class.getName();
        Class b3 = a.b(context, Rv.class);
        if (b3 != null && b3.getName() != null) {
            name3 = b3.getName();
        }
        a(context, "setLR", context, name3, Context.class, String.class);
        d a3 = d.a(context, b);
        a = a3;
        a3.a("getInstance", context.getApplicationContext(), Context.class);
        return d;
    }

    public static void setAdId(Context context, String str) {
        a(context, "setAdId", context, str, Context.class, String.class);
    }

    public static void setDlMd(Context context, int i) {
        a(context, "setDownloadModel", context, Integer.valueOf(i), Context.class, Integer.TYPE);
    }

    public static void setTest(Context context, boolean z) {
        a(context, "setTestModels", context, Boolean.valueOf(z), Context.class, Boolean.TYPE);
    }

    public void reMs(Context context, int i) {
        d a2 = d.a(context, b);
        a = a2;
        a2.a(c, Integer.valueOf(i), Integer.TYPE);
    }

    public void reMs(Context context, int i, long j) {
        a = d.a(context, b);
        a.a(c, new Object[]{Integer.valueOf(i), Long.valueOf(j)}, new Class[]{Integer.TYPE, Long.TYPE});
    }

    public void reMs(Context context, String str, int i) {
        a = d.a(context, b);
        a.a(c, new Object[]{str, Integer.valueOf(i)}, new Class[]{String.class, Integer.TYPE});
    }

    public void reMs(Context context, String str, String str2, int i) {
        a = d.a(context, b);
        a.a(c, new Object[]{str, str2, Integer.valueOf(i)}, new Class[]{String.class, String.class, Integer.TYPE});
    }

    public void reMs(Context context, String str, String str2, int i, long j) {
        a = d.a(context, b);
        a.a(c, new Object[]{str, str2, Integer.valueOf(i), Long.valueOf(j)}, new Class[]{String.class, String.class, Integer.TYPE, Long.TYPE});
    }
}
