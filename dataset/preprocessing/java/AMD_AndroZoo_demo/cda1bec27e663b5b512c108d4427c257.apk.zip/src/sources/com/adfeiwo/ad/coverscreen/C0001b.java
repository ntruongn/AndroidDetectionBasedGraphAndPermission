package com.adfeiwo.ad.coverscreen;

import android.content.Context;

/* JADX INFO: Access modifiers changed from: package-private */
/* renamed from: com.adfeiwo.ad.coverscreen.b, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class C0001b implements com.adfeiwo.ad.coverscreen.c.j.e {
    private /* synthetic */ AdComponent a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public C0001b(AdComponent adComponent) {
        this.a = adComponent;
    }

    @Override // com.adfeiwo.ad.coverscreen.c.j.e
    public final void a(boolean z, String str) {
        Context context;
        com.adfeiwo.ad.coverscreen.c.g.a.a("服务器返回（uploadClientInfo）：" + str);
        context = this.a.e;
        com.adfeiwo.ad.coverscreen.c.d.c.b(context, "coverscreen", "isFirstRun", false);
        this.a.a();
    }
}
