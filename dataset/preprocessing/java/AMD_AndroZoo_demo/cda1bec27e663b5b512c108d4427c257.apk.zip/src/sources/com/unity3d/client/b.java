package com.unity3d.client;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class b extends Handler {
    private Context a;

    public b(Looper looper, Context context) {
        super(looper);
        this.a = context;
    }

    private void a(a aVar) {
        if (!c.a(aVar.i())) {
            c.d.add(aVar);
        }
        String b = aVar.b();
        if (c.a(this.a, aVar.i())) {
            c.c(aVar.i());
        } else if (b.equals("4") || b.equals("0")) {
            c.a(this.a, aVar);
        }
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        if (message != null) {
            switch (message.what) {
                case 67:
                default:
                    return;
                case 71:
                    a((a) message.obj);
                    return;
            }
        }
    }
}
