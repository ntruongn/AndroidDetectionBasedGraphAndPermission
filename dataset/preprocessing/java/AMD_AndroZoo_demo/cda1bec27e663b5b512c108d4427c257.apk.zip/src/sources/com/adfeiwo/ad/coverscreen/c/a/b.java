package com.adfeiwo.ad.coverscreen.c.a;

import com.adfeiwo.ad.coverscreen.c.j.c;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class b {
    private static final String a = c.a("H8Zno4EBTQxpkSXNq43Tf0h/1+g6gUD21yju2WDt51Y=", c.a("123456"));

    public static String a() {
        return String.valueOf(a) + "/webviewAdClick";
    }

    public static String b() {
        return String.valueOf(a) + "/showCount";
    }

    public static String c() {
        return String.valueOf(a) + "/clientinfo";
    }

    public static String d() {
        return String.valueOf(a) + "/installCount";
    }

    public static String e() {
        return String.valueOf(a) + "/getCoverScreenAdList";
    }
}
