package com.adfeiwo.ad.coverscreen;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class h implements Runnable {
    private /* synthetic */ CoverAdComponent a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h(CoverAdComponent coverAdComponent, String str) {
        this.a = coverAdComponent;
        this.b = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.adfeiwo.ad.coverscreen.c.e.e.a().a(this.a.f(), this.b, (com.adfeiwo.ad.coverscreen.c.e.h) null);
    }
}
