package com.adfeiwo.ad.coverscreen.c.e;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import java.io.File;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class e {
    private static e a = null;
    private Handler b = new f(this);
    private ConcurrentHashMap c = new ConcurrentHashMap();
    private ExecutorService d = Executors.newSingleThreadExecutor();
    private ConcurrentHashMap e = new ConcurrentHashMap();

    public static Bitmap a(Context context, String str) {
        Bitmap bitmap;
        if (!new File(str).exists()) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        int i = options.outWidth;
        int i2 = options.outHeight;
        com.adfeiwo.ad.coverscreen.c.i.a.a d = com.adfeiwo.ad.coverscreen.c.i.b.d(context);
        int i3 = 1;
        while (i / 2 > d.a() && i2 / 2 > d.b()) {
            i /= 2;
            i2 /= 2;
            i3 <<= 1;
        }
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inSampleSize = i3;
        options.inJustDecodeBounds = false;
        File file = new File(str);
        if (file.exists()) {
            bitmap = BitmapFactory.decodeFile(str, options);
            if (bitmap == null) {
                file.delete();
            }
        } else {
            bitmap = null;
        }
        return bitmap;
    }

    public static e a() {
        if (a == null) {
            a = new e();
        }
        return a;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00a3 A[Catch: IOException -> 0x00a7, TRY_LEAVE, TryCatch #1 {IOException -> 0x00a7, blocks: (B:55:0x009e, B:49:0x00a3), top: B:54:0x009e }] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x009e A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static /* synthetic */ void a(com.adfeiwo.ad.coverscreen.c.e.e r9, android.content.Context r10, java.lang.String r11) {
        /*
            r3 = 0
            com.adfeiwo.ad.coverscreen.c.d.a.a()
            java.lang.String r0 = com.adfeiwo.ad.coverscreen.a.a.a
            java.lang.String r0 = com.adfeiwo.ad.coverscreen.c.d.a.a(r10, r0, r11)
            java.io.File r1 = new java.io.File
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r4 = java.lang.String.valueOf(r0)
            r2.<init>(r4)
            java.lang.String r4 = "."
            java.lang.StringBuilder r2 = r2.append(r4)
            long r4 = java.lang.System.currentTimeMillis()
            java.lang.StringBuilder r2 = r2.append(r4)
            java.lang.String r4 = ".temp"
            java.lang.StringBuilder r2 = r2.append(r4)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            java.io.File r4 = new java.io.File
            r4.<init>(r0)
            boolean r0 = r4.exists()
            if (r0 != 0) goto L7d
            java.net.URL r0 = new java.net.URL     // Catch: java.lang.Throwable -> L9a java.lang.Exception -> Lc1
            r0.<init>(r11)     // Catch: java.lang.Throwable -> L9a java.lang.Exception -> Lc1
            java.net.URLConnection r0 = r0.openConnection()     // Catch: java.lang.Throwable -> L9a java.lang.Exception -> Lc1
            java.net.HttpURLConnection r0 = (java.net.HttpURLConnection) r0     // Catch: java.lang.Throwable -> L9a java.lang.Exception -> Lc1
            r2 = 5000(0x1388, float:7.006E-42)
            r0.setConnectTimeout(r2)     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lc4
            r2 = 5000(0x1388, float:7.006E-42)
            r0.setReadTimeout(r2)     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lc4
            java.lang.String r2 = "GET"
            r0.setRequestMethod(r2)     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lc4
            r0.connect()     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lc4
            java.io.InputStream r5 = r0.getInputStream()     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lc4
            java.io.FileOutputStream r2 = new java.io.FileOutputStream     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lc4
            r2.<init>(r1)     // Catch: java.lang.Throwable -> Lb1 java.lang.Exception -> Lc4
            r3 = 1024(0x400, float:1.435E-42)
            byte[] r3 = new byte[r3]     // Catch: java.lang.Exception -> L83 java.lang.Throwable -> Lb6
        L65:
            int r6 = r5.read(r3)     // Catch: java.lang.Exception -> L83 java.lang.Throwable -> Lb6
            r7 = -1
            if (r6 != r7) goto L7e
            r2.flush()     // Catch: java.lang.Exception -> L83 java.lang.Throwable -> Lb6
            r2.close()     // Catch: java.lang.Exception -> L83 java.lang.Throwable -> Lb6
            r1.renameTo(r4)     // Catch: java.lang.Exception -> L83 java.lang.Throwable -> Lb6
            r2.close()     // Catch: java.io.IOException -> Lac
            if (r0 == 0) goto L7d
            r0.disconnect()     // Catch: java.io.IOException -> Lac
        L7d:
            return
        L7e:
            r7 = 0
            r2.write(r3, r7, r6)     // Catch: java.lang.Exception -> L83 java.lang.Throwable -> Lb6
            goto L65
        L83:
            r1 = move-exception
            r3 = r0
            r0 = r1
            r1 = r2
        L87:
            com.adfeiwo.ad.coverscreen.c.g.a.a(r0)     // Catch: java.lang.Throwable -> Lbc
            if (r1 == 0) goto L8f
            r1.close()     // Catch: java.io.IOException -> L95
        L8f:
            if (r3 == 0) goto L7d
            r3.disconnect()     // Catch: java.io.IOException -> L95
            goto L7d
        L95:
            r0 = move-exception
            com.adfeiwo.ad.coverscreen.c.g.a.a(r0)
            goto L7d
        L9a:
            r0 = move-exception
            r1 = r3
        L9c:
            if (r3 == 0) goto La1
            r3.close()     // Catch: java.io.IOException -> La7
        La1:
            if (r1 == 0) goto La6
            r1.disconnect()     // Catch: java.io.IOException -> La7
        La6:
            throw r0
        La7:
            r1 = move-exception
            com.adfeiwo.ad.coverscreen.c.g.a.a(r1)
            goto La6
        Lac:
            r0 = move-exception
            com.adfeiwo.ad.coverscreen.c.g.a.a(r0)
            goto L7d
        Lb1:
            r1 = move-exception
            r8 = r1
            r1 = r0
            r0 = r8
            goto L9c
        Lb6:
            r1 = move-exception
            r3 = r2
            r8 = r1
            r1 = r0
            r0 = r8
            goto L9c
        Lbc:
            r0 = move-exception
            r8 = r1
            r1 = r3
            r3 = r8
            goto L9c
        Lc1:
            r0 = move-exception
            r1 = r3
            goto L87
        Lc4:
            r1 = move-exception
            r8 = r1
            r1 = r3
            r3 = r0
            r0 = r8
            goto L87
        */
        throw new UnsupportedOperationException("Method not decompiled: com.adfeiwo.ad.coverscreen.c.e.e.a(com.adfeiwo.ad.coverscreen.c.e.e, android.content.Context, java.lang.String):void");
    }

    public final Drawable a(Context context, String str, h hVar) {
        boolean z;
        if (this.c.containsKey(str)) {
            Queue queue = (Queue) this.c.get(str);
            if (hVar != null) {
                queue.add(hVar);
            }
            z = true;
        } else {
            ConcurrentLinkedQueue concurrentLinkedQueue = new ConcurrentLinkedQueue();
            this.c.put(str, concurrentLinkedQueue);
            if (hVar != null) {
                concurrentLinkedQueue.add(hVar);
            }
            z = false;
        }
        if (!z) {
            this.d.submit(new g(this, context, str));
        }
        return null;
    }
}
