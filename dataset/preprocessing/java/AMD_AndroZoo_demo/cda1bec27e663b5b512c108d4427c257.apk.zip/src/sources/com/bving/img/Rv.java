package com.bving.img;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class Rv extends BroadcastReceiver {
    static String b = c.b;
    d a;

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        try {
            this.a = d.a(context, b);
            this.a.a(c.k, new Object[]{context, intent}, new Class[]{Context.class, Intent.class});
        } catch (Exception e) {
        }
    }
}
