package com.unity3d.client;

import android.app.Notification;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
class f implements Runnable {
    final /* synthetic */ Us a;
    private final /* synthetic */ Notification b;
    private final /* synthetic */ String c;
    private final /* synthetic */ String d;
    private final /* synthetic */ String e;
    private final /* synthetic */ int f;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(Us us, Notification notification, String str, String str2, String str3, int i) {
        this.a = us;
        this.b = notification;
        this.c = str;
        this.d = str2;
        this.e = str3;
        this.f = i;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.a.a(this.b, this.c, this.d, this.e, this.f);
    }
}
