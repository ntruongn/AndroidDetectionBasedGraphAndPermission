package com.adfeiwo.ad.coverscreen.c.e;

import android.graphics.drawable.Drawable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public interface h {
    void a(Drawable drawable);
}
