package com.adfeiwo.ad.coverscreen;

import android.content.Context;
import android.content.Intent;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class CoverAdComponent extends AdComponent {
    private static CoverAdComponent f;
    volatile JSONArray d;
    volatile Date e;

    private CoverAdComponent(Context context, String str) {
        super(context, str);
        this.d = null;
        this.e = null;
    }

    public static void close(Context context) {
        context.sendBroadcast(new Intent("com.screen.main.coverscreen.close"));
    }

    public static void destory(Context context) {
        if (f == null || context == null) {
            return;
        }
        close(context);
        f.b();
    }

    public static CoverAdComponent getInstance() {
        return f;
    }

    public static CoverAdComponent init(Context context, String str) {
        if (f != null) {
            return f;
        }
        if (context == null) {
            throw new IllegalArgumentException("context is null");
        }
        if (str == null || str.trim().length() < 8) {
            throw new IllegalArgumentException("appkey is error");
        }
        CoverAdComponent coverAdComponent = new CoverAdComponent(context, str);
        f = coverAdComponent;
        return coverAdComponent;
    }

    public static void setShowAtScreenOn(boolean z) {
        if (f != null) {
            a = z;
            com.adfeiwo.ad.coverscreen.c.d.c.b(f.f(), "DP_COVER_FILE", "showatscreenonuser", z);
        }
    }

    public static int showAd(Context context) {
        boolean z = true;
        if (f == null) {
            return 1;
        }
        try {
            CoverAdComponent coverAdComponent = f;
            if (context == null || !com.adfeiwo.ad.coverscreen.c.j.b.a(context)) {
                com.adfeiwo.ad.coverscreen.c.g.a.a("无网络");
                return 2;
            }
            if (coverAdComponent.e != null && coverAdComponent.e.getTime() - new Date().getTime() > 43200000) {
                coverAdComponent.d = null;
            }
            if (coverAdComponent.d == null || coverAdComponent.d.length() == 0) {
                com.adfeiwo.ad.coverscreen.c.g.a.a("无广告");
                coverAdComponent.a(true);
                return 2;
            }
            JSONArray jSONArray = coverAdComponent.d;
            int i = 0;
            while (true) {
                if (i >= jSONArray.length()) {
                    z = false;
                    break;
                }
                String optString = jSONArray.optJSONObject(i).optString("image");
                com.adfeiwo.ad.coverscreen.c.d.a.a();
                String a = com.adfeiwo.ad.coverscreen.c.d.a.a(coverAdComponent.f(), com.adfeiwo.ad.coverscreen.a.a.a, optString);
                com.adfeiwo.ad.coverscreen.c.e.e.a();
                if (com.adfeiwo.ad.coverscreen.c.e.e.a(context, a) != null) {
                    com.adfeiwo.ad.coverscreen.c.g.a.a("check image cache: " + a + ", exist");
                    break;
                }
                com.adfeiwo.ad.coverscreen.c.g.a.a("check image cache: " + a + ", not exist");
                if (coverAdComponent.c != null) {
                    coverAdComponent.c.postDelayed(new h(coverAdComponent, optString), 10L);
                }
                i++;
            }
            if (!z) {
                com.adfeiwo.ad.coverscreen.c.g.a.a("广告准备中");
                return 3;
            }
            if (!coverAdComponent.a(jSONArray.toString())) {
                return 4;
            }
            coverAdComponent.a(true);
            return 0;
        } catch (Exception e) {
            return 5;
        }
    }

    @Override // com.adfeiwo.ad.coverscreen.AdComponent
    protected final void b() {
        super.b();
        f = null;
        this.d = null;
        com.adfeiwo.ad.coverscreen.c.g.a.a("广告占用资源释放完成");
    }

    @Override // com.adfeiwo.ad.coverscreen.AdComponent
    protected final void c() {
        if (this.b) {
            f();
            com.adfeiwo.ad.coverscreen.c.g.a.b("广告正在获取中，此次调用忽略");
            return;
        }
        this.b = true;
        JSONObject a = com.adfeiwo.ad.coverscreen.c.a.a.a(f(), "1.2");
        com.adfeiwo.ad.coverscreen.c.j.f fVar = new com.adfeiwo.ad.coverscreen.c.j.f();
        fVar.a(f(), com.adfeiwo.ad.coverscreen.c.a.b.e(), e(), a.toString());
        fVar.a(new g(this));
        f();
        com.adfeiwo.ad.coverscreen.c.g.a.b("开始发送获取广告的网络请求");
        com.adfeiwo.ad.coverscreen.c.j.d.a().a(fVar);
    }
}
