package com.adfeiwo.ad.coverscreen.c.f;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class a {
    private static a c;
    private double a = 0.0d;
    private double b = 0.0d;

    public a() {
        new b(this);
    }

    public static a c() {
        if (c == null) {
            c = new a();
        }
        return c;
    }

    public final double a() {
        return this.a;
    }

    public final double b() {
        return this.b;
    }
}
