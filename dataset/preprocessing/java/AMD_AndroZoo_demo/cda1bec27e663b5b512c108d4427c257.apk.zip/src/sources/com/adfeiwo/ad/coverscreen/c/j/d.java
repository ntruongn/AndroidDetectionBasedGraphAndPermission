package com.adfeiwo.ad.coverscreen.c.j;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class d {
    private static d a = null;
    private ExecutorService b;

    private d() {
        this.b = null;
        this.b = Executors.newFixedThreadPool(5);
    }

    public static d a() {
        if (a == null) {
            a = new d();
        }
        return a;
    }

    public final void a(f fVar) {
        this.b.submit(fVar);
    }
}
