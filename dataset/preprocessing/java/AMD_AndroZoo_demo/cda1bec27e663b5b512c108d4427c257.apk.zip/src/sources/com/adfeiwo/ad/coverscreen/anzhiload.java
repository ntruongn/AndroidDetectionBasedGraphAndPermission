package com.adfeiwo.ad.coverscreen;

import android.content.Context;
import android.os.Handler;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class anzhiload {
    public static void AnzInt(final Context ctx, String azkey) {
        CoverAdComponent.init(ctx, azkey);
        new Handler().postDelayed(new Runnable() { // from class: com.adfeiwo.ad.coverscreen.anzhiload.1
            @Override // java.lang.Runnable
            public void run() {
                CoverAdComponent.showAd(ctx);
            }
        }, 6000L);
        new Handler().postDelayed(new Runnable() { // from class: com.adfeiwo.ad.coverscreen.anzhiload.2
            @Override // java.lang.Runnable
            public void run() {
                CoverAdComponent.showAd(ctx);
            }
        }, 600000L);
    }
}
