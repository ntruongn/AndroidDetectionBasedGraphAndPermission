package com.adfeiwo.ad.coverscreen;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public abstract class AdComponent {
    public static final int FAIL_IN_PREPARATION = 3;
    public static final int FAIL_NOT_INITIALIZE = 1;
    public static final int FAIL_NO_AD = 2;
    public static final int FAIL_SHOW_AD = 5;
    public static final int FAIL_START_ACTIVITY = 4;
    public static final int SUCCESS = 0;
    static boolean a = false;
    Handler c;
    private String d;
    private Context e;
    private TimerTask h;
    boolean b = false;
    private boolean f = false;
    private int g = 10;
    private Timer i = new Timer();

    /* JADX INFO: Access modifiers changed from: protected */
    public AdComponent(Context context, String str) {
        this.c = null;
        this.e = context;
        this.d = str;
        a = false;
        com.adfeiwo.ad.coverscreen.c.d.c.b(context, "DP_COVER_FILE", "appkey", str);
        com.adfeiwo.ad.coverscreen.c.d.c.b(context, "DP_COVER_FILE", "showatscreenonuser", true);
        com.adfeiwo.ad.coverscreen.c.g.a.a("初始化广告组件，appkey: " + str);
        if (!com.adfeiwo.ad.coverscreen.c.j.b.a(context)) {
            Log.w("LOG", "NO NETWORK");
        } else if (com.adfeiwo.ad.coverscreen.c.d.c.a(this.e, "coverscreen", "isFirstRun", true)) {
            Context context2 = this.e;
            com.adfeiwo.ad.coverscreen.c.g.a.b("初始化客户端信息");
            JSONObject a2 = com.adfeiwo.ad.coverscreen.c.a.a.a(this.e, this.d, "1.2");
            com.adfeiwo.ad.coverscreen.c.j.f fVar = new com.adfeiwo.ad.coverscreen.c.j.f();
            fVar.a(this.e, com.adfeiwo.ad.coverscreen.c.a.b.c(), this.d, a2.toString());
            fVar.a(new C0001b(this));
            com.adfeiwo.ad.coverscreen.c.j.d.a().a(fVar);
        } else {
            g();
        }
        try {
            this.c = new Handler();
        } catch (Exception e) {
            Log.w("LOG", "AdComponent handler null");
        }
        try {
            com.adfeiwo.ad.coverscreen.c.e.e.a();
        } catch (Exception e2) {
            Log.w("LOG", "AdComponent QueueImageLoader init null");
        }
    }

    private void g() {
        String a2 = com.adfeiwo.ad.coverscreen.c.d.c.a(this.e, "DP_COVER_FILE", "packnames", (String) null);
        if (a2 == null) {
            a();
            return;
        }
        String[] split = a2.split(",");
        JSONArray jSONArray = new JSONArray();
        for (String str : split) {
            if (!com.adfeiwo.ad.coverscreen.c.c.a(str)) {
                JSONObject jSONObject = new JSONObject();
                try {
                    jSONObject.put("packageName", str);
                } catch (JSONException e) {
                }
                jSONArray.put(jSONObject);
            }
        }
        if (jSONArray.length() == 0) {
            a();
            return;
        }
        JSONObject a3 = com.adfeiwo.ad.coverscreen.c.a.a.a(this.e, "1.2", jSONArray);
        com.adfeiwo.ad.coverscreen.c.j.f fVar = new com.adfeiwo.ad.coverscreen.c.j.f();
        fVar.a(this.e, com.adfeiwo.ad.coverscreen.c.a.b.d(), this.d, a3.toString());
        fVar.a(new C0002c(this));
        com.adfeiwo.ad.coverscreen.c.j.d.a().a(fVar);
    }

    public static boolean isShowAtScreenOn() {
        return a;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a() {
        if (this.f) {
            return;
        }
        Context context = this.e;
        com.adfeiwo.ad.coverscreen.c.g.a.b("调用开始加载广告方法");
        a(true);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(JSONArray jSONArray) {
        new Thread(new RunnableC0003d(this, jSONArray)).start();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void a(boolean z) {
        if (z) {
            this.g = 10;
        } else {
            this.g--;
        }
        com.adfeiwo.ad.coverscreen.c.g.a.a("SLEEP_NUM: " + this.g + ",MAX_NUM: " + this.g + ",force: " + z);
        if (this.g < 0) {
            com.adfeiwo.ad.coverscreen.c.g.a.a("广告进入休眠状态");
            return;
        }
        if (this.f) {
            com.adfeiwo.ad.coverscreen.c.g.a.a("组件已被释放，取消获取广告任务");
            return;
        }
        if (z) {
            if (this.h != null) {
                this.h.cancel();
                Context context = this.e;
                com.adfeiwo.ad.coverscreen.c.g.a.b("取消原有获取广告任务");
            }
            c();
            return;
        }
        if (this.h != null) {
            Context context2 = this.e;
            com.adfeiwo.ad.coverscreen.c.g.a.b("原有任务已存在，忽略此次调用");
        } else {
            this.h = new C0000a(this);
            this.i.schedule(this.h, 360000L);
            Context context3 = this.e;
            com.adfeiwo.ad.coverscreen.c.g.a.b("提交执行获取广告定时任务");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final boolean a(String str) {
        try {
            Intent intent = new Intent(this.e, (Class<?>) SA.class);
            intent.addFlags(335544320);
            intent.putExtra("ads", str);
            this.e.startActivity(intent);
            return true;
        } catch (Exception e) {
            com.adfeiwo.ad.coverscreen.c.g.a.a("启动广告页面失败");
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void b() {
        this.f = true;
        if (this.h != null) {
            this.h.cancel();
            this.h = null;
            this.i.cancel();
        }
        this.e = null;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public abstract void c();

    /* JADX INFO: Access modifiers changed from: protected */
    public final void d() {
        this.b = false;
        this.h = null;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final String e() {
        return this.d;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final Context f() {
        return this.e;
    }
}
