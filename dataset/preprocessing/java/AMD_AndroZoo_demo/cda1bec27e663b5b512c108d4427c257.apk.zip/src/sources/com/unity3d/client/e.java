package com.unity3d.client;

import android.content.Context;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class e extends Thread {
    private final /* synthetic */ Context a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(Context context, String str) {
        this.a = context;
        this.b = str;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        String b;
        b = c.b(this.a, "G02", "Pack:" + this.b + "#Appkey:" + InfoManage.a());
        InfoManage.b.sendMessage(InfoManage.b.obtainMessage(67, b));
    }
}
