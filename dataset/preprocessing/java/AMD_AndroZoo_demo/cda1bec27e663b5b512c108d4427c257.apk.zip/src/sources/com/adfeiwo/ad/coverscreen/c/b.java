package com.adfeiwo.ad.coverscreen.c;

import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class b {
    private static AtomicLong a = new AtomicLong(System.currentTimeMillis());

    public static int a(int i) {
        return new Random(a.incrementAndGet()).nextInt(i);
    }
}
