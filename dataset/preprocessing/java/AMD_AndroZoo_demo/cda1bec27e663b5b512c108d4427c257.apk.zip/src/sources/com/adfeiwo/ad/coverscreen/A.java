package com.adfeiwo.ad.coverscreen;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
final class A implements com.adfeiwo.ad.coverscreen.c.e.h {
    private final /* synthetic */ ImageView a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public A(x xVar, ImageView imageView, String str) {
        this.a = imageView;
        this.b = str;
    }

    @Override // com.adfeiwo.ad.coverscreen.c.e.h
    public final void a(Drawable drawable) {
        if (drawable == null || this.a.getTag() == null || !this.a.getTag().equals(this.b)) {
            return;
        }
        this.a.setImageDrawable(drawable);
    }
}
