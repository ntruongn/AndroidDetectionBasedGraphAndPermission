package com.adfeiwo.ad.coverscreen;

import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class C extends x {
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;
    private int i;
    private int j;
    private int k;
    private int l;
    private int m;
    private int n;
    private int o;
    private int p;
    private ImageView q;
    private RelativeLayout r;

    public C(SA sa, com.adfeiwo.ad.coverscreen.b.a aVar, boolean z) {
        super(sa, aVar, z);
        this.d = 5;
        this.e = 32;
        this.f = this.e / 2;
        this.g = 275;
        this.h = 180;
        this.i = 5;
        this.j = 50;
        this.k = 50;
        this.l = 14;
        this.m = 96;
        this.n = 36;
        this.o = this.g + this.e + (this.d << 1);
        this.p = this.h + this.e + (this.d << 1) + this.i + this.k;
        e();
    }

    @Override // com.adfeiwo.ad.coverscreen.x
    protected final void a() {
        this.d = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.d);
        this.e = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.e);
        this.o = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.o);
        this.p = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.p);
        this.f = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.f);
        this.g = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.g);
        this.h = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.h);
        this.i = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.i);
        this.j = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.j);
        this.k = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.k);
        this.n = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.n);
        this.m = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), this.m);
        Rect rect = new Rect();
        this.c.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        com.adfeiwo.ad.coverscreen.c.g.a.a("initParam: [imageWidth: " + this.g + ",imageHeight: " + this.h + ",outContainerWidth: " + this.o + ",outContainerHeight: " + this.p + "]" + rect);
        int width = rect.width() - this.o;
        com.adfeiwo.ad.coverscreen.c.g.a.a("extraWidth: " + width + ",frame.width: " + rect.width() + ",outContainerHeight: " + this.o);
        if (width < 0 || Math.abs(width) > 10) {
            double height = ((double) (rect.height() - 10)) / this.p;
            double width2 = ((double) (rect.width() - 10)) / this.o;
            if (height <= width2) {
                width2 = height;
            }
            double d = width2 <= 2.0d ? width2 : 2.0d;
            this.d = (int) (this.d * d);
            this.e = (int) (this.e * d);
            this.o = (int) (this.o * d);
            this.p = (int) (this.p * d);
            this.f = (int) (this.f * d);
            this.g = (int) (this.g * d);
            this.h = (int) (this.h * d);
            this.i = (int) (this.i * d);
            this.j = (int) (this.j * d);
            this.k = (int) (this.k * d);
            this.n = (int) (this.n * d);
            this.m = (int) (this.m * d);
            this.l = (int) (this.l * d);
            com.adfeiwo.ad.coverscreen.c.g.a.a("initParam: [rate: " + d + ",imageWidth: " + this.g + ",imageHeight: " + this.h + ",outContainerWidth: " + this.o + ",outContainerHeight: " + this.p + "]");
        }
    }

    @Override // com.adfeiwo.ad.coverscreen.x
    protected final void b() {
        float f = this.d;
        ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(new float[]{f, f, f, f, f, f, f, f}, null, null));
        shapeDrawable.setPadding(this.d, this.d, this.d, this.d);
        shapeDrawable.getPaint().setColor(-1);
        this.r = new RelativeLayout(getContext());
        this.r.setLayoutParams(new LinearLayout.LayoutParams(this.o, this.p));
        addView(this.r);
        LinearLayout linearLayout = new LinearLayout(getContext());
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.setMargins(this.f, this.f, this.f, this.f);
        layoutParams.addRule(13, -1);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundDrawable(shapeDrawable);
        linearLayout.setOrientation(1);
        this.r.addView(linearLayout);
        this.q = new ImageView(getContext());
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(10, -1);
        layoutParams2.addRule(11, -1);
        int i = this.e;
        layoutParams2.width = i;
        layoutParams2.height = i;
        this.q.setLayoutParams(layoutParams2);
        this.q.setScaleType(ImageView.ScaleType.FIT_XY);
        ImageView imageView = this.q;
        getContext();
        imageView.setImageDrawable(com.adfeiwo.ad.coverscreen.c.d.b.a(com.adfeiwo.ad.coverscreen.a.a.c));
        this.r.addView(this.q);
        ImageView imageView2 = new ImageView(getContext());
        imageView2.setLayoutParams(new LinearLayout.LayoutParams(this.g, this.h));
        imageView2.setScaleType(ImageView.ScaleType.FIT_XY);
        a(imageView2, this.b.b());
        linearLayout.addView(imageView2);
        LinearLayout linearLayout2 = new LinearLayout(getContext());
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = this.i;
        linearLayout2.setLayoutParams(layoutParams3);
        linearLayout2.setOrientation(0);
        linearLayout.addView(linearLayout2);
        ImageView imageView3 = new ImageView(getContext());
        imageView3.setLayoutParams(new LinearLayout.LayoutParams(this.j, this.k));
        imageView3.setScaleType(ImageView.ScaleType.FIT_XY);
        a(imageView3, this.b.j());
        linearLayout2.addView(imageView3);
        LinearLayout linearLayout3 = new LinearLayout(getContext());
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(0, -1);
        layoutParams4.leftMargin = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), 4.0f);
        layoutParams4.weight = 1.0f;
        linearLayout3.setLayoutParams(layoutParams4);
        linearLayout3.setGravity(16);
        linearLayout3.setOrientation(1);
        linearLayout2.addView(linearLayout3);
        TextView textView = new TextView(getContext());
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-2, -2);
        if ("download".equals(this.b.h())) {
            textView.setText(this.b.d());
        } else {
            textView.setText(this.b.c());
        }
        textView.setTextColor(-16777216);
        textView.setTextSize(this.l);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setLayoutParams(layoutParams5);
        linearLayout3.addView(textView);
        if ("download".equals(this.b.h())) {
            TextView textView2 = new TextView(getContext());
            LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, -2);
            layoutParams6.topMargin = com.adfeiwo.ad.coverscreen.c.d.b.a(getContext(), 2.0f);
            textView2.setText(this.b.l());
            textView2.setTextColor(-16777216);
            textView2.setTextSize((float) (this.l - 2));
            textView2.setLayoutParams(layoutParams6);
            linearLayout3.addView(textView2);
        }
        ImageView imageView4 = new ImageView(getContext());
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(this.m, this.n);
        layoutParams7.gravity = 16;
        imageView4.setLayoutParams(layoutParams7);
        imageView4.setScaleType(ImageView.ScaleType.FIT_XY);
        if ("download".equals(this.b.h())) {
            getContext();
            imageView4.setImageDrawable(com.adfeiwo.ad.coverscreen.c.d.b.a(com.adfeiwo.ad.coverscreen.a.a.d));
        } else {
            getContext();
            imageView4.setImageDrawable(com.adfeiwo.ad.coverscreen.c.d.b.a(com.adfeiwo.ad.coverscreen.a.a.e));
        }
        linearLayout2.addView(imageView4);
        if (this.a) {
            a(this.r);
        } else {
            b(imageView2);
        }
    }

    @Override // com.adfeiwo.ad.coverscreen.x
    protected final View c() {
        return this.q;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.adfeiwo.ad.coverscreen.x
    public final View d() {
        return this.r;
    }
}
