package com.adfeiwo.ad.coverscreen;

import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class t extends TimerTask {
    private /* synthetic */ SA a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public t(SA sa) {
        this.a = sa;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public final void run() {
        this.a.c++;
        this.a.a.postDelayed(new u(this), 1L);
    }
}
