package com.adfeiwo.ad.coverscreen;

import java.util.Date;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class n implements com.adfeiwo.ad.coverscreen.c.c.c {
    final /* synthetic */ SA a;
    private final /* synthetic */ com.adfeiwo.ad.coverscreen.b.a b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public n(SA sa, com.adfeiwo.ad.coverscreen.b.a aVar) {
        this.a = sa;
        this.b = aVar;
    }

    @Override // com.adfeiwo.ad.coverscreen.c.c.c
    public final void a(int i) {
        this.a.a.post(new o(this, this.b, i));
    }

    @Override // com.adfeiwo.ad.coverscreen.c.c.c
    public final void a(int i, String str) {
        com.adfeiwo.ad.coverscreen.c.d.c.b(this.a.getApplicationContext(), "DP_COVER_FILE", this.b.e().replace(".", ""), String.valueOf(this.b.a()) + "," + new Date().getTime());
        try {
            com.adfeiwo.ad.coverscreen.c.a.a();
            com.adfeiwo.ad.coverscreen.c.a.a(this.a.getApplicationContext(), str);
        } catch (Exception e) {
            this.a.getApplicationContext();
            com.adfeiwo.ad.coverscreen.c.g.a.b("start install apk error: " + e);
        }
        if (i > 0) {
            this.a.a.post(new p(this, str, this.b));
        }
    }
}
