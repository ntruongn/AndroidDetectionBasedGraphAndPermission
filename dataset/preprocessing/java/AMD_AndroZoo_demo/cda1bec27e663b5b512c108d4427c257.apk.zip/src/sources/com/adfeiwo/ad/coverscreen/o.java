package com.adfeiwo.ad.coverscreen;

import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
final class o implements Runnable {
    private /* synthetic */ n a;
    private final /* synthetic */ com.adfeiwo.ad.coverscreen.b.a b;
    private final /* synthetic */ int c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(n nVar, com.adfeiwo.ad.coverscreen.b.a aVar, int i) {
        this.a = nVar;
        this.b = aVar;
        this.c = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.adfeiwo.ad.coverscreen.c.h.a.a(this.a.a.getApplicationContext()).a(this.b.a(), 17301586, this.b.d(), this.b.d(), "正在下载，已下载 " + (this.c + 1) + "%", new Intent(), 16, this.b.k());
    }
}
