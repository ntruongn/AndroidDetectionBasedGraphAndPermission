package com.adfeiwo.ad.coverscreen.c.e;

import android.os.Handler;
import android.os.Message;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class b extends Handler {
    private final /* synthetic */ d a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(a aVar, d dVar, String str) {
        this.a = dVar;
        this.b = str;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        if (message.obj == null || this.a == null) {
            return;
        }
        d dVar = this.a;
        Object obj = message.obj;
        String str = this.b;
    }
}
