package com.adfeiwo.ad.coverscreen;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
final class p implements Runnable {
    private /* synthetic */ n a;
    private final /* synthetic */ String b;
    private final /* synthetic */ com.adfeiwo.ad.coverscreen.b.a c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(n nVar, String str, com.adfeiwo.ad.coverscreen.b.a aVar) {
        this.a = nVar;
        this.b = str;
        this.c = aVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        com.adfeiwo.ad.coverscreen.c.h.a.a(this.a.a.getApplicationContext()).a(this.c.a(), 17301586, this.c.d(), this.c.d(), "下载完成，点击安装", com.adfeiwo.ad.coverscreen.c.a.a(this.b), 16, this.c.k());
    }
}
