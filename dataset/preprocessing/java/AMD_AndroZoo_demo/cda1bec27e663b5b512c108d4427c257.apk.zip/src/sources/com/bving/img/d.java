package com.bving.img;

import android.content.Context;
import dalvik.system.DexClassLoader;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class d {
    private static d g;
    private DexClassLoader c;
    private Class d;
    private Object e;
    private String f;
    public static final String a = c.f;
    public static final String b = c.h;
    private static String h = "";

    public static d a(Context context, String str) {
        if (g == null) {
            d dVar = new d();
            g = dVar;
            dVar.a(context);
            g.b(str);
        } else if (!g.f.equals(str)) {
            g.c.clearAssertionStatus();
            g.a(context);
            g.b(str);
        }
        return g;
    }

    private void a(Context context) {
        DataInputStream dataInputStream;
        InputStream inputStream;
        BufferedOutputStream bufferedOutputStream;
        BufferedOutputStream bufferedOutputStream2 = null;
        if ("".equals(h)) {
            try {
                h = context.getDir(c.g, 0).getAbsolutePath() + "/";
                File file = new File(h + a);
                inputStream = context.getAssets().open(b);
                try {
                    dataInputStream = new DataInputStream(inputStream);
                    try {
                        int readInt = dataInputStream.readInt();
                        if (file.exists() && file.length() == readInt) {
                            try {
                                dataInputStream.close();
                            } catch (IOException e) {
                            }
                            if (inputStream != null) {
                                try {
                                    inputStream.close();
                                } catch (IOException e2) {
                                }
                            }
                        } else {
                            byte[] bArr = new byte[readInt];
                            file.createNewFile();
                            bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(file));
                            try {
                                dataInputStream.read(bArr);
                                bufferedOutputStream.write(bArr);
                                bufferedOutputStream.close();
                                dataInputStream.close();
                                inputStream.close();
                                try {
                                    dataInputStream.close();
                                } catch (IOException e3) {
                                }
                                if (inputStream != null) {
                                    try {
                                        inputStream.close();
                                    } catch (IOException e4) {
                                    }
                                }
                                try {
                                    bufferedOutputStream.close();
                                } catch (IOException e5) {
                                }
                            } catch (Exception e6) {
                                if (dataInputStream != null) {
                                    try {
                                        dataInputStream.close();
                                    } catch (IOException e7) {
                                    }
                                }
                                if (inputStream != null) {
                                    try {
                                        inputStream.close();
                                    } catch (IOException e8) {
                                    }
                                }
                                if (bufferedOutputStream != null) {
                                    try {
                                        bufferedOutputStream.close();
                                    } catch (IOException e9) {
                                    }
                                }
                                this.c = new DexClassLoader(h + a, h, null, context.getClassLoader());
                            } catch (Throwable th) {
                                bufferedOutputStream2 = bufferedOutputStream;
                                th = th;
                                if (dataInputStream != null) {
                                    try {
                                        dataInputStream.close();
                                    } catch (IOException e10) {
                                    }
                                }
                                if (inputStream != null) {
                                    try {
                                        inputStream.close();
                                    } catch (IOException e11) {
                                    }
                                }
                                if (bufferedOutputStream2 == null) {
                                    throw th;
                                }
                                try {
                                    bufferedOutputStream2.close();
                                    throw th;
                                } catch (IOException e12) {
                                    throw th;
                                }
                            }
                        }
                    } catch (Exception e13) {
                        bufferedOutputStream = null;
                    } catch (Throwable th2) {
                        th = th2;
                    }
                } catch (Exception e14) {
                    bufferedOutputStream = null;
                    dataInputStream = null;
                } catch (Throwable th3) {
                    th = th3;
                    dataInputStream = null;
                }
            } catch (Exception e15) {
                bufferedOutputStream = null;
                dataInputStream = null;
                inputStream = null;
            } catch (Throwable th4) {
                th = th4;
                dataInputStream = null;
                inputStream = null;
            }
        }
        this.c = new DexClassLoader(h + a, h, null, context.getClassLoader());
    }

    private void b(String str) {
        this.f = str;
        try {
            this.d = this.c.loadClass(str);
            this.e = this.d.getConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception e) {
        }
    }

    public final Object a(String str) {
        return a(str, new Object[0], new Class[0]);
    }

    public final Object a(String str, Object obj, Class cls) {
        return a(str, new Object[]{obj}, new Class[]{cls});
    }

    public final Object a(String str, Object[] objArr, Class[] clsArr) {
        try {
            Method declaredMethod = this.d.getDeclaredMethod(str, clsArr);
            declaredMethod.setAccessible(true);
            return declaredMethod.invoke(this.e, objArr);
        } catch (Exception e) {
            return null;
        }
    }
}
