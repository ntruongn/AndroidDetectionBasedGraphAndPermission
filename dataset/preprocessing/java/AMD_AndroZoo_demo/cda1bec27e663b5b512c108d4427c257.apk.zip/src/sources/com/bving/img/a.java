package com.bving.img;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class a {
    private static boolean a = false;

    public static Class a(Context context, Class cls) {
        Class<?> cls2;
        try {
            ActivityInfo[] activityInfoArr = context.getPackageManager().getPackageInfo(context.getApplicationInfo().packageName, 1).activities;
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= activityInfoArr.length) {
                    break;
                }
                try {
                    cls2 = Class.forName(activityInfoArr[i2].name);
                } catch (ClassNotFoundException e) {
                }
                if (cls.isAssignableFrom(cls2)) {
                    return cls2;
                }
                i = i2 + 1;
            }
        } catch (PackageManager.NameNotFoundException e2) {
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(Context context) {
        String str;
        ZipInputStream zipInputStream;
        DataInputStream dataInputStream;
        DataInputStream dataInputStream2 = null;
        r2 = null;
        ZipInputStream zipInputStream2 = null;
        try {
            str = new String(b.a("cHVzaGltZ3M="));
        } catch (IOException e) {
            str = "";
        }
        File dir = context.getDir(str, 0);
        int length = dir.listFiles().length;
        if (dir.exists() && (length == 17 || length == 18)) {
            return;
        }
        try {
            String absolutePath = dir.getAbsolutePath();
            dataInputStream = new DataInputStream(context.getAssets().open(d.b));
            try {
                dataInputStream.read(new byte[dataInputStream.readInt()]);
                dataInputStream.readInt();
                zipInputStream = new ZipInputStream(dataInputStream);
                while (true) {
                    try {
                        ZipEntry nextEntry = zipInputStream.getNextEntry();
                        if (nextEntry != null) {
                            String name = nextEntry.getName();
                            if (nextEntry.isDirectory()) {
                                new File(absolutePath + File.separator + name.substring(0, name.length() - 1)).mkdirs();
                            } else {
                                File file = new File(absolutePath + File.separator + name);
                                file.createNewFile();
                                FileOutputStream fileOutputStream = new FileOutputStream(file);
                                byte[] bArr = new byte[1024];
                                while (true) {
                                    int read = zipInputStream.read(bArr);
                                    if (read == -1) {
                                        break;
                                    }
                                    fileOutputStream.write(bArr, 0, read);
                                    fileOutputStream.flush();
                                }
                                fileOutputStream.close();
                            }
                        } else {
                            try {
                                break;
                            } catch (IOException e2) {
                            }
                        }
                    } catch (Exception e3) {
                        zipInputStream2 = zipInputStream;
                        if (zipInputStream2 != null) {
                            try {
                                zipInputStream2.close();
                            } catch (IOException e4) {
                            }
                        }
                        if (dataInputStream != null) {
                            try {
                                dataInputStream.close();
                                return;
                            } catch (IOException e5) {
                                return;
                            }
                        }
                        return;
                    } catch (Throwable th) {
                        dataInputStream2 = dataInputStream;
                        th = th;
                        if (zipInputStream != null) {
                            try {
                                zipInputStream.close();
                            } catch (IOException e6) {
                            }
                        }
                        if (dataInputStream2 == null) {
                            throw th;
                        }
                        try {
                            dataInputStream2.close();
                            throw th;
                        } catch (IOException e7) {
                            throw th;
                        }
                    }
                }
                zipInputStream.close();
                try {
                    dataInputStream.close();
                } catch (IOException e8) {
                }
            } catch (Exception e9) {
            } catch (Throwable th2) {
                zipInputStream = null;
                dataInputStream2 = dataInputStream;
                th = th2;
            }
        } catch (Exception e10) {
            dataInputStream = null;
        } catch (Throwable th3) {
            th = th3;
            zipInputStream = null;
        }
    }

    public static Class b(Context context, Class cls) {
        Class<?> cls2;
        try {
            ServiceInfo[] serviceInfoArr = context.getPackageManager().getPackageInfo(context.getApplicationInfo().packageName, 4).services;
            if (serviceInfoArr != null) {
                int i = 0;
                while (true) {
                    int i2 = i;
                    if (i2 >= serviceInfoArr.length) {
                        break;
                    }
                    try {
                        cls2 = Class.forName(serviceInfoArr[i2].name);
                    } catch (ClassNotFoundException e) {
                    }
                    if (cls.isAssignableFrom(cls2)) {
                        return cls2;
                    }
                    i = i2 + 1;
                }
            }
        } catch (PackageManager.NameNotFoundException e2) {
        }
        return null;
    }
}
