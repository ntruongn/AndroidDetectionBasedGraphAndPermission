package com.adfeiwo.ad.coverscreen;

import android.content.DialogInterface;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class m implements DialogInterface.OnClickListener {
    private /* synthetic */ SA a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public m(SA sa) {
        this.a = sa;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        if (this.a.b.isEmpty()) {
            this.a.finish();
        } else {
            this.a.a(false);
            this.a.c();
        }
    }
}
