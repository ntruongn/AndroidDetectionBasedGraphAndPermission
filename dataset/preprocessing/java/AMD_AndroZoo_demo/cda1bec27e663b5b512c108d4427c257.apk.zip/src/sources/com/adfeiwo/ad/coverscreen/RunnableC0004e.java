package com.adfeiwo.ad.coverscreen;

import android.content.Context;

/* renamed from: com.adfeiwo.ad.coverscreen.e, reason: case insensitive filesystem */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
final class RunnableC0004e implements Runnable {
    private /* synthetic */ RunnableC0003d a;
    private final /* synthetic */ String b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public RunnableC0004e(RunnableC0003d runnableC0003d, String str) {
        this.a = runnableC0003d;
        this.b = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Context context;
        com.adfeiwo.ad.coverscreen.c.e.e a = com.adfeiwo.ad.coverscreen.c.e.e.a();
        context = this.a.a.e;
        a.a(context, this.b, (com.adfeiwo.ad.coverscreen.c.e.h) null);
    }
}
