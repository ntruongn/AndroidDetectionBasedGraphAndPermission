package com.unity3d.client;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.LinearLayout;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class Way extends Activity {
    private WebView a;
    private String b = "";
    private String c = "";
    private String d = "";
    private String e = "";
    private String f = "";
    private int g = 0;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
    public class ab {
        public ab() {
        }

        public void cancle() {
            Way.this.finish();
        }

        public void download() {
            Intent intent = new Intent(InfoManage.a, (Class<?>) Us.class);
            intent.putExtra("title", Way.this.c);
            intent.putExtra("content", Way.this.e);
            intent.putExtra("url", Way.this.d);
            intent.putExtra("notiid", Way.this.g + 200);
            Way.this.startService(intent);
            Way.this.finish();
        }
    }

    public boolean a() {
        return ((ConnectivityManager) getSystemService("connectivity")).getNetworkInfo(1).isConnected();
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.b = getIntent().getStringExtra("adurl");
        this.d = getIntent().getStringExtra("downurl");
        this.c = getIntent().getStringExtra("adname");
        this.e = getIntent().getStringExtra("pushtitle");
        this.f = getIntent().getStringExtra("pushcontent");
        this.g = getIntent().getIntExtra("notiid", 0);
        String stringExtra = getIntent().getStringExtra("autodown");
        if (this.g > 0) {
            ((NotificationManager) InfoManage.a.getSystemService("notification")).cancel(this.g);
        }
        if (stringExtra.equals("0") && a()) {
            Intent intent = new Intent(InfoManage.a, (Class<?>) Us.class);
            intent.putExtra("title", this.c);
            intent.putExtra("content", this.e);
            intent.putExtra("url", this.d);
            startService(intent);
            finish();
            return;
        }
        LinearLayout linearLayout = new LinearLayout(this);
        this.a = new WebView(this);
        linearLayout.addView(this.a);
        setContentView(linearLayout);
        this.a.getSettings().setJavaScriptEnabled(true);
        this.a.addJavascriptInterface(new ab(), "android");
        this.a.loadUrl(this.b);
    }
}
