package com.adfeiwo.ad.coverscreen.c.e;

import android.content.Context;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public final class g implements Runnable {
    private /* synthetic */ e a;
    private final /* synthetic */ Context b;
    private final /* synthetic */ String c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(e eVar, Context context, String str) {
        this.a = eVar;
        this.b = context;
        this.c = str;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x003d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0032 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            r6 = this;
            r5 = 0
            com.adfeiwo.ad.coverscreen.c.d.a.a()
            android.content.Context r0 = r6.b
            java.lang.String r1 = com.adfeiwo.ad.coverscreen.a.a.a
            java.lang.String r2 = r6.c
            java.lang.String r2 = com.adfeiwo.ad.coverscreen.c.d.a.a(r0, r1, r2)
            com.adfeiwo.ad.coverscreen.c.e.e r0 = r6.a
            java.util.concurrent.ConcurrentHashMap r0 = com.adfeiwo.ad.coverscreen.c.e.e.a(r0)
            java.lang.String r1 = r6.c
            java.lang.Object r0 = r0.get(r1)
            java.lang.ref.WeakReference r0 = (java.lang.ref.WeakReference) r0
            r1 = 0
            if (r0 == 0) goto L26
            java.lang.Object r0 = r0.get()
            android.graphics.Bitmap r0 = (android.graphics.Bitmap) r0
            r1 = r0
        L26:
            if (r1 != 0) goto L85
            com.adfeiwo.ad.coverscreen.c.e.e r0 = r6.a     // Catch: java.lang.Exception -> L81
            android.content.Context r0 = r6.b     // Catch: java.lang.Exception -> L81
            android.graphics.Bitmap r0 = com.adfeiwo.ad.coverscreen.c.e.e.a(r0, r2)     // Catch: java.lang.Exception -> L81
        L30:
            if (r0 != 0) goto L3b
            com.adfeiwo.ad.coverscreen.c.e.e r1 = r6.a     // Catch: java.lang.Exception -> L87
            android.content.Context r3 = r6.b     // Catch: java.lang.Exception -> L87
            java.lang.String r4 = r6.c     // Catch: java.lang.Exception -> L87
            com.adfeiwo.ad.coverscreen.c.e.e.a(r1, r3, r4)     // Catch: java.lang.Exception -> L87
        L3b:
            if (r0 != 0) goto L45
            com.adfeiwo.ad.coverscreen.c.e.e r1 = r6.a     // Catch: java.lang.Exception -> L8c
            android.content.Context r1 = r6.b     // Catch: java.lang.Exception -> L8c
            android.graphics.Bitmap r0 = com.adfeiwo.ad.coverscreen.c.e.e.a(r1, r2)     // Catch: java.lang.Exception -> L8c
        L45:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "loadDrawable complete, bitmap: "
            r1.<init>(r2)
            java.lang.StringBuilder r1 = r1.append(r0)
            java.lang.String r2 = ", url: "
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r2 = r6.c
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            com.adfeiwo.ad.coverscreen.c.g.a.b(r1)
            com.adfeiwo.ad.coverscreen.c.e.e r1 = r6.a
            android.os.Handler r1 = com.adfeiwo.ad.coverscreen.c.e.e.c(r1)
            com.adfeiwo.ad.coverscreen.c.e.e r2 = r6.a
            android.os.Handler r2 = com.adfeiwo.ad.coverscreen.c.e.e.c(r2)
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.String r4 = r6.c
            r3[r5] = r4
            r4 = 1
            r3[r4] = r0
            android.os.Message r0 = r2.obtainMessage(r5, r3)
            r1.sendMessage(r0)
            return
        L81:
            r0 = move-exception
            com.adfeiwo.ad.coverscreen.c.g.a.a(r0)
        L85:
            r0 = r1
            goto L30
        L87:
            r1 = move-exception
            com.adfeiwo.ad.coverscreen.c.g.a.a(r1)
            goto L3b
        L8c:
            r1 = move-exception
            com.adfeiwo.ad.coverscreen.c.g.a.a(r1)
            goto L45
        */
        throw new UnsupportedOperationException("Method not decompiled: com.adfeiwo.ad.coverscreen.c.e.g.run():void");
    }
}
