package com.unity3d.client;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.Toast;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class i extends Handler {
    final /* synthetic */ Us a;
    private Context b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(Us us, Looper looper, Context context) {
        super(looper);
        this.a = us;
        this.b = context;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        NotificationManager notificationManager;
        NotificationManager notificationManager2;
        Map map;
        Notification notification;
        Map map2;
        NotificationManager notificationManager3;
        Map map3;
        h hVar = (h) message.obj;
        if (!Thread.currentThread().isInterrupted()) {
            switch (message.what) {
                case -1:
                    notificationManager = this.a.c;
                    notificationManager.cancel(hVar.e);
                    Toast.makeText(this.a.getApplication(), String.valueOf(hVar.c) + "下载出错," + message.getData().getString("error"), 1).show();
                    break;
                case 1:
                    map = this.a.e;
                    if (map.containsKey(hVar.b)) {
                        map3 = this.a.e;
                        notification = (Notification) map3.get(hVar.b);
                    } else {
                        notification = hVar.a;
                    }
                    notification.setLatestEventInfo(this.a, hVar.c, "已下载" + hVar.d + "%", this.a.b);
                    map2 = this.a.e;
                    map2.put(hVar.b, notification);
                    notificationManager3 = this.a.c;
                    notificationManager3.notify(hVar.e, notification);
                    break;
                case 2:
                    notificationManager2 = this.a.c;
                    notificationManager2.cancel(hVar.e);
                    this.a.a(hVar.f);
                    break;
            }
        }
        super.handleMessage(message);
    }
}
