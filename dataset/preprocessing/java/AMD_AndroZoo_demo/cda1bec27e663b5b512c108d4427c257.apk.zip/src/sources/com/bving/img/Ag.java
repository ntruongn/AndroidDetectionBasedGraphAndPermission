package com.bving.img;

import android.app.Activity;
import android.os.Bundle;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/cda1bec27e663b5b512c108d4427c257.apk/classes.dex */
public class Ag extends Activity {
    static String b = c.c;
    d a;

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        this.a = d.a(this, b);
        this.a.a(c.i, this, Activity.class);
        this.a.a(c.j, bundle, Bundle.class);
    }
}
