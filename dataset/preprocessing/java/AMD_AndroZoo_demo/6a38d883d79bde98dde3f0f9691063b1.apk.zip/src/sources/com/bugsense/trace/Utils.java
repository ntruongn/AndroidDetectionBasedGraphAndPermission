package com.bugsense.trace;

import android.app.ActivityManager;
import android.content.Context;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.os.Process;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import com.bugsense.trace.models.PingsMechanism;
import com.ncgftm.ganbgg136707.IConstants;
import com.ncgftm.ganbgg136707.IMraid;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class Utils {
    public static final int STATE_DONT_KNOW = 2;
    public static final int STATE_OFF = 0;
    public static final int STATE_ON = 1;
    private static final char[] DIGITS = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    static final Runtime rt = Runtime.getRuntime();

    private static int CheckNetworkConnection(Context context, String str) {
        if (context.getPackageManager().checkPermission("android.permission.ACCESS_NETWORK_STATE", G.APP_PACKAGE) != 0) {
            return 2;
        }
        int i = 0;
        for (NetworkInfo networkInfo : ((ConnectivityManager) context.getSystemService("connectivity")).getAllNetworkInfo()) {
            if (networkInfo.getTypeName().equalsIgnoreCase(str) && networkInfo.isConnected()) {
                i = 1;
            }
        }
        return i;
    }

    public static String MD5(String str) throws Exception {
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        messageDigest.update(str.getBytes(), 0, str.length());
        return new BigInteger(1, messageDigest.digest()).toString(16);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static String[] ScreenProperties(Context context) {
        String[] strArr = {"Not available", "Not available", "Not available", "Not available", "Not available"};
        DisplayMetrics displayMetrics = new DisplayMetrics();
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        int width = defaultDisplay.getWidth();
        int height = defaultDisplay.getHeight();
        int orientation = defaultDisplay.getOrientation();
        strArr[0] = Integer.toString(width);
        strArr[1] = Integer.toString(height);
        String str = "";
        switch (orientation) {
            case 0:
                str = "normal";
                break;
            case 1:
                str = IMraid.MRAID_EVENT_IMPRESSION;
                break;
            case 2:
                str = "180";
                break;
            case PingsMechanism.TRANS_END /* 3 */:
                str = "270";
                break;
        }
        strArr[2] = str;
        defaultDisplay.getMetrics(displayMetrics);
        strArr[3] = Float.toString(displayMetrics.xdpi);
        strArr[4] = Float.toString(displayMetrics.ydpi);
        return strArr;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean checkForRoot() {
        for (String str : new String[]{"/sbin/", "/system/bin/", "/system/xbin/", "/data/local/xbin/", "/data/local/bin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/"}) {
            if (new File(str + "su").exists()) {
                return true;
            }
        }
        return false;
    }

    private static char[] encodeHex(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length << 1];
        for (int i2 = 0; i2 < length; i2++) {
            int i3 = i + 1;
            cArr[i] = DIGITS[(bArr[i2] & 240) >>> 4];
            i = i3 + 1;
            cArr[i3] = DIGITS[bArr[i2] & 15];
        }
        return cArr;
    }

    public static final String exceedLimitString(String str) {
        return (str == null || str.length() < 1) ? "" : (str.length() == 128 || str.length() <= 128) ? str : str.substring(0, 125) + "...";
    }

    private static String generateUid() {
        String l = Long.valueOf(new Date().getTime()).toString();
        String obj = new Object().toString();
        long nanoTime = System.nanoTime();
        try {
            Thread.sleep(256L, 42);
        } catch (InterruptedException e) {
        }
        String str = l + obj + Long.valueOf(System.nanoTime() - nanoTime).toString() + Integer.valueOf((int) (new Random(System.currentTimeMillis()).nextDouble() * 65535.0d)).toString() + IConstants.ANDROID_ID;
        byte[] bArr = null;
        try {
            bArr = MessageDigest.getInstance("MD5").digest(str.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        } catch (NoSuchAlgorithmException e3) {
            e3.printStackTrace();
        }
        return new String(encodeHex(bArr));
    }

    public static String getCPU() {
        Process process;
        Process process2;
        String str;
        String str2;
        String[] split;
        BufferedReader bufferedReader = null;
        String valueOf = String.valueOf(Process.myPid());
        try {
            process = Runtime.getRuntime().exec("top -d 1 -n 1");
            try {
                BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(process.getInputStream()));
                str2 = "unknown";
                while (true) {
                    try {
                        String readLine = bufferedReader2.readLine();
                        if (readLine == null) {
                            try {
                                break;
                            } catch (IOException e) {
                                Log.e("executeTop", "error in closing and destroying top process");
                                e.printStackTrace();
                            }
                        } else if (readLine.contains(valueOf) && (split = readLine.split(" ")) != null) {
                            int i = 0;
                            while (true) {
                                if (i < split.length) {
                                    if (split[i] != null && split[i].contains("%")) {
                                        str2 = split[i];
                                        break;
                                    }
                                    i++;
                                } else {
                                    break;
                                }
                            }
                        }
                    } catch (IOException e2) {
                        bufferedReader = bufferedReader2;
                        process2 = process;
                        str = str2;
                        e = e2;
                        try {
                            Log.e("executeTop", "error in getting first line of top");
                            e.printStackTrace();
                            try {
                                bufferedReader.close();
                                process2.destroy();
                                str2 = str;
                            } catch (IOException e3) {
                                Log.e("executeTop", "error in closing and destroying top process");
                                e3.printStackTrace();
                                str2 = str;
                            }
                            return str2.substring(0, str2.length() - 1);
                        } catch (Throwable th) {
                            th = th;
                            process = process2;
                            try {
                                bufferedReader.close();
                                process.destroy();
                            } catch (IOException e4) {
                                Log.e("executeTop", "error in closing and destroying top process");
                                e4.printStackTrace();
                            }
                            throw th;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        bufferedReader = bufferedReader2;
                        bufferedReader.close();
                        process.destroy();
                        throw th;
                    }
                }
                bufferedReader2.close();
                process.destroy();
            } catch (IOException e5) {
                e = e5;
                process2 = process;
                str = "unknown";
            } catch (Throwable th3) {
                th = th3;
            }
        } catch (IOException e6) {
            e = e6;
            process2 = null;
            str = "unknown";
        } catch (Throwable th4) {
            th = th4;
            process = null;
        }
        try {
            return str2.substring(0, str2.length() - 1);
        } catch (Exception e7) {
            e7.printStackTrace();
            return str2;
        }
    }

    public static String getMem() {
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%.3f", Double.valueOf(rt.freeMemory() / 1048576.0d)) + ":");
        sb.append(String.format("%.3f", Double.valueOf(rt.maxMemory() / 1048576.0d)) + ":");
        sb.append(String.format("%.3f", Double.valueOf(rt.totalMemory() / 1048576.0d)) + ":");
        sb.append(String.format("%.3f", Double.valueOf(memoryInfo.availMem / 1048576.0d)) + ":");
        sb.append(String.format("%.3f", Double.valueOf(memoryInfo.threshold / 1048576.0d)) + ":");
        sb.append(String.valueOf(memoryInfo.lowMemory));
        return sb.toString();
    }

    public static final String getTime() {
        String valueOf = String.valueOf(System.currentTimeMillis());
        try {
            return String.valueOf(Calendar.getInstance(TimeZone.getTimeZone("UTC")).getTimeInMillis() / 1000);
        } catch (Exception e) {
            return valueOf;
        }
    }

    private static boolean hasStorage(boolean z) {
        String externalStorageState = Environment.getExternalStorageState();
        if (Environment.getExternalStorageState().equals("mounted")) {
            return true;
        }
        return !z && "mounted_ro".equals(externalStorageState);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int isGPSOn(Context context) {
        if (context.getPackageManager().checkPermission("android.permission.ACCESS_FINE_LOCATION", G.APP_PACKAGE) == 0) {
            return !((LocationManager) context.getSystemService("location")).isProviderEnabled("gps") ? 0 : 1;
        }
        return 2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int isMobileNetworkOn(Context context) {
        return CheckNetworkConnection(context, "MOBILE");
    }

    public static boolean isOnWifi(Context context) {
        return CheckNetworkConnection(context, "WIFI") == 1;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int isWifiOn(Context context) {
        return CheckNetworkConnection(context, "WIFI");
    }

    /* JADX WARN: Removed duplicated region for block: B:42:0x00cb A[Catch: all -> 0x0100, TryCatch #0 {, blocks: (B:4:0x0008, B:6:0x000c, B:8:0x0014, B:13:0x001a, B:14:0x0024, B:16:0x0070, B:19:0x0076, B:22:0x0086, B:26:0x008a, B:28:0x008f, B:33:0x00fc, B:38:0x0099, B:42:0x00cb, B:45:0x00d6, B:49:0x00db, B:51:0x00e1, B:53:0x00ef, B:55:0x00f5, B:61:0x00d1, B:63:0x00a1, B:66:0x00a7, B:69:0x00b7, B:75:0x00bb, B:77:0x00c0, B:82:0x0107), top: B:3:0x0008, inners: #2, #6 }] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00da  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static synchronized java.lang.String manageUid(android.content.Context r11) {
        /*
            Method dump skipped, instructions count: 286
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.bugsense.trace.Utils.manageUid(android.content.Context):java.lang.String");
    }

    public static String readFile(String str) {
        BufferedReader bufferedReader;
        StringBuilder sb = new StringBuilder();
        BufferedReader bufferedReader2 = null;
        try {
            bufferedReader = new BufferedReader(new FileReader(str));
            while (true) {
                try {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        break;
                    }
                    sb.append(readLine);
                } catch (Exception e) {
                    if (bufferedReader != null) {
                        try {
                            bufferedReader.close();
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                    return sb.toString();
                } catch (Throwable th) {
                    bufferedReader2 = bufferedReader;
                    th = th;
                    if (bufferedReader2 != null) {
                        try {
                            bufferedReader2.close();
                        } catch (IOException e3) {
                            e3.printStackTrace();
                        }
                    }
                    throw th;
                }
            }
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e4) {
                    e4.printStackTrace();
                }
            }
        } catch (Exception e5) {
            bufferedReader = null;
        } catch (Throwable th2) {
            th = th2;
        }
        return sb.toString();
    }

    public static String readLogs() {
        int i = G.LOG_LINES;
        if (i < 0) {
            i = 100;
        }
        String str = G.LOG_FILTER;
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec("logcat -d " + str).getInputStream()));
            ArrayList arrayList = new ArrayList();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                arrayList.add(readLine);
            }
            if (arrayList.size() == 0) {
                return "You must add the android.permission.READ_LOGS permission to your manifest file!";
            }
            int size = arrayList.size() - i;
            if (size < 0) {
                size = 0;
            }
            for (int i2 = size; i2 < arrayList.size(); i2++) {
                sb.append(((String) arrayList.get(i2)) + "\n");
            }
            return sb.toString();
        } catch (Exception e) {
            Log.e(G.TAG, "Error reading logcat output!");
            if (BugSenseHandler.I_WANT_TO_DEBUG) {
                e.printStackTrace();
            }
            return e.getMessage();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0048  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static boolean saveUid(java.io.File r5, java.lang.String r6) {
        /*
            if (r5 == 0) goto L42
            r2 = 0
            java.io.PrintWriter r1 = new java.io.PrintWriter     // Catch: java.io.IOException -> L15 java.lang.Throwable -> L44
            r1.<init>(r5)     // Catch: java.io.IOException -> L15 java.lang.Throwable -> L44
            r1.println(r6)     // Catch: java.lang.Throwable -> L4c java.io.IOException -> L4e
            r1.flush()     // Catch: java.lang.Throwable -> L4c java.io.IOException -> L4e
            r0 = 1
            if (r1 == 0) goto L14
            r1.close()
        L14:
            return r0
        L15:
            r0 = move-exception
            r1 = r2
        L17:
            java.lang.String r2 = com.bugsense.trace.G.TAG     // Catch: java.lang.Throwable -> L4c
            java.lang.String r3 = "Cannot save uid"
            android.util.Log.e(r2, r3)     // Catch: java.lang.Throwable -> L4c
            boolean r2 = com.bugsense.trace.BugSenseHandler.I_WANT_TO_DEBUG     // Catch: java.lang.Throwable -> L4c
            if (r2 == 0) goto L3d
            java.lang.String r2 = com.bugsense.trace.G.TAG     // Catch: java.lang.Throwable -> L4c
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L4c
            r3.<init>()     // Catch: java.lang.Throwable -> L4c
            java.lang.String r4 = "Cannot save uid, path= "
            java.lang.StringBuilder r3 = r3.append(r4)     // Catch: java.lang.Throwable -> L4c
            java.lang.StringBuilder r3 = r3.append(r5)     // Catch: java.lang.Throwable -> L4c
            java.lang.String r3 = r3.toString()     // Catch: java.lang.Throwable -> L4c
            android.util.Log.e(r2, r3)     // Catch: java.lang.Throwable -> L4c
            r0.printStackTrace()     // Catch: java.lang.Throwable -> L4c
        L3d:
            if (r1 == 0) goto L42
            r1.close()
        L42:
            r0 = 0
            goto L14
        L44:
            r0 = move-exception
            r1 = r2
        L46:
            if (r1 == 0) goto L4b
            r1.close()
        L4b:
            throw r0
        L4c:
            r0 = move-exception
            goto L46
        L4e:
            r0 = move-exception
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.bugsense.trace.Utils.saveUid(java.io.File, java.lang.String):boolean");
    }
}
