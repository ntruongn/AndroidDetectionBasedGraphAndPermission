package com.ncgftm.ganbgg136707;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.util.List;
import java.util.zip.GZIPInputStream;
import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponse;
import org.apache.http.HttpResponseInterceptor;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.HttpEntityWrapper;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
final class HttpPostDataTask extends AsyncTask<Void, Void, Boolean> {
    private static final String ENCODING_GZIP = "gzip";
    private static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
    private final String URL_TO_CALL;
    private final AsyncTaskCompleteListener<String> callback;
    private Context mContext;
    private String responseString;
    private List<NameValuePair> valuePairs;

    public HttpPostDataTask(Context context, List<NameValuePair> values, String api_url, AsyncTaskCompleteListener<String> asyncTaskCompleteListener) {
        Util.printDebugLog("Calling URL:> " + api_url);
        this.mContext = context;
        this.valuePairs = values;
        this.URL_TO_CALL = api_url;
        this.callback = asyncTaskCompleteListener;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public synchronized Boolean doInBackground(Void... params) {
        BasicHttpResponse httpResponse;
        int code;
        Boolean bool;
        if (Util.checkInternetConnection(this.mContext)) {
            try {
                try {
                    try {
                        HttpPost httpPost = new HttpPost(this.URL_TO_CALL);
                        httpPost.setEntity(new UrlEncodedFormEntity(this.valuePairs));
                        BasicHttpParams httpParameters = new BasicHttpParams();
                        HttpConnectionParams.setConnectionTimeout(httpParameters, 7000);
                        HttpConnectionParams.setSoTimeout(httpParameters, 7000);
                        DefaultHttpClient httpClient = new DefaultHttpClient(httpParameters);
                        httpClient.addRequestInterceptor(new HttpRequestInterceptor() { // from class: com.ncgftm.ganbgg136707.HttpPostDataTask.1
                            @Override // org.apache.http.HttpRequestInterceptor
                            public void process(HttpRequest request, HttpContext context) {
                                if (!request.containsHeader(HttpPostDataTask.HEADER_ACCEPT_ENCODING)) {
                                    request.addHeader(HttpPostDataTask.HEADER_ACCEPT_ENCODING, HttpPostDataTask.ENCODING_GZIP);
                                }
                            }
                        });
                        httpClient.addResponseInterceptor(new HttpResponseInterceptor() { // from class: com.ncgftm.ganbgg136707.HttpPostDataTask.2
                            @Override // org.apache.http.HttpResponseInterceptor
                            public void process(HttpResponse response, HttpContext context) {
                                HttpEntity entity = response.getEntity();
                                Header encoding = entity.getContentEncoding();
                                if (encoding != null) {
                                    HeaderElement[] arr$ = encoding.getElements();
                                    for (HeaderElement element : arr$) {
                                        if (element.getName().equalsIgnoreCase(HttpPostDataTask.ENCODING_GZIP)) {
                                            response.setEntity(new InflatingEntity(response.getEntity()));
                                            return;
                                        }
                                    }
                                }
                            }
                        });
                        httpResponse = (BasicHttpResponse) httpClient.execute(httpPost);
                        code = httpResponse.getStatusLine().getStatusCode();
                        Log.i(IConstants.TAG, "Status Code: " + code);
                    } catch (MalformedURLException e) {
                        Log.d("MalformedURLException Thrown", e.toString());
                    } catch (SocketTimeoutException e2) {
                        Log.d("SocketTimeoutException Thrown", e2.toString());
                    }
                } catch (Exception iex) {
                    Log.d("Exception Thrown: ", "" + iex.getMessage());
                } catch (Throwable th) {
                }
            } catch (ClientProtocolException e3) {
                Log.d("ClientProtocolException Thrown", e3.toString());
            } catch (IOException e4) {
                Log.d("IOException Thrown", e4.toString());
            }
            if (code == 200) {
                this.responseString = EntityUtils.toString(httpResponse.getEntity());
                Util.printDebugLog("Response String:" + this.responseString);
                if (this.responseString != null && !this.responseString.equals("")) {
                    bool = Boolean.TRUE;
                }
            } else {
                Log.i(IConstants.TAG, "HTTP response Reason: " + httpResponse.getStatusLine().getReasonPhrase());
            }
        }
        bool = Boolean.FALSE;
        return bool;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public synchronized void onPostExecute(Boolean result) {
        try {
            if (result.booleanValue()) {
                this.callback.onTaskComplete(this.responseString);
            } else {
                this.callback.onTaskComplete(this.responseString);
                Util.printDebugLog("Call Failed due to Network error. ");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    private static class InflatingEntity extends HttpEntityWrapper {
        public InflatingEntity(HttpEntity wrapped) {
            super(wrapped);
        }

        @Override // org.apache.http.entity.HttpEntityWrapper, org.apache.http.HttpEntity
        public InputStream getContent() throws IOException {
            return new GZIPInputStream(this.wrappedEntity.getContent());
        }

        @Override // org.apache.http.entity.HttpEntityWrapper, org.apache.http.HttpEntity
        public long getContentLength() {
            return -1L;
        }
    }
}
