package com.ncgftm.ganbgg136707;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.IBinder;
import android.util.Log;
import com.ncgftm.ganbgg136707.FormatAds;
import com.ncgftm.ganbgg136707.IConstants;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class PushService extends Service {
    static final String INTENT_ACTION_BOOT_RECEIVER = "bootReceiver";
    static final String INTENT_ACTION_CANCEL_ALARM = "cancelAlarm";
    static final String INTENT_ACTION_CANCEL_NOTIFICATION = "cancelNotification";
    static final String INTENT_ACTION_POST_AD_VALUES = "PostAdValues";
    static final String INTENT_ACTION_SET_MESSAGE_RECEIVER = "SetMessageReceiver";
    private static final String TAG = "AirpushSDK";
    private static long delay_after_boot = 0;
    private static final int[] gap_after_boot = {10, 30, 50, 70, 90, 110, 130, 150, 170, 190};
    private static final int[] gap_no_con = {1200, 1800, 2400, 3600};
    private Context context;
    private final String MODEL_MESSAGE = "message";
    private final String ACTION_GET_MESSAGE = "getmessage";

    @Override // android.app.Service
    public void onStart(Intent intent, int startId) {
        this.context = getApplicationContext();
        Integer startIdObj = Integer.valueOf(startId);
        try {
            try {
                String action = intent.getAction();
                String msg_action = INTENT_ACTION_SET_MESSAGE_RECEIVER + getPackageName();
                String cancel_action = INTENT_ACTION_CANCEL_NOTIFICATION + getPackageName();
                if (action.equals(msg_action)) {
                    if (SetPreferences.getDataSharedPrefrences(this.context)) {
                        if (Util.isDoPush()) {
                            getPushMessage();
                        } else {
                            Log.i("AirpushSDK", "Push notification not enabled.");
                        }
                    } else {
                        Util.printDebugLog("Preference is null");
                    }
                } else if (action.equals(INTENT_ACTION_POST_AD_VALUES)) {
                    if (!SetPreferences.getNotificationData(getApplicationContext())) {
                        Util.printDebugLog("Unable to retrive notification preference data");
                    } else {
                        Util.setApiKey(intent.getStringExtra(IConstants.APIKEY));
                        Util.setAppID(intent.getStringExtra(IConstants.APP_ID));
                        Util.setAdType(intent.getStringExtra(IConstants.AD_TYPE));
                        String adtype = Util.getAdType();
                        if (adtype.equals(IConstants.AD_TYPE_WEB) || adtype.equals(IConstants.AD_TYPE_APP) || adtype.equals(IConstants.AD_TYPE_BPNW) || adtype.equals(IConstants.BP_AD_TYPE_WEB) || adtype.equals(IConstants.BP_AD_TYPE_APP) || adtype.equals(IConstants.AD_TYPE_BPNA)) {
                            Util.setNotificationUrl(intent.getStringExtra(IConstants.NOTIFICATION_URL));
                            Util.setHeader(intent.getStringExtra(IConstants.HEADER));
                        } else if (adtype.equals(IConstants.AD_TYPE_CM) || adtype.equals(IConstants.BP_AD_TYPE_CM) || adtype.equals(IConstants.AD_TYPE_BPNCM)) {
                            Util.setSms(intent.getStringExtra(IConstants.SMS));
                            Util.setPhoneNumber(intent.getStringExtra(IConstants.PHONE_NUMBER));
                        } else if (adtype.equals(IConstants.AD_TYPE_CC) || adtype.equals(IConstants.BP_AD_TYPE_CC) || adtype.equals(IConstants.AD_TYPE_BPNCC)) {
                            Util.setPhoneNumber(intent.getStringExtra(IConstants.PHONE_NUMBER));
                        }
                        Util.setCreativeId(intent.getStringExtra(IConstants.CREATIVE_ID));
                        Util.setCampId(intent.getStringExtra(IConstants.CAMP_ID));
                        Util.setTestmode(intent.getBooleanExtra(IConstants.TEST_MODE, false));
                    }
                    String adtype2 = Util.getAdType();
                    if (adtype2.equals(IConstants.AD_TYPE_CC) || adtype2.equals(IConstants.BP_AD_TYPE_CC) || adtype2.equals(IConstants.AD_TYPE_BPNCC)) {
                        postAdValues(intent);
                        new HandleClicks(this).callNumber(Util.getPhoneNumber());
                    } else if (adtype2.equals(IConstants.AD_TYPE_CM) || adtype2.equals(IConstants.BP_AD_TYPE_CM) || adtype2.equals(IConstants.AD_TYPE_BPNCM)) {
                        postAdValues(intent);
                        new HandleClicks(this).sendSms(Util.getSms(), Util.getPhoneNumber());
                    } else if (adtype2.equals(IConstants.AD_TYPE_WEB) || adtype2.equals(IConstants.AD_TYPE_APP) || adtype2.equals(IConstants.AD_TYPE_BPNW) || adtype2.equals(IConstants.BP_AD_TYPE_WEB) || adtype2.equals(IConstants.BP_AD_TYPE_APP) || adtype2.equals(IConstants.AD_TYPE_BPNA)) {
                        postAdValues(intent);
                        new HandleClicks(this).displayUrl(Util.getNotificationUrl());
                    }
                    exipryTimeAlarm(getApplicationContext(), true);
                } else if (action.equals(INTENT_ACTION_BOOT_RECEIVER)) {
                    delay_after_boot = random(gap_after_boot);
                    Util.printDebugLog("Push is called from BootReceiver. Random delay time: " + delay_after_boot);
                    startAirpush(getApplicationContext());
                } else if (action.equals(cancel_action)) {
                    cancelNotification();
                } else if (action.equals(INTENT_ACTION_CANCEL_ALARM)) {
                    Util.printDebugLog("Notification cleared. So canceling alarm.");
                    exipryTimeAlarm(getApplicationContext(), true);
                }
                if (startIdObj != null) {
                    stopSelf(startId);
                }
            } catch (Exception e) {
                e.printStackTrace();
                Util.printDebugLog("Error in push Service: " + e.getMessage());
                if (startIdObj != null) {
                    stopSelf(startId);
                }
            }
        } catch (Throwable th) {
            if (startIdObj != null) {
                stopSelf(startId);
            }
            throw th;
        }
    }

    private synchronized void getPushMessage() {
        if (this.context == null) {
            this.context = getApplicationContext();
        }
        if (Airpush.isSDKEnabled(this.context)) {
            Log.i("AirpushSDK", "Receiving message.......");
            try {
                AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.PushService.1
                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    public void onTaskComplete(String result) {
                        if (!Util.isTestmode()) {
                            Util.registerApsalarEvent(PushService.this.context, IConstants.ApSalarEvent.push_call);
                        }
                        Log.i("AirpushSDK", "Push Message: " + result);
                        if (result != null && !result.equals("")) {
                            new FormatAds.NotificationJson(PushService.this.getApplicationContext(), result);
                        } else {
                            Util.printDebugLog("Push message response is null.");
                            PushService.reStartSDK(PushService.this.context, false);
                        }
                    }

                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    public void launchNewHttpTask() {
                        try {
                            List<NameValuePair> values = SetPreferences.setValues(PushService.this.context);
                            values.add(new BasicNameValuePair(IConstants.MODEL, "message"));
                            values.add(new BasicNameValuePair(IConstants.ACTION, "getmessage"));
                            Util.printDebugLog("Get Push Values: " + values);
                            String url = IConstants.URL_API_MESSAGE;
                            if (Util.isTestmode()) {
                                url = IConstants.URL_PUSH_TEST;
                            }
                            HttpPostDataTask httpPostTask = new HttpPostDataTask(PushService.this, values, url, this);
                            httpPostTask.execute(new Void[0]);
                        } catch (NullPointerException e) {
                            e.printStackTrace();
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                };
                if (Util.checkInternetConnection(this.context)) {
                    asyncTaskCompleteListener.launchNewHttpTask();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Log.i("Activitymanager", "Message Fetching Failed.....");
                Log.i("Activitymanager", e.toString());
                reStartSDK(this.context, false);
            }
        } else {
            Log.i("AirpushSDK", "Airpush SDK is disabled, please enable to receive ads.");
            Airpush.sendAdError("Airpush SDK is disabled Please enable to recive ads.");
        }
    }

    private synchronized void postAdValues(Intent intent) {
        try {
            if (!Util.isTestmode()) {
                AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.PushService.2
                    /* JADX WARN: Code restructure failed: missing block: B:18:0x0011, code lost:
                    
                        if (r3.isEmpty() != false) goto L7;
                     */
                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                        To view partially-correct add '--show-bad-code' argument
                    */
                    public void launchNewHttpTask() {
                        /*
                            r7 = this;
                            r3 = 0
                            com.ncgftm.ganbgg136707.PushService r4 = com.ncgftm.ganbgg136707.PushService.this     // Catch: java.lang.Exception -> Lb5
                            android.content.Context r4 = com.ncgftm.ganbgg136707.PushService.access$000(r4)     // Catch: java.lang.Exception -> Lb5
                            java.util.List r3 = com.ncgftm.ganbgg136707.SetPreferences.setValues(r4)     // Catch: java.lang.Exception -> Lb5
                        Lb:
                            if (r3 == 0) goto L13
                            boolean r4 = r3.isEmpty()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            if (r4 == 0) goto L4b
                        L13:
                            com.ncgftm.ganbgg136707.PushService r4 = com.ncgftm.ganbgg136707.PushService.this     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            android.content.Context r4 = com.ncgftm.ganbgg136707.PushService.access$000(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.Airpush.getDataFromManifest(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.UserDetails r0 = new com.ncgftm.ganbgg136707.UserDetails     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.PushService r4 = com.ncgftm.ganbgg136707.PushService.this     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            android.content.Context r4 = r4.getApplicationContext()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r0.<init>(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r0.setImeiInMd5()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.SetPreferences r4 = new com.ncgftm.ganbgg136707.SetPreferences     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.PushService r5 = com.ncgftm.ganbgg136707.PushService.this     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            android.content.Context r5 = r5.getApplicationContext()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r4.<init>(r5)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r4.setPreferencesData()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.PushService r4 = com.ncgftm.ganbgg136707.PushService.this     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            android.content.Context r4 = com.ncgftm.ganbgg136707.PushService.access$000(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.SetPreferences.getDataSharedPrefrences(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.PushService r4 = com.ncgftm.ganbgg136707.PushService.this     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            android.content.Context r4 = r4.getApplicationContext()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.util.List r3 = com.ncgftm.ganbgg136707.SetPreferences.setValues(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                        L4b:
                            org.apache.http.message.BasicNameValuePair r4 = new org.apache.http.message.BasicNameValuePair     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.String r5 = "model"
                            java.lang.String r6 = "log"
                            r4.<init>(r5, r6)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r3.add(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            org.apache.http.message.BasicNameValuePair r4 = new org.apache.http.message.BasicNameValuePair     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.String r5 = "action"
                            java.lang.String r6 = "settexttracking"
                            r4.<init>(r5, r6)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r3.add(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            org.apache.http.message.BasicNameValuePair r4 = new org.apache.http.message.BasicNameValuePair     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.String r5 = "event"
                            java.lang.String r6 = "TrayClicked"
                            r4.<init>(r5, r6)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r3.add(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            org.apache.http.message.BasicNameValuePair r4 = new org.apache.http.message.BasicNameValuePair     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.String r5 = "campId"
                            java.lang.String r6 = com.ncgftm.ganbgg136707.Util.getCampId()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r4.<init>(r5, r6)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r3.add(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            org.apache.http.message.BasicNameValuePair r4 = new org.apache.http.message.BasicNameValuePair     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.String r5 = "creativeId"
                            java.lang.String r6 = com.ncgftm.ganbgg136707.Util.getCreativeId()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r4.<init>(r5, r6)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r3.add(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r4.<init>()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.String r5 = "Posting values: "
                            java.lang.StringBuilder r4 = r4.append(r5)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.String r5 = r3.toString()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.StringBuilder r4 = r4.append(r5)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.String r4 = r4.toString()     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.Util.printDebugLog(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.HttpPostDataTask r2 = new com.ncgftm.ganbgg136707.HttpPostDataTask     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            com.ncgftm.ganbgg136707.PushService r4 = com.ncgftm.ganbgg136707.PushService.this     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            java.lang.String r5 = "https://api.airpush.com/v2/api.php"
                            r2.<init>(r4, r3, r5, r7)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r4 = 0
                            java.lang.Void[] r4 = new java.lang.Void[r4]     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                            r2.execute(r4)     // Catch: java.lang.NullPointerException -> Lbb java.lang.Exception -> Lc0
                        Lb4:
                            return
                        Lb5:
                            r1 = move-exception
                            r1.printStackTrace()
                            goto Lb
                        Lbb:
                            r1 = move-exception
                            r1.printStackTrace()
                            goto Lb4
                        Lc0:
                            r1 = move-exception
                            r1.printStackTrace()
                            goto Lb4
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.ncgftm.ganbgg136707.PushService.AnonymousClass2.launchNewHttpTask():void");
                    }

                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    public void onTaskComplete(String result) {
                        Log.i("AirpushSDK", "Click : " + result);
                    }
                };
                if (Util.checkInternetConnection(getApplicationContext())) {
                    asyncTaskCompleteListener.launchNewHttpTask();
                }
            }
        } catch (Exception e) {
            Util.printLog("Error while posting ad values");
        }
    }

    private void cancelNotification() {
        try {
            NotificationManager manager = (NotificationManager) getSystemService("notification");
            manager.cancel(999);
            Log.i("AirpushSDK", "Notification cleared.");
        } catch (Exception e) {
            Log.e("AirpushSDK", "Notification not cleared. " + e.getMessage());
        } catch (Throwable e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void exipryTimeAlarm(Context context, boolean cancel) {
        try {
            Intent intent = new Intent(context, (Class<?>) PushService.class);
            String action = INTENT_ACTION_CANCEL_NOTIFICATION + context.getPackageName();
            intent.setAction(action);
            PendingIntent pendingIntent = PendingIntent.getService(context, 0, intent, 268435456);
            AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
            long l = System.currentTimeMillis() + (Util.getExpiry_time() * 1000);
            alarmManager.set(0, l, pendingIntent);
            if (cancel) {
                alarmManager.cancel(pendingIntent);
                Util.printDebugLog("Expiry Alarm cancelled");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } catch (Throwable e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int getAppIcon(Context context) {
        try {
            PackageInfo p = context.getPackageManager().getPackageInfo(context.getPackageName(), 128);
            return p.applicationInfo.icon;
        } catch (Exception exception) {
            exception.printStackTrace();
            return 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int getNotificationXML(Context context) {
        try {
            Class<?> cls2 = Class.forName(context.getPackageName() + ".R$layout");
            return cls2.getField("airpush_notify").getInt(cls2);
        } catch (NoSuchFieldException e) {
            Log.e("AirpushSDK", "Required airpush_notify.xml file not found in layout folder. Please add.");
            Airpush.sendIntegrationError("Required airpush_notify.xml file not found in layout folder. Please add.");
            return 0;
        } catch (Exception exception) {
            exception.printStackTrace();
            return 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void startAirpush(final Context context) {
        PackageManager packageManager;
        List<ResolveInfo> list;
        try {
            packageManager = context.getPackageManager();
            Intent intent = new Intent(context, (Class<?>) PushService.class);
            list = packageManager.queryIntentServices(intent, 65536);
        } catch (Exception e) {
        }
        if (list.size() == 0) {
            Log.e("AirpushSDK", "Required PushService class is not declared in Manifest. Please add.");
            Airpush.sendIntegrationError("Required PushService class is not declared in Manifest. Please add.");
            return;
        }
        Intent intent1 = new Intent(context, (Class<?>) BootReceiver.class);
        List<ResolveInfo> list1 = packageManager.queryBroadcastReceivers(intent1, 0);
        if (list1.size() == 0) {
            Log.i("AirpushSDK", "BootReceiver is not declared in Manifest. Please add.");
            Airpush.sendIntegrationError("BootReceiver is not declared in Manifest. Please add.");
        } else {
            boolean permissionReceiveBootCompleted = context.checkCallingOrSelfPermission("android.permission.RECEIVE_BOOT_COMPLETED") == 0;
            if (!permissionReceiveBootCompleted) {
                Log.e("AirpushSDK", "Required permission android.permission.RECEIVE_BOOT_COMPLETED not added in Manifest, Please add.");
                Airpush.sendIntegrationError("Required permission android.permission.RECEIVE_BOOT_COMPLETED not added in Manifest, Please add.");
            }
        }
        if (Util.isDoPush()) {
            Log.i("AirpushSDK", "Push Notification...." + Util.isDoPush());
            if (getNotificationXML(context) != 0 && Airpush.checkRequiredPermission(context) && Airpush.getDataFromManifest(context)) {
                UserDetails details = new UserDetails(context);
                if (details.setImeiInMd5()) {
                    try {
                        new SetPreferences(context).setPreferencesData();
                        SetPreferences.getDataSharedPrefrences(context);
                        if (Util.isTestmode()) {
                            Log.i("AirpushSDK", "Notification is running in test mode.");
                        }
                        if (Airpush.isSDKEnabled(context)) {
                            Log.i("AirpushSDK", "Initialising push notification.....");
                            try {
                                Timer timer = new Timer(true);
                                timer.schedule(new TimerTask() { // from class: com.ncgftm.ganbgg136707.PushService.3
                                    @Override // java.util.TimerTask, java.lang.Runnable
                                    public void run() {
                                        Util.printDebugLog("Timer scheduled.");
                                        if (Util.checkInternetConnection(context)) {
                                            long startTime = SetPreferences.getSDKStartTime(context);
                                            if (startTime == 0) {
                                                Intent messageIntent = new Intent(context, (Class<?>) PushService.class);
                                                String action = PushService.INTENT_ACTION_SET_MESSAGE_RECEIVER + context.getPackageName();
                                                messageIntent.setAction(action);
                                                context.startService(messageIntent);
                                                return;
                                            }
                                            PushService.reStartSDK(context, true);
                                            return;
                                        }
                                        PushService.reStartSDK(context, false);
                                    }
                                }, 6000L);
                                return;
                            } catch (Exception e2) {
                                e2.printStackTrace();
                                reStartSDK(context, Util.checkInternetConnection(context));
                                return;
                            }
                        }
                        Log.i("AirpushSDK", "Airpush SDK is disabled, Please enable it to receive push ads.");
                        Airpush.sendAdError("Airpush SDK is disabled Please enable to recive ads.");
                        return;
                    } catch (Exception e3) {
                        Util.printLog("" + e3.getMessage());
                        return;
                    }
                }
                return;
            }
            return;
        }
        Log.i("AirpushSDK", "Push Notification is off.");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void reStartSDK(Context context, boolean connectivity) {
        long timeDifference = 0;
        if (connectivity) {
            long startTime = SetPreferences.getSDKStartTime(context);
            if (startTime != 0) {
                long currentTime = System.currentTimeMillis();
                if (currentTime < startTime) {
                    long diff = startTime - currentTime;
                    Log.i("AirpushSDK", "SDK will restart after " + diff + " ms.");
                    timeDifference = diff;
                    Util.printDebugLog("time difference : " + diff + " minutes");
                }
            }
        } else {
            timeDifference = random(gap_no_con);
            Log.i("AirpushSDK", "SDK will start after " + timeDifference + " ms.");
        }
        try {
            Intent messageIntent = new Intent(context, (Class<?>) PushService.class);
            String action = INTENT_ACTION_SET_MESSAGE_RECEIVER + context.getPackageName();
            messageIntent.setAction(action);
            PendingIntent pendingIntent = PendingIntent.getService(context, 0, messageIntent, 0);
            AlarmManager msgAlarmMgr = (AlarmManager) context.getSystemService("alarm");
            Calendar calendar = Calendar.getInstance();
            long triggerAtTime = calendar.getTimeInMillis() + timeDifference + IConstants.INTERVAL_FIRST_TIME.intValue() + delay_after_boot;
            msgAlarmMgr.setInexactRepeating(0, triggerAtTime, Util.getMessageIntervalTime(), pendingIntent);
            if (SetPreferences.isDeviceBlackListed(context)) {
                msgAlarmMgr.cancel(pendingIntent);
                System.out.println("Device blacklisted canceling next calls.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static long random(int[] array) {
        Random random = new Random();
        int i = random.nextInt(array.length - 1);
        return array[i] * 1000;
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override // android.app.Service, android.content.ComponentCallbacks
    public void onLowMemory() {
        super.onLowMemory();
        Log.e("AirpushSDK", "Low On Memory");
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        Log.i("AirpushSDK", "Service Finished");
    }
}
