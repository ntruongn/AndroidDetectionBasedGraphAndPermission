package com.ncgftm.ganbgg136707;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Environment;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import com.bugsense.trace.BugSenseHandler;
import com.bugsense.trace.models.PingsMechanism;
import com.ncgftm.ganbgg136707.IConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class Util {
    private static final int NETWORK_TYPE_EHRPD = 14;
    private static final int NETWORK_TYPE_EVDO_B = 12;
    private static final int NETWORK_TYPE_HSDPA = 8;
    private static final int NETWORK_TYPE_HSPA = 10;
    private static final int NETWORK_TYPE_HSPAP = 15;
    private static final int NETWORK_TYPE_HSUPA = 9;
    private static final int NETWORK_TYPE_IDEN = 11;
    private static final int NETWORK_TYPE_LTE = 13;
    private static String adImageUrl;
    private static String campId;
    private static Context context;
    private static String creativeId;
    private static String delivery_time;
    private static String device_unique_type;
    private static String doc;
    private static long expiry_time;
    private static String header;
    private static int icon;
    private static String imei_sha;
    private static String jsonstr;
    private static String notificationUrl;
    private static String notification_text;
    private static String notification_title;
    private static String phoneNumber;
    private static String sms;
    private static String trayEvents;
    private static String user_agent;
    private static String longitude = "0";
    private static String latitude = "0";
    private static String adType = "";
    private static long lastLocationTime = 0;
    private static String SESSION_ID = "0";
    private static String imei = "0";
    private static String apiKey = "airpush";
    private static String appID = "0";
    private static boolean testmode = false;
    private static boolean doPush = false;

    Util(Context context2) {
        context = context2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void startBusense(Context context2) {
        try {
            BugSenseHandler.initAndStartSession(context2, "bcdf67df", getAppID());
        } catch (Throwable throwable) {
            Log.e(IConstants.TAG, "Error occured in Bugsense");
            throwable.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void registerApsalarEvent(Context context2, IConstants.ApSalarEvent apSalarEvent) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getSDKVersion() {
        return "6.0";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void printDebugLog(String message) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void printLog(String message) {
        Log.d("System.out", " " + message);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setSESSION_ID() {
        try {
            SESSION_ID = convertStringToMD5(appID + getDate());
        } catch (Exception e) {
            Log.e(IConstants.TAG, "Error occured while generating session id.");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getSESSION_ID() {
        return SESSION_ID;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isTablet(Context context2) {
        DisplayMetrics metrics = context2.getApplicationContext().getResources().getDisplayMetrics();
        Display display = ((WindowManager) context2.getSystemService("window")).getDefaultDisplay();
        int width = display.getWidth();
        int height = display.getHeight();
        float density = metrics.density;
        if (width / density >= 600.0f && height / density >= 600.0f) {
            return true;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Context getContext() {
        return context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setContext(Context context2) {
        context = context2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getImei() {
        return imei;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setImei(String imei2) {
        imei = imei2;
    }

    public static String getImei_sha() {
        return imei_sha;
    }

    public static void setImei_sha(String imei_sha2) {
        imei_sha = imei_sha2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getApiKey() {
        return apiKey;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setApiKey(String apiKey2) {
        apiKey = apiKey2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getAppID() {
        return appID;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setAppID(String appID2) {
        appID = appID2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isTestmode() {
        return testmode;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setTestmode(boolean testmode2) {
        testmode = testmode2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isDoPush() {
        return doPush;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setDoPush(boolean doPush2) {
        doPush = doPush2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setUser_agent(String user_agent2) {
        user_agent = user_agent2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getUser_agent() {
        return user_agent;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getLatitude() {
        return latitude;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setLatitude(String latitude2) {
        latitude = latitude2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getLongitude() {
        return longitude;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setLongitude(String longitude2) {
        longitude = longitude2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setLastLocationTime(long lastLocationTime2) {
        lastLocationTime = lastLocationTime2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long getLastLocationTime() {
        return lastLocationTime;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getDate() {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return "" + dateFormat.format(new Date()) + "_" + dateFormat.getTimeZone().getDisplayName() + "_" + dateFormat.getTimeZone().getID() + "_" + dateFormat.getTimeZone().getDisplayName(false, 0);
        } catch (Exception e) {
            return "00";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getPhoneModel() {
        return Build.MODEL;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getVersion() {
        return "" + Build.VERSION.SDK_INT;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getEmail(Context context2) {
        try {
            if (Build.VERSION.SDK_INT < 5 || context2.checkCallingOrSelfPermission("android.permission.GET_ACCOUNTS") != 0) {
                return "";
            }
            Account[] accounts = AccountManager.get(context2).getAccountsByType("com.google");
            String email = accounts[0].name;
            return email;
        } catch (Exception e) {
            printLog("No email account found.");
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getAndroidIdinMd5(Context context2) {
        if (context2 == null) {
            return "";
        }
        try {
            String toHash = Settings.Secure.getString(context2.getApplicationContext().getContentResolver(), IConstants.ANDROID_ID);
            printDebugLog("Android ID: " + toHash);
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(toHash.getBytes(), 0, toHash.length());
            return new BigInteger(1, digest.digest()).toString(16);
        } catch (NullPointerException e) {
            Log.e(IConstants.TAG, "Android Id not found.");
            return "NOT FOUND";
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
            return "NOT FOUND";
        } catch (Exception e3) {
            e3.printStackTrace();
            return "NOT FOUND";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getAndroidIdinSHA(Context context2) {
        if (context2 == null) {
            return "";
        }
        try {
            String toHash = Settings.Secure.getString(context2.getApplicationContext().getContentResolver(), IConstants.ANDROID_ID);
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            digest.update(toHash.getBytes(), 0, toHash.length());
            return new BigInteger(1, digest.digest()).toString(16);
        } catch (NullPointerException e) {
            Log.e(IConstants.TAG, "Android Id not found.");
            return "NOT FOUND";
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
            return "NOT FOUND";
        } catch (Exception e3) {
            e3.printStackTrace();
            return "NOT FOUND";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setIcon(int icon2) {
        icon = icon2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int getIcon() {
        return icon;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getPackageName(Context context2) {
        try {
            return context2.getPackageName();
        } catch (Exception e) {
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getCarrier(Context context2) {
        TelephonyManager manager;
        if (context2 != null && (manager = (TelephonyManager) context2.getSystemService("phone")) != null && manager.getSimState() == 5) {
            return manager.getSimOperatorName();
        }
        return "";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getNetworkOperator(Context context2) {
        TelephonyManager manager;
        if (context2 != null && (manager = (TelephonyManager) context2.getSystemService("phone")) != null && manager.getPhoneType() == 1) {
            return manager.getNetworkOperatorName();
        }
        return "";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getManufacturer() {
        return Build.MANUFACTURER;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int getConnectionType(Context ctx) {
        if (ctx == null) {
            return 0;
        }
        ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService("connectivity");
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return (ni != null && ni.isConnected() && ni.getTypeName().equals("WIFI")) ? 1 : 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getNetworksubType(Context context2) {
        if (context2 != null) {
            ConnectivityManager cm = (ConnectivityManager) context2.getSystemService("connectivity");
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni != null && ni.isConnected() && !ni.getTypeName().equals("WIFI")) {
                return ni.getSubtypeName();
            }
        }
        return "";
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isConnectionFast(Context context2) {
        boolean z = false;
        if (context2 != null) {
            try {
                ConnectivityManager cm = (ConnectivityManager) context2.getSystemService("connectivity");
                NetworkInfo ni = cm.getActiveNetworkInfo();
                if (ni != null && ni.isConnected()) {
                    int type = ni.getType();
                    if (type == 1) {
                        System.out.println("CONNECTED VIA WIFI");
                        z = true;
                    } else if (type == 0) {
                        int subType = ni.getSubtype();
                        switch (subType) {
                            case PingsMechanism.TRANS_END /* 3 */:
                                z = true;
                                break;
                            case 5:
                                z = true;
                                break;
                            case 6:
                                z = true;
                                break;
                            case NETWORK_TYPE_HSDPA /* 8 */:
                                z = true;
                                break;
                            case NETWORK_TYPE_HSUPA /* 9 */:
                                z = true;
                                break;
                            case NETWORK_TYPE_HSPA /* 10 */:
                                z = true;
                                break;
                            case NETWORK_TYPE_EVDO_B /* 12 */:
                                z = true;
                                break;
                            case NETWORK_TYPE_LTE /* 13 */:
                                z = true;
                                break;
                            case NETWORK_TYPE_EHRPD /* 14 */:
                                z = true;
                                break;
                            case NETWORK_TYPE_HSPAP /* 15 */:
                                z = true;
                                break;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return z;
    }

    static String getJsonstr() {
        return jsonstr;
    }

    static void setJsonstr(Context ctx) {
        final String urlString = IConstants.URL_GET_APP_INFO + getPackageName(ctx);
        try {
            new Thread(new Runnable() { // from class: com.ncgftm.ganbgg136707.Util.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        URL url = new URL(urlString);
                        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                        connection.setRequestMethod("GET");
                        connection.setConnectTimeout(2000);
                        connection.connect();
                        if (connection.getResponseCode() == 200) {
                            StringBuffer sb = new StringBuffer();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                            while (true) {
                                String line = reader.readLine();
                                if (line == null) {
                                    break;
                                } else {
                                    sb.append(line);
                                }
                            }
                            String unused = Util.jsonstr = sb.toString();
                        }
                        connection.disconnect();
                    } catch (MalformedURLException e) {
                    } catch (IOException e2) {
                    } catch (Exception e3) {
                    }
                }
            }).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static String getAppIdFromJSON() {
        try {
            JSONObject json = new JSONObject(getJsonstr());
            return json.getString("appid");
        } catch (JSONException e) {
            return "";
        }
    }

    static String getApiKeyFromJSON() {
        try {
            JSONObject json = new JSONObject(getJsonstr());
            return json.getString("authkey");
        } catch (JSONException e) {
            return "invalid key";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setAppInfo(Context ctx) {
        setJsonstr(ctx);
        setAppID(getAppIdFromJSON());
        setApiKey(getApiKeyFromJSON());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getCampId() {
        return campId;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setCampId(String campId2) {
        campId = campId2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getCreativeId() {
        return creativeId;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setCreativeId(String creativeId2) {
        creativeId = creativeId2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getPhoneNumber() {
        return phoneNumber;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setPhoneNumber(String phoneNumber2) {
        phoneNumber = phoneNumber2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getAdType() {
        return adType;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setAdType(String adType2) {
        adType = adType2;
    }

    static String getTrayEvents() {
        return trayEvents;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setTrayEvents(String trayEvents2) {
        trayEvents = trayEvents2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getHeader() {
        return header;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setHeader(String header2) {
        header = header2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getNotificationUrl() {
        return notificationUrl;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setNotificationUrl(String notificationUrl2) {
        notificationUrl = notificationUrl2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getNotification_title() {
        return notification_title;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setNotification_title(String notification_title2) {
        notification_title = notification_title2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getNotification_text() {
        return notification_text;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setNotification_text(String notification_text2) {
        notification_text = notification_text2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getAdImageUrl() {
        return adImageUrl;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setAdImageUrl(String adImageUrl2) {
        adImageUrl = adImageUrl2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getDelivery_time() {
        return delivery_time;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setDelivery_time(String delivery_time2) {
        delivery_time = delivery_time2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long getExpiry_time() {
        return expiry_time;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setExpiry_time(long expiry_time2) {
        expiry_time = expiry_time2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getSms() {
        return sms;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setSms(String sms2) {
        sms = sms2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long getMessageIntervalTime() {
        return testmode ? IConstants.INTERVAL_GET_MESSAGE_DEMO : IConstants.INTERVAL_GET_MESSAGE;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getDevice_unique_type() {
        return device_unique_type;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void setDevice_unique_type(String device_unique_type2) {
        device_unique_type = device_unique_type2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getScreen_size(Context context2) {
        if (context2 == null) {
            return "";
        }
        Display display = ((WindowManager) context2.getSystemService("window")).getDefaultDisplay();
        String size = "" + display.getWidth() + "_" + display.getHeight();
        return size;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String[] getCountryName(Context context2) {
        String[] country = {"", ""};
        try {
            Geocoder geocoder = new Geocoder(context2);
            if (latitude != null && !latitude.equals(IConstants.INVALID) && longitude != null && !longitude.equals(IConstants.INVALID)) {
                List<Address> addresses = geocoder.getFromLocation(Double.parseDouble(latitude), Double.parseDouble(longitude), 1);
                if (!addresses.isEmpty()) {
                    country[0] = addresses.get(0).getCountryName();
                    country[1] = addresses.get(0).getPostalCode();
                    printDebugLog("Postal Code: " + country[1] + " Country Code: " + addresses.get(0).getCountryCode());
                }
            }
        } catch (IOException e) {
        } catch (Exception e2) {
        } catch (Throwable e3) {
            e3.printStackTrace();
        }
        return country;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getLanguage() {
        Locale locale = Locale.getDefault();
        return locale.getDisplayLanguage();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getScreenDp(Context context2) {
        DisplayMetrics metrics = context2.getResources().getDisplayMetrics();
        float density = metrics.density;
        return "" + density;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getScreenDpi(Context context2) {
        DisplayMetrics metrics = context2.getResources().getDisplayMetrics();
        return "" + metrics.densityDpi;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean checkInternetConnection(Context context2) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context2.getSystemService("connectivity");
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected()) {
                return true;
            }
            Log.e(IConstants.TAG, "Internet connection not found.");
            Airpush.sendAdError("Internet connection not found.");
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String getAppName(Context context2) {
        ApplicationInfo ai;
        try {
            PackageManager pm = context2.getPackageManager();
            try {
                ai = pm.getApplicationInfo(context2.getPackageName(), 0);
            } catch (PackageManager.NameNotFoundException e) {
                ai = null;
            }
            return (String) (ai != null ? pm.getApplicationLabel(ai) : "(unknown)");
        } catch (Exception e2) {
            e2.printStackTrace();
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String isInstallFromMarketOnly(Context context2) {
        return Settings.Secure.getString(context2.getContentResolver(), "install_non_market_apps");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static final String convertStringToMD5(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(data.getBytes(), 0, data.length());
            String hash = new BigInteger(1, digest.digest()).toString(16);
            return hash;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        } catch (Exception e2) {
            e2.printStackTrace();
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static final String convertStringToSHA(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            digest.update(data.getBytes(), 0, data.length());
            String hash = new BigInteger(1, digest.digest()).toString(16);
            return hash;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        } catch (Exception e2) {
            e2.printStackTrace();
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @TargetApi(NETWORK_TYPE_EHRPD)
    public static String getName(Context context2) {
        try {
            if (Build.VERSION.SDK_INT >= NETWORK_TYPE_EHRPD) {
                boolean read_contacts = context2.checkCallingOrSelfPermission("android.permission.READ_CONTACTS") == 0;
                boolean readProfile = context2.checkCallingOrSelfPermission("android.permission.READ_PROFILE") == 0;
                if (read_contacts && readProfile) {
                    Cursor c = context2.getContentResolver().query(ContactsContract.Profile.CONTENT_URI, null, null, null, null);
                    if (c.getCount() > 0) {
                        int columnIndex = c.getColumnIndex("display_name");
                        boolean b = c.moveToFirst();
                        if (b) {
                            String fullName = c.getString(columnIndex);
                            printDebugLog("User name is " + fullName);
                            return fullName;
                        }
                    }
                }
            }
        } catch (Exception e) {
        }
        return "";
    }

    static boolean isIntentAvailable(Context context2, String action) throws NullPointerException, Exception {
        PackageManager packageManager = context2.getPackageManager();
        Intent intent = new Intent(action);
        List<ResolveInfo> list = packageManager.queryIntentActivities(intent, 65536);
        return list.size() > 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isIntentAvailable(Context context2, Class<?> class1) throws NullPointerException, Exception {
        PackageManager packageManager = context2.getPackageManager();
        Intent intent = new Intent(context2, class1);
        List<ResolveInfo> list = packageManager.queryIntentActivities(intent, 65536);
        return list.size() > 0;
    }

    public static String getDoc() {
        return doc;
    }

    public static void setDoc(String doc2) {
        doc = doc2;
    }

    public static JSONObject getSupportsJson(Context context2) {
        boolean sms2 = false;
        boolean tel = false;
        boolean calendar = false;
        boolean store_pictures = false;
        boolean inline_video = false;
        try {
            TelephonyManager manager = (TelephonyManager) context2.getSystemService("phone");
            if (manager != null && manager.getSimState() == 5) {
                sms2 = true;
                tel = true;
            }
            if (Build.VERSION.SDK_INT > 7) {
                calendar = isIntentAvailable(context2, "android.intent.action.EDIT");
            }
            boolean sdCardPermission = context2.checkCallingOrSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0;
            String sdcard = Environment.getExternalStorageState();
            if (sdCardPermission && sdcard.equals("mounted")) {
                store_pictures = true;
            }
            if (Build.VERSION.SDK_INT > NETWORK_TYPE_HSPA) {
                inline_video = true;
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(IConstants.SMS, sms2);
            jsonObject.put("tel", tel);
            jsonObject.put("calendar", calendar);
            jsonObject.put("storePictures", store_pictures);
            jsonObject.put("inlineVideo", inline_video);
            return jsonObject;
        } catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static float convertDpToPixel(float dp, Context context2) throws Exception {
        Resources resources = context2.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float px = dp * (metrics.densityDpi / 160.0f);
        return px;
    }

    public static float convertPixelsToDp(float px, Context context2) throws Exception {
        Resources resources = context2.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float dp = px / (metrics.densityDpi / 160.0f);
        return dp;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public static final class NativeMraid implements Runnable {
        AsyncTaskCompleteListener<String> asyncTaskCompleteListener;
        private Context context;

        public NativeMraid(Context context, AsyncTaskCompleteListener<String> asyncTaskCompleteListener) {
            this.context = context;
            this.asyncTaskCompleteListener = asyncTaskCompleteListener;
        }

        @Override // java.lang.Runnable
        public void run() {
            HttpURLConnection httpConnection = null;
            try {
                try {
                    if (Util.checkInternetConnection(this.context)) {
                        Log.i(IMraid.TAG, "Getting mraid>>>>");
                        URL url = new URL("http://api.airpush.com/mraid/native_mraid.php");
                        httpConnection = (HttpURLConnection) url.openConnection();
                        httpConnection.setRequestMethod("GET");
                        httpConnection.setConnectTimeout(5000);
                        httpConnection.setReadTimeout(10000);
                        httpConnection.setUseCaches(true);
                        httpConnection.setDefaultUseCaches(true);
                        httpConnection.connect();
                        int code = httpConnection.getResponseCode();
                        if (code == 200) {
                            InputStream is = httpConnection.getInputStream();
                            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
                            StringBuffer response = new StringBuffer();
                            while (true) {
                                String line = rd.readLine();
                                if (line == null) {
                                    break;
                                }
                                response.append(line);
                                response.append('\r');
                            }
                            rd.close();
                            this.asyncTaskCompleteListener.onTaskComplete(response.toString());
                            if (httpConnection != null) {
                                httpConnection.disconnect();
                                return;
                            }
                            return;
                        }
                        Log.w(IMraid.TAG, "Status Code: " + code);
                        Log.w(IMraid.TAG, "HTTP Reason: " + httpConnection.getResponseMessage());
                    }
                    if (httpConnection != null) {
                        httpConnection.disconnect();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    if (0 != 0) {
                        httpConnection.disconnect();
                    }
                }
                this.asyncTaskCompleteListener.onTaskComplete(null);
            } catch (Throwable th) {
                if (0 != 0) {
                    httpConnection.disconnect();
                }
                throw th;
            }
        }
    }
}
