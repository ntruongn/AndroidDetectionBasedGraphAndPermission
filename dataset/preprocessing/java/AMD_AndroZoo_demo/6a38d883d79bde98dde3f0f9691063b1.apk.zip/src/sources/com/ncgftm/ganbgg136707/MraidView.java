package com.ncgftm.ganbgg136707;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.VideoView;
import com.ncgftm.ganbgg136707.AdCallbackListener;
import com.ncgftm.ganbgg136707.AdView;
import com.ncgftm.ganbgg136707.FormatAds;
import com.ncgftm.ganbgg136707.IConstants;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public final class MraidView extends WebView implements IMraid {
    static MraidView airpushMraidView;
    private AdCallbackListener.MraidCallbackListener adListener;
    private String adUrl;
    private AdView adView;
    private AdView.AnimationDrawListener animationDrawListener;
    private DisplayMetrics displayMetrics;
    private ExpandProperties expandProperties;
    private FrameLayout expandedFrameLayout;
    private Handler handler;
    private int height;
    private int heightDp;
    boolean isTestMode;
    private boolean isViewable;
    private MraidAdUtil mraidAdUtil;
    private ViewGroup parentViewGroup;
    private FormatAds.ParseMraidJson parseMraidJson;
    private String placementType;
    private float scale;
    private String state;
    private VideoView videoHolder;
    private int viewIndex;
    private boolean viewable;
    private int width;
    private int widthDp;

    @SuppressLint({"InlinedApi"})
    public MraidView(Context context, FormatAds.ParseMraidJson parseMraidJson, Handler handler) {
        super(context);
        this.isTestMode = false;
        try {
            try {
                if (Build.VERSION.SDK_INT >= 11 && (context instanceof Activity)) {
                    ((Activity) context).getWindow().setFlags(16777216, 16777216);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        } catch (Throwable th) {
        }
        this.adUrl = parseMraidJson.getAd_url();
        this.handler = handler;
        this.mraidAdUtil = new MraidAdUtil();
        this.displayMetrics = context.getResources().getDisplayMetrics();
        this.scale = this.displayMetrics.density;
        this.expandProperties = new ExpandProperties();
        this.parseMraidJson = parseMraidJson;
        initSettting();
    }

    @SuppressLint({"InlinedApi"})
    public MraidView(Context context, AdView adView, AdCallbackListener.MraidCallbackListener adListener, Handler handler, AdView.AnimationDrawListener animationDrawListener) {
        super(context);
        this.isTestMode = false;
        try {
            if (Build.VERSION.SDK_INT >= 11 && (getContext() instanceof Activity)) {
                ((Activity) getContext()).getWindow().setFlags(16777216, 16777216);
            }
        } catch (Throwable th) {
        }
        this.animationDrawListener = animationDrawListener;
        airpushMraidView = this;
        this.parseMraidJson = adView.parseMraidJson;
        this.adView = adView;
        this.adListener = adListener;
        this.handler = handler;
        this.adUrl = this.parseMraidJson.getAd_url();
        this.isTestMode = adView.isTestMode();
        this.mraidAdUtil = new MraidAdUtil();
        this.placementType = adView.getPlacementType();
        this.displayMetrics = context.getResources().getDisplayMetrics();
        this.scale = this.displayMetrics.density;
        if (this.placementType.equals("inline")) {
            this.width = this.displayMetrics.widthPixels;
            if (Util.isTablet(getContext())) {
                this.height = 90;
            } else {
                this.height = 60;
            }
        } else {
            this.width = this.displayMetrics.widthPixels;
            this.height = this.displayMetrics.heightPixels;
        }
        try {
            this.widthDp = (int) Util.convertPixelsToDp(this.width, getContext());
            this.heightDp = (int) Util.convertPixelsToDp(this.height, getContext());
        } catch (Exception e) {
            e.printStackTrace();
        }
        Util.printDebugLog("Device Width:" + this.width + ", Device Height:" + this.height);
        this.expandProperties = new ExpandProperties();
        initSettting();
        this.expandProperties.getProperties();
        int height = (int) (60.0f * this.scale);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, Util.isTablet(getContext()) ? (int) (90.0f * this.scale) : height);
        setLayoutParams(layoutParams);
    }

    @SuppressLint({"SetJavaScriptEnabled", "InlinedApi"})
    private void initSettting() {
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(this.width, this.height);
        setLayoutParams(layoutParams);
        setHorizontalScrollBarEnabled(false);
        setVerticalScrollBarEnabled(false);
        setScrollBarStyle(33554432);
        setBackgroundColor(0);
        setWebChromeClient(new AirpushWebChromeClient());
        WebSettings settings = getSettings();
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        settings.setCacheMode(2);
        settings.setLoadWithOverviewMode(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(false);
        settings.setJavaScriptEnabled(true);
        addJavascriptInterface(new JavaScriptInterface(), "airpush_mraid");
        if (Build.VERSION.SDK_INT >= 8) {
            settings.setPluginState(WebSettings.PluginState.ON);
        } else {
            settings.setPluginsEnabled(true);
        }
        setWebViewClient(new AirpuhWebViewClient());
        displayAd(this.adUrl);
        if (this.adListener != null) {
            this.adListener.onAdLoadingListener();
        }
    }

    void displayAd(String url) {
        injectJSCode(Util.getDoc());
        if (url != null && url.endsWith(".js")) {
            int lastIndex = url.lastIndexOf("/");
            String jsFile = url.substring(lastIndex, url.length() - 1);
            String baseUrl = url.substring(0, lastIndex - 1);
            loadDataWithBaseURL(baseUrl, "<html><head><script type=\"text/javascript\" src=\"" + jsFile + "\"/></head><body></body></html>", "text/html", "utf-8", null);
            return;
        }
        if (this.parseMraidJson.isInlineScript()) {
            if (this.parseMraidJson.getTag() != null && !this.parseMraidJson.getTag().equals("")) {
                loadDataWithBaseURL(null, this.parseMraidJson.getTag(), "text/html", "utf-8", null);
                return;
            } else {
                Log.e(IMraid.TAG, "Tag data is null");
                return;
            }
        }
        if (this.parseMraidJson.isJsAd()) {
            if (this.parseMraidJson.getTag() != null && !this.parseMraidJson.getTag().equals("")) {
                loadDataWithBaseURL(null, "<html><head><script type=\"text/javascript\" src=\"" + this.parseMraidJson.getTag() + "\"/></head><body></body></html>", "text/html", "utf-8", null);
                return;
            } else {
                Log.e(IMraid.TAG, "Tag data is null");
                return;
            }
        }
        if (this.parseMraidJson.isHtmlAd()) {
            if (this.parseMraidJson.getTag() != null && !this.parseMraidJson.getTag().equals("")) {
                loadDataWithBaseURL(null, "<html><head></head><body>" + this.parseMraidJson.getTag() + "</body></html>", "text/html", "utf-8", null);
                return;
            } else {
                Log.e(IMraid.TAG, "tag data is null");
                return;
            }
        }
        if (url != null && !url.equals("")) {
            loadUrl(url);
        } else {
            Log.e(IMraid.TAG, "Invalid url: " + url);
        }
    }

    void displayAD() {
        injectJSCode("mraid.setPlacementType('" + this.placementType + "')");
        Util.printDebugLog("SDK LOG: display Ad called.");
        injectJSCode("mraid.setExpandProperties(" + this.expandProperties.getProperties() + ");");
        checkVisibility();
        setState(IMraid.STATE_DEFAULT);
        triggerEvent(IMraid.EVENT_READY);
        if (this.handler != null) {
            this.handler.sendEmptyMessage(0);
            onAnimationEnd();
        }
        setDefaultPosition();
        Log.i(IMraid.TAG, "Sending impression data:>");
        sendEventData(IMraid.MRAID_EVENT_IMPRESSION);
    }

    private void checkVisibility() {
        boolean visible;
        if (this.isViewable && getVisibility() == 0) {
            visible = true;
        } else {
            visible = false;
        }
        if (visible != this.viewable && this.state == IMraid.STATE_DEFAULT) {
            this.viewable = visible;
            setViewable(this.viewable);
        }
    }

    @Override // android.webkit.WebView, android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.isViewable = true;
        checkVisibility();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.isViewable = false;
        checkVisibility();
    }

    @Override // android.view.View
    public void setVisibility(int visibility) {
        super.setVisibility(visibility);
        checkVisibility();
    }

    @Override // android.webkit.WebView
    public void loadUrl(String url) {
        Util.printDebugLog("Loading url: " + url);
        super.loadUrl(url);
    }

    @Override // android.webkit.WebView
    public void loadDataWithBaseURL(String baseUrl, String data, String mimeType, String encoding, String historyUrl) {
        super.loadDataWithBaseURL(baseUrl, data, mimeType, encoding, historyUrl);
        if (this.adListener != null) {
            this.adListener.onAdLoadingListener();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setDataInJs() {
        setScreenSize();
        setMaxSize();
        setSupportProperties();
        setCurrentPosition();
    }

    @Override // android.view.View
    protected void onAnimationEnd() {
        super.onAnimationEnd();
        if (this.animationDrawListener != null) {
            Util.printDebugLog("Animation end.");
            this.animationDrawListener.onAnimationDrawEnd();
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraidBridge
    public void expand(String url) {
        try {
            clearView();
            FrameLayout content = (FrameLayout) getRootView().findViewById(16908290);
            FrameLayout.LayoutParams adParams = new FrameLayout.LayoutParams(-1, -1);
            View placeholderView = new View(getContext());
            placeholderView.setLayoutParams(getLayoutParams());
            this.expandedFrameLayout = new FrameLayout(getContext());
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
            layoutParams.gravity = 17;
            this.expandedFrameLayout.setLayoutParams(layoutParams);
            this.parentViewGroup = (ViewGroup) getParent();
            if (this.parentViewGroup != null) {
                int count = this.parentViewGroup.getChildCount();
                int index = 0;
                while (index < count && this.parentViewGroup.getChildAt(index) != this) {
                    index++;
                }
                this.viewIndex = index;
                setLayoutParams(adParams);
                this.parentViewGroup.removeView(this);
                this.expandedFrameLayout.addView(this);
                if (!this.expandProperties.useCustomClose) {
                    Button close = addCloseButton(5);
                    close.setId(111);
                    FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(((int) this.scale) * 50, ((int) this.scale) * 50);
                    closeParams.gravity = 53;
                    close.setLayoutParams(closeParams);
                    this.expandedFrameLayout.addView(close);
                }
                content.addView(this.expandedFrameLayout);
                this.parentViewGroup.addView(placeholderView, this.viewIndex);
                this.parentViewGroup.setVisibility(8);
                setState(IMraid.STATE_EXPANDED);
                if (url != null && !url.equals("")) {
                    loadUrl(url);
                }
            }
            if (this.adListener != null) {
                this.adListener.onAdExpandedListner();
            }
            if (this.adView != null) {
                this.adView.canFetchAd = false;
            }
            sendEventData(IMraid.MRAID_EVENT_EXPAND);
            if (!this.isTestMode) {
                Util.registerApsalarEvent(getContext(), IConstants.ApSalarEvent.expand);
            }
        } catch (Exception e) {
            sendEventData(IMraid.MRAID_EVENT_ERROR);
            e.printStackTrace();
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraidBridge
    public void resize() {
        int width = this.displayMetrics.widthPixels;
        int height = this.displayMetrics.heightPixels;
        int offsetX = 0;
        int offsetY = 0;
        boolean allowOffscreen = true;
        int closeButtonGravity = 53;
        try {
            clearView();
            if (this.mraidAdUtil != null && !this.mraidAdUtil.getResizeProperties().equals("")) {
                try {
                    JSONObject jsonObject = new JSONObject(this.mraidAdUtil.getResizeProperties());
                    if (jsonObject.isNull(IMraid.WIDTH)) {
                        width = this.displayMetrics.widthPixels;
                    } else {
                        width = (int) Util.convertDpToPixel(jsonObject.getInt(IMraid.WIDTH), getContext());
                    }
                    if (jsonObject.isNull(IMraid.HEIGHT)) {
                        height = this.displayMetrics.heightPixels;
                    } else {
                        height = (int) Util.convertDpToPixel(jsonObject.getInt(IMraid.HEIGHT), getContext());
                    }
                    String customClosePosition = jsonObject.isNull(IMraid.CUSTOM_CLOSE_POSITION) ? IMraid.CUSTOM_CLOSE_POSITION_TOP_RIGHT : jsonObject.getString(IMraid.CUSTOM_CLOSE_POSITION);
                    offsetX = jsonObject.isNull(IMraid.OFF_SET_X) ? 0 : jsonObject.getInt(IMraid.OFF_SET_X);
                    offsetY = jsonObject.isNull(IMraid.OFF_SET_Y) ? 0 : jsonObject.getInt(IMraid.OFF_SET_Y);
                    allowOffscreen = jsonObject.isNull(IMraid.ALLOW_OFF_SCREEN) ? true : jsonObject.getBoolean(IMraid.ALLOW_OFF_SCREEN);
                    closeButtonGravity = this.mraidAdUtil.getGravity(customClosePosition);
                } catch (Exception e) {
                    if (this.adListener != null) {
                        this.adListener.onErrorListener(e.getMessage());
                    }
                    triggerErrorEvent("resize", "Error occured while parsing resizeProperties data.");
                    return;
                }
            }
            if (!allowOffscreen) {
                int[] size = checkSizeParams(width, height);
                width = size[0];
                height = size[1];
            }
            FrameLayout content = (FrameLayout) getRootView().findViewById(16908290);
            FrameLayout.LayoutParams adParams = new FrameLayout.LayoutParams(width, height);
            View placeholderView = new View(getContext());
            placeholderView.setLayoutParams(getLayoutParams());
            this.expandedFrameLayout = new FrameLayout(getContext());
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(width, height);
            layoutParams.leftMargin = offsetX;
            layoutParams.topMargin = offsetY;
            this.expandedFrameLayout.setLayoutParams(layoutParams);
            this.parentViewGroup = (ViewGroup) getParent();
            if (this.parentViewGroup != null) {
                int count = this.parentViewGroup.getChildCount();
                int index = 0;
                while (index < count && this.parentViewGroup.getChildAt(index) != this) {
                    index++;
                }
                this.viewIndex = index;
                setLayoutParams(adParams);
                this.parentViewGroup.removeView(this);
                this.expandedFrameLayout.addView(this);
                try {
                    LinearLayout ll = new LinearLayout(getContext());
                    FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams((int) (this.scale * 50.0f), (int) (this.scale * 50.0f));
                    closeParams.gravity = closeButtonGravity;
                    ll.setLayoutParams(closeParams);
                    ll.setGravity(closeButtonGravity);
                    this.expandedFrameLayout.addView(ll);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
                content.addView(this.expandedFrameLayout);
                this.parentViewGroup.addView(placeholderView, this.viewIndex);
                this.parentViewGroup.setVisibility(8);
                setState(IMraid.STATE_RESIZED);
                triggerEvent(IMraid.EVENT_SIZE_CHANGE);
            }
            if (this.adListener != null) {
                this.adListener.onAdExpandedListner();
            }
            if (this.adView != null) {
                this.adView.canFetchAd = false;
            }
            sendEventData(IMraid.MRAID_EVENT_RESIZE);
            if (!this.isTestMode) {
                Util.registerApsalarEvent(getContext(), IConstants.ApSalarEvent.resized);
            }
        } catch (Exception e3) {
            sendEventData(IMraid.MRAID_EVENT_ERROR);
            e3.printStackTrace();
        }
    }

    private int[] checkSizeParams(int width, int height) {
        if (width > this.width || height > this.height) {
            float ratio = height / width;
            int diffWidth = (int) ((width - this.width) * ratio);
            int diffHeight = (int) ((height - this.height) * ratio);
            if (diffWidth > diffHeight) {
                width = this.width;
                height = (int) (width * ratio);
            } else {
                height = this.width;
                width = (int) (height / ratio);
            }
        }
        return new int[]{width, height};
    }

    private void setButtonBackground(Button button) {
        if (button != null) {
            try {
                Class<?> cls = Class.forName("com.android.internal.R$drawable");
                int background = cls.getField("ic_menu_close_clear_cancel").getInt(cls);
                button.setBackgroundResource(background);
            } catch (Exception e) {
                button.setText("Close");
                button.setTypeface(null, 1);
                button.setBackgroundColor(0);
            }
        }
    }

    Button addCloseButton(int gravity) {
        Button button = new Button(getContext());
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams((int) (this.scale * 50.0f), (int) (this.scale * 50.0f));
        button.setGravity(gravity);
        button.setLayoutParams(layoutParams);
        setButtonBackground(button);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.ncgftm.ganbgg136707.MraidView.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                MraidView.this.close();
            }
        });
        return button;
    }

    @Override // com.ncgftm.ganbgg136707.IMraidBridge
    public void close() {
        try {
            if (this.adView != null) {
                this.adView.canFetchAd = true;
            }
            if (this.state.equals(IMraid.STATE_EXPANDED)) {
                if (this.expandedFrameLayout != null && this.parentViewGroup != null) {
                    ((ViewGroup) this.expandedFrameLayout.getParent()).removeView(this.expandedFrameLayout);
                    this.expandedFrameLayout.removeView(this);
                    setLayoutParams(this.parentViewGroup.getChildAt(this.viewIndex).getLayoutParams());
                    this.parentViewGroup.removeViewAt(this.viewIndex);
                    this.parentViewGroup.setVisibility(0);
                }
                setState(IMraid.STATE_DEFAULT);
                if (this.adView != null) {
                    this.adView.getAd();
                }
            } else if (this.state.equals(IMraid.STATE_DEFAULT)) {
                ((ViewGroup) getParent()).setVisibility(8);
                setState(IMraid.STATE_HIDDEN);
                if (this.handler != null) {
                    this.handler.sendEmptyMessage(-3);
                }
            } else if (this.state.equals(IMraid.STATE_RESIZED)) {
                if (this.expandedFrameLayout != null && this.parentViewGroup != null) {
                    ((ViewGroup) this.expandedFrameLayout.getParent()).removeView(this.expandedFrameLayout);
                    this.expandedFrameLayout.removeView(this);
                    setLayoutParams(this.parentViewGroup.getChildAt(this.viewIndex).getLayoutParams());
                    this.parentViewGroup.removeViewAt(this.viewIndex);
                    this.parentViewGroup.setVisibility(0);
                }
                setState(IMraid.STATE_DEFAULT);
                if (this.adView != null) {
                    this.adView.getAd();
                }
            } else {
                ((ViewGroup) getParent()).setVisibility(8);
                setState(IMraid.STATE_HIDDEN);
                if (this.handler != null) {
                    this.handler.sendEmptyMessage(-3);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (this.adListener != null) {
            this.adListener.onCloseListener();
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraidBridge
    public void createCalendarEvent(String jsonString) {
        canFetchAd(false);
        Util.printDebugLog("SDK LOG: inside createCalendarEvent: " + jsonString);
        if (this.adListener != null) {
            this.adListener.onAdClickListener();
        }
        if (jsonString != null) {
            try {
                if (!jsonString.equals("")) {
                    Intent intent = new Intent(getContext(), (Class<?>) BrowserActivity.class);
                    intent.setAction("newCalendarEvent");
                    intent.addFlags(268435456);
                    intent.addFlags(8388608);
                    intent.putExtra("json", jsonString);
                    getContext().startActivity(intent);
                }
            } catch (Exception e) {
                e.printStackTrace();
                sendEventData(IMraid.MRAID_EVENT_ERROR);
                triggerErrorEvent("createCalendarEvent", "Error occured in createCalenderEvent.");
                Log.e(IMraid.TAG, "Error occured in createCalenderEvent.");
                return;
            }
        }
        triggerErrorEvent("createCalendarEvent", "Calender method called with empty json.");
        Log.e(IMraid.TAG, "Error occured while creating calendar event.");
    }

    @Override // com.ncgftm.ganbgg136707.IMraidBridge
    public void playVideo(String url) {
        canFetchAd(false);
        try {
            if (this.adListener != null) {
                this.adListener.onAdClickListener();
            }
            Intent intent = new Intent(getContext(), (Class<?>) BrowserActivity.class);
            intent.setAction("playVideo");
            intent.putExtra(IConstants.NOTIFICATION_URL, url);
            intent.addFlags(8388608);
            intent.addFlags(268435456);
            getContext().startActivity(intent);
        } catch (Exception exception) {
            exception.printStackTrace();
            sendEventData(IMraid.MRAID_EVENT_ERROR);
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraidBridge
    public void storePicture(String imageURL, String fileNameWithExt) {
        canFetchAd(false);
        try {
            if (this.adListener != null) {
                this.adListener.onAdClickListener();
            }
            if (imageURL == null || imageURL.equals("")) {
                triggerErrorEvent("storePicture", "Image url is null.");
                return;
            }
            if (fileNameWithExt == null || fileNameWithExt.equals("")) {
                triggerErrorEvent("storePicture", "File name is null.");
                return;
            }
            if (getContext() instanceof Activity) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
                alertDialog.setMessage("This image will be added in gallery. Please confirm ?");
                alertDialog.setPositiveButton("Yes", new AnonymousClass2(imageURL, fileNameWithExt));
                alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() { // from class: com.ncgftm.ganbgg136707.MraidView.3
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        MraidView.this.triggerErrorEvent("storePicture", "User has canceled.");
                        if (MraidView.this.adListener != null) {
                            MraidView.this.adListener.onCloseListener();
                        }
                        MraidView.this.canFetchAd(true);
                    }
                });
                alertDialog.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.ncgftm.ganbgg136707.MraidView.4
                    @Override // android.content.DialogInterface.OnCancelListener
                    public void onCancel(DialogInterface dialog) {
                        dialog.dismiss();
                        MraidView.this.triggerErrorEvent("storePicture", "User has canceled.");
                        if (MraidView.this.adListener != null) {
                            MraidView.this.adListener.onCloseListener();
                        }
                        MraidView.this.canFetchAd(true);
                    }
                });
                alertDialog.setCancelable(false);
                alertDialog.show();
            }
        } catch (Exception e) {
            triggerErrorEvent("storePicture", "Error occured while storing picture.");
            sendEventData(IMraid.EVENT_ERROR);
            if (this.adListener != null) {
                this.adListener.onCloseListener();
            }
            canFetchAd(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.ncgftm.ganbgg136707.MraidView$2, reason: invalid class name */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public class AnonymousClass2 implements DialogInterface.OnClickListener {
        final /* synthetic */ String val$fileNameWithExt;
        final /* synthetic */ String val$imageURL;

        AnonymousClass2(String str, String str2) {
            this.val$imageURL = str;
            this.val$fileNameWithExt = str2;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            Thread thread = new Thread(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.2.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        URL myImageURL = new URL(AnonymousClass2.this.val$imageURL);
                        HttpURLConnection connection = (HttpURLConnection) myImageURL.openConnection();
                        connection.setDoInput(true);
                        connection.connect();
                        InputStream input = connection.getInputStream();
                        Bitmap myBitmap = BitmapFactory.decodeStream(input);
                        String dataDir = MraidView.this.getContext().getApplicationInfo().dataDir;
                        File file = new File(dataDir, AnonymousClass2.this.val$fileNameWithExt);
                        Log.i("TAG", "file: " + file.getAbsolutePath());
                        OutputStream fOut = new FileOutputStream(file);
                        myBitmap.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
                        fOut.flush();
                        fOut.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    String dataDir2 = MraidView.this.getContext().getApplicationInfo().dataDir + "/" + AnonymousClass2.this.val$fileNameWithExt;
                    try {
                        MediaStore.Images.Media.insertImage(MraidView.this.getContext().getContentResolver(), dataDir2, "My Image", AnonymousClass2.this.val$fileNameWithExt);
                        MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.2.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                MraidView.this.sendEventData(IMraid.MRAID_EVENT_STORE_PICTURE);
                                Log.i(IMraid.TAG, "Ad image is saved in Gallery.");
                                if (!MraidView.this.isTestMode) {
                                    Util.registerApsalarEvent(MraidView.this.getContext(), IConstants.ApSalarEvent.store_picture);
                                }
                                MraidView.this.canFetchAd(true);
                            }
                        });
                    } catch (FileNotFoundException e2) {
                        MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.2.1.2
                            @Override // java.lang.Runnable
                            public void run() {
                                MraidView.this.triggerErrorEvent("storePicture", "Url does not exist.");
                                MraidView.this.canFetchAd(true);
                            }
                        });
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.2.1.3
                            @Override // java.lang.Runnable
                            public void run() {
                                MraidView.this.triggerErrorEvent("storePicture", "Unknown error occured: " + e3.getMessage());
                                if (MraidView.this.adListener != null) {
                                    MraidView.this.adListener.onCloseListener();
                                }
                                MraidView.this.canFetchAd(true);
                            }
                        });
                        e3.printStackTrace();
                    }
                }
            });
            thread.start();
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void triggerEvent(String event) {
        injectJSCode("mraid.triggerEvent('" + event + "');");
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void triggerErrorEvent(String action, String msg) {
        injectJSCode("mraid.triggerErrorEvent(" + action + ",'" + msg + "');");
        if (!this.isTestMode) {
            sendEventData(IMraid.EVENT_ERROR);
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void setCurrentPosition() {
        try {
            int width = (int) Util.convertPixelsToDp(getWidth(), getContext());
            int height = (int) Util.convertPixelsToDp(getHeight(), getContext());
            int x = getLeft();
            if (Build.VERSION.SDK_INT > 10) {
                x = (int) getX();
            }
            int y = getTop();
            if (Build.VERSION.SDK_INT > 10) {
                y = (int) getY();
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("x", x);
            jsonObject.put("y", y);
            jsonObject.put(IMraid.WIDTH, width);
            jsonObject.put(IMraid.HEIGHT, height);
            injectJSCode("mraid.setCurrentPosition(" + jsonObject + ");");
        } catch (Exception exception) {
            triggerErrorEvent("setCurrentPosition", "Error occured while setting current position.");
            exception.printStackTrace();
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void setDefaultPosition() {
        try {
            int width = (int) Util.convertPixelsToDp(getWidth(), getContext());
            int height = (int) Util.convertPixelsToDp(getHeight(), getContext());
            int x = getLeft();
            if (Build.VERSION.SDK_INT > 10) {
                x = (int) getX();
            }
            int y = getTop();
            if (Build.VERSION.SDK_INT > 10) {
                y = (int) getY();
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("x", x);
            jsonObject.put("y", y);
            jsonObject.put(IMraid.WIDTH, width);
            jsonObject.put(IMraid.HEIGHT, height);
            injectJSCode("mraid.setDefaultPosition(" + jsonObject + ");");
        } catch (Exception exception) {
            triggerErrorEvent("setDefaultPosition", "Error occured while setting default position.");
            exception.printStackTrace();
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void setMaxSize() {
        try {
            int width = this.widthDp;
            int height = (int) Util.convertPixelsToDp(this.displayMetrics.heightPixels - getTokenSize(), getContext());
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(IMraid.WIDTH, width);
            jsonObject.put(IMraid.HEIGHT, height);
            injectJSCode("mraid.setMaxSize(" + jsonObject + ");");
        } catch (Exception exception) {
            triggerErrorEvent("setMaxSize", "Error occured while setting max size.");
            exception.printStackTrace();
        }
    }

    private int getTokenSize() {
        Rect rectgle = new Rect();
        Activity activity = (Activity) getContext();
        Window window = activity.getWindow();
        window.getDecorView().getWindowVisibleDisplayFrame(rectgle);
        int StatusBarHeight = rectgle.top;
        int contentViewTop = window.findViewById(16908290).getTop();
        int TitleBarHeight = contentViewTop - StatusBarHeight;
        Util.printDebugLog("StatusBar Height= " + StatusBarHeight + " , TitleBar Height = " + TitleBarHeight);
        return StatusBarHeight + TitleBarHeight;
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void setScreenSize() {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(IMraid.WIDTH, this.widthDp);
            jsonObject.put(IMraid.HEIGHT, this.heightDp);
            injectJSCode("mraid.setScreenSize(" + jsonObject + ");");
        } catch (Exception exception) {
            triggerErrorEvent("setScreenSize", "Error occured while setting screen size.");
            exception.printStackTrace();
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void setAdOrientation() {
        try {
            Activity activity = (Activity) getContext();
            String forceOrientation = this.mraidAdUtil.getForceOrientation();
            Configuration configuration = getResources().getConfiguration();
            boolean allowOrientationChange = this.mraidAdUtil.isOrientationChange();
            if (forceOrientation != null && forceOrientation.equals(IMraid.ORIENTATION_LANDSCAPE)) {
                activity.setRequestedOrientation(0);
                configuration.orientation = 2;
                activity.onConfigurationChanged(configuration);
                Util.printDebugLog("Orientation cahnged to landscape.");
            } else if (forceOrientation != null && forceOrientation.equals(IMraid.ORIENTATION_PORTRAIT)) {
                activity.setRequestedOrientation(1);
                Util.printDebugLog("Orientation changed to protrait.");
            } else if (forceOrientation != null && forceOrientation.equals(IMraid.ORIENTATION_NONE)) {
                activity.setRequestedOrientation(-1);
                Util.printDebugLog("Orientation changed to none.");
            }
            if (!allowOrientationChange) {
                int i = activity.getRequestedOrientation();
                activity.setRequestedOrientation(i);
                activity.onConfigurationChanged(configuration);
                Util.printDebugLog("Orientation changed to false.");
            }
            Util.printDebugLog("Orientation saved.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void setSupportProperties() {
        JSONObject jsonObject = Util.getSupportsJson(getContext());
        if (jsonObject != null) {
            injectJSCode("mraid.setSupportedFeatures(" + jsonObject + ");");
        } else {
            triggerErrorEvent("supports", "Error occured in supports.");
        }
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void injectJSCode(final String js_code) {
        post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.5
            @Override // java.lang.Runnable
            public void run() {
                MraidView.this.loadUrl("javascript:" + js_code);
            }
        });
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void setState(String state) {
        this.state = state;
        injectJSCode("mraid.setState('" + state + "');");
    }

    @Override // com.ncgftm.ganbgg136707.IMraid
    public void setViewable(boolean isViewable) {
        injectJSCode("mraid.setViewable(" + isViewable + ");");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public class ExpandProperties {
        boolean useCustomClose = false;

        ExpandProperties() {
        }

        String getProperties() {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put(IMraid.WIDTH, MraidView.this.widthDp);
                jsonObject.put(IMraid.HEIGHT, MraidView.this.heightDp);
                jsonObject.put(IMraid.USE_CUSTOM_CLOSE, this.useCustomClose);
                jsonObject.put(IMraid.IS_MODAL, true);
            } catch (JSONException exception) {
                exception.printStackTrace();
            }
            return jsonObject.toString();
        }

        void setProperties(String json) {
            int i;
            int i2;
            try {
                JSONObject jsonObject = new JSONObject(json);
                MraidView mraidView = MraidView.this;
                if (jsonObject.isNull(IMraid.WIDTH)) {
                    i = MraidView.this.widthDp;
                } else {
                    i = jsonObject.getInt(IMraid.WIDTH);
                }
                mraidView.width = i;
                MraidView mraidView2 = MraidView.this;
                if (jsonObject.isNull(IMraid.HEIGHT)) {
                    i2 = MraidView.this.heightDp;
                } else {
                    i2 = jsonObject.getInt(IMraid.HEIGHT);
                }
                mraidView2.height = i2;
                this.useCustomClose = jsonObject.isNull(IMraid.USE_CUSTOM_CLOSE) ? false : jsonObject.getBoolean(IMraid.USE_CUSTOM_CLOSE);
            } catch (JSONException exception) {
                exception.printStackTrace();
            } catch (Exception e) {
                MraidView.this.triggerErrorEvent("setExpandProperties", "An error occured while parsing expand properties json;");
            }
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public class JavaScriptInterface extends MraidJS {
        public JavaScriptInterface() {
        }

        @Override // com.ncgftm.ganbgg136707.MraidJS
        @JavascriptInterface
        public void printJSLog(String log) {
            Log.i(IMraid.TAG, "JS Log: " + log);
        }

        @JavascriptInterface
        public void expand() {
            expand("");
        }

        @Override // com.ncgftm.ganbgg136707.IMraidBridge
        @JavascriptInterface
        public void expand(final String url) {
            MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.JavaScriptInterface.1
                @Override // java.lang.Runnable
                public void run() {
                    MraidView.this.expand(url);
                }
            });
        }

        @Override // com.ncgftm.ganbgg136707.IMraidBridge
        @JavascriptInterface
        public void close() {
            MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.JavaScriptInterface.2
                @Override // java.lang.Runnable
                public void run() {
                    MraidView.this.close();
                }
            });
        }

        @Override // com.ncgftm.ganbgg136707.MraidJS
        @JavascriptInterface
        public void open(String url) {
            if (MraidView.this.adListener != null) {
                MraidView.this.adListener.onAdClickListener();
            }
            Intent intent = new Intent(MraidView.this.getContext(), (Class<?>) BrowserActivity.class);
            intent.setAction("browser");
            intent.addFlags(268435456);
            intent.addFlags(8388608);
            intent.putExtra(IConstants.NOTIFICATION_URL, url);
            try {
                MraidView.this.getContext().startActivity(intent);
                MraidView.this.sendEventData(IMraid.MRAID_EVENT_OPEN);
            } catch (ActivityNotFoundException e) {
                Log.e(IMraid.TAG, "Required BrowserActivty is not added in manifest please add.");
                if (MraidView.this.adListener != null) {
                    MraidView.this.adListener.onErrorListener("Required BrowserActivty is not added in manifest please add.");
                }
                MraidView.this.sendEventData(IMraid.MRAID_EVENT_ERROR);
            }
            MraidView.this.canFetchAd(true);
        }

        @Override // com.ncgftm.ganbgg136707.MraidJS
        @JavascriptInterface
        public void setExpandProperties(String json) {
            Util.printDebugLog("Expand Json: " + json);
            if (MraidView.this.expandProperties != null) {
                MraidView.this.expandProperties.setProperties(json);
                return;
            }
            MraidView.this.expandProperties = new ExpandProperties();
            MraidView.this.expandProperties.setProperties(json);
        }

        @Override // com.ncgftm.ganbgg136707.MraidJS
        @JavascriptInterface
        public void setResizeProperties(String properties) {
            if (MraidView.this.mraidAdUtil != null) {
                MraidView.this.mraidAdUtil.setResizeProperties(properties);
            }
        }

        @Override // com.ncgftm.ganbgg136707.IMraidBridge
        @JavascriptInterface
        public void resize() {
            MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.JavaScriptInterface.3
                @Override // java.lang.Runnable
                public void run() {
                    MraidView.this.resize();
                }
            });
        }

        @Override // com.ncgftm.ganbgg136707.IMraidBridge
        @JavascriptInterface
        public void playVideo(final String url) {
            MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.JavaScriptInterface.4
                @Override // java.lang.Runnable
                public void run() {
                    MraidView.this.playVideo(url);
                }
            });
        }

        @Override // com.ncgftm.ganbgg136707.IMraidBridge
        @JavascriptInterface
        public void storePicture(final String url, final String fileName) {
            MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.JavaScriptInterface.5
                @Override // java.lang.Runnable
                public void run() {
                    MraidView.this.storePicture(url, fileName);
                }
            });
        }

        @Override // com.ncgftm.ganbgg136707.IMraidBridge
        @JavascriptInterface
        public void createCalendarEvent(final String json) {
            MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.JavaScriptInterface.6
                @Override // java.lang.Runnable
                public void run() {
                    MraidView.this.createCalendarEvent(json);
                }
            });
        }

        @Override // com.ncgftm.ganbgg136707.MraidJS
        @JavascriptInterface
        public void setOrientationProperties(String json) {
            Util.printDebugLog("Orientation json: " + json);
            try {
                JSONObject jsonObject = new JSONObject(json);
                boolean allowOrientationChange = jsonObject.isNull(IMraid.ALLOW_ORIENTATION_CHANGE) ? true : jsonObject.getBoolean(IMraid.ALLOW_ORIENTATION_CHANGE);
                String forceOrientation = jsonObject.isNull(IMraid.FORCE_ORIENTATION) ? IMraid.ORIENTATION_NONE : jsonObject.getString(IMraid.FORCE_ORIENTATION);
                MraidView.this.mraidAdUtil.setForceOrientation(forceOrientation);
                MraidView.this.mraidAdUtil.setOrientationChange(allowOrientationChange);
                MraidView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.JavaScriptInterface.7
                    @Override // java.lang.Runnable
                    public void run() {
                        MraidView.this.setAdOrientation();
                    }
                });
            } catch (Exception e) {
                MraidView.this.triggerErrorEvent("setOrientationProperties", "Error occured in while parsing orientation json.");
            }
        }

        @Override // com.ncgftm.ganbgg136707.MraidJS
        @JavascriptInterface
        public void showDialer(String phoneNumber) {
            Log.i(IMraid.TAG, "Showing dialer.....");
            try {
                if (MraidView.this.adListener != null) {
                    MraidView.this.adListener.onAdClickListener();
                }
            } catch (ActivityNotFoundException e) {
                MraidView.this.triggerErrorEvent("showDialer", "Error occurred while dialing number.");
                Log.e(IMraid.TAG, "Error whlie displaying push ad......: " + e.getMessage());
                MraidView.this.sendEventData(IMraid.MRAID_EVENT_ERROR);
            }
            if (phoneNumber == null || phoneNumber.equals("")) {
                MraidView.this.triggerErrorEvent("showDialer", "Phone numer is null.");
                return;
            }
            Uri uri = Uri.parse("tel:" + phoneNumber);
            Intent intent = new Intent("android.intent.action.DIAL", uri);
            intent.addFlags(268435456);
            intent.addFlags(8388608);
            MraidView.this.getContext().startActivity(intent);
            MraidView.this.sendEventData(IMraid.MRAID_EVENT_TEL);
            if (!MraidView.this.isTestMode) {
                Util.registerApsalarEvent(MraidView.this.getContext(), IConstants.ApSalarEvent.tel);
            }
            MraidView.this.canFetchAd(true);
        }

        @Override // com.ncgftm.ganbgg136707.MraidJS
        @JavascriptInterface
        public void sendSms(String number, String sms_text) {
            Log.i(IMraid.TAG, "Sending SMS.....");
            try {
                if (MraidView.this.adListener != null) {
                    MraidView.this.adListener.onAdClickListener();
                }
            } catch (Exception e) {
                Log.e(IMraid.TAG, "Error whlie displaying push ad......: " + e.getMessage());
                MraidView.this.triggerErrorEvent("sendSms", "Error occurred while sending message");
                MraidView.this.sendEventData(IMraid.EVENT_ERROR);
            }
            if (number == null || number.equals("")) {
                MraidView.this.triggerErrorEvent("sendSms", "Numer is null.");
                return;
            }
            if (sms_text == null || sms_text.equals("")) {
                MraidView.this.triggerErrorEvent("sendSms", "SMS text is null.");
                return;
            }
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.addFlags(268435456);
            intent.setType("vnd.android-dir/mms-sms");
            intent.putExtra("address", number);
            intent.putExtra("sms_body", sms_text);
            MraidView.this.getContext().startActivity(intent);
            MraidView.this.sendEventData(IMraid.MRAID_EVENT_SMS);
            if (!MraidView.this.isTestMode) {
                Util.registerApsalarEvent(MraidView.this.getContext(), IConstants.ApSalarEvent.sms);
            }
            MraidView.this.canFetchAd(true);
        }

        @Override // com.ncgftm.ganbgg136707.MraidJS
        @JavascriptInterface
        public void downloadApp(String url) {
            try {
                if (MraidView.this.adListener != null) {
                    MraidView.this.adListener.onAdClickListener();
                }
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                intent.setFlags(268435456);
                intent.addFlags(8388608);
                MraidView.this.getContext().startActivity(intent);
                MraidView.this.sendEventData(IMraid.MRAID_EVENT_DOWNLOAD_APP);
                if (!MraidView.this.isTestMode) {
                    Util.registerApsalarEvent(MraidView.this.getContext(), IConstants.ApSalarEvent.app);
                }
            } catch (Exception e) {
                Log.e(IMraid.TAG, "Error whlie displaying App......: " + e.getMessage());
                MraidView.this.triggerErrorEvent("downloadApp", "Error occurred while redirecting to market.");
                MraidView.this.sendEventData(IMraid.EVENT_ERROR);
            }
            MraidView.this.canFetchAd(true);
        }

        @Override // com.ncgftm.ganbgg136707.MraidJS
        @JavascriptInterface
        public void showLocation(String latitude, String longitude) {
            try {
                if (MraidView.this.adListener != null) {
                    MraidView.this.adListener.onAdClickListener();
                }
                String url = String.format(Locale.ENGLISH, "geo:%f,%f", latitude, longitude);
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                intent.setFlags(268435456);
                intent.addFlags(8388608);
                MraidView.this.getContext().startActivity(intent);
                MraidView.this.sendEventData(IMraid.MRAID_EVENT_SHOW_LOCATION);
                if (!MraidView.this.isTestMode) {
                    Util.registerApsalarEvent(MraidView.this.getContext(), IConstants.ApSalarEvent.loc);
                }
            } catch (Exception e) {
                Log.e(IMraid.TAG, "Error occurred whlie displaying Location......: " + e.getMessage());
                MraidView.this.triggerErrorEvent("showLoaction", "Error occurred while showing location.");
                MraidView.this.sendEventData(IMraid.EVENT_ERROR);
            }
            MraidView.this.canFetchAd(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public class AirpuhWebViewClient extends WebViewClient {
        boolean isErrorOccured = false;

        AirpuhWebViewClient() {
        }

        @Override // android.webkit.WebViewClient
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (!this.isErrorOccured) {
                if (MraidView.this.state == null || (MraidView.this.state != IMraid.STATE_EXPANDED && MraidView.this.state != IMraid.STATE_RESIZED)) {
                    MraidView.this.displayAD();
                }
                if (MraidView.this.adListener != null) {
                    MraidView.this.adListener.onAdLoadedListener();
                }
                MraidView.this.setDataInJs();
            }
        }

        @Override // android.webkit.WebViewClient
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            this.isErrorOccured = true;
            super.onReceivedError(view, errorCode, description, failingUrl);
            if (MraidView.this.adListener != null) {
                MraidView.this.adListener.onErrorListener(description);
            }
            if (MraidView.this.handler != null) {
                MraidView.this.handler.sendEmptyMessage(-4);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public class AirpushWebChromeClient extends WebChromeClient {
        private AirpushWebChromeClient() {
        }

        @Override // android.webkit.WebChromeClient
        public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
            super.onShowCustomView(view, callback);
            if (view instanceof FrameLayout) {
                FrameLayout frame = (FrameLayout) view;
                if (frame.getFocusedChild() instanceof VideoView) {
                    MraidView.this.videoHolder = (VideoView) ((FrameLayout) view).getFocusedChild();
                    frame.removeView(MraidView.this.videoHolder);
                    ((ViewGroup) MraidView.this.getParent()).addView(MraidView.this.videoHolder);
                    MraidView.this.videoHolder.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.ncgftm.ganbgg136707.MraidView.AirpushWebChromeClient.1
                        @Override // android.media.MediaPlayer.OnCompletionListener
                        public void onCompletion(MediaPlayer player) {
                            try {
                                player.stop();
                                MraidView.this.sendEventData(IMraid.MRAID_EVENT_INLINE_VIDEO);
                                if (!MraidView.this.isTestMode) {
                                    Util.registerApsalarEvent(MraidView.this.getContext(), IConstants.ApSalarEvent.inline_video);
                                }
                                MraidView.this.canFetchAd(true);
                            } catch (Exception e) {
                            }
                        }
                    });
                    MraidView.this.videoHolder.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.ncgftm.ganbgg136707.MraidView.AirpushWebChromeClient.2
                        @Override // android.media.MediaPlayer.OnErrorListener
                        public boolean onError(MediaPlayer mp, int what, int extra) {
                            MraidView.this.sendEventData(IMraid.MRAID_EVENT_ERROR);
                            MraidView.this.canFetchAd(true);
                            return false;
                        }
                    });
                    MraidView.this.videoHolder.start();
                    MraidView.this.canFetchAd(false);
                }
            }
        }

        @Override // android.webkit.WebChromeClient
        public void onHideCustomView() {
            if (MraidView.this.videoHolder != null) {
                ((ViewGroup) MraidView.this.getParent()).removeView(MraidView.this.videoHolder);
                if (MraidView.this.videoHolder.isPlaying()) {
                    MraidView.this.videoHolder.stopPlayback();
                }
            }
            MraidView.this.canFetchAd(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void sendEventData(final String event) {
        synchronized (event) {
            if (this.isTestMode) {
                Util.printDebugLog("Ad in test mode. Sending ignored.");
            } else if (Util.checkInternetConnection(getContext())) {
                Thread thread = new Thread(new Runnable() { // from class: com.ncgftm.ganbgg136707.MraidView.6
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            Log.i(IMraid.TAG, "Sending event: ");
                            if (MraidView.this.parseMraidJson.isErrorReporting() || !event.equals(IMraid.MRAID_EVENT_ERROR)) {
                                String imp_url = MraidView.this.parseMraidJson.getImpression_url();
                                if (imp_url.contains("%event%")) {
                                    imp_url = imp_url.replace("%event%", event);
                                }
                                Util.printDebugLog("URL: " + imp_url);
                                HttpClient httpclient = new DefaultHttpClient();
                                HttpPost httppost = new HttpPost(imp_url);
                                BasicHttpParams basicHttpParams = new BasicHttpParams();
                                httppost.setParams(basicHttpParams);
                                HttpConnectionParams.setConnectionTimeout(basicHttpParams, 15000);
                                HttpConnectionParams.setSoTimeout(basicHttpParams, 10000);
                                HttpResponse response = httpclient.execute(httppost);
                                int code = response == null ? 0 : response.getStatusLine().getStatusCode();
                                Log.i(IMraid.TAG, "Status code: " + code);
                                if (code == 200) {
                                    String string = EntityUtils.toString(response.getEntity());
                                    Log.i(IMraid.TAG, "MRAID Data: " + string);
                                    return;
                                }
                                return;
                            }
                            Util.printDebugLog("Error reporting is off.");
                        } catch (Exception e) {
                            Log.e(IMraid.TAG, "Exception: " + e.getMessage());
                            e.printStackTrace();
                        }
                    }
                }, "mraid_event");
                thread.start();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void canFetchAd(boolean canFetchAd) {
        if (this.adView != null) {
            if (canFetchAd && this.state != null && (!this.state.equalsIgnoreCase(IMraid.STATE_EXPANDED) || !this.state.equalsIgnoreCase(IMraid.STATE_RESIZED))) {
                this.adView.canFetchAd = true;
                if (this.placementType != null && this.placementType.equals("inline") && this.adView != null) {
                    this.adView.getAd();
                    return;
                }
                return;
            }
            this.adView.canFetchAd = false;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public static class MraidAdUtil {
        private String expandProperties;
        private String forceOrientation;
        private boolean orientationChange;
        private String resizeProperties = "";
        private boolean useCustomClose = false;

        public String getResizeProperties() {
            return this.resizeProperties;
        }

        public void setResizeProperties(String resizeProperties) {
            this.resizeProperties = resizeProperties;
        }

        public String getExpandProperties() {
            return this.expandProperties;
        }

        public void setExpandProperties(String expandProperties) {
            this.expandProperties = expandProperties;
        }

        public String getForceOrientation() {
            return this.forceOrientation;
        }

        public void setForceOrientation(String forceOrientation) {
            this.forceOrientation = forceOrientation;
        }

        public void setOrientationChange(boolean orientationChange) {
            this.orientationChange = orientationChange;
        }

        public boolean isOrientationChange() {
            return this.orientationChange;
        }

        public void setUseCustomClose(boolean useCustomClose) {
            this.useCustomClose = useCustomClose;
        }

        public boolean isUseCustomClose() {
            return this.useCustomClose;
        }

        public int getGravity(String position) {
            if (position.equals(IMraid.CUSTOM_CLOSE_POSITION_TOP_RIGHT)) {
                return 53;
            }
            if (position.equals(IMraid.CUSTOM_CLOSE_POSITION_BOTTOM_CENTER)) {
                return 81;
            }
            if (position.equals(IMraid.CUSTOM_CLOSE_POSITION_BOTTOM_LEFT)) {
                return 83;
            }
            if (position.equals(IMraid.CUSTOM_CLOSE_POSITION_BOTTOM_RIGHT)) {
                return 85;
            }
            if (position.equals(IMraid.CUSTOM_CLOSE_POSITION_CENTER)) {
                return 17;
            }
            if (position.equals(IMraid.CUSTOM_CLOSE_POSITION_TOP_CENTER)) {
                return 49;
            }
            if (position.equals(IMraid.CUSTOM_CLOSE_POSITION_TOP_LEFT)) {
                return 51;
            }
            return 53;
        }
    }
}
