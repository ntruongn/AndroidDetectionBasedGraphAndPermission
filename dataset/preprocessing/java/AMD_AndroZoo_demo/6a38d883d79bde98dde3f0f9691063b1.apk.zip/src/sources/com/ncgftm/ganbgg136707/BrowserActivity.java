package com.ncgftm.ganbgg136707;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.CookieSyncManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.ncgftm.ganbgg136707.IConstants;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class BrowserActivity extends Activity implements View.OnClickListener {
    private static final int BUTTON_BACK_ID = 11;
    private static final int BUTTON_CLOSE_ID = 14;
    private static final int BUTTON_FORWARD_ID = 12;
    private static final int BUTTON_REFRESH_ID = 13;
    static final int CALENDER_CREATE_EVENT_REQUEST_CODE = 7;
    static final String INTENT_ACTION_BROWSE = "browser";
    static final String INTENT_ACTION_CREATE_CALENDAR_EVENT = "newCalendarEvent";
    static final String INTENT_ACTION_PLAY_VIDEO = "playVideo";
    private Button backButton;
    private Button closeButton;
    private Button forwardButton;
    private LinearLayout fullScreenLayout;
    Handler handler = new Handler() { // from class: com.ncgftm.ganbgg136707.BrowserActivity.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case -3:
                    BrowserActivity.this.finish();
                    return;
                case -2:
                case -1:
                default:
                    return;
                case 0:
                    BrowserActivity.this.setContentView(BrowserActivity.this.mraidView);
                    BrowserActivity.this.mraidView.setVisibility(0);
                    Toast.makeText(BrowserActivity.this, "Ad is showing on screen.", 0).show();
                    return;
            }
        }
    };
    private MraidView mraidView;
    private Button refreshButton;
    private float scale;
    private BrowserView webView;

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:19:0x00be -> B:10:0x003a). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00e2 -> B:10:0x003a). Please submit an issue!!! */
    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            try {
                Intent intent = getIntent();
                String action = intent.getAction();
                if (action.equals(INTENT_ACTION_BROWSE)) {
                    String url = intent.getStringExtra(IConstants.NOTIFICATION_URL);
                    if (url.startsWith("market://") || url.startsWith("tel:")) {
                        Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse(url));
                        startActivity(intent2);
                        finish();
                    } else {
                        showBrowser(url);
                    }
                } else if (action.equals(INTENT_ACTION_PLAY_VIDEO)) {
                    String url2 = intent.getStringExtra(IConstants.NOTIFICATION_URL);
                    requestWindowFeature(1);
                    setTheme(16973840);
                    super.onCreate(savedInstanceState);
                    Intent intent1 = new Intent("android.intent.action.VIEW", Uri.parse(url2));
                    intent1.setDataAndType(Uri.parse(url2), "video/*");
                    startActivityForResult(intent1, 8);
                } else if (action.equals(INTENT_ACTION_CREATE_CALENDAR_EVENT)) {
                    requestWindowFeature(1);
                    setTheme(16973840);
                    super.onCreate(savedInstanceState);
                    try {
                        String json = intent.getStringExtra("json");
                        if (json == null || json.equals("")) {
                            MraidView.airpushMraidView.triggerErrorEvent("createCalendarEvent", "Calendar json is empty");
                            MraidView.airpushMraidView.canFetchAd(true);
                            finish();
                        } else {
                            CalendarEvent.createCalenderEvent(this, json);
                        }
                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                        MraidView.airpushMraidView.sendEventData(IMraid.EVENT_ERROR);
                        MraidView.airpushMraidView.triggerErrorEvent("createCalendarEvent", "Calendar activity not found.");
                        MraidView.airpushMraidView.canFetchAd(true);
                        finish();
                    } catch (Exception exception) {
                        MraidView.airpushMraidView.sendEventData(IMraid.EVENT_ERROR);
                        exception.printStackTrace();
                        MraidView.airpushMraidView.triggerErrorEvent("createCalendarEvent", "Calendar json parsing error");
                        MraidView.airpushMraidView.canFetchAd(true);
                        finish();
                    }
                }
            } catch (Exception exception2) {
                exception2.printStackTrace();
                finish();
            }
        } catch (Throwable e2) {
            e2.printStackTrace();
            finish();
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == CALENDER_CREATE_EVENT_REQUEST_CODE) {
                if (resultCode == -1) {
                    Util.printDebugLog("Calender event added");
                    MraidView.airpushMraidView.sendEventData(IMraid.MRAID_EVENT_CREATE_CALENDER);
                    MraidView.airpushMraidView.canFetchAd(true);
                    if (!MraidView.airpushMraidView.isTestMode) {
                        Util.registerApsalarEvent(getApplicationContext(), IConstants.ApSalarEvent.calander_event);
                    }
                    finish();
                } else if (resultCode == 0) {
                    MraidView.airpushMraidView.canFetchAd(true);
                    MraidView.airpushMraidView.triggerErrorEvent("createCalendarEvent", "Creating calendar event canceled by user.");
                    finish();
                } else {
                    finish();
                }
            }
            if (requestCode == 8) {
                if (resultCode == -1) {
                    Util.printDebugLog("Video played added");
                    MraidView.airpushMraidView.sendEventData(IMraid.MRAID_EVENT_PLAY_VIDEO);
                    MraidView.airpushMraidView.canFetchAd(true);
                    if (!MraidView.airpushMraidView.isTestMode) {
                        Util.registerApsalarEvent(getApplicationContext(), IConstants.ApSalarEvent.play_video);
                    }
                    finish();
                    return;
                }
                if (resultCode == 0) {
                    MraidView.airpushMraidView.canFetchAd(true);
                    MraidView.airpushMraidView.triggerErrorEvent(INTENT_ACTION_PLAY_VIDEO, "Play video is canceled by user.");
                    finish();
                    return;
                }
                finish();
            }
        } catch (Exception e) {
        }
    }

    private void showBrowser(String url) {
        requestWindowFeature(2);
        this.scale = getResources().getDisplayMetrics().density;
        if (url != null) {
            try {
                if (!url.equals("")) {
                    buildLayout(url);
                }
            } catch (Exception e) {
                e.printStackTrace();
                finish();
                return;
            }
        }
        Log.i(IConstants.TAG, "Url is null.");
        finish();
    }

    private void buildLayout(String url) {
        this.fullScreenLayout = new LinearLayout(this);
        this.fullScreenLayout.setOrientation(1);
        this.fullScreenLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        RelativeLayout buttonLayout = new RelativeLayout(this);
        RelativeLayout.LayoutParams buttonLayoutParams = new RelativeLayout.LayoutParams(-1, (int) (40.0f * this.scale));
        buttonLayout.setLayoutParams(buttonLayoutParams);
        this.backButton = new Button(this);
        RelativeLayout.LayoutParams backParams = new RelativeLayout.LayoutParams(-2, -2);
        backParams.addRule(9, -1);
        backParams.addRule(15, -1);
        this.backButton.setLayoutParams(backParams);
        this.backButton.setText("Back");
        this.backButton.setTypeface(null, 1);
        this.backButton.setTextColor(-1);
        this.backButton.setId(BUTTON_BACK_ID);
        buttonLayout.addView(this.backButton);
        this.forwardButton = new Button(this);
        RelativeLayout.LayoutParams forwardParams = new RelativeLayout.LayoutParams(-2, -2);
        forwardParams.addRule(1, BUTTON_BACK_ID);
        forwardParams.addRule(15, -1);
        this.forwardButton.setLayoutParams(forwardParams);
        this.forwardButton.setText("Forward");
        this.forwardButton.setTypeface(null, 1);
        this.forwardButton.setTextColor(-1);
        this.forwardButton.setId(BUTTON_FORWARD_ID);
        buttonLayout.addView(this.forwardButton);
        this.refreshButton = new Button(this);
        RelativeLayout.LayoutParams refreshParams = new RelativeLayout.LayoutParams(-2, -2);
        refreshParams.addRule(1, BUTTON_FORWARD_ID);
        refreshParams.addRule(15, -1);
        this.refreshButton.setLayoutParams(refreshParams);
        this.refreshButton.setText("Refresh");
        this.refreshButton.setTypeface(null, 1);
        this.refreshButton.setTextColor(-1);
        this.refreshButton.setId(BUTTON_REFRESH_ID);
        buttonLayout.addView(this.refreshButton);
        this.closeButton = new Button(this);
        RelativeLayout.LayoutParams closeParams = new RelativeLayout.LayoutParams(-2, -2);
        closeParams.addRule(BUTTON_BACK_ID, -1);
        closeParams.addRule(15, -1);
        this.closeButton.setLayoutParams(closeParams);
        this.closeButton.setText("Close");
        this.closeButton.setTypeface(null, 1);
        this.closeButton.setTextColor(-1);
        this.closeButton.setId(BUTTON_CLOSE_ID);
        buttonLayout.addView(this.closeButton);
        buttonLayout.setGravity(17);
        this.fullScreenLayout.addView(buttonLayout);
        this.webView = new BrowserView(this, url);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        this.webView.setLayoutParams(layoutParams);
        this.fullScreenLayout.addView(this.webView);
        setContentView(this.fullScreenLayout);
        this.webView.loadUrl(url);
        this.backButton.setOnClickListener(this);
        this.forwardButton.setOnClickListener(this);
        this.refreshButton.setOnClickListener(this);
        this.closeButton.setOnClickListener(this);
        this.forwardButton.setEnabled(false);
        this.backButton.setEnabled(false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public class BrowserView extends WebView {
        @SuppressLint({"SetJavaScriptEnabled"})
        public BrowserView(Context context, String url) {
            super(context);
            setHorizontalScrollBarEnabled(false);
            setVerticalScrollBarEnabled(false);
            setScrollBarStyle(33554432);
            setBackgroundColor(0);
            CookieSyncManager.createInstance(BrowserActivity.this);
            CookieSyncManager.getInstance().startSync();
            getSettings().setJavaScriptEnabled(true);
            setWebChromeClient(new WebChromeClient() { // from class: com.ncgftm.ganbgg136707.BrowserActivity.BrowserView.1
                @Override // android.webkit.WebChromeClient
                public void onProgressChanged(WebView view, int progress) {
                    r3.setTitle("loading....");
                    r3.setProgress(progress * 100);
                    if (progress == 100) {
                        r3.setTitle(view.getUrl());
                    }
                }
            });
            setWebViewClient(new WebViewClient() { // from class: com.ncgftm.ganbgg136707.BrowserActivity.BrowserView.2
                @Override // android.webkit.WebViewClient
                public void onPageFinished(WebView view, String url2) {
                    super.onPageFinished(view, url2);
                    if ((view != null) & view.canGoBack()) {
                        BrowserActivity.this.backButton.setEnabled(true);
                    } else {
                        BrowserActivity.this.backButton.setEnabled(false);
                    }
                    if ((view != null) & view.canGoForward()) {
                        BrowserActivity.this.forwardButton.setEnabled(true);
                    } else {
                        BrowserActivity.this.forwardButton.setEnabled(false);
                    }
                }

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView view, String url2) {
                    if (!url2.startsWith("market://")) {
                        return super.shouldOverrideUrlLoading(view, url2);
                    }
                    view.loadUrl(url2);
                    return true;
                }

                @Override // android.webkit.WebViewClient
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    super.onReceivedError(view, errorCode, description, failingUrl);
                    Log.i(IConstants.TAG, "Error code: " + errorCode + " ,description: " + description);
                    try {
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(failingUrl));
                        BrowserActivity.this.startActivity(intent);
                        BrowserActivity.this.finish();
                    } catch (Exception e) {
                    }
                }
            });
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case BUTTON_BACK_ID /* 11 */:
                if (this.webView != null && this.webView.canGoBack()) {
                    this.webView.goBack();
                    return;
                }
                return;
            case BUTTON_FORWARD_ID /* 12 */:
                if (this.webView != null && this.webView.canGoForward()) {
                    this.webView.goForward();
                    return;
                }
                return;
            case BUTTON_REFRESH_ID /* 13 */:
                if (this.webView != null) {
                    this.webView.reload();
                    return;
                }
                return;
            case BUTTON_CLOSE_ID /* 14 */:
                finish();
                return;
            default:
                return;
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Window window = getWindow();
        window.setFormat(1);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        try {
            CookieSyncManager.getInstance().stopSync();
        } catch (Exception e) {
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        try {
            CookieSyncManager.getInstance().startSync();
        } catch (Exception e) {
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        try {
            if (this.webView != null) {
                this.webView.stopLoading();
                this.fullScreenLayout.removeView(this.webView);
                this.webView.removeAllViews();
                this.webView.destroy();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        try {
            if (getIntent().getAction().equals(INTENT_ACTION_PLAY_VIDEO)) {
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onBackPressed();
    }
}
