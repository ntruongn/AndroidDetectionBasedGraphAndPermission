package com.ncgftm.ganbgg136707;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import com.bugsense.trace.models.PingsMechanism;
import com.ncgftm.ganbgg136707.AdCallbackListener;
import com.ncgftm.ganbgg136707.FormatAds;
import com.ncgftm.ganbgg136707.IConstants;
import com.ncgftm.ganbgg136707.Util;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class AdView extends FrameLayout {
    static final String AD_TYPE_BACC = "BACC";
    static final String AD_TYPE_BACM = "BACM";
    static final String AD_TYPE_BAU = "BAU";
    public static final String ANIMATION_TYPE_FADE = "fade";
    public static final String ANIMATION_TYPE_LEFT_TO_RIGHT = "left_to_right";
    public static final String ANIMATION_TYPE_TOP_DOWN = "top_down";
    static final int BACKGROUND_COLOR_DEFAULT = 0;
    static final int BANNER_HEIGHT_MOBILE = 60;
    static final int BANNER_HEIGHT_TABLET = 90;
    static final int BANNER_MEDIUM_RECTANGLE_HEIGHT = 250;
    static final int BANNER_MEDIUM_RECTANGLE_WIDTH = 300;
    public static final String BANNER_TYPE_IMAGE = "image";
    public static final String BANNER_TYPE_IN_APP_AD = "inappad";
    public static final String BANNER_TYPE_MEDIUM_RECTANGLE = "medium_rectangle";
    public static final String BANNER_TYPE_RICH_MEDIA = "rich_media";
    static final String BANNER_TYPE_TEXT = "text";
    static final int BANNER_WIDTH_MOBILE = 468;
    static final int BANNER_WIDTH_TABLET = 728;
    public static final String PLACEMENT_TYPE_INLINE = "inline";
    public static final String PLACEMENT_TYPE_INTERSTITIAL = "interstitial";
    static final int REFRESH_AD = 45;
    static final int TEXT_COLOR_DEFAULT = -1;
    static AdCallbackListener.MraidCallbackListener adListener;
    private final String TAG;
    private int adRefreshTime;
    private Thread adThread;
    private AnimationDrawListener animationDrawListener;
    private FormatAds.ParseBannerAd bannerAd;
    private String bannerAnimation;
    private Drawable bannerBgDrawable;
    private String banner_type;
    boolean canFetchAd;
    private boolean canShowMR;
    boolean debug;
    AsyncTaskCompleteListener<String> getDoc;
    Handler handler;
    private int height;
    private int heightDp;
    private boolean isAdRequestInProgress;
    private boolean isAnyIssue;
    private boolean isTestMode;
    private long lastAdfetchedTime;
    private List<View> oldViews;
    FormatAds.ParseMraidJson parseMraidJson;
    private String placementType;
    private Timer timer;
    private int width;
    private int widthDp;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public interface AnimationDrawListener {
        void onAnimationDrawEnd();
    }

    public AdView(Activity activity, String banner_type, String placementType, int adRefreshTime, boolean isTestMode, boolean canShowMRInAPP, String animationForBanner) {
        super(activity);
        this.TAG = IMraid.TAG;
        this.debug = false;
        this.isAnyIssue = false;
        this.isTestMode = false;
        this.adRefreshTime = REFRESH_AD;
        this.isAdRequestInProgress = false;
        this.lastAdfetchedTime = 0L;
        this.canFetchAd = true;
        this.width = 468;
        this.height = 60;
        this.oldViews = new ArrayList();
        this.bannerAnimation = "fade";
        this.banner_type = BANNER_TYPE_IN_APP_AD;
        this.canShowMR = false;
        this.animationDrawListener = new AnimationDrawListener() { // from class: com.ncgftm.ganbgg136707.AdView.1
            @Override // com.ncgftm.ganbgg136707.AdView.AnimationDrawListener
            public void onAnimationDrawEnd() {
                AdView.this.handler.sendEmptyMessage(2);
            }
        };
        this.handler = new Handler() { // from class: com.ncgftm.ganbgg136707.AdView.2
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 0:
                        AdView.this.setVisibility(0);
                        return;
                    case 1:
                    case PingsMechanism.TRANS_END /* 3 */:
                    case 5:
                    case 6:
                    case 7:
                    default:
                        return;
                    case 2:
                        AdView.this.removeOldViews();
                        return;
                    case 4:
                        AdView.this.setVisibility(4);
                        return;
                    case 8:
                        AdView.this.setVisibility(8);
                        return;
                }
            }
        };
        this.getDoc = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.AdView.8
            @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
            public void onTaskComplete(final String result) {
                try {
                    AdView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.AdView.8.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (result != null && !result.equals("")) {
                                Util.setDoc(result);
                                AdView.this.loadRichMediaAd();
                            } else {
                                Log.e(IMraid.TAG, "Not able to get mraid.");
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
            public void launchNewHttpTask() {
                Util.NativeMraid mraid = new Util.NativeMraid(AdView.this.getContext(), this);
                new Thread(mraid, "native_mraid").start();
            }
        };
        this.isTestMode = isTestMode;
        if (banner_type != null && (banner_type.equals(BANNER_TYPE_IMAGE) || banner_type.equals(BANNER_TYPE_TEXT) || banner_type.equals("rich_media") || banner_type.equals(BANNER_TYPE_MEDIUM_RECTANGLE) || banner_type.equals(BANNER_TYPE_IN_APP_AD))) {
            this.banner_type = banner_type;
            Log.i(IMraid.TAG, "Banner Type: " + banner_type);
        } else {
            this.banner_type = BANNER_TYPE_IN_APP_AD;
            Log.e(IMraid.TAG, "Invalid banner type. Setting to default: inappad");
        }
        if (this.banner_type != null && this.banner_type.equals("rich_media")) {
            if (placementType != null && (placementType.equals("inline") || placementType.equals("interstitial"))) {
                this.placementType = placementType;
            } else {
                this.placementType = "inline";
                Log.e(IMraid.TAG, "Invalid placement type. Setting to default: inline");
            }
        }
        if (adRefreshTime >= REFRESH_AD) {
            this.adRefreshTime = adRefreshTime;
        } else {
            this.adRefreshTime = REFRESH_AD;
            Log.e(IMraid.TAG, "Refresh interval must be higher than 45");
        }
        this.canShowMR = canShowMRInAPP;
        if (animationForBanner != null) {
            this.bannerAnimation = animationForBanner;
        } else {
            this.bannerAnimation = "fade";
        }
        Log.i(IMraid.TAG, "Initializing AdView ");
        if (!Airpush.getDataFromManifest(activity) || !Airpush.checkRequiredPermission(activity)) {
            this.isAnyIssue = true;
            return;
        }
        try {
            if (!Util.isIntentAvailable(activity, (Class<?>) BrowserActivity.class)) {
                Log.e(IMraid.TAG, "Required BrowserActivty not found in Manifest please add.");
                this.isAnyIssue = true;
                return;
            }
        } catch (Exception e) {
        }
        setVisibility(8);
        UserDetails userDetails = new UserDetails(activity);
        if (!userDetails.setImeiInMd5()) {
            if (adListener != null) {
                adListener.onErrorListener("Can not serve ad on this device. Device details not found.");
            }
            this.isAnyIssue = true;
            return;
        }
        new SetPreferences(activity).setPreferencesData();
        this.bannerBgDrawable = getBackground();
        setClickable(true);
        setFocusable(true);
        setDescendantFocusability(131072);
        if (this.adThread == null || !this.adThread.isAlive()) {
            getAd();
        }
        Util.startBusense(activity);
    }

    public AdView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.TAG = IMraid.TAG;
        this.debug = false;
        this.isAnyIssue = false;
        this.isTestMode = false;
        this.adRefreshTime = REFRESH_AD;
        this.isAdRequestInProgress = false;
        this.lastAdfetchedTime = 0L;
        this.canFetchAd = true;
        this.width = 468;
        this.height = 60;
        this.oldViews = new ArrayList();
        this.bannerAnimation = "fade";
        this.banner_type = BANNER_TYPE_IN_APP_AD;
        this.canShowMR = false;
        this.animationDrawListener = new AnimationDrawListener() { // from class: com.ncgftm.ganbgg136707.AdView.1
            @Override // com.ncgftm.ganbgg136707.AdView.AnimationDrawListener
            public void onAnimationDrawEnd() {
                AdView.this.handler.sendEmptyMessage(2);
            }
        };
        this.handler = new Handler() { // from class: com.ncgftm.ganbgg136707.AdView.2
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 0:
                        AdView.this.setVisibility(0);
                        return;
                    case 1:
                    case PingsMechanism.TRANS_END /* 3 */:
                    case 5:
                    case 6:
                    case 7:
                    default:
                        return;
                    case 2:
                        AdView.this.removeOldViews();
                        return;
                    case 4:
                        AdView.this.setVisibility(4);
                        return;
                    case 8:
                        AdView.this.setVisibility(8);
                        return;
                }
            }
        };
        this.getDoc = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.AdView.8
            @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
            public void onTaskComplete(final String result) {
                try {
                    AdView.this.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.AdView.8.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (result != null && !result.equals("")) {
                                Util.setDoc(result);
                                AdView.this.loadRichMediaAd();
                            } else {
                                Log.e(IMraid.TAG, "Not able to get mraid.");
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
            public void launchNewHttpTask() {
                Util.NativeMraid mraid = new Util.NativeMraid(AdView.this.getContext(), this);
                new Thread(mraid, "native_mraid").start();
            }
        };
        Log.i(IMraid.TAG, "Initializing AdView from xml");
        if (attributeSet == null) {
            if (adListener != null) {
                adListener.onErrorListener("AttributeSet can not be null. If you are creating layout from dynamic code then use the other consturctor.");
            }
            Log.e(IMraid.TAG, "AttributeSet can not be null. If you are creating layout from dynamic code then use the other consturctor.");
            this.isAnyIssue = true;
            return;
        }
        if (!Airpush.getDataFromManifest(context) || !Airpush.checkRequiredPermission(context)) {
            this.isAnyIssue = true;
            return;
        }
        setVisibility(8);
        try {
            if (!Util.isIntentAvailable(context, (Class<?>) BrowserActivity.class)) {
                Log.e(IMraid.TAG, "Required BrowserActivty not found in Manifest please add.");
                if (adListener != null) {
                    adListener.onErrorListener("Required BrowserActivty not found in Manifest please add.");
                }
                this.isAnyIssue = true;
                return;
            }
        } catch (Exception e) {
        }
        UserDetails userDetails = new UserDetails(context);
        if (!userDetails.setImeiInMd5()) {
            if (adListener != null) {
                adListener.onErrorListener("Can not serve ad on this device. Device details not found.");
            }
            this.isAnyIssue = true;
            return;
        }
        new SetPreferences(context).setPreferencesData();
        this.bannerBgDrawable = getBackground();
        setClickable(true);
        setFocusable(true);
        setDescendantFocusability(131072);
        getAttrParameters(attributeSet);
        if (this.adThread == null || !this.adThread.isAlive()) {
            getAd();
        }
        Util.startBusense(context);
    }

    private void getAttrParameters(AttributeSet attributeSet) {
        try {
            if (attributeSet != null) {
                this.isTestMode = attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res-auto", "test_mode", false);
                this.adRefreshTime = attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res-auto", "refresh_time", REFRESH_AD);
                String banner_type = attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "banner_type");
                if (banner_type != null && (banner_type.equals(BANNER_TYPE_IMAGE) || banner_type.equals("rich_media") || banner_type.equals(BANNER_TYPE_MEDIUM_RECTANGLE) || banner_type.equals(BANNER_TYPE_IN_APP_AD))) {
                    this.banner_type = banner_type;
                    Log.i(IMraid.TAG, "Banner Type: " + banner_type);
                } else {
                    this.banner_type = BANNER_TYPE_IN_APP_AD;
                    Log.w(IMraid.TAG, "Invalid banner type. Setting to default: inappad");
                }
                if (banner_type != null && banner_type.equals("rich_media")) {
                    if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", IMraid.PLACEMENT_TYPE) != null) {
                        this.placementType = attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", IMraid.PLACEMENT_TYPE);
                    } else {
                        Log.w(IMraid.TAG, "Invalid placement type. Setting to default placementType: inline.");
                        this.placementType = "inline";
                    }
                }
                if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "animation") != null) {
                    this.bannerAnimation = attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "animation");
                } else {
                    this.bannerAnimation = "fade";
                }
                this.canShowMR = attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res-auto", "canShowMediumRectangle", false);
            } else {
                Util.printDebugLog("AttributeSet is null. Using default parameters");
                this.banner_type = BANNER_TYPE_IN_APP_AD;
                this.canShowMR = false;
                this.bannerAnimation = "fade";
                this.adRefreshTime = REFRESH_AD;
                this.placementType = "inline";
                this.isTestMode = false;
            }
            if (this.adRefreshTime < REFRESH_AD) {
                this.adRefreshTime = REFRESH_AD;
                Util.printDebugLog("Refresh interval must be higher than 45");
                if (adListener != null) {
                    adListener.onErrorListener("Refresh interval must be higher than 45");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadRichMediaAd() {
        try {
            setBackGround();
            if (this.parseMraidJson != null) {
                if (this.parseMraidJson.isHtmlAd() || this.parseMraidJson.isInlineScript() || this.parseMraidJson.isJsAd()) {
                    if (this.parseMraidJson.getTag() == null || this.parseMraidJson.equals("")) {
                        Log.i(IMraid.TAG, "Tag data is null");
                        return;
                    }
                } else if (this.parseMraidJson.getAd_url() == null || this.parseMraidJson.equals("")) {
                    Log.i(IMraid.TAG, "Ad url is null");
                    return;
                }
                Log.i(IMraid.TAG, "Loading Mraid ad..");
                MraidView view = new MraidView(getContext(), this, adListener, this.handler, this.animationDrawListener);
                int childViewCounter = getChildCount();
                if (childViewCounter > 0) {
                    for (int i = 0; i < childViewCounter; i++) {
                        if (getChildAt(i) != null) {
                            this.oldViews.add(getChildAt(i));
                        }
                    }
                }
                addView(view);
                return;
            }
            removeAllViews();
            setVisibility(8);
            Log.i(IMraid.TAG, "Ad not loaded. Mraid data is null.");
            if (adListener != null) {
                adListener.onErrorListener("Ad not loaded. Url is null.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadBannerAd() {
        try {
            setBackGround();
            if (this.bannerAd != null) {
                if (this.bannerAd.isHtmlAd() || this.bannerAd.isInlineScript() || this.bannerAd.isJsAd() || this.bannerAd.isPlainUrl()) {
                    if (this.bannerAd.getTag().equals("")) {
                        Log.i(IMraid.TAG, "Tag data is null");
                        return;
                    }
                } else if (this.bannerAd.getAdimage() == null || this.bannerAd.getAdimage().equals("")) {
                    Log.i(IMraid.TAG, "image url is null");
                    return;
                }
                Log.i(IMraid.TAG, "Loading banner ad");
                ImageBanner imageView = new ImageBanner(getContext().getApplicationContext(), this.widthDp, this.heightDp, this.handler, this.bannerAd, this.animationDrawListener, this.isTestMode, this);
                animateOldViews();
                addView(imageView);
                Animation animation = createAnimation(false);
                if (animation != null) {
                    imageView.startAnimation(animation);
                }
                Log.i(IMraid.TAG, "Ad loaded successfully");
                if (adListener != null) {
                    adListener.onAdLoadedListener();
                    return;
                }
                return;
            }
            removeAllViews();
            Log.i(IMraid.TAG, "Ad not loaded. Banner data is null.");
            setVisibility(8);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized void getAd() {
        if (!this.canFetchAd || this.debug) {
            Util.printDebugLog("Ad request is disabled.");
        } else if (this.isAdRequestInProgress) {
            Log.i(IMraid.TAG, "Ad request is already in progress.");
            if (adListener != null) {
                post(new Runnable() { // from class: com.ncgftm.ganbgg136707.AdView.3
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.adListener.onErrorListener("Another ad request is already in progress. Please wait...");
                    }
                });
            }
        } else if (System.currentTimeMillis() - this.lastAdfetchedTime < this.adRefreshTime) {
            Log.i(IMraid.TAG, "Ad requested beforing refresh time. Aborting request... ");
            if (adListener != null) {
                post(new Runnable() { // from class: com.ncgftm.ganbgg136707.AdView.4
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.adListener.onErrorListener("Ad requested beforing refresh time. Aborting request... ");
                    }
                });
            }
        } else {
            synchronized (this) {
                AsyncTaskCompleteListener<String> taskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.AdView.5
                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    public void launchNewHttpTask() {
                        String url;
                        AdView.this.isAdRequestInProgress = true;
                        if (AdView.this.banner_type == null || !AdView.this.banner_type.equals("rich_media")) {
                            if (AdView.this.banner_type != null && AdView.this.banner_type.equals(AdView.BANNER_TYPE_IN_APP_AD)) {
                                url = IConstants.URL_IN_APP_AD_API;
                                if (AdView.this.isTestMode) {
                                    url = IConstants.URL_IN_APP_AD_TEST_API;
                                }
                            } else {
                                url = IConstants.URL_BANNER_API;
                                if (AdView.this.isTestMode) {
                                    url = IConstants.URL_BANNER_TEST_API;
                                }
                            }
                        } else {
                            url = IConstants.URL_MRAID_API;
                            if (AdView.this.isTestMode) {
                                url = IConstants.URL_MRAID_TEST_API;
                            }
                        }
                        List<NameValuePair> list = new ArrayList<>();
                        list.add(new BasicNameValuePair("banner_type", AdView.this.banner_type));
                        list.add(new BasicNameValuePair("supports", "" + Util.getSupportsJson(AdView.this.getContext())));
                        list.add(new BasicNameValuePair("placement_type", "" + AdView.this.placementType));
                        list.add(new BasicNameValuePair("canShowMR", String.valueOf(AdView.this.canShowMR)));
                        NetworkThread networkThread = new NetworkThread(AdView.this.getContext(), this, list, url, 0L, true);
                        AdView.this.adThread = new Thread(networkThread, "AdView");
                        AdView.this.adThread.start();
                    }

                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    public void onTaskComplete(String result) {
                        try {
                            Log.i(IMraid.TAG, "Ad json:" + result);
                            AdView.this.lastAdfetchedTime = System.currentTimeMillis();
                            if (result != null && !result.equals("")) {
                                JSONObject jsonObject = new JSONObject(result);
                                String jsonBannerType = jsonObject.isNull("banner_type") ? "" : jsonObject.getString("banner_type");
                                if (jsonBannerType == null || jsonBannerType.equals("")) {
                                    Log.i(IMraid.TAG, "No banner type present in response.");
                                    return;
                                }
                                if (AdView.this.banner_type.equals(AdView.BANNER_TYPE_IN_APP_AD)) {
                                    if (jsonBannerType.equals("rich_media")) {
                                        String adtype = jsonObject.getString(IConstants.AD_TYPE);
                                        if (adtype.equals("MIT")) {
                                            AdView.this.placementType = "interstitial";
                                        } else {
                                            if (!adtype.equals("MIN")) {
                                                Log.i(IMraid.TAG, "Invalid placement type for rich media.");
                                                return;
                                            }
                                            AdView.this.placementType = "inline";
                                        }
                                        AdView.this.parseMraidJson(AdView.this.getContext(), jsonObject);
                                    } else if (jsonBannerType.equals(AdView.BANNER_TYPE_IMAGE) || jsonBannerType.equals(AdView.BANNER_TYPE_TEXT)) {
                                        AdView.this.parseBannerAd(jsonObject);
                                    } else if (!jsonBannerType.equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE)) {
                                        Log.i(IMraid.TAG, "Invalid banner type in inappad json: " + jsonBannerType);
                                    } else if (AdView.this.canShowMR) {
                                        AdView.this.parseBannerAd(jsonObject);
                                    } else {
                                        Log.w(IMraid.TAG, "Can not show this ad.");
                                    }
                                } else if (AdView.this.banner_type.equals("rich_media")) {
                                    AdView.this.parseMraidJson(AdView.this.getContext(), jsonObject);
                                } else if (AdView.this.banner_type.equals(AdView.BANNER_TYPE_IMAGE) || AdView.this.banner_type.equals(AdView.BANNER_TYPE_TEXT) || AdView.this.banner_type.equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE)) {
                                    AdView.this.parseBannerAd(jsonObject);
                                } else {
                                    Log.i(IMraid.TAG, "Invalid banner type in json: " + jsonBannerType);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            AdView.this.isAdRequestInProgress = false;
                        }
                    }
                };
                if (Util.checkInternetConnection(getContext())) {
                    taskCompleteListener.launchNewHttpTask();
                } else if (adListener != null) {
                    adListener.onErrorListener("Ad request failed. Internet connection not found.");
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void parseMraidJson(Context context, JSONObject result) {
        try {
            this.parseMraidJson = new FormatAds.ParseMraidJson(getContext(), result);
            if (this.adRefreshTime == REFRESH_AD && this.parseMraidJson.getRefreshTime() > REFRESH_AD) {
                Log.i(IMraid.TAG, "Refresh time changed.");
                this.adRefreshTime = this.parseMraidJson.getRefreshTime();
            }
            if (Util.getDoc() != null && !Util.getDoc().equals("")) {
                this.handler.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.AdView.6
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.this.loadRichMediaAd();
                    }
                });
            } else if (Util.checkInternetConnection(getContext())) {
                this.getDoc.launchNewHttpTask();
            }
        } catch (IOException e) {
            Log.e(IMraid.TAG, "" + e.getMessage());
        } catch (JSONException e2) {
            Log.e(IMraid.TAG, "JSONExection occured while parsing MRAID json: " + e2.getMessage());
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        if (!this.isTestMode) {
            Util.registerApsalarEvent(getContext(), IConstants.ApSalarEvent.rich_media_call);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void parseBannerAd(JSONObject jsonObject) {
        try {
            String bt = jsonObject.getString("banner_type");
            resizeBanner(bt);
            this.bannerAd = new FormatAds.ParseBannerAd();
            if (this.bannerAd.isParseBannerAd(getContext(), jsonObject, this.banner_type)) {
                this.handler.post(new Runnable() { // from class: com.ncgftm.ganbgg136707.AdView.7
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.this.loadBannerAd();
                    }
                });
                if (this.adRefreshTime == REFRESH_AD && this.bannerAd.getRefreshTime() > REFRESH_AD) {
                    Log.i(IMraid.TAG, "Refresh time changed.");
                    this.adRefreshTime = this.bannerAd.getRefreshTime();
                }
                if (!this.isTestMode) {
                    Util.registerApsalarEvent(getContext(), IConstants.ApSalarEvent.banner_ad_call);
                }
            }
        } catch (JSONException e) {
            Log.e(IMraid.TAG, "JSONExection occured while parsing Banner ad json: " + e.getMessage());
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @Override // android.view.View
    public void setVisibility(int visibility) {
        int parentVisibility = super.getVisibility();
        if (parentVisibility != visibility) {
            synchronized (this) {
                int childViewCounter = getChildCount();
                for (int i = 0; i < childViewCounter; i++) {
                    View child = getChildAt(i);
                    child.setVisibility(visibility);
                }
                super.setVisibility(visibility);
            }
        }
    }

    @Override // android.view.View
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        actionOnViewChanges(hasWindowFocus);
        super.onWindowFocusChanged(hasWindowFocus);
        getParent();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        actionOnViewChanges(false);
        super.onAttachedToWindow();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        actionOnViewChanges(false);
        super.onDetachedFromWindow();
    }

    private void actionOnViewChanges(boolean isViewable) {
        synchronized (this) {
            try {
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (!this.isAnyIssue) {
                if (isViewable) {
                    if (this.timer == null) {
                        this.timer = new Timer();
                        TimerTask task = new TimerTask() { // from class: com.ncgftm.ganbgg136707.AdView.9
                            @Override // java.util.TimerTask, java.lang.Runnable
                            public void run() {
                                Util.printDebugLog("Getting new ad....");
                                AdView.this.getAd();
                            }
                        };
                        this.timer.scheduleAtFixedRate(task, this.adRefreshTime * 1000, this.adRefreshTime * 1000);
                    }
                } else if (this.timer != null) {
                    this.timer.cancel();
                    this.timer = null;
                    Log.i(IMraid.TAG, "Lost foucus. Removing thread>>>");
                    this.canFetchAd = true;
                }
            }
        }
    }

    private void animateOldViews() {
        int childViewCounter = getChildCount();
        if (childViewCounter > 0) {
            Animation animation = createAnimation(true);
            for (int i = 0; i < childViewCounter; i++) {
                if (animation != null && getChildAt(i) != null) {
                    getChildAt(i).setAnimation(animation);
                    this.oldViews.add(getChildAt(i));
                }
            }
        }
    }

    private Animation createAnimation(boolean isOutAnimation) {
        if (isOutAnimation) {
            if (this.bannerAnimation != null && this.bannerAnimation.equals("fade")) {
                Animation animation = new AlphaAnimation(1.0f, 0.0f);
                animation.setDuration(700L);
                return animation;
            }
            if (this.bannerAnimation != null && this.bannerAnimation.equals("left_to_right")) {
                Animation animation2 = new TranslateAnimation(2, 0.0f, 2, 1.0f, 2, 0.0f, 2, 0.0f);
                animation2.setDuration(900L);
                animation2.setInterpolator(new AccelerateInterpolator());
                return animation2;
            }
            if (this.bannerAnimation == null || !this.bannerAnimation.equals("top_down")) {
                return null;
            }
            Animation animation3 = new TranslateAnimation(2, 0.0f, 2, 0.0f, 2, 0.0f, 2, 1.0f);
            animation3.setDuration(900L);
            animation3.setInterpolator(new AccelerateInterpolator());
            return animation3;
        }
        if (this.bannerAnimation != null && this.bannerAnimation.equals("fade")) {
            Animation animation4 = new AlphaAnimation(0.0f, 1.0f);
            animation4.setDuration(1200L);
            return animation4;
        }
        if (this.bannerAnimation != null && this.bannerAnimation.equals("left_to_right")) {
            Animation animation5 = new TranslateAnimation(2, -1.0f, 2, 0.0f, 2, 0.0f, 2, 0.0f);
            animation5.setDuration(900L);
            animation5.setInterpolator(new AccelerateInterpolator());
            return animation5;
        }
        if (this.bannerAnimation == null || !this.bannerAnimation.equals("top_down")) {
            return null;
        }
        Animation animation6 = new TranslateAnimation(2, 0.0f, 2, 0.0f, 2, -1.0f, 2, 0.0f);
        animation6.setDuration(900L);
        animation6.setInterpolator(new AccelerateInterpolator());
        return animation6;
    }

    private void resizeBanner(String banner_type) {
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        float scale = displayMetrics.density;
        if ((banner_type != null && banner_type.contains(BANNER_TYPE_IMAGE)) || banner_type.contains(BANNER_TYPE_TEXT)) {
            if (Util.isTablet(getContext())) {
                this.height = (int) ((90.0f * scale) + 0.5f);
                this.heightDp = BANNER_HEIGHT_TABLET;
                this.width = (int) ((728.0f * scale) + 0.5f);
                this.widthDp = BANNER_WIDTH_TABLET;
            } else {
                this.height = (int) ((60.0f * scale) + 0.5f);
                this.heightDp = 60;
                this.width = (int) ((468.0f * scale) + 0.5f);
                this.widthDp = 468;
            }
        } else if (banner_type != null && banner_type.contains(BANNER_TYPE_MEDIUM_RECTANGLE)) {
            this.height = (int) ((250.0f * scale) + 0.5f);
            this.width = (int) ((300.0f * scale) + 0.5f);
            this.heightDp = BANNER_MEDIUM_RECTANGLE_HEIGHT;
            this.widthDp = BANNER_MEDIUM_RECTANGLE_WIDTH;
        }
        int tempHeight = this.height;
        int tempWidth = this.width;
        if (displayMetrics.heightPixels < this.height) {
            tempHeight = displayMetrics.heightPixels;
        }
        if (displayMetrics.widthPixels < this.width) {
            tempWidth = displayMetrics.widthPixels;
        }
        float heightRatio = this.height / tempHeight;
        float widthRatio = this.width / tempWidth;
        if (heightRatio > widthRatio) {
            this.width = (int) (this.width / heightRatio);
            this.widthDp = (int) (this.width / scale);
            Util.printDebugLog("if: " + heightRatio + " " + widthRatio + " " + this.width + " " + this.height + " " + this.widthDp + " " + this.heightDp);
        } else {
            this.width = tempWidth;
            this.widthDp = (int) (tempWidth / scale);
            Util.printDebugLog("else: " + heightRatio + " " + widthRatio + " " + this.width + " " + this.height + " " + this.widthDp + " " + this.heightDp);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void removeOldViews() {
        for (View view : this.oldViews) {
            removeView(view);
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration newConfig) {
        if (Build.VERSION.SDK_INT >= 8) {
            super.onConfigurationChanged(newConfig);
        }
        if (this.bannerAd != null) {
            String banner_type = this.bannerAd.getBanner_type();
            if (banner_type.equals(BANNER_TYPE_IMAGE) || banner_type.equals(BANNER_TYPE_TEXT) || banner_type.equals(BANNER_TYPE_MEDIUM_RECTANGLE)) {
                this.handler.sendEmptyMessage(2);
                resizeBanner(banner_type);
                loadBannerAd();
            }
        }
    }

    private void setBackGround() {
        try {
            if (Build.VERSION.SDK_INT >= 16) {
                setBackground(this.bannerBgDrawable);
            } else {
                setBackgroundDrawable(this.bannerBgDrawable);
            }
        } catch (Exception e) {
        }
    }

    public void setAdListener(AdCallbackListener.MraidCallbackListener adListener2) {
        adListener = adListener2;
    }

    public AdCallbackListener.MraidCallbackListener getAdListener() {
        return adListener;
    }

    public String getBanner_type() {
        return this.banner_type;
    }

    public boolean isTestMode() {
        return this.isTestMode;
    }

    public int getAdRefreshTime() {
        return this.adRefreshTime;
    }

    public String getPlacementType() {
        return this.placementType;
    }

    public int getadWidth() {
        return this.width;
    }

    public int getadHeight() {
        return this.height;
    }
}
