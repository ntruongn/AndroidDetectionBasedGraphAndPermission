package com.bugsense.trace;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.util.Log;
import com.bugsense.trace.models.CrashMechanism;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class BugSenseHandler {
    protected static Context gContext;
    private static ActivityAsyncTask<Processor, Object, Object, Object> sTask;
    public static boolean I_WANT_TO_DEBUG = false;
    protected static int sMinDelay = 0;
    private static boolean sSetupCalled = false;
    private static ExceptionCallback exceptionCallback = null;
    private static boolean isSessionActive = false;
    static String locTicker = "";
    static String locTitle = "";
    static String locText = "";
    private static HashMap<String, String> crashExtraData = new HashMap<>();

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public interface Processor {
        boolean beginSubmit();

        void handlerInstalled();

        void submitDone();
    }

    public static void addCrashExtraData(String str, String str2) {
        if (crashExtraData == null) {
            crashExtraData = new HashMap<>();
        }
        crashExtraData.put(str, Utils.exceedLimitString(str2));
    }

    public static void addCrashExtraMap(HashMap<String, String> hashMap) {
        if (crashExtraData == null) {
            crashExtraData = new HashMap<>();
        }
        for (Map.Entry<String, String> entry : hashMap.entrySet()) {
            crashExtraData.put(entry.getKey(), Utils.exceedLimitString(entry.getValue()));
        }
    }

    public static void clearCrashExtraData() {
        if (crashExtraData == null) {
            crashExtraData = new HashMap<>();
        } else {
            crashExtraData.clear();
        }
    }

    public static void closeSession(Context context) {
        isSessionActive = false;
    }

    public static void flush(Context context) {
        Log.i(G.TAG, "Flushing...");
        CrashMechanism.getInstance().sendSavedCrashes(context);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static ExceptionCallback getCallback() {
        return exceptionCallback;
    }

    public static HashMap<String, String> getCrashExtraData() {
        if (crashExtraData == null) {
            crashExtraData = new HashMap<>();
        }
        return crashExtraData;
    }

    private static void initAndStartSession(Context context, Processor processor, String str, String str2) {
        if (context == null) {
            Log.e(G.TAG, "Context is null!");
            return;
        }
        gContext = context;
        if (str == null || str.length() < 8 || str.length() > 14) {
            throw new IllegalArgumentException("Your BugSense API Key is invalid!");
        }
        G.API_KEY = str;
        installHandler();
        processor.handlerInstalled();
        G.PHONE_MODEL = Build.MODEL;
        G.ANDROID_VERSION = Build.VERSION.RELEASE;
        G.APPID = str2;
        try {
            PackageInfo packageInfo = gContext.getPackageManager().getPackageInfo(gContext.getPackageName(), 0);
            G.APP_VERSION = packageInfo.versionName;
            G.APP_VERSIONCODE = String.valueOf(packageInfo.versionCode);
            G.APP_PACKAGE = packageInfo.packageName;
        } catch (Exception e) {
            Log.e(G.TAG, "Error collecting information about the package!");
            if (I_WANT_TO_DEBUG) {
                e.printStackTrace();
            }
        }
        if (sSetupCalled && sTask != null && !sTask.postProcessingDone()) {
            sTask.connectTo(null);
            sTask.connectTo(processor);
        }
        sSetupCalled = true;
        try {
            G.FILES_PATH = gContext.getFilesDir().getAbsolutePath();
        } catch (Exception e2) {
            if (I_WANT_TO_DEBUG) {
                e2.printStackTrace();
            }
        }
        if (G.FILES_PATH == null) {
            Log.e(G.TAG, "G.FILES_PATH GOT NULL!");
            return;
        }
        if (I_WANT_TO_DEBUG) {
            Log.d(G.TAG, "Files Path set to: " + G.FILES_PATH);
        }
        G.HAS_ROOT = Utils.checkForRoot();
        new Thread(new Runnable() { // from class: com.bugsense.trace.BugSenseHandler.1
            @Override // java.lang.Runnable
            public void run() {
                G.UID = Utils.manageUid(BugSenseHandler.gContext);
                if (BugSenseHandler.I_WANT_TO_DEBUG) {
                    Log.d(G.TAG, "Crash     URL set to: " + G.URL);
                }
                BugSenseHandler.flush(BugSenseHandler.gContext);
                BugSenseHandler.startSession(BugSenseHandler.gContext);
            }
        }).start();
    }

    public static void initAndStartSession(Context context, String str, String str2) {
        initAndStartSession(context, new Processor() { // from class: com.bugsense.trace.BugSenseHandler.2
            @Override // com.bugsense.trace.BugSenseHandler.Processor
            public boolean beginSubmit() {
                return true;
            }

            @Override // com.bugsense.trace.BugSenseHandler.Processor
            public void handlerInstalled() {
            }

            @Override // com.bugsense.trace.BugSenseHandler.Processor
            public void submitDone() {
            }
        }, str, str2);
    }

    private static void installHandler() {
        Log.i(G.TAG, "Registering default exceptions handler");
        Thread.UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        if (defaultUncaughtExceptionHandler != null && I_WANT_TO_DEBUG) {
            Log.d(G.TAG, "current handler class=" + defaultUncaughtExceptionHandler.getClass().getName());
        }
        if (defaultUncaughtExceptionHandler instanceof DefaultExceptionHandler) {
            return;
        }
        Thread.setDefaultUncaughtExceptionHandler(new DefaultExceptionHandler(defaultUncaughtExceptionHandler));
    }

    public static void leaveBreadcrumb(String str) {
        if (G.breadcrumbs == null) {
            G.breadcrumbs = new ArrayList<>(16);
        }
        if (G.breadcrumbs.size() >= 16) {
            G.breadcrumbs.remove(0);
        }
        G.breadcrumbs.add(str);
        if (I_WANT_TO_DEBUG) {
            Log.i(G.TAG, "BreadCrumb: " + str + " added.");
        }
    }

    public static void removeCrashExtraData(String str) {
        if (crashExtraData == null) {
            crashExtraData = new HashMap<>();
        }
        crashExtraData.remove(str);
    }

    public static void sendException(Exception exc) {
        sendExceptionMap(new HashMap(0), exc);
    }

    public static void sendExceptionMap(HashMap<String, String> hashMap, Exception exc) {
        String str;
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        if (G.API_KEY == null) {
            Log.e(G.TAG, "Could not send: API Key is missing");
            return;
        }
        Log.i(G.TAG, "Saving handled exception");
        exc.printStackTrace(printWriter);
        HashMap hashMap2 = new HashMap();
        if (hashMap != null) {
            for (Map.Entry<String, String> entry : hashMap.entrySet()) {
                hashMap2.put(entry.getKey(), Utils.exceedLimitString(entry.getValue()));
            }
        }
        long j = 0;
        try {
            j = System.currentTimeMillis() - G.TIMESTAMP;
        } catch (Exception e) {
        }
        try {
            exc.printStackTrace(printWriter);
            try {
                str = CrashMechanism.createJSONFromCrash(stringWriter.toString(), Utils.isWifiOn(gContext), Utils.isMobileNetworkOn(gContext), Utils.isGPSOn(gContext), Utils.ScreenProperties(gContext), Utils.getTime(), getCrashExtraData(), hashMap2, 0, j, null);
            } catch (Exception e2) {
                e2.printStackTrace();
                str = "";
            }
            CrashMechanism.saveCrash(str, 0);
        } catch (Exception e3) {
            Log.e(G.TAG, "Failed to save handled exception ");
            if (I_WANT_TO_DEBUG) {
                e3.printStackTrace();
            }
        }
    }

    public static void sendExceptionMessage(String str, String str2, Exception exc) {
        HashMap hashMap = new HashMap(1);
        if (str != null && str2 != null) {
            hashMap.put(str, Utils.exceedLimitString(str2));
        }
        sendExceptionMap(hashMap, exc);
    }

    public static void setExceptionCallback(ExceptionCallback exceptionCallback2) {
        exceptionCallback = exceptionCallback2;
    }

    public static void setLocalizedNotification(String str, String str2, String str3) {
        locTicker = str;
        locTitle = str2;
        locText = str3;
    }

    public static void setLogging(int i) {
        G.SEND_LOG = true;
        G.LOG_LINES = i;
    }

    public static void setLogging(int i, String str) {
        G.SEND_LOG = true;
        G.LOG_LINES = i;
        G.LOG_FILTER = str;
    }

    public static void setLogging(String str) {
        G.SEND_LOG = true;
        G.LOG_FILTER = str;
    }

    public static void setLogging(boolean z) {
        G.SEND_LOG = z;
    }

    public static void startSession(Context context) {
        gContext = context;
        installHandler();
        if (isSessionActive) {
            return;
        }
        G.TIMESTAMP = System.currentTimeMillis();
        isSessionActive = true;
    }

    public static void useProxy(boolean z) {
        G.proxyEnabled = z;
    }
}
