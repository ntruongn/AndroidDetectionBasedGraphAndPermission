package com.bugsense.trace;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class G {
    public static final String BUGSENSE_VERSION = "3.2.1";
    public static final String CRASH_READ_COMPLETED = "CRASH_READ_COMPLETED";
    public static final int MAX_BREADCRUMBS = 16;
    public static final String PINGS_READ_COMPLETED = "PINGS_READ_COMPLETED";
    public static String APPID = "";
    public static String FILES_PATH = null;
    public static String APP_VERSION = "unknown";
    public static String APP_VERSIONCODE = "unknown";
    public static String APP_PACKAGE = "unknown";
    public static String URL = "https://bugsense.appspot.com/api/errors/airpush";
    public static String TAG = "BugSenseHandler";
    public static String ANDROID_VERSION = "unknown";
    public static String PHONE_MODEL = "unknown";
    public static String PHONE_BRAND = "unknown";
    public static String API_KEY = "unknown";
    public static boolean HAS_ROOT = false;
    public static String UID = "";
    public static ArrayList<String> breadcrumbs = new ArrayList<>(16);
    public static boolean SEND_LOG = false;
    public static String LOG_FILTER = "";
    public static int LOG_LINES = 5000;
    public static long TIMESTAMP = 0;
    public static boolean proxyEnabled = false;
}
