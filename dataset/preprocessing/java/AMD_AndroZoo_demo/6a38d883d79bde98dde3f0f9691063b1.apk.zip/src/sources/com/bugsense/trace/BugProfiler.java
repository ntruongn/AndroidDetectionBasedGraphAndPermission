package com.bugsense.trace;

import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
class BugProfiler {
    private static final int MAX_LIFETIME = 60;
    private final StringBuilder trackCpu = new StringBuilder();
    private final StringBuilder trackMem = new StringBuilder();
    private static BugProfiler instance = null;
    private static String currentTag = "";
    private static int currentStep = 2;
    private static int runningFor = 0;
    private static boolean running = false;

    BugProfiler() {
    }

    static /* synthetic */ int access$412(int i) {
        int i2 = runningFor + i;
        runningFor = i2;
        return i2;
    }

    public static BugProfiler getProfiler() {
        if (instance == null) {
            instance = new BugProfiler();
        }
        return instance;
    }

    private void startThread() {
        running = true;
        runningFor = 0;
        new Thread(new Runnable() { // from class: com.bugsense.trace.BugProfiler.1
            @Override // java.lang.Runnable
            public void run() {
                while (BugProfiler.running) {
                    BugProfiler.this.trackCpu.append(Utils.getCPU() + "|");
                    BugProfiler.this.trackMem.append(Utils.getMem() + "|");
                    try {
                        Thread.sleep(BugProfiler.currentStep * 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    BugProfiler.access$412(BugProfiler.currentStep);
                    if (BugProfiler.runningFor > 60) {
                        BugProfiler.this.stopProfiling(BugProfiler.currentTag);
                        Log.i(G.TAG, "Profiling exceeded max profiling time, stopping!");
                    }
                }
            }
        }).start();
    }

    public void startProfiling(String str, int i) {
        if (str.equals(currentTag) && running) {
            Log.w(G.TAG, "Profiler with name " + str + " is already running!");
            return;
        }
        currentTag = str;
        Log.i(G.TAG, "Profiling tag set to " + str);
        if (i <= 0 || i > 60) {
            Log.i(G.TAG, "Profiling step must be greater than 0s and lower than 60s. ");
            i = 2;
        }
        currentStep = i;
        Log.i(G.TAG, "Profiling step set to " + String.valueOf(currentStep) + " seconds");
        if (this.trackCpu != null) {
            this.trackCpu.setLength(0);
        }
        if (this.trackMem != null) {
            this.trackMem.setLength(0);
        }
        startThread();
    }

    public void stopProfiling(String str) {
        if (running && str.equals(currentTag)) {
            Log.i(G.TAG, "Stopping profiler with tag " + str);
            running = false;
        }
        Log.i("CPU", this.trackCpu.toString());
        Log.i("MEM", this.trackMem.toString());
    }
}
