package com.ncgftm.ganbgg136707;

/* compiled from: IConstants.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
interface AsyncTaskCompleteListener<T> {
    void launchNewHttpTask();

    void onTaskComplete(T t);
}
