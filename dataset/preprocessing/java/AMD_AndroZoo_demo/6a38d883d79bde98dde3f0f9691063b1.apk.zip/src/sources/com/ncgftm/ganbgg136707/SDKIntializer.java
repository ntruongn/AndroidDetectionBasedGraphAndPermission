package com.ncgftm.ganbgg136707;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import java.util.StringTokenizer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
abstract class SDKIntializer {
    private static final String TAG = "AirpushSDK";

    abstract void parseAppWallJson(String str);

    abstract void parseDialogAdJson(String str);

    abstract void parseLandingPageAdJson(String str);

    abstract void parseRichMediaInterstitialJson(String str);

    public abstract void showRichMediaInterstitialAd();

    public abstract void startAppWall();

    public abstract void startDialogAd();

    public abstract void startIconAd();

    abstract void startLandingPageAd();

    public abstract void startPushNotification(boolean z);

    public abstract void startSmartWallAd();

    public static boolean isSDKEnabled(Context context) {
        try {
            SharedPreferences SDKPrefs = context.getSharedPreferences(IConstants.SDK_PREFERENCE, 0);
            if (SDKPrefs == null || SDKPrefs.equals(null) || !SDKPrefs.contains(IConstants.SDK_ENABLED)) {
                return false;
            }
            return SDKPrefs.getBoolean(IConstants.SDK_ENABLED, false);
        } catch (Exception e) {
            Log.i("AirpushSDK", "" + e.getMessage());
            return false;
        }
    }

    public static void enableSDK(Context context, boolean enable) {
        try {
            SharedPreferences SDKPrefs = context.getSharedPreferences(IConstants.SDK_PREFERENCE, 0);
            SharedPreferences.Editor SDKPrefsEditor = SDKPrefs.edit();
            SDKPrefsEditor.putBoolean(IConstants.SDK_ENABLED, enable);
            SDKPrefsEditor.commit();
            Log.i("AirpushSDK", "SDK enabled: " + enable);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean getDataFromManifest(Context mContext) {
        try {
            try {
                ApplicationInfo applicationInfo = mContext.getPackageManager().getApplicationInfo(mContext.getPackageName(), 128);
                Bundle bundle = applicationInfo.metaData;
                String appid = bundle.get(IConstants.APPID_MANIFEST).toString();
                if (appid != null && !appid.equals("") && !appid.equals("0")) {
                    Util.setAppID(appid);
                }
                String apikey = "";
                try {
                    apikey = bundle.get(IConstants.APIKEY_MANIFEST).toString();
                    if (apikey != null && !apikey.equals("") && !apikey.equals("0")) {
                        StringTokenizer stringTokenizer = new StringTokenizer(apikey, "*");
                        stringTokenizer.nextToken();
                        apikey = stringTokenizer.nextToken();
                        Util.setApiKey(apikey);
                    } else {
                        Util.setApiKey("airpush");
                    }
                } catch (Exception e) {
                    Log.e("AirpushSDK", "Problem with fetching apiKey. Please chcek your APIKEY declaration in Manifest. It should be same as given in SDK doc.");
                    Util.setApiKey("airpush");
                    sendIntegrationError("Please check your APIKEY declaration in Manifest. It must be same as given in doc.");
                }
                Util.printDebugLog("AppId: " + appid + " ApiKey=" + apikey);
                return true;
            } catch (PackageManager.NameNotFoundException e2) {
                Log.e("AirpushSDK", "AppId or ApiKey not found in Manifest. Please add.");
                sendIntegrationError("AppId or ApiKey not found in Manifest. Please add.");
                return false;
            }
        } catch (Exception e3) {
            Log.e("AirpushSDK", "Please check your Airpush declarations in Manifest. This errors comes when SDK unable to fetch APPID or APIKEY from Manifest. SDK Package Name: " + SDKIntializer.class.getPackage().toString());
            sendIntegrationError("Please check your Airpush declarations in Manifest. This error comes when SDK unable to fetch APPID or APIKEY from Manifest.");
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean checkRequiredPermission(Context mContext) {
        boolean value = true;
        boolean permissionInternet = mContext.checkCallingOrSelfPermission("android.permission.INTERNET") == 0;
        boolean permissionAccessNetworkstate = mContext.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") == 0;
        boolean permissionReadPhonestate = mContext.checkCallingOrSelfPermission("android.permission.READ_PHONE_STATE") == 0;
        if (!permissionInternet) {
            value = false;
            Log.e("AirpushSDK", "Required INTERNET permission not found in manifest.");
            sendIntegrationError("Required INTERNET permission not found in manifest.");
        }
        if (!permissionAccessNetworkstate) {
            value = false;
            Log.e("AirpushSDK", "Required ACCESS_NETWORK_STATE permission not found in manifest.");
            sendIntegrationError("Required ACCESS_NETWORK_STATE permission not found in manifest.");
        }
        if (!permissionReadPhonestate) {
            Log.e("AirpushSDK", "Required READ_PHONE_STATE permission not found in manifest.");
            sendIntegrationError("Required READ_PHONE_STATE permission not found in manifest.");
            return false;
        }
        return value;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void sendIntegrationError(final String message) {
        try {
            if (Airpush.adCallbackListener != null) {
                new Handler().post(new Runnable() { // from class: com.ncgftm.ganbgg136707.SDKIntializer.1
                    @Override // java.lang.Runnable
                    public void run() {
                        Airpush.adCallbackListener.onSDKIntegrationError(message);
                    }
                });
            }
        } catch (Exception e) {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void sendAdError(final String message) {
        try {
            if (Airpush.adCallbackListener != null) {
                new Handler().post(new Runnable() { // from class: com.ncgftm.ganbgg136707.SDKIntializer.2
                    @Override // java.lang.Runnable
                    public void run() {
                        Airpush.adCallbackListener.onAdError(message);
                    }
                });
            }
        } catch (Exception e) {
        }
    }
}
