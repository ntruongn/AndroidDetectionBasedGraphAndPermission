package com.ncgftm.ganbgg136707;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;
import com.ncgftm.ganbgg136707.IConstants;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class IconAds implements IConstants {
    private String[] iconImageArr;
    private String[] iconTextArr;
    private String[] iconUrlArr;
    private boolean isShowopt;
    private JSONObject jsonObject;
    private Context mContext;
    private String optout;
    private JSONObject post;
    private String[] campaignArr = null;
    private String[] creativeArr = null;
    private int len = 0;
    AsyncTaskCompleteListener<String> sendInstallListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.IconAds.2
        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            Log.i(IConstants.TAG, "Icon Install returns:" + result);
        }

        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void launchNewHttpTask() {
            Log.i(IConstants.TAG, "Sending Install Data....");
            try {
                String json = IconAds.this.post.toString();
                if (json != null && !json.equals("")) {
                    List<NameValuePair> values = SetPreferences.setValues(IconAds.this.mContext);
                    values.add(new BasicNameValuePair(IConstants.MODEL, IConstants.MODEL_LOG));
                    values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_SET_ICON_INSTALL_TRACKING));
                    values.add(new BasicNameValuePair(IConstants.APIKEY, Util.getApiKey()));
                    values.add(new BasicNameValuePair(IConstants.EVENT, IConstants.EVENT_iINSTALL));
                    values.add(new BasicNameValuePair("campaigncreativedata", json));
                    HttpPostDataTask httpPostTask = new HttpPostDataTask(IconAds.this.mContext, values, IConstants.URL_API_MESSAGE, this);
                    httpPostTask.execute(new Void[0]);
                    Util.printDebugLog("Install values: " + values);
                }
            } catch (Exception e) {
                Util.printDebugLog("Error in send listener.");
            }
        }
    };

    public IconAds(Context context) {
        this.mContext = context;
        if (this.mContext == null) {
            this.mContext = Util.getContext();
        }
        getShortcutData();
    }

    void createShortcut(Bitmap bmpicon, String iconText, String iconUrl) throws Exception {
        try {
            Intent shortcutIntent = new Intent("android.intent.action.VIEW");
            shortcutIntent.setData(Uri.parse(iconUrl));
            shortcutIntent.addFlags(268435456);
            shortcutIntent.addFlags(67108864);
            Intent addIntent = new Intent();
            addIntent.putExtra("android.intent.extra.shortcut.INTENT", shortcutIntent);
            addIntent.putExtra("android.intent.extra.shortcut.NAME", iconText);
            addIntent.putExtra("duplicate", false);
            addIntent.putExtra("android.intent.extra.shortcut.ICON", bmpicon);
            makeShortcut(addIntent);
        } catch (Exception e) {
            String iconUrl1 = SetPreferences.getPostValues(this.mContext);
            Intent shortcutIntent2 = new Intent("android.intent.action.VIEW");
            shortcutIntent2.setData(Uri.parse(iconUrl1 + "&model=log&action=seticonclicktracking&APIKEY=airpushsearch&event=iClick&campaignid=0&creativeid=0"));
            shortcutIntent2.addFlags(268435456);
            shortcutIntent2.addFlags(67108864);
            Intent addIntent2 = new Intent();
            addIntent2.putExtra("android.intent.extra.shortcut.INTENT", shortcutIntent2);
            addIntent2.putExtra("android.intent.extra.shortcut.NAME", "Search");
            addIntent2.putExtra("duplicate", false);
            addIntent2.putExtra("android.intent.extra.shortcut.ICON", Intent.ShortcutIconResource.fromContext(this.mContext, 17301583));
            makeShortcut(addIntent2);
        }
    }

    private void showOptout() {
        try {
            if (this.isShowopt && this.optout != null && !this.optout.equals("")) {
                if (this.optout.contains("#APPNAME")) {
                    this.optout = this.optout.replace("#APPNAME", Util.getAppName(this.mContext));
                }
                if (this.optout.contains("#PACKAGENAME")) {
                    this.optout = this.optout.replace("#PACKAGENAME", Util.getPackageName(this.mContext));
                }
                Toast.makeText(this.mContext, this.optout, 0).show();
                this.isShowopt = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void makeShortcut(Intent addIntent) {
        if (this.mContext.getPackageManager().checkPermission("com.android.launcher.permission.INSTALL_SHORTCUT", this.mContext.getPackageName()) == 0) {
            addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
            this.mContext.getApplicationContext().sendBroadcast(addIntent);
            showOptout();
            return;
        }
        Log.i(IConstants.TAG, "Installing shortcut permission not found in Manifest, please add.");
    }

    private void getShortcutData() {
        try {
            AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.IconAds.1
                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void onTaskComplete(String result) {
                    Util.registerApsalarEvent(IconAds.this.mContext, IConstants.ApSalarEvent.icon_call);
                    Log.i(IConstants.TAG, "Icon Ad Json: " + result);
                    if (result != null) {
                        IconAds.this.parseIconJson(result);
                    }
                }

                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void launchNewHttpTask() {
                    try {
                        int width = IconAds.this.mContext.getApplicationContext().getResources().getDisplayMetrics().widthPixels;
                        List<NameValuePair> values = SetPreferences.setValues(IconAds.this.mContext);
                        values.add(new BasicNameValuePair(IMraid.WIDTH, String.valueOf(width)));
                        values.add(new BasicNameValuePair(IConstants.MODEL, "message"));
                        values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_GET_ICON));
                        values.add(new BasicNameValuePair(IConstants.APIKEY, Util.getApiKey()));
                        Util.printDebugLog("Icon  data values: " + values);
                        HttpPostDataTask httpPostTask = new HttpPostDataTask(IconAds.this.mContext, values, IConstants.URL_API_MESSAGE, this);
                        httpPostTask.execute(new Void[0]);
                    } catch (NullPointerException e) {
                        e.printStackTrace();
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
            };
            if (Util.checkInternetConnection(this.mContext)) {
                asyncTaskCompleteListener.launchNewHttpTask();
            }
        } catch (Exception e) {
            Util.printLog("geticd err " + e.getMessage());
            Util.printDebugLog("IconAds Problem in getshortcutdata");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void parseIconJson(String jsonString) {
        try {
            if (jsonString.contains("campaignid")) {
                JSONArray jsonArray = new JSONArray(jsonString);
                this.len = jsonArray.length();
                Util.printDebugLog("JSON Array lenght: " + this.len);
                this.iconImageArr = new String[this.len];
                this.iconUrlArr = new String[this.len];
                this.iconTextArr = new String[this.len];
                this.campaignArr = new String[this.len];
                this.creativeArr = new String[this.len];
                this.post = new JSONObject();
                for (int i = 0; i < jsonArray.length(); i++) {
                    this.jsonObject = new JSONObject(jsonArray.get(i).toString());
                    if (i == 0) {
                        this.optout = this.jsonObject.isNull("optout") ? "Optout:xapush.com, Ad by: " + Util.getAppName(this.mContext) : this.jsonObject.getString("optout");
                        this.isShowopt = true;
                    }
                    this.iconImageArr[i] = getIconImage(this.jsonObject);
                    this.iconTextArr[i] = getIconText(this.jsonObject);
                    this.iconUrlArr[i] = getIconUrl(this.jsonObject);
                    this.campaignArr[i] = getCampaignId(this.jsonObject);
                    this.creativeArr[i] = getCreativeId(this.jsonObject);
                    if (this.iconImageArr[i].equals("Not Found") || this.iconTextArr[i].equals("Not Found") || this.iconUrlArr[i].equals("Not Found")) {
                        Util.printLog("json issue in cmid: " + this.campaignArr[i] + ", cid: " + this.creativeArr[i]);
                    } else {
                        this.post.put(this.campaignArr[i], this.creativeArr[i]);
                        new CreateIcon(this.iconTextArr[i], this.iconUrlArr[i], this.iconImageArr[i]);
                    }
                }
                if (Util.checkInternetConnection(this.mContext)) {
                    this.sendInstallListener.launchNewHttpTask();
                }
            }
        } catch (Exception e) {
            Log.e(IConstants.TAG, "Icon parse error: " + e.getMessage());
        }
    }

    private String getIconImage(JSONObject json) {
        try {
            String iconImage = json.getString("iconimage");
            if (iconImage.equals("")) {
                return "Not Found";
            }
            return iconImage;
        } catch (JSONException e) {
            return "Not Found";
        }
    }

    private String getIconText(JSONObject json) {
        try {
            return json.getString("icontext");
        } catch (JSONException e) {
            return "Not Found";
        }
    }

    private String getCampaignId(JSONObject json) {
        try {
            String campaignId = json.getString("campaignid");
            Util.printDebugLog("Campaign id: " + campaignId);
            return campaignId;
        } catch (JSONException e) {
            return "Not Found";
        }
    }

    private String getCreativeId(JSONObject json) {
        try {
            String creativeId = json.getString("creativeid");
            Util.printDebugLog("Creative id: " + creativeId);
            return creativeId;
        } catch (JSONException e) {
            return "Not Found";
        }
    }

    private String getIconUrl(JSONObject json) {
        try {
            return json.getString("iconurl");
        } catch (JSONException e) {
            return "Not Found";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public final class CreateIcon implements AsyncTaskCompleteListener<Bitmap> {
        final String iconImage;
        final String iconText;
        final String iconUrl;

        public CreateIcon(String iconText, String iconUrl, String iconImage) {
            this.iconText = iconText;
            this.iconUrl = iconUrl;
            this.iconImage = iconImage;
            if (Util.checkInternetConnection(IconAds.this.mContext)) {
                launchNewHttpTask();
            }
        }

        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void onTaskComplete(Bitmap result) {
            try {
                IconAds.this.createShortcut(result, this.iconText, this.iconUrl);
            } catch (Exception e) {
                Log.e("TAG", "Icon not created." + e.getMessage());
            }
        }

        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void launchNewHttpTask() {
            ImageTask imageTask = new ImageTask(this.iconImage, this);
            imageTask.execute(new Void[0]);
        }
    }
}
