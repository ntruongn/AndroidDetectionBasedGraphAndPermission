package com.bugsense.trace.models;

import android.util.Log;
import com.bugsense.trace.BugSense;
import com.bugsense.trace.BugSenseHandler;
import com.bugsense.trace.CryptoHttpClient;
import com.bugsense.trace.G;
import com.bugsense.trace.Utils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public final class PingsMechanism {
    public static final int GNIP = 1;
    private static final int MAX_GNIPS_SIZE = 2;
    private static final int MAX_PERFS_SIZE = 10;
    private static final int MAX_PINGS_SIZE = 2;
    public static final int PING = 0;
    public static final int TRANS_END = 3;
    public static final int TRANS_START = 2;
    private static volatile PingsMechanism instance;

    public static String getFlatLine(int i, String str, String str2, String str3) {
        String str4 = "";
        if (i == 0) {
            str4 = "_ping";
        } else if (i == 1) {
            str4 = "_gnip";
        } else if (i == 2) {
            str4 = "_trstart-" + str;
        } else if (i == 3) {
            str4 = "_trend-" + str;
        }
        String str5 = "3.2.1:" + str4 + ":" + G.PHONE_MODEL + ":" + G.PHONE_BRAND + ":" + G.ANDROID_VERSION + ":" + G.APP_VERSION + ":" + Locale.getDefault().getDisplayLanguage() + ":" + Utils.getTime();
        return (str2 == null || str3 == null || str2.length() <= 0 || str3.length() <= 0) ? str5 : str5 + ":" + str2 + ":" + str3;
    }

    public static PingsMechanism getInstance() {
        if (instance == null) {
            instance = new PingsMechanism();
        }
        return instance;
    }

    public static void savePing(final int i, final String str) {
        new Thread(new Runnable() { // from class: com.bugsense.trace.models.PingsMechanism.3
            @Override // java.lang.Runnable
            public void run() {
                if (i == 2 || i == 3) {
                    PingsMechanism.savePing(i, str, Utils.getCPU(), Utils.getMem());
                } else {
                    PingsMechanism.savePing(i, null, null, null);
                }
            }
        }).start();
    }

    public static void savePing(final int i, final String str, final String str2, final String str3) {
        Thread thread = new Thread(new Runnable() { // from class: com.bugsense.trace.models.PingsMechanism.4
            @Override // java.lang.Runnable
            public void run() {
                String flatLine = PingsMechanism.getFlatLine(i, str, str2, str3);
                String str4 = i == 1 ? "Gnip_" : "Ping_";
                if (i == 2 || i == 3) {
                    str4 = "Perf_";
                }
                try {
                    BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(G.FILES_PATH + "/" + (str4 + String.valueOf(System.currentTimeMillis()) + "-" + Integer.toString(new Random(System.currentTimeMillis()).nextInt(99999)))));
                    bufferedWriter.write(flatLine);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                } catch (IOException e) {
                    Log.e(G.TAG, "Error saving ping data");
                    if (BugSenseHandler.I_WANT_TO_DEBUG) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ExecutorService executor = BugSense.getExecutor();
        if (thread == null || executor == null) {
            return;
        }
        executor.submit(thread);
    }

    public static void transmitPingASync(int i) {
        transmitPingASync(getFlatLine(i, null, null, null), i);
    }

    public static void transmitPingASync(final String str, final int i) {
        Thread thread = new Thread(new Runnable() { // from class: com.bugsense.trace.models.PingsMechanism.2
            @Override // java.lang.Runnable
            public void run() {
                if (PingsMechanism.transmitPingSync(str)) {
                    return;
                }
                PingsMechanism.savePing(i, null, null, null);
            }
        });
        ExecutorService executor = BugSense.getExecutor();
        if (thread == null || executor == null) {
            return;
        }
        executor.submit(thread);
    }

    public static boolean transmitPingSync(String str) {
        if (BugSenseHandler.I_WANT_TO_DEBUG) {
            Log.d(G.TAG, "URL: " + G.ANALYTICS_URL);
            Log.d(G.TAG, "APIKEY: " + G.API_KEY);
        }
        try {
            DefaultHttpClient cryptoHttpClient = G.ANALYTICS_URL.startsWith("https://") ? new CryptoHttpClient(0) : new DefaultHttpClient();
            HttpParams params = cryptoHttpClient.getParams();
            HttpProtocolParams.setUseExpectContinue(params, false);
            HttpConnectionParams.setConnectionTimeout(params, 20000);
            HttpConnectionParams.setSoTimeout(params, 20000);
            HttpPost httpPost = new HttpPost(G.ANALYTICS_URL);
            httpPost.addHeader("X-BugSense-Api-Key", G.API_KEY);
            new ArrayList().add(new BasicNameValuePair("data", str));
            httpPost.setEntity(new StringEntity(str));
            HttpEntity entity = cryptoHttpClient.execute(httpPost).getEntity();
            if (entity == null) {
                Log.w(G.TAG, "It seems that there is no internet connectivity");
                throw new Exception("no internet connection");
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(entity.getContent()));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine);
            }
            if (BugSenseHandler.I_WANT_TO_DEBUG) {
                Log.i(G.TAG, "Ping Response: " + sb.toString());
            }
            return true;
        } catch (Exception e) {
            Log.w(G.TAG, "Transmitting ping Exception " + e.getMessage());
            if (!BugSenseHandler.I_WANT_TO_DEBUG) {
                return false;
            }
            e.printStackTrace();
            return false;
        }
    }

    public synchronized void sendSavedPings() {
        Thread thread = new Thread(new Runnable() { // from class: com.bugsense.trace.models.PingsMechanism.1
            @Override // java.lang.Runnable
            public void run() {
                File file = new File(G.FILES_PATH);
                if (!file.exists()) {
                    file.mkdir();
                }
                FilenameFilter filenameFilter = new FilenameFilter() { // from class: com.bugsense.trace.models.PingsMechanism.1.1
                    @Override // java.io.FilenameFilter
                    public boolean accept(File file2, String str) {
                        return str.startsWith("Ping_");
                    }
                };
                FilenameFilter filenameFilter2 = new FilenameFilter() { // from class: com.bugsense.trace.models.PingsMechanism.1.2
                    @Override // java.io.FilenameFilter
                    public boolean accept(File file2, String str) {
                        return str.startsWith("Gnip_");
                    }
                };
                FilenameFilter filenameFilter3 = new FilenameFilter() { // from class: com.bugsense.trace.models.PingsMechanism.1.3
                    @Override // java.io.FilenameFilter
                    public boolean accept(File file2, String str) {
                        return str.startsWith("Perf_");
                    }
                };
                String[] list = file.list(filenameFilter);
                String[] list2 = file.list(filenameFilter2);
                String[] list3 = file.list(filenameFilter3);
                if (BugSenseHandler.I_WANT_TO_DEBUG) {
                    Log.d(G.TAG, "Ping List has: " + list.length + " items");
                    Log.d(G.TAG, "Gnip List has: " + list2.length + " items");
                    Log.d(G.TAG, "Perf List has: " + list3.length + " items");
                }
                int length = 2 > list.length ? list.length : 2;
                int i = 0;
                while (i < length && PingsMechanism.transmitPingSync(Utils.readFile(G.FILES_PATH + "/" + list[i]))) {
                    i++;
                }
                if (i >= 1) {
                    for (int i2 = 0; i2 < list.length; i2++) {
                        try {
                            new File(G.FILES_PATH + "/" + list[i2]).delete();
                        } catch (Exception e) {
                            Log.e(G.TAG, "Error deleting trace file: " + G.FILES_PATH + "/" + list[i2], e);
                        }
                    }
                }
                int length2 = 2 > list2.length ? list2.length : 2;
                int i3 = 0;
                while (i3 < length2 && PingsMechanism.transmitPingSync(Utils.readFile(G.FILES_PATH + "/" + list2[i3]))) {
                    i3++;
                }
                if (i3 >= 1) {
                    for (int i4 = 0; i4 < list2.length; i4++) {
                        try {
                            new File(G.FILES_PATH + "/" + list2[i4]).delete();
                        } catch (Exception e2) {
                            Log.e(G.TAG, "Error deleting trace file: " + G.FILES_PATH + "/" + list2[i4], e2);
                        }
                    }
                }
                int i5 = PingsMechanism.MAX_PERFS_SIZE;
                if (PingsMechanism.MAX_PERFS_SIZE > list3.length) {
                    i5 = list3.length;
                }
                int i6 = 0;
                while (i6 < i5 && PingsMechanism.transmitPingSync(Utils.readFile(G.FILES_PATH + "/" + list3[i6]))) {
                    i6++;
                }
                if (i6 >= 1) {
                    for (int i7 = 0; i7 < list3.length; i7++) {
                        try {
                            new File(G.FILES_PATH + "/" + list3[i7]).delete();
                        } catch (Exception e3) {
                            Log.e(G.TAG, "Error deleting trace file: " + G.FILES_PATH + "/" + list3[i7], e3);
                        }
                    }
                }
            }
        });
        ExecutorService executor = BugSense.getExecutor();
        if (thread != null && executor != null) {
            executor.submit(thread);
        }
    }
}
