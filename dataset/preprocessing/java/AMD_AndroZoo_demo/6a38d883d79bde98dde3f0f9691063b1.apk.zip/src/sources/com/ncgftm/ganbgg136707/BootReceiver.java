package com.ncgftm.ganbgg136707;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class BootReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(final Context arg0, Intent arg1) {
        try {
            if (Build.VERSION.SDK_INT >= 7) {
                if (SetPreferences.isDeviceBlackListed(arg0)) {
                    Log.i("AiprushSDK", "Can not start push device is blacklisted.");
                } else if (SetPreferences.getDataSharedPrefrences(arg0)) {
                    Thread thread = new Thread(new Runnable() { // from class: com.ncgftm.ganbgg136707.BootReceiver.1
                        @Override // java.lang.Runnable
                        public void run() {
                            synchronized (this) {
                                try {
                                    wait(3000L);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                if (!SetPreferences.isShowOptinDialog(arg0) && Util.isDoPush()) {
                                    Intent intent = new Intent(arg0, (Class<?>) PushService.class);
                                    intent.setAction("bootReceiver");
                                    arg0.startService(intent);
                                    Log.i("AiprushSDK", "SDK started from BootReceiver.");
                                }
                            }
                        }
                    });
                    thread.start();
                }
            }
        } catch (Exception e) {
            Log.e(IConstants.TAG, "Error occurred while starting BootReciver. " + e.getMessage());
        }
    }
}
