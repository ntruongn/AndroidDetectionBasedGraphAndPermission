package com.ncgftm.ganbgg136707;

/* compiled from: IMraid.java */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
abstract class MraidJS implements IMraidBridge {
    abstract void downloadApp(String str);

    abstract void open(String str);

    abstract void printJSLog(String str);

    abstract void sendSms(String str, String str2);

    abstract void setExpandProperties(String str);

    abstract void setOrientationProperties(String str);

    abstract void setResizeProperties(String str);

    abstract void showDialer(String str);

    abstract void showLocation(String str, String str2);
}
