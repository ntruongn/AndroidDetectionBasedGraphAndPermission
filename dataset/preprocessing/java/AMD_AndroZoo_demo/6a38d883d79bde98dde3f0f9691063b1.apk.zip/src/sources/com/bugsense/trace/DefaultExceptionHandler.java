package com.bugsense.trace;

import android.app.ActivityManager;
import android.util.Log;
import com.bugsense.trace.models.CrashMechanism;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class DefaultExceptionHandler implements Thread.UncaughtExceptionHandler {
    private Thread.UncaughtExceptionHandler defaultExceptionHandler;

    public DefaultExceptionHandler(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
        this.defaultExceptionHandler = uncaughtExceptionHandler;
    }

    @Override // java.lang.Thread.UncaughtExceptionHandler
    public void uncaughtException(Thread thread, Throwable th) {
        String str;
        StringWriter stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        long j = 0;
        try {
            j = System.currentTimeMillis() - G.TIMESTAMP;
        } catch (Exception e) {
        }
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        Runtime runtime = Runtime.getRuntime();
        HashMap hashMap = new HashMap(6);
        hashMap.put("sysMemAvail", String.valueOf(memoryInfo.availMem / 1048576.0d));
        hashMap.put("sysMemLow", String.valueOf(memoryInfo.lowMemory));
        hashMap.put("sysMemThreshold", String.valueOf(memoryInfo.threshold / 1048576.0d));
        hashMap.put("appMemAvail", String.valueOf(runtime.freeMemory() / 1048576.0d));
        hashMap.put("appMemMax", String.valueOf(runtime.maxMemory() / 1048576.0d));
        hashMap.put("appMemTotal", String.valueOf(runtime.totalMemory() / 1048576.0d));
        try {
            str = CrashMechanism.createJSONFromCrash(stringWriter.toString(), Utils.isWifiOn(BugSenseHandler.gContext), Utils.isMobileNetworkOn(BugSenseHandler.gContext), Utils.isGPSOn(BugSenseHandler.gContext), Utils.ScreenProperties(BugSenseHandler.gContext), Utils.getTime(), BugSenseHandler.getCrashExtraData(), null, 1, j, hashMap);
        } catch (Exception e2) {
            e2.printStackTrace();
            str = "";
        }
        CrashMechanism.transmitCrashASync(BugSenseHandler.gContext, str, 1);
        if (BugSenseHandler.I_WANT_TO_DEBUG) {
            Log.d(G.TAG, stringWriter.toString());
        }
        if (BugSenseHandler.getCallback() != null) {
            BugSenseHandler.getCallback().lastBreath();
        }
        try {
            Thread.sleep(3000L);
        } catch (InterruptedException e3) {
            e3.printStackTrace();
        }
        this.defaultExceptionHandler.uncaughtException(thread, th);
    }
}
