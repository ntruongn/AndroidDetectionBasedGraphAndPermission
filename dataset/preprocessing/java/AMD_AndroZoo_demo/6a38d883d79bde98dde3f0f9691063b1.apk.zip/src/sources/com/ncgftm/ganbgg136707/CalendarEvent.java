package com.ncgftm.ganbgg136707;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
abstract class CalendarEvent {
    static final String EVENT_RECURRENCE = "rrule";
    static final String EVENT_REMINDER = "reminder";
    static final String EVENT_TRANSPARENCY = "transparency";
    final String CALENDAR_ID = "id";
    final String CALENDAR_TITLE = "summary";
    final String LOCATION = "location";
    final String DESCRIPTION = "description";
    final String START_TIME = "start";
    final String END_TIME = "end";
    final String STATUS = "status";
    final String TRANSPARENCY = EVENT_TRANSPARENCY;
    final String RECURRENCE = "recurrence";
    final String REMINDER = EVENT_REMINDER;

    CalendarEvent() {
    }

    @TargetApi(14)
    public static void createCalenderEvent(Activity activity, String jsonString) throws ActivityNotFoundException, Exception {
        JSONObject jsonObject = new JSONObject(jsonString);
        String id = jsonObject.isNull("id") ? "" : jsonObject.getString("id");
        String title = jsonObject.isNull("summary") ? "" : jsonObject.getString("summary");
        String location = jsonObject.isNull("location") ? "" : jsonObject.getString("location");
        String description = jsonObject.isNull("description") ? "" : jsonObject.getString("description");
        String start = jsonObject.isNull("start") ? "" : jsonObject.getString("start");
        String end = jsonObject.isNull("end") ? "" : jsonObject.getString("end");
        String status = jsonObject.isNull("status") ? "" : jsonObject.getString("status");
        String transparency = jsonObject.isNull(EVENT_TRANSPARENCY) ? "" : jsonObject.getString(EVENT_TRANSPARENCY);
        String reminder = jsonObject.isNull(EVENT_REMINDER) ? "" : jsonObject.getString(EVENT_REMINDER);
        String recurrenceJson = jsonObject.isNull("recurrence") ? "" : jsonObject.getString("recurrence");
        Recurrence recurrence = new Recurrence(recurrenceJson);
        Intent calIntent = new Intent("android.intent.action.INSERT");
        calIntent.setAction("android.intent.action.EDIT");
        calIntent.setType("vnd.android.cursor.item/event");
        calIntent.putExtra("calendar_id", id);
        calIntent.putExtra("title", title);
        calIntent.putExtra("eventLocation", location);
        calIntent.putExtra("description", description);
        calIntent.putExtra("beginTime", convertUTC(start));
        calIntent.putExtra("endTime", convertUTC(end));
        calIntent.putExtra("eventStatus", status);
        calIntent.putExtra(EVENT_TRANSPARENCY, transparency);
        calIntent.putExtra(EVENT_RECURRENCE, recurrence.getRrule());
        calIntent.putExtra("exdate", recurrence.getEXdate());
        if (reminder != null) {
            try {
                if (!reminder.equals("")) {
                    calIntent.putExtra("event_id", id);
                    calIntent.putExtra("method", 0);
                    if (reminder.startsWith("-")) {
                        calIntent.putExtra("minutes", reminder);
                    } else {
                        calIntent.putExtra("minutes", convertUTC(reminder));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        activity.startActivityForResult(calIntent, 7);
    }

    static long convertUTC(String date) throws Exception {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date value = formatter.parse(date);
        System.out.println(value);
        SimpleDateFormat dateFormatter = new SimpleDateFormat();
        dateFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        String dt = dateFormatter.format(value);
        long d = DateFormat.getInstance().parse(dt).getTime();
        return d;
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public static class Recurrence {
        short[] daysInMonth;
        short[] daysInWeek;
        short[] daysInYear;
        String[] exceptionDates;
        String expires;
        String frequency;
        short interval;
        final JSONObject jsonObject;
        short[] monthsInYear;
        short[] weeksInMonth;
        String[] days = {"SU", "MO", "TU", "WE", "TH", "FR", "SA"};
        final String RECURRENCE_FREQUENCY = "frequency";
        final String RECURRENCE_INTERVAL = "interval";
        final String RECURRENCE_EXPIRES = "expires";
        final String RECURRENCE_EXCEPTION_DATES = "exceptionDates";
        final String RECURRENCE_DAYS_IN_WEEK = "daysInWeek";
        final String RECURRENCE_DAYS_IN_MONTH = "daysInMonth";
        final String RECURRENCE_DAYS_IN_YEAR = "daysInYear";
        final String RECURRENCE_WEEKS_IN_MONTH = "weeksInMonth";
        final String RECURRENCE_MONTHS_IN_YEAR = "monthsInYear";

        public Recurrence(String jsonString) throws NullPointerException, JSONException {
            this.jsonObject = new JSONObject(jsonString);
            this.frequency = this.jsonObject.isNull("frequency") ? "" : this.jsonObject.getString("frequency");
            this.interval = this.jsonObject.isNull("interval") ? (short) 0 : Short.parseShort(this.jsonObject.getString("interval"));
            this.expires = this.jsonObject.isNull("expires") ? "" : this.jsonObject.getString("expires");
            JSONArray array = this.jsonObject.isNull("exceptionDates") ? null : this.jsonObject.getJSONArray("exceptionDates");
            if (array != null) {
                this.exceptionDates = new String[array.length()];
                for (int i = 0; i < this.exceptionDates.length; i++) {
                    this.exceptionDates[i] = array.getString(i);
                }
            }
            this.daysInWeek = parseJson("daysInWeek");
            this.daysInMonth = parseJson("daysInMonth");
            this.daysInYear = parseJson("daysInYear");
            this.weeksInMonth = parseJson("weeksInMonth");
            this.monthsInYear = parseJson("monthsInYear");
        }

        final short[] parseJson(String key) throws NullPointerException, JSONException {
            short[] data = null;
            JSONArray array = this.jsonObject.isNull(key) ? null : this.jsonObject.getJSONArray(key);
            if (array != null) {
                data = new short[array.length()];
                for (int i = 0; i < data.length; i++) {
                    data[i] = (short) array.getInt(i);
                }
            }
            return data;
        }

        public String getDate(short[] any) {
            String data = "";
            for (int i = 0; i < any.length; i++) {
                if (i == 0) {
                    short d = any[i];
                    data = "" + this.days[d];
                } else {
                    short d2 = any[i];
                    data = data + "," + this.days[d2];
                }
            }
            return data;
        }

        public String getDate(String[] any) throws Exception {
            String data = "";
            for (int i = 0; i < any.length; i++) {
                if (i == 0) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date date = dateFormat.parse(any[i]);
                    System.out.println("dt: " + date);
                    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");
                    String dt = format.format(date);
                    data = "" + dt;
                } else {
                    SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
                    Date date2 = dateFormat2.parse(any[i]);
                    System.out.println("dt: " + date2);
                    SimpleDateFormat format2 = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");
                    String dt2 = format2.format(date2);
                    data = data + "," + dt2;
                }
            }
            return data;
        }

        public String getDate(String any) throws Exception {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date = dateFormat.parse(any);
            System.out.println("dt: " + date);
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");
            String data = format.format(date);
            return data;
        }

        String getEXdate() throws Exception {
            return this.exceptionDates != null ? getDate(this.exceptionDates) : "";
        }

        public String getRrule() {
            StringBuilder builder = new StringBuilder();
            try {
                if (this.frequency != null && !this.frequency.equals("")) {
                    builder.append("FREQ=" + this.frequency + ";");
                }
                if (this.interval != 0) {
                    builder.append("INTERVAL=" + ((int) this.interval) + ";");
                }
                if (this.expires != null && !this.expires.equals("")) {
                    builder.append("UNTIL=" + getDate(this.expires) + ";");
                }
                if (this.daysInWeek != null) {
                    builder.append("BYDAY=" + getDate(this.daysInWeek) + ";");
                }
                if (this.daysInMonth != null) {
                    builder.append("BYMONTHDAY=" + this.daysInMonth + ";");
                }
                if (this.daysInYear != null) {
                    builder.append("BYYEARDAY=" + this.daysInYear + ";");
                }
                if (this.weeksInMonth != null) {
                    builder.append("BYWEEKNO=" + this.weeksInMonth + ";");
                }
                if (this.monthsInYear != null) {
                    builder.append("BYMONTH=" + this.monthsInYear + ";");
                }
                Util.printDebugLog("Rrule: " + builder.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return builder.toString();
        }
    }
}
