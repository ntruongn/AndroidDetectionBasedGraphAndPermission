package com.ncgftm.ganbgg136707;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import com.ncgftm.ganbgg136707.IConstants;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class DialogAd implements DialogInterface.OnClickListener {
    private static AlertDialog dialog;
    private Activity activity;
    private String adtype;
    private String buttontxt;
    private String campid;
    private String creativeId;
    private String number;
    private String sms;
    private String title;
    private String url;
    private String event = "0";
    Runnable runnable = new Runnable() { // from class: com.ncgftm.ganbgg136707.DialogAd.1
        @Override // java.lang.Runnable
        public void run() {
            if (DialogAd.this.event.equalsIgnoreCase("1")) {
                DialogAd.this.asyncTaskCompleteListener.launchNewHttpTask();
                DialogAd.this.handleClicks();
            } else {
                DialogAd.this.asyncTaskCompleteListener.launchNewHttpTask();
                DialogAd.this.activity.finish();
            }
        }
    };
    AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.DialogAd.2
        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            Log.i(IConstants.TAG, "Dialog Click: " + result);
        }

        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void launchNewHttpTask() {
            List<NameValuePair> list = new ArrayList<>();
            list.add(new BasicNameValuePair("creativeid", DialogAd.this.creativeId));
            list.add(new BasicNameValuePair("campaignid", DialogAd.this.campid));
            list.add(new BasicNameValuePair(IConstants.EVENT, DialogAd.this.event));
            NetworkThread networkThread = new NetworkThread(DialogAd.this.activity, this, list, IConstants.URL_DIALOG_CLICK, 0L, true);
            new Thread(networkThread, "dialogclick").start();
        }
    };

    /* JADX INFO: Access modifiers changed from: package-private */
    public DialogAd(Intent intent, Activity activity) {
        try {
            this.activity = activity;
            this.title = intent.getStringExtra("title");
            this.buttontxt = intent.getStringExtra("buttontxt");
            this.url = intent.getStringExtra(IConstants.NOTIFICATION_URL);
            this.creativeId = intent.getStringExtra("creativeid");
            this.campid = intent.getStringExtra("campaignid");
            this.adtype = intent.getStringExtra(IConstants.AD_TYPE);
            this.sms = intent.getStringExtra(IConstants.SMS);
            this.number = intent.getStringExtra(IConstants.PHONE_NUMBER);
            dialog = showDialog();
            Util.registerApsalarEvent(activity, IConstants.ApSalarEvent.dialog_displayed);
            if (Airpush.adCallbackListener != null) {
                Airpush.adCallbackListener.onSmartWallAdShowing();
            }
        } catch (Exception e) {
            Util.printDebugLog("Error occured in DialogAd: " + e.getMessage());
        }
    }

    protected AlertDialog showDialog() {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(this.activity);
            if (this.title != null && !this.title.equalsIgnoreCase("")) {
                builder.setMessage(this.title);
            } else {
                builder.setMessage("Click for new offers");
            }
            builder.setPositiveButton("No Thanks.", this);
            if (this.buttontxt != null && !this.buttontxt.equalsIgnoreCase("")) {
                builder.setNegativeButton(this.buttontxt, this);
            } else {
                builder.setNegativeButton("Yes!", this);
            }
            builder.setCancelable(false);
            builder.create();
            return builder.show();
        } catch (Exception e) {
            Log.e(IConstants.TAG, "Error : " + e.toString());
            return null;
        }
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialog2, int which) {
        try {
            switch (which) {
                case -2:
                    this.event = "1";
                    dialog2.dismiss();
                    new Thread(this.runnable, "dialogclick").start();
                    if (Airpush.adCallbackListener != null) {
                        Airpush.adCallbackListener.onSmartWallAdClosed();
                        break;
                    }
                    break;
                case -1:
                    this.event = "0";
                    dialog2.dismiss();
                    new Thread(this.runnable, "dialogclick").start();
                    if (Airpush.adCallbackListener != null) {
                        Airpush.adCallbackListener.onSmartWallAdClosed();
                        break;
                    }
                    break;
                default:
                    return;
            }
        } catch (Exception e) {
        }
    }

    void handleClicks() {
        try {
            if (this.adtype.equalsIgnoreCase(IConstants.AD_TYPE_DAU)) {
                Log.i(IConstants.TAG, "Pushing dialog DAU Ads.....");
                try {
                    try {
                        Intent internetIntent = new Intent("android.intent.action.VIEW", Uri.parse(this.url));
                        internetIntent.setFlags(268435456);
                        internetIntent.addFlags(8388608);
                        internetIntent.addCategory("android.intent.category.LAUNCHER");
                        internetIntent.setClassName("com.android.browser", "com.android.browser.BrowserActivity");
                        this.activity.startActivity(internetIntent);
                    } catch (ActivityNotFoundException e) {
                        try {
                            Log.i(IConstants.TAG, "Browser not found.");
                            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(this.url));
                            intent.setFlags(268435456);
                            intent.addFlags(8388608);
                            this.activity.startActivity(intent);
                        } catch (ActivityNotFoundException e2) {
                            Log.e(IConstants.TAG, "Error whlie displaying dialog ad......: " + e2.getMessage());
                        }
                    }
                } catch (Exception e3) {
                    e3.printStackTrace();
                }
            } else {
                if (this.adtype.equalsIgnoreCase(IConstants.AD_TYPE_DCC)) {
                    Log.i(IConstants.TAG, "Pushing dialog CC Ads.....");
                    try {
                        Uri uri = Uri.parse("tel:" + this.number);
                        Intent intent2 = new Intent("android.intent.action.DIAL", uri);
                        intent2.addFlags(268435456);
                        this.activity.startActivity(intent2);
                    } catch (ActivityNotFoundException e4) {
                        e4.printStackTrace();
                    } catch (Exception e5) {
                    }
                    try {
                        dialog.dismiss();
                        this.activity.finish();
                    } catch (Exception e6) {
                        return;
                    }
                }
                if (this.adtype.equalsIgnoreCase(IConstants.AD_TYPE_DCM)) {
                    try {
                        Log.i(IConstants.TAG, "Pushing dialog CM Ads.....");
                        Intent intent3 = new Intent("android.intent.action.VIEW");
                        intent3.addFlags(268435456);
                        intent3.setType("vnd.android-dir/mms-sms");
                        intent3.putExtra("address", this.number);
                        intent3.putExtra("sms_body", this.sms);
                        this.activity.startActivity(intent3);
                    } catch (Exception e7) {
                        e7.printStackTrace();
                    }
                } else {
                    Log.w(IConstants.TAG, "Invalid ad type for dialog ad." + this.adtype);
                }
                dialog.dismiss();
                this.activity.finish();
            }
        } finally {
            try {
                dialog.dismiss();
                this.activity.finish();
            } catch (Exception e8) {
            }
        }
    }

    public static AlertDialog getDialog() {
        return dialog;
    }
}
