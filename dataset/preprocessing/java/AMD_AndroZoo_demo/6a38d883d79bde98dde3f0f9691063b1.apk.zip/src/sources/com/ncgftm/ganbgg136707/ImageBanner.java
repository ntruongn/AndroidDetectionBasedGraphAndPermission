package com.ncgftm.ganbgg136707;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import com.ncgftm.ganbgg136707.AdView;
import com.ncgftm.ganbgg136707.FormatAds;
import com.ncgftm.ganbgg136707.IConstants;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class ImageBanner extends WebView {
    private final String TAG;
    private AdView adView;
    private AdView.AnimationDrawListener animationDrawListener;
    private FormatAds.ParseBannerAd bannerAd;
    private boolean isClicked;
    private boolean isTestMode;

    @SuppressLint({"InlinedApi"})
    void plugin() {
        if (Build.VERSION.SDK_INT >= 8) {
            getSettings().setPluginState(WebSettings.PluginState.ON_DEMAND);
        } else {
            getSettings().setPluginsEnabled(true);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public ImageBanner(final Context context, int newWidth, int newHeight, final Handler loadingListener, FormatAds.ParseBannerAd ad, AdView.AnimationDrawListener animationListener, boolean isTestMode, AdView adView) {
        super(context);
        this.TAG = IMraid.TAG;
        try {
            this.isTestMode = isTestMode;
            this.animationDrawListener = animationListener;
            this.adView = adView;
            this.bannerAd = ad;
            setVerticalScrollBarEnabled(false);
            setHorizontalScrollBarEnabled(false);
            setScrollBarStyle(33554432);
            getSettings().setJavaScriptEnabled(true);
            plugin();
            setBackgroundColor(0);
            WebViewClient webViewClient = new WebViewClient() { // from class: com.ncgftm.ganbgg136707.ImageBanner.1
                boolean error = false;

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    if ((ImageBanner.this.bannerAd.isJsAd() || ImageBanner.this.bannerAd.isHtmlAd() || ImageBanner.this.bannerAd.isInlineScript() || ImageBanner.this.bannerAd.isPlainUrl()) && ImageBanner.this.isClicked && !url.equals(ImageBanner.this.bannerAd.getTag())) {
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                        intent.setFlags(268435456);
                        intent.addFlags(8388608);
                        context.startActivity(intent);
                        ImageBanner.this.isClicked = false;
                    } else {
                        view.loadUrl(url);
                    }
                    return true;
                }

                @Override // android.webkit.WebViewClient
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    this.error = true;
                    ImageBanner.this.sendImpression(IMraid.MRAID_EVENT_ERROR);
                    if (loadingListener != null) {
                        loadingListener.sendEmptyMessage(8);
                        Util.printDebugLog("Error in ad loading.");
                    }
                    if (AdView.adListener != null) {
                        AdView.adListener.onErrorListener(description);
                    }
                    super.onReceivedError(view, errorCode, description, failingUrl);
                }

                @Override // android.webkit.WebViewClient
                public void onPageFinished(WebView view, String url) {
                    if (!this.error && loadingListener != null) {
                        loadingListener.sendEmptyMessage(0);
                        Util.printDebugLog("Ad loading complete");
                    }
                    ImageBanner.this.sendImpression("14");
                    if (AdView.adListener != null) {
                        AdView.adListener.onAdLoadedListener();
                    }
                }
            };
            setWebViewClient(webViewClient);
            if (Build.VERSION.SDK_INT >= 11) {
                try {
                    try {
                        Method setLayerTypeMethod = getClass().getMethod("setLayerType", Integer.TYPE, Paint.class);
                        setLayerTypeMethod.invoke(this, 1, null);
                    } catch (NoSuchMethodException e) {
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                } catch (IllegalAccessException e3) {
                    e3.printStackTrace();
                } catch (IllegalArgumentException e4) {
                    e4.printStackTrace();
                } catch (InvocationTargetException e5) {
                    e5.printStackTrace();
                }
            }
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(this.adView.getadWidth(), this.adView.getadHeight());
            if (this.bannerAd.isInlineScript()) {
                setLayoutParams(layoutParams);
                loadDataWithBaseURL(null, this.bannerAd.getTag(), "text/html", "UTF-8", null);
            } else if (this.bannerAd.isPlainUrl()) {
                setLayoutParams(layoutParams);
                if (this.bannerAd.getTag() != null && !this.bannerAd.getTag().equals("")) {
                    loadUrl(this.bannerAd.getTag());
                } else {
                    Log.e(IMraid.TAG, "Url is null");
                }
            } else if (this.bannerAd.isJsAd()) {
                setLayoutParams(layoutParams);
                StringBuilder content = new StringBuilder();
                content.append("<html><head>" + this.bannerAd.getTag() + "<style>* {margin:0;padding:0; width: " + newWidth + "; height: " + newHeight + ";}</style></head><body>").append("</body></html>");
                loadDataWithBaseURL(null, content.toString(), "text/html", "UTF-8", null);
            } else if (this.bannerAd.isHtmlAd()) {
                setLayoutParams(layoutParams);
                StringBuilder content2 = new StringBuilder();
                content2.append("<html><head><style>* {margin:0;padding:0; width: " + newWidth + "; height: " + newHeight + ";}</style></head><body>").append(this.bannerAd.getTag()).append("</body></html>");
                loadDataWithBaseURL(null, content2.toString(), "text/html", "UTF-8", null);
            } else if (this.bannerAd.getBanner_type().equals("text")) {
                StringBuilder builder = new StringBuilder();
                builder.append("<html><head><style>* {margin:0;}</style></head><body>");
                builder.append("<div style='background-color: " + this.bannerAd.getBanner_bg() + "; width: " + newWidth + "; height: " + newHeight + ";'><table><tr>");
                builder.append("<td rowspan='2' align='center'><img alt='icon' style='padding: 2' src='" + this.bannerAd.getAdimage() + "'></td>");
                builder.append("<td><font color='" + this.bannerAd.getTextColor() + "'><b>" + this.bannerAd.getTitle() + "</b><br></font>");
                builder.append("</td><tr><td><font size=2 color='" + this.bannerAd.getTextColor() + "'>" + this.bannerAd.getText() + "</font></td></tr>");
                builder.append("</table></div></body></html>");
                loadDataWithBaseURL(null, builder.toString(), "text/html", "UTF-8", null);
            } else {
                StringBuilder content3 = new StringBuilder();
                content3.append("<html><head><style>* {margin:0;padding:0;}</style></head><body>").append("<img src=\"" + this.bannerAd.getAdimage() + "\" height=\"" + newHeight + "\" width=\"" + newWidth + "\"/>").append("</html></head>");
                loadDataWithBaseURL(null, content3.toString(), "text/html", "UTF-8", null);
            }
            if (!isTestMode) {
                if (this.bannerAd.getBanner_type().equals(AdView.BANNER_TYPE_IMAGE)) {
                    Util.registerApsalarEvent(context, IConstants.ApSalarEvent.banner_image);
                } else if (this.bannerAd.getBanner_type().equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE)) {
                    Util.registerApsalarEvent(context, IConstants.ApSalarEvent.banner_medium_rectangle);
                } else if (this.bannerAd.getBanner_type().equals("text")) {
                    Util.registerApsalarEvent(context, IConstants.ApSalarEvent.banner_text);
                }
            }
        } catch (Exception e6) {
            e6.printStackTrace();
            sendImpression(IMraid.MRAID_EVENT_ERROR);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == 0) {
            sendImpression("13");
            if (AdView.adListener != null) {
                AdView.adListener.onAdClickListener();
            }
            if (this.bannerAd.isJsAd() || this.bannerAd.isHtmlAd() || this.bannerAd.isInlineScript() || this.bannerAd.isPlainUrl()) {
                this.isClicked = true;
                return super.dispatchTouchEvent(event);
            }
            this.bannerAd.handleClicks();
            return true;
        }
        return super.dispatchTouchEvent(event);
    }

    @Override // android.view.View
    protected void onAnimationEnd() {
        super.onAnimationEnd();
        if (this.animationDrawListener != null) {
            this.animationDrawListener.onAnimationDrawEnd();
        }
    }

    synchronized void sendImpression(final String event) {
        synchronized (event) {
            if (this.isTestMode) {
                Util.printDebugLog("Ad in test mode. Sending ignored.");
            } else if (Util.checkInternetConnection(getContext())) {
                Thread thread = new Thread(new Runnable() { // from class: com.ncgftm.ganbgg136707.ImageBanner.2
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            Log.i(IMraid.TAG, "Sending banner impression event: ");
                            if (ImageBanner.this.bannerAd.isErrorReport() || !event.equals(IMraid.MRAID_EVENT_ERROR)) {
                                String imp_url = ImageBanner.this.bannerAd.getApi_url();
                                if (imp_url.contains("%event%")) {
                                    imp_url = imp_url.replace("%event%", event);
                                }
                                Util.printDebugLog("URL: " + imp_url);
                                HttpClient httpclient = new DefaultHttpClient();
                                HttpPost httppost = new HttpPost(imp_url);
                                BasicHttpParams basicHttpParams = new BasicHttpParams();
                                httppost.setParams(basicHttpParams);
                                HttpConnectionParams.setConnectionTimeout(basicHttpParams, 15000);
                                HttpConnectionParams.setSoTimeout(basicHttpParams, 10000);
                                HttpResponse response = httpclient.execute(httppost);
                                int code = response == null ? 0 : response.getStatusLine().getStatusCode();
                                Log.i(IMraid.TAG, "Status code: " + code);
                                if (code == 200) {
                                    String string = EntityUtils.toString(response.getEntity());
                                    Log.i(IMraid.TAG, "Banner Data: " + string);
                                    return;
                                }
                                return;
                            }
                            Util.printDebugLog("Error reporting is off.");
                        } catch (Exception e) {
                            Log.e(IMraid.TAG, "Data not sent. Exception: " + e.getMessage());
                            e.printStackTrace();
                        }
                    }
                }, "banner_event");
                thread.start();
            }
        }
    }

    @Override // android.webkit.WebView, android.widget.AbsoluteLayout, android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if (this.bannerAd != null) {
            String banner_type = this.bannerAd.getBanner_type();
            if (banner_type.equals(AdView.BANNER_TYPE_IMAGE) || banner_type.equals("text") || banner_type.equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE)) {
                setMeasuredDimension(this.adView.getadWidth(), this.adView.getadHeight());
            }
        }
    }
}
