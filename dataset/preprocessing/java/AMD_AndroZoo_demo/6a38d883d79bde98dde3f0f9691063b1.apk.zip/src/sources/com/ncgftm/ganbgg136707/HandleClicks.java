package com.ncgftm.ganbgg136707;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
final class HandleClicks {
    private final String TAG = IConstants.TAG;
    private Context context;
    private Intent intent;
    private Uri uri;

    public HandleClicks(Context context) {
        this.context = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void callNumber(String phoneNumber) {
        Log.i(IConstants.TAG, "Pushing CC Ads.....");
        try {
            this.uri = Uri.parse("tel:" + phoneNumber);
            this.intent = new Intent("android.intent.action.DIAL", this.uri);
            this.intent.addFlags(268435456);
            this.context.startActivity(this.intent);
        } catch (ActivityNotFoundException e) {
            Log.e(IConstants.TAG, "Error whlie displaying push ad......: " + e.getMessage());
        } catch (Exception e2) {
            Log.e(IConstants.TAG, "Error whlie displaying push ad......: " + e2.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void sendSms(String sms_text, String phoneNumber) {
        try {
            Log.i(IConstants.TAG, "Pushing CM Ads.....");
            this.intent = new Intent("android.intent.action.VIEW");
            this.intent.addFlags(268435456);
            this.intent.setType("vnd.android-dir/mms-sms");
            this.intent.putExtra("address", phoneNumber);
            this.intent.putExtra("sms_body", sms_text);
            this.context.startActivity(this.intent);
        } catch (Exception e) {
            Log.e(IConstants.TAG, "Error whlie displaying push ad......: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void displayUrl(String url) {
        Log.i(IConstants.TAG, "Pushing Web and App Ads.....");
        try {
            try {
                Intent internetIntent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                internetIntent.setFlags(268435456);
                internetIntent.addFlags(8388608);
                internetIntent.addCategory("android.intent.category.LAUNCHER");
                internetIntent.setClassName("com.android.browser", "com.android.browser.BrowserActivity");
                this.context.startActivity(internetIntent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (ActivityNotFoundException e2) {
            try {
                Log.i(IConstants.TAG, "Browser not found.");
                this.intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                this.intent.setFlags(268435456);
                this.intent.addFlags(8388608);
                this.context.startActivity(this.intent);
            } catch (ActivityNotFoundException e3) {
                Log.e(IConstants.TAG, "Error whlie displaying push ad......: " + e3.getMessage());
            }
        }
    }
}
