package com.bugsense.trace.models;

import android.util.Log;
import com.bugsense.trace.BugSense;
import com.bugsense.trace.BugSenseHandler;
import com.bugsense.trace.CryptoHttpClient;
import com.bugsense.trace.G;
import com.bugsense.trace.Utils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public final class EventsMechanism {
    private static final int MAX_BYTES = 256;
    private static final int MAX_EVENTS_SIZE = 12;
    private static volatile EventsMechanism instance;

    public static String getFlatLine(String str) {
        if (str.getBytes().length > MAX_BYTES) {
            str = str.substring(0, MAX_BYTES);
        }
        if (str.equals("_ping") || str.equals("_gnip")) {
            str = str.replaceAll("_", "-");
        }
        if (str.contains(":") || str.contains("|")) {
            str = str.replaceAll(":", "_").replace("|", "_");
        }
        int length = 256 - ("3.2.1:".getBytes().length + (":" + G.PHONE_MODEL + ":" + G.PHONE_BRAND + ":" + G.ANDROID_VERSION + ":" + G.APP_VERSION + ":" + Locale.getDefault().getDisplayLanguage() + ":" + Utils.getTime()).getBytes().length);
        if (str.getBytes().length > length) {
            str = str.substring(0, length);
        }
        return "3.2.1:" + str + ":" + G.PHONE_MODEL + ":" + G.PHONE_BRAND + ":" + G.ANDROID_VERSION + ":" + G.APP_VERSION + ":" + Locale.getDefault().getDisplayLanguage() + ":" + Utils.getTime();
    }

    public static EventsMechanism getInstance() {
        if (instance == null) {
            instance = new EventsMechanism();
        }
        return instance;
    }

    public static void saveEvent(final String str) {
        Thread thread = new Thread(new Runnable() { // from class: com.bugsense.trace.models.EventsMechanism.2
            @Override // java.lang.Runnable
            public void run() {
                String flatLine = EventsMechanism.getFlatLine(str);
                try {
                    BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(G.FILES_PATH + "/" + ("Event_" + String.valueOf(System.currentTimeMillis()) + "-" + Integer.toString(new Random(System.currentTimeMillis()).nextInt(99999)))));
                    bufferedWriter.write(flatLine);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                } catch (IOException e) {
                    Log.e(G.TAG, "Error saving event data");
                    if (BugSenseHandler.I_WANT_TO_DEBUG) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ExecutorService executor = BugSense.getExecutor();
        if (thread == null || executor == null) {
            return;
        }
        executor.submit(thread);
    }

    public static boolean transmitEventSync(String str) {
        if (BugSenseHandler.I_WANT_TO_DEBUG) {
            Log.d(G.TAG, "URL: " + G.ANALYTICS_URL);
            Log.d(G.TAG, "APIKEY: " + G.API_KEY);
        }
        try {
            DefaultHttpClient cryptoHttpClient = G.ANALYTICS_URL.startsWith("https://") ? new CryptoHttpClient(0) : new DefaultHttpClient();
            HttpParams params = cryptoHttpClient.getParams();
            HttpProtocolParams.setUseExpectContinue(params, false);
            HttpConnectionParams.setConnectionTimeout(params, 20000);
            HttpConnectionParams.setSoTimeout(params, 20000);
            HttpPost httpPost = new HttpPost(G.ANALYTICS_URL);
            httpPost.addHeader("X-BugSense-Api-Key", G.API_KEY);
            new ArrayList().add(new BasicNameValuePair("data", str));
            httpPost.setEntity(new StringEntity(str));
            HttpEntity entity = cryptoHttpClient.execute(httpPost).getEntity();
            if (entity == null) {
                Log.w(G.TAG, "It seems that there is no internet connectivity");
                throw new Exception("no internet connection");
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(entity.getContent()));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine);
            }
            if (BugSenseHandler.I_WANT_TO_DEBUG) {
                Log.i(G.TAG, "Event Response: " + sb.toString());
            }
            return true;
        } catch (Exception e) {
            Log.w(G.TAG, "Transmitting ping Exception " + e.getMessage());
            if (!BugSenseHandler.I_WANT_TO_DEBUG) {
                return false;
            }
            e.printStackTrace();
            return false;
        }
    }

    public synchronized void sendSavedEvents() {
        Thread thread = new Thread(new Runnable() { // from class: com.bugsense.trace.models.EventsMechanism.1
            @Override // java.lang.Runnable
            public void run() {
                File file = new File(G.FILES_PATH);
                if (!file.exists()) {
                    file.mkdir();
                }
                String[] list = file.list(new FilenameFilter() { // from class: com.bugsense.trace.models.EventsMechanism.1.1
                    @Override // java.io.FilenameFilter
                    public boolean accept(File file2, String str) {
                        return str.startsWith("Event_");
                    }
                });
                if (BugSenseHandler.I_WANT_TO_DEBUG) {
                    Log.d(G.TAG, "Events List has: " + list.length + " items");
                }
                int i = EventsMechanism.MAX_EVENTS_SIZE;
                if (EventsMechanism.MAX_EVENTS_SIZE > list.length) {
                    i = list.length;
                }
                int i2 = 0;
                while (i2 < i && EventsMechanism.transmitEventSync(Utils.readFile(G.FILES_PATH + "/" + list[i2]))) {
                    i2++;
                }
                if (i2 >= 1) {
                    for (int i3 = 0; i3 < list.length; i3++) {
                        try {
                            new File(G.FILES_PATH + "/" + list[i3]).delete();
                        } catch (Exception e) {
                            Log.e(G.TAG, "Error deleting trace file: " + G.FILES_PATH + "/" + list[i3], e);
                        }
                    }
                }
            }
        });
        ExecutorService executor = BugSense.getExecutor();
        if (thread != null && executor != null) {
            executor.submit(thread);
        }
    }
}
