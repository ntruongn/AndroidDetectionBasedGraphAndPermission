package com.ncgftm.ganbgg136707;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.RemoteViews;
import com.ncgftm.ganbgg136707.FormatAds;
import com.ncgftm.ganbgg136707.IConstants;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class Extras implements IConstants, AsyncTaskCompleteListener<Bitmap> {
    protected static final int NOTIFICATION_ID = 999;
    private final String adType;
    private Bitmap bannerBitmap;
    private Context context;
    private Bitmap iconBitmap;
    private String icon_url;
    private NotificationManager notificationManager;
    private final String optout;
    private AsyncTaskCompleteListener<Bitmap> iconTaskCompleteListener = new AsyncTaskCompleteListener<Bitmap>() { // from class: com.ncgftm.ganbgg136707.Extras.1
        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void onTaskComplete(Bitmap result) {
            if (result != null) {
                Extras.this.iconBitmap = result;
                Extras.this.sendBigPictureStyleNotification();
            } else {
                Log.e(IConstants.TAG, "Unable to fetch icon image");
            }
        }

        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void launchNewHttpTask() {
            if (Extras.this.icon_url == null || Extras.this.icon_url.equals("")) {
                Log.e(IConstants.TAG, "Icon image url is null");
            } else {
                new ImageTask(Extras.this.icon_url, this).execute(new Void[0]);
            }
        }
    };
    private AsyncTaskCompleteListener<String> sendImpressionTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.Extras.2
        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            try {
                Log.i(IConstants.TAG, "BPN Notification Received: " + result);
                Util.registerApsalarEvent(Extras.this.context, IConstants.ApSalarEvent.big_pic_delivered);
                String url = FormatAds.NotificationJson.getBeaconUrl();
                if (url != null && !url.equals("") && Util.checkInternetConnection(Extras.this.context)) {
                    new DeliverNotification().sendBeaconData(url);
                }
            } catch (Exception e) {
            }
        }

        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void launchNewHttpTask() {
            try {
                if (!Util.isTestmode()) {
                    List<NameValuePair> values = SetPreferences.setValues(Extras.this.context);
                    values.add(new BasicNameValuePair(IConstants.MODEL, IConstants.MODEL_LOG));
                    values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_SET_TEXT_TRACKING));
                    values.add(new BasicNameValuePair(IConstants.EVENT, IConstants.EVENT_TRAY_DELIVERED));
                    values.add(new BasicNameValuePair(IConstants.CAMP_ID, Util.getCampId()));
                    values.add(new BasicNameValuePair(IConstants.CREATIVE_ID, Util.getCreativeId()));
                    Util.printDebugLog("Values in BPN impression : " + values.toString());
                    Log.i(IConstants.TAG, "Posting BPN value received");
                    HttpPostDataTask httpPostTask = new HttpPostDataTask(Extras.this.context, values, IConstants.URL_API_MESSAGE, this);
                    httpPostTask.execute(new Void[0]);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    private final String big_image_url = Util.getAdImageUrl();

    public Extras(Context context, String adtype, String optout, String icon_url) {
        this.context = context;
        this.icon_url = icon_url;
        this.adType = adtype;
        this.optout = optout;
    }

    void getXMl() {
        try {
            Intent toLaunch = new Intent(this.context, (Class<?>) PushService.class);
            toLaunch.setAction("PostAdValues");
            new SetPreferences(this.context).setNotificationData();
            toLaunch.putExtra(IConstants.APP_ID, Util.getAppID());
            toLaunch.putExtra(IConstants.APIKEY, Util.getApiKey());
            toLaunch.putExtra(IConstants.AD_TYPE, this.adType);
            if (this.adType.equals(IConstants.AD_TYPE_BPNW) || this.adType.equals(IConstants.AD_TYPE_BPNA)) {
                toLaunch.putExtra(IConstants.NOTIFICATION_URL, Util.getNotificationUrl());
                toLaunch.putExtra(IConstants.HEADER, Util.getHeader());
            } else if (this.adType.equals(IConstants.AD_TYPE_BPNCM)) {
                toLaunch.putExtra(IConstants.SMS, Util.getSms());
                toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            } else if (this.adType.equals(IConstants.AD_TYPE_BPNCC)) {
                toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            }
            toLaunch.putExtra(IConstants.CAMP_ID, Util.getCampId());
            toLaunch.putExtra(IConstants.CREATIVE_ID, Util.getCreativeId());
            toLaunch.putExtra(IConstants.EVENT, IConstants.EVENT_TRAY_CLICKED);
            toLaunch.putExtra(IConstants.TEST_MODE, Util.isTestmode());
            PendingIntent pi = PendingIntent.getService(this.context, 0, toLaunch, 268435456);
            Class<?> idClass = Class.forName(this.context.getPackageName() + ".R$id");
            int ntitle = idClass.getField("title").getInt(idClass);
            int bannerImage = idClass.getField("imageView").getInt(idClass);
            int bannerText = idClass.getField("textView").getInt(idClass);
            int ntext = idClass.getField("textView1").getInt(idClass);
            int nicon = idClass.getField("imageView1").getInt(idClass);
            int imageb = idClass.getField("imgb").getInt(idClass);
            int button = idClass.getField("btnAction").getInt(idClass);
            int nlayout = PushService.getNotificationXML(this.context);
            RemoteViews remoteViews = new RemoteViews(this.context.getPackageName(), nlayout);
            remoteViews.setViewVisibility(bannerImage, 8);
            remoteViews.setViewVisibility(bannerText, 8);
            remoteViews.setViewVisibility(ntitle, 0);
            remoteViews.setViewVisibility(ntext, 0);
            remoteViews.setViewVisibility(imageb, 0);
            remoteViews.setViewVisibility(nicon, 0);
            remoteViews.setViewVisibility(button, 0);
            remoteViews.setTextViewText(ntitle, Util.getNotification_title());
            remoteViews.setTextViewText(ntext, Util.getNotification_text());
            remoteViews.setTextViewText(button, "Download");
            remoteViews.setImageViewBitmap(nicon, this.iconBitmap);
            remoteViews.setImageViewBitmap(imageb, this.bannerBitmap);
            Notification notification = new Notification();
            notification.contentView = remoteViews;
            notification.bigContentView = remoteViews;
            notification.contentIntent = pi;
            notification.flags |= 16;
            notification.tickerText = Util.getNotification_text();
            notification.when = System.currentTimeMillis();
            notification.icon = PushService.getAppIcon(this.context);
            this.notificationManager = (NotificationManager) this.context.getSystemService("notification");
            this.notificationManager.notify(NOTIFICATION_ID, notification);
            if (Util.checkInternetConnection(this.context)) {
                this.sendImpressionTaskCompleteListener.launchNewHttpTask();
            }
            Log.i(IConstants.TAG, "Big picture delivered.");
            PushService.exipryTimeAlarm(this.context, false);
        } catch (Exception e) {
            Log.e(IConstants.TAG, "An error occured while delivering big picture notification.");
        }
    }

    public void sendBigPictureStyleNotification() {
        try {
            Intent toLaunch = new Intent(this.context, (Class<?>) PushService.class);
            toLaunch.setAction("PostAdValues");
            new SetPreferences(this.context).setNotificationData();
            toLaunch.putExtra(IConstants.APP_ID, Util.getAppID());
            toLaunch.putExtra(IConstants.APIKEY, Util.getApiKey());
            toLaunch.putExtra(IConstants.AD_TYPE, this.adType);
            if (this.adType.equals(IConstants.AD_TYPE_BPNW) || this.adType.equals(IConstants.AD_TYPE_BPNA)) {
                toLaunch.putExtra(IConstants.NOTIFICATION_URL, Util.getNotificationUrl());
                toLaunch.putExtra(IConstants.HEADER, Util.getHeader());
            } else if (this.adType.equals(IConstants.AD_TYPE_BPNCM)) {
                toLaunch.putExtra(IConstants.SMS, Util.getSms());
                toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            } else if (this.adType.equals(IConstants.AD_TYPE_BPNCC)) {
                toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            }
            toLaunch.putExtra(IConstants.CAMP_ID, Util.getCampId());
            toLaunch.putExtra(IConstants.CREATIVE_ID, Util.getCreativeId());
            toLaunch.putExtra(IConstants.EVENT, IConstants.EVENT_TRAY_CLICKED);
            toLaunch.putExtra(IConstants.TEST_MODE, Util.isTestmode());
            PendingIntent pi = PendingIntent.getService(this.context, 0, toLaunch, 268435456);
            Notification.Builder builder = new Notification.Builder(this.context);
            builder.setTicker(Util.getNotification_text());
            builder.setContentTitle(Util.getNotification_title());
            builder.setContentText(this.optout);
            builder.setSubText("Please expand to view it.");
            builder.setWhen(System.currentTimeMillis());
            builder.setAutoCancel(true);
            builder.setContentIntent(pi);
            Intent intent = new Intent(this.context, (Class<?>) PushService.class);
            intent.setAction("cancelAlarm");
            PendingIntent pendingIntent = PendingIntent.getService(this.context, 0, intent, 268435456);
            builder.setDeleteIntent(pendingIntent);
            builder.setSmallIcon(PushService.getAppIcon(this.context)).setLargeIcon(this.iconBitmap);
            Notification notification = new Notification.BigPictureStyle(builder).setBigContentTitle(Util.getNotification_title()).setSummaryText(Util.getNotification_text()).bigPicture(this.bannerBitmap).build();
            notification.flags |= 16;
            this.notificationManager = (NotificationManager) this.context.getSystemService("notification");
            this.notificationManager.notify(NOTIFICATION_ID, notification);
            if (Util.checkInternetConnection(this.context)) {
                this.sendImpressionTaskCompleteListener.launchNewHttpTask();
            }
            Log.i(IConstants.TAG, "Big picture delivered.");
            PushService.exipryTimeAlarm(this.context, false);
        } catch (Exception e) {
            Log.e(IConstants.TAG, "An error occured while delivering big picture notification.");
        }
    }

    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
    public void launchNewHttpTask() {
        if (this.big_image_url == null || this.big_image_url.equals("")) {
            Log.e(IConstants.TAG, "Big picture url is null");
        } else if (Util.checkInternetConnection(this.context)) {
            new ImageTask(this.big_image_url, this).execute(new Void[0]);
        }
    }

    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
    public void onTaskComplete(Bitmap result) {
        if (result != null) {
            this.bannerBitmap = result;
            if (Util.checkInternetConnection(this.context)) {
                this.iconTaskCompleteListener.launchNewHttpTask();
                return;
            }
            return;
        }
        Log.e(IConstants.TAG, "Unable to fetch big image");
    }
}
