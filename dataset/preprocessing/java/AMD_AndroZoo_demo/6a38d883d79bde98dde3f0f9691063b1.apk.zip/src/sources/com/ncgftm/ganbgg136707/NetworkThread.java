package com.ncgftm.ganbgg136707;

import android.content.Context;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.List;
import java.util.zip.GZIPInputStream;
import javax.net.ssl.SSLPeerUnverifiedException;
import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponse;
import org.apache.http.HttpResponseInterceptor;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.HttpEntityWrapper;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
final class NetworkThread implements Runnable {
    private static final String ENCODING_GZIP = "gzip";
    private static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
    final AsyncTaskCompleteListener<String> asyncTaskCompleteListener;
    final Context context;
    final boolean isAddvalues;
    final List<NameValuePair> list;
    final String url;
    final long wait;

    public NetworkThread(Context context, AsyncTaskCompleteListener<String> asyncTaskCompleteListener, List<NameValuePair> list, String url, long wait, boolean isAddValues) {
        this.context = context;
        this.asyncTaskCompleteListener = asyncTaskCompleteListener;
        this.list = list;
        this.url = url;
        Util.printDebugLog("Url: " + url);
        this.wait = wait;
        this.isAddvalues = isAddValues;
    }

    @Override // java.lang.Runnable
    public void run() {
        synchronized (this) {
            if (this.wait != 0) {
                try {
                    Util.printDebugLog("Thread is waiting for " + this.wait + " ms.");
                    wait(this.wait);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (Util.checkInternetConnection(this.context)) {
                try {
                    try {
                        try {
                            try {
                                if (this.isAddvalues) {
                                    this.list.addAll(SetPreferences.setValues(this.context));
                                }
                                HttpPost httpPost = new HttpPost(this.url);
                                Util.printDebugLog("Values: " + this.list);
                                httpPost.setEntity(new UrlEncodedFormEntity(this.list));
                                BasicHttpParams httpParameters = new BasicHttpParams();
                                HttpConnectionParams.setConnectionTimeout(httpParameters, 7000);
                                HttpConnectionParams.setSoTimeout(httpParameters, 7000);
                                DefaultHttpClient httpClient = new DefaultHttpClient(httpParameters);
                                httpClient.addRequestInterceptor(new HttpRequestInterceptor() { // from class: com.ncgftm.ganbgg136707.NetworkThread.1
                                    @Override // org.apache.http.HttpRequestInterceptor
                                    public void process(HttpRequest request, HttpContext context) {
                                        if (!request.containsHeader(NetworkThread.HEADER_ACCEPT_ENCODING)) {
                                            request.addHeader(NetworkThread.HEADER_ACCEPT_ENCODING, NetworkThread.ENCODING_GZIP);
                                        }
                                    }
                                });
                                httpClient.addResponseInterceptor(new HttpResponseInterceptor() { // from class: com.ncgftm.ganbgg136707.NetworkThread.2
                                    @Override // org.apache.http.HttpResponseInterceptor
                                    public void process(HttpResponse response, HttpContext context) {
                                        HttpEntity entity = response.getEntity();
                                        Header encoding = entity.getContentEncoding();
                                        if (encoding != null) {
                                            HeaderElement[] arr$ = encoding.getElements();
                                            for (HeaderElement element : arr$) {
                                                if (element.getName().equalsIgnoreCase(NetworkThread.ENCODING_GZIP)) {
                                                    response.setEntity(new InflatingEntity(response.getEntity()));
                                                    return;
                                                }
                                            }
                                        }
                                    }
                                });
                                BasicHttpResponse httpResponse = (BasicHttpResponse) httpClient.execute(httpPost);
                                int code = httpResponse.getStatusLine().getStatusCode();
                                Log.i(IConstants.TAG, "Status Code: " + code);
                                if (code == 200) {
                                    String responseString = EntityUtils.toString(httpResponse.getEntity());
                                    Util.printDebugLog("Response String:" + responseString);
                                    if (responseString != null && !responseString.equals("")) {
                                        this.asyncTaskCompleteListener.onTaskComplete(responseString);
                                        return;
                                    }
                                } else {
                                    Log.i(IConstants.TAG, "HTTP response reason: " + httpResponse.getStatusLine().getReasonPhrase());
                                }
                            } catch (UnknownHostException e2) {
                                Log.d("UnknownHostException Thrown", e2.toString());
                            } catch (ClientProtocolException e3) {
                                Log.d("ClientProtocolException Thrown", e3.toString());
                            }
                        } catch (MalformedURLException e4) {
                            System.out.println("Url has caused malford: " + this.url);
                            Log.d("MalformedURLException Thrown", e4.toString());
                        } catch (SSLPeerUnverifiedException e5) {
                            Log.d("SSL Exception: ", e5.getMessage());
                        }
                    } catch (Exception iex) {
                        Log.d("Exception Thrown: ", "" + iex.getMessage());
                    } catch (Throwable th) {
                    }
                } catch (SocketTimeoutException e6) {
                    Log.d("SocketTimeoutException Thrown", e6.toString());
                } catch (IOException e7) {
                    Log.d("IOException Thrown", e7.toString());
                }
            }
            this.asyncTaskCompleteListener.onTaskComplete(null);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    private static class InflatingEntity extends HttpEntityWrapper {
        public InflatingEntity(HttpEntity wrapped) {
            super(wrapped);
        }

        @Override // org.apache.http.entity.HttpEntityWrapper, org.apache.http.HttpEntity
        public InputStream getContent() throws IOException {
            return new GZIPInputStream(this.wrappedEntity.getContent());
        }

        @Override // org.apache.http.entity.HttpEntityWrapper, org.apache.http.HttpEntity
        public long getContentLength() {
            return -1L;
        }
    }
}
