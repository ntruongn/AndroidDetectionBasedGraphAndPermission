package com.bugsense.trace;

import android.os.AsyncTask;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public abstract class ActivityAsyncTask<Connect, Params, Progress, Result> extends AsyncTask<Params, Progress, Result> {
    private volatile boolean mPostProcessingDone = false;
    private Result mResult;
    protected volatile Connect mWrapped;

    public ActivityAsyncTask(Connect connect) {
        connectTo(connect);
    }

    public void connectTo(Connect connect) {
        if (this.mWrapped != null && connect != null) {
            throw new IllegalStateException();
        }
        this.mWrapped = connect;
        if (this.mWrapped != null) {
            if (getStatus() == AsyncTask.Status.RUNNING) {
                onPreExecute();
            } else {
                if (getStatus() != AsyncTask.Status.FINISHED || this.mPostProcessingDone) {
                    return;
                }
                this.mPostProcessingDone = true;
                processPostExecute(this.mResult);
                this.mResult = null;
            }
        }
    }

    @Override // android.os.AsyncTask
    protected void onPostExecute(Result result) {
        super.onPostExecute(result);
        if (this.mWrapped == null) {
            this.mResult = result;
        } else {
            this.mPostProcessingDone = true;
            processPostExecute(result);
        }
    }

    public boolean postProcessingDone() {
        return this.mPostProcessingDone;
    }

    protected abstract void processPostExecute(Result result);
}
