package com.ncgftm.ganbgg136707;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.RemoteViews;
import com.ncgftm.ganbgg136707.FormatAds;
import com.ncgftm.ganbgg136707.IConstants;
import java.util.List;
import java.util.Random;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class DeliverNotification implements IConstants {
    private static final int NOTIFICATION_ID = 999;
    private static Bitmap bmpIcon;
    private String adType;
    private Context context;
    private CharSequence text;
    private CharSequence title;
    AsyncTaskCompleteListener<Bitmap> asyncTaskCompleteListener = new AsyncTaskCompleteListener<Bitmap>() { // from class: com.ncgftm.ganbgg136707.DeliverNotification.1
        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void onTaskComplete(Bitmap result) {
            Bitmap unused = DeliverNotification.bmpIcon = result;
            if (DeliverNotification.this.adType.contains(IConstants.BP_AD_TYPE_WEB) || DeliverNotification.this.adType.contains(IConstants.BP_AD_TYPE_CM) || DeliverNotification.this.adType.contains(IConstants.BP_AD_TYPE_CC) || DeliverNotification.this.adType.contains(IConstants.BP_AD_TYPE_APP)) {
                Util.printDebugLog("BannerPush Type: " + DeliverNotification.this.adType);
                DeliverNotification.this.notifyUsers(DeliverNotification.this.context);
            } else {
                DeliverNotification.this.deliverNotification();
            }
        }

        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void launchNewHttpTask() {
            ImageTask imageTask = new ImageTask(Util.getAdImageUrl(), this);
            imageTask.execute(new Void[0]);
        }
    };
    AsyncTaskCompleteListener<String> sendImpressionTask = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.DeliverNotification.2
        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            try {
                Log.i(IConstants.TAG, "Notification Received : " + result);
                if (DeliverNotification.this.adType.equals(IConstants.AD_TYPE_APP) || DeliverNotification.this.adType.equals(IConstants.AD_TYPE_WEB) || DeliverNotification.this.adType.equals(IConstants.AD_TYPE_CC) || DeliverNotification.this.adType.equals(IConstants.AD_TYPE_CM)) {
                    Util.registerApsalarEvent(DeliverNotification.this.context, IConstants.ApSalarEvent.text_push_delivered);
                } else {
                    Util.registerApsalarEvent(DeliverNotification.this.context, IConstants.ApSalarEvent.banner_push_delivered);
                }
                String url = FormatAds.NotificationJson.getBeaconUrl();
                if (url != null && !url.equals("") && Util.checkInternetConnection(DeliverNotification.this.context)) {
                    DeliverNotification.this.sendBeaconData(url);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void launchNewHttpTask() {
            try {
                if (!Util.isTestmode()) {
                    List<NameValuePair> values = SetPreferences.setValues(DeliverNotification.this.context);
                    values.add(new BasicNameValuePair(IConstants.MODEL, IConstants.MODEL_LOG));
                    values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_SET_TEXT_TRACKING));
                    values.add(new BasicNameValuePair(IConstants.EVENT, IConstants.EVENT_TRAY_DELIVERED));
                    values.add(new BasicNameValuePair(IConstants.CAMP_ID, Util.getCampId()));
                    values.add(new BasicNameValuePair(IConstants.CREATIVE_ID, Util.getCreativeId()));
                    Util.printDebugLog("Values in PushService : " + values.toString());
                    Log.i(IConstants.TAG, "Posting Notification value received");
                    HttpPostDataTask httpPostTask = new HttpPostDataTask(DeliverNotification.this.context, values, IConstants.URL_API_MESSAGE, this);
                    httpPostTask.execute(new Void[0]);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    public DeliverNotification() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public DeliverNotification(Context context) {
        this.context = context;
        if (context == null) {
            Util.getContext();
        }
        Util.setIcon(selectIcon());
        this.adType = Util.getAdType();
        this.text = Util.getNotification_text();
        this.title = Util.getNotification_title();
        this.asyncTaskCompleteListener.launchNewHttpTask();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void deliverNotification() {
        try {
            Class<?> idClass = Class.forName(this.context.getPackageName() + ".R$id");
            int ntitle = idClass.getField("title").getInt(idClass);
            int bannerImage = idClass.getField("imageView").getInt(idClass);
            int bannerText = idClass.getField("textView").getInt(idClass);
            int ntext = idClass.getField("textView1").getInt(idClass);
            int nicon = idClass.getField("imageView1").getInt(idClass);
            int nlayout = PushService.getNotificationXML(this.context);
            if (nlayout != 0) {
                PackageInfo p = this.context.getPackageManager().getPackageInfo(Util.getPackageName(this.context), 128);
                int iconid = p.applicationInfo.icon;
                if (iconid == 0) {
                    iconid = Util.getIcon();
                }
                CharSequence text1 = this.text;
                CharSequence contentTitle = this.title;
                CharSequence contentText = this.text;
                long when = System.currentTimeMillis();
                Notification notification = new Notification();
                notification.icon = iconid;
                notification.tickerText = text1;
                notification.when = when;
                notification.ledARGB = -65536;
                notification.ledOffMS = 300;
                notification.ledOnMS = 300;
                Intent toLaunch = new Intent(this.context, (Class<?>) PushService.class);
                toLaunch.setAction("PostAdValues");
                new SetPreferences(this.context).setNotificationData();
                toLaunch.putExtra(IConstants.APP_ID, Util.getAppID());
                toLaunch.putExtra(IConstants.APIKEY, Util.getApiKey());
                toLaunch.putExtra(IConstants.AD_TYPE, this.adType);
                if (this.adType.equals(IConstants.AD_TYPE_WEB) || this.adType.equals(IConstants.AD_TYPE_APP)) {
                    toLaunch.putExtra(IConstants.NOTIFICATION_URL, Util.getNotificationUrl());
                    toLaunch.putExtra(IConstants.HEADER, Util.getHeader());
                } else if (this.adType.equals(IConstants.AD_TYPE_CM)) {
                    toLaunch.putExtra(IConstants.SMS, Util.getSms());
                    toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
                } else if (this.adType.equals(IConstants.AD_TYPE_CC)) {
                    toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
                }
                toLaunch.putExtra(IConstants.CAMP_ID, Util.getCampId());
                toLaunch.putExtra(IConstants.CREATIVE_ID, Util.getCreativeId());
                toLaunch.putExtra(IConstants.EVENT, IConstants.EVENT_TRAY_CLICKED);
                toLaunch.putExtra(IConstants.TEST_MODE, Util.isTestmode());
                PendingIntent intentBack = PendingIntent.getService(this.context, 0, toLaunch, 268435456);
                notification.defaults |= 4;
                notification.flags |= 16;
                notification.contentView = new RemoteViews(this.context.getPackageName(), nlayout);
                notification.contentView.setViewVisibility(bannerText, 8);
                notification.contentView.setViewVisibility(bannerImage, 8);
                if (bmpIcon != null) {
                    notification.contentView.setImageViewBitmap(nicon, bmpIcon);
                } else {
                    notification.contentView.setImageViewResource(nicon, Util.getIcon());
                }
                notification.contentView.setViewVisibility(nicon, 0);
                notification.contentView.setTextViewText(ntitle, contentTitle);
                notification.contentView.setViewVisibility(ntitle, 0);
                notification.contentView.setTextViewText(ntext, contentText);
                notification.contentView.setViewVisibility(ntext, 0);
                notification.contentIntent = intentBack;
                Intent intent = new Intent(this.context, (Class<?>) PushService.class);
                intent.setAction("cancelAlarm");
                PendingIntent delPendingIntent = PendingIntent.getService(this.context, 0, intent, 268435456);
                notification.deleteIntent = delPendingIntent;
                NotificationManager notificationManager = (NotificationManager) this.context.getSystemService("notification");
                notificationManager.notify(NOTIFICATION_ID, notification);
                Log.i(IConstants.TAG, "Notification Delivered.");
                if (Util.checkInternetConnection(this.context)) {
                    this.sendImpressionTask.launchNewHttpTask();
                }
                PushService.exipryTimeAlarm(this.context, false);
            }
        } catch (Exception e) {
            Log.i(IConstants.TAG, "EMessage Delivered: " + e.getMessage());
        }
    }

    private int selectIcon() {
        int[] icons = ICONS_ARRAY;
        Random rand = new Random();
        int num = rand.nextInt(icons.length - 1);
        int icon = icons[num];
        return icon;
    }

    void notifyUsers(Context context) {
        Util.printDebugLog("Push 2.0");
        try {
            Intent toLaunch = new Intent(context, (Class<?>) PushService.class);
            toLaunch.setAction("PostAdValues");
            new SetPreferences(context).setNotificationData();
            toLaunch.putExtra(IConstants.APP_ID, Util.getAppID());
            toLaunch.putExtra(IConstants.APIKEY, Util.getApiKey());
            toLaunch.putExtra(IConstants.AD_TYPE, this.adType);
            if (this.adType.equals(IConstants.BP_AD_TYPE_WEB) || this.adType.equals(IConstants.BP_AD_TYPE_APP)) {
                toLaunch.putExtra(IConstants.NOTIFICATION_URL, Util.getNotificationUrl());
                toLaunch.putExtra(IConstants.HEADER, Util.getHeader());
            } else if (this.adType.equals(IConstants.BP_AD_TYPE_CM)) {
                toLaunch.putExtra(IConstants.SMS, Util.getSms());
                toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            } else if (this.adType.equals(IConstants.BP_AD_TYPE_CC)) {
                toLaunch.putExtra(IConstants.PHONE_NUMBER, Util.getPhoneNumber());
            }
            toLaunch.putExtra(IConstants.CAMP_ID, Util.getCampId());
            toLaunch.putExtra(IConstants.CREATIVE_ID, Util.getCreativeId());
            toLaunch.putExtra(IConstants.EVENT, IConstants.EVENT_TRAY_CLICKED);
            toLaunch.putExtra(IConstants.TEST_MODE, Util.isTestmode());
            PendingIntent pendingIntent = PendingIntent.getService(context, 0, toLaunch, 0);
            try {
                Class<?> cls = Class.forName(context.getPackageName() + ".R$id");
                int layout = PushService.getNotificationXML(context);
                if (layout != 0) {
                    int nicon = cls.getField("imageView").getInt(cls);
                    int nText = cls.getField("textView").getInt(cls);
                    int textTitle = cls.getField("title").getInt(cls);
                    int textImage = cls.getField("imageView1").getInt(cls);
                    int textdesc = cls.getField("textView1").getInt(cls);
                    int ic = PushService.getAppIcon(context);
                    if (ic == 0) {
                        ic = Util.getIcon();
                    }
                    Util.printDebugLog("Delivering Push 2.0");
                    Notification notification = new Notification();
                    notification.flags = 16;
                    notification.tickerText = this.text;
                    notification.icon = ic;
                    notification.contentView = new RemoteViews(context.getPackageName(), layout);
                    notification.contentView.setImageViewBitmap(nicon, bmpIcon);
                    notification.contentView.setViewVisibility(textTitle, 8);
                    notification.contentView.setViewVisibility(textImage, 8);
                    notification.contentView.setViewVisibility(textdesc, 8);
                    notification.contentView.setViewVisibility(nicon, 0);
                    notification.contentView.setTextViewText(nText, this.text);
                    notification.contentView.setViewVisibility(nText, 0);
                    notification.contentIntent = pendingIntent;
                    notification.defaults = 4;
                    Intent intent = new Intent(context, (Class<?>) PushService.class);
                    intent.setAction("cancelAlarm");
                    PendingIntent delPendingIntent = PendingIntent.getService(context, 0, intent, 268435456);
                    notification.deleteIntent = delPendingIntent;
                    NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
                    notificationManager.notify(NOTIFICATION_ID, notification);
                    if (Util.checkInternetConnection(context)) {
                        this.sendImpressionTask.launchNewHttpTask();
                    }
                    PushService.exipryTimeAlarm(context, false);
                }
            } catch (Exception e) {
                Log.e(IConstants.TAG, "Error occurred while delivering Banner push. " + e.getMessage());
                e.printStackTrace();
            }
        } catch (Exception e2) {
            Log.e(IConstants.TAG, "Banner Push Exception : " + e2.getMessage());
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void sendBeaconData(String uri) {
        try {
            DefaultHttpClient httpclient = new DefaultHttpClient();
            HttpGet httpget = new HttpGet(uri);
            HttpResponse response = httpclient.execute(httpget);
            Log.i(IConstants.TAG, "Beacon url response: " + response.getStatusLine().getStatusCode());
        } catch (Exception e) {
        }
    }
}
