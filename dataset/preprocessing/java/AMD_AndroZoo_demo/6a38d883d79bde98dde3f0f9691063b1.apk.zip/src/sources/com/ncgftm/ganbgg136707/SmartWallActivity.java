package com.ncgftm.ganbgg136707;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.ncgftm.ganbgg136707.AdCallbackListener;
import com.ncgftm.ganbgg136707.IConstants;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class SmartWallActivity extends Activity {
    static final String INTENT_ACTION_APPWALL_AD = "appwallad";
    static final String INTENT_ACTION_DIALOG_AD = "dialogad";
    static final String INTENT_ACTION_LANDING_PAGE_AD = "lpad";
    static final String INTENT_ACTION_RICH_MEDIA_FULL_PAGE_AD = "mfpad";
    private static final String OPT_IN_TEXT = "<html><body style='background:#C4C4C4;font-family:Arial;font-size:11pt;line-height:18px'><p align='justify'>This app is ad-supported and our advertising network, Airpush, Inc., will place ads within this app and your device&#39;s notification tray and home screen. Airpush automatically collects certain data from your device, including your Android ID, IP address and a list of apps installed on your device. Airpush may also receive information via the permissions you granted to this app in the prior screen, including your precise geolocation. To learn more about Airpush&#39;s privacy practices, visit its <a href='http://m.airpush.com/technology_privacy'><i>Privacy Policy</i></a>. If you click &quot;Cancel&quot; below, Airpush will not place ads in your notification tray or home screen. If you click &quot;Ok&quot;, and later want to opt out of receiving these ads, visit the Airpush <a href='http://m.airpush.com/optout'><i>opt-out page</i></a>. To disable Airpush&#39;s collection of information from your device and stop receiving targeted in-app ads from Airpush, you must delete this app and all other apps on your device that use Airpush&#39;s service.</p></body></html>";
    private static final String TITLE = "Privacy Policy & Advertising Terms";
    private static WebView webView;
    private String adType;
    private AppWall appWall;
    Dialog dialog;
    private Intent intent;
    private LandingPageAd landingPageAd;
    private MraidView mraidView;
    private OptinDialog optinDialog;
    private AdCallbackListener.OptinListener optinListener;
    private ProgressDialog progressDialog;
    private static String TAG = IConstants.TAG;
    private static String event = "optOut";
    private static boolean isShowing = false;
    Handler handler = new Handler() { // from class: com.ncgftm.ganbgg136707.SmartWallActivity.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case -4:
                    try {
                        if (SmartWallActivity.this.dialog != null) {
                            SmartWallActivity.this.dialog.dismiss();
                        }
                        SmartWallActivity.this.finish();
                        if (Airpush.adCallbackListener != null) {
                            Airpush.adCallbackListener.onAdError("Error occurred while loading ad.");
                            return;
                        }
                        return;
                    } catch (Exception e) {
                        return;
                    }
                case -3:
                    try {
                        if (SmartWallActivity.this.dialog != null) {
                            SmartWallActivity.this.dialog.dismiss();
                        }
                        SmartWallActivity.this.finish();
                        if (Airpush.adCallbackListener != null) {
                            Airpush.adCallbackListener.onSmartWallAdClosed();
                            return;
                        }
                        return;
                    } catch (Exception e2) {
                        SmartWallActivity.this.finish();
                        return;
                    }
                case -2:
                case -1:
                default:
                    return;
                case 0:
                    try {
                        SmartWallActivity.this.dialog.show();
                        SmartWallActivity.this.dialog.getWindow().setFlags(1024, 1024);
                        if (Airpush.adCallbackListener != null) {
                            Airpush.adCallbackListener.onSmartWallAdShowing();
                            return;
                        }
                        return;
                    } catch (Exception e3) {
                        SmartWallActivity.this.finish();
                        return;
                    }
            }
        }
    };
    AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.SmartWallActivity.4
        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void onTaskComplete(String result) {
            Log.i(SmartWallActivity.TAG, SmartWallActivity.event + " data sent: " + result);
            SmartWallActivity.this.finish();
        }

        @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
        public void launchNewHttpTask() {
            List<NameValuePair> list = new ArrayList<>();
            list.add(new BasicNameValuePair(IConstants.EVENT, SmartWallActivity.event));
            list.add(new BasicNameValuePair(IConstants.IMEI, "" + Util.getImei()));
            list.add(new BasicNameValuePair(IConstants.APP_ID, Util.getAppID()));
            Log.i(SmartWallActivity.TAG, SmartWallActivity.event + " Data: " + list);
            NetworkThread networkThread = new NetworkThread(SmartWallActivity.this.getApplicationContext(), SmartWallActivity.this.asyncTaskCompleteListener, list, IConstants.URL_OPT_IN, 0L, false);
            new Thread(networkThread, "opt_in").start();
        }
    };

    @Override // android.app.Activity
    @SuppressLint({"InlinedApi"})
    protected void onCreate(Bundle savedInstanceState) {
        String action;
        super.onCreate(savedInstanceState);
        try {
            isShowing = true;
            this.intent = getIntent();
            action = this.intent.getAction();
            this.adType = this.intent.getStringExtra(IConstants.AD_TYPE);
        } catch (Exception e) {
        }
        if (action.equals(INTENT_ACTION_RICH_MEDIA_FULL_PAGE_AD) && this.adType.equalsIgnoreCase(IConstants.AD_TYPE_MFP)) {
            this.dialog = new Dialog(this, 16973841);
            this.dialog.requestWindowFeature(1);
            this.dialog.getWindow().setLayout(-1, -1);
            this.mraidView = new MraidView(this, Airpush.parseMraidJson, this.handler);
            this.dialog.setContentView(this.mraidView);
            this.dialog.setCanceledOnTouchOutside(false);
            this.dialog.setCancelable(false);
            this.dialog.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.ncgftm.ganbgg136707.SmartWallActivity.2
                @Override // android.content.DialogInterface.OnCancelListener
                public void onCancel(DialogInterface dialog) {
                    dialog.dismiss();
                    SmartWallActivity.this.finish();
                }
            });
            return;
        }
        if (action.equals(INTENT_ACTION_APPWALL_AD) && this.adType.equalsIgnoreCase(IConstants.AD_TYPE_AW)) {
            String url = this.intent.getStringExtra(IConstants.NOTIFICATION_URL);
            if (url != null && !url.equals("") && Util.checkInternetConnection(this)) {
                try {
                    if (Build.VERSION.SDK_INT >= 11) {
                        getWindow().setFlags(16777216, 16777216);
                    }
                } catch (Throwable th) {
                }
                this.progressDialog = ProgressDialog.show(this, null, "Loading....");
                this.appWall = new AppWall(this, url);
                if (Airpush.adCallbackListener != null) {
                    Airpush.adCallbackListener.onSmartWallAdShowing();
                    return;
                }
                return;
            }
        } else if (action.equals(INTENT_ACTION_LANDING_PAGE_AD) && this.adType.equalsIgnoreCase(IConstants.AD_TYPE_FP)) {
            String url2 = this.intent.getStringExtra(IConstants.NOTIFICATION_URL);
            if (url2 != null && !url2.equals("") && Util.checkInternetConnection(this)) {
                try {
                    if (Build.VERSION.SDK_INT >= 11) {
                        getWindow().setFlags(16777216, 16777216);
                    }
                } catch (Throwable th2) {
                }
                this.progressDialog = ProgressDialog.show(this, null, "Loading ....");
                this.landingPageAd = new LandingPageAd(this, url2);
                if (Airpush.adCallbackListener != null) {
                    Airpush.adCallbackListener.onSmartWallAdShowing();
                    return;
                }
                return;
            }
        } else if (action.equals("dialogad") && (this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DAU) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCM) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCC))) {
            new DialogAd(this.intent, this);
            return;
        }
        if (SetPreferences.isShowOptinDialog(getApplicationContext())) {
            this.optinListener = Airpush.getOptinListener();
            this.optinDialog = new OptinDialog(this);
            this.optinDialog.setCanceledOnTouchOutside(false);
            this.optinDialog.show();
            this.optinDialog.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.ncgftm.ganbgg136707.SmartWallActivity.3
                @Override // android.content.DialogInterface.OnCancelListener
                public void onCancel(DialogInterface dialog) {
                    dialog.dismiss();
                    SmartWallActivity.this.finish();
                    if (SmartWallActivity.this.optinListener != null) {
                        SmartWallActivity.this.optinListener.optinResult(false);
                    }
                }
            });
        }
    }

    @Override // android.app.Activity
    protected void onUserLeaveHint() {
        try {
            if (this.adType != null && (this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DAU) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCM) || this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCC))) {
                DialogAd.getDialog().dismiss();
                finish();
            }
        } catch (Exception e) {
            finish();
        }
        super.onUserLeaveHint();
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    class OptinDialog extends AlertDialog {
        Context context;

        protected OptinDialog(Context context) {
            super(context);
            this.context = context;
            showOptinDialog();
        }

        private void showOptinDialog() {
            Log.i(SmartWallActivity.TAG, "Display Privacy & Terms");
            try {
                setTitle(SmartWallActivity.TITLE);
                int[] colors = {Color.parseColor("#A5A5A5"), Color.parseColor("#9C9C9C"), Color.parseColor("#929493")};
                GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors);
                ViewGroup.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
                LinearLayout linearLayout = new LinearLayout(this.context);
                linearLayout.setLayoutParams(layoutParams);
                linearLayout.setOrientation(1);
                float scale = this.context.getResources().getDisplayMetrics().density;
                LinearLayout linearLayout2 = new LinearLayout(this.context);
                linearLayout2.setGravity(17);
                if (Build.VERSION.SDK_INT >= 16) {
                    linearLayout2.setBackground(drawable);
                } else {
                    linearLayout2.setBackgroundDrawable(drawable);
                }
                LinearLayout.LayoutParams buttonLayoutParams = new LinearLayout.LayoutParams(-1, (int) (60.0f * scale), 2.0f);
                buttonLayoutParams.topMargin = (int) (-(60.0f * scale));
                buttonLayoutParams.gravity = 80;
                linearLayout2.setOrientation(0);
                linearLayout2.setLayoutParams(buttonLayoutParams);
                TextView closeText = new TextView(this.context);
                closeText.setGravity(17);
                LinearLayout.LayoutParams btparParams = new LinearLayout.LayoutParams(-1, -2, 2.0f);
                btparParams.gravity = 17;
                closeText.setLayoutParams(btparParams);
                closeText.setTextColor(-16777216);
                closeText.setTextAppearance(this.context, 16843271);
                SpannableString content = new SpannableString("Cancel");
                content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
                closeText.setText(content);
                closeText.setId(-2);
                linearLayout2.addView(closeText);
                Button continueButton = new Button(this.context);
                continueButton.setId(-1);
                continueButton.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 2.0f));
                continueButton.setText("Ok");
                linearLayout2.addView(continueButton);
                linearLayout2.setBackgroundColor(-3355444);
                LinearLayout layout = new LinearLayout(this.context);
                LinearLayout.LayoutParams webLayoutParams = new LinearLayout.LayoutParams(-1, -1);
                webLayoutParams.bottomMargin = (int) (60.0f * scale);
                layout.setLayoutParams(webLayoutParams);
                WebView unused = SmartWallActivity.webView = new WebView(this.context);
                SmartWallActivity.webView.loadData(SmartWallActivity.OPT_IN_TEXT, "text/html", "utf-8");
                SmartWallActivity.webView.setWebChromeClient(new WebChromeClient());
                SmartWallActivity.webView.setWebViewClient(new MyWebViewClient());
                SmartWallActivity.webView.setScrollBarStyle(33554432);
                layout.addView(SmartWallActivity.webView);
                linearLayout.addView(layout);
                linearLayout.addView(linearLayout2);
                setView(linearLayout);
                setCancelable(true);
                closeText.setOnClickListener(new View.OnClickListener() { // from class: com.ncgftm.ganbgg136707.SmartWallActivity.OptinDialog.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View arg0) {
                        try {
                            boolean unused2 = SmartWallActivity.isShowing = false;
                            if (Util.checkInternetConnection(SmartWallActivity.this)) {
                                String unused3 = SmartWallActivity.event = "optOut";
                                OptinDialog.this.dismiss();
                                SmartWallActivity.this.asyncTaskCompleteListener.launchNewHttpTask();
                                Airpush.startNewAdThread(false);
                            } else {
                                OptinDialog.this.dismiss();
                                Airpush.startNewAdThread(false);
                                SmartWallActivity.this.finish();
                            }
                            SmartWallActivity.this.finish();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        if (SmartWallActivity.this.optinListener != null) {
                            SmartWallActivity.this.optinListener.optinResult(false);
                        }
                    }
                });
                continueButton.setOnClickListener(new View.OnClickListener() { // from class: com.ncgftm.ganbgg136707.SmartWallActivity.OptinDialog.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View arg0) {
                        try {
                            boolean unused2 = SmartWallActivity.isShowing = false;
                            OptinDialog.this.dismiss();
                            SetPreferences.setOptinDialogPref(SmartWallActivity.this);
                            if (Util.checkInternetConnection(OptinDialog.this.context)) {
                                String unused3 = SmartWallActivity.event = "optIn";
                                SmartWallActivity.this.asyncTaskCompleteListener.launchNewHttpTask();
                                Airpush.startNewAdThread(true);
                            } else {
                                Airpush.startNewAdThread(true);
                                SmartWallActivity.this.finish();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        if (SmartWallActivity.this.optinListener != null) {
                            SmartWallActivity.this.optinListener.optinResult(true);
                        }
                    }
                });
                if (SmartWallActivity.this.optinListener != null) {
                    SmartWallActivity.this.optinListener.showingDialog();
                }
            } catch (Exception e) {
                e.printStackTrace();
                SmartWallActivity.this.finish();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public class MyWebViewClient extends WebViewClient {
        private MyWebViewClient() {
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            try {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                intent.addFlags(268435456);
                SmartWallActivity.this.startActivity(intent);
                return true;
            } catch (Exception e) {
                return true;
            }
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    private class AppWall extends Dialog implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
        public AppWall(Context context, String url) {
            super(context);
            requestWindowFeature(1);
            getWindow().setBackgroundDrawable(new ColorDrawable(0));
            setCancelable(true);
            setCanceledOnTouchOutside(false);
            setOnCancelListener(this);
            setOnDismissListener(this);
            DisplayMetrics displayMetrics = SmartWallActivity.this.getResources().getDisplayMetrics();
            float scale = displayMetrics.density;
            int margin = (int) (7.0f * scale);
            RelativeLayout relativeLayout = new RelativeLayout(context);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -2);
            layoutParams.setMargins(margin, margin, margin, margin);
            layoutParams.addRule(15, -1);
            layoutParams.addRule(14, -1);
            relativeLayout.setLayoutParams(layoutParams);
            WebView unused = SmartWallActivity.webView = new WebView(context);
            SmartWallActivity.webView.getSettings().setCacheMode(-1);
            SmartWallActivity.webView.getSettings().setJavaScriptEnabled(true);
            SmartWallActivity.webView.addJavascriptInterface(new JavaScriptInterface(), "Airpush");
            SmartWallActivity.webView.setWebChromeClient(new WebChromeClient());
            SmartWallActivity.webView.setWebViewClient(new WebViewClient() { // from class: com.ncgftm.ganbgg136707.SmartWallActivity.AppWall.1
                @Override // android.webkit.WebViewClient
                public void onPageFinished(WebView view, String url2) {
                    super.onPageFinished(view, url2);
                    try {
                        if (SmartWallActivity.this.progressDialog != null) {
                            SmartWallActivity.this.progressDialog.dismiss();
                        }
                        AppWall.this.show();
                    } catch (Exception e) {
                        SmartWallActivity.this.finish();
                    }
                }

                @Override // android.webkit.WebViewClient
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    try {
                        if (SmartWallActivity.this.progressDialog != null) {
                            SmartWallActivity.this.progressDialog.dismiss();
                        }
                        if (SmartWallActivity.this.appWall != null) {
                            SmartWallActivity.this.appWall.dismiss();
                        }
                        String error = "Error occurred while loading AppWall: code " + errorCode + ", desc: " + description;
                        Log.e(SmartWallActivity.TAG, error);
                        if (Airpush.adCallbackListener != null) {
                            Airpush.adCallbackListener.onAdError(error);
                        }
                    } catch (Throwable th) {
                        Log.e(SmartWallActivity.TAG, "Error occurred while loading AppWall: code " + errorCode + ", desc: " + description);
                    }
                    if (Airpush.adCallbackListener != null) {
                        Airpush.adCallbackListener.onSmartWallAdClosed();
                    }
                    SmartWallActivity.this.finish();
                }

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView view, String url2) {
                    try {
                        Util.printDebugLog("SmartWall Url: " + url2);
                        try {
                            if (SmartWallActivity.this.appWall != null) {
                                if (SmartWallActivity.webView != null) {
                                    SmartWallActivity.webView.stopLoading();
                                    SmartWallActivity.webView.removeAllViews();
                                    SmartWallActivity.webView.destroy();
                                }
                                SmartWallActivity.this.appWall.dismiss();
                            }
                        } catch (Exception e) {
                        } catch (Throwable th) {
                        }
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url2));
                        intent.addFlags(268435456);
                        intent.addFlags(8388608);
                        SmartWallActivity.this.startActivity(intent);
                        SmartWallActivity.this.finish();
                        return true;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                        return false;
                    }
                }
            });
            SmartWallActivity.webView.setVerticalScrollBarEnabled(false);
            SmartWallActivity.webView.setHorizontalScrollBarEnabled(false);
            SmartWallActivity.webView.setScrollBarStyle(33554432);
            SmartWallActivity.webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
            SmartWallActivity.webView.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
            relativeLayout.addView(SmartWallActivity.webView);
            setContentView(relativeLayout);
            SmartWallActivity.webView.loadUrl(url);
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialog) {
            if (dialog != null) {
                try {
                    dialog.dismiss();
                } catch (Exception e) {
                    return;
                }
            }
            SmartWallActivity.this.finish();
            if (Airpush.adCallbackListener != null) {
                Airpush.adCallbackListener.onSmartWallAdClosed();
            }
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialog) {
            if (dialog != null) {
                try {
                    dialog.dismiss();
                } catch (Exception e) {
                } catch (Throwable th) {
                }
            }
            if (SmartWallActivity.webView != null) {
                SmartWallActivity.webView.stopLoading();
                SmartWallActivity.webView.removeAllViews();
                SmartWallActivity.webView.destroy();
            }
            SmartWallActivity.this.finish();
            if (Airpush.adCallbackListener != null) {
                Airpush.adCallbackListener.onSmartWallAdClosed();
            }
        }

        /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
        public class JavaScriptInterface {
            public JavaScriptInterface() {
            }

            @JavascriptInterface
            public void closewin() {
                SmartWallActivity.this.appWall.dismiss();
                SmartWallActivity.this.finish();
                if (Airpush.adCallbackListener != null) {
                    Airpush.adCallbackListener.onSmartWallAdClosed();
                }
            }

            @JavascriptInterface
            public void triggerEvent(String event) {
                try {
                    Util.registerApsalarEvent(SmartWallActivity.this, IConstants.ApSalarEvent.valueOf(event));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        try {
            if (this.progressDialog != null) {
                this.progressDialog.dismiss();
            }
        } catch (Exception e) {
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        try {
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (this.adType == null || (!this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DAU) && !this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCM) && !this.adType.equalsIgnoreCase(IConstants.AD_TYPE_DCC))) {
            if (this.adType != null && this.adType.equals(IConstants.AD_TYPE_AW)) {
                if (this.progressDialog != null) {
                    this.progressDialog.dismiss();
                }
                if (this.appWall != null) {
                    this.appWall.dismiss();
                }
                if (Airpush.adCallbackListener != null) {
                    Airpush.adCallbackListener.onSmartWallAdClosed();
                }
                finish();
            } else if (this.adType != null && this.adType.equals(IConstants.AD_TYPE_FP)) {
                if (this.progressDialog != null) {
                    this.progressDialog.dismiss();
                }
                if (this.landingPageAd != null) {
                    this.landingPageAd.dismiss();
                }
                if (Airpush.adCallbackListener != null) {
                    Airpush.adCallbackListener.onSmartWallAdClosed();
                }
                finish();
            } else if (this.adType != null && this.adType.equals(IConstants.AD_TYPE_MFP)) {
                if (this.dialog != null) {
                    this.dialog.dismiss();
                }
                finish();
            } else {
                if (this.optinDialog != null) {
                    this.optinDialog.dismiss();
                }
                finish();
            }
            super.onBackPressed();
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    private class LandingPageAd extends Dialog implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
        public LandingPageAd(Context context, String url) {
            super(context);
            try {
                requestWindowFeature(1);
                getWindow().setBackgroundDrawable(new ColorDrawable(0));
                setCancelable(true);
                setCanceledOnTouchOutside(false);
                setOnCancelListener(this);
                setOnDismissListener(this);
                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(1);
                LinearLayout.LayoutParams mainLayoutParams = new LinearLayout.LayoutParams(-2, -2);
                mainLayoutParams.gravity = 17;
                linearLayout.setLayoutParams(mainLayoutParams);
                RelativeLayout relativeLayout = new RelativeLayout(context);
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
                relativeLayout.setLayoutParams(layoutParams);
                Button button = new Button(context);
                RelativeLayout.LayoutParams buttonLayoutParams = new RelativeLayout.LayoutParams(-2, -2);
                buttonLayoutParams.addRule(11, -1);
                buttonLayoutParams.bottomMargin = 0;
                button.setPadding(0, 0, 0, 0);
                button.setGravity(17);
                button.setLayoutParams(buttonLayoutParams);
                button.setText("X");
                button.setTextSize(15.0f);
                button.setTypeface(Typeface.DEFAULT, 1);
                button.setTextColor(-1);
                button.setBackgroundColor(0);
                button.setOnClickListener(new View.OnClickListener() { // from class: com.ncgftm.ganbgg136707.SmartWallActivity.LandingPageAd.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View v) {
                        LandingPageAd.this.dismiss();
                        SmartWallActivity.this.finish();
                    }
                });
                WebView unused = SmartWallActivity.webView = new WebView(context);
                SmartWallActivity.webView.getSettings().setJavaScriptEnabled(true);
                SmartWallActivity.webView.setWebChromeClient(new WebChromeClient());
                SmartWallActivity.webView.setScrollBarStyle(33554432);
                SmartWallActivity.webView.setWebViewClient(new WebViewClient() { // from class: com.ncgftm.ganbgg136707.SmartWallActivity.LandingPageAd.2
                    @Override // android.webkit.WebViewClient
                    public void onPageFinished(WebView view, String url2) {
                        super.onPageFinished(view, url2);
                        try {
                            if (SmartWallActivity.this.progressDialog != null) {
                                SmartWallActivity.this.progressDialog.dismiss();
                            }
                            LandingPageAd.this.show();
                            Util.registerApsalarEvent(SmartWallActivity.this, IConstants.ApSalarEvent.landing_page_displayed);
                        } catch (Exception e) {
                            SmartWallActivity.this.finish();
                        }
                    }

                    @Override // android.webkit.WebViewClient
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        try {
                            if (SmartWallActivity.this.progressDialog != null) {
                                SmartWallActivity.this.progressDialog.dismiss();
                            }
                            if (SmartWallActivity.this.landingPageAd != null) {
                                SmartWallActivity.this.landingPageAd.dismiss();
                            }
                            if (Airpush.adCallbackListener != null) {
                                Airpush.adCallbackListener.onSmartWallAdClosed();
                            }
                        } catch (Throwable th) {
                            Log.e(SmartWallActivity.TAG, "Error occurred while loading landing page: code " + errorCode + ", desc: " + description);
                        }
                        SmartWallActivity.this.finish();
                    }

                    @Override // android.webkit.WebViewClient
                    public boolean shouldOverrideUrlLoading(WebView view, String url2) {
                        try {
                            Util.printDebugLog("SmartWall Url: " + url2);
                            try {
                                if (SmartWallActivity.this.landingPageAd != null) {
                                    if (SmartWallActivity.webView != null) {
                                        SmartWallActivity.webView.stopLoading();
                                        SmartWallActivity.webView.removeAllViews();
                                        SmartWallActivity.webView.destroy();
                                    }
                                    SmartWallActivity.this.landingPageAd.dismiss();
                                }
                            } catch (Exception e) {
                            } catch (Throwable th) {
                            }
                            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url2));
                            intent.addFlags(268435456);
                            intent.addFlags(8388608);
                            SmartWallActivity.this.startActivity(intent);
                            SmartWallActivity.this.finish();
                            return true;
                        } catch (Exception e2) {
                            e2.printStackTrace();
                            return false;
                        }
                    }
                });
                SmartWallActivity.webView.loadUrl(url);
                relativeLayout.addView(button);
                linearLayout.addView(relativeLayout);
                linearLayout.addView(SmartWallActivity.webView, mainLayoutParams);
                setContentView(linearLayout);
            } catch (Exception e) {
                Log.e(IConstants.TAG, "An error occured while starting LandingPageAd.");
                SmartWallActivity.this.finish();
            }
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialog) {
            if (dialog != null) {
                try {
                    dialog.dismiss();
                } catch (Exception e) {
                    return;
                }
            }
            SmartWallActivity.this.finish();
            if (Airpush.adCallbackListener != null) {
                Airpush.adCallbackListener.onSmartWallAdClosed();
            }
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialog) {
            if (dialog != null) {
                try {
                    dialog.dismiss();
                } catch (Exception e) {
                    return;
                }
            }
            SmartWallActivity.this.finish();
            if (Airpush.adCallbackListener != null) {
                Airpush.adCallbackListener.onSmartWallAdClosed();
            }
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        try {
            isShowing = false;
            if (webView != null) {
                webView.stopLoading();
                webView.removeAllViews();
                webView.destroy();
            }
        } catch (Exception e) {
        }
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isShowing() {
        return isShowing;
    }
}
