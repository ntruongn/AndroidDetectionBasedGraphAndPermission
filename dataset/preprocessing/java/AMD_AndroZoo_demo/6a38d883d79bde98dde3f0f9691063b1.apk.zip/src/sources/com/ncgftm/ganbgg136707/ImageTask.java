package com.ncgftm.ganbgg136707;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
final class ImageTask extends AsyncTask<Void, Void, Void> {
    final String IMAGE_URL;
    Bitmap bmpicon = null;
    final AsyncTaskCompleteListener<Bitmap> listener;

    public ImageTask(String image_url, AsyncTaskCompleteListener<Bitmap> completeListener) {
        this.IMAGE_URL = image_url;
        this.listener = completeListener;
        Util.printDebugLog("Image URL: " + image_url);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public Void doInBackground(Void... params) {
        HttpURLConnection httpConnection = null;
        try {
            try {
                URL u = new URL(this.IMAGE_URL);
                HttpURLConnection httpConnection2 = (HttpURLConnection) u.openConnection();
                httpConnection2.setRequestMethod("GET");
                httpConnection2.setConnectTimeout(20000);
                httpConnection2.setReadTimeout(20000);
                httpConnection2.setUseCaches(false);
                httpConnection2.setDefaultUseCaches(false);
                httpConnection2.connect();
                int code = httpConnection2.getResponseCode();
                if (code == 200) {
                    InputStream iconStream = httpConnection2.getInputStream();
                    this.bmpicon = BitmapFactory.decodeStream(iconStream);
                } else {
                    Log.w(IConstants.TAG, "Http Code: " + code + ", Message: " + httpConnection2.getResponseMessage());
                }
                if (httpConnection2 != null) {
                    httpConnection2.disconnect();
                    return null;
                }
                return null;
            } catch (Exception ex) {
                ex.printStackTrace();
                Log.e(IConstants.TAG, "Network Error, please try again later");
                if (0 != 0) {
                    httpConnection.disconnect();
                    return null;
                }
                return null;
            }
        } catch (Throwable th) {
            if (0 != 0) {
                httpConnection.disconnect();
            }
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public void onPostExecute(Void result) {
        if (this.listener != null) {
            this.listener.onTaskComplete(this.bmpicon);
        }
    }
}
