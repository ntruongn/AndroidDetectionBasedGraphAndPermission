package com.ncgftm.ganbgg136707;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.util.Log;
import com.ncgftm.ganbgg136707.AdCallbackListener;
import com.ncgftm.ganbgg136707.FormatAds;
import com.ncgftm.ganbgg136707.IConstants;
import com.ncgftm.ganbgg136707.Util;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class Airpush extends SDKIntializer {
    static final String TAG = "AirpushSDK";
    static AdCallbackListener adCallbackListener;
    private static Context mContext;
    private static AdCallbackListener.OptinListener optinListener;
    static FormatAds.ParseMraidJson parseMraidJson;
    private boolean isDialogClosed;
    Runnable optinRunnable = new Runnable() { // from class: com.ncgftm.ganbgg136707.Airpush.1
        @Override // java.lang.Runnable
        public void run() {
            try {
                Intent intent = new Intent(Airpush.mContext, (Class<?>) SmartWallActivity.class);
                intent.setFlags(268435456);
                intent.addFlags(536870912);
                intent.addFlags(8388608);
                Airpush.mContext.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Log.e("AirpushSDK", "Required SmartWallActivity not declared in Manifest, Please add.");
                SDKIntializer.sendIntegrationError("Required SmartWallActivity not declared in Manifest, Please add.");
            } catch (Exception e2) {
                Log.e("AirpushSDK", "Error in Optin runnable: " + e2.getMessage());
            }
        }
    };

    public Airpush(Context context, AdCallbackListener adCallbackListener2) {
        this.isDialogClosed = false;
        adCallbackListener = adCallbackListener2;
        if (context == null) {
            Log.e("AirpushSDK", "Context must not be null.");
            sendIntegrationError("Context must not be null.");
            return;
        }
        mContext = context;
        Util.setContext(mContext);
        try {
            boolean is = Util.isIntentAvailable(context, (Class<?>) SmartWallActivity.class);
            if (!is) {
                Log.e("AirpushSDK", "Required SmartWallActivity not declared in Manifest, Please add.");
                sendIntegrationError("Required SmartWallActivity not declared in Manifest, Please add.");
                return;
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        this.isDialogClosed = false;
        if (getDataFromManifest(mContext) && checkRequiredPermission(mContext)) {
            Util.startBusense(mContext);
            UserDetails details = new UserDetails(mContext);
            if (details.setImeiInMd5()) {
                new SetPreferences(mContext).setPreferencesData();
                SetPreferences.getDataSharedPrefrences(mContext);
                Util.setSESSION_ID();
                SharedPreferences SDKPrefs = context.getSharedPreferences(IConstants.SDK_PREFERENCE, 0);
                if (SDKPrefs == null || !SDKPrefs.contains(IConstants.SDK_ENABLED)) {
                    enableSDK(context, true);
                }
                if (SetPreferences.isShowOptinDialog(mContext)) {
                    new Thread(this.optinRunnable, "optin_thread").start();
                } else {
                    sendUserInfo();
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Airpush() {
        this.isDialogClosed = false;
        try {
            this.isDialogClosed = true;
            if (!SetPreferences.isShowOptinDialog(mContext)) {
                sendUserInfo();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendUserInfo() {
        if (SetPreferences.isDeviceBlackListed(mContext)) {
            System.out.println("Device blacklisted.");
            return;
        }
        if (isSDKEnabled(mContext)) {
            try {
                AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.Airpush.2
                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    public void launchNewHttpTask() {
                        Log.i("AirpushSDK", "Sending user info...>>>>");
                        List<NameValuePair> values = new ArrayList<>();
                        values.add(new BasicNameValuePair(IConstants.MODEL, IConstants.MODEL_USER));
                        values.add(new BasicNameValuePair(IConstants.ACTION, IConstants.ACTION_SET_USER_INFO));
                        values.add(new BasicNameValuePair(IConstants.TYPE, IConstants.TYPE_APP));
                        NetworkThread networkThread = new NetworkThread(Airpush.mContext, this, values, IConstants.URL_API_MESSAGE, 4000L, true);
                        new Thread(networkThread, "sn").start();
                    }

                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    public void onTaskComplete(String result) {
                        Log.i("AirpushSDK", "Info sent: " + result);
                        long startTime = SetPreferences.getAppListStartTime(Airpush.mContext);
                        if (startTime == 0 || startTime < System.currentTimeMillis()) {
                            try {
                                if (Util.checkInternetConnection(Airpush.mContext)) {
                                    new SetPreferences(Airpush.mContext).sendAppInfoAsyncTaskCompleteListener.launchNewHttpTask();
                                }
                            } catch (Exception e) {
                            }
                        }
                    }
                };
                if (Util.checkInternetConnection(mContext)) {
                    asyncTaskCompleteListener.launchNewHttpTask();
                }
            } catch (Exception e) {
                Log.i("Activitymanager", e.toString());
            }
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    public void startPushNotification(boolean testMode) {
        if (mContext == null) {
            Log.e("AirpushSDK", "Context is null.");
            sendIntegrationError("Context is null");
            return;
        }
        try {
            if (SetPreferences.isShowOptinDialog(mContext)) {
                SharedPreferences preferences = mContext.getSharedPreferences(IConstants.ENABLE_AD_PREF, 0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean(IConstants.DO_PUSH, true);
                editor.putBoolean(IConstants.TEST_MODE, testMode);
                editor.commit();
            } else if (SetPreferences.isDeviceBlackListed(mContext)) {
                Log.w("AirpushSDK", "Can not start pushes device blacklisted.");
            } else {
                Util.setTestmode(testMode);
                Util.setDoPush(true);
                PushService.startAirpush(mContext);
            }
        } catch (Exception e) {
            Util.printLog("Error in Start Push Notification: " + e.getMessage());
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    public void startIconAd() {
        if (mContext == null) {
            Log.e("AirpushSDK", "Context is null.");
            sendIntegrationError("Context is null");
            return;
        }
        try {
            if (SetPreferences.isShowOptinDialog(mContext)) {
                SharedPreferences preferences = mContext.getSharedPreferences(IConstants.ENABLE_AD_PREF, 0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean(IConstants.ICON, true);
                editor.commit();
            } else if (SetPreferences.isDeviceBlackListed(mContext)) {
                Log.e("AirpushSDK", "Can not start icon ad device blacklisted.");
            } else {
                Log.i("AirpushSDK", "Push IconSearch....true");
                if (checkRequiredPermission(mContext) || getDataFromManifest(mContext)) {
                    UserDetails details = new UserDetails(mContext);
                    if (details.setImeiInMd5()) {
                        new SetPreferences(mContext).setPreferencesData();
                        SetPreferences.getDataSharedPrefrences(mContext);
                        if (mContext.checkCallingOrSelfPermission("com.android.launcher.permission.INSTALL_SHORTCUT") == 0) {
                            if (isSDKEnabled(mContext)) {
                                new IconAds(mContext);
                            } else {
                                Log.i("AirpushSDK", "Airpush SDK is disabled, Please enable it to receive Icon ad. ");
                            }
                        } else {
                            Log.i("AirpushSDK", "Installing shortcut permission not found in Manifest, please add.");
                            sendIntegrationError("Installing shortcut permission not found in Manifest, please add.");
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.i("AirpushSDK", "Error in StartIconAd: " + e.getMessage());
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    public void startSmartWallAd() {
        if (mContext == null) {
            Log.e("AirpushSDK", "Context is null.");
            sendIntegrationError("Context is null");
            return;
        }
        if (!this.isDialogClosed && SetPreferences.isShowOptinDialog(mContext)) {
            SharedPreferences preferences = mContext.getSharedPreferences(IConstants.ENABLE_AD_PREF, 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(IConstants.INTERSTITAL_AD_STRING, true);
            editor.commit();
            return;
        }
        Log.i("AirpushSDK", "Initialising SmartWall.....");
        try {
            if (!Util.isIntentAvailable(mContext, (Class<?>) SmartWallActivity.class)) {
                Log.i("AirpushSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                sendIntegrationError("Required SmartWallActivity not found in Manifest. Please add.");
                return;
            }
        } catch (Exception e) {
        }
        try {
            if (!Util.isIntentAvailable(mContext, (Class<?>) BrowserActivity.class)) {
                Log.i("AirpushSDK", "Required BrowserActivity not found in Manifest. Please add.");
                sendIntegrationError("Required BrowserActivity not found in Manifest. Please add.");
                return;
            }
        } catch (Exception e2) {
        }
        if (mContext == null || !isSDKEnabled(mContext)) {
            Log.i("AirpushSDK", "Airpush SDK is disabled Please enable to recive ads.");
            sendAdError("Airpush SDK is disabled Please enable to recive ads.");
            return;
        }
        if (SetPreferences.getNextAdCallTime(mContext) > System.currentTimeMillis()) {
            Log.i("AirpushSDK", "SmartWall Ad called within 20 secs. Ignoring request.");
            sendAdError("SmartWall Ad called within 20 secs. Ignoring request.");
            return;
        }
        if (SmartWallActivity.isShowing()) {
            Log.i("AirpushSDK", "Another ad is showing on screen.");
            sendAdError("Another ad is showing on screen.");
            return;
        }
        SetPreferences.setNextAdCallTime(mContext);
        Util.setContext(mContext);
        if (getDataFromManifest(mContext) && checkRequiredPermission(mContext) && new UserDetails(mContext).setImeiInMd5()) {
            new SetPreferences(mContext).setPreferencesData();
            SetPreferences.getDataSharedPrefrences(mContext);
            AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.Airpush.3
                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void onTaskComplete(String result) {
                    Log.i("AirpushSDK", "SmartWall JSON: " + result);
                    if (result != null) {
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String adtype = jsonObject.isNull(IConstants.AD_TYPE) ? "" : jsonObject.getString(IConstants.AD_TYPE);
                            if (!adtype.equals("") && adtype.equalsIgnoreCase(IConstants.AD_TYPE_AW)) {
                                Airpush.this.parseAppWallJson(result);
                            } else if (!adtype.equals("") && (adtype.equalsIgnoreCase(IConstants.AD_TYPE_DAU) || adtype.equalsIgnoreCase(IConstants.AD_TYPE_DCC) || adtype.equalsIgnoreCase(IConstants.AD_TYPE_DCM))) {
                                Airpush.this.parseDialogAdJson(result);
                            } else if (!adtype.equals("") && adtype.equalsIgnoreCase(IConstants.AD_TYPE_FP)) {
                                Airpush.this.parseLandingPageAdJson(result);
                            } else if (!adtype.equals("") && adtype.equalsIgnoreCase(IConstants.AD_TYPE_MFP)) {
                                Airpush.this.parseRichMediaInterstitialJson(result);
                            }
                            Util.registerApsalarEvent(Airpush.mContext, IConstants.ApSalarEvent.smartwall_call);
                        } catch (JSONException e3) {
                            Util.printLog("Error in Smart Wall json: " + e3.getMessage());
                        } catch (Exception e4) {
                            Util.printLog("Error occurred in Smart Wall: " + e4.getMessage());
                        }
                    }
                }

                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void launchNewHttpTask() {
                    try {
                        List<NameValuePair> nameValuePairs = SetPreferences.setValues(Airpush.mContext);
                        Util.printDebugLog("Interstitial values: " + nameValuePairs);
                        HttpPostDataTask httpPostTask = new HttpPostDataTask(Airpush.mContext, nameValuePairs, IConstants.URL_INTERSTITIAL, this);
                        httpPostTask.execute(new Void[0]);
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
            };
            if (Util.checkInternetConnection(mContext)) {
                asyncTaskCompleteListener.launchNewHttpTask();
            }
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    public void startDialogAd() {
        if (mContext == null) {
            Log.e("AirpushSDK", "Context is null.");
            sendIntegrationError("Context is null");
            return;
        }
        if (!this.isDialogClosed && SetPreferences.isShowOptinDialog(mContext)) {
            SharedPreferences preferences = mContext.getSharedPreferences(IConstants.ENABLE_AD_PREF, 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(IConstants.DIALOG_AD, true);
            editor.commit();
            return;
        }
        Log.i("AirpushSDK", "Initialising DialogAd.....");
        try {
            if (!Util.isIntentAvailable(mContext, (Class<?>) SmartWallActivity.class)) {
                Log.i("AirpushSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                sendIntegrationError("Required SmartWallActivity not found in Manifest. Please add.");
                return;
            }
        } catch (Exception e) {
        }
        if (mContext == null || !isSDKEnabled(mContext)) {
            Log.i("AirpushSDK", "Airpush SDK is disabled Please enable to recive ads.");
            sendAdError("Airpush SDK is disabled Please enable to recive ads.");
            return;
        }
        if (SetPreferences.getNextAdCallTime(mContext) > System.currentTimeMillis()) {
            Log.i("AirpushSDK", "Dialog Ad called within 20 secs. Ignoring request");
            sendAdError("Dialog Ad called within 20 secs. Ignoring request");
            return;
        }
        if (SmartWallActivity.isShowing()) {
            Log.i("AirpushSDK", "Another ad is showing on screen.");
            sendAdError("Another ad is showing on screen.");
            return;
        }
        SetPreferences.setNextAdCallTime(mContext);
        Util.setContext(mContext);
        if (getDataFromManifest(mContext) && checkRequiredPermission(mContext) && new UserDetails(mContext).setImeiInMd5()) {
            new SetPreferences(mContext).setPreferencesData();
            SetPreferences.getDataSharedPrefrences(mContext);
            AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.Airpush.4
                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void onTaskComplete(String result) {
                    Log.i("AirpushSDK", "Dialog Ad Json: " + result);
                    if (result != null) {
                        try {
                            Airpush.this.parseDialogAdJson(result);
                            Util.registerApsalarEvent(Airpush.mContext, IConstants.ApSalarEvent.dialog_call);
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                }

                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void launchNewHttpTask() {
                    try {
                        List<NameValuePair> nameValuePairs = SetPreferences.setValues(Airpush.mContext);
                        Util.printDebugLog("Dialog AD Values: " + nameValuePairs);
                        HttpPostDataTask httpPostTask = new HttpPostDataTask(Airpush.mContext, nameValuePairs, IConstants.URL_DIALOG, this);
                        httpPostTask.execute(new Void[0]);
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
            };
            if (Util.checkInternetConnection(mContext)) {
                asyncTaskCompleteListener.launchNewHttpTask();
            }
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    void parseDialogAdJson(final String json) {
        if (json != null && !json.equals("")) {
            Runnable runnable = new Runnable() { // from class: com.ncgftm.ganbgg136707.Airpush.5
                @Override // java.lang.Runnable
                public void run() {
                    String adtype;
                    String url;
                    String title;
                    String buttontxt;
                    try {
                        JSONObject jsonObject = new JSONObject(json);
                        String status = jsonObject.isNull("status") ? IConstants.INVALID : jsonObject.getString("status");
                        String msg = jsonObject.isNull("message") ? IConstants.INVALID : jsonObject.getString("message");
                        if (jsonObject.isNull(IConstants.AD_TYPE)) {
                            adtype = IConstants.INVALID;
                        } else {
                            adtype = jsonObject.getString(IConstants.AD_TYPE);
                        }
                        if (status.equals("200") && msg.equalsIgnoreCase("Success")) {
                            String data = jsonObject.isNull("data") ? "nodata" : jsonObject.getString("data");
                            if (!data.equals("nodata")) {
                                JSONObject jsonObject2 = new JSONObject(data);
                                if (jsonObject2.isNull(IConstants.NOTIFICATION_URL)) {
                                    url = IConstants.INVALID;
                                } else {
                                    url = jsonObject2.getString(IConstants.NOTIFICATION_URL);
                                }
                                if (jsonObject2.isNull("title")) {
                                    title = IConstants.INVALID;
                                } else {
                                    title = jsonObject2.getString("title");
                                }
                                String creativeid = jsonObject2.isNull("creativeid") ? "" : jsonObject2.getString("creativeid");
                                String camid = jsonObject2.isNull("campaignid") ? "" : jsonObject2.getString("campaignid");
                                String sms = jsonObject2.isNull(IConstants.SMS) ? "" : jsonObject2.getString(IConstants.SMS);
                                String number = jsonObject2.isNull(IConstants.PHONE_NUMBER) ? "" : jsonObject2.getString(IConstants.PHONE_NUMBER);
                                if (jsonObject2.isNull("buttontxt")) {
                                    buttontxt = IConstants.INVALID;
                                } else {
                                    buttontxt = jsonObject2.getString("buttontxt");
                                }
                                if (!adtype.equalsIgnoreCase(IConstants.INVALID)) {
                                    SetPreferences.setNextAdCallTime(Airpush.mContext);
                                    Intent intent = new Intent(Airpush.mContext, (Class<?>) SmartWallActivity.class);
                                    intent.setFlags(268435456);
                                    intent.addFlags(536870912);
                                    intent.addFlags(8388608);
                                    intent.setAction(IConstants.DIALOG_AD);
                                    intent.putExtra(IConstants.NOTIFICATION_URL, url);
                                    intent.putExtra("title", title);
                                    intent.putExtra("buttontxt", buttontxt);
                                    intent.putExtra("creativeid", creativeid);
                                    intent.putExtra("campaignid", camid);
                                    intent.putExtra(IConstants.SMS, sms);
                                    intent.putExtra(IConstants.PHONE_NUMBER, number);
                                    intent.putExtra(IConstants.AD_TYPE, adtype);
                                    try {
                                        Airpush.mContext.startActivity(intent);
                                    } catch (ActivityNotFoundException e) {
                                        Log.e("AirpushSDK", "Required SmartWallActivity not found in Manifest, Please add.");
                                        SDKIntializer.sendIntegrationError("Required SmartWallActivity not found in Manifest, Please add.");
                                    }
                                }
                            }
                        }
                    } catch (JSONException e2) {
                        Util.printLog("Error in Dialog Json: " + e2.getMessage());
                    } catch (Exception e3) {
                        Util.printLog("Error occured in Dialog Json: " + e3.getMessage());
                    }
                }
            };
            new Thread(runnable, IConstants.DIALOG_AD).start();
        } else {
            Log.e("AirpushSDK", "Dialog ad json is null");
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    public void startAppWall() {
        if (mContext == null) {
            Log.e("AirpushSDK", "Context is null.");
            sendIntegrationError("Context is null");
            return;
        }
        if (!this.isDialogClosed && SetPreferences.isShowOptinDialog(mContext)) {
            SharedPreferences preferences = mContext.getSharedPreferences(IConstants.ENABLE_AD_PREF, 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(IConstants.APP_WALL_AD, true);
            editor.commit();
            return;
        }
        Log.i("AirpushSDK", "Initialising AppWall.....");
        try {
            if (!Util.isIntentAvailable(mContext, (Class<?>) SmartWallActivity.class)) {
                Log.i("AirpushSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                sendIntegrationError("Required SmartWallActivity not found in Manifest. Please add.");
                return;
            }
        } catch (Exception e) {
        }
        if (mContext == null || !isSDKEnabled(mContext)) {
            Log.i("AirpushSDK", "Airpush SDK is disabled Please enable to recive ads.");
            sendAdError("Airpush SDK is disabled Please enable to recive ads.");
            return;
        }
        if (SetPreferences.getNextAdCallTime(mContext) > System.currentTimeMillis()) {
            Log.i("AirpushSDK", "AppWall called within 20 secs. Ignoring request");
            sendAdError("AppWall called within 20 secs. Ignoring request.");
            return;
        }
        if (SmartWallActivity.isShowing()) {
            Log.i("AirpushSDK", "Another ad is showing on screen.");
            sendAdError("Another ad is showing on screen.");
            return;
        }
        SetPreferences.setNextAdCallTime(mContext);
        Util.setContext(mContext);
        if (getDataFromManifest(mContext) && checkRequiredPermission(mContext) && new UserDetails(mContext).setImeiInMd5()) {
            new SetPreferences(mContext).setPreferencesData();
            SetPreferences.getDataSharedPrefrences(mContext);
            AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.Airpush.6
                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void onTaskComplete(String result) {
                    Log.i("AirpushSDK", "AppWall Json: " + result);
                    if (result != null) {
                        try {
                            Airpush.this.parseAppWallJson(result);
                            Util.registerApsalarEvent(Airpush.mContext, IConstants.ApSalarEvent.appwall_call);
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                }

                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void launchNewHttpTask() {
                    try {
                        List<NameValuePair> nameValuePairs = SetPreferences.setValues(Airpush.mContext);
                        Util.printDebugLog("AppWall AD Values: " + nameValuePairs);
                        HttpPostDataTask httpPostTask = new HttpPostDataTask(Airpush.mContext, nameValuePairs, IConstants.URL_APP_WALL, this);
                        httpPostTask.execute(new Void[0]);
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
            };
            if (Util.checkInternetConnection(mContext)) {
                asyncTaskCompleteListener.launchNewHttpTask();
            }
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    void parseAppWallJson(String json) {
        String status;
        String msg;
        final String url;
        try {
            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.isNull("status")) {
                status = IConstants.INVALID;
            } else {
                status = jsonObject.getString("status");
            }
            if (jsonObject.isNull("message")) {
                msg = IConstants.INVALID;
            } else {
                msg = jsonObject.getString("message");
            }
            if (!status.equals(IConstants.INVALID) && status.equals("200") && msg.equals("Success") && (url = jsonObject.getString(IConstants.NOTIFICATION_URL)) != null && !url.equals("")) {
                SetPreferences.setNextAdCallTime(mContext);
                Runnable appwallRunnable = new Runnable() { // from class: com.ncgftm.ganbgg136707.Airpush.7
                    @Override // java.lang.Runnable
                    public void run() {
                        Intent intent = new Intent(Airpush.mContext, (Class<?>) SmartWallActivity.class);
                        intent.setFlags(268435456);
                        intent.addFlags(536870912);
                        intent.addFlags(8388608);
                        intent.setAction("appwallad");
                        intent.putExtra(IConstants.AD_TYPE, IConstants.AD_TYPE_AW);
                        intent.putExtra(IConstants.NOTIFICATION_URL, url);
                        try {
                            Airpush.mContext.startActivity(intent);
                        } catch (ActivityNotFoundException e) {
                            Log.e("AirpushSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                        }
                    }
                };
                new Thread(appwallRunnable, "Appwall").start();
            }
        } catch (JSONException e) {
            Util.printLog("Error in AppWall Json: " + e.getMessage());
        } catch (Exception e2) {
            Util.printLog("Error occured in AppWall Json: " + e2.getMessage());
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    public void startLandingPageAd() {
        if (mContext == null) {
            Log.e("AirpushSDK", "Context is null.");
            sendIntegrationError("Context is null");
            return;
        }
        if (!this.isDialogClosed && SetPreferences.isShowOptinDialog(mContext)) {
            SharedPreferences preferences = mContext.getSharedPreferences(IConstants.ENABLE_AD_PREF, 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(IConstants.LANDING_PAGE_AD, true);
            editor.commit();
            return;
        }
        Log.i("AirpushSDK", "Initialising LandingPage AD.....");
        try {
            if (!Util.isIntentAvailable(mContext, (Class<?>) SmartWallActivity.class)) {
                Log.i("AirpushSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                sendIntegrationError("Required SmartWallActivity not found in Manifest. Please add.");
                return;
            }
        } catch (Exception e) {
        }
        if (mContext == null || !isSDKEnabled(mContext)) {
            Log.i("AirpushSDK", "Airpush SDK is disabled Please enable to recive ads.");
            sendAdError("Airpush SDK is disabled Please enable to recive ads.");
            return;
        }
        if (SetPreferences.getNextAdCallTime(mContext) > System.currentTimeMillis()) {
            Log.i("AirpushSDK", "LandingPage Ad called within 20 secs. Ignoring request");
            sendAdError("LandingPage Ad called within 20 secs. Ignoring request");
            return;
        }
        if (SmartWallActivity.isShowing()) {
            Log.i("AirpushSDK", "Another ad is showing on screen.");
            sendAdError("Another ad is showing on screen.");
            return;
        }
        SetPreferences.setNextAdCallTime(mContext);
        Util.setContext(mContext);
        if (getDataFromManifest(mContext) && checkRequiredPermission(mContext) && new UserDetails(mContext).setImeiInMd5()) {
            new SetPreferences(mContext).setPreferencesData();
            SetPreferences.getDataSharedPrefrences(mContext);
            AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.Airpush.8
                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void onTaskComplete(String result) {
                    Util.printLog("LandingPage Json: " + result);
                    if (result != null) {
                        try {
                            Util.registerApsalarEvent(Airpush.mContext, IConstants.ApSalarEvent.landing_page_call);
                            Airpush.this.parseLandingPageAdJson(result);
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                }

                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void launchNewHttpTask() {
                    try {
                        List<NameValuePair> nameValuePairs = SetPreferences.setValues(Airpush.mContext);
                        Util.printDebugLog("LandingPage AD Values: " + nameValuePairs);
                        HttpPostDataTask httpPostTask = new HttpPostDataTask(Airpush.mContext, nameValuePairs, IConstants.URL_FULL_PAGE, this);
                        httpPostTask.execute(new Void[0]);
                    } catch (Exception e2) {
                    }
                }
            };
            if (Util.checkInternetConnection(mContext)) {
                asyncTaskCompleteListener.launchNewHttpTask();
            }
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    void parseLandingPageAdJson(String json) {
        String status;
        String msg;
        String url;
        if (json != null) {
            try {
                try {
                    JSONObject jsonObject = new JSONObject(json);
                    if (jsonObject.isNull("status")) {
                        status = IConstants.INVALID;
                    } else {
                        status = jsonObject.getString("status");
                    }
                    if (jsonObject.isNull("message")) {
                        msg = IConstants.INVALID;
                    } else {
                        msg = jsonObject.getString("message");
                    }
                    if (status.equals("200") && msg.equals("Success")) {
                        if (jsonObject.isNull(IConstants.NOTIFICATION_URL)) {
                            url = IConstants.INVALID;
                        } else {
                            url = jsonObject.getString(IConstants.NOTIFICATION_URL);
                        }
                        if (!url.equals(IConstants.INVALID)) {
                            SetPreferences.setNextAdCallTime(mContext);
                            Intent intent = new Intent(mContext, (Class<?>) SmartWallActivity.class);
                            intent.setAction("lpad");
                            intent.setFlags(268435456);
                            intent.addFlags(536870912);
                            intent.addFlags(8388608);
                            intent.putExtra(IConstants.AD_TYPE, IConstants.AD_TYPE_FP);
                            intent.putExtra(IConstants.NOTIFICATION_URL, url);
                            try {
                                mContext.startActivity(intent);
                            } catch (ActivityNotFoundException e) {
                                Log.e("AirpushSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                            } catch (Exception e2) {
                            }
                        }
                    }
                } catch (Exception e3) {
                    Util.printLog("Error occured in LandingPage Json: " + e3.getMessage());
                }
            } catch (JSONException e4) {
                Util.printLog("Error in Landing Page Json: " + e4.getMessage());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void startNewAdThread(boolean isOptin) {
        try {
            new Handler().postDelayed(new Runnable() { // from class: com.ncgftm.ganbgg136707.Airpush.9
                @Override // java.lang.Runnable
                public void run() {
                    SetPreferences.enableADPref(Airpush.mContext);
                }
            }, 3000L);
        } catch (Exception e) {
            Util.printLog("An error occured while starting new thread. " + e.getMessage());
            if (adCallbackListener != null) {
                adCallbackListener.onAdError(e.getMessage());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static AdCallbackListener.OptinListener getOptinListener() {
        return optinListener;
    }

    public static void setOptinListener(AdCallbackListener.OptinListener optinListener2) {
        optinListener = optinListener2;
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    public void showRichMediaInterstitialAd() {
        if (mContext == null) {
            Log.e("AirpushSDK", "Context is null.");
            sendIntegrationError("Context is null");
            return;
        }
        if (!this.isDialogClosed && SetPreferences.isShowOptinDialog(mContext)) {
            SharedPreferences preferences = mContext.getSharedPreferences(IConstants.ENABLE_AD_PREF, 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("rich_media", true);
            editor.commit();
            return;
        }
        Log.i("AirpushSDK", "Initialising Rich Media Interstitial Ad.....");
        try {
            if (!Util.isIntentAvailable(mContext, (Class<?>) SmartWallActivity.class)) {
                Log.i("AirpushSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                sendIntegrationError("Required SmartWallActivity not found in Manifest. Please add.");
                return;
            }
        } catch (Exception e) {
        }
        try {
            if (!Util.isIntentAvailable(mContext, (Class<?>) BrowserActivity.class)) {
                Log.i("AirpushSDK", "Required BrowserActivity not found in Manifest. Please add.");
                sendIntegrationError("Required BrowserActivity not found in Manifest. Please add.");
                return;
            }
        } catch (Exception e2) {
        }
        if (mContext == null || !isSDKEnabled(mContext)) {
            Log.i("AirpushSDK", "Airpush SDK is disabled Please enable to recive ads.");
            sendAdError("Airpush SDK is disabled Please enable to recive ads.");
            return;
        }
        if (SetPreferences.getNextAdCallTime(mContext) > System.currentTimeMillis()) {
            Log.i("AirpushSDK", "Rich Media Interstitial Ad called within 20 secs. Ignoring request");
            sendAdError("Rich Media Interstitial Ad called within 20 secs. Ignoring request");
            return;
        }
        if (SmartWallActivity.isShowing()) {
            Log.i("AirpushSDK", "Another ad is showing on screen.");
            sendAdError("Another ad is showing on screen.");
            return;
        }
        SetPreferences.setNextAdCallTime(mContext);
        Util.setContext(mContext);
        if (getDataFromManifest(mContext) && checkRequiredPermission(mContext) && new UserDetails(mContext).setImeiInMd5()) {
            new SetPreferences(mContext).setPreferencesData();
            SetPreferences.getDataSharedPrefrences(mContext);
            AsyncTaskCompleteListener<String> asyncTaskCompleteListener = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.Airpush.10
                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void onTaskComplete(String result) {
                    Log.i("AirpushSDK", "Rich Media Ad Json: " + result);
                    if (result != null) {
                        try {
                            Util.registerApsalarEvent(Airpush.mContext, IConstants.ApSalarEvent.rm_interstitial_call);
                            Airpush.this.parseRichMediaInterstitialJson(result);
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }
                    }
                }

                @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                public void launchNewHttpTask() {
                    try {
                        List<NameValuePair> list = new ArrayList<>();
                        list.add(new BasicNameValuePair("banner_type", "rich_media"));
                        list.add(new BasicNameValuePair("supports", "" + Util.getSupportsJson(Airpush.mContext)));
                        list.add(new BasicNameValuePair("placement_type", "fullpage"));
                        NetworkThread networkThread = new NetworkThread(Airpush.mContext, this, list, IConstants.URL_MRAID_API, 0L, true);
                        Thread thread = new Thread(networkThread, "AdView");
                        thread.start();
                    } catch (Exception e3) {
                    }
                }
            };
            if (Util.checkInternetConnection(mContext)) {
                asyncTaskCompleteListener.launchNewHttpTask();
            }
        }
    }

    @Override // com.ncgftm.ganbgg136707.SDKIntializer
    void parseRichMediaInterstitialJson(String json) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            parseMraidJson = new FormatAds.ParseMraidJson(mContext, jsonObject);
            String adtype = jsonObject.getString(IConstants.AD_TYPE);
            if (adtype == null || !adtype.equals(IConstants.AD_TYPE_MFP)) {
                Log.w("AirpushSDK", "Invalid adtype: " + adtype);
            } else if (Util.getDoc() != null && !Util.getDoc().equals("")) {
                SetPreferences.setNextAdCallTime(mContext);
                Intent intent = new Intent(mContext, (Class<?>) SmartWallActivity.class);
                intent.setAction("mfpad");
                intent.setFlags(268435456);
                intent.addFlags(8388608);
                intent.addFlags(536870912);
                intent.putExtra(IConstants.AD_TYPE, IConstants.AD_TYPE_MFP);
                mContext.startActivity(intent);
            } else {
                AsyncTaskCompleteListener<String> getDoc = new AsyncTaskCompleteListener<String>() { // from class: com.ncgftm.ganbgg136707.Airpush.11
                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    public void onTaskComplete(String result) {
                        if (result != null && !result.equals("")) {
                            Util.setDoc(result);
                            SetPreferences.setNextAdCallTime(Airpush.mContext);
                            Intent intent2 = new Intent(Airpush.mContext, (Class<?>) SmartWallActivity.class);
                            intent2.setAction("mfpad");
                            intent2.setFlags(268435456);
                            intent2.addFlags(8388608);
                            intent2.addFlags(536870912);
                            intent2.putExtra(IConstants.AD_TYPE, IConstants.AD_TYPE_MFP);
                            Airpush.mContext.startActivity(intent2);
                            return;
                        }
                        Log.e("AirpushSDK", "Not able to get doc.");
                    }

                    @Override // com.ncgftm.ganbgg136707.AsyncTaskCompleteListener
                    public void launchNewHttpTask() {
                        Util.NativeMraid nativeMraid = new Util.NativeMraid(Airpush.mContext, this);
                        new Thread(nativeMraid, "native").start();
                    }
                };
                if (Util.checkInternetConnection(mContext)) {
                    getDoc.launchNewHttpTask();
                }
            }
        } catch (IOException e) {
            Log.i("AirpushSDK", "Rich Media Full Page: " + e.getMessage());
        } catch (JSONException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }
}
