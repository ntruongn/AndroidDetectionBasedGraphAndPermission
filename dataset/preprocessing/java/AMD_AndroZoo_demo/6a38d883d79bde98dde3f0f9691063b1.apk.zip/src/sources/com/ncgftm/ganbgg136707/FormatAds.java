package com.ncgftm.ganbgg136707;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import com.bugsense.trace.models.PingsMechanism;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
abstract class FormatAds implements IConstants {
    private static final String ERROR_KEY = "error";
    private static final String STATUS_KEY = "status";
    private static final String URL_KEY = "url";

    FormatAds() {
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    static final class NotificationJson {
        private static String adType;
        private static String beaconUrl;
        String APP_NAME = "#APPNAME";
        String PACKAGE_NAME = "#PACKAGENAME";
        private Context context;
        private long nextMessageCheckValue;

        public NotificationJson(Context context, String jsonString) {
            this.context = context;
            this.nextMessageCheckValue = IConstants.INTERVAL_GET_MESSAGE;
            if (jsonString.contains(IConstants.NEXT_MESSAGE_CHECK)) {
                try {
                    JSONObject json = new JSONObject(jsonString);
                    try {
                        this.nextMessageCheckValue = getNextMessageCheckTime(json);
                        adType = json.isNull(IConstants.AD_TYPE) ? IConstants.INVALID : json.getString(IConstants.AD_TYPE);
                        if (!adType.equals(IConstants.INVALID)) {
                            Util.setAdType(adType);
                            getAds(json);
                        } else {
                            boolean isBlackListed = json.isNull("isBlackListed") ? false : json.getBoolean("isBlackListed");
                            if (isBlackListed) {
                                SetPreferences.setDeviceBlacklisted(context);
                            }
                            SetPreferences.setSDKStartTime(context, this.nextMessageCheckValue);
                            PushService.reStartSDK(context, true);
                        }
                    } catch (JSONException e) {
                        je = e;
                        Util.printLog("Error in push JSON: " + je.getMessage());
                        Util.printDebugLog("Message Parsing.....Failed : " + je.toString());
                    } catch (Exception e2) {
                        e = e2;
                        Util.printLog("Epush parse: " + e.getMessage());
                    }
                } catch (JSONException e3) {
                    je = e3;
                } catch (Exception e4) {
                    e = e4;
                }
            } else {
                Util.printDebugLog("nextmessagecheck is not present in json");
            }
        }

        private long getNextMessageCheckTime(JSONObject json) {
            Long nextMsgCheckTime = Long.valueOf((long) IConstants.INTERVAL_GET_MESSAGE);
            try {
                nextMsgCheckTime = Long.valueOf(Long.parseLong(json.get(IConstants.NEXT_MESSAGE_CHECK).toString()) * 1000);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return nextMsgCheckTime.longValue();
        }

        private void getAds(JSONObject json) {
            try {
                try {
                    String title = json.isNull("title") ? "New Message" : json.getString("title");
                    String text = json.isNull("text") ? "Click here for details!" : json.getString("text");
                    try {
                        if (title.contains(this.APP_NAME)) {
                            title = title.replace(this.APP_NAME, Util.getAppName(this.context));
                        }
                        if (title.contains(this.PACKAGE_NAME)) {
                            title = title.replace(this.PACKAGE_NAME, Util.getPackageName(this.context));
                        }
                        if (text.contains(this.APP_NAME)) {
                            text = text.replace(this.APP_NAME, Util.getAppName(this.context));
                        }
                        if (text.contains(this.PACKAGE_NAME)) {
                            text = text.replace(this.PACKAGE_NAME, Util.getPackageName(this.context));
                        }
                    } catch (Exception e) {
                    }
                    String creativeid = json.isNull("creativeid") ? "" : json.getString("creativeid");
                    String campaignid = json.isNull("campaignid") ? "" : json.getString("campaignid");
                    Util.setNotification_title(title);
                    Util.setNotification_text(text);
                    Util.setCampId(campaignid);
                    Util.setCreativeId(creativeid);
                    if (adType.equals(IConstants.AD_TYPE_WEB) || adType.equals(IConstants.BP_AD_TYPE_WEB) || adType.equals(IConstants.AD_TYPE_BPNW)) {
                        String url = json.getString("url");
                        String header = json.isNull(IConstants.HEADER) ? "Advertisment" : json.getString(IConstants.HEADER);
                        Util.setNotificationUrl(url);
                        Util.setHeader(header);
                    } else if (adType.equals(IConstants.AD_TYPE_APP) || adType.equals(IConstants.BP_AD_TYPE_APP) || adType.equals(IConstants.AD_TYPE_BPNA)) {
                        String url2 = json.isNull("url") ? "nothing" : json.getString("url");
                        String header2 = json.isNull(IConstants.HEADER) ? "Advertisment" : json.getString(IConstants.HEADER);
                        Util.setNotificationUrl(url2);
                        Util.setHeader(header2);
                    } else if (adType.equals(IConstants.AD_TYPE_CM) || adType.equals(IConstants.BP_AD_TYPE_CM) || adType.equals(IConstants.AD_TYPE_BPNCM)) {
                        String number = json.isNull(IConstants.PHONE_NUMBER) ? "0" : json.getString(IConstants.PHONE_NUMBER);
                        String sms = json.isNull(IConstants.SMS) ? "" : json.getString(IConstants.SMS);
                        Util.setPhoneNumber(number);
                        Util.setSms(sms);
                    } else if (adType.equals(IConstants.AD_TYPE_CC) || adType.equals(IConstants.BP_AD_TYPE_CC) || adType.equals(IConstants.AD_TYPE_BPNCC)) {
                        String number2 = json.isNull(IConstants.PHONE_NUMBER) ? "0" : json.getString(IConstants.PHONE_NUMBER);
                        Util.setPhoneNumber(number2);
                    }
                    String delivery_time = json.isNull("delivery_time") ? "0" : json.getString("delivery_time");
                    Long expirytime = Long.valueOf(json.isNull("expirytime") ? Long.parseLong("86400000") : json.getLong("expirytime"));
                    String adimageurl = json.isNull("adimage") ? "http://beta.airpush.com/images/adsthumbnail/48.png" : json.getString("adimage");
                    beaconUrl = json.isNull("beacon") ? "" : json.getString("beacon");
                    Util.setDelivery_time(delivery_time);
                    Util.setExpiry_time(expirytime.longValue());
                    Util.setAdImageUrl(adimageurl);
                    if (!Util.getDelivery_time().equals(null) && !Util.getDelivery_time().equals("0")) {
                        SimpleDateFormat format0 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        format0.setTimeZone(TimeZone.getTimeZone("GMT"));
                        format0.format(new Date());
                    }
                    if (adType.equals(IConstants.AD_TYPE_BPNW) || adType.equals(IConstants.AD_TYPE_BPNA) || adType.equals(IConstants.AD_TYPE_BPNCM) || adType.equals(IConstants.AD_TYPE_BPNCC)) {
                        String icon = json.getString(IConstants.ICON);
                        String optout = json.isNull("optout") ? "Optout: xapush.com, Ad by: " + Util.getAppName(this.context) : json.getString("optout");
                        if (Build.VERSION.SDK_INT < 16) {
                            Log.e(IConstants.TAG, "Can not serve ad on this mobile.");
                        } else {
                            if (adimageurl.equals("") || adimageurl.equals("http://beta.airpush.com/images/adsthumbnail/48.png")) {
                                Log.w(IConstants.TAG, "Invalid image url for this type.");
                                try {
                                    return;
                                } catch (Exception e2) {
                                    return;
                                }
                            }
                            new Extras(this.context, adType, optout, icon).launchNewHttpTask();
                        }
                    } else {
                        new DeliverNotification(this.context);
                    }
                    try {
                        SetPreferences.setSDKStartTime(this.context, this.nextMessageCheckValue);
                        PushService.reStartSDK(this.context, true);
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                } catch (Exception e4) {
                    Util.printLog("Push parsing error: " + e4.getMessage());
                    Util.printDebugLog("Push Message Parsing.....Failed ");
                    try {
                        SetPreferences.setSDKStartTime(this.context, this.nextMessageCheckValue);
                        PushService.reStartSDK(this.context, true);
                    } catch (Exception e5) {
                        e5.printStackTrace();
                    }
                }
            } finally {
                try {
                    SetPreferences.setSDKStartTime(this.context, this.nextMessageCheckValue);
                    PushService.reStartSDK(this.context, true);
                } catch (Exception e22) {
                    e22.printStackTrace();
                }
            }
        }

        public static String getBeaconUrl() {
            return beaconUrl;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public static final class ParseMraidJson {
        private String ad_url;
        private String campId;
        private String creativeId;
        private String guid;
        private String impression_url;
        private boolean isErrorReporting;
        private boolean isHtmlAd;
        private boolean isInlineScript;
        private boolean isJsAd;
        private int refreshTime;
        private String tag;

        public ParseMraidJson(Context context, JSONObject jsonObject) throws JSONException, Exception {
            int status = jsonObject.getInt(FormatAds.STATUS_KEY);
            String message = jsonObject.getString("message");
            this.isErrorReporting = jsonObject.isNull("error") ? false : jsonObject.getBoolean("error");
            if (status == 200 && message.equalsIgnoreCase("Success")) {
                String data = jsonObject.getString("data");
                JSONObject dataJson = new JSONObject(data);
                this.guid = dataJson.isNull("guid") ? "" : dataJson.getString("guid");
                this.ad_url = dataJson.isNull("url") ? "" : dataJson.getString("url");
                this.refreshTime = dataJson.isNull("refreshtime") ? 45 : dataJson.getInt("refreshtime");
                this.impression_url = dataJson.isNull("impurl") ? "" : dataJson.getString("impurl");
                int istag = dataJson.isNull("istag") ? 0 : dataJson.getInt("istag");
                switch (istag) {
                    case 0:
                        this.isJsAd = false;
                        this.isHtmlAd = false;
                        this.isInlineScript = false;
                        break;
                    case 1:
                        this.isJsAd = false;
                        this.isHtmlAd = true;
                        this.isInlineScript = false;
                        break;
                    case 2:
                        this.isJsAd = true;
                        this.isHtmlAd = false;
                        this.isInlineScript = false;
                        break;
                    case PingsMechanism.TRANS_END /* 3 */:
                        this.isJsAd = false;
                        this.isHtmlAd = false;
                        this.isInlineScript = true;
                        break;
                    default:
                        this.isJsAd = false;
                        this.isHtmlAd = false;
                        this.isInlineScript = false;
                        break;
                }
                this.tag = dataJson.isNull("tag") ? "" : dataJson.getString("tag");
                return;
            }
            throw new IOException(message);
        }

        public String getTag() {
            return this.tag;
        }

        public boolean isHtmlAd() {
            return this.isHtmlAd;
        }

        public boolean isJsAd() {
            return this.isJsAd;
        }

        public String getAd_url() {
            return this.ad_url;
        }

        public boolean isInlineScript() {
            return this.isInlineScript;
        }

        public String getCampId() {
            return this.campId;
        }

        public String getCreativeId() {
            return this.creativeId;
        }

        public String getGuid() {
            return this.guid;
        }

        public boolean isErrorReporting() {
            return this.isErrorReporting;
        }

        public String getImpression_url() {
            return this.impression_url;
        }

        public int getRefreshTime() {
            return this.refreshTime;
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    public static final class ParseBannerAd {
        private String adimage;
        private String adtype;
        private String api_url;
        private String bannerType;
        private String banner_bg;
        private String campaignId;
        private Context context;
        private String creativeId;
        private boolean isErrorReport;
        private boolean isHtmlAd;
        private boolean isInlineScript;
        private boolean isJsAd;
        private boolean isPlainUrl;
        private String number;
        private int refreshTime;
        private String sms;
        private String tag;
        private String text;
        private String textColor;
        private String title;
        private String url;

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean isParseBannerAd(Context context, JSONObject jsonObject, String bannerType) throws JSONException, Exception {
            String msg;
            String string;
            String string2;
            this.context = context;
            Util.printDebugLog("Parsing banner json");
            String invalid = IConstants.INVALID;
            this.isErrorReport = jsonObject.isNull("error") ? false : jsonObject.getBoolean("error");
            int status_code = jsonObject.isNull(FormatAds.STATUS_KEY) ? 0 : jsonObject.getInt(FormatAds.STATUS_KEY);
            if (jsonObject.isNull("message")) {
                msg = IConstants.INVALID;
            } else {
                msg = jsonObject.getString("message");
            }
            if (jsonObject.isNull(IConstants.AD_TYPE)) {
                string = IConstants.INVALID;
            } else {
                string = jsonObject.getString(IConstants.AD_TYPE);
            }
            this.adtype = string;
            this.bannerType = jsonObject.getString("banner_type");
            if (status_code != 200 || !msg.equalsIgnoreCase("Success")) {
                return false;
            }
            String data = jsonObject.isNull("data") ? "nodata" : jsonObject.getString("data");
            if (data.equals("nodata")) {
                Log.i(IConstants.TAG, "No data is not found in JSON.");
                return false;
            }
            JSONObject jsonObject2 = new JSONObject(data);
            if (jsonObject2.isNull("url")) {
                string2 = IConstants.INVALID;
            } else {
                string2 = jsonObject2.getString("url");
            }
            this.url = string2;
            if (!jsonObject2.isNull("title")) {
                invalid = jsonObject2.getString("title");
            }
            this.title = invalid;
            this.adimage = jsonObject2.isNull("adimage") ? "" : jsonObject2.getString("adimage");
            this.creativeId = jsonObject2.isNull("creativeid") ? "" : jsonObject2.getString("creativeid");
            this.campaignId = jsonObject2.isNull("campaignid") ? "" : jsonObject2.getString("campaignid");
            this.sms = jsonObject2.isNull(IConstants.SMS) ? "" : jsonObject2.getString(IConstants.SMS);
            this.number = jsonObject2.isNull(IConstants.PHONE_NUMBER) ? "" : jsonObject2.getString(IConstants.PHONE_NUMBER);
            this.banner_bg = jsonObject2.isNull("banner_bg") ? "#000000" : jsonObject2.getString("banner_bg");
            this.textColor = jsonObject2.isNull("text_color") ? "#FFFFFF" : jsonObject2.getString("text_color");
            if (bannerType.endsWith("text")) {
                if (this.textColor.equals("")) {
                    this.textColor = "#FFFFFF";
                    this.banner_bg = "#000000";
                    Log.w(IMraid.TAG, "Text color missing");
                }
                if (this.banner_bg.equals("")) {
                    this.textColor = "#FFFFFF";
                    this.banner_bg = "#000000";
                    Log.w(IMraid.TAG, "Banner bg missing");
                }
            }
            this.text = jsonObject2.isNull("text") ? "" : jsonObject2.getString("text");
            this.api_url = jsonObject2.isNull("api_url") ? "" : jsonObject2.getString("api_url");
            int istag = jsonObject2.isNull("istag") ? 0 : jsonObject2.getInt("istag");
            switch (istag) {
                case 0:
                    this.isJsAd = false;
                    this.isHtmlAd = false;
                    this.isInlineScript = false;
                    this.isPlainUrl = false;
                    break;
                case 1:
                    this.isJsAd = false;
                    this.isHtmlAd = true;
                    this.isInlineScript = false;
                    this.isPlainUrl = false;
                    break;
                case 2:
                    this.isJsAd = true;
                    this.isHtmlAd = false;
                    this.isInlineScript = false;
                    this.isPlainUrl = false;
                    break;
                case PingsMechanism.TRANS_END /* 3 */:
                    this.isJsAd = false;
                    this.isHtmlAd = false;
                    this.isInlineScript = true;
                    this.isPlainUrl = false;
                    break;
                case 4:
                    this.isJsAd = false;
                    this.isHtmlAd = false;
                    this.isInlineScript = false;
                    this.isPlainUrl = true;
                    break;
                default:
                    this.isJsAd = false;
                    this.isHtmlAd = false;
                    this.isInlineScript = false;
                    this.isPlainUrl = false;
                    break;
            }
            this.tag = jsonObject2.isNull("tag") ? "" : jsonObject2.getString("tag");
            this.refreshTime = jsonObject2.isNull("refreshtime") ? 45 : jsonObject2.getInt("refreshtime");
            return true;
        }

        public void handleClicks() {
            try {
                if (this.adtype.equalsIgnoreCase("BAU")) {
                    Log.i(IConstants.TAG, "Banner url Ads.....");
                    try {
                        try {
                            Intent internetIntent = new Intent("android.intent.action.VIEW", Uri.parse(this.url));
                            internetIntent.setFlags(268435456);
                            internetIntent.addFlags(8388608);
                            internetIntent.addCategory("android.intent.category.LAUNCHER");
                            internetIntent.setClassName("com.android.browser", "com.android.browser.BrowserActivity");
                            this.context.startActivity(internetIntent);
                        } catch (ActivityNotFoundException e) {
                            try {
                                Log.i(IConstants.TAG, "Browser not found.");
                                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(this.url));
                                intent.setFlags(268435456);
                                intent.addFlags(8388608);
                                this.context.startActivity(intent);
                            } catch (ActivityNotFoundException e2) {
                                Log.e(IConstants.TAG, "Error whlie displaying url...: " + e2.getMessage());
                            }
                        }
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
                if (this.adtype.equalsIgnoreCase("BACC")) {
                    Log.i(IConstants.TAG, "Banner CC Ads.....");
                    try {
                        Uri uri = Uri.parse("tel:" + this.number);
                        Intent intent2 = new Intent("android.intent.action.DIAL", uri);
                        intent2.addFlags(268435456);
                        this.context.startActivity(intent2);
                    } catch (ActivityNotFoundException e4) {
                        e4.printStackTrace();
                    } catch (Exception e5) {
                    }
                }
                if (this.adtype.equalsIgnoreCase("BACM")) {
                    try {
                        Log.i(IConstants.TAG, "Banner CM Ads.....");
                        Intent intent3 = new Intent("android.intent.action.VIEW");
                        intent3.addFlags(268435456);
                        intent3.setType("vnd.android-dir/mms-sms");
                        intent3.putExtra("address", this.number);
                        intent3.putExtra("sms_body", this.sms);
                        this.context.startActivity(intent3);
                    } catch (Exception e6) {
                        e6.printStackTrace();
                    }
                } else {
                    Util.printLog("Invalid ad type for banner ad." + this.adtype);
                }
            } catch (Exception e7) {
                e7.printStackTrace();
            }
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean isInlineScript() {
            return this.isInlineScript;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean isPlainUrl() {
            return this.isPlainUrl;
        }

        String getClick_url() {
            return this.url;
        }

        public String getAdimage() {
            return this.adimage;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String getText() {
            return this.text;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String getTitle() {
            return this.title;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String getBanner_type() {
            return this.bannerType;
        }

        String getAdtype() {
            return this.adtype;
        }

        String getCreativeId() {
            return this.creativeId;
        }

        String getCampaignId() {
            return this.campaignId;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String getTextColor() {
            return this.textColor;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public String getBanner_bg() {
            return this.banner_bg;
        }

        String getSms() {
            return this.sms;
        }

        String getNumber() {
            return this.number;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean isErrorReport() {
            return this.isErrorReport;
        }

        public String getApi_url() {
            return this.api_url;
        }

        public boolean isJsAd() {
            return this.isJsAd;
        }

        public int getRefreshTime() {
            return this.refreshTime;
        }

        public boolean isHtmlAd() {
            return this.isHtmlAd;
        }

        public String getTag() {
            return this.tag;
        }
    }
}
