package com.bugsense.trace;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.util.Log;
import com.ncgftm.ganbgg136707.IConstants;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class BugSense {
    private static ExecutorService executor = Executors.newFixedThreadPool(2);

    public static ExecutorService getExecutor() {
        if (executor == null) {
            executor = Executors.newFixedThreadPool(2);
        }
        return executor;
    }

    public static void showUpgradeNotification(Context context, String str) {
        if (BugSenseHandler.I_WANT_TO_DEBUG) {
            Log.i(G.TAG, "Show notification: " + str);
        }
        if (str == null || str.length() <= 5) {
            return;
        }
        try {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
            JSONObject jSONObject = new JSONObject(new JSONObject(str).getString("data"));
            String string = (BugSenseHandler.locTicker == null || BugSenseHandler.locTicker.length() <= 1) ? jSONObject.getString("tickerText") : BugSenseHandler.locTicker;
            long currentTimeMillis = System.currentTimeMillis();
            Resources resources = context.getResources();
            int identifier = resources.getIdentifier("ic_launcher", "drawable", context.getPackageName());
            if (identifier == 0) {
                identifier = resources.getIdentifier(IConstants.ICON, "drawable", context.getPackageName());
            }
            Notification notification = new Notification(identifier, string, currentTimeMillis);
            notification.flags = 16;
            String string2 = (BugSenseHandler.locTitle == null || BugSenseHandler.locTitle.length() <= 1) ? jSONObject.getString("contentTitle") : BugSenseHandler.locTitle;
            String string3 = jSONObject.getString("contentText");
            if (BugSenseHandler.locText != null && BugSenseHandler.locText.length() > 1) {
                string3 = BugSenseHandler.locText;
            }
            notification.setLatestEventInfo(context, string2, string3, PendingIntent.getActivity(context, 0, new Intent("android.intent.action.VIEW", Uri.parse(jSONObject.getString(IConstants.NOTIFICATION_URL))), 268435456));
            notificationManager.notify(1, notification);
        } catch (Exception e) {
            Log.e(G.TAG, "Error starting fix notification");
            if (BugSenseHandler.I_WANT_TO_DEBUG) {
                e.printStackTrace();
            }
        }
    }
}
