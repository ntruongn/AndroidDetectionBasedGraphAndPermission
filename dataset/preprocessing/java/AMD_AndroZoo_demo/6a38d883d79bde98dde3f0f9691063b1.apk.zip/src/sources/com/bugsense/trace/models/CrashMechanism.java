package com.bugsense.trace.models;

import android.content.Context;
import android.util.Log;
import com.bugsense.trace.BugSense;
import com.bugsense.trace.BugSenseHandler;
import com.bugsense.trace.G;
import com.bugsense.trace.Utils;
import com.ncgftm.ganbgg136707.IConstants;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import org.apache.http.HttpEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public final class CrashMechanism {
    public static final int CRASH = 1;
    public static final int HANDLEDEXCEPTION = 0;
    private static final int MAX_CRASHES = 5;
    private static final int MAX_EXCEPTIONS = 8;
    private static volatile CrashMechanism instance;

    public static String createJSONFromCrash(String str, int i, int i2, int i3, String[] strArr, String str2, Map<String, String> map, Map<String, String> map2, int i4, long j, Map<String, String> map3) throws Exception {
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = new JSONObject();
        JSONObject jSONObject3 = new JSONObject();
        JSONObject jSONObject4 = new JSONObject();
        JSONObject jSONObject5 = new JSONObject();
        JSONObject jSONObject6 = new JSONObject();
        JSONObject jSONObject7 = new JSONObject();
        jSONObject2.put("remote_ip", "");
        JSONObject jSONObject8 = new JSONObject();
        jSONObject8.put("appid", G.APPID);
        jSONObject2.put("extra_data", jSONObject8);
        jSONObject.put("request", jSONObject2);
        BufferedReader bufferedReader = new BufferedReader(new StringReader(str));
        if (str2 == null) {
            jSONObject3.put("occured_at", bufferedReader.readLine());
        } else {
            jSONObject3.put("occured_at", str2);
        }
        jSONObject3.put("message", bufferedReader.readLine());
        String readLine = bufferedReader.readLine();
        try {
            readLine = readLine.substring(readLine.lastIndexOf("(") + 1, readLine.lastIndexOf(")"));
        } catch (Exception e) {
        }
        jSONObject3.put("where", readLine);
        jSONObject3.put("handled", i4);
        jSONObject3.put("klass", getClass(str));
        jSONObject3.put("backtrace", str);
        jSONObject3.put("breadcrumbs", getBreadcrumbsLine(G.breadcrumbs));
        jSONObject.put("exception", jSONObject3);
        bufferedReader.close();
        jSONObject5.put("uid", G.UID);
        jSONObject5.put("phone", G.PHONE_MODEL);
        jSONObject5.put("brand", G.PHONE_BRAND);
        jSONObject5.put("appver", G.APP_VERSION);
        jSONObject5.put("appname", G.APP_PACKAGE);
        jSONObject5.put("internal_version", G.APP_VERSIONCODE);
        jSONObject5.put("osver", G.ANDROID_VERSION);
        jSONObject5.put("wifi_on", i);
        jSONObject5.put("mobile_net_on", i2);
        jSONObject5.put("gps_on", i3);
        jSONObject5.put("screen:width", strArr[0]);
        jSONObject5.put("screen:height", strArr[1]);
        jSONObject5.put("screen:orientation", strArr[2]);
        jSONObject5.put("screen_dpi(x:y)", strArr[3] + ":" + strArr[4]);
        if (map2 != null) {
            map.putAll(map2);
        }
        if (G.SEND_LOG && i4 == 1) {
            map.put(IConstants.MODEL_LOG, Utils.readLogs());
        }
        map.put("rooted", String.valueOf(G.HAS_ROOT));
        map.put("ms_from_start", String.valueOf(j));
        if (map != null && !map.isEmpty()) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                jSONObject4.put(entry.getKey(), entry.getValue());
            }
            jSONObject5.put("log_data", jSONObject4);
        }
        if (map3 != null && !map3.isEmpty()) {
            for (Map.Entry<String, String> entry2 : map3.entrySet()) {
                jSONObject6.put(entry2.getKey(), entry2.getValue());
            }
            jSONObject.put("performance", jSONObject6);
        }
        jSONObject.put("application_environment", jSONObject5);
        jSONObject7.put(IConstants.ANDROID_VERSION, G.BUGSENSE_VERSION);
        jSONObject7.put("name", "bugsense-android");
        jSONObject.put("client", jSONObject7);
        return jSONObject.toString();
    }

    private static String getBreadcrumbsLine(ArrayList<String> arrayList) {
        if (arrayList == null || arrayList.size() == 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        Iterator<String> it = arrayList.iterator();
        while (it.hasNext()) {
            String replaceAll = it.next().replaceAll("\\|", "_");
            if (replaceAll.charAt(0) == '_') {
                replaceAll = replaceAll.replaceFirst("_", "-");
            }
            sb.append(replaceAll);
            sb.append("|");
        }
        try {
            return sb.toString().substring(0, sb.toString().length() - 1);
        } catch (Exception e) {
            Log.e(G.TAG, "Error occured in breadcrumbs");
            return "";
        }
    }

    private static String getClass(String str) {
        try {
            int indexOf = str.indexOf(":");
            return (indexOf == -1 || indexOf + 1 >= str.length()) ? "" : str.substring(0, indexOf);
        } catch (Exception e) {
            return "";
        }
    }

    public static CrashMechanism getInstance() {
        if (instance == null) {
            instance = new CrashMechanism();
        }
        return instance;
    }

    public static void saveCrash(final String str, final int i) {
        Thread thread = new Thread(new Runnable() { // from class: com.bugsense.trace.models.CrashMechanism.3
            @Override // java.lang.Runnable
            public void run() {
                try {
                    BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(G.FILES_PATH + "/" + ((i == 0 ? "Exception_" : "Crash_") + String.valueOf(System.currentTimeMillis()) + "-" + Integer.toString(new Random(System.currentTimeMillis()).nextInt(99999)))));
                    bufferedWriter.write(str);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                } catch (IOException e) {
                    Log.e(G.TAG, "Error saving crash data");
                    if (BugSenseHandler.I_WANT_TO_DEBUG) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ExecutorService executor = BugSense.getExecutor();
        if (thread == null || executor == null) {
            return;
        }
        executor.submit(thread);
    }

    public static void transmitCrashASync(final Context context, final String str, final int i) {
        Thread thread = new Thread(new Runnable() { // from class: com.bugsense.trace.models.CrashMechanism.2
            @Override // java.lang.Runnable
            public void run() {
                if (CrashMechanism.transmitCrashSync(context, str, i)) {
                    return;
                }
                CrashMechanism.saveCrash(str, i);
            }
        });
        ExecutorService executor = BugSense.getExecutor();
        if (thread == null || executor == null) {
            return;
        }
        executor.submit(thread);
    }

    public static boolean transmitCrashSync(Context context, String str, int i) {
        if (BugSenseHandler.I_WANT_TO_DEBUG) {
            Log.d(G.TAG, "URL: " + G.URL);
            Log.d(G.TAG, "APIKEY: " + G.API_KEY);
        }
        if (str.length() > 10) {
            ArrayList arrayList = new ArrayList();
            DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
            HttpParams params = defaultHttpClient.getParams();
            HttpProtocolParams.setUseExpectContinue(params, false);
            HttpConnectionParams.setConnectionTimeout(params, 20000);
            HttpConnectionParams.setSoTimeout(params, 20000);
            HttpPost httpPost = new HttpPost(G.URL);
            httpPost.addHeader("X-BugSense-Api-Key", G.API_KEY);
            try {
                arrayList.add(new BasicNameValuePair("data", str));
                httpPost.setEntity(new UrlEncodedFormEntity(arrayList, "UTF-8"));
                HttpEntity entity = defaultHttpClient.execute(httpPost).getEntity();
                if (entity == null) {
                    Log.w(G.TAG, "It seems that there is no internet connectivity");
                    throw new Exception("no internet connection");
                }
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(entity.getContent()));
                String readLine = bufferedReader.readLine();
                bufferedReader.close();
                if (BugSenseHandler.I_WANT_TO_DEBUG) {
                    Log.i(G.TAG, "Crash Response: " + readLine);
                }
                if (readLine != null && readLine.contains("tickerText") && readLine.contains("contentTitle") && readLine.contains(IConstants.NOTIFICATION_URL)) {
                    BugSense.showUpgradeNotification(context, readLine);
                }
            } catch (Exception e) {
                Log.w(G.TAG, "Transmitting crash Exception " + e.getMessage());
                if (!BugSenseHandler.I_WANT_TO_DEBUG) {
                    return false;
                }
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    public synchronized void sendSavedCrashes(final Context context) {
        Thread thread = new Thread(new Runnable() { // from class: com.bugsense.trace.models.CrashMechanism.1
            @Override // java.lang.Runnable
            public void run() {
                File file = new File(G.FILES_PATH);
                if (!file.exists()) {
                    file.mkdir();
                }
                FilenameFilter filenameFilter = new FilenameFilter() { // from class: com.bugsense.trace.models.CrashMechanism.1.1
                    @Override // java.io.FilenameFilter
                    public boolean accept(File file2, String str) {
                        return str.startsWith("Crash_");
                    }
                };
                FilenameFilter filenameFilter2 = new FilenameFilter() { // from class: com.bugsense.trace.models.CrashMechanism.1.2
                    @Override // java.io.FilenameFilter
                    public boolean accept(File file2, String str) {
                        return str.startsWith("Exception_");
                    }
                };
                String[] list = file.list(filenameFilter);
                String[] list2 = file.list(filenameFilter2);
                if (BugSenseHandler.I_WANT_TO_DEBUG) {
                    Log.d(G.TAG, "Crash List has: " + list.length + " items");
                    Log.d(G.TAG, "HandledEx List has: " + list2.length + " items");
                }
                int i = CrashMechanism.MAX_CRASHES;
                if (CrashMechanism.MAX_CRASHES > list.length) {
                    i = list.length;
                }
                int i2 = 0;
                while (i2 < i && CrashMechanism.transmitCrashSync(context, Utils.readFile(G.FILES_PATH + "/" + list[i2]), 1)) {
                    i2++;
                }
                if (i2 >= 1) {
                    for (int i3 = 0; i3 < list.length; i3++) {
                        try {
                            new File(G.FILES_PATH + "/" + list[i3]).delete();
                        } catch (Exception e) {
                            Log.e(G.TAG, "Error deleting trace file: " + G.FILES_PATH + "/" + list[i3], e);
                        }
                    }
                }
                int i4 = CrashMechanism.MAX_EXCEPTIONS;
                if (CrashMechanism.MAX_EXCEPTIONS > list2.length) {
                    i4 = list2.length;
                }
                int i5 = 0;
                while (i5 < i4 && CrashMechanism.transmitCrashSync(context, Utils.readFile(G.FILES_PATH + "/" + list2[i5]), 0)) {
                    i5++;
                }
                if (i5 >= 1) {
                    for (int i6 = 0; i6 < list2.length; i6++) {
                        try {
                            new File(G.FILES_PATH + "/" + list2[i6]).delete();
                        } catch (Exception e2) {
                            Log.e(G.TAG, "Error deleting trace file: " + G.FILES_PATH + "/" + list2[i6], e2);
                        }
                    }
                }
            }
        });
        ExecutorService executor = BugSense.getExecutor();
        if (thread != null && executor != null) {
            executor.submit(thread);
        }
    }
}
