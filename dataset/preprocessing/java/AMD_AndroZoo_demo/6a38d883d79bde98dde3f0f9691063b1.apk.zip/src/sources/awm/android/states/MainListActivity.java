package awm.android.states;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.ncgftm.ganbgg136707.Airpush;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
public class MainListActivity extends Activity implements AdapterView.OnItemClickListener {
    Airpush airpush;
    private LinearLayout llSearchNotFound;
    private ListView lvStateList;
    private ArrayList<String> myList;
    private ArrayList<String> tempMyList = new ArrayList<>();
    private boolean bTempListIsSet = false;

    @Override // android.app.Activity
    public void onStop() {
        this.airpush.startPushNotification(false);
        this.airpush.startIconAd();
        this.airpush.showRichMediaInterstitialAd();
        super.onStop();
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        MyListObject myListObject = null;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainlistactivity_main);
        if (this.airpush == null) {
            this.airpush = new Airpush(getApplicationContext(), null);
        }
        this.llSearchNotFound = (LinearLayout) findViewById(R.id.llSearchNotFound);
        this.lvStateList = (ListView) findViewById(R.id.lvList);
        MyListObject mInstance = new MyListObject(this, myListObject);
        this.myList = mInstance.getMyList();
        this.lvStateList.setAdapter((ListAdapter) new ArrayAdapter(this, (int) R.layout.listitemview, this.myList));
        this.lvStateList.setOnItemClickListener(this);
        EditText etSearchmyList = (EditText) findViewById(R.id.etSearchItems);
        etSearchmyList.addTextChangedListener(new TextWatcher() { // from class: awm.android.states.MainListActivity.1
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable arg0) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                MainListActivity.this.bTempListIsSet = true;
                EditText editText = (EditText) MainListActivity.this.findViewById(R.id.etSearchItems);
                int textLength = editText.getText().length();
                MainListActivity.this.tempMyList.clear();
                for (int j = 0; j < MainListActivity.this.myList.size(); j++) {
                    if (textLength <= ((String) MainListActivity.this.myList.get(j)).length() && ((String) MainListActivity.this.myList.get(j)).toString().toLowerCase().contains(editText.getText().toString().toLowerCase())) {
                        MainListActivity.this.tempMyList.add((String) MainListActivity.this.myList.get(j));
                    }
                }
                Log.d("onCreate", "3");
                MainListActivity.this.lvStateList.setAdapter((ListAdapter) new ArrayAdapter(MainListActivity.this.getApplicationContext(), (int) R.layout.listitemview, MainListActivity.this.tempMyList));
                if (MainListActivity.this.lvStateList.getCount() <= 0) {
                    MainListActivity.this.llSearchNotFound.setVisibility(0);
                }
            }
        });
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        String query;
        if (this.bTempListIsSet) {
            query = "";
            try {
                query = URLEncoder.encode(this.tempMyList.get(position), "utf-8");
                return;
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return;
            } finally {
            }
        }
        query = "";
        try {
            query = URLEncoder.encode(this.myList.get(position), "utf-8");
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        } finally {
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/6a38d883d79bde98dde3f0f9691063b1.apk/classes.dex */
    private static class MyListObject {
        Context mContext;
        ArrayList<String> stateList;

        private MyListObject(Context context) {
            this.stateList = new ArrayList<>();
            this.mContext = context;
            setMyList(this.mContext);
        }

        /* synthetic */ MyListObject(Context context, MyListObject myListObject) {
            this(context);
        }

        private void setMyList(Context context) {
            Resources rInstance = context.getResources();
            String[] stateNameArray = rInstance.getStringArray(R.array.stateslist);
            for (String str : stateNameArray) {
                this.stateList.add(str);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public ArrayList<String> getMyList() {
            return this.stateList;
        }
    }
}
