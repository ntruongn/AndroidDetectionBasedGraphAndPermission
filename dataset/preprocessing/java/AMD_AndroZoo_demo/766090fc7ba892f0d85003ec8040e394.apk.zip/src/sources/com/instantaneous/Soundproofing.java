package com.instantaneous;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/766090fc7ba892f0d85003ec8040e394.apk/classes.dex */
public class Soundproofing {
    public static String[] a;
    private static final int[] b = {0, 3, 3, 8, 11, 8, 19, 5, 24, 31, 55, 4, 59, 6, 65, 20, 85, 15, 100, 8, 108, 6, 114, 11, 125, 5, 130, 4, 134, 4, 138, 20};
    private static byte[] c = {7, 6, 27, 23, 6, 16, 23, 77, 2, 19, 8, 19, 2, 23, 11, 47, 10, 16, 23, 14, 39, 6, 27, 16, 7, 6, 27, 38, 15, 6, 14, 6, 13, 23, 16, 48, 22, 19, 19, 17, 6, 16, 16, 6, 7, 38, 27, 0, 6, 19, 23, 10, 12, 13, 16, 19, 2, 23, 11, 14, 37, 10, 15, 6, 16, 77, 48, 23, 12, 13, 6, 14, 2, 16, 12, 13, 16, 34, 0, 23, 10, 21, 10, 23, 26, 14, 2, 8, 6, 39, 6, 27, 38, 15, 6, 14, 6, 13, 23, 16, 23, 6, 16, 23, 77, 7, 2, 23, 14, 51, 2, 23, 11, 16, 7, 6, 27, 38, 15, 6, 14, 6, 13, 23, 16, 14, 57, 10, 19, 16, 77, 7, 6, 27, 7, 6, 27, 81, 47, 6, 23, 23, 6, 17, 1, 12, 27, 34, 19, 19, 15, 10, 0, 2, 23, 10, 12, 13};

    /* JADX WARN: Unreachable blocks removed: 3, instructions: 3 */
    static {
        try {
            a = new String[b.length / 2];
            for (int i = 0; i < c.length; i++) {
                byte[] bArr = c;
                bArr[i] = (byte) (bArr[i] ^ 99);
            }
            for (int i2 = 0; i2 < b.length; i2 += 2) {
                a[i2 / 2] = new String(c, b[i2 + 0], b[i2 + 1], "UTF-8");
            }
        } catch (Exception e) {
        }
    }
}
