package com.droidhen.api.scoreclient.ui;

import android.view.View;
import android.widget.AdapterView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class k implements AdapterView.OnItemSelectedListener {
    final /* synthetic */ HighScoresActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(HighScoresActivity highScoresActivity) {
        this.a = highScoresActivity;
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView adapterView, View view, int i, long j) {
        int i2;
        i2 = this.a.l;
        if (i2 != i) {
            this.a.l = i;
            this.a.b();
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView adapterView) {
    }
}
