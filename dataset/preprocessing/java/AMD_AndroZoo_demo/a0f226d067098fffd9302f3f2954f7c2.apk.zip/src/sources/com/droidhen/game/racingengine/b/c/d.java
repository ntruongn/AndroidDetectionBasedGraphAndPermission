package com.droidhen.game.racingengine.b.c;

import com.droidhen.game.racingengine.a.a.g;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d implements e {
    public int a;
    public String b;
    public String c;
    public boolean d;
    public float e;
    public float f;
    public float g;
    public float h;
    public float i;
    public float j;
    public float k;
    public float l;
    public float m;
    public float n;
    public int o;
    public int p;
    public float[] q;
    private boolean r;

    public d(int i, String str, float f, float f2, float f3, float f4) {
        this(str);
        this.i = f3;
        this.j = f4;
        this.m = f;
        this.n = f2;
        this.g = f / f3;
        this.h = f2 / f4;
    }

    public d(String str) {
        this.a = -1;
        this.d = false;
        this.r = false;
        this.e = 0.0f;
        this.f = 0.0f;
        this.g = 1.0f;
        this.h = 1.0f;
        this.i = 0.0f;
        this.j = 0.0f;
        this.k = 0.0f;
        this.l = 0.0f;
        this.m = 0.0f;
        this.n = 0.0f;
        this.o = 1;
        this.p = 1;
        this.q = null;
        String[] split = str.split("[.]")[0].split("[/]");
        this.b = split[split.length - 1];
        this.c = str;
    }

    public d(String str, float f, float f2, float f3, float f4) {
        this.a = -1;
        this.d = false;
        this.r = false;
        this.e = 0.0f;
        this.f = 0.0f;
        this.g = 1.0f;
        this.h = 1.0f;
        this.i = 0.0f;
        this.j = 0.0f;
        this.k = 0.0f;
        this.l = 0.0f;
        this.m = 0.0f;
        this.n = 0.0f;
        this.o = 1;
        this.p = 1;
        this.q = null;
        String[] split = str.split("[/]");
        this.b = split[split.length - 1];
        this.c = String.valueOf(str) + ".png";
        this.i = f3;
        this.j = f4;
        this.m = f;
        this.n = f2;
        this.g = f / f3;
        this.h = f2 / f4;
    }

    public d(String str, float f, float f2, float f3, float f4, int i, int i2) {
        this(str, f, f2, f3, f4);
        this.o = i;
        this.p = i2;
        this.q = g.a(this);
    }

    public d(String str, String str2) {
        this.a = -1;
        this.d = false;
        this.r = false;
        this.e = 0.0f;
        this.f = 0.0f;
        this.g = 1.0f;
        this.h = 1.0f;
        this.i = 0.0f;
        this.j = 0.0f;
        this.k = 0.0f;
        this.l = 0.0f;
        this.m = 0.0f;
        this.n = 0.0f;
        this.o = 1;
        this.p = 1;
        this.q = null;
        String[] split = str2.split("[.]")[0].split("[/]");
        this.b = split[split.length - 1];
        this.c = str2;
    }

    public d(String str, String str2, float f, float f2, float f3, float f4) {
        this.a = -1;
        this.d = false;
        this.r = false;
        this.e = 0.0f;
        this.f = 0.0f;
        this.g = 1.0f;
        this.h = 1.0f;
        this.i = 0.0f;
        this.j = 0.0f;
        this.k = 0.0f;
        this.l = 0.0f;
        this.m = 0.0f;
        this.n = 0.0f;
        this.o = 1;
        this.p = 1;
        this.q = null;
        this.b = str;
        this.c = str2;
        this.i = f3;
        this.j = f4;
        this.m = f;
        this.n = f2;
        this.g = f / f3;
        this.h = f2 / f4;
    }

    public float a() {
        return this.m / this.p;
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public d a(String str) {
        if (this.b.equals(str)) {
            return this;
        }
        return null;
    }

    public void a(boolean z) {
        this.r = z;
    }

    public float b() {
        return this.n / this.o;
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public void d() {
        if (this.r) {
            return;
        }
        com.droidhen.game.racingengine.a.e.a(this);
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public void e() {
        if (this.r) {
            com.droidhen.game.racingengine.a.e.b(this);
        }
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public boolean f() {
        return this.r;
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public void g() {
        this.r = false;
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public String h() {
        return this.b;
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public int i() {
        return 0;
    }
}
