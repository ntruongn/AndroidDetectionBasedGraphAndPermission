package com.droidhen.game.racingmototerLHL.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e {
    public com.droidhen.game.racingengine.c.f a;
    public com.droidhen.game.racingengine.g.c b = new com.droidhen.game.racingengine.g.c(0.0f, -60.0f, 0.0f);
    public com.droidhen.game.racingengine.g.c c = new com.droidhen.game.racingengine.g.c();
    private float e = 15.0f;
    private float f = 0.1f;
    private float g = 0.0f;
    private float h = 1.1f;
    private float i = 0.28f;
    private float j = 9.8f;
    private float k = 0.6f;
    private float l = 0.44f;
    private float m = 400.0f;
    private float n = 100.0f;
    public boolean d = false;

    public e(com.droidhen.game.racingengine.c.f fVar) {
        this.a = fVar;
        fVar.k.c = 0.0f;
        fVar.k.b = 0.0f;
    }

    public void a() {
        com.droidhen.game.racingengine.b.b.b g = com.droidhen.game.racingengine.a.b.g();
        if (this.b.c < 0.0f && (this.a.k.c < 6.0d || ((com.droidhen.game.racingengine.c.d) this.a.a().a.get(0)).a() == 19)) {
            this.c.c = 0.0f;
            this.a.c = false;
            this.b.c = 0.0f;
            this.b.a /= 2.0f;
            this.b.b /= 2.0f;
            return;
        }
        if (!this.a.c) {
            this.b.a(-0.5f, this.c);
        }
        com.droidhen.game.racingengine.g.c d = com.droidhen.game.racingengine.g.c.d();
        com.droidhen.game.racingengine.g.c d2 = com.droidhen.game.racingengine.g.c.d();
        this.b.d(this.c.a(g.b(), d).a(3.6f, d2));
        com.droidhen.game.racingengine.g.c.f(d2);
        com.droidhen.game.racingengine.g.c.f(d);
        com.droidhen.game.racingengine.g.c d3 = com.droidhen.game.racingengine.g.c.d();
        com.droidhen.game.racingengine.g.c d4 = com.droidhen.game.racingengine.g.c.d();
        com.droidhen.game.racingengine.g.c d5 = com.droidhen.game.racingengine.g.c.d();
        this.a.k.d(this.b.a(g.c(), d4).a(1000.0f, d3).a(this.n, d5));
        com.droidhen.game.racingengine.g.c.f(d5);
        com.droidhen.game.racingengine.g.c.f(d4);
        com.droidhen.game.racingengine.g.c.f(d3);
    }

    public void b() {
        this.a.a().b(true);
        this.a.a().a(0.6f);
        this.a.a(com.droidhen.game.racingengine.a.b.f().a());
        this.a.c = true;
    }

    public void c() {
        this.d = true;
        this.b.c = 13.0f;
        this.b.b = (this.b.b / 50.0f) - 23.0f;
        this.c.c = -this.j;
        b();
    }

    public void d() {
        this.d = false;
        this.a.c = false;
        this.a.c();
    }
}
