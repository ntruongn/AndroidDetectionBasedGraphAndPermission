package com.droidhen.game.racingengine.b;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f {
    public long a;
    public String b;
    protected e i;
    protected com.droidhen.game.racingengine.b.c.a j;
    protected d k;
    public com.droidhen.game.racingengine.g.c[] m;
    public int[] n;
    private com.droidhen.game.racingengine.d.a v = com.droidhen.game.racingengine.d.a.TRIANGLES;
    public boolean c = false;
    public boolean d = true;
    public boolean e = true;
    public boolean f = false;
    protected boolean g = true;
    public boolean h = true;
    private com.droidhen.game.racingengine.d.e w = new com.droidhen.game.racingengine.d.e();
    private com.droidhen.game.racingengine.d.d x = com.droidhen.game.racingengine.d.d.SMOOTH;
    private float y = 3.0f;
    private boolean z = true;
    private float A = 1.0f;
    private boolean B = false;
    public ArrayList l = new ArrayList();
    public ArrayList o = null;
    public com.droidhen.game.racingengine.g.c p = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c q = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c r = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c s = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c t = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.e u = new com.droidhen.game.racingengine.g.e();

    public f(e eVar, com.droidhen.game.racingengine.b.c.a aVar, d dVar) {
        this.i = eVar;
        this.j = aVar;
        this.k = dVar;
    }

    public e a() {
        return this.i;
    }

    public com.droidhen.game.racingengine.b.c.a b() {
        return this.j;
    }

    public d c() {
        return this.k;
    }

    public com.droidhen.game.racingengine.d.a d() {
        return this.v;
    }

    public float e() {
        return this.y;
    }

    public boolean f() {
        return this.z;
    }

    public float g() {
        return this.A;
    }

    public boolean h() {
        return this.B;
    }

    public boolean i() {
        return this.i.b();
    }

    public boolean j() {
        return this.i.c();
    }

    public boolean k() {
        return this.i.d();
    }

    public void l() {
        this.o = new ArrayList();
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.m.length; i++) {
            arrayList.clear();
            for (int i2 = 0; i2 < this.n.length; i2++) {
                if (this.n[i2] == i) {
                    arrayList.add(Integer.valueOf(i2));
                }
            }
            int[] iArr = new int[arrayList.size()];
            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                iArr[i3] = ((Integer) arrayList.get(i3)).intValue();
            }
            this.o.add(iArr);
        }
    }
}
