package com.droidhen.game.racingmototerLHL.a.a;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b extends com.droidhen.game.racingengine.a.a.a {
    private int U;
    float[] d;
    final /* synthetic */ x e;
    private int[] v;
    private float w;
    private int x;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public b(com.droidhen.game.racingmototerLHL.a.a.x r7) {
        /*
            r6 = this;
            r6.e = r7
            com.droidhen.game.racingengine.b.c.c r0 = com.droidhen.game.racingengine.a.e
            java.lang.String r1 = "kedu"
            com.droidhen.game.racingengine.b.c.d r1 = r0.a(r1)
            r2 = 1110966272(0x42380000, float:46.0)
            r3 = 1115160576(0x42780000, float:62.0)
            r4 = 1089470464(0x40f00000, float:7.5)
            int r5 = com.droidhen.game.racingmototerLHL.a.a.x.c(r7)
            r0 = r6
            r0.<init>(r1, r2, r3, r4, r5)
            r0 = 25
            int[] r0 = new int[r0]
            r0 = {x0042: FILL_ARRAY_DATA , data: [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3} // fill-array
            r6.v = r0
            r0 = 1120403456(0x42c80000, float:100.0)
            r6.w = r0
            r0 = 2
            float[] r0 = new float[r0]
            r6.d = r0
            com.droidhen.game.racingengine.g.c r0 = r6.G
            r1 = -1042284544(0xffffffffc1e00000, float:-28.0)
            r0.b = r1
            float r0 = r6.w
            float r1 = com.droidhen.game.racingmototerLHL.a.a.x.a(r7)
            float r0 = r0 / r1
            int r1 = com.droidhen.game.racingmototerLHL.a.a.x.c(r7)
            float r1 = (float) r1
            float r0 = r0 * r1
            int r0 = (int) r0
            r6.U = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.droidhen.game.racingmototerLHL.a.a.b.<init>(com.droidhen.game.racingmototerLHL.a.a.x):void");
    }

    private void a(int i, int i2) {
        this.M.position(i * 8);
        for (int i3 = i; i3 < i2; i3++) {
            this.d[0] = this.l.q[(this.v[i3] * 8) + 6];
            this.d[1] = this.l.q[(this.v[i3] * 8) + 7];
            this.M.put(this.d);
            this.M.put(this.l.q, this.v[i3] * 8, 6);
        }
        this.M.position(0);
        this.D = i2 * 6;
    }

    public void a(float f) {
        float f2;
        int i;
        int i2;
        int[] iArr;
        int i3;
        int i4;
        int i5;
        f2 = this.e.f;
        i = this.e.i;
        this.x = (int) ((f / f2) * i);
        int i6 = this.x;
        i2 = this.e.i;
        if (i6 > i2) {
            i5 = this.e.i;
            this.x = i5;
        }
        iArr = this.e.j;
        a(iArr, 0, this.x);
        int i7 = this.x;
        i3 = this.e.i;
        if (i7 != i3) {
            int i8 = this.x + 1;
            i4 = this.e.i;
            a(i8, i4);
        }
    }
}
