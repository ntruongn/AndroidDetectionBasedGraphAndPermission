package com.droidhen.game.racingengine.d;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e {
    public short a = 255;
    public short b = 255;
    public short c = 255;
    public short d = 255;

    public String toString() {
        return "r:" + ((int) this.a) + ", g:" + ((int) this.b) + ", b:" + ((int) this.c) + ", a:" + ((int) this.d);
    }
}
