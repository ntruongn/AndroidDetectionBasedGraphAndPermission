package com.droidhen.api.scoreclient.ui;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public interface b {
    int a(double d, Integer num);

    int a(double d, Integer num, int i);

    int a(int i, String str, String str2, String str3, String str4, int i2);

    int a(String str, String str2, String str3, String str4);

    String a();

    void a(int i);

    void a(int i, String str);

    void a(String str);

    void a(String[] strArr);

    Integer b(int i);

    void b(int i, String str);

    boolean b();

    void c(int i);
}
