package com.droidhen.game.racingmototerLHL.global;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f {
    public static int a;
    public static float b;
    public static float c;
    public static float d;
    public static boolean e = true;
    public static boolean f = false;
    private static com.droidhen.game.racingmototerLHL.a.a g;
    private static com.droidhen.game.racingmototerLHL.f h;

    public static com.droidhen.game.racingmototerLHL.a.a a() {
        return g;
    }

    public static void a(com.droidhen.game.racingmototerLHL.a.a aVar) {
        g = aVar;
    }

    public static void a(com.droidhen.game.racingmototerLHL.f fVar) {
        h = fVar;
    }

    public static com.droidhen.game.racingmototerLHL.f b() {
        return h;
    }
}
