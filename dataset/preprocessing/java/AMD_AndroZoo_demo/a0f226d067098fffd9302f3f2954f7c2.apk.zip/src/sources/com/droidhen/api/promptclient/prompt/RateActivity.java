package com.droidhen.api.promptclient.prompt;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class RateActivity extends Activity implements View.OnClickListener {
    private String a;
    private String b;

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case 2131230737:
                com.droidhen.api.promptclient.a.b.a(this);
                g.a(getApplicationContext(), true);
                finish();
                return;
            case 2131230738:
                com.droidhen.api.promptclient.a.g.a(this, this.a, this.b);
                g.a(getApplicationContext(), true);
                finish();
                return;
            case 2131230739:
                g.a(getApplicationContext(), false);
                finish();
                return;
            default:
                return;
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        setTheme(2131165184);
        super.onCreate(bundle);
        Intent intent = getIntent();
        if (intent != null) {
            this.a = intent.getStringExtra("msg");
            this.b = intent.getStringExtra("file");
        }
        setContentView(2130903042);
        ((ImageButton) findViewById(2131230737)).setOnClickListener(this);
        ((ImageButton) findViewById(2131230738)).setOnClickListener(this);
        ((ImageButton) findViewById(2131230739)).setOnClickListener(this);
    }
}
