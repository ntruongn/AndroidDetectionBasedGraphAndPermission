package com.droidhen.api.scoreclient.ui;

import android.app.Activity;
import android.content.Intent;
import android.widget.EditText;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c {
    public static com.droidhen.api.scoreclient.c a;
    private static g b;
    private static int c;
    private static double d;

    public static com.droidhen.api.scoreclient.widget.e a(Activity activity) {
        return a(activity, null);
    }

    public static com.droidhen.api.scoreclient.widget.e a(Activity activity, com.droidhen.api.scoreclient.widget.a aVar) {
        com.droidhen.api.scoreclient.widget.e eVar = new com.droidhen.api.scoreclient.widget.e(activity, aVar);
        eVar.a(new a((EditText) eVar.findViewById(2131230736), activity));
        return eVar;
    }

    public static void a(Activity activity, com.droidhen.api.scoreclient.c cVar, int i, double d2, g gVar) {
        a = cVar;
        b = gVar;
        c = i;
        d = d2;
        if (i.a().b()) {
            try {
                activity.showDialog(1111);
                return;
            } catch (Exception e) {
                return;
            }
        }
        if (b != null) {
            b.a(null);
        } else {
            System.err.println("listener is null!!!!");
        }
        Intent intent = new Intent(activity, (Class<?>) HighScoresActivity.class);
        intent.putExtra("mode", i);
        intent.putExtra("submit", true);
        intent.putExtra("score", d2);
        activity.startActivity(intent);
    }

    public static void a(Activity activity, com.droidhen.api.scoreclient.c cVar, int i, boolean z) {
        a = cVar;
        Intent intent = new Intent(activity, (Class<?>) HighScoresActivity.class);
        intent.putExtra("mode", i);
        intent.putExtra("global", true);
        activity.startActivity(intent);
    }
}
