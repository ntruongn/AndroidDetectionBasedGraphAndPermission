package com.droidhen.api.scoreclient.ui;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class o extends ArrayAdapter {
    final /* synthetic */ AchievementListActivity a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(AchievementListActivity achievementListActivity, Context context, int i, List list) {
        super(context, i, list);
        this.a = achievementListActivity;
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        String c;
        String d;
        Integer num;
        Integer num2;
        View inflate = view == null ? this.a.getLayoutInflater().inflate(2130903044, (ViewGroup) null) : view;
        com.droidhen.api.scoreclient.b.a aVar = (com.droidhen.api.scoreclient.b.a) getItem(i);
        TextView textView = (TextView) inflate.findViewById(2131230766);
        TextView textView2 = (TextView) inflate.findViewById(2131230767);
        ImageView imageView = (ImageView) inflate.findViewById(2131230765);
        int a = aVar.a();
        boolean i2 = aVar.i();
        if (a == 1 || !i2) {
            c = aVar.c();
            d = aVar.d();
        } else {
            c = "Locked";
            d = "";
        }
        textView.setText(c);
        textView2.setText(d);
        String e = a == 1 ? aVar.e() : i2 ? aVar.g() : aVar.f();
        if (e != null) {
            try {
                imageView.setImageBitmap(BitmapFactory.decodeStream(this.a.getAssets().open(e)));
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        } else if (a == 1) {
            imageView.setImageResource(2130837516);
        } else if (i2) {
            imageView.setImageResource(2130837517);
        } else {
            imageView.setImageResource(2130837518);
        }
        num = this.a.c;
        if (num != null) {
            num2 = this.a.c;
            imageView.setBackgroundColor(num2.intValue());
        }
        return inflate;
    }
}
