package com.droidhen.api.scoreclient.a;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c {
    private Context a;
    private SharedPreferences e;
    private List b = null;
    private HashMap c = new HashMap();
    private int d = 0;
    private boolean f = false;
    private a g = new a(this);
    private String h = null;

    public c(Context context) {
        this.a = null;
        this.a = context;
        this.e = this.a.getSharedPreferences("achievement_data", 0);
    }

    public int a(int i, String str, String str2, String str3, String str4, int i2) {
        return a(i, str, str2, str3, str4, null, i2, false);
    }

    public int a(int i, String str, String str2, String str3, String str4, String str5, int i2, boolean z) {
        if (str == null || str2 == null) {
            throw new IllegalStateException("achievement's title and description can't be null");
        }
        if (this.b == null) {
            this.b = new ArrayList();
        }
        int i3 = this.e.getInt(String.valueOf(i), 0);
        if (i3 == 1) {
            this.d++;
        }
        com.droidhen.api.scoreclient.b.a aVar = new com.droidhen.api.scoreclient.b.a(Integer.valueOf(i), str, str2, str3, str4, str5, i3, i2, z);
        if (this.c.containsKey(Integer.valueOf(i))) {
            throw new IllegalStateException("Invalid id");
        }
        this.c.put(Integer.valueOf(i), Integer.valueOf(this.b.size()));
        this.b.add(aVar);
        this.f = true;
        return i;
    }

    public int a(String str, String str2, String str3, String str4) {
        if (str == null || str2 == null) {
            throw new IllegalStateException("achievement's title and description can't be null");
        }
        if (this.b == null) {
            this.b = new ArrayList();
        }
        int size = this.b.size();
        int i = this.e.getInt(String.valueOf(size), 0);
        if (i == 1) {
            this.d++;
        }
        com.droidhen.api.scoreclient.b.a aVar = new com.droidhen.api.scoreclient.b.a(Integer.valueOf(size), str, str2, str3, str4, i);
        this.c.put(Integer.valueOf(size), Integer.valueOf(this.b.size()));
        this.b.add(aVar);
        this.f = true;
        return size;
    }

    public List a() {
        if (this.b == null) {
            this.b = new ArrayList();
        }
        if (this.f) {
            Collections.sort(this.b, this.g);
            for (int i = 0; i < this.b.size(); i++) {
                this.c.put(((com.droidhen.api.scoreclient.b.a) this.b.get(i)).h(), Integer.valueOf(i));
            }
            this.f = false;
        }
        return this.b;
    }

    public void a(int i) {
        Integer num = (Integer) this.c.get(Integer.valueOf(i));
        if (num == null) {
            throw new IllegalStateException("Invalid id");
        }
        com.droidhen.api.scoreclient.b.a aVar = (com.droidhen.api.scoreclient.b.a) this.b.get(num.intValue());
        if (aVar.h().intValue() != i) {
            throw new IllegalStateException("Invalid id");
        }
        if (aVar.a() == 1) {
            return;
        }
        aVar.a(1);
        this.d++;
        SharedPreferences.Editor edit = this.e.edit();
        edit.putInt(String.valueOf(i), 1);
        edit.commit();
    }

    public void a(int i, String str) {
        if (str == null) {
            throw new IllegalStateException("achievement's description can't be null");
        }
        Integer num = (Integer) this.c.get(Integer.valueOf(i));
        if (num == null) {
            throw new IllegalStateException("Invalid id");
        }
        com.droidhen.api.scoreclient.b.a aVar = (com.droidhen.api.scoreclient.b.a) this.b.get(num.intValue());
        if (aVar.h().intValue() != i) {
            throw new IllegalStateException("Invalid id");
        }
        aVar.a(str);
    }

    public int b() {
        return this.d;
    }

    public String c() {
        return this.h;
    }
}
