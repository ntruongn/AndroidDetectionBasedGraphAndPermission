package com.droidhen.game.racingengine.a;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e extends com.droidhen.game.racingengine.a.a.e {
    private float d;
    private float e;
    private long f;
    private long g;
    private long[] h;
    private float i;

    public e(com.droidhen.game.racingengine.b.c.d dVar) {
        super(dVar);
        this.d = 0.0f;
        this.e = 0.0f;
        this.h = new long[]{300, 600};
        this.i = 100.0f;
        this.z = false;
    }

    public void a(com.droidhen.game.racingengine.b.c.d dVar) {
        this.C = dVar;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        boolean z;
        if (this.z) {
            c();
            if (this.e != 1.0f) {
                z = true;
                gl10.glColor4f(1.0f, 1.0f, 1.0f, this.e);
            } else {
                z = false;
            }
            gl10.glBindTexture(3553, this.C.a);
            gl10.glPushMatrix();
            gl10.glTranslatef(this.G.a, this.d, this.G.c);
            gl10.glTexCoordPointer(2, 5126, 0, this.M);
            gl10.glVertexPointer(3, 5126, 0, this.N);
            gl10.glDrawElements(4, this.D, 5123, this.O);
            if (z) {
                gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            }
            gl10.glPopMatrix();
        }
    }

    @Override // com.droidhen.game.racingengine.a.a.e, com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        super.c();
        this.g = System.currentTimeMillis() - this.f;
        if (this.g < this.h[0]) {
            this.e = 0.0f + ((1.0f / ((float) this.h[0])) * ((float) this.g));
            this.d = this.G.b + ((this.i / ((float) this.h[1])) * ((float) this.g));
        } else if (this.g >= this.h[0]) {
            this.z = false;
        } else {
            this.e = 1.0f - ((1.0f / ((float) (this.h[1] - this.h[0]))) * ((float) (this.g - this.h[0])));
            this.d = this.G.b + ((this.i / ((float) this.h[1])) * ((float) this.g));
        }
    }

    @Override // com.droidhen.game.racingengine.a.a.e, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        this.f = System.currentTimeMillis();
        this.z = true;
        this.d = this.G.b;
        this.e = 0.0f;
    }

    @Override // com.droidhen.game.racingengine.a.a.e, com.droidhen.game.racingengine.a.l
    public void e() {
        this.z = false;
    }
}
