package com.droidhen.game.racingmototerLHL.b;

import com.droidhen.game.racingmototerLHL.a.a.y;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c {
    protected int a = 0;
    protected long b = 0;
    final /* synthetic */ g c;

    public c(g gVar) {
        this.c = gVar;
    }

    public void a() {
        if (com.droidhen.game.racingengine.a.b.f().a() - this.b < 40000) {
            this.a++;
            this.b = com.droidhen.game.racingengine.a.b.f().a();
            if (this.a >= 5) {
                com.droidhen.game.racingmototerLHL.global.f.a().a(y.Smile);
                this.a = 0;
            }
        }
    }

    public void b() {
        this.a = 0;
        if (com.droidhen.game.racingengine.a.b.f() != null) {
            this.b = com.droidhen.game.racingengine.a.b.f().a();
        } else {
            this.b = System.currentTimeMillis();
        }
    }
}
