package com.droidhen.game.racingengine.b;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d {
    private ShortBuffer a;
    private int b;
    private int c = 0;
    private int d = 1;
    private boolean e = false;

    public d(ShortBuffer shortBuffer, int i) {
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(shortBuffer.limit() * 2);
        allocateDirect.order(ByteOrder.nativeOrder());
        this.a = allocateDirect.asShortBuffer();
        this.a.put(shortBuffer);
        this.b = i;
    }

    public int a() {
        return this.b;
    }

    public ShortBuffer b() {
        return this.a;
    }

    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public d clone() {
        this.a.position(0);
        return new d(this.a, a());
    }
}
