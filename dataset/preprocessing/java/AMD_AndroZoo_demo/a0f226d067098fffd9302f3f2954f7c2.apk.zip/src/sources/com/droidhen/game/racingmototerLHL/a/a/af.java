package com.droidhen.game.racingmototerLHL.a.a;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class af extends com.droidhen.game.racingengine.a.a {
    public static long d;
    public static int e;
    private static com.droidhen.game.racingengine.b.c.d[] l = null;
    private static com.droidhen.game.racingengine.b.c.d[] m = null;
    private static final long[] n = {0, 800, 2000, 5000, 10000, 20000};
    private com.droidhen.game.racingengine.a.a.e i;
    private com.droidhen.game.racingengine.a.a.e j;
    private com.droidhen.game.racingengine.a.a.e k;
    private long o;
    private float p;
    private float q;
    private float s;
    private boolean t;
    private float[] r = new float[8];
    com.droidhen.game.racingengine.b.b.b f = new com.droidhen.game.racingengine.b.b.b();
    int g = 0;
    int h = 0;

    public af() {
        this.E = 140.0f;
        this.F = 70.0f;
        a(480.0f, 40.0f, com.droidhen.game.racingengine.a.h.RIGHTTOP);
        a(com.droidhen.game.racingengine.a.j.FitScreen);
        this.i = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("boost_bg"));
        this.i.a(475.0f, 40.0f, com.droidhen.game.racingengine.a.h.RIGHTTOP);
        this.j = new ah(this, com.droidhen.game.racingengine.a.e.a("L2"));
        this.j.a(475.0f, 40.0f, com.droidhen.game.racingengine.a.h.RIGHTTOP);
        this.k = new ai(this, com.droidhen.game.racingengine.a.e.a("x1"));
        this.k.a(470.0f, 70.0f, com.droidhen.game.racingengine.a.h.RIGHTTOP);
        l = new com.droidhen.game.racingengine.b.c.d[]{com.droidhen.game.racingengine.a.e.a("L2"), com.droidhen.game.racingengine.a.e.a("L3"), com.droidhen.game.racingengine.a.e.a("L4"), com.droidhen.game.racingengine.a.e.a("L5"), com.droidhen.game.racingengine.a.e.a("L5_3")};
        m = new com.droidhen.game.racingengine.b.c.d[]{com.droidhen.game.racingengine.a.e.a("x1"), com.droidhen.game.racingengine.a.e.a("x2"), com.droidhen.game.racingengine.a.e.a("x3"), com.droidhen.game.racingengine.a.e.a("x4"), com.droidhen.game.racingengine.a.e.a("x5")};
    }

    @Override // com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        super.a();
        this.i.a();
        this.k.a();
        this.j.a();
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        c();
        gl10.glPushMatrix();
        this.i.a(gl10);
        this.j.a(gl10);
        this.k.a(gl10);
        gl10.glPopMatrix();
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() != com.droidhen.game.racingmototerLHL.global.e.PLAYING) {
            d = 0L;
            this.o = 0L;
            this.j.C = l[0];
            this.k.C = m[0];
            e = 0;
            this.q = 1.0f;
            this.p = 0.0f;
            this.h = 0;
            return;
        }
        if (com.droidhen.game.racingengine.a.b.g() != null) {
            this.f = com.droidhen.game.racingengine.a.b.g();
        } else {
            this.f.a(10L);
        }
        if (com.droidhen.game.racingmototerLHL.global.f.f) {
            this.o += this.f.a();
            d = 0L;
        } else {
            d += this.f.a();
            this.o = 0L;
            this.j.C = l[0];
            this.k.C = m[0];
            e = 0;
            this.q = 1.0f;
            this.p = 0.0f;
            this.h = 0;
        }
        if (this.o <= 0) {
            this.p = 0.0f;
            this.q = 1.0f;
            return;
        }
        int length = n.length - 1;
        while (true) {
            if (length <= -1) {
                break;
            }
            if (this.o > n[length]) {
                e = length;
                break;
            }
            length--;
        }
        if (e < 5) {
            this.s = (float) (this.o - n[e]);
            this.g = e;
        } else {
            this.s = (float) (this.o - n[4]);
            this.g = 4;
        }
        if (this.g >= n.length - 2) {
            this.p = 1.0f;
            if (((int) (this.s / 200.0f)) > this.h) {
                this.t = !this.t;
                if (this.t) {
                    this.j.C = l[4];
                } else {
                    this.j.C = l[3];
                }
                this.h = (int) (this.s / 200.0f);
            }
        } else {
            this.j.C = l[this.g];
            this.p = this.s / ((float) (n[this.g + 1] - n[this.g]));
        }
        this.k.C = m[this.g];
        if (this.g == 0 || this.s >= 220.0f) {
            this.q = 1.0f;
        } else if (this.s < 150.0f) {
            this.q = (0.5f * (((float) (this.o - n[this.g])) / 150.0f)) + 1.0f;
        } else {
            this.q = 1.5f - (0.5f * ((this.s - 150.0f) / 70.0f));
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void e() {
    }
}
