package com.droidhen.game.racingengine.a.a;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c extends d {
    protected com.droidhen.game.racingengine.b.c.d k;
    public int d = 0;
    public int e = 0;
    protected float f = 0.0f;
    protected float g = 0.0f;
    public float h = 0.0f;
    protected float i = 0.0f;
    protected float j = 0.0f;
    protected b l = h.b;

    protected c() {
    }

    public c(com.droidhen.game.racingengine.b.c.d dVar, float f, int i) {
        a(dVar, dVar.a(), dVar.b(), f, i);
    }

    public float a(int i) {
        return ((this.f + this.h) * i) - this.h;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a(com.droidhen.game.racingengine.b.c.d dVar, float f, float f2, float f3, int i) {
        this.d = i;
        this.h = f3;
        this.k = dVar;
        this.C = dVar;
        b(i);
        this.E = f;
        this.F = f2;
        this.f = f;
        this.g = f2;
        g(this.F, 0.0f);
        short[] sArr = new short[6];
        this.N.position(0);
        float f4 = 0.0f;
        short s = 0;
        for (int i2 = 0; i2 < i; i2++) {
            float f5 = f4 + f;
            h(f4, f5);
            f4 = f5 + f3;
            this.N.put(this.q);
            for (int i3 = 0; i3 < 6; i3++) {
                sArr[i3] = (short) (o[i3] + s);
            }
            this.O.put(sArr);
            s = (short) (s + 4);
        }
        this.O.position(0);
        this.N.position(0);
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        boolean z;
        f(this.i, this.j);
        if (this.B != 1.0f) {
            z = true;
            gl10.glColor4f(1.0f, 1.0f, 1.0f, this.B);
        } else {
            z = false;
        }
        gl10.glBindTexture(3553, this.C.a);
        gl10.glPushMatrix();
        gl10.glTranslatef(this.G.a, this.G.b, 0.0f);
        gl10.glTranslatef(-this.f0I, -this.J, 0.0f);
        gl10.glTexCoordPointer(2, 5126, 0, this.M);
        gl10.glVertexPointer(3, 5126, 0, this.N);
        gl10.glDrawElements(4, this.D, 5123, this.O);
        gl10.glPopMatrix();
        if (z) {
            gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        }
    }

    public void a(int[] iArr, int i, int i2) {
        this.l.a(iArr, i, i2);
        this.M.position(0);
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            this.M.put(this.k.q, iArr[i4] * 8, 8);
        }
        this.M.position(0);
        this.E = a(i2);
        this.D = i2 * 6;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean b(float f, float f2) {
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void e() {
    }

    public void e(float f, float f2) {
        this.i = f;
        this.j = f2;
    }

    @Override // com.droidhen.game.racingengine.a.a.d
    public void f(float f, float f2) {
        if (f > 0.0f) {
            this.f0I = this.E * f;
        } else {
            this.f0I = 0.0f;
        }
        this.J = this.F * f2;
        this.u = true;
    }
}
