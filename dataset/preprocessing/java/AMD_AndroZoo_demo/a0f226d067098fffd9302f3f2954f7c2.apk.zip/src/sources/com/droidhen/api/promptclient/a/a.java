package com.droidhen.api.promptclient.a;

import android.content.Context;
import android.os.Environment;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    private static boolean a;

    public static String a(Context context, String str) {
        try {
            File file = new File(Environment.getExternalStorageDirectory(), "droidhen/" + context.getPackageName() + ".jpg");
            if (a && file.exists()) {
                return file.getAbsolutePath();
            }
            a = true;
            InputStream open = context.getResources().getAssets().open(str);
            if (file.exists()) {
                int available = open.available();
                FileInputStream fileInputStream = new FileInputStream(file);
                int available2 = fileInputStream.available();
                a(fileInputStream);
                if (available == available2) {
                    a(open);
                    return file.getAbsolutePath();
                }
                file.delete();
            } else {
                File parentFile = file.getParentFile();
                if (parentFile != null) {
                    parentFile.mkdirs();
                }
                file.createNewFile();
                byte[] bArr = new byte[4096];
                BufferedInputStream bufferedInputStream = new BufferedInputStream(open, 8192);
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(file), 8192);
                while (true) {
                    int read = bufferedInputStream.read(bArr);
                    if (read == -1) {
                        break;
                    }
                    bufferedOutputStream.write(bArr, 0, read);
                }
                bufferedOutputStream.flush();
                a(bufferedInputStream);
                a(bufferedOutputStream);
            }
            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void a(Closeable closeable) {
        try {
            closeable.close();
        } catch (IOException e) {
        }
    }
}
