package com.droidhen.game.racingengine.c;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    private e a;
    private long b;
    private long c;
    private long d;

    public b(long j, long j2) {
        this.b = j;
        this.c = j2;
        this.d = j2 - j;
    }

    public long a() {
        return this.b;
    }

    public void a(e eVar) {
        this.a = eVar;
    }

    public long b() {
        return this.c;
    }

    public long c() {
        return this.d;
    }
}
