package com.droidhen.api.scoreclient.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    private Integer a;
    private String b;
    private String c;
    private String d;
    private String e;
    private String f;
    private int g;
    private int h;
    private boolean i;

    public a(Integer num, String str, String str2, String str3, String str4, int i) {
        this(num, str, str2, str3, str4, null, i, num.intValue(), false);
    }

    public a(Integer num, String str, String str2, String str3, String str4, String str5, int i, int i2, boolean z) {
        this.a = num;
        this.b = str;
        this.c = str2;
        this.d = str3;
        this.e = str4;
        this.f = str5;
        this.g = i;
        this.h = i2;
        this.i = z;
    }

    public int a() {
        return this.g;
    }

    public void a(int i) {
        this.g = i;
    }

    public void a(String str) {
        this.c = str;
    }

    public int b() {
        return this.h;
    }

    public String c() {
        return this.b;
    }

    public String d() {
        return this.c;
    }

    public String e() {
        return this.d;
    }

    public String f() {
        return this.e;
    }

    public String g() {
        return this.f;
    }

    public Integer h() {
        return this.a;
    }

    public boolean i() {
        return this.i;
    }
}
