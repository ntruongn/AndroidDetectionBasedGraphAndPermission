package com.droidhen.game.racingengine.b.c;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b implements e {
    public static String a = "general";
    private boolean b;
    private String c;
    private String d;
    private ArrayList e;
    private ArrayList f;

    public b() {
        this.b = false;
        this.e = null;
        this.f = null;
        this.d = a;
        this.e = new ArrayList();
    }

    public b(String str, String str2) {
        this.b = false;
        this.e = null;
        this.f = null;
        this.c = str;
        this.d = str2;
        this.e = new ArrayList();
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public d a(String str) {
        for (int i = 0; i < this.e.size(); i++) {
            d a2 = ((d) this.e.get(i)).a(str);
            if (a2 != null) {
                return a2;
            }
        }
        if (this.f != null) {
            for (int i2 = 0; i2 < this.f.size(); i2++) {
                d a3 = ((b) this.f.get(i2)).a(str);
                if (a3 != null) {
                    return a3;
                }
            }
        }
        return null;
    }

    public void a() {
        com.droidhen.game.racingengine.a.e.b(this);
    }

    public void a(String str, boolean z) {
        try {
            for (String str2 : com.droidhen.game.racingengine.a.d.list(str)) {
                if (str2.contains(".")) {
                    d dVar = new d(str, String.valueOf(str) + "/" + str2);
                    dVar.d = z;
                    this.e.add(dVar);
                } else {
                    a(String.valueOf(str) + "/" + str2, z);
                }
            }
        } catch (IOException e) {
            throw new Error("No directory: " + str);
        }
    }

    public void a(boolean z) {
        a(this.c, z);
    }

    public void a(d[] dVarArr) {
        this.e.addAll(Arrays.asList(dVarArr));
    }

    public void b() {
        com.droidhen.game.racingengine.a.e.c(this);
    }

    public void c() {
        com.droidhen.game.racingengine.a.e.a(this);
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public void d() {
        if (this.b) {
            return;
        }
        for (int i = 0; i < this.e.size(); i++) {
            ((d) this.e.get(i)).d();
        }
        if (this.f != null) {
            for (int i2 = 0; i2 < this.e.size(); i2++) {
                ((b) this.f.get(i2)).d();
            }
        }
        this.b = true;
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public void e() {
        if (this.b) {
            for (int i = 0; i < this.e.size(); i++) {
                ((d) this.e.get(i)).e();
            }
            if (this.f != null) {
                for (int i2 = 0; i2 < this.e.size(); i2++) {
                    ((b) this.f.get(i2)).e();
                }
            }
            this.b = false;
        }
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public boolean f() {
        return this.b;
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public void g() {
        for (int i = 0; i < this.e.size(); i++) {
            ((d) this.e.get(i)).g();
        }
        if (this.f != null) {
            for (int i2 = 0; i2 < this.f.size(); i2++) {
                ((b) this.f.get(i2)).g();
            }
        }
        this.b = false;
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public String h() {
        return this.d;
    }

    @Override // com.droidhen.game.racingengine.b.c.e
    public int i() {
        return 1;
    }
}
