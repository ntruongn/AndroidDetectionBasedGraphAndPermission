package com.droidhen.game.racingmototerLHL.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class aq extends com.droidhen.game.racingengine.a.f {
    private com.droidhen.game.racingengine.a.a.e d;
    private com.droidhen.game.racingengine.a.d e;
    private com.droidhen.game.racingengine.a.d j;
    private com.droidhen.game.racingengine.a.d k;

    public aq() {
        super(0.5f, 0.5f, 480.0f, 800.0f, -1);
        this.B = 0.0f;
        this.d = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("pause_bg"));
        this.d.a(240.0f, 115.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        this.d.a(com.droidhen.game.racingengine.a.j.KeepRatioAll);
        a(this.d);
        this.e = new com.droidhen.game.racingengine.a.d(378.0f, 383.0f, com.droidhen.game.racingengine.a.h.CENTERBOTTOM, com.droidhen.game.racingengine.a.e.a("resume_a"), com.droidhen.game.racingengine.a.e.a("resume_b"));
        this.e.a(new g(this));
        this.j = new com.droidhen.game.racingengine.a.d(240.0f, 383.0f, com.droidhen.game.racingengine.a.h.CENTERBOTTOM, com.droidhen.game.racingengine.a.e.a("retry_a"), com.droidhen.game.racingengine.a.e.a("retry_b"));
        this.j.a(new h(this));
        this.k = new com.droidhen.game.racingengine.a.d(102.0f, 383.0f, com.droidhen.game.racingengine.a.h.CENTERBOTTOM, com.droidhen.game.racingengine.a.e.a("menu_a"), com.droidhen.game.racingengine.a.e.a("menu_b"));
        this.k.a(new f(this));
        a(this.k);
        a(this.e);
        a(this.j);
        a(com.droidhen.game.racingmototerLHL.global.f.a().e);
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        super.c();
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l
    public void e() {
        this.i = true;
        this.z = false;
    }
}
