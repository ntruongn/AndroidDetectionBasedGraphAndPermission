package com.droidhen.api.promptclient.a;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public enum f {
    Empty(2131034126),
    Score(2131034127),
    ScoreMode(2131034128),
    Level(2131034130),
    LevelMode(2131034130);

    private int f;

    f(int i) {
        this.f = i;
    }

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static f[] valuesCustom() {
        f[] valuesCustom = values();
        int length = valuesCustom.length;
        f[] fVarArr = new f[length];
        System.arraycopy(valuesCustom, 0, fVarArr, 0, length);
        return fVarArr;
    }

    public String a(Context context, String str, String str2) {
        CharSequence charSequence;
        PackageManager packageManager = context.getPackageManager();
        try {
            charSequence = packageManager.getApplicationLabel(packageManager.getApplicationInfo(context.getPackageName(), 128));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            charSequence = "";
        }
        return context.getString(this.f, "#" + ((Object) charSequence) + "#", Build.MODEL, String.valueOf(com.droidhen.api.promptclient.a.c.c()) + context.getPackageName(), str, str2);
    }
}
