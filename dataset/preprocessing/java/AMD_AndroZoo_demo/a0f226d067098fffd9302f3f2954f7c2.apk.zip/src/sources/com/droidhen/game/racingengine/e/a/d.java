package com.droidhen.game.racingengine.e.a;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d {
    public String b;
    public ArrayList a = new ArrayList();
    public com.droidhen.game.racingengine.g.c c = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c d = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c e = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c f = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c g = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.e h = new com.droidhen.game.racingengine.g.e();

    public d(String str) {
        this.b = str;
    }
}
