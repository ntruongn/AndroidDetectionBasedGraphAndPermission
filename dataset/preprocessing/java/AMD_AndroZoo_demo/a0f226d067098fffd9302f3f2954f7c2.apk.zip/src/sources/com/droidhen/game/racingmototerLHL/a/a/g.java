package com.droidhen.game.racingmototerLHL.a.a;

import com.droidhen.game.racingmototerLHL.GameActivity;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class g implements com.droidhen.game.racingengine.a.g {
    final /* synthetic */ aq a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(aq aqVar) {
        this.a = aqVar;
    }

    @Override // com.droidhen.game.racingengine.a.g
    public void a(com.droidhen.game.racingengine.a.d dVar) {
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.a);
        com.droidhen.game.racingmototerLHL.global.f.b().d();
        com.droidhen.game.racingmototerLHL.global.f.a().a("game_panel");
    }
}
