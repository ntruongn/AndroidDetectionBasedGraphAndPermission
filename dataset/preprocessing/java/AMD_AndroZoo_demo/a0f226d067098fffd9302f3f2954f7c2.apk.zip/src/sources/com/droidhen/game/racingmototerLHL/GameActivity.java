package com.droidhen.game.racingmototerLHL;

import android.app.AlertDialog;
import android.app.Dialog;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Window;
import android.widget.RelativeLayout;
import com.droidhen.api.promptclient.prompt.h;
import com.droidhen.api.scoreclient.widget.UsernameEdit;
import com.droidhen.game.racingengine.BaseActivity;
import com.droidhen.game.racingmototerLHL.a.a.ae;
import com.droidhen.game.racingmototerLHL.a.a.ag;
import com.google.ads.AdView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class GameActivity extends BaseActivity implements com.droidhen.api.scoreclient.ui.g {
    public static boolean e = false;
    private static com.droidhen.game.racingengine.h.b g;
    private static /* synthetic */ int[] l;
    Handler d = new b(this);
    private com.droidhen.api.promptclient.prompt.a f;
    private UsernameEdit h;
    private AdView i;
    private com.droidhen.game.racingmototerLHL.a.a j;
    private GLSurfaceView k;

    public static void a(com.droidhen.game.racingengine.h.e eVar) {
        if (g == null || !com.droidhen.game.racingmototerLHL.global.f.e) {
            return;
        }
        if (eVar.b()) {
            g.a(eVar);
        } else {
            g.a();
            g.a(eVar);
        }
    }

    public static void b() {
        g.a();
    }

    static /* synthetic */ int[] d() {
        int[] iArr = l;
        if (iArr == null) {
            iArr = new int[com.droidhen.game.racingmototerLHL.global.e.valuesCustom().length];
            try {
                iArr[com.droidhen.game.racingmototerLHL.global.e.CRASH.ordinal()] = 5;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[com.droidhen.game.racingmototerLHL.global.e.GAME_MENU.ordinal()] = 8;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[com.droidhen.game.racingmototerLHL.global.e.GAME_OVER.ordinal()] = 7;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[com.droidhen.game.racingmototerLHL.global.e.LOADING_MODEL.ordinal()] = 2;
            } catch (NoSuchFieldError e5) {
            }
            try {
                iArr[com.droidhen.game.racingmototerLHL.global.e.LOADING_TEXTURE.ordinal()] = 1;
            } catch (NoSuchFieldError e6) {
            }
            try {
                iArr[com.droidhen.game.racingmototerLHL.global.e.PAUSE.ordinal()] = 3;
            } catch (NoSuchFieldError e7) {
            }
            try {
                iArr[com.droidhen.game.racingmototerLHL.global.e.PLAYING.ordinal()] = 6;
            } catch (NoSuchFieldError e8) {
            }
            try {
                iArr[com.droidhen.game.racingmototerLHL.global.e.SELECT_MOTO.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
            try {
                iArr[com.droidhen.game.racingmototerLHL.global.e.STOP.ordinal()] = 4;
            } catch (NoSuchFieldError e10) {
            }
            l = iArr;
        }
        return iArr;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e() {
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        layoutParams.height = (int) ((com.droidhen.game.racingengine.a.c.b() * 50.0f) / 800.0f);
        layoutParams.width = (int) ((com.droidhen.game.racingengine.a.c.a() * 400.0f) / 480.0f);
        layoutParams.setMargins((int) ((com.droidhen.game.racingengine.a.c.b() * 30.0f) / 480.0f), (int) ((com.droidhen.game.racingengine.a.c.b() * 185.0f) / 800.0f), 0, 0);
        this.h.setTextSize(layoutParams.height / 2.0f);
        this.h.setLayoutParams(layoutParams);
    }

    private Dialog f() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(this.f.d).setIcon(2130837534).setTitle(2131034113).setPositiveButton("Free Update", new c(this));
        return builder.create();
    }

    @Override // com.droidhen.api.scoreclient.ui.g
    public void a(String str) {
        if (str == null || this.h.a(str)) {
            ag.f();
        }
    }

    public UsernameEdit c() {
        return this.h;
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        Window window = getWindow();
        window.setFlags(1024, 1024);
        window.setFlags(128, 128);
        setContentView(2130903047);
        toStart();
        this.h = (UsernameEdit) findViewById(2131230736);
        this.h.a(true);
        this.h.setVisibility(4);
        this.i = (AdView) findViewById(2131230727);
        this.j = new com.droidhen.game.racingmototerLHL.a.a(this);
        com.droidhen.game.racingmototerLHL.global.f.a(this.j);
        g = com.droidhen.game.racingengine.h.c.a(this, com.droidhen.game.racingmototerLHL.global.b.i);
        setVolumeControlStream(3);
        if (h.a(this)) {
            this.f = com.droidhen.api.promptclient.prompt.f.b(this);
            com.droidhen.api.promptclient.prompt.f.a(this);
            showDialog(9527);
        }
        f fVar = new f(this, this.d);
        com.droidhen.game.racingmototerLHL.global.f.a(fVar);
        this.k = (GLSurfaceView) findViewById(2131230776);
        a(fVar, this.k, this.d);
        this.c = this.d;
        this.j.a(com.droidhen.game.racingengine.a.e);
        fVar.C();
    }

    @Override // android.app.Activity
    protected Dialog onCreateDialog(int i) {
        switch (i) {
            case 1111:
                return com.droidhen.api.scoreclient.ui.c.a(this);
            case 9527:
                return f();
            default:
                return super.onCreateDialog(i);
        }
    }

    @Override // com.droidhen.game.racingengine.BaseActivity, android.app.Activity, android.view.KeyEvent.Callback
    public synchronized boolean onKeyDown(int i, KeyEvent keyEvent) {
        boolean onKeyDown;
        if (i != 4) {
            onKeyDown = i == 84 ? true : super.onKeyDown(i, keyEvent);
        } else if (ae.e) {
            onKeyDown = true;
        } else {
            switch (d()[com.droidhen.game.racingmototerLHL.global.f.b().u().ordinal()]) {
                case 3:
                    com.droidhen.game.racingmototerLHL.global.f.b().d();
                    this.j.a("game_panel");
                    break;
                case 4:
                default:
                    finish();
                    break;
                case 5:
                    break;
                case 6:
                    com.droidhen.game.racingmototerLHL.global.f.b().c();
                    this.j.a("game_pause_panel");
                    break;
                case 7:
                    com.droidhen.game.racingmototerLHL.global.f.b().r();
                    break;
                case 8:
                    finish();
                    break;
                case 9:
                    com.droidhen.game.racingmototerLHL.global.f.b().r();
                    break;
            }
            onKeyDown = true;
        }
        return onKeyDown;
    }

    @Override // com.droidhen.game.racingengine.BaseActivity, android.app.Activity
    public void onPause() {
        super.onPause();
        this.k.onPause();
        ((f) this.b).w();
        g.a();
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.PLAYING) {
            com.droidhen.game.racingmototerLHL.global.f.b().c();
        }
        this.j.e();
    }

    @Override // com.droidhen.game.racingengine.BaseActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        this.k.onResume();
        ((f) this.b).v();
        this.j.f();
    }

    @Override // com.droidhen.game.racingengine.BaseActivity, android.app.Activity
    public synchronized boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.CRASH || com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.LOADING_MODEL || com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.LOADING_TEXTURE) {
            z = true;
        } else {
            if (motionEvent.getAction() == 0) {
                if (!com.droidhen.game.racingmototerLHL.global.f.a().a(motionEvent.getX(), motionEvent.getY()) && com.droidhen.game.racingmototerLHL.global.f.b().u() != com.droidhen.game.racingmototerLHL.global.e.PAUSE) {
                    com.droidhen.game.racingmototerLHL.global.f.f = true;
                }
            } else if (motionEvent.getAction() == 2) {
                com.droidhen.game.racingmototerLHL.global.f.a().c(motionEvent.getX(), motionEvent.getY());
            } else if (motionEvent.getAction() == 1) {
                com.droidhen.game.racingmototerLHL.global.f.a().b(motionEvent.getX(), motionEvent.getY());
                com.droidhen.game.racingmototerLHL.global.f.f = false;
            }
            z = true;
        }
        return z;
    }

    public void toStart() {
    }
}
