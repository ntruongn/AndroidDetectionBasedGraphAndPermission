package com.droidhen.game.racingengine.a;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public abstract class a extends l {
    protected static k a = null;
    protected static k b = null;
    public static final Map c = f();
    private com.droidhen.game.racingengine.g.c d = new com.droidhen.game.racingengine.g.c();

    private static Map f() {
        HashMap hashMap = new HashMap();
        hashMap.put(h.CENTER, new com.droidhen.game.racingengine.g.d(0.5f, 0.5f));
        hashMap.put(h.CENTERBOTTOM, new com.droidhen.game.racingengine.g.d(0.5f, 1.0f));
        hashMap.put(h.CENTERTOP, new com.droidhen.game.racingengine.g.d(0.5f, 0.0f));
        hashMap.put(h.LEFTBOTTOM, new com.droidhen.game.racingengine.g.d(0.0f, 1.0f));
        hashMap.put(h.LEFTTOP, new com.droidhen.game.racingengine.g.d(0.0f, 0.0f));
        hashMap.put(h.RIGHTBOTTOM, new com.droidhen.game.racingengine.g.d(1.0f, 1.0f));
        hashMap.put(h.RIGHTTOP, new com.droidhen.game.racingengine.g.d(1.0f, 0.0f));
        return Collections.unmodifiableMap(hashMap);
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void a() {
        float a2 = com.droidhen.game.racingengine.a.c.a() / this.R;
        float b2 = com.droidhen.game.racingengine.a.c.b() / this.S;
        if (this.T == j.FitScreen) {
            this.E *= a2;
            this.F *= b2;
            this.G.a = a2 * this.G.a;
            this.G.b = b2 * this.G.b;
        } else if (this.T == j.KeepRatio) {
            float min = Math.min(a2, b2);
            this.E *= min;
            this.F = min * this.F;
            this.G.a = a2 * this.G.a;
            this.G.b = b2 * this.G.b;
        } else if (this.T == j.KeepRatioX) {
            float a3 = com.droidhen.game.racingengine.a.c.a() / this.R;
            this.E *= a3;
            this.F *= a3;
            this.G.a *= a3;
            this.G.b = a3 * this.G.b;
        } else if (this.T == j.KeepRatioY) {
            float b3 = com.droidhen.game.racingengine.a.c.b() / this.S;
            this.E *= b3;
            this.F *= b3;
            this.G.a *= b3;
            this.G.b = b3 * this.G.b;
        } else if (this.T == j.KeepRatioAll) {
            float min2 = Math.min(a2, b2);
            this.E *= min2;
            this.F *= min2;
            this.G.a *= min2;
            this.G.b = min2 * this.G.b;
        }
        this.S = com.droidhen.game.racingengine.a.c.b();
        this.R = com.droidhen.game.racingengine.a.c.a();
    }

    public void a(float f, float f2) {
        if (b == null || a == null) {
            b = new k(this);
            a = new k(this);
        }
        if (com.droidhen.game.racingengine.g.f.c(b.b - f) > 0.1f || com.droidhen.game.racingengine.g.f.c(b.c - f2) > 0.1f) {
            com.droidhen.game.racingengine.g.e d = com.droidhen.game.racingengine.g.e.d();
            com.droidhen.game.racingengine.g.e d2 = com.droidhen.game.racingengine.g.e.d();
            com.droidhen.game.racingengine.g.c d3 = com.droidhen.game.racingengine.g.c.d();
            d3.a(f / 2.0f, f2 / 2.0f, 0.0f);
            d.b(d3);
            d3.a(180.0f, 0.0f, 0.0f);
            d2.a(d3);
            com.droidhen.game.racingengine.g.c.f(d3);
            com.droidhen.game.racingengine.g.e.a(d, d2, b.a);
            b.a.a(a.a);
            b.b = f;
            b.c = f2;
            a.b = f;
            a.c = f2;
            com.droidhen.game.racingengine.g.e.d(d2);
            com.droidhen.game.racingengine.g.e.d(d);
        }
    }

    public void a(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        a(f5, f6);
        this.d.a(((f7 - f3) * this.E) + f, ((f8 - f4) * this.F) + f2, 0.0f);
        a.a.a(this.d, this.G);
    }

    public void a(float f, float f2, h hVar) {
        if (this.Q != null) {
            a(f, f2, hVar, this.Q.E, this.Q.F);
        } else {
            a(f, f2, hVar, this.R, this.S);
        }
    }

    public void a(float f, float f2, h hVar, float f3, float f4) {
        com.droidhen.game.racingengine.g.d dVar = (com.droidhen.game.racingengine.g.d) c.get(hVar);
        com.droidhen.game.racingengine.g.d dVar2 = (com.droidhen.game.racingengine.g.d) c.get(this.H);
        a(f, f2, dVar.a, dVar.b, f3, f4, dVar2.a, dVar2.b);
    }

    public void b() {
        a(this.R, this.S);
    }
}
