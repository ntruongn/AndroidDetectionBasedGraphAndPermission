package com.droidhen.api.promptclient.prompt;

import android.os.Handler;
import android.os.Message;
import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class e extends Handler {
    final /* synthetic */ RecommendActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(RecommendActivity recommendActivity) {
        this.a = recommendActivity;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        View view;
        if (message.what == 9527) {
            view = this.a.d;
            view.setVisibility(0);
        }
    }
}
