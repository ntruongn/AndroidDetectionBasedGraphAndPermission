package com.droidhen.game.racingengine.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public enum h {
    LEFTTOP,
    CENTER,
    CENTERTOP,
    LEFTBOTTOM,
    CENTERBOTTOM,
    RIGHTTOP,
    RIGHTBOTTOM;

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static h[] valuesCustom() {
        h[] valuesCustom = values();
        int length = valuesCustom.length;
        h[] hVarArr = new h[length];
        System.arraycopy(valuesCustom, 0, hVarArr, 0, length);
        return hVarArr;
    }
}
