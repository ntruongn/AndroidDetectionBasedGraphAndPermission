package com.droidhen.api.scoreclient.d;

import java.security.MessageDigest;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    public static String a(String str, String str2, double d) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            String str3 = String.valueOf(str) + str2 + d + "^&*()";
            return a(messageDigest.digest((String.valueOf(a(messageDigest.digest(("!@#$%" + str + str2 + d).getBytes("UTF-8")))) + a(messageDigest.digest(str3.getBytes("UTF-8")))).getBytes("UTF-8")));
        } catch (Exception e) {
            return "";
        }
    }

    public static String a(byte[] bArr) {
        StringBuilder sb = new StringBuilder("");
        for (byte b : bArr) {
            String hexString = Integer.toHexString(b & 255);
            if (hexString.length() == 1) {
                sb.append("0");
            }
            sb.append(hexString);
        }
        return sb.toString().toLowerCase();
    }
}
