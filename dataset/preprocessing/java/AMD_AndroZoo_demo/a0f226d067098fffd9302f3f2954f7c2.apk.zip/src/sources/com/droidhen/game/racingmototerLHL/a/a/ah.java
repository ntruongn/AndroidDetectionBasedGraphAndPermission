package com.droidhen.game.racingmototerLHL.a.a;

import javax.microedition.khronos.opengles.GL10;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class ah extends com.droidhen.game.racingengine.a.a.e {
    final /* synthetic */ af d;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ah(af afVar, com.droidhen.game.racingengine.b.c.d dVar) {
        super(dVar);
        this.d = afVar;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        float f;
        float f2;
        float f3;
        if (this.z) {
            c();
            if (this.B != 1.0f) {
                gl10.glColor4f(1.0f, 1.0f, 1.0f, this.B);
            }
            gl10.glBindTexture(3553, this.C.a);
            gl10.glMatrixMode(5890);
            gl10.glLoadIdentity();
            f = this.d.p;
            gl10.glScalef(f, 1.0f, 1.0f);
            gl10.glMatrixMode(5888);
            gl10.glPushMatrix();
            gl10.glTranslatef(this.G.a, this.G.b, 0.0f);
            f2 = this.d.p;
            if (f2 != 1.0f) {
                f3 = this.d.p;
                gl10.glScalef(f3, 1.0f, 1.0f);
            }
            gl10.glTranslatef(this.f0I, this.J, 0.0f);
            gl10.glTexCoordPointer(2, 5126, 0, this.M);
            gl10.glVertexPointer(3, 5126, 0, this.N);
            gl10.glDrawElements(4, this.D, 5123, this.O);
            gl10.glPopMatrix();
            gl10.glMatrixMode(5890);
            gl10.glLoadIdentity();
            gl10.glMatrixMode(5888);
        }
    }
}
