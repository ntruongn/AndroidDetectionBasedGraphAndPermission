package com.droidhen.game.racingmototerLHL.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class k extends com.droidhen.game.racingengine.a.f {
    ae d;
    private com.droidhen.game.racingengine.a.a.e e;
    private x j;
    private com.droidhen.game.racingengine.a.a.f k;
    private com.droidhen.game.racingengine.a.a.f l;
    private com.droidhen.game.racingengine.a.d m;
    private o n;
    private i o;
    private n p;
    private l q;
    private com.droidhen.game.racingengine.a.a.e r;
    private af s;

    public k() {
        super(0.5f, 0.5f, 480.0f, 800.0f, -1);
        this.B = 0.0f;
        this.e = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("background"));
        this.e.a(0.0f, 800.0f, com.droidhen.game.racingengine.a.h.LEFTBOTTOM);
        this.e.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.e);
        this.r = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("scores"));
        this.r.a(83.0f, 0.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        a(this.r);
        com.droidhen.game.racingengine.a.a.e eVar = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("boost"));
        eVar.a(480.0f, 0.0f, com.droidhen.game.racingengine.a.h.RIGHTTOP);
        a(eVar);
        this.j = new x();
        this.j.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.j);
        this.k = new com.droidhen.game.racingengine.a.a.f(com.droidhen.game.racingengine.a.e.a("shuzi_03"), 0.0f, 10);
        this.k.c(0);
        this.k.a(93.0f, 35.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        a(this.k);
        this.s = new af();
        a(this.s);
        this.l = new com.droidhen.game.racingengine.a.a.f(com.droidhen.game.racingengine.a.e.a("shuzi_01"), 0.0f, 10);
        this.l.l(0.0f, -394.0f);
        this.l.e(0.5f, 0.0f);
        a(this.l);
        this.m = new com.droidhen.game.racingengine.a.d(0.0f, 800.0f, com.droidhen.game.racingengine.a.h.LEFTBOTTOM, com.droidhen.game.racingengine.a.e.a("pause_a"), com.droidhen.game.racingengine.a.e.a("pause_b"));
        this.m.a(new m(this));
        a(this.m);
        this.q = new l(this, 480.0f, 800.0f);
        this.q.a(240.0f, 400.0f, com.droidhen.game.racingengine.a.h.CENTER);
        this.q.a(com.droidhen.game.racingengine.a.j.FitScreen);
        this.q.e();
        a(this.q);
        this.n = new o(this);
        a(this.n);
        this.o = new i();
        this.o.a(240.0f, 100.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        a(this.o);
        this.p = new n(this);
        a(this.p);
        this.d = new ae();
        a(this.d);
        a(com.droidhen.game.racingmototerLHL.global.f.a().d);
    }

    public void a(int i, int i2) {
        this.n.a(i, i2);
    }

    public void a(y yVar) {
        this.p.a(yVar);
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        if (this.z) {
            super.c();
            if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.PLAYING) {
                this.k.c((int) com.droidhen.game.racingmototerLHL.global.f.b);
            }
            this.l.c(com.droidhen.game.racingmototerLHL.global.f.a);
            if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.CRASH) {
                this.j.a(com.droidhen.game.racingmototerLHL.global.f.a);
            } else if (com.droidhen.game.racingmototerLHL.global.f.f) {
                this.j.f();
            } else {
                this.j.g();
            }
        }
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        this.i = true;
        this.z = true;
        this.q.e();
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l
    public void e() {
        this.i = true;
        this.z = false;
        this.d.e();
    }

    public void f() {
        this.o.d();
    }

    public void g() {
        this.q.d();
        this.p.a(y.Panic);
    }

    @Override // com.droidhen.game.racingengine.a.f
    public void h() {
    }

    @Override // com.droidhen.game.racingengine.a.f
    public void i() {
    }
}
