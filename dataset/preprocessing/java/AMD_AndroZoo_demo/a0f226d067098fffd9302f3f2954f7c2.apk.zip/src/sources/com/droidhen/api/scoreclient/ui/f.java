package com.droidhen.api.scoreclient.ui;

import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f extends ArrayAdapter {
    final /* synthetic */ HighScoresActivity a;
    private int b;
    private int c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(HighScoresActivity highScoresActivity, Context context, int i, List list) {
        super(context, i, list);
        this.a = highScoresActivity;
        Resources resources = highScoresActivity.getResources();
        this.b = resources.getColor(2131099651);
        this.c = resources.getColor(2131099650);
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public int getCount() {
        List list;
        int i;
        List list2;
        int i2;
        list = this.a.i;
        if (list == null) {
            return 0;
        }
        i = this.a.A;
        list2 = this.a.i;
        int size = i + list2.size();
        i2 = this.a.B;
        return size + i2;
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        int i2;
        int i3;
        List list;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        View.OnClickListener onClickListener;
        View.OnClickListener onClickListener2;
        View.OnClickListener onClickListener3;
        View.OnClickListener onClickListener4;
        View.OnClickListener onClickListener5;
        View.OnClickListener onClickListener6;
        View.OnClickListener onClickListener7;
        View.OnClickListener onClickListener8;
        i2 = this.a.A;
        if (i < i2) {
            View inflate = this.a.getLayoutInflater().inflate(2130903045, (ViewGroup) null);
            ImageView imageView = (ImageView) inflate.findViewById(2131230768);
            imageView.setImageResource(2130837530);
            imageView.setTag(0);
            onClickListener5 = this.a.z;
            imageView.setOnClickListener(onClickListener5);
            TextView textView = (TextView) inflate.findViewById(2131230769);
            textView.setText(2131034124);
            textView.setTag(0);
            onClickListener6 = this.a.z;
            textView.setOnClickListener(onClickListener6);
            ImageView imageView2 = (ImageView) inflate.findViewById(2131230770);
            imageView2.setTag(2);
            onClickListener7 = this.a.z;
            imageView2.setOnClickListener(onClickListener7);
            TextView textView2 = (TextView) inflate.findViewById(2131230771);
            textView2.setTag(2);
            onClickListener8 = this.a.z;
            textView2.setOnClickListener(onClickListener8);
            return inflate;
        }
        i3 = this.a.A;
        list = this.a.i;
        if (i >= i3 + list.size()) {
            View inflate2 = this.a.getLayoutInflater().inflate(2130903045, (ViewGroup) null);
            ImageView imageView3 = (ImageView) inflate2.findViewById(2131230768);
            imageView3.setImageResource(2130837527);
            imageView3.setTag(1);
            onClickListener = this.a.z;
            imageView3.setOnClickListener(onClickListener);
            TextView textView3 = (TextView) inflate2.findViewById(2131230769);
            textView3.setText(2131034123);
            textView3.setTag(1);
            onClickListener2 = this.a.z;
            textView3.setOnClickListener(onClickListener2);
            ImageView imageView4 = (ImageView) inflate2.findViewById(2131230770);
            imageView4.setTag(2);
            onClickListener3 = this.a.z;
            imageView4.setOnClickListener(onClickListener3);
            TextView textView4 = (TextView) inflate2.findViewById(2131230771);
            textView4.setTag(2);
            onClickListener4 = this.a.z;
            textView4.setOnClickListener(onClickListener4);
            return inflate2;
        }
        View inflate3 = (view == null || view.getId() != 2130903046) ? this.a.getLayoutInflater().inflate(2130903046, (ViewGroup) null) : view;
        i4 = this.a.A;
        com.droidhen.api.scoreclient.b.b bVar = (com.droidhen.api.scoreclient.b.b) getItem(i - i4);
        TextView textView5 = (TextView) inflate3.findViewById(2131230772);
        TextView textView6 = (TextView) inflate3.findViewById(2131230773);
        TextView textView7 = (TextView) inflate3.findViewById(2131230775);
        ImageView imageView5 = (ImageView) inflate3.findViewById(2131230774);
        textView5.setText(String.valueOf(bVar.d()), (TextView.BufferType) null);
        textView6.setText(bVar.c(), (TextView.BufferType) null);
        i5 = this.a.k;
        if (i5 == 1) {
            textView7.setText(String.valueOf(bVar.a()), (TextView.BufferType) null);
        } else {
            textView7.setText(String.valueOf((int) bVar.a()), (TextView.BufferType) null);
        }
        i6 = this.a.A;
        if ((i - i6) % 2 == 0) {
            inflate3.setBackgroundColor(this.b);
        } else {
            inflate3.setBackgroundColor(this.c);
        }
        i7 = this.a.m;
        if (i7 != 0) {
            i9 = this.a.w;
            if (i9 != 0) {
                imageView5.setVisibility(8);
                return inflate3;
            }
        }
        i8 = this.a.A;
        switch (i - i8) {
            case 0:
                imageView5.setImageResource(2130837524);
                imageView5.setVisibility(0);
                break;
            case 1:
                imageView5.setImageResource(2130837550);
                imageView5.setVisibility(0);
                break;
            case 2:
                imageView5.setImageResource(2130837506);
                imageView5.setVisibility(0);
                break;
            default:
                imageView5.setVisibility(8);
                break;
        }
        return inflate3;
    }
}
