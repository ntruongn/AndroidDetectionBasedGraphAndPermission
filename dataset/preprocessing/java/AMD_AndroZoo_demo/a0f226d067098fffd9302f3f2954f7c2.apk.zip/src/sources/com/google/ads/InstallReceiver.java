package com.google.ads;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import com.google.ads.util.AdUtil;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class InstallReceiver extends BroadcastReceiver {
    private static String a(String str, String str2, String str3) {
        if (str != null) {
            try {
                StringBuilder sb = null;
                for (String str4 : str.split("&")) {
                    if (str4.startsWith("admob_")) {
                        String[] split = str4.substring("admob_".length()).split("=");
                        String encode = URLEncoder.encode(split[0], "UTF-8");
                        String encode2 = URLEncoder.encode(split[1], "UTF-8");
                        if (sb == null) {
                            sb = new StringBuilder(128);
                        } else {
                            sb.append("&");
                        }
                        sb.append(encode).append("=").append(encode2);
                    }
                }
                if (sb != null) {
                    sb.append("&").append("isu").append("=").append(URLEncoder.encode(str2, "UTF-8"));
                    sb.append("&").append("app_id").append("=").append(URLEncoder.encode(str3, "UTF-8"));
                    return "http://a.admob.com/f0?" + sb.toString();
                }
            } catch (UnsupportedEncodingException e) {
                com.google.ads.util.d.a("Could not create install URL.  Install not tracked.", e);
            }
        }
        return null;
    }

    public void a(Context context, Intent intent) {
        ActivityInfo receiverInfo;
        Set<String> keySet;
        try {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager != null && (receiverInfo = packageManager.getReceiverInfo(new ComponentName(context, (Class<?>) InstallReceiver.class), 128)) != null && ((PackageItemInfo) receiverInfo).metaData != null && (keySet = ((PackageItemInfo) receiverInfo).metaData.keySet()) != null) {
                Iterator<String> it = keySet.iterator();
                while (it.hasNext()) {
                    String str = null;
                    try {
                        str = ((PackageItemInfo) receiverInfo).metaData.getString(it.next());
                    } catch (Exception e) {
                        e = e;
                    }
                    try {
                        if (!str.equals("com.google.android.apps.analytics.AnalyticsReceiver")) {
                            ((BroadcastReceiver) Class.forName(str).newInstance()).onReceive(context, intent);
                            com.google.ads.util.d.a("Successfully forwarded install notification to " + str);
                        }
                    } catch (Exception e2) {
                        e = e2;
                        com.google.ads.util.d.c("Could not forward Market's INSTALL_REFERRER intent to " + str, e);
                    }
                }
            }
            try {
                try {
                    ((BroadcastReceiver) Class.forName("com.google.android.apps.analytics.AnalyticsReceiver").newInstance()).onReceive(context, intent);
                    com.google.ads.util.d.a("Successfully forwarded install notification to com.google.android.apps.analytics.AnalyticsReceiver");
                } catch (ClassNotFoundException e3) {
                    com.google.ads.util.d.d("Google Analytics not installed.");
                }
            } catch (Exception e4) {
                com.google.ads.util.d.c("Exception from the Google Analytics install receiver.", e4);
            }
        } catch (Exception e5) {
            com.google.ads.util.d.c("Unhandled exception while forwarding install intents. Possibly lost some install information.", e5);
        }
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        try {
            String stringExtra = intent.getStringExtra("referrer");
            String a = AdUtil.a(context);
            String a2 = a(stringExtra, a, context.getPackageName());
            if (a2 != null) {
                com.google.ads.util.d.d("Processing install from an AdMob ad (" + a2 + ").");
            }
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(a2).openConnection();
            AdUtil.a(httpURLConnection, context.getApplicationContext());
            httpURLConnection.setRequestProperty("X-Admob-Isu", a);
            httpURLConnection.getResponseCode();
            a(context, intent);
        } catch (Exception e) {
            com.google.ads.util.d.a("Unhandled exception processing Market install.", e);
        }
    }
}
