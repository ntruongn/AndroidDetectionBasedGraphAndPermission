package com.droidhen.game.racingengine.b.c;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    private ArrayList a = new ArrayList();

    public int a() {
        return this.a.size();
    }

    public com.droidhen.game.racingengine.d.c a(int i) {
        return (com.droidhen.game.racingengine.d.c) this.a.get(i);
    }

    public boolean a(com.droidhen.game.racingengine.d.c cVar) {
        return this.a.add(cVar);
    }
}
