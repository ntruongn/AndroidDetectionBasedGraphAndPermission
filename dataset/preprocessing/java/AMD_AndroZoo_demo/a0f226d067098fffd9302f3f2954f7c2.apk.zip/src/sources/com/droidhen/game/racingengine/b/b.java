package com.droidhen.game.racingengine.b;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    private FloatBuffer a;
    private int b;

    public b(FloatBuffer floatBuffer, int i) {
        this.b = 0;
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(floatBuffer.limit() * 4);
        allocateDirect.order(ByteOrder.nativeOrder());
        this.a = allocateDirect.asFloatBuffer();
        this.a.put(floatBuffer);
        this.b = i;
    }

    public int a() {
        return this.b;
    }

    public void a(int i, com.droidhen.game.racingengine.g.c cVar) {
        this.a.position(i * 3);
        this.a.put(cVar.a);
        this.a.put(cVar.b);
        this.a.put(cVar.c);
    }

    public void a(float[] fArr) {
        this.a.position(0);
        this.a.put(fArr);
    }

    public FloatBuffer b() {
        return this.a;
    }

    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public b clone() {
        this.a.position(0);
        return new b(this.a, a());
    }
}
