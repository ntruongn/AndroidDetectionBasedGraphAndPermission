package com.droidhen.game.racingmototerLHL.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public enum m {
    INIT,
    FRONT,
    BACK;

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static m[] valuesCustom() {
        m[] valuesCustom = values();
        int length = valuesCustom.length;
        m[] mVarArr = new m[length];
        System.arraycopy(valuesCustom, 0, mVarArr, 0, length);
        return mVarArr;
    }
}
