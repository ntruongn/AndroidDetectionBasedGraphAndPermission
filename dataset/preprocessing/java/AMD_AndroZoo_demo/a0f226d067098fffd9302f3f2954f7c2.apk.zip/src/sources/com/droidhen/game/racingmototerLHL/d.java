package com.droidhen.game.racingmototerLHL;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d {
    private static SharedPreferences a;

    public static synchronized void a(Context context, boolean z) {
        synchronized (d.class) {
            c(context);
            SharedPreferences.Editor edit = a.edit();
            edit.putBoolean("sound_enabled", z);
            edit.commit();
        }
    }

    public static synchronized boolean a(Context context) {
        boolean z;
        synchronized (d.class) {
            c(context);
            z = a.getBoolean("sound_enabled", true);
        }
        return z;
    }

    public static synchronized void b(Context context, boolean z) {
        synchronized (d.class) {
            c(context);
            SharedPreferences.Editor edit = a.edit();
            edit.putBoolean("novice_tutorial", z);
            edit.commit();
        }
    }

    public static synchronized boolean b(Context context) {
        boolean z;
        synchronized (d.class) {
            c(context);
            z = a.getBoolean("novice_tutorial", false);
        }
        return z;
    }

    private static void c(Context context) {
        if (a == null) {
            a = context.getSharedPreferences("config", 0);
        }
    }
}
