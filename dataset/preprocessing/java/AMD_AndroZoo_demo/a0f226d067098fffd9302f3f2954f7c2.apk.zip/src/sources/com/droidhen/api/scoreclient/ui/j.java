package com.droidhen.api.scoreclient.ui;

import android.view.View;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class j implements View.OnClickListener {
    final /* synthetic */ HighScoresActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(HighScoresActivity highScoresActivity) {
        this.a = highScoresActivity;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int i20;
        Integer num = (Integer) view.getTag();
        if (num == null) {
            return;
        }
        switch (num.intValue()) {
            case 0:
                this.a.o = false;
                HighScoresActivity highScoresActivity = this.a;
                i13 = highScoresActivity.w;
                i14 = this.a.x;
                highScoresActivity.w = i13 - i14;
                i15 = this.a.w;
                if (i15 < 0) {
                    this.a.w = 0;
                }
                i16 = this.a.m;
                if (i16 == 2) {
                    HighScoresActivity highScoresActivity2 = this.a;
                    i19 = this.a.w;
                    i20 = this.a.x;
                    highScoresActivity2.a(i19, i20, 1);
                    return;
                }
                HighScoresActivity highScoresActivity3 = this.a;
                i17 = this.a.w;
                i18 = this.a.x;
                highScoresActivity3.a(i17, i18, 0);
                return;
            case 1:
                this.a.o = false;
                HighScoresActivity highScoresActivity4 = this.a;
                i6 = highScoresActivity4.w;
                i7 = this.a.x;
                highScoresActivity4.w = i6 + i7;
                i8 = this.a.m;
                if (i8 == 2) {
                    HighScoresActivity highScoresActivity5 = this.a;
                    i11 = this.a.w;
                    i12 = this.a.x;
                    highScoresActivity5.a(i11, i12, 1);
                    return;
                }
                HighScoresActivity highScoresActivity6 = this.a;
                i9 = this.a.w;
                i10 = this.a.x;
                highScoresActivity6.a(i9, i10, 0);
                return;
            case 2:
                this.a.o = false;
                this.a.w = 0;
                i = this.a.m;
                if (i == 2) {
                    HighScoresActivity highScoresActivity7 = this.a;
                    i4 = this.a.w;
                    i5 = this.a.x;
                    highScoresActivity7.a(i4, i5, 1);
                    return;
                }
                HighScoresActivity highScoresActivity8 = this.a;
                i2 = this.a.w;
                i3 = this.a.x;
                highScoresActivity8.a(i2, i3, 0);
                return;
            default:
                return;
        }
    }
}
