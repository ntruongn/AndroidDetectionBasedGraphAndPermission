package com.droidhen.game.racingengine.g;

import java.util.Random;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class f {
    public static final Random a = new Random(System.currentTimeMillis());

    private f() {
    }

    public static float a() {
        return a.nextFloat();
    }

    public static float a(float f) {
        return (float) Math.cos(f);
    }

    public static int a(int i, int i2) {
        return ((int) (a() * ((i2 - i) + 1))) + i;
    }

    public static float b(float f) {
        return (float) Math.sin(f);
    }

    public static float c(float f) {
        return f < 0.0f ? -f : f;
    }

    public static float d(float f) {
        return (float) Math.tan(f);
    }
}
