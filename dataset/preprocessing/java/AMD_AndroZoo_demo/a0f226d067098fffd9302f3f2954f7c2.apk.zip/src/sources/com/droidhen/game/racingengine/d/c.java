package com.droidhen.game.racingengine.d;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c {
    public String a;
    public boolean b = false;
    public boolean c = true;
    public boolean d = true;
    public float e = 0.0f;
    public float f = 0.0f;
    public float g = 1.0f;
    public float h = 1.0f;
    public ArrayList i = new ArrayList();

    public c(String str) {
        this.a = str;
        this.i.add(new b());
    }
}
