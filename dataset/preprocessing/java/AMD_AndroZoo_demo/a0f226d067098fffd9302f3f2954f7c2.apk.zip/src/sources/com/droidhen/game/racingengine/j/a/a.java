package com.droidhen.game.racingengine.j.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    public d a;
    public d b;
    public int d;
    private boolean e;
    public com.droidhen.game.racingengine.j.a c = null;
    private boolean f = true;
    private boolean g = true;

    public a(float f, float f2, float f3, float f4) {
        this.a = new d(f, f2);
        this.b = new d(f3, f4);
    }

    public void a() {
    }

    public void a(a aVar, a aVar2) {
    }

    public void a(com.droidhen.game.racingengine.j.a aVar) {
        this.c = aVar;
    }

    public void a(boolean z) {
        this.f = z;
    }

    public boolean a(a aVar) {
        if (!this.g) {
            return false;
        }
        if (this.a.a(aVar.a)) {
            if (c.a(this.b, aVar.b)) {
                if (this.f) {
                    b(this, aVar);
                }
                this.e = true;
                return true;
            }
            if (this.f) {
                a(this, aVar);
            }
        }
        this.e = false;
        return false;
    }

    public void b(a aVar, a aVar2) {
    }

    public boolean b() {
        return this.f;
    }

    public boolean c() {
        return this.g;
    }

    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public a clone() {
        try {
            return (a) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
}
