package com.droidhen.api.promptclient.a;

import java.util.Random;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e {
    public static final String[] a = {"com.hz.game", "com.droidhen", "com.reverie.game"};
    public static final String[] b = {"com.hz.game", "com.droidhen", "com.reverie.game", "com.myyearbook"};
    public static final Random c = new Random();
}
