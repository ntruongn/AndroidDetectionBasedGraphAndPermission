package com.droidhen.api.scoreclient.ui;

import android.content.DialogInterface;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class m implements DialogInterface.OnClickListener {
    final /* synthetic */ HighScoresActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public m(HighScoresActivity highScoresActivity) {
        this.a = highScoresActivity;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        int i2;
        int i3;
        this.a.m = 0;
        HighScoresActivity highScoresActivity = this.a;
        i2 = this.a.m;
        highScoresActivity.b(i2);
        HighScoresActivity highScoresActivity2 = this.a;
        i3 = this.a.l;
        highScoresActivity2.c(i3);
    }
}
