package com.droidhen.game.racingengine.f;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class g {
    public int a;

    private g() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ g(g gVar) {
        this();
    }
}
