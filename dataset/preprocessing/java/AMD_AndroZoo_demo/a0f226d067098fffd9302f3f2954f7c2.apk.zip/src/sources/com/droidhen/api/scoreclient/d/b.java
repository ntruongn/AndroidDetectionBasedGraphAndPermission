package com.droidhen.api.scoreclient.d;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    private static BasicHttpParams a;

    public static String a(String str, List list) {
        try {
            if (a == null) {
                a = new BasicHttpParams();
            }
            HttpConnectionParams.setConnectionTimeout(a, 15000);
            HttpConnectionParams.setSoTimeout(a, 15000);
            DefaultHttpClient defaultHttpClient = new DefaultHttpClient(a);
            HttpPost httpPost = new HttpPost(str);
            httpPost.setEntity(new UrlEncodedFormEntity(list, "UTF-8"));
            HttpResponse execute = defaultHttpClient.execute(httpPost);
            if (execute.getStatusLine().getStatusCode() == 200) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                InputStream content = execute.getEntity().getContent();
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = content.read(bArr);
                    if (read <= 0) {
                        return byteArrayOutputStream.toString("UTF-8");
                    }
                    byteArrayOutputStream.write(bArr, 0, read);
                }
            }
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return null;
    }
}
