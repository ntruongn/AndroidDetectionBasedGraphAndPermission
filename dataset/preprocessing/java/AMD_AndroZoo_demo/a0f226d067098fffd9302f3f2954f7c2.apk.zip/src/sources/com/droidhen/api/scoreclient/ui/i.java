package com.droidhen.api.scoreclient.ui;

import android.content.Context;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class i {
    private static b a;

    public static b a() {
        if (a == null) {
            throw new IllegalStateException("ScoreClientManagerSingleton.init() must be called first");
        }
        return a;
    }

    public static b a(Context context) {
        if (a != null) {
            throw new IllegalStateException("ScoreClientManagerSingleton.init() can be called only once");
        }
        a = new h(context);
        return a;
    }
}
