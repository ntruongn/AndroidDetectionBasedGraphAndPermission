package com.droidhen.game.racingmototerLHL.a.a;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class x extends com.droidhen.game.racingengine.a.a {
    private float e;
    private int[] j;
    private com.droidhen.game.racingengine.a.a.e k;
    private ak l;
    private b m;
    private float f = 200.0f;
    private float g = 100.0f;
    private float h = 160.0f;
    private int i = 20;
    float d = 10.0f;

    public x() {
        this.E = 162.0f;
        this.F = 162.0f;
        a(240.0f, 800.0f, com.droidhen.game.racingengine.a.h.LEFTBOTTOM);
        a(com.droidhen.game.racingengine.a.j.FitScreen);
        this.j = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2};
        this.k = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("biaopan_bg"));
        this.k.a(240.0f, 800.0f, com.droidhen.game.racingengine.a.h.CENTERBOTTOM);
        this.k.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.k);
        this.l = new ak(this);
        this.l.a(com.droidhen.game.racingengine.a.h.CENTERBOTTOM);
        this.l.a(240.0f, 774.0f, com.droidhen.game.racingengine.a.h.CENTERBOTTOM);
        a(this.l);
        this.m = new b(this);
        this.m.a(240.0f, 774.0f, com.droidhen.game.racingengine.a.h.CENTERBOTTOM);
        a(this.m);
    }

    @Override // com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        super.a();
        this.k.a();
        this.m.a();
        this.l.a();
    }

    public void a(int i) {
        this.e = i;
        this.m.a(i);
        this.l.a(i);
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        gl10.glPushMatrix();
        gl10.glTranslatef(this.G.a, this.G.b, 0.0f);
        gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.k.a(gl10);
        this.m.a(gl10);
        this.l.a(gl10);
        gl10.glPopMatrix();
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean b(float f, float f2) {
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void e() {
    }

    public void f() {
        this.e += this.d;
        if (this.e > this.f) {
            this.e = this.f - (com.droidhen.game.racingengine.g.f.a() * this.d);
        }
        a((int) this.e);
    }

    public void g() {
        this.e -= this.d;
        if (this.e < this.g) {
            this.e = this.g;
        }
        a((int) this.e);
    }
}
