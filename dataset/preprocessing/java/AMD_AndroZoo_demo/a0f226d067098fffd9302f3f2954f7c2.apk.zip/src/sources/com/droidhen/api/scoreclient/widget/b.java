package com.droidhen.api.scoreclient.widget;

import android.view.View;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b implements View.OnFocusChangeListener {
    final /* synthetic */ UsernameEdit a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(UsernameEdit usernameEdit) {
        this.a = usernameEdit;
    }

    @Override // android.view.View.OnFocusChangeListener
    public void onFocusChange(View view, boolean z) {
        if (z) {
            return;
        }
        this.a.setCursorVisible(false);
        this.a.c(false);
        this.a.d(true);
    }
}
