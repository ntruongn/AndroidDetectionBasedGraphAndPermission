package com.droidhen.game.racingmototerLHL.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class al extends com.droidhen.game.racingengine.a.e implements Cloneable {
    private static com.droidhen.game.racingengine.b.c.d[] d = null;

    public al() {
        super(com.droidhen.game.racingengine.a.e.a("n_10"));
        d = new com.droidhen.game.racingengine.b.c.d[]{com.droidhen.game.racingengine.a.e.a("n_10"), com.droidhen.game.racingengine.a.e.a("n_20"), com.droidhen.game.racingengine.a.e.a("n_30"), com.droidhen.game.racingengine.a.e.a("n_40"), com.droidhen.game.racingengine.a.e.a("n_50")};
    }

    public void a(int i, int i2) {
        int i3 = (i2 / 10) - 1;
        if (i3 >= 5) {
            i3 = 4;
        }
        if (i == 0) {
            this.G.a = (com.droidhen.game.racingengine.a.c.a() / 2.0f) - this.E;
        } else if (i == 1) {
            this.G.a = 0.0f;
        } else {
            this.G.a = (-com.droidhen.game.racingengine.a.c.a()) / 2.0f;
        }
        a(d[i3]);
        d();
    }

    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public al clone() {
        al alVar;
        al alVar2 = null;
        try {
            alVar = (al) super.clone();
        } catch (CloneNotSupportedException e) {
            e = e;
        }
        try {
            alVar.G = this.G.clone();
            return alVar;
        } catch (CloneNotSupportedException e2) {
            alVar2 = alVar;
            e = e2;
            e.printStackTrace();
            return alVar2;
        }
    }
}
