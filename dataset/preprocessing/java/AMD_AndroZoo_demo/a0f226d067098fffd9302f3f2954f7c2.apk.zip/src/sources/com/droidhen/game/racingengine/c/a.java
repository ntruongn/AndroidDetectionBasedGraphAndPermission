package com.droidhen.game.racingengine.c;

import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    private static com.droidhen.game.racingengine.g.c h = null;
    private h d;
    private ArrayList e = new ArrayList();
    private ArrayList f = new ArrayList();
    private int g = 0;
    public c a = c.NORMALIZE;
    com.droidhen.game.racingengine.g.e b = new com.droidhen.game.racingengine.g.e();
    com.droidhen.game.racingengine.g.e c = new com.droidhen.game.racingengine.g.e();

    private void a(h hVar, com.droidhen.game.racingengine.g.e[] eVarArr, float[] fArr, com.droidhen.game.racingengine.g.e eVar, com.droidhen.game.racingengine.g.e eVar2) {
        hVar.a(eVar, eVar2, this.c);
        for (int i = 0; i < hVar.a(); i++) {
            int i2 = hVar.g[i];
            float f = hVar.h[i];
            if (f != 0.0f) {
                this.b.c(this.c);
                a(this.b, f);
                if (this.a == c.ADDITIVE) {
                    Log.e("RacingEngine", "Skeleton:Link Mode not be supported Now.");
                    throw new Error("Link Mode not be supported Now.");
                }
                a(eVarArr[i2], this.b);
                fArr[i2] = f + fArr[i2];
            }
        }
        for (int i3 = 0; i3 < hVar.f.size(); i3++) {
            a((h) hVar.f.get(i3), eVarArr, fArr, eVar, eVar2);
        }
    }

    private static void a(com.droidhen.game.racingengine.g.e eVar, float f) {
        for (int i = 0; i < 16; i++) {
            float[] fArr = eVar.b;
            fArr[i] = fArr[i] * f;
        }
    }

    private static void a(com.droidhen.game.racingengine.g.e eVar, com.droidhen.game.racingengine.g.e eVar2) {
        for (int i = 0; i < 16; i++) {
            float[] fArr = eVar.b;
            fArr[i] = fArr[i] + eVar2.b[i];
        }
    }

    private void b(h hVar) {
        this.e.add(hVar);
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= hVar.f.size()) {
                return;
            }
            b((h) hVar.f.get(i2));
            i = i2 + 1;
        }
    }

    public h a() {
        return this.d;
    }

    public h a(long j) {
        this.e.clear();
        b(this.d);
        Iterator it = this.e.iterator();
        while (it.hasNext()) {
            h hVar = (h) it.next();
            if (hVar.b == j) {
                return hVar;
            }
        }
        return null;
    }

    public void a(h hVar) {
        this.d = hVar;
    }

    public void a(com.droidhen.game.racingengine.g.e[] eVarArr, float[] fArr, com.droidhen.game.racingengine.g.e eVar, com.droidhen.game.racingengine.g.e eVar2) {
        for (c cVar : c.valuesCustom()) {
            if (cVar.a() == a().d) {
                this.a = cVar;
            }
        }
        a(a(), eVarArr, fArr, eVar, eVar2);
    }
}
