package com.droidhen.game.racingmototerLHL.a;

import com.droidhen.game.racingengine.a.f;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b extends f {
    final /* synthetic */ a d;
    private int e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(a aVar, float f, float f2, float f3, float f4, int i) {
        super(f, f2, f3, f4, i);
        this.d = aVar;
        this.e = 0;
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        this.z = true;
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l
    public void e() {
        this.z = false;
    }

    @Override // com.droidhen.game.racingengine.a.f
    public void i() {
    }

    @Override // com.droidhen.game.racingengine.a.f
    public void j() {
    }
}
