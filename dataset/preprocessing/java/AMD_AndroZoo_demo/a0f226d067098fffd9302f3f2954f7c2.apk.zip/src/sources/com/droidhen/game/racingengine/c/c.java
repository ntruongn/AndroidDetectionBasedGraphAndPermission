package com.droidhen.game.racingengine.c;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public enum c {
    NORMALIZE(0),
    ADDITIVE(1),
    TOTAL1(2);

    private final int d;

    c(int i) {
        this.d = i;
    }

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static c[] valuesCustom() {
        c[] valuesCustom = values();
        int length = valuesCustom.length;
        c[] cVarArr = new c[length];
        System.arraycopy(valuesCustom, 0, cVarArr, 0, length);
        return cVarArr;
    }

    public int a() {
        return this.d;
    }
}
