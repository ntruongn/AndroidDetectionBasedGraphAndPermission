package com.droidhen.api.promptclient.prompt;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class RecommendActivity extends Activity {
    a a;
    View.OnClickListener b = new d(this);
    Handler c = new e(this);
    private View d;

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0046  */
    /* JADX WARN: Removed duplicated region for block: B:17:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void a(java.lang.String r7, int r8) {
        /*
            r6 = this;
            r4 = 0
            java.net.URL r0 = new java.net.URL     // Catch: java.io.IOException -> L4a
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch: java.io.IOException -> L4a
            java.lang.String r2 = "http://moreapps.droidhen.com/games/"
            r1.<init>(r2)     // Catch: java.io.IOException -> L4a
            java.lang.StringBuilder r1 = r1.append(r7)     // Catch: java.io.IOException -> L4a
            java.lang.String r1 = r1.toString()     // Catch: java.io.IOException -> L4a
            r0.<init>(r1)     // Catch: java.io.IOException -> L4a
            java.net.URLConnection r0 = r0.openConnection()     // Catch: java.io.IOException -> L4a
            java.net.HttpURLConnection r0 = (java.net.HttpURLConnection) r0     // Catch: java.io.IOException -> L4a
            r1 = 5000(0x1388, float:7.006E-42)
            r0.setConnectTimeout(r1)     // Catch: java.io.IOException -> L53
            java.io.DataInputStream r1 = new java.io.DataInputStream     // Catch: java.io.IOException -> L53
            java.io.BufferedInputStream r2 = new java.io.BufferedInputStream     // Catch: java.io.IOException -> L53
            java.io.InputStream r3 = r0.getInputStream()     // Catch: java.io.IOException -> L53
            r2.<init>(r3)     // Catch: java.io.IOException -> L53
            r1.<init>(r2)     // Catch: java.io.IOException -> L53
            android.graphics.Bitmap r2 = android.graphics.BitmapFactory.decodeStream(r1)     // Catch: java.io.IOException -> L58
            if (r2 == 0) goto L5d
            android.os.Handler r3 = r6.c     // Catch: java.io.IOException -> L58
            com.droidhen.api.promptclient.prompt.c r4 = new com.droidhen.api.promptclient.prompt.c     // Catch: java.io.IOException -> L58
            r4.<init>(r6, r8, r2)     // Catch: java.io.IOException -> L58
            r3.post(r4)     // Catch: java.io.IOException -> L58
            r5 = r1
            r1 = r0
            r0 = r5
        L41:
            com.droidhen.api.promptclient.a.d.a(r0)
            if (r1 == 0) goto L49
            r1.disconnect()
        L49:
            return
        L4a:
            r0 = move-exception
            r1 = r4
            r2 = r4
        L4d:
            r0.printStackTrace()
            r0 = r1
            r1 = r2
            goto L41
        L53:
            r1 = move-exception
            r2 = r0
            r0 = r1
            r1 = r4
            goto L4d
        L58:
            r2 = move-exception
            r5 = r2
            r2 = r0
            r0 = r5
            goto L4d
        L5d:
            r5 = r1
            r1 = r0
            r0 = r5
            goto L41
        */
        throw new UnsupportedOperationException("Method not decompiled: com.droidhen.api.promptclient.prompt.RecommendActivity.a(java.lang.String, int):void");
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(new k(this).a());
        this.a = f.b(this);
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= k.a.length) {
                new b(this).start();
                this.d = findViewById(2131230720);
                this.d.setVisibility(8);
                this.d.setOnClickListener(this.b);
                return;
            }
            TextView textView = (TextView) findViewById(k.b[i2]);
            ImageView imageView = (ImageView) findViewById(k.a[i2]);
            textView.setText(this.a.b[i2].b);
            textView.setOnClickListener(this.b);
            imageView.setOnClickListener(this.b);
            i = i2 + 1;
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() != 4 || this.d.getVisibility() == 0) {
            return super.onKeyDown(i, keyEvent);
        }
        return true;
    }
}
