package com.droidhen.api.promptclient.prompt;

import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    public int a;
    public i[] b;
    public String c;
    public String d;
    public long e;
    public int f;

    public a() {
    }

    public a(int i, i[] iVarArr) {
        this.a = i;
        this.b = iVarArr;
        this.e = System.currentTimeMillis();
        this.f = 0;
    }

    public static a a(String str) {
        JSONObject jSONObject = new JSONObject(str);
        int i = jSONObject.getInt("code");
        System.err.println("code : " + i);
        if (i != 0) {
            return null;
        }
        int i2 = jSONObject.getInt("id");
        i[] iVarArr = new i[3];
        JSONArray jSONArray = jSONObject.getJSONArray("games");
        for (int i3 = 0; i3 < 3; i3++) {
            iVarArr[i3] = new i(jSONArray.getJSONObject(i3).getString("icon"), jSONArray.getJSONObject(i3).getString("title"), jSONArray.getJSONObject(i3).getString("link"));
        }
        a aVar = new a(i2, iVarArr);
        if (!jSONObject.isNull("es1")) {
            aVar.c = jSONObject.getString("es1");
        }
        if (!jSONObject.isNull("es2")) {
            aVar.d = jSONObject.getString("es2");
        }
        return aVar;
    }

    public boolean a() {
        if (this.b == null || this.b.length != 3) {
            return false;
        }
        for (int i = 0; i < this.b.length; i++) {
            if (com.droidhen.api.promptclient.a.c.a(this.b[i].b)) {
                return false;
            }
        }
        return true;
    }
}
