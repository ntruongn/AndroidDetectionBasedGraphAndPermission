package com.droidhen.game.racingengine.b.a;

import java.util.ArrayList;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    private ArrayList b = new ArrayList();
    private b a = new b();

    private void c(GL10 gl10) {
        this.a.a(gl10);
        gl10.glShadeModel(7425);
        gl10.glClearDepthf(1.0f);
        gl10.glEnable(2929);
        gl10.glDepthFunc(515);
        gl10.glDisable(2929);
        gl10.glEnable(3008);
        gl10.glHint(3152, 4354);
        gl10.glEnable(3042);
        gl10.glBlendFunc(1, 771);
        gl10.glEnable(3155);
        gl10.glHint(3155, 4354);
        gl10.glFrontFace(2305);
        gl10.glCullFace(1029);
        gl10.glEnable(2884);
        gl10.glEnableClientState(32884);
        gl10.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        gl10.glClear(16640);
    }

    public b a() {
        return this.a;
    }

    public com.droidhen.game.racingengine.i.a a(int i) {
        return (com.droidhen.game.racingengine.i.a) this.b.get(i);
    }

    public void a(b bVar) {
        this.a = bVar;
    }

    public void a(com.droidhen.game.racingengine.i.a aVar) {
        if (aVar != null) {
            this.b.add(aVar);
        }
    }

    public void a(GL10 gl10) {
        c(gl10);
    }

    public int b() {
        return this.b.size();
    }

    public synchronized void b(GL10 gl10) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 < this.b.size()) {
                ((com.droidhen.game.racingengine.i.a) this.b.get(i2)).a(gl10);
                i = i2 + 1;
            }
        }
    }

    public synchronized boolean b(com.droidhen.game.racingengine.i.a aVar) {
        return this.b.remove(aVar);
    }

    public synchronized void c() {
        this.a = new b();
        this.b.clear();
        System.gc();
    }
}
