package com.droidhen.game.racingmototerLHL.a.a;

import android.app.Activity;
import android.widget.Toast;
import com.droidhen.game.racingmototerLHL.GameActivity;
import com.droidhen.game.racingmototerLHL.global.SCApplication;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class z implements com.droidhen.game.racingengine.a.g {
    final /* synthetic */ ag a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public z(ag agVar) {
        this.a = agVar;
    }

    @Override // com.droidhen.game.racingengine.a.g
    public void a(com.droidhen.game.racingengine.a.d dVar) {
        boolean z;
        float f;
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.a);
        if (com.droidhen.game.racingmototerLHL.global.f.b().o) {
            f = this.a.x;
            if (f <= 0.0f) {
                Toast.makeText(com.droidhen.game.racingengine.a.a.a(), "You can't submit your score in tutorial mode.", 0).show();
                this.a.x = 3.0f;
                return;
            }
            return;
        }
        z = ag.v;
        if (z) {
            com.droidhen.api.scoreclient.ui.c.a((Activity) com.droidhen.game.racingengine.a.a.a(), com.droidhen.game.racingmototerLHL.a.b, SCApplication.a(), true);
        } else {
            com.droidhen.api.scoreclient.ui.c.a((Activity) com.droidhen.game.racingengine.a.a.a(), com.droidhen.game.racingmototerLHL.a.b, SCApplication.a(), (int) com.droidhen.game.racingmototerLHL.global.f.b, (com.droidhen.api.scoreclient.ui.g) com.droidhen.game.racingengine.a.a.a());
        }
    }
}
