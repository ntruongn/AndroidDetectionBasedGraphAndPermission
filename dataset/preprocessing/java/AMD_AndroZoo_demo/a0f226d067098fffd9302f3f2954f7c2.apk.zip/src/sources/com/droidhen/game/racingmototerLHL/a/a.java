package com.droidhen.game.racingmototerLHL.a;

import android.util.Log;
import com.droidhen.api.scoreclient.widget.UsernameEdit;
import com.droidhen.game.racingengine.a.f;
import com.droidhen.game.racingengine.a.i;
import com.droidhen.game.racingengine.b.c.c;
import com.droidhen.game.racingengine.b.c.d;
import com.droidhen.game.racingmototerLHL.GameActivity;
import com.droidhen.game.racingmototerLHL.a.a.ae;
import com.droidhen.game.racingmototerLHL.a.a.ag;
import com.droidhen.game.racingmototerLHL.a.a.aq;
import com.droidhen.game.racingmototerLHL.a.a.e;
import com.droidhen.game.racingmototerLHL.a.a.j;
import com.droidhen.game.racingmototerLHL.a.a.k;
import com.droidhen.game.racingmototerLHL.a.a.y;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    public static boolean i = false;
    public UsernameEdit a;
    private boolean n = true;
    private aq o = null;
    private k p = null;
    private ag q = null;
    private j r = null;
    private e s = null;
    private b t = null;
    private com.droidhen.game.racingmototerLHL.a.a.a u = null;
    private f v = null;
    public com.droidhen.game.racingengine.b.c.b b = null;
    public com.droidhen.game.racingengine.b.c.b c = null;
    public com.droidhen.game.racingengine.b.c.b d = null;
    public com.droidhen.game.racingengine.b.c.b e = null;
    public com.droidhen.game.racingengine.b.c.b f = null;
    public com.droidhen.game.racingengine.b.c.b g = null;
    public com.droidhen.game.racingengine.b.c.b h = null;
    float j = 0.0f;
    float k = 0.0f;
    private HashMap l = new HashMap();
    private ArrayList m = new ArrayList();

    public a(GameActivity gameActivity) {
        this.a = gameActivity.c();
    }

    private void b(GL10 gl10) {
        gl10.glClearDepthf(1.0f);
        gl10.glDisable(2929);
        gl10.glDisable(2896);
        gl10.glEnable(3042);
        gl10.glBlendFunc(1, 771);
        gl10.glMatrixMode(5889);
        gl10.glLoadIdentity();
        gl10.glOrthof((-com.droidhen.game.racingengine.a.c.a()) / 2, com.droidhen.game.racingengine.a.c.a() / 2, (-com.droidhen.game.racingengine.a.c.b()) / 2, com.droidhen.game.racingengine.a.c.b() / 2, -1.0f, 10.0f);
        gl10.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        gl10.glMatrixMode(5888);
        gl10.glLoadIdentity();
        gl10.glEnableClientState(32884);
        gl10.glEnable(3553);
        gl10.glEnableClientState(32888);
        gl10.glTexEnvf(8960, 8704, 8448.0f);
    }

    private void h() {
        if (this.v != null) {
            this.v.e();
        }
    }

    public void a() {
        for (int size = this.m.size() - 1; size >= 0; size--) {
            i iVar = (i) this.m.get(size);
            iVar.c();
            if (((f) iVar).i && !((f) iVar).z) {
                this.m.remove(size);
                ((f) iVar).k().e();
            }
        }
    }

    public void a(int i2, int i3) {
        this.p.a(i2, i3);
    }

    public void a(i iVar) {
        if (this.l.containsKey(iVar.p())) {
            return;
        }
        this.l.put(iVar.p(), iVar);
    }

    public void a(c cVar) {
        this.b = new com.droidhen.game.racingengine.b.c.b("Textures/MenuTextures/loading/", "Loading");
        this.c = new com.droidhen.game.racingengine.b.c.b("Textures/MenuTextures/menus/", "Menu");
        this.d = new com.droidhen.game.racingengine.b.c.b("Textures/MenuTextures/panel/", "Panel");
        this.e = new com.droidhen.game.racingengine.b.c.b("Textures/MenuTextures/panel/pause/", "PusePanel");
        this.f = new com.droidhen.game.racingengine.b.c.b("Textures/MenuTextures/gameOver/", "GameOver");
        this.g = new com.droidhen.game.racingengine.b.c.b("Textures/MenuTextures/tutorial/", "Tutorial");
        this.h = new com.droidhen.game.racingengine.b.c.b("Textures/MenuTextures/selectMoto/", "SelectMoto");
        this.b.a(new d[]{new d("loading_bg", "Textures/MenuTextures/menus/begin_bg.png", 480.0f, 800.0f, 512.0f, 1024.0f), new d("Textures/MenuTextures/loading/loading", 122.0f, 18.0f, 128.0f, 32.0f), new d("Textures/MenuTextures/loading/rotate", 54.0f, 54.0f, 64.0f, 64.0f)});
        this.b.c();
        this.c.a(new d[]{new d("share_menu", "Textures/MenuTextures/gameOver/share.png", 102.0f, 99.0f, 128.0f, 128.0f), new d("Textures/MenuTextures/menus/begin_bg", 480.0f, 800.0f, 512.0f, 1024.0f), new d(1, "Textures/MenuTextures/menus/b_selectmoto_a.png", 263.0f, 54.0f, 512.0f, 64.0f), new d(1, "Textures/MenuTextures/menus/b_selectmoto_b.png", 263.0f, 54.0f, 512.0f, 64.0f), new d("Textures/MenuTextures/menus/music_01", 117.0f, 104.0f, 128.0f, 128.0f), new d("Textures/MenuTextures/menus/music_02", 117.0f, 104.0f, 128.0f, 128.0f), new d(1, "Textures/MenuTextures/menus/play_b.png", 165.0f, 54.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/menus/play_a.png", 165.0f, 54.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/menus/score_a.png", 165.0f, 54.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/menus/score_b.png", 165.0f, 54.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/menus/tutorial_a.png", 195.0f, 54.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/menus/tutorial_b.png", 195.0f, 54.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/menus/more_a.png", 165.0f, 54.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/menus/more_b.png", 165.0f, 54.0f, 256.0f, 64.0f)});
        this.c.c();
        this.d.a(new d[]{new d("Textures/MenuTextures/panel/background", 480.0f, 100.0f, 512.0f, 128.0f), new d("Textures/MenuTextures/panel/biaopan_bg", 162.0f, 106.0f, 256.0f, 128.0f), new d("Textures/MenuTextures/panel/kedu", 32.0f, 16.0f, 32.0f, 16.0f, 1, 4), new d("Textures/MenuTextures/panel/pause_a", 76.0f, 63.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/pause_b", 76.0f, 63.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/pointer", 12.0f, 33.0f, 16.0f, 64.0f), new d("Textures/MenuTextures/panel/shuzi_01", 190.0f, 28.0f, 256.0f, 32.0f, 1, 10), new d("Textures/MenuTextures/panel/shuzi_02", 216.0f, 24.0f, 256.0f, 32.0f, 1, 12), new d("Textures/MenuTextures/panel/shuzi_03", 180.0f, 24.0f, 256.0f, 32.0f, 1, 10), new d("Textures/MenuTextures/panel/scores", 87.0f, 35.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/time", 87.0f, 35.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/n_10", 66.0f, 45.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/n_20", 66.0f, 45.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/n_30", 66.0f, 45.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/n_40", 66.0f, 45.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/n_50", 66.0f, 45.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/speeding_up", 377.0f, 55.0f, 512.0f, 64.0f), new d("Textures/MenuTextures/panel/warning_64_32", 64.0f, 32.0f, 64.0f, 32.0f), new d("Textures/MenuTextures/panel/face_bg", 83.0f, 124.0f, 128.0f, 128.0f), new d("Textures/MenuTextures/panel/face_normal", 83.0f, 97.0f, 128.0f, 128.0f), new d("Textures/MenuTextures/panel/face_panic", 83.0f, 97.0f, 128.0f, 128.0f), new d("Textures/MenuTextures/panel/face_smile", 83.0f, 97.0f, 128.0f, 128.0f), new d("Textures/MenuTextures/panel/ha01", 83.0f, 36.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/ha02", 83.0f, 36.0f, 128.0f, 64.0f), new d("Textures/MenuTextures/panel/ha03", 83.0f, 36.0f, 128.0f, 64.0f), new d(1, "Textures/MenuTextures/panel/L2.png", 139.0f, 29.0f, 256.0f, 32.0f), new d(1, "Textures/MenuTextures/panel/L3.png", 139.0f, 29.0f, 256.0f, 32.0f), new d(1, "Textures/MenuTextures/panel/L4.png", 139.0f, 29.0f, 256.0f, 32.0f), new d(1, "Textures/MenuTextures/panel/L5.png", 139.0f, 29.0f, 256.0f, 32.0f), new d(1, "Textures/MenuTextures/panel/L5_3.png", 139.0f, 29.0f, 256.0f, 32.0f), new d(1, "Textures/MenuTextures/panel/boost_bg.png", 139.0f, 29.0f, 256.0f, 32.0f), new d(1, "Textures/MenuTextures/panel/boost.png", 87.0f, 35.0f, 128.0f, 64.0f), new d(1, "Textures/MenuTextures/panel/x1.png", 56.0f, 46.0f, 64.0f, 64.0f), new d(1, "Textures/MenuTextures/panel/x2.png", 56.0f, 46.0f, 64.0f, 64.0f), new d(1, "Textures/MenuTextures/panel/x3.png", 56.0f, 46.0f, 64.0f, 64.0f), new d(1, "Textures/MenuTextures/panel/x4.png", 56.0f, 46.0f, 64.0f, 64.0f), new d(1, "Textures/MenuTextures/panel/x5.png", 56.0f, 46.0f, 64.0f, 64.0f)});
        this.d.c();
        this.e.a(new d[]{new d("Textures/MenuTextures/panel/pause/pause_bg", 434.0f, 296.0f, 512.0f, 512.0f), new d("Textures/MenuTextures/panel/pause/menu_a", 130.0f, 118.0f, 256.0f, 128.0f), new d("Textures/MenuTextures/panel/pause/menu_b", 130.0f, 118.0f, 256.0f, 128.0f), new d("Textures/MenuTextures/panel/pause/resume_a", 130.0f, 118.0f, 256.0f, 128.0f), new d("Textures/MenuTextures/panel/pause/resume_b", 130.0f, 118.0f, 256.0f, 128.0f), new d("Textures/MenuTextures/panel/pause/retry_a", 130.0f, 118.0f, 256.0f, 128.0f), new d("Textures/MenuTextures/panel/pause/retry_b", 130.0f, 118.0f, 256.0f, 128.0f)});
        this.e.c();
        this.f.a(new d[]{new d("Textures/MenuTextures/gameOver/gameover", 440.0f, 66.0f, 512.0f, 128.0f), new d("Textures/MenuTextures/gameOver/gameover_bg", 295.0f, 305.0f, 512.0f, 512.0f), new d("Textures/MenuTextures/gameOver/gameover_zi", 420.0f, 57.0f, 512.0f, 64.0f, 1, 10), new d("Textures/MenuTextures/gameOver/gameover_zi02", 260.0f, 38.0f, 512.0f, 64.0f, 1, 10), new d(1, "Textures/MenuTextures/gameOver/more2_a.png", 97.0f, 46.0f, 128.0f, 64.0f), new d(1, "Textures/MenuTextures/gameOver/more2_b.png", 97.0f, 46.0f, 128.0f, 64.0f), new d(1, "Textures/MenuTextures/gameOver/rate_a.png", 97.0f, 46.0f, 128.0f, 64.0f), new d(1, "Textures/MenuTextures/gameOver/rate_b.png", 97.0f, 46.0f, 128.0f, 64.0f), new d(1, "Textures/MenuTextures/gameOver/retry3_a.png", 259.0f, 63.0f, 512.0f, 64.0f), new d(1, "Textures/MenuTextures/gameOver/retry3_b.png", 259.0f, 63.0f, 512.0f, 64.0f), new d(1, "Textures/MenuTextures/gameOver/rock24h_a.png", 145.0f, 46.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/gameOver/rock24h_b.png", 145.0f, 46.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/gameOver/score2_a.png", 145.0f, 46.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/gameOver/score2_b.png", 145.0f, 46.0f, 256.0f, 64.0f), new d("Textures/MenuTextures/gameOver/share", 102.0f, 99.0f, 128.0f, 128.0f)});
        this.f.c();
        this.g.a(new d[]{new d("Textures/MenuTextures/tutorial/line", 190.0f, 61.0f, 256.0f, 64.0f), new d("Textures/MenuTextures/tutorial/phone", 72.0f, 116.0f, 128.0f, 128.0f), new d(1, "Textures/MenuTextures/tutorial/help_1.png", 280.0f, 44.0f, 512.0f, 64.0f), new d(1, "Textures/MenuTextures/tutorial/help_1_pointer.png", 94.0f, 94.0f, 128.0f, 128.0f), new d(1, "Textures/MenuTextures/tutorial/help_1_touch.png", 94.0f, 41.0f, 128.0f, 64.0f), new d(1, "Textures/MenuTextures/tutorial/help_2.png", 340.0f, 44.0f, 512.0f, 64.0f), new d(1, "Textures/MenuTextures/tutorial/help_3.png", 323.0f, 84.0f, 512.0f, 128.0f), new d(1, "Textures/MenuTextures/tutorial/b_start_a.png", 138.0f, 83.0f, 256.0f, 128.0f), new d(1, "Textures/MenuTextures/tutorial/b_start_b.png", 138.0f, 83.0f, 256.0f, 128.0f), new d(1, "Textures/MenuTextures/tutorial/help3_bg.png", 447.0f, 373.0f, 512.0f, 512.0f)});
        this.g.c();
        this.h.a(new d[]{new d(1, "Textures/MenuTextures/selectMoto/back_a.png", 81.0f, 67.0f, 128.0f, 128.0f), new d(1, "Textures/MenuTextures/selectMoto/back_b.png", 81.0f, 67.0f, 128.0f, 128.0f), new d(1, "Textures/MenuTextures/selectMoto/b_star_a.png", 246.0f, 64.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/selectMoto/b_star_b.png", 246.0f, 64.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/selectMoto/b_you.png", 61.0f, 61.0f, 64.0f, 64.0f), new d(1, "Textures/MenuTextures/selectMoto/b_zuo.png", 61.0f, 61.0f, 64.0f, 64.0f), new d(1, "Textures/MenuTextures/selectMoto/carduelis.png", 246.0f, 63.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/selectMoto/n_sapphire.png", 246.0f, 63.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/selectMoto/n_titan.png", 246.0f, 63.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/selectMoto/pts.png", 44.0f, 26.0f, 64.0f, 32.0f), new d(1, "Textures/MenuTextures/selectMoto/unlockby.png", 117.0f, 31.0f, 128.0f, 32.0f), new d("Textures/MenuTextures/selectMoto/select_num", 210.0f, 27.0f, 256.0f, 32.0f, 1, 10), new d(1, "Textures/MenuTextures/selectMoto/select.png", 480.0f, 142.0f, 512.0f, 256.0f), new d(1, "Textures/MenuTextures/selectMoto/myscore.png", 126.0f, 29.0f, 128.0f, 32.0f), new d(1, "Textures/MenuTextures/selectMoto/suo.png", 32.0f, 44.0f, 32.0f, 64.0f), new d(1, "Textures/MenuTextures/selectMoto/start_hui.png", 246.0f, 64.0f, 256.0f, 64.0f), new d(1, "Textures/MenuTextures/selectMoto/lit_pts.png", 27.0f, 16.0f, 32.0f, 16.0f), new d("Textures/MenuTextures/selectMoto/lit_num", 126.0f, 16.0f, 128.0f, 16.0f, 1, 10)});
        this.h.c();
    }

    public void a(y yVar) {
        this.p.a(yVar);
    }

    public void a(String str) {
        h();
        i iVar = (i) this.l.get(str);
        if (iVar == null) {
            throw new Error("No Page: " + str);
        }
        if (((f) iVar).g != 1.0f) {
            this.t.b(((f) iVar).g);
            this.t.d();
        } else {
            this.t.e();
        }
        iVar.d();
        this.v = (f) iVar;
        this.m.add(iVar);
    }

    public void a(GL10 gl10) {
        a();
        b(gl10);
        int i2 = 0;
        while (true) {
            int i3 = i2;
            if (i3 >= this.m.size()) {
                gl10.glDisableClientState(32884);
                gl10.glDisable(3553);
                gl10.glDisableClientState(32888);
                return;
            }
            ((i) this.m.get(i3)).a(gl10);
            i2 = i3 + 1;
        }
    }

    public boolean a(float f, float f2) {
        float a = f - (com.droidhen.game.racingengine.a.c.a() / 2);
        float b = (-1.0f) * (f2 - (com.droidhen.game.racingengine.a.c.b() / 2));
        for (int i2 = 0; i2 < this.m.size(); i2++) {
            if (((i) this.m.get(i2)).b(a, b)) {
                return true;
            }
        }
        return false;
    }

    public void b() {
        if (this.n) {
            this.u = new com.droidhen.game.racingmototerLHL.a.a.a();
            this.u.y = "loading_panel";
            this.u.z = false;
            this.p = new k();
            this.p.y = "game_panel";
            this.p.z = false;
            this.o = new aq();
            this.o.y = "game_pause_panel";
            this.o.g = 0.3f;
            this.o.z = false;
            this.q = new ag();
            this.q.y = "game_over";
            this.q.g = 0.5f;
            this.q.z = false;
            this.r = new j();
            this.r.y = "game_menu";
            this.r.z = false;
            this.s = new e();
            this.s.y = "select_moto";
            this.s.z = false;
            this.t = new b(this, 0.5f, 0.5f, 480.0f, 800.0f, -1);
            this.t.y = "alpha_bg";
            this.t.e();
            this.t.b(0.3f);
            this.t.j();
            this.t.y = "Alpha BG";
            this.t.a(com.droidhen.game.racingengine.a.j.FitScreen);
            this.l.clear();
            a(this.u);
            a(this.t);
            a(this.p);
            a(this.o);
            a(this.q);
            a(this.r);
            a(this.s);
            this.m.add(this.t);
            g();
            this.n = false;
        }
    }

    public boolean b(float f, float f2) {
        float a = f - (com.droidhen.game.racingengine.a.c.a() / 2);
        float b = (-1.0f) * (f2 - (com.droidhen.game.racingengine.a.c.b() / 2));
        for (int i2 = 0; i2 < this.m.size(); i2++) {
            if (((i) this.m.get(i2)).c(a, b)) {
                return true;
            }
        }
        return false;
    }

    public void c() {
        this.p.f();
    }

    public boolean c(float f, float f2) {
        float a = f - (com.droidhen.game.racingengine.a.c.a() / 2);
        float b = (-1.0f) * (f2 - (com.droidhen.game.racingengine.a.c.b() / 2));
        for (int i2 = 0; i2 < this.m.size(); i2++) {
            if (((i) this.m.get(i2)).d(a, b)) {
                return true;
            }
        }
        return false;
    }

    public void d() {
        this.p.g();
    }

    public void e() {
    }

    public void f() {
        i = true;
        if (ae.e) {
            return;
        }
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.PAUSE) {
            h();
            this.t.b(this.o.g);
            this.t.d();
            this.o.j();
            this.o.d();
            this.m.add(this.o);
            this.v = this.o;
        } else if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.GAME_OVER) {
            h();
            this.t.b(this.q.g);
            this.t.d();
            this.q.j();
            this.q.d();
            this.q.z = true;
            this.q.i = true;
            this.m.add(this.q);
            this.v = this.q;
        }
        i = false;
    }

    public void g() {
        if (com.droidhen.game.racingengine.g.f.c(com.droidhen.game.racingengine.a.c.b() - this.j) <= 0.1f || com.droidhen.game.racingengine.g.f.c(com.droidhen.game.racingengine.a.c.a() - this.k) <= 0.1f) {
            Log.e("RacingMoto", "Resize Err: Screen size is not ready.");
            return;
        }
        Iterator it = this.l.entrySet().iterator();
        while (it.hasNext()) {
            i iVar = (i) ((Map.Entry) it.next()).getValue();
            if (iVar instanceof f) {
                ((f) iVar).a();
            }
        }
        com.droidhen.game.racingmototerLHL.global.f.b().z();
        this.j = com.droidhen.game.racingengine.a.c.b();
        this.k = com.droidhen.game.racingengine.a.c.a();
    }
}
