package com.droidhen.game.racingengine.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e extends d {
    public e(com.droidhen.game.racingengine.b.c.d dVar) {
        h();
        b(dVar);
        k(dVar.m, dVar.n);
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean b(float f, float f2) {
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        if (this.u) {
            this.N.position(0);
            this.N.put(this.q);
            this.M.position(0);
            this.M.put(this.r);
            this.O = com.droidhen.game.racingengine.f.a.a(new short[]{0, 1, 2, 2, 3});
            this.O.position(0);
            this.N.position(0);
            this.M.position(0);
            this.u = false;
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        this.z = true;
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void e() {
        this.z = false;
    }
}
