package com.droidhen.game.racingengine.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class c implements com.droidhen.game.racingengine.a.b.a {
    final /* synthetic */ f a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(f fVar) {
        this.a = fVar;
    }

    @Override // com.droidhen.game.racingengine.a.b.a
    public void a(com.droidhen.game.racingengine.a.b.c cVar) {
        this.a.z = false;
        this.a.i = true;
        this.a.h.b();
    }
}
