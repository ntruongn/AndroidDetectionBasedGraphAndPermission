package com.droidhen.api.promptclient.prompt;

import android.app.Activity;
import android.graphics.Color;
import android.view.Display;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class k {
    public static final int[] a = {2131230721, 2131230723, 2131230725};
    public static final int[] b = {2131230722, 2131230724, 2131230726};
    private Activity c;
    private float d;

    public k(Activity activity) {
        this.c = activity;
        Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
        float min = Math.min(Math.min(defaultDisplay.getWidth(), defaultDisplay.getHeight()) / 480.0f, Math.max(defaultDisplay.getWidth(), defaultDisplay.getHeight()) / 800.0f);
        this.d = min > 1.0f ? ((min - 1.0f) / 2.0f) + 1.0f : min;
    }

    private int a(int i) {
        return i > 0 ? (int) (i * this.d) : i;
    }

    private LinearLayout.LayoutParams a(int i, int i2, float f) {
        return new LinearLayout.LayoutParams(a(i), a(i2), f);
    }

    private void a(LinearLayout linearLayout, float f) {
        linearLayout.addView(new TextView(this.c), a(0, 0, f));
    }

    private void a(LinearLayout linearLayout, int i, int i2, int i3) {
        RelativeLayout relativeLayout = new RelativeLayout(this.c);
        linearLayout.addView(relativeLayout, new RelativeLayout.LayoutParams(a(i3), -1));
        ImageView imageView = new ImageView(this.c);
        imageView.setId(i);
        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        imageView.setImageResource(2130837545);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(a(72), a(72));
        layoutParams.addRule(10);
        layoutParams.addRule(14);
        relativeLayout.addView(imageView, layoutParams);
        TextView textView = new TextView(this.c);
        textView.setId(i2);
        textView.setGravity(1);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(a(i3 - 10), a(60));
        textView.setTextSize(a(15));
        textView.setTextColor(Color.argb(255, 34, 187, 231));
        layoutParams2.addRule(3, i);
        layoutParams2.addRule(14);
        layoutParams2.setMargins(0, a(10), 0, 0);
        relativeLayout.addView(textView, layoutParams2);
    }

    private void a(RelativeLayout relativeLayout) {
        relativeLayout.setBackgroundResource(2130837541);
        ImageView imageView = new ImageView(this.c);
        imageView.setId(2131230720);
        imageView.setBackgroundResource(2130837542);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(a(57), a(57));
        layoutParams.setMargins(0, a(9), a(7), 0);
        layoutParams.addRule(10);
        layoutParams.addRule(11);
        relativeLayout.addView(imageView, layoutParams);
        LinearLayout linearLayout = new LinearLayout(this.c);
        linearLayout.setOrientation(0);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(a(330), a(140));
        layoutParams2.setMargins(0, a(90), 0, 0);
        layoutParams2.addRule(14);
        relativeLayout.addView(linearLayout, layoutParams2);
        for (int i = 0; i < a.length; i++) {
            a(linearLayout, a[i], b[i], 110);
        }
    }

    public LinearLayout a() {
        LinearLayout linearLayout = new LinearLayout(this.c);
        linearLayout.setOrientation(0);
        a(linearLayout, 2.0f);
        LinearLayout linearLayout2 = new LinearLayout(this.c);
        linearLayout2.setOrientation(1);
        linearLayout.addView(linearLayout2, a(380, -1, 0.0f));
        a(linearLayout, 1.0f);
        a(linearLayout2, 1.0f);
        RelativeLayout relativeLayout = new RelativeLayout(this.c);
        linearLayout2.addView(relativeLayout, a(380, 254, 0.0f));
        a(relativeLayout);
        a(linearLayout2, 1.0f);
        return linearLayout;
    }
}
