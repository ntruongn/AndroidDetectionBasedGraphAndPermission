package com.droidhen.game.racingengine.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class g {
    public static float[] a(com.droidhen.game.racingengine.b.c.d dVar) {
        int i = dVar.o;
        int i2 = dVar.p;
        float[] fArr = new float[i * i2 * 8];
        float b = dVar.b() / dVar.j;
        float a = dVar.a() / dVar.i;
        int i3 = 0;
        int i4 = 0;
        float f = 0.0f;
        while (i3 < i) {
            float f2 = f + b;
            int i5 = i4;
            float f3 = 0.0f;
            for (int i6 = 0; i6 < i2; i6++) {
                fArr[i5 + 2] = f3;
                fArr[i5] = f3;
                fArr[i5 + 7] = f;
                fArr[i5 + 1] = f;
                f3 += a;
                fArr[i5 + 6] = f3;
                fArr[i5 + 4] = f3;
                fArr[i5 + 5] = f2;
                fArr[i5 + 3] = f2;
                i5 += 8;
            }
            i3++;
            i4 = i5;
            f = f2;
        }
        return fArr;
    }
}
