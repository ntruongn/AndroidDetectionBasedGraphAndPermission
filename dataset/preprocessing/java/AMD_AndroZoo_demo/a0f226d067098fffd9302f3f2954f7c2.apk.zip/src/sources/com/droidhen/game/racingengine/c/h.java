package com.droidhen.game.racingengine.c;

import android.util.Log;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class h {
    protected String a;
    protected long b;
    protected int c;
    protected int d;
    protected h e = null;
    protected ArrayList f = new ArrayList();
    public int[] g = null;
    public float[] h = null;
    public com.droidhen.game.racingengine.g.e i = new com.droidhen.game.racingengine.g.e();
    public com.droidhen.game.racingengine.g.e j = new com.droidhen.game.racingengine.g.e();
    protected com.droidhen.game.racingengine.g.c k = new com.droidhen.game.racingengine.g.c();
    protected com.droidhen.game.racingengine.g.c l = new com.droidhen.game.racingengine.g.c();
    protected com.droidhen.game.racingengine.g.c m = new com.droidhen.game.racingengine.g.c();
    protected com.droidhen.game.racingengine.g.c n = new com.droidhen.game.racingengine.g.c();
    protected com.droidhen.game.racingengine.g.c o = new com.droidhen.game.racingengine.g.c();
    protected d p = null;
    public com.droidhen.game.racingengine.g.e q = new com.droidhen.game.racingengine.g.e();
    public com.droidhen.game.racingengine.g.e r = new com.droidhen.game.racingengine.g.e();
    public com.droidhen.game.racingengine.g.e s = null;
    private static com.droidhen.game.racingengine.g.e t = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e u = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e v = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e w = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e x = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e y = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e z = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e A = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e B = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e C = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e D = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e E = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e F = new com.droidhen.game.racingengine.g.e();

    public int a() {
        if (this.g != null) {
            return this.g.length;
        }
        return 0;
    }

    public com.droidhen.game.racingengine.g.e a(com.droidhen.game.racingengine.g.e eVar, com.droidhen.game.racingengine.g.e eVar2, com.droidhen.game.racingengine.g.e eVar3) {
        com.droidhen.game.racingengine.g.e.a(this.q, eVar, B);
        com.droidhen.game.racingengine.g.e.a(this.r.a(E), B, C);
        com.droidhen.game.racingengine.g.e.a(eVar2.a(F), c(), D);
        com.droidhen.game.racingengine.g.e.a(D, C, eVar3);
        return eVar3;
    }

    public void a(int i) {
        this.c = i;
    }

    public void a(long j) {
        this.b = j;
    }

    public void a(h hVar) {
        this.f.add(hVar);
    }

    public void a(com.droidhen.game.racingengine.g.c cVar) {
        this.k.a(cVar);
    }

    public void a(String str) {
        this.a = str;
    }

    public com.droidhen.game.racingengine.g.e b() {
        if (this.p != null) {
            com.droidhen.game.racingengine.g.e d = com.droidhen.game.racingengine.g.e.d();
            this.p.a(d);
            this.j.c(d);
            com.droidhen.game.racingengine.g.e.d(d);
        } else {
            t.a(this.n);
            u.a(this.o);
            v.a(this.l);
            z.a();
            y.a();
            com.droidhen.game.racingengine.g.e.a(t, v, y);
            com.droidhen.game.racingengine.g.e.a(y, u, z);
            x.b(this.k);
            w.c(this.m);
            y.a();
            com.droidhen.game.racingengine.g.e.a(x, z, y);
            A.a();
            com.droidhen.game.racingengine.g.e.a(y, w, A);
            this.j.c(A);
        }
        return this.j;
    }

    public void b(int i) {
        this.d = i;
    }

    public void b(h hVar) {
        this.e = hVar;
    }

    public void b(com.droidhen.game.racingengine.g.c cVar) {
        this.l.a(cVar);
    }

    public com.droidhen.game.racingengine.g.e c() {
        if (this.e != null) {
            com.droidhen.game.racingengine.g.e.a(this.e.i, b(), this.i);
        } else {
            this.i.c(b());
        }
        if (com.droidhen.game.racingengine.a.g && !com.droidhen.game.racingengine.g.e.b(this.i, this.s)) {
            Log.e("RacingEngine", "Skeleton Test: Test False: " + this.a);
        }
        return this.i;
    }

    public void c(com.droidhen.game.racingengine.g.c cVar) {
        this.m.a(cVar);
    }

    public void d(com.droidhen.game.racingengine.g.c cVar) {
        this.n.a(cVar);
    }

    public void e(com.droidhen.game.racingengine.g.c cVar) {
        this.o.a(cVar);
    }
}
