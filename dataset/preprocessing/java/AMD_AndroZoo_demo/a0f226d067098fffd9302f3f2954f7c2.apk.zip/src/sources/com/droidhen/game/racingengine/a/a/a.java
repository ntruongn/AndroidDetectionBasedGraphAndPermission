package com.droidhen.game.racingengine.a.a;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a extends d {
    protected com.droidhen.game.racingengine.b.c.d l;
    public int f = 0;
    public int g = 0;
    public float h = 0.0f;
    public float i = 0.0f;
    public float j = 0.0f;
    public float k = 0.0f;
    float[] m = new float[2];

    public a(com.droidhen.game.racingengine.b.c.d dVar, float f, float f2, float f3, int i) {
        a(dVar, f, f2, f3, i);
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        float min = Math.min(com.droidhen.game.racingengine.a.c.a() / this.R, com.droidhen.game.racingengine.a.c.b() / this.S);
        this.E *= min;
        this.F *= min;
        this.G.a *= min;
        this.G.b *= min;
        this.j *= min;
        this.k = min * this.k;
        a(this.l, this.j, this.k, this.h, this.f);
        this.S = com.droidhen.game.racingengine.a.c.a();
        this.R = com.droidhen.game.racingengine.a.c.b();
    }

    public void a(com.droidhen.game.racingengine.b.c.d dVar, float f, float f2, float f3, int i) {
        this.f = i;
        this.h = f3;
        this.j = f;
        this.k = f2;
        this.l = dVar;
        this.C = dVar;
        b(this.f);
        short[] sArr = new short[6];
        this.N.position(0);
        short s = 0;
        float f4 = 0.0f;
        for (int i2 = 0; i2 < this.f; i2++) {
            this.q[0] = (-com.droidhen.game.racingengine.g.f.a(f4 * 0.017453292f)) * f;
            this.q[1] = com.droidhen.game.racingengine.g.f.b(f4 * 0.017453292f) * f;
            this.q[9] = (-com.droidhen.game.racingengine.g.f.a(f4 * 0.017453292f)) * f2;
            this.q[10] = com.droidhen.game.racingengine.g.f.b(f4 * 0.017453292f) * f2;
            this.q[3] = (-com.droidhen.game.racingengine.g.f.a((f4 + f3) * 0.017453292f)) * f;
            this.q[4] = com.droidhen.game.racingengine.g.f.b((f4 + f3) * 0.017453292f) * f;
            this.q[6] = (-com.droidhen.game.racingengine.g.f.a((f4 + f3) * 0.017453292f)) * f2;
            this.q[7] = com.droidhen.game.racingengine.g.f.b((f4 + f3) * 0.017453292f) * f2;
            this.N.put(this.q);
            f4 += this.i + f3;
            for (int i3 = 0; i3 < 6; i3++) {
                sArr[i3] = (short) (o[i3] + s);
            }
            this.O.put(sArr);
            s = (short) (s + 4);
        }
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        boolean z;
        if (this.B != 1.0f) {
            z = true;
            gl10.glColor4f(1.0f, 1.0f, 1.0f, this.B);
        } else {
            z = false;
        }
        gl10.glBindTexture(3553, this.C.a);
        gl10.glPushMatrix();
        gl10.glTranslatef(this.G.a, this.G.b, 0.0f);
        gl10.glTranslatef(this.f0I, this.J, 0.0f);
        this.M.position(0);
        gl10.glTexCoordPointer(2, 5126, 0, this.M);
        this.N.position(0);
        gl10.glVertexPointer(3, 5126, 0, this.N);
        this.O.position(0);
        gl10.glDrawElements(4, this.D, 5123, this.O);
        gl10.glPopMatrix();
        if (z) {
            gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        }
    }

    public void a(int[] iArr, int i, int i2) {
        this.M.position(0);
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            this.m[0] = this.l.q[(iArr[i4] * 8) + 6];
            this.m[1] = this.l.q[(iArr[i4] * 8) + 7];
            this.M.put(this.m);
            this.M.put(this.l.q, iArr[i4] * 8, 6);
        }
        this.M.position(0);
        this.D = i2 * 6;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean b(float f, float f2) {
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void e() {
    }
}
