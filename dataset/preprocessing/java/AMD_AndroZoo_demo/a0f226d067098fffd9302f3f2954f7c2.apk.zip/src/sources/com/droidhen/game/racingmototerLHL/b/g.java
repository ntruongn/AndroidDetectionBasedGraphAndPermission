package com.droidhen.game.racingmototerLHL.b;

import com.droidhen.game.racingmototerLHL.GameActivity;
import com.droidhen.game.racingmototerLHL.a.a.ae;
import com.droidhen.game.racingmototerLHL.a.a.af;
import java.util.ArrayList;
import java.util.Arrays;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class g {
    public static float c;
    private com.droidhen.game.racingengine.j.a.b g;
    private n h;
    private float u;
    private static float m = 3000.0f;
    private static float n = -800.0f;
    private static float o = 400.0f;
    private static float p = 500.0f;
    private static float q = -200.0f;
    private static float r = -1400.0f;
    private static float s = 800.0f;
    private static float t = 300.0f;
    public static float a = 122.0f;
    public static float b = 3000.0f;
    public static float[] e = new float[3];
    private static String v = "RacingMoto.CarManager";
    private c l = new c(this);
    public int[] d = new int[3];
    int f = 0;
    private ArrayList i = new ArrayList();
    private ArrayList j = new ArrayList();
    private ArrayList k = new ArrayList();

    public g(com.droidhen.game.racingengine.j.a.b bVar) {
        this.g = bVar;
    }

    private float a(float f) {
        return -f;
    }

    private void a(k kVar, k kVar2, int i, int i2) {
        float f = kVar.d.b.b.b;
        float f2 = kVar2.d.b.b.b;
        if (kVar.g() == kVar2.g() || com.droidhen.game.racingengine.g.f.c(f - f2) >= p) {
            return;
        }
        int i3 = 0;
        while (true) {
            int i4 = i3;
            if (i4 >= this.j.size()) {
                return;
            }
            if (i4 != i && i4 != i2) {
                k kVar3 = (k) this.j.get(i4);
                float f3 = kVar3.d.b.b.b;
                if (kVar3.g() != kVar.g() && kVar3.g() != kVar2.g() && com.droidhen.game.racingengine.g.f.c(f3 - f) < p && com.droidhen.game.racingengine.g.f.c(f3 - f2) < p) {
                    if (f > f2 && f > f3) {
                        kVar.d();
                    } else if (f2 > f3) {
                        kVar2.d();
                    } else {
                        kVar3.d();
                    }
                }
            }
            i3 = i4 + 1;
        }
    }

    private void b(k kVar) {
        kVar.a.b = false;
        kVar.d.a(false);
        kVar.c(h.f);
        do {
            kVar.a(m.FRONT);
            kVar.d.a();
        } while (this.g.a(kVar.d));
        kVar.d.a(true);
        kVar.a.b = true;
    }

    private void c(k kVar) {
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.c);
        com.droidhen.game.racingmototerLHL.global.f.b().a(100);
        this.l.a();
        com.droidhen.game.racingmototerLHL.global.f.a().a(kVar.g(), (com.droidhen.game.racingmototerLHL.f.e + 1) * 10);
    }

    private void d(k kVar) {
        if (com.droidhen.game.racingengine.g.f.a() < c) {
            if (kVar.g() == 0) {
                if (com.droidhen.game.racingengine.g.f.a() > 0.5f) {
                    kVar.c();
                }
            } else if (kVar.g() == 2) {
                if (com.droidhen.game.racingengine.g.f.a() > 0.5f) {
                    kVar.b();
                }
            } else if (com.droidhen.game.racingengine.g.f.a() >= 0.5f) {
                kVar.c();
            } else {
                kVar.b();
            }
        }
    }

    private void e() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.j.size()) {
                break;
            }
            ((k) this.j.get(i2)).a(m.INIT, true);
            i = i2 + 1;
        }
        this.g.a();
        this.f++;
        if (this.f <= 20 && this.g.b()) {
            e();
        }
    }

    private void f() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.j.size()) {
                return;
            }
            k kVar = (k) this.j.get(i2);
            int i3 = i2 + 1;
            while (true) {
                int i4 = i3;
                if (i4 >= this.j.size()) {
                    break;
                }
                a(kVar, (k) this.j.get(i4), i2, i4);
                i3 = i4 + 1;
            }
            i = i2 + 1;
        }
    }

    public synchronized k a(d dVar) {
        k clone;
        clone = ((k) this.i.get(dVar.ordinal())).clone();
        clone.a(this.g);
        this.j.add(clone);
        this.h.a(clone.a);
        int[] iArr = this.d;
        int ordinal = dVar.ordinal();
        iArr[ordinal] = iArr[ordinal] + 1;
        return clone;
    }

    public void a() {
        b();
        this.l.b();
        this.f = 0;
    }

    public void a(com.droidhen.game.racingengine.e.a.a aVar, n nVar) {
        this.h = nVar;
        this.h.a(this.j);
        com.droidhen.game.racingengine.b.a b2 = aVar.b("suv");
        com.droidhen.game.racingengine.b.g a2 = b2.a("suv");
        b2.d.remove(a2);
        b2.d.add(0, a2);
        com.droidhen.game.racingengine.b.g a3 = b2.a("Plane03");
        b2.d.remove(a3);
        b2.d.add(0, a3);
        k kVar = new k(b2, a2);
        kVar.b = d.SUV;
        kVar.e = new com.droidhen.game.racingengine.b.c.d[]{com.droidhen.game.racingengine.a.e.a("suv_lan"), com.droidhen.game.racingengine.a.e.a("suv_lv"), com.droidhen.game.racingengine.a.e.a("suv_zi")};
        this.i.add(kVar);
        com.droidhen.game.racingengine.b.a b3 = aVar.b("sanxiangche");
        com.droidhen.game.racingengine.b.g a4 = b3.a("sanxiangche");
        b3.d.remove(a4);
        b3.d.add(0, a4);
        com.droidhen.game.racingengine.b.g a5 = b3.a("Plane02");
        b3.d.remove(a5);
        b3.d.add(0, a5);
        k kVar2 = new k(b3, a4);
        kVar2.b = d.Sedan;
        kVar2.e = new com.droidhen.game.racingengine.b.c.d[]{com.droidhen.game.racingengine.a.e.a("sanxiangche_bai"), com.droidhen.game.racingengine.a.e.a("sanxiangche_hei"), com.droidhen.game.racingengine.a.e.a("sanxiangche_hong")};
        this.i.add(kVar2);
        com.droidhen.game.racingengine.b.a b4 = aVar.b("pika");
        com.droidhen.game.racingengine.b.g a6 = b4.a("Pickup");
        a6.p = true;
        b4.d.remove(a6);
        b4.d.add(0, a6);
        com.droidhen.game.racingengine.b.g a7 = b4.a("Plane01");
        b4.d.remove(a7);
        b4.d.add(0, a7);
        k kVar3 = new k(b4, a6);
        kVar3.b = d.Pickup;
        kVar3.e = new com.droidhen.game.racingengine.b.c.d[]{com.droidhen.game.racingengine.a.e.a("Pickup_cheng"), com.droidhen.game.racingengine.a.e.a("Pickup_huang"), com.droidhen.game.racingengine.a.e.a("Pickup_qing")};
        this.i.add(kVar3);
    }

    public void a(d dVar, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            a(dVar);
        }
    }

    public synchronized void a(k kVar) {
        this.j.remove(kVar);
        this.h.b(kVar.a);
        this.g.c(kVar.d);
        int[] iArr = this.d;
        int ordinal = kVar.b.ordinal();
        iArr[ordinal] = iArr[ordinal] - 1;
    }

    public synchronized void a(com.droidhen.game.racingmototerLHL.global.a aVar) {
        Arrays.fill(e, 0.0f);
        for (int i = 0; i < aVar.a.length; i++) {
            if (aVar.a[i] > this.d[i]) {
                a(d.valuesCustom()[i], aVar.a[i] - this.d[i]);
            } else if (aVar.a[i] != this.d[i]) {
                b(d.valuesCustom()[i], this.d[i] - aVar.a[i]);
            }
        }
        if (aVar.a.length < this.d.length) {
            for (int length = aVar.a.length; length < this.d.length; length++) {
                b(d.valuesCustom()[length], this.d[length]);
            }
        }
        c = aVar.b;
    }

    public synchronized void b() {
        for (int size = this.j.size() - 1; size >= 0; size--) {
            k kVar = (k) this.j.get(size);
            if (kVar.j) {
                a(kVar);
            } else {
                kVar.c(h.f);
                kVar.a.b = false;
            }
        }
        this.g.a(false);
        e();
        this.g.a(true);
        for (int i = 0; i < this.j.size(); i++) {
            ((k) this.j.get(i)).a.b = true;
        }
    }

    public void b(d dVar) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.j.size()) {
                return;
            }
            k kVar = (k) this.j.get(i2);
            if (kVar.b == dVar && !kVar.j) {
                kVar.j = true;
                return;
            }
            i = i2 + 1;
        }
    }

    public void b(d dVar, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            b(dVar);
        }
    }

    public void c() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.j.size()) {
                d();
                return;
            }
            k kVar = (k) this.j.get(i2);
            kVar.a();
            if (af.d > 10000 && com.droidhen.game.racingmototerLHL.f.e < 5) {
                kVar.e();
            }
            i = i2 + 1;
        }
    }

    public synchronized void d() {
        this.u = a(com.droidhen.game.racingmototerLHL.global.f.d);
        float f = 100.0f * ((-com.droidhen.game.racingmototerLHL.global.f.b().d.b.b) / 3.6f);
        if (com.droidhen.game.racingmototerLHL.global.f.b().o) {
            for (int i = 0; i < this.j.size(); i++) {
                k kVar = (k) this.j.get(i);
                float f2 = kVar.d.b.b.b;
                if (f2 - this.u > q) {
                    if (!kVar.c) {
                        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.c);
                        com.droidhen.game.racingmototerLHL.global.f.b().a(100);
                        this.l.a();
                        com.droidhen.game.racingmototerLHL.global.f.a().a(kVar.g(), (com.droidhen.game.racingmototerLHL.f.e + 1) * 10);
                        kVar.c = true;
                    }
                    if (f2 - this.u > 500.0f) {
                        ae.d = true;
                    }
                }
            }
        } else {
            for (int size = this.j.size() - 1; size >= 0; size--) {
                k kVar2 = (k) this.j.get(size);
                float f3 = this.u - kVar2.d.b.b.b;
                if (f3 <= n || f3 >= m) {
                    kVar2.a.b = false;
                } else {
                    kVar2.a.b = true;
                }
                if (f3 < q && !kVar2.c) {
                    c(kVar2);
                    kVar2.c = true;
                }
                if (f3 < r) {
                    if (kVar2.j) {
                        a(kVar2);
                    } else {
                        b(kVar2);
                    }
                }
                if (!kVar2.i && f3 < s + (0.3f * f) && f3 > t + (0.1f * f)) {
                    d(kVar2);
                    kVar2.i = true;
                }
            }
            f();
        }
    }
}
