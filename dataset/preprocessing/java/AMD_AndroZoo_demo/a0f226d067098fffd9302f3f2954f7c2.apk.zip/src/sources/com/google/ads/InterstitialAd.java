package com.google.ads;

import android.app.Activity;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class InterstitialAd implements Ad {
    private defpackage.d a;

    public InterstitialAd(Activity activity, String adUnitId) {
        this.a = new defpackage.d(activity, this, null, adUnitId);
    }

    @Override // com.google.ads.Ad
    public boolean isReady() {
        return this.a.o();
    }

    @Override // com.google.ads.Ad
    public void loadAd(AdRequest adRequest) {
        this.a.a(adRequest);
    }

    @Override // com.google.ads.Ad
    public void setAdListener(AdListener adListener) {
        this.a.a(adListener);
    }

    public void show() {
        if (!isReady()) {
            com.google.ads.util.a.c("Cannot show interstitial because it is not loaded and ready.");
            return;
        }
        this.a.x();
        this.a.u();
        AdActivity.launchAdActivity(this.a, new defpackage.e("interstitial"));
    }

    @Override // com.google.ads.Ad
    public void stopLoading() {
        this.a.y();
    }
}
