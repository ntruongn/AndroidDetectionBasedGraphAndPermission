package com.droidhen.game.racingengine.b.b;

import android.util.Log;
import java.nio.IntBuffer;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.opengles.GL11;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    private static float a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static int h;
    private static int i;
    private static int j;
    private static int k;
    private static int l;

    public static void a(GL10 gl10) {
        if (gl10 instanceof GL11) {
            a = 1.1f;
        } else {
            a = 1.0f;
        }
        IntBuffer allocate = IntBuffer.allocate(1);
        gl10.glGetIntegerv(34018, allocate);
        b = allocate.get(0);
        IntBuffer allocate2 = IntBuffer.allocate(1);
        gl10.glGetIntegerv(3379, allocate2);
        c = allocate2.get(0);
        IntBuffer allocate3 = IntBuffer.allocate(2);
        gl10.glGetIntegerv(33901, allocate3);
        d = allocate3.get(0);
        e = allocate3.get(1);
        IntBuffer allocate4 = IntBuffer.allocate(2);
        gl10.glGetIntegerv(2834, allocate4);
        f = allocate4.get(0);
        g = allocate4.get(1);
        IntBuffer allocate5 = IntBuffer.allocate(2);
        gl10.glGetIntegerv(33902, allocate5);
        h = allocate5.get(0);
        i = allocate5.get(1);
        IntBuffer allocate6 = IntBuffer.allocate(2);
        gl10.glGetIntegerv(2850, allocate6);
        j = allocate6.get(0);
        k = allocate6.get(1);
        IntBuffer allocate7 = IntBuffer.allocate(1);
        gl10.glGetIntegerv(3377, allocate7);
        l = allocate7.get(0);
        Log.v("RacingEngine", "RenderCaps - openGLVersion: " + a);
        Log.v("RacingEngine", "RenderCaps - maxTextureUnits: " + b);
        Log.v("RacingEngine", "RenderCaps - maxTextureSize: " + c);
        Log.v("RacingEngine", "RenderCaps - maxLights: " + l);
    }
}
