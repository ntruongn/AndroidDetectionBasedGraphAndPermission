package com.droidhen.game.racingmototerLHL.b;

import java.io.IOException;
import java.util.ArrayList;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class j implements com.droidhen.game.racingengine.i.a {
    public static j a = null;
    private static int h = 0;
    private ArrayList e = new ArrayList();
    private com.droidhen.game.racingengine.b.a f = null;
    private com.droidhen.game.racingengine.b.a g = null;
    com.droidhen.game.racingengine.b.g b = null;
    float c = 0.0f;
    public com.droidhen.game.racingengine.b.a[] d = new com.droidhen.game.racingengine.b.a[l.e];

    private j() {
        d();
        com.droidhen.game.racingmototerLHL.global.f.b().n().a(this);
        g();
    }

    public static j a() {
        if (a == null) {
            a = new j();
        }
        return a;
    }

    private com.droidhen.game.racingengine.b.a b(int i) {
        com.droidhen.game.racingengine.b.a b;
        com.droidhen.game.racingengine.e.a.a aVar = null;
        i iVar = l.d[i];
        if (this.d[i] != null) {
            b = this.d[i];
        } else {
            try {
                aVar = new com.droidhen.game.racingengine.e.a.a(com.droidhen.game.racingengine.a.d.open(iVar.a));
            } catch (IOException e) {
                e.printStackTrace();
            }
            b = aVar.b(iVar.d);
        }
        com.droidhen.game.racingengine.b.g a2 = b.a(iVar.f);
        com.droidhen.game.racingengine.b.g a3 = b.a(iVar.e);
        com.droidhen.game.racingengine.b.g a4 = b.a(iVar.g);
        this.b = b.a(iVar.h);
        a4.i = true;
        a2.i = false;
        b.c = true;
        a3.p = true;
        a2.a(com.droidhen.game.racingengine.a.e.a(iVar.k[0]));
        this.d[i] = b;
        return b;
    }

    public static j c() {
        if (a == null) {
            a = new j();
        }
        com.droidhen.game.racingmototerLHL.global.f.b().n().a(a);
        a.g();
        a.a(h);
        return a;
    }

    public static int f() {
        return h;
    }

    private void g() {
        com.droidhen.game.racingengine.b.a.b bVar = new com.droidhen.game.racingengine.b.a.b(new com.droidhen.game.racingengine.g.c(0.0f, 0.0f, (-11.0f) * 2.0f), new com.droidhen.game.racingengine.g.c(0.0f, 73.0f * 2.0f, 2.0f * 176.0f));
        bVar.c.a(-1.0f);
        bVar.e = 44.0f;
        bVar.f = 10.0f;
        bVar.g = 1200.0f;
        com.droidhen.game.racingmototerLHL.global.f.b().n().a(bVar);
    }

    public void a(int i) {
        this.f = b(i);
        this.f.o.a();
        this.f.m.c = 0.0f;
        h = i;
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void a(GL10 gl10) {
        b();
        gl10.glEnable(2929);
        gl10.glEnable(3008);
        gl10.glClearDepthf(1.0f);
        gl10.glClear(3414);
        gl10.glDepthMask(true);
        gl10.glDisable(2884);
        gl10.glPushMatrix();
        gl10.glScalef(1.0f, -1.0f, 1.0f);
        this.b.i = false;
        gl10.glCullFace(1028);
        this.f.a(gl10);
        gl10.glCullFace(1029);
        this.b.i = true;
        gl10.glPopMatrix();
        gl10.glDisable(2929);
        gl10.glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
        gl10.glBlendFunc(770, 771);
        this.g.a(gl10);
        gl10.glBlendFunc(1, 771);
        gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        gl10.glEnable(2929);
        this.f.a(gl10);
        gl10.glDisable(2929);
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void b() {
        this.c += com.droidhen.game.racingengine.a.b.g().b() * 40.0f;
        this.f.m.c = this.c;
    }

    public void d() {
        com.droidhen.game.racingengine.e.a.a aVar = null;
        com.droidhen.game.racingengine.b.a b = b(h);
        try {
            aVar = new com.droidhen.game.racingengine.e.a.a(com.droidhen.game.racingengine.a.d.open("Models/xuanchechangjing.data"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        com.droidhen.game.racingengine.b.a b2 = aVar.b("Group_xuanchebeijing");
        this.f = b;
        this.g = b2;
    }

    public com.droidhen.game.racingengine.b.a e() {
        return this.f;
    }
}
