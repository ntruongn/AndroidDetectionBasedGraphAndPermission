package com.droidhen.game.racingengine;

import android.opengl.GLSurfaceView;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d extends c implements GLSurfaceView.Renderer {
    protected BaseActivity a;
    protected GLSurfaceView b;
    protected int c;
    protected int d;

    public d(BaseActivity baseActivity, GLSurfaceView gLSurfaceView) {
        this.a = baseActivity;
        this.b = gLSurfaceView;
        this.b.setRenderer(this);
        this.b.requestFocus();
        this.b.setFocusableInTouchMode(true);
    }

    @Override // com.droidhen.game.racingengine.c
    public int a() {
        return this.c;
    }

    @Override // com.droidhen.game.racingengine.c
    public int b() {
        return this.d;
    }

    public void c() {
        this.b.onResume();
    }

    public void d() {
        this.b.onPause();
    }

    @Override // android.opengl.GLSurfaceView.Renderer
    public void onDrawFrame(GL10 gl10) {
        a.e.c(gl10);
        this.a.b.a(gl10);
    }

    @Override // android.opengl.GLSurfaceView.Renderer
    public void onSurfaceChanged(GL10 gl10, int i, int i2) {
        a.f = gl10;
        gl10.glViewport(0, 0, i, i2);
        gl10.glMatrixMode(5889);
        gl10.glLoadIdentity();
        gl10.glMatrixMode(5888);
        gl10.glLoadIdentity();
        this.c = i;
        this.d = i2;
        this.a.b.i();
    }

    @Override // android.opengl.GLSurfaceView.Renderer
    public void onSurfaceCreated(GL10 gl10, EGLConfig eGLConfig) {
        a.f = gl10;
        a.e.a();
        this.a.b.h();
    }
}
