package com.droidhen.api.scoreclient.c;

import android.net.Uri;
import android.provider.BaseColumns;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class a implements BaseColumns {
    public static final Uri a = Uri.parse("content://" + b.a + "/score");
}
