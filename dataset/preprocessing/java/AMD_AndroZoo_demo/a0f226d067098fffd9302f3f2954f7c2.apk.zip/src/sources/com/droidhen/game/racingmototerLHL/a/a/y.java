package com.droidhen.game.racingmototerLHL.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public enum y {
    Normal,
    Panic,
    Smile;

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static y[] valuesCustom() {
        y[] valuesCustom = values();
        int length = valuesCustom.length;
        y[] yVarArr = new y[length];
        System.arraycopy(valuesCustom, 0, yVarArr, 0, length);
        return yVarArr;
    }
}
