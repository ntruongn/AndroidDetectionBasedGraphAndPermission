package com.droidhen.game.racingmototerLHL;

import android.util.Log;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e extends com.droidhen.game.racingengine.j.a.a {
    final /* synthetic */ f e;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(f fVar, float f, float f2, float f3, float f4) {
        super(f, f2, f3, f4);
        this.e = fVar;
    }

    @Override // com.droidhen.game.racingengine.j.a.a
    public void a() {
        com.droidhen.game.racingengine.g.c d = com.droidhen.game.racingengine.g.c.d();
        this.a.a(this.e.d.a.o.d(d));
        com.droidhen.game.racingengine.g.c.f(d);
        this.b.a(this.e.d.a.o);
    }

    @Override // com.droidhen.game.racingengine.j.a.a
    public void a(com.droidhen.game.racingengine.j.a.a aVar, com.droidhen.game.racingengine.j.a.a aVar2) {
        if (aVar2 != null || this.e.u() == com.droidhen.game.racingmototerLHL.global.e.CRASH) {
            return;
        }
        com.droidhen.game.racingmototerLHL.global.f.a().d();
    }

    @Override // com.droidhen.game.racingengine.j.a.a
    public void b(com.droidhen.game.racingengine.j.a.a aVar, com.droidhen.game.racingengine.j.a.a aVar2) {
        com.droidhen.game.racingmototerLHL.b.e eVar;
        com.droidhen.game.racingmototerLHL.b.e eVar2;
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() != com.droidhen.game.racingmototerLHL.global.e.CRASH) {
            if (aVar2 == null) {
                this.e.d.f();
                eVar2 = this.e.y;
                eVar2.c();
            } else {
                if (!aVar2.c() || !aVar2.b()) {
                    Log.e("RacingMoto", "unexpected collids.");
                    return;
                }
                this.e.d.f();
                eVar = this.e.y;
                eVar.c();
            }
        }
    }
}
