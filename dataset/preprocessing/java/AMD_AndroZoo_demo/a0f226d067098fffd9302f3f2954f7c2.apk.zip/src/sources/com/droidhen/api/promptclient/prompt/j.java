package com.droidhen.api.promptclient.prompt;

import android.content.Context;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class j extends Thread {
    private final /* synthetic */ Context a;
    private final /* synthetic */ a b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(Context context, a aVar) {
        this.a = context;
        this.b = aVar;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        l.b(this.a, this.b.a);
    }
}
