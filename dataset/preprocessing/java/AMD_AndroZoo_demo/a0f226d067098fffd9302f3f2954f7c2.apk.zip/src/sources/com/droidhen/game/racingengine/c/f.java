package com.droidhen.game.racingengine.c;

import java.util.Arrays;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f extends com.droidhen.game.racingengine.b.g {
    private int A;
    private boolean B;
    private boolean C;
    private float[] D;
    public a a;
    public e b;
    public boolean c;
    int d;
    private com.droidhen.game.racingengine.g.c w;
    private com.droidhen.game.racingengine.g.c x;
    private com.droidhen.game.racingengine.g.e[] y;
    private float[] z;

    public f(com.droidhen.game.racingengine.b.f fVar) {
        super(fVar);
        this.c = false;
        this.w = new com.droidhen.game.racingengine.g.c();
        this.x = new com.droidhen.game.racingengine.g.c();
        this.y = null;
        this.z = null;
        this.A = 0;
        this.B = true;
        this.C = false;
        this.D = new float[this.g.n.length * 3];
        this.d = 0;
        this.a = new a();
        this.b = new e();
    }

    public f(com.droidhen.game.racingengine.b.f fVar, a aVar, e eVar) {
        super(fVar);
        this.c = false;
        this.w = new com.droidhen.game.racingengine.g.c();
        this.x = new com.droidhen.game.racingengine.g.c();
        this.y = null;
        this.z = null;
        this.A = 0;
        this.B = true;
        this.C = false;
        this.D = new float[this.g.n.length * 3];
        this.d = 0;
        this.a = aVar;
        this.b = eVar;
    }

    private void a(boolean z) {
        if (!z) {
            for (int i = 0; i < this.A; i++) {
                this.y[i].b();
            }
            Arrays.fill(this.z, 0.0f);
            return;
        }
        this.A = this.g.m.length;
        this.y = new com.droidhen.game.racingengine.g.e[this.A];
        for (int i2 = 0; i2 < this.A; i2++) {
            this.y[i2] = new com.droidhen.game.racingengine.g.e();
            this.y[i2].b();
        }
        this.z = new float[this.A];
        if (this.n == null) {
            e();
        }
    }

    private synchronized void b(long j) {
        this.b.c = j;
    }

    private synchronized void h() {
        if (this.B) {
            a(true);
            this.B = false;
        } else {
            a(false);
        }
        this.a.a(this.y, this.z, this.g.u, this.n);
        for (int i = 0; i < this.A; i++) {
            this.w.a(this.g.m[i]);
            this.x.a(this.g.m[i]);
            float f = this.z[i];
            if (f != 0.0f) {
                this.y[i].a(this.w, this.x);
                if (this.a.a == c.NORMALIZE) {
                    this.x.a(1.0f / f);
                } else if (this.a.a == c.TOTAL1) {
                    this.w.a(1.0f - f);
                    this.x.d(this.w);
                }
                if (this.g.o != null) {
                    for (int i2 : (int[]) this.g.o.get(i)) {
                        this.g.a().e().a(i2, this.x);
                    }
                } else {
                    for (int i3 = 0; i3 < this.g.n.length; i3++) {
                        if (this.g.n[i3] == i) {
                            this.g.a().e().a(i3, this.x);
                        }
                    }
                }
            }
        }
        this.g.a().e().b().position(0);
    }

    public e a() {
        return this.b;
    }

    public void a(int i) {
        if (this.d == i) {
            this.g.a().e().a(this.D);
            this.g.a().e().b().position(0);
            return;
        }
        this.b.b(false);
        this.b.a(1.0f);
        a(0L);
        b(((d) this.b.a.get(0)).a(i).a());
        h();
        this.g.a().e().b().position(0);
        this.D = new float[this.g.n.length * 3];
        this.g.a().e().b().get(this.D);
        this.g.a().e().b().position(0);
        this.C = true;
        this.g.a().e().a(this.D);
        this.g.a().e().b().position(0);
        this.d = i;
    }

    public void a(long j) {
        this.b.d = j;
    }

    @Override // com.droidhen.game.racingengine.b.g, com.droidhen.game.racingengine.i.a
    public void b() {
        b(com.droidhen.game.racingengine.a.b.f().a());
        if (this.c) {
            h();
        }
    }

    public void c() {
        if (!this.C) {
            this.b.b(false);
            a(0L);
            b(0L);
            h();
            this.g.a().e().b().position(0);
            this.g.a().e().b().get(this.D);
            this.g.a().e().b().position(0);
            this.d = 0;
            this.C = true;
        }
        this.k.a();
        this.l.a();
        this.m.a(1.0f, 1.0f, 1.0f);
        this.o.a();
        this.g.a().e().a(this.D);
        this.g.a().e().b().position(0);
    }
}
