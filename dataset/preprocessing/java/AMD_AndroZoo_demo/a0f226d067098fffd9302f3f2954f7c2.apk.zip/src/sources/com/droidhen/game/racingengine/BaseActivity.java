package com.droidhen.game.racingengine;

import android.app.Activity;
import android.content.Context;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.MotionEvent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class BaseActivity extends Activity {
    protected d a;
    protected b b;
    protected Handler c;

    public Context a() {
        return this;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a(b bVar, GLSurfaceView gLSurfaceView, Handler handler) {
        this.b = bVar;
        this.a = new d(this, gLSurfaceView);
        this.c = handler;
        a.a = this;
        a.b = bVar;
        a.c = this.a;
        a.d = getAssets();
        a.e = new com.droidhen.game.racingengine.b.c.c();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public synchronized boolean onKeyDown(int i, KeyEvent keyEvent) {
        return super.onKeyDown(i, keyEvent);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        this.a.d();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        this.a.c();
    }

    @Override // android.app.Activity
    public synchronized boolean onTouchEvent(MotionEvent motionEvent) {
        return true;
    }
}
