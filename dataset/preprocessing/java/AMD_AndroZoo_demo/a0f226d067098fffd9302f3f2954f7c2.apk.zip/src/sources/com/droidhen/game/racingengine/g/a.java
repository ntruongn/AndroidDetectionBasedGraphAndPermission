package com.droidhen.game.racingengine.g;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a extends com.droidhen.game.racingengine.f.c {
    @Override // com.droidhen.game.racingengine.f.c
    public Object a() {
        return new e();
    }
}
