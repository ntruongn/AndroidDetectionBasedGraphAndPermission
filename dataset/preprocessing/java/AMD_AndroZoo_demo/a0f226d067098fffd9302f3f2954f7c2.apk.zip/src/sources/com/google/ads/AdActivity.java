package com.google.ads;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.VideoView;
import defpackage.n;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class AdActivity extends Activity implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener, View.OnClickListener {
    private static final Object a = new Object();
    private static AdActivity b = null;
    private static defpackage.c c = null;
    private static AdActivity d = null;
    private static AdActivity e = null;
    private defpackage.b f;
    private long g;
    private RelativeLayout h;
    private AdActivity i = null;
    private boolean j;
    private VideoView k;

    private void a(defpackage.b bVar, boolean z, int i) {
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        if (bVar.getParent() != null) {
            a("Interstitial created with an AdWebView that has a parent.");
            return;
        }
        if (bVar.b() != null) {
            a("Interstitial created with an AdWebView that is already in use by another AdActivity.");
            return;
        }
        setRequestedOrientation(i);
        bVar.a(this);
        ImageButton imageButton = new ImageButton(getApplicationContext());
        imageButton.setImageResource(17301527);
        imageButton.setBackgroundDrawable(null);
        int applyDimension = (int) TypedValue.applyDimension(1, 1.0f, getResources().getDisplayMetrics());
        imageButton.setPadding(applyDimension, applyDimension, 0, 0);
        imageButton.setOnClickListener(this);
        this.h.addView(bVar, new ViewGroup.LayoutParams(-1, -1));
        this.h.addView(imageButton);
        setContentView(this.h);
        if (z) {
            defpackage.g.a(bVar);
        }
    }

    public static void a(defpackage.c cVar, defpackage.d dVar) {
        synchronized (a) {
            if (c == null) {
                c = cVar;
            } else if (c != cVar) {
                com.google.ads.util.d.b("Tried to launch a new AdActivity with a different AdManager.");
                return;
            }
            Activity d2 = cVar.d();
            if (d2 == null) {
                com.google.ads.util.d.e("activity was null while launching an AdActivity.");
                return;
            }
            Intent intent = new Intent(d2.getApplicationContext(), (Class<?>) AdActivity.class);
            intent.putExtra("com.google.ads.AdOpener", dVar.a());
            try {
                com.google.ads.util.d.a("Launching AdActivity.");
                d2.startActivity(intent);
            } catch (ActivityNotFoundException e2) {
                com.google.ads.util.d.a(e2.getMessage(), e2);
            }
        }
    }

    private void a(String str) {
        com.google.ads.util.d.b(str);
        finish();
    }

    public VideoView a() {
        return this.k;
    }

    public void a(VideoView videoView) {
        this.k = videoView;
        if (this.f == null) {
            a("Couldn't get adWebView to show the video.");
            return;
        }
        this.f.setBackgroundColor(0);
        videoView.setOnCompletionListener(this);
        videoView.setOnPreparedListener(this);
        videoView.setOnErrorListener(this);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -1);
        LinearLayout linearLayout = new LinearLayout(getApplicationContext());
        linearLayout.setGravity(17);
        linearLayout.addView(videoView, layoutParams);
        this.h.addView(linearLayout, 0, layoutParams);
    }

    public defpackage.b b() {
        defpackage.b bVar;
        if (this.i != null) {
            return this.i.f;
        }
        synchronized (a) {
            if (c == null) {
                com.google.ads.util.d.e("currentAdManager was null while trying to get the opening AdWebView.");
                bVar = null;
            } else {
                defpackage.b h = c.h();
                bVar = h != this.f ? h : null;
            }
        }
        return bVar;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        finish();
    }

    @Override // android.media.MediaPlayer.OnCompletionListener
    public void onCompletion(MediaPlayer mediaPlayer) {
        com.google.ads.util.d.d("Video finished playing.");
        if (this.k != null) {
            this.k.setVisibility(8);
        }
        this.f.loadUrl("javascript:AFMA_ReceiveMessage('onVideoEvent', {'event': 'finish'});");
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        Intent intent;
        super.onCreate(bundle);
        synchronized (a) {
            if (c == null) {
                a("Could not get currentAdManager.");
                return;
            }
            defpackage.c cVar = c;
            if (d == null) {
                d = this;
            }
            if (this.i == null && e != null) {
                this.i = e;
            }
            e = this;
            this.h = null;
            this.j = false;
            this.k = null;
            Bundle bundleExtra = getIntent().getBundleExtra("com.google.ads.AdOpener");
            if (bundleExtra == null) {
                a("Could not get the Bundle used to create AdActivity.");
                return;
            }
            defpackage.d dVar = new defpackage.d(bundleExtra);
            String b2 = dVar.b();
            HashMap c2 = dVar.c();
            if (this == d) {
                cVar.q();
            }
            if (!b2.equals("intent")) {
                this.h = new RelativeLayout(getApplicationContext());
                if (!b2.equals("webapp")) {
                    if (!b2.equals("interstitial")) {
                        a("Unknown AdOpener, <action: " + b2 + ">");
                        return;
                    } else {
                        this.f = cVar.h();
                        a(this.f, true, cVar.l());
                        return;
                    }
                }
                this.f = new defpackage.b(getApplicationContext(), null);
                n nVar = new n(cVar, defpackage.g.b, true, true);
                nVar.b();
                this.f.setWebViewClient(nVar);
                String str = (String) c2.get("u");
                String str2 = (String) c2.get("baseurl");
                String str3 = (String) c2.get("html");
                String str4 = (String) c2.get("o");
                if (str != null) {
                    this.f.loadUrl(str);
                } else {
                    if (str3 == null) {
                        a("Could not get the URL or HTML parameter to show a web app.");
                        return;
                    }
                    this.f.loadDataWithBaseURL(str2, str3, "text/html", "utf-8", null);
                }
                a(this.f, false, "p".equals(str4) ? 1 : "l".equals(str4) ? 0 : cVar.l());
                return;
            }
            this.f = null;
            this.g = SystemClock.elapsedRealtime();
            this.j = true;
            if (c2 == null) {
                a("Could not get the paramMap in launchIntent()");
                return;
            }
            String str5 = (String) c2.get("u");
            if (str5 == null) {
                a("Could not get the URL parameter in launchIntent().");
                return;
            }
            String str6 = (String) c2.get("i");
            String str7 = (String) c2.get("m");
            Uri parse = Uri.parse(str5);
            if (str6 == null) {
                intent = new Intent("android.intent.action.VIEW", parse);
            } else {
                Intent intent2 = new Intent(str6);
                if (str7 != null) {
                    intent2.setDataAndType(parse, str7);
                    intent = intent2;
                } else {
                    intent2.setData(parse);
                    intent = intent2;
                }
            }
            synchronized (a) {
                if (b == null) {
                    b = this;
                    if (c != null) {
                        c.r();
                    } else {
                        com.google.ads.util.d.e("currentAdManager is null while trying to call onLeaveApplication().");
                    }
                }
            }
            try {
                com.google.ads.util.d.a("Launching an intent from AdActivity.");
                startActivity(intent);
            } catch (ActivityNotFoundException e2) {
                com.google.ads.util.d.a(e2.getMessage(), e2);
                finish();
            }
        }
    }

    @Override // android.app.Activity
    public void onDestroy() {
        if (this.h != null) {
            this.h.removeAllViews();
        }
        if (this.f != null) {
            defpackage.g.b(this.f);
            this.f.a(null);
        }
        if (isFinishing()) {
            if (this.k != null) {
                this.k.stopPlayback();
                this.k = null;
            }
            synchronized (a) {
                if (c != null && this.f != null) {
                    if (this.f == c.h()) {
                        c.a();
                    }
                    this.f.stopLoading();
                    this.f.destroy();
                }
                if (this == d) {
                    if (c != null) {
                        c.p();
                        c = null;
                    } else {
                        com.google.ads.util.d.e("currentAdManager is null while trying to destroy AdActivity.");
                    }
                    d = null;
                }
            }
            if (this == b) {
                b = null;
            }
            e = this.i;
        }
        com.google.ads.util.d.a("AdActivity is closing.");
        super.onDestroy();
    }

    @Override // android.media.MediaPlayer.OnErrorListener
    public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
        com.google.ads.util.d.e("Video threw error! <what:" + i + ", extra:" + i2 + ">");
        finish();
        return true;
    }

    @Override // android.media.MediaPlayer.OnPreparedListener
    public void onPrepared(MediaPlayer mediaPlayer) {
        com.google.ads.util.d.d("Video is ready to play.");
        this.f.loadUrl("javascript:AFMA_ReceiveMessage('onVideoEvent', {'event': 'load'});");
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean z) {
        if (this.j && z && SystemClock.elapsedRealtime() - this.g > 250) {
            com.google.ads.util.d.d("Launcher AdActivity got focus and is closing.");
            finish();
        }
        super.onWindowFocusChanged(z);
    }
}
