package com.droidhen.api.scoreclient.ui;

import android.os.Handler;
import android.os.Message;
import android.widget.Toast;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class l extends Handler {
    final /* synthetic */ HighScoresActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(HighScoresActivity highScoresActivity) {
        this.a = highScoresActivity;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        Toast toast;
        Toast toast2;
        int i;
        int i2;
        Toast toast3;
        this.a.a(false);
        switch (message.what) {
            case 0:
                this.a.a();
                return;
            case 1:
                try {
                    this.a.showDialog(1);
                    return;
                } catch (Exception e) {
                    return;
                }
            case 2:
                this.a.a();
                return;
            case 3:
                toast = this.a.v;
                if (toast == null) {
                    this.a.v = Toast.makeText(this.a.getApplicationContext(), 2131034119, 1);
                    toast3 = this.a.v;
                    toast3.setGravity(17, 0, 0);
                }
                toast2 = this.a.v;
                toast2.show();
                this.a.m = 0;
                HighScoresActivity highScoresActivity = this.a;
                i = this.a.m;
                highScoresActivity.b(i);
                HighScoresActivity highScoresActivity2 = this.a;
                i2 = this.a.l;
                highScoresActivity2.c(i2);
                return;
            case 4:
                this.a.a();
                return;
            default:
                return;
        }
    }
}
