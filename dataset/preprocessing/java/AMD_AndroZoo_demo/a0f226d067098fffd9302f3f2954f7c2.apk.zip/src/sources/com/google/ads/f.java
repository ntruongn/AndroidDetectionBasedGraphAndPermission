package com.google.ads;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f {
    public static final f a = new f(320, 50, "320x50_mb");
    public static final f b = new f(300, 250, "300x250_as");
    public static final f c = new f(468, 60, "468x60_as");
    public static final f d = new f(728, 90, "728x90_as");
    private int e;
    private int f;
    private String g;

    private f(int i, int i2, String str) {
        this.e = i;
        this.f = i2;
        this.g = str;
    }

    public int a() {
        return this.e;
    }

    public int b() {
        return this.f;
    }

    public String toString() {
        return this.g;
    }
}
