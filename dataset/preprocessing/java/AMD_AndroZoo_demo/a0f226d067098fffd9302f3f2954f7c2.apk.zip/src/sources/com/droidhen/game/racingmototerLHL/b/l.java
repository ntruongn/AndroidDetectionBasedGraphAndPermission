package com.droidhen.game.racingmototerLHL.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class l {
    public static i a = new i("Models/Motos/group_moto01.data", "n_sapphire", 0, "Group_moto01", "moto", "jiasu_huoyan", new String[]{"huoyan_01", "huoyan_02", "huoyan_03"}, "Box_dingwei", "jiasu_qiliu01", "moto_yingzi", "qianlun", "houlun", 1, 2);
    public static i b = new i("Models/Motos/group_moto02.data", "carduelis", 30000, "Group_moto02", "moto02", "lansehuoyan", new String[]{"lansehuoyan01", "lansehuoyan02"}, "Box_dingwei", "jiasu_qiliu02", "moto02_yingzi", "moto02_qianlun", "moto02_houlun", 20, 21);
    public static i c = new i("Models/Motos/group_moto03.data", "n_titan", 70000, "Group_moto03", "moto03", "Object02", new String[]{"zisehuoyan01", "zisehuoyan02"}, "Box_dingwei01", "jiasu_qiliu03", "moto02_yingzi01", "moto03_qianlun", "moto03_houlun", 22, 23);
    public static i[] d = {a, b, c};
    public static int e = d.length;
}
