package com.droidhen.api.promptclient.prompt;

import android.graphics.Bitmap;
import android.widget.ImageView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class c implements Runnable {
    final /* synthetic */ RecommendActivity a;
    private final /* synthetic */ int b;
    private final /* synthetic */ Bitmap c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(RecommendActivity recommendActivity, int i, Bitmap bitmap) {
        this.a = recommendActivity;
        this.b = i;
        this.c = bitmap;
    }

    @Override // java.lang.Runnable
    public void run() {
        ((ImageView) this.a.findViewById(this.b)).setImageBitmap(this.c);
    }
}
