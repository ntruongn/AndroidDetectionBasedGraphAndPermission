package com.droidhen.game.racingmototerLHL.a.a;

import com.droidhen.game.racingmototerLHL.GameActivity;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class an implements com.droidhen.game.racingengine.a.g {
    final /* synthetic */ e a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public an(e eVar) {
        this.a = eVar;
    }

    @Override // com.droidhen.game.racingengine.a.g
    public void a(com.droidhen.game.racingengine.a.d dVar) {
        com.droidhen.game.racingengine.a.a.f fVar;
        com.droidhen.game.racingengine.a.a.e eVar;
        com.droidhen.game.racingengine.b.c.d[] dVarArr;
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.a);
        int f = com.droidhen.game.racingmototerLHL.b.j.f();
        int i = (f - 1) % 3 < 0 ? ((f - 1) % 3) + 3 : (f - 1) % 3;
        com.droidhen.game.racingmototerLHL.b.j.a().a(i);
        fVar = this.a.q;
        fVar.c(com.droidhen.game.racingmototerLHL.b.l.d[i].c);
        eVar = this.a.m;
        dVarArr = this.a.x;
        eVar.C = dVarArr[i];
    }
}
