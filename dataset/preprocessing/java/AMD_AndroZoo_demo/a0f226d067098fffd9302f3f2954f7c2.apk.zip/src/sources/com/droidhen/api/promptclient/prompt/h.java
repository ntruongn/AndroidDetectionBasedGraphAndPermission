package com.droidhen.api.promptclient.prompt;

import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class h {
    private static long a = 0;

    private static void a(Context context, a aVar) {
        context.startActivity(new Intent(context, (Class<?>) RecommendActivity.class));
    }

    public static void a(Context context, boolean z, com.droidhen.api.promptclient.a.f fVar, String str, String str2, String str3) {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - a < 600000) {
            return;
        }
        long a2 = g.a(context);
        if (a2 == 0) {
            a2 = (currentTimeMillis - 86400000) + 5400000;
            g.a(context, a2);
        }
        if (z) {
            if (currentTimeMillis - a2 > (g.b(context) ? 259200000L : 86400000L)) {
                Intent intent = new Intent(context, (Class<?>) RateActivity.class);
                intent.putExtra("msg", fVar.a(context, str, str2));
                intent.putExtra("file", str3);
                context.startActivity(intent);
                a = currentTimeMillis;
                g.a(context, currentTimeMillis);
                return;
            }
        }
        b(context);
    }

    public static boolean a(Context context) {
        return l.b(context);
    }

    public static void b(Context context) {
        l.a(context);
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - a < 600000) {
            return;
        }
        a b = f.b(context);
        if (b.f >= 1 || !b.a()) {
            return;
        }
        a(context, b);
        a = currentTimeMillis;
        b.f++;
        f.a(context, b);
    }
}
