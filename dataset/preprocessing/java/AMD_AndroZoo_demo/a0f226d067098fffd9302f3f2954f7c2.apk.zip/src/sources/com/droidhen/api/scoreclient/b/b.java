package com.droidhen.api.scoreclient.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    private double a;
    private String b;
    private int c;
    private int d;

    public b(double d) {
        this.a = d;
        this.c = 0;
    }

    public b(double d, int i) {
        this.a = d;
        this.c = i;
    }

    public b(double d, int i, String str) {
        this.a = d;
        this.c = i;
        this.b = str;
    }

    public double a() {
        return this.a;
    }

    public void a(int i) {
        this.d = i;
    }

    public void a(String str) {
        this.b = str;
    }

    public int b() {
        return this.c;
    }

    public String c() {
        return this.b;
    }

    public int d() {
        return this.d;
    }
}
