package com.droidhen.game.racingmototerLHL.global;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    public static final com.droidhen.game.racingengine.h.e a = new com.droidhen.game.racingengine.h.e(2130968577, true, 1.0f);
    public static final com.droidhen.game.racingengine.h.e b = new com.droidhen.game.racingengine.h.e(2130968576, true, 1.0f);
    public static final com.droidhen.game.racingengine.h.e c = new com.droidhen.game.racingengine.h.e(2130968582, true, 1.0f);
    public static final com.droidhen.game.racingengine.h.e d = new com.droidhen.game.racingengine.h.e(2130968583, true, 1.0f);
    public static final com.droidhen.game.racingengine.h.e e = new com.droidhen.game.racingengine.h.e(2130968578, true, 1.0f);
    public static final com.droidhen.game.racingengine.h.e f = new com.droidhen.game.racingengine.h.e(2130968581, false, 1.0f);
    public static final com.droidhen.game.racingengine.h.e g = new com.droidhen.game.racingengine.h.e(2130968580, false, 1.0f);
    public static final com.droidhen.game.racingengine.h.e h = new com.droidhen.game.racingengine.h.e(2130968579, false, 1.0f);
    public static final com.droidhen.game.racingengine.h.e[] i = {a, c, h, f, g, e, b, d};
}
