package com.droidhen.game.racingmototerLHL.a.a;

import javax.microedition.khronos.opengles.GL10;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class ak extends com.droidhen.game.racingengine.a.a.e {
    protected float d;
    final /* synthetic */ x e;
    private float f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ak(x xVar) {
        super(com.droidhen.game.racingengine.a.e.a("pointer"));
        this.e = xVar;
        this.f = 30.0f;
        this.d = 70.0f;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        super.a();
        this.d = 1.6f * this.F;
    }

    public void a(int i) {
        float f;
        float f2;
        f = this.e.f;
        float f3 = -(i / f);
        f2 = this.e.h;
        this.f = (f3 * f2) + 90.0f;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        c();
        this.d = 0.6f * this.F;
        gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        gl10.glBindTexture(3553, this.C.a);
        gl10.glPushMatrix();
        gl10.glTranslatef(this.G.a, this.G.b, 0.0f);
        gl10.glRotatef(this.f, 0.0f, 0.0f, 1.0f);
        gl10.glTranslatef((-0.5f) * this.E, this.d, 0.0f);
        this.M.position(0);
        gl10.glTexCoordPointer(2, 5126, 0, this.M);
        this.N.position(0);
        gl10.glVertexPointer(3, 5126, 0, this.N);
        this.O.position(0);
        gl10.glDrawElements(4, this.D, 5123, this.O);
        gl10.glPopMatrix();
    }
}
