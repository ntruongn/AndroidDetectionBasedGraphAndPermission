package com.droidhen.game.racingmototerLHL.a.a;

import com.droidhen.game.racingmototerLHL.global.SCApplication;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class ag extends com.droidhen.game.racingengine.a.f {
    private static boolean v = false;
    private static boolean w = false;
    private com.droidhen.game.racingengine.a.d d;
    private com.droidhen.game.racingengine.a.d e;
    private com.droidhen.game.racingengine.a.d j;
    private com.droidhen.game.racingengine.a.d k;
    private com.droidhen.game.racingengine.a.d l;
    private com.droidhen.game.racingengine.a.a.f m;
    private com.droidhen.game.racingengine.a.a.f n;
    private com.droidhen.game.racingengine.a.a.e o;
    private com.droidhen.game.racingengine.a.a.e p;
    private com.droidhen.game.racingengine.b.c.d q;
    private com.droidhen.game.racingengine.b.c.d r;
    private com.droidhen.game.racingengine.b.c.d s;
    private com.droidhen.game.racingengine.b.c.d t;
    private boolean u;
    private float x;

    public ag() {
        super(0.5f, 0.5f, 480.0f, 800.0f, -1);
        this.q = com.droidhen.game.racingengine.a.e.a("rock24h_a");
        this.r = com.droidhen.game.racingengine.a.e.a("rock24h_b");
        this.s = com.droidhen.game.racingengine.a.e.a("score2_a");
        this.t = com.droidhen.game.racingengine.a.e.a("score2_b");
        this.x = 0.0f;
        this.B = 0.0f;
        this.o = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("gameover_bg"));
        this.o.a(20.0f, 146.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.o.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.o);
        this.p = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("gameover"));
        this.p.a(20.0f, 40.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.p.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.p);
        this.d = new com.droidhen.game.racingengine.a.d(240.0f, 552.0f, com.droidhen.game.racingengine.a.h.CENTERTOP, com.droidhen.game.racingengine.a.e.a("retry3_a"), com.droidhen.game.racingengine.a.e.a("retry3_b"));
        this.d.a(new ad(this));
        this.e = new com.droidhen.game.racingengine.a.d(340.0f, 637.0f, com.droidhen.game.racingengine.a.h.LEFTTOP, com.droidhen.game.racingengine.a.e.a("more2_a"), com.droidhen.game.racingengine.a.e.a("more2_b"));
        this.e.a(new ac(this));
        this.k = new com.droidhen.game.racingengine.a.d(213.0f, 637.0f, com.droidhen.game.racingengine.a.h.LEFTTOP, com.droidhen.game.racingengine.a.e.a("rate_a"), com.droidhen.game.racingengine.a.e.a("rate_b"));
        this.k.a(new aa(this));
        this.j = new com.droidhen.game.racingengine.a.d(45.0f, 637.0f, com.droidhen.game.racingengine.a.h.LEFTTOP, com.droidhen.game.racingengine.a.e.a("rock24h_a"), com.droidhen.game.racingengine.a.e.a("rock24h_b"));
        this.j.a(new z(this));
        this.l = new com.droidhen.game.racingengine.a.d(480.0f, 100.0f, com.droidhen.game.racingengine.a.h.RIGHTBOTTOM, com.droidhen.game.racingengine.a.e.a("share"));
        this.l.a(new ab(this));
        a(this.d);
        a(this.e);
        a(this.j);
        a(this.k);
        a(this.l);
        this.m = new com.droidhen.game.racingengine.a.a.f(com.droidhen.game.racingengine.a.e.a("gameover_zi"), 0.0f, 10);
        this.m.c(10000);
        this.m.a(49.0f, 300.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.n = new com.droidhen.game.racingengine.a.a.f(com.droidhen.game.racingengine.a.e.a("gameover_zi02"), 0.0f, 10);
        this.n.c(100000);
        this.n.a(49.0f, 412.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        a(this.n);
        a(this.m);
        a(com.droidhen.game.racingmototerLHL.global.f.a().f);
    }

    public static void f() {
        w = true;
        v = true;
    }

    private void q() {
        this.m.c((int) com.droidhen.game.racingmototerLHL.global.f.b);
        if (com.droidhen.game.racingmototerLHL.global.f.a().a.getText().toString() != null && !com.droidhen.game.racingmototerLHL.a.a.i && !com.droidhen.game.racingmototerLHL.global.f.b().o) {
            com.droidhen.game.racingmototerLHL.global.f.a().a.a((int) com.droidhen.game.racingmototerLHL.global.f.b, SCApplication.a());
        }
        if (com.droidhen.api.scoreclient.ui.i.a().b(SCApplication.a()) == null) {
            this.n.c(0);
        } else {
            this.n.c(com.droidhen.api.scoreclient.ui.i.a().b(SCApplication.a()).intValue());
        }
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        super.c();
        if (w) {
            if (v) {
                this.j.a(this.s, this.t);
            } else {
                this.j.a(this.q, this.r);
            }
            w = false;
        }
        if (this.i && this.u) {
            this.u = false;
            if (!com.droidhen.game.racingmototerLHL.a.a.i) {
                com.droidhen.api.promptclient.prompt.h.a(com.droidhen.game.racingengine.a.a.a(), true, com.droidhen.api.promptclient.a.f.Score, new StringBuilder().append((int) com.droidhen.game.racingmototerLHL.global.f.b).toString(), null, SCApplication.a(com.droidhen.game.racingengine.a.a.a()));
            }
        }
        if (this.x > 0.0f) {
            this.x -= com.droidhen.game.racingengine.a.b.g().b();
        }
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        super.d();
        q();
        this.u = true;
        com.droidhen.game.racingmototerLHL.global.f.b().A();
        com.droidhen.game.racingmototerLHL.global.f.b().x();
        this.x = 0.0f;
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l
    public void e() {
        super.e();
        com.droidhen.game.racingmototerLHL.global.f.b().y();
        com.droidhen.game.racingmototerLHL.global.f.b().B();
        if (com.droidhen.game.racingmototerLHL.a.a.i) {
            return;
        }
        v = false;
        w = true;
    }
}
