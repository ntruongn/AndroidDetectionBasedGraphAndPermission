package com.droidhen.game.racingengine.a.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public abstract class c {
    protected float a;
    protected float b;
    protected float c;
    protected float d;
    protected int e = 1;
    protected boolean f = false;
    protected boolean g = false;
    protected b h = b.Initialized;
    protected a i = null;
    protected com.droidhen.game.racingengine.b.b.b j = new com.droidhen.game.racingengine.b.b.b();
    private long k;
    private long l;
    private long m;

    public void a() {
        this.m = System.currentTimeMillis();
        this.k = 0L;
        this.g = true;
        this.f = false;
        this.h = b.Running;
    }

    public void a(a aVar) {
        this.i = aVar;
    }

    public void b() {
        this.g = false;
        this.f = false;
        this.h = b.Initialized;
    }

    public void c() {
        if (((float) this.k) > this.c * 1000.0f * this.e && this.g) {
            this.d = this.b;
            if (this.i != null) {
                this.i.a(this);
            }
            this.g = false;
            this.h = b.Ended;
        }
        if (this.g) {
            if (!this.f) {
                this.l = System.currentTimeMillis() - this.m;
                this.k += this.l;
            }
            this.m = System.currentTimeMillis();
            f();
        }
    }

    public float d() {
        return this.d;
    }

    public com.droidhen.game.racingengine.b.b.b e() {
        return this.j.a(this.k);
    }

    public void f() {
    }
}
