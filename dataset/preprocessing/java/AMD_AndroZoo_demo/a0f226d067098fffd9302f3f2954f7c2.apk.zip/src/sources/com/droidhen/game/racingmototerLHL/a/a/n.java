package com.droidhen.game.racingmototerLHL.a.a;

import javax.microedition.khronos.opengles.GL10;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class n extends com.droidhen.game.racingengine.a.a.e {
    long d;
    final /* synthetic */ k e;
    private com.droidhen.game.racingengine.a.a.e f;
    private com.droidhen.game.racingengine.a.a.e g;
    private com.droidhen.game.racingengine.a.a.e h;
    private y i;
    private int j;
    private com.droidhen.game.racingengine.b.c.d k;
    private com.droidhen.game.racingengine.b.c.d l;
    private com.droidhen.game.racingengine.b.c.d m;
    private com.droidhen.game.racingengine.b.c.d v;
    private com.droidhen.game.racingengine.b.c.d w;
    private com.droidhen.game.racingengine.b.c.d x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(k kVar) {
        super(com.droidhen.game.racingengine.a.e.a("face_bg"));
        this.e = kVar;
        this.j = 4;
        this.k = com.droidhen.game.racingengine.a.e.a("face_normal");
        this.l = com.droidhen.game.racingengine.a.e.a("face_smile");
        this.m = com.droidhen.game.racingengine.a.e.a("face_panic");
        this.v = com.droidhen.game.racingengine.a.e.a("ha01");
        this.w = com.droidhen.game.racingengine.a.e.a("ha02");
        this.x = com.droidhen.game.racingengine.a.e.a("ha03");
        a(0.0f, 0.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.f = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("face_bg"));
        this.f.a(0.0f, 0.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.g = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("face_normal"));
        this.g.a(0.0f, 0.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.h = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("ha01"));
        this.h.a(0.0f, 0.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.h.z = false;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        super.a();
        this.f.a();
        this.h.a();
        this.g.a();
    }

    public void a(y yVar) {
        this.i = yVar;
        if (yVar == y.Smile) {
            this.d = 0L;
        }
        this.j = 4;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        c();
        this.f.a(gl10);
        this.g.a(gl10);
        this.h.a(gl10);
    }

    @Override // com.droidhen.game.racingengine.a.a.e, com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.PAUSE) {
            return;
        }
        com.droidhen.game.racingengine.b.b.b g = com.droidhen.game.racingengine.a.b.g();
        if (this.i == y.Normal) {
            this.g.C = this.k;
            this.h.z = false;
        } else if (this.i == y.Smile) {
            this.g.C = this.l;
            this.h.z = true;
            this.d += g.a();
            this.d %= 800;
            if (this.d > 600) {
                this.h.z = false;
            } else if (this.d > 400) {
                this.h.z = true;
                this.h.C = this.x;
            } else if (this.d > 200) {
                this.h.C = this.w;
            } else {
                this.h.C = this.v;
            }
        } else {
            this.h.z = false;
            this.g.C = this.m;
        }
        if ((!com.droidhen.game.racingmototerLHL.global.f.f || this.i != y.Smile) && this.j > 0) {
            this.j--;
        }
        if (this.j <= 0) {
            if (com.droidhen.game.racingmototerLHL.global.f.f) {
                this.i = y.Smile;
            } else {
                this.i = y.Normal;
            }
        }
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.CRASH) {
            this.i = y.Panic;
        }
    }
}
