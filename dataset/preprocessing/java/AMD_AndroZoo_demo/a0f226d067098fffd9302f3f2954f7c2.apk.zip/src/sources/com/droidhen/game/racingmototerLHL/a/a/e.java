package com.droidhen.game.racingmototerLHL.a.a;

import com.droidhen.game.racingmototerLHL.global.SCApplication;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e extends com.droidhen.game.racingengine.a.f {
    com.droidhen.game.racingengine.b.c.d[] d;
    int e;
    private com.droidhen.game.racingengine.a.d j;
    private com.droidhen.game.racingengine.a.d k;
    private com.droidhen.game.racingengine.a.a.e l;
    private com.droidhen.game.racingengine.a.a.e m;
    private com.droidhen.game.racingengine.a.d n;
    private com.droidhen.game.racingengine.a.d o;
    private com.droidhen.game.racingengine.a.a.e p;
    private com.droidhen.game.racingengine.a.a.f q;
    private com.droidhen.game.racingengine.a.a.f r;
    private com.droidhen.game.racingengine.a.a.e s;
    private com.droidhen.game.racingengine.a.a.e t;
    private com.droidhen.game.racingengine.a.a.e u;
    private com.droidhen.game.racingengine.a.a.e v;
    private float w;
    private com.droidhen.game.racingengine.b.c.d[] x;

    public e() {
        super(0.5f, 0.5f, 480.0f, 800.0f, -1);
        this.w = 0.0f;
        this.d = new com.droidhen.game.racingengine.b.c.d[]{com.droidhen.game.racingengine.a.e.a("b_star_a"), com.droidhen.game.racingengine.a.e.a("b_star_b"), com.droidhen.game.racingengine.a.e.a("start_hui")};
        this.e = 0;
        this.x = new com.droidhen.game.racingengine.b.c.d[]{com.droidhen.game.racingengine.a.e.a(com.droidhen.game.racingmototerLHL.b.l.d[0].b), com.droidhen.game.racingengine.a.e.a(com.droidhen.game.racingmototerLHL.b.l.d[1].b), com.droidhen.game.racingengine.a.e.a(com.droidhen.game.racingmototerLHL.b.l.d[2].b)};
        this.B = 0.0f;
        a(com.droidhen.game.racingengine.a.j.FitScreen);
        this.y = "SelectMoto";
        this.j = new com.droidhen.game.racingengine.a.d(0.0f, 40.0f, com.droidhen.game.racingengine.a.h.LEFTTOP, com.droidhen.game.racingengine.a.e.a("back_a"), com.droidhen.game.racingengine.a.e.a("back_b"));
        this.j.a(new ao(this));
        this.k = new com.droidhen.game.racingengine.a.d(240.0f, 690.0f, com.droidhen.game.racingengine.a.h.CENTERTOP, this.d[0], this.d[1]);
        this.k.a(new am(this));
        this.o = new com.droidhen.game.racingengine.a.d(10.0f, 580.0f, com.droidhen.game.racingengine.a.h.LEFTTOP, com.droidhen.game.racingengine.a.e.a("b_zuo"));
        this.o.a(new an(this));
        this.n = new com.droidhen.game.racingengine.a.d(470.0f, 580.0f, com.droidhen.game.racingengine.a.h.RIGHTTOP, com.droidhen.game.racingengine.a.e.a("b_you"));
        this.n.a(new ap(this));
        this.l = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("select"));
        this.l.a(240.0f, 0.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        this.l.a(com.droidhen.game.racingengine.a.j.FitScreen);
        this.m = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("carduelis"));
        this.m.a(240.0f, 540.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        this.m.a(com.droidhen.game.racingengine.a.j.FitScreen);
        this.p = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("unlockby"));
        this.p.a(240.0f, 605.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        this.q = new com.droidhen.game.racingengine.a.a.f(com.droidhen.game.racingengine.a.e.a("select_num"), 0.0f, 10);
        this.q.c(10000);
        this.q.l(0.0f, -276.0f);
        this.q.e(0.5f, 0.0f);
        this.r = new com.droidhen.game.racingengine.a.a.f(com.droidhen.game.racingengine.a.e.a("lit_num"), 0.0f, 10);
        this.r.c(10000);
        this.r.l(128.0f, 237.0f);
        this.r.e(0.0f, 0.0f);
        this.u = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("myscore"));
        this.u.a(364.0f, 134.0f, com.droidhen.game.racingengine.a.h.RIGHTTOP);
        this.s = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("suo"));
        this.s.a(110.0f, 700.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.t = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("suo"));
        this.t.a(340.0f, 700.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        com.droidhen.game.racingengine.a.a.e eVar = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("pts"));
        eVar.a(325.0f, 650.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        this.v = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("lit_pts"));
        this.v.a(460.0f, 148.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        a(this.l);
        a(this.m);
        a(this.j);
        a(this.n);
        a(this.o);
        a(this.k);
        a(eVar);
        a(this.p);
        a(this.q);
        a(this.u);
        a(this.v);
        a(this.s);
        a(this.t);
        a(this.r);
        a(com.droidhen.game.racingmototerLHL.global.f.a().h);
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        boolean z;
        if (!this.z) {
            this.h.e();
            return;
        }
        this.h.d();
        if (this.B != 1.0f) {
            gl10.glColor4f(0.0f, 0.0f, 0.0f, this.B);
            z = true;
        } else {
            z = false;
        }
        gl10.glBindTexture(3553, this.C.a);
        gl10.glPushMatrix();
        gl10.glMultMatrixf(this.f.b, 0);
        gl10.glTexCoordPointer(2, 5126, 0, this.M);
        gl10.glVertexPointer(3, 5126, 0, this.N);
        gl10.glDrawElements(4, this.D, 5123, this.O);
        if (z) {
            gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        }
        if (this.P != null) {
            for (int i = 0; i < this.P.size(); i++) {
                ((com.droidhen.game.racingengine.a.l) this.P.get(i)).a(gl10);
            }
        }
        if (this.e < com.droidhen.game.racingmototerLHL.b.l.d[com.droidhen.game.racingmototerLHL.b.j.f()].c) {
            this.k.a(this.d[2], this.d[2]);
            this.t.z = true;
            this.s.z = true;
        } else {
            this.k.a(this.d[0], this.d[1]);
            this.t.z = false;
            this.s.z = false;
        }
        gl10.glPopMatrix();
        if (this.w > 0.0f) {
            this.w -= com.droidhen.game.racingengine.a.b.g().b();
        }
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        super.d();
        this.q.c(com.droidhen.game.racingmototerLHL.b.l.d[com.droidhen.game.racingmototerLHL.b.j.f()].c);
        if (com.droidhen.api.scoreclient.ui.i.a().b(SCApplication.a()) != null) {
            this.e = com.droidhen.api.scoreclient.ui.i.a().b(SCApplication.a()).intValue();
        } else {
            this.e = 0;
        }
        this.r.c(this.e);
        this.w = 0.0f;
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l
    public void e() {
        super.e();
    }
}
