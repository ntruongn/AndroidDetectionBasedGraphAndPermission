package com.droidhen.game.racingmototerLHL.global;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d {
    public static final a a = new a(new int[]{0, 1, 1}, 0.1f, 60.0f, 100.0f);
    public static final a b = new a(new int[]{1, 1, 1}, 0.2f, 70.0f, 120.0f);
    public static final a c = new a(new int[3], 0.0f, 60.0f, 100.0f);
    public static final a[] d = {a, b};
}
