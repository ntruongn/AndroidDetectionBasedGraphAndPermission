package com.droidhen.game.racingmototerLHL.b;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class o extends com.droidhen.game.racingengine.j.a.a {
    final /* synthetic */ k e;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(k kVar, float f, float f2, float f3, float f4) {
        super(f, f2, f3, f4);
        this.e = kVar;
    }

    @Override // com.droidhen.game.racingengine.j.a.a
    public void a() {
        com.droidhen.game.racingengine.g.c d = com.droidhen.game.racingengine.g.c.d();
        this.a.a(this.e.a.o.d(d));
        com.droidhen.game.racingengine.g.c.f(d);
        this.b.a(this.e.a.o);
    }

    @Override // com.droidhen.game.racingengine.j.a.a
    public void a(com.droidhen.game.racingengine.j.a.a aVar, com.droidhen.game.racingengine.j.a.a aVar2) {
        com.droidhen.game.racingengine.g.c cVar;
        com.droidhen.game.racingengine.g.c cVar2;
        com.droidhen.game.racingengine.g.c cVar3;
        com.droidhen.game.racingengine.g.c cVar4;
        com.droidhen.game.racingengine.g.c cVar5;
        com.droidhen.game.racingengine.g.c cVar6;
        com.droidhen.game.racingengine.g.c cVar7;
        com.droidhen.game.racingengine.g.c cVar8;
        com.droidhen.game.racingengine.g.c cVar9;
        com.droidhen.game.racingengine.g.c cVar10;
        if (aVar.c == null || aVar2.c == null) {
            return;
        }
        this.e.f = 4;
        this.e.g = ((k) aVar2.c).g();
        if (((k) aVar.c).g() == ((k) aVar2.c).g()) {
            k kVar = this.e;
            cVar9 = ((k) aVar2.c).z;
            float f = cVar9.b;
            cVar10 = ((k) aVar.c).z;
            kVar.t = f - cVar10.b;
            if (aVar.b.b.b >= aVar2.b.b.b) {
                if (this.e.t >= 5.0f || this.e.t <= -5.0f) {
                    ((k) aVar.c).b((-this.e.t) / 5.0f);
                    return;
                } else {
                    ((k) aVar.c).b(2.0f);
                    ((k) aVar2.c).a(2.0f);
                    return;
                }
            }
            if (this.e.t >= 5.0f || this.e.t <= -5.0f) {
                ((k) aVar2.c).b(this.e.t / 5.0f);
                return;
            } else {
                ((k) aVar2.c).b(2.0f);
                ((k) aVar.c).a(2.0f);
                return;
            }
        }
        if (((k) aVar.c).f() == a.TurnLeft || ((k) aVar.c).f() == a.TurnRight) {
            if (aVar.b.b.b > aVar2.b.b.b) {
                cVar3 = ((k) aVar2.c).z;
                cVar4 = ((k) aVar.c).z;
                cVar3.b = cVar4.b - 3.0f;
                return;
            } else {
                cVar = ((k) aVar2.c).z;
                cVar2 = ((k) aVar.c).z;
                cVar.b = cVar2.b + 3.0f;
                return;
            }
        }
        if (((k) aVar2.c).f() == a.TurnLeft || ((k) aVar2.c).f() == a.TurnRight) {
            if (aVar.b.b.b > aVar2.b.b.b) {
                cVar7 = ((k) aVar.c).z;
                cVar8 = ((k) aVar2.c).z;
                cVar7.b = cVar8.b + 3.0f;
            } else {
                cVar5 = ((k) aVar.c).z;
                cVar6 = ((k) aVar2.c).z;
                cVar5.b = cVar6.b - 3.0f;
            }
        }
    }

    @Override // com.droidhen.game.racingengine.j.a.a
    public void b(com.droidhen.game.racingengine.j.a.a aVar, com.droidhen.game.racingengine.j.a.a aVar2) {
        com.droidhen.game.racingengine.g.c cVar;
        com.droidhen.game.racingengine.g.c cVar2;
        com.droidhen.game.racingengine.g.c cVar3;
        com.droidhen.game.racingengine.g.c cVar4;
        float f;
        com.droidhen.game.racingengine.g.c cVar5;
        float f2;
        com.droidhen.game.racingengine.g.c cVar6;
        float f3;
        com.droidhen.game.racingengine.g.c cVar7;
        com.droidhen.game.racingengine.g.c cVar8;
        com.droidhen.game.racingengine.g.c cVar9;
        com.droidhen.game.racingengine.g.c cVar10;
        float f4;
        com.droidhen.game.racingengine.g.c cVar11;
        float f5;
        com.droidhen.game.racingengine.g.c cVar12;
        float f6;
        if (aVar.c == null || aVar2.c == null) {
            return;
        }
        if (aVar.b.b.b >= aVar2.b.b.b) {
            cVar7 = ((k) aVar.c).z;
            cVar8 = ((k) aVar2.c).z;
            cVar7.b = cVar8.b + 20.0f;
            cVar9 = ((k) aVar2.c).z;
            cVar9.b -= 3.0f;
            cVar10 = ((k) aVar.c).z;
            float f7 = cVar10.b;
            f4 = this.e.J;
            if (f7 > (-f4)) {
                cVar11 = ((k) aVar.c).z;
                f5 = this.e.J;
                cVar11.b = -f5;
                cVar12 = ((k) aVar2.c).z;
                f6 = this.e.J;
                cVar12.b = (-f6) - 20.0f;
                return;
            }
            return;
        }
        cVar = ((k) aVar2.c).z;
        cVar2 = ((k) aVar.c).z;
        cVar.b = cVar2.b + 20.0f;
        cVar3 = ((k) aVar2.c).z;
        cVar3.b -= 3.0f;
        cVar4 = ((k) aVar2.c).z;
        float f8 = cVar4.b;
        f = this.e.J;
        if (f8 > (-f)) {
            cVar5 = ((k) aVar2.c).z;
            f2 = this.e.J;
            cVar5.b = -f2;
            cVar6 = ((k) aVar.c).z;
            f3 = this.e.J;
            cVar6.b = (-f3) - 20.0f;
        }
    }
}
