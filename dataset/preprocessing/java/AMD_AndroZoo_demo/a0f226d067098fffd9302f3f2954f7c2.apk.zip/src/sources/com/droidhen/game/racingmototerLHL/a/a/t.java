package com.droidhen.game.racingmototerLHL.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class t extends com.droidhen.game.racingengine.a.d {
    final /* synthetic */ j e;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t(j jVar, float f, float f2, com.droidhen.game.racingengine.a.h hVar, com.droidhen.game.racingengine.b.c.d dVar, com.droidhen.game.racingengine.b.c.d dVar2) {
        super(f, f2, hVar, dVar, dVar2);
        this.e = jVar;
    }

    @Override // com.droidhen.game.racingengine.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean d(float f, float f2) {
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.d
    public void f() {
    }

    @Override // com.droidhen.game.racingengine.a.d
    public void g() {
    }
}
