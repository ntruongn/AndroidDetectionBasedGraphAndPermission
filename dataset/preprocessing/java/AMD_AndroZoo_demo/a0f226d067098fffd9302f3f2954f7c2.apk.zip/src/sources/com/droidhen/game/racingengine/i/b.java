package com.droidhen.game.racingengine.i;

import android.os.Handler;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public abstract class b {
    protected Handler a;
    private long b;
    private long c;
    private int g;
    private int h;
    private long i;
    private final com.droidhen.game.racingengine.b.b.b d = new com.droidhen.game.racingengine.b.b.b();
    private final com.droidhen.game.racingengine.b.b.b e = new com.droidhen.game.racingengine.b.b.b();
    private long f = 0;
    private boolean j = true;
    private boolean k = false;
    private boolean l = false;

    public synchronized void a() {
        if (!this.l) {
            this.i = System.nanoTime();
            this.b = 0L;
            this.l = true;
        }
        this.c = this.b;
        long nanoTime = System.nanoTime();
        this.b += nanoTime - this.i;
        this.i = nanoTime;
        if (this.b - this.f > 1000000000) {
            this.h = this.g;
            this.g = 0;
            this.f = this.b;
        }
        this.g++;
        if (!this.j) {
            b();
        }
    }

    protected abstract void b();

    public synchronized void c() {
        this.j = true;
    }

    public synchronized void d() {
        this.j = false;
        this.i = System.nanoTime();
    }

    public synchronized boolean e() {
        this.l = false;
        return this.l;
    }

    public com.droidhen.game.racingengine.b.b.b f() {
        return this.b < 0 ? this.d.b(0L) : this.d.b(this.b);
    }

    public com.droidhen.game.racingengine.b.b.b g() {
        long j = this.b - this.c;
        return j < 0 ? this.e.b(0L) : this.e.b(j);
    }
}
