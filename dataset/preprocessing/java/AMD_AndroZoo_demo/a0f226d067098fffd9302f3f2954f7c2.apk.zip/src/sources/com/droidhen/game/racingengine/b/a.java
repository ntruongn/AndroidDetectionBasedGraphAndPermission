package com.droidhen.game.racingengine.b;

import java.util.ArrayList;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a implements com.droidhen.game.racingengine.i.a, Cloneable {
    public String a;
    public boolean b = true;
    public boolean c = false;
    public ArrayList d = new ArrayList();
    public com.droidhen.game.racingengine.g.c e = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c f = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c g = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c h = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c i = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.e j = null;
    public com.droidhen.game.racingengine.g.e k = new com.droidhen.game.racingengine.g.e();
    public com.droidhen.game.racingengine.g.c l = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c m = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c n = new com.droidhen.game.racingengine.g.c(1.0f, 1.0f, 1.0f);
    public com.droidhen.game.racingengine.g.e o = new com.droidhen.game.racingengine.g.e();
    com.droidhen.game.racingengine.g.e p = new com.droidhen.game.racingengine.g.e();

    public a() {
    }

    public a(String str) {
        this.a = str;
    }

    public g a(String str) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.d.size()) {
                throw new RuntimeException("Can't find an object3d matched the name " + str + " .");
            }
            g gVar = (g) this.d.get(i2);
            if (gVar.e.equals(str)) {
                return gVar;
            }
            i = i2 + 1;
        }
    }

    public void a() {
        com.droidhen.game.racingengine.g.e d = com.droidhen.game.racingengine.g.e.d();
        d.a(this.h);
        com.droidhen.game.racingengine.g.e d2 = com.droidhen.game.racingengine.g.e.d();
        d2.a(this.i);
        com.droidhen.game.racingengine.g.e d3 = com.droidhen.game.racingengine.g.e.d();
        d3.a(this.f);
        com.droidhen.game.racingengine.g.e d4 = com.droidhen.game.racingengine.g.e.d();
        com.droidhen.game.racingengine.g.e d5 = com.droidhen.game.racingengine.g.e.d();
        com.droidhen.game.racingengine.g.e.a(com.droidhen.game.racingengine.g.e.a(d, d3, d4), d2, d5);
        com.droidhen.game.racingengine.g.e.d(d4);
        com.droidhen.game.racingengine.g.e.d(d3);
        com.droidhen.game.racingengine.g.e.d(d2);
        com.droidhen.game.racingengine.g.e.d(d);
        com.droidhen.game.racingengine.g.e d6 = com.droidhen.game.racingengine.g.e.d();
        d6.b(this.e);
        com.droidhen.game.racingengine.g.e d7 = com.droidhen.game.racingengine.g.e.d();
        d7.c(this.g);
        com.droidhen.game.racingengine.g.e d8 = com.droidhen.game.racingengine.g.e.d();
        if (this.j == null) {
            this.j = new com.droidhen.game.racingengine.g.e();
        }
        com.droidhen.game.racingengine.g.e.a(com.droidhen.game.racingengine.g.e.a(d6, d5, d8), d7, this.j);
        com.droidhen.game.racingengine.g.e.d(d8);
        com.droidhen.game.racingengine.g.e.d(d6);
        com.droidhen.game.racingengine.g.e.d(d5);
        com.droidhen.game.racingengine.g.e.d(d7);
    }

    public void a(g gVar) {
        gVar.f = this;
        this.d.add(gVar);
    }

    public void a(g gVar, int i) {
        gVar.f = this;
        if (i < 0) {
            this.d.add((this.d.size() - 1) + i, gVar);
        } else {
            this.d.add(i, gVar);
        }
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void a(GL10 gl10) {
        if (this.b) {
            if (this.c) {
                gl10.glEnable(2929);
                gl10.glDepthFunc(515);
                gl10.glClearDepthf(1.0f);
                gl10.glClear(256);
            }
            gl10.glPushMatrix();
            if (this.j == null) {
                a();
            }
            gl10.glMultMatrixf(this.j.b, 0);
            this.p.a(this.n, this.m, this.l);
            gl10.glMultMatrixf(this.p.b, 0);
            gl10.glMultMatrixf(this.o.b, 0);
            for (int i = 0; i < this.d.size(); i++) {
                ((g) this.d.get(i)).a(gl10);
            }
            gl10.glPopMatrix();
            if (this.c) {
                gl10.glDisable(2929);
            }
        }
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void b() {
    }

    public void b(g gVar) {
        gVar.f = null;
        this.d.remove(gVar);
    }

    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public a clone() {
        a aVar = new a();
        aVar.a = this.a;
        aVar.e.a(this.e);
        aVar.f.a(this.f);
        aVar.g.a(this.g);
        aVar.h.a(this.h);
        aVar.i.a(this.i);
        aVar.a();
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.d.size()) {
                return aVar;
            }
            aVar.d.add(((g) this.d.get(i2)).clone());
            i = i2 + 1;
        }
    }
}
