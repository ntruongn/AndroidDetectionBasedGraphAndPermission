package com.droidhen.api.promptclient.a;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class g {
    public static void a(Activity activity, String str) {
        a(activity, null, null, f.Empty, str);
    }

    public static void a(Activity activity, String str, String str2) {
        Intent intent = new Intent("android.intent.action.SEND");
        if (str2 != null) {
            intent.setType("image/jpeg");
            intent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + str2));
        } else {
            intent.setType("text/plain");
        }
        if (str != null) {
            intent.putExtra("android.intent.extra.TEXT", str);
        }
        activity.startActivity(intent);
    }

    public static void a(Activity activity, String str, String str2, f fVar, String str3) {
        a(activity, fVar.a(activity, str, str2), str3);
    }

    public static void a(Activity activity, String str, String str2, String str3) {
        a(activity, str, str2, f.ScoreMode, str3);
    }
}
