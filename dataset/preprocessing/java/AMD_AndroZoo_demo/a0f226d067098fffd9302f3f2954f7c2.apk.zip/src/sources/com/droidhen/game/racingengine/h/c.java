package com.droidhen.game.racingengine.h;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c {
    private static SharedPreferences a;

    public static b a(Context context, e[] eVarArr) {
        return a(context) ? d.a(context, eVarArr) : new a();
    }

    public static boolean a(Context context) {
        b(context);
        return a.getBoolean("sound_enabled", true);
    }

    private static void b(Context context) {
        if (a == null) {
            a = PreferenceManager.getDefaultSharedPreferences(context);
        }
    }
}
