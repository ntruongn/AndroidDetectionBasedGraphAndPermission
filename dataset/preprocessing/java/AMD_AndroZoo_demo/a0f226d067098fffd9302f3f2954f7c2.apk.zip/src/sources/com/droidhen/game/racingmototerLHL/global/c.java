package com.droidhen.game.racingmototerLHL.global;

import android.hardware.SensorListener;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c implements SensorListener {
    private float a;
    private com.droidhen.game.racingmototerLHL.f b;

    public c(com.droidhen.game.racingmototerLHL.f fVar) {
        this.b = fVar;
    }

    @Override // android.hardware.SensorListener
    public void onAccuracyChanged(int i, int i2) {
    }

    @Override // android.hardware.SensorListener
    public void onSensorChanged(int i, float[] fArr) {
        this.a = fArr[0];
        this.b.a(-this.a);
    }
}
