package com.droidhen.api.scoreclient.ui;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a implements View.OnClickListener {
    private final /* synthetic */ EditText a;
    private final /* synthetic */ Activity b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(EditText editText, Activity activity) {
        this.a = editText;
        this.b = activity;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        g gVar;
        int i;
        double d;
        g gVar2;
        String trim = this.a.getText().toString().trim();
        if (trim.length() == 0) {
            Toast.makeText(this.b, "用户名不可为空", 1).show();
            return;
        }
        gVar = c.b;
        if (gVar != null) {
            gVar2 = c.b;
            gVar2.a(trim);
        } else {
            System.err.println("listener is null!!!!");
        }
        Intent intent = new Intent(this.b, (Class<?>) HighScoresActivity.class);
        i = c.c;
        intent.putExtra("mode", i);
        intent.putExtra("submit", true);
        d = c.d;
        intent.putExtra("score", d);
        this.b.startActivity(intent);
        try {
            this.b.dismissDialog(1111);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
