package com.droidhen.game.racingmototerLHL.hnxiw;

import android.content.Context;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class pj {
    private static byte[] d = {54, 120, 57, 120, 85, 122, 121, 50, 65, 48, 107, 56, 52, 50, 102, 108};
    private static byte[] e = {106};
    static String a = new String(new byte[]{b(41), b(45), b(53)});
    public static HashMap b = new HashMap();
    static String c = new String(new byte[]{b(53), b(48), b(41), b(31), b(50)}) + a;
    private static String f = new String(new byte[]{c(46), c(112), c(110), c(103)});
    private static String g = new String(a());
    private static final String h = g;

    public pj(Context context) {
        try {
            InputStream open = context.getAssets().open(new String(e) + f);
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            DataInputStream dataInputStream = new DataInputStream(new ByteArrayInputStream(b(h.getBytes(), bArr)));
            int readInt = dataInputStream.readInt();
            for (String readUTF = dataInputStream.readUTF(); readUTF != null; readUTF = dataInputStream.readUTF()) {
                b.put(Integer.valueOf(readInt), readUTF);
                readInt = dataInputStream.readInt();
            }
            dataInputStream.close();
        } catch (FileNotFoundException e2) {
        } catch (IOException e3) {
        } catch (Exception e4) {
        }
    }

    public static String a(int i) {
        return (String) b.get(Integer.valueOf(i));
    }

    public static String a(String str) {
        return a(str.getBytes());
    }

    public static String a(String str, String str2) {
        return a(a(b(str.getBytes()), str2.getBytes()));
    }

    public static String a(byte[] bArr) {
        if (bArr == null) {
            return "";
        }
        StringBuffer stringBuffer = new StringBuffer(bArr.length * 2);
        for (byte b2 : bArr) {
            a(stringBuffer, b2);
        }
        return stringBuffer.toString().toLowerCase();
    }

    private static void a(StringBuffer stringBuffer, byte b2) {
        stringBuffer.append(h.charAt((b2 >> 4) & 15)).append(h.charAt(b2 & 15));
    }

    private static byte[] a() {
        return d;
    }

    private static byte[] a(byte[] bArr, byte[] bArr2) {
        SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, a);
        Cipher cipher = Cipher.getInstance(a);
        cipher.init(1, secretKeySpec);
        return cipher.doFinal(bArr2);
    }

    private static byte b(int i) {
        return Byte.parseByte(i + "", 16);
    }

    public static String b(String str) {
        return new String(c(str));
    }

    public static String b(String str, String str2) {
        return new String(b(b(str.getBytes()), c(str2)));
    }

    private static byte[] b(byte[] bArr) {
        KeyGenerator keyGenerator = KeyGenerator.getInstance(a);
        SecureRandom secureRandom = SecureRandom.getInstance(c);
        secureRandom.setSeed(bArr);
        keyGenerator.init(128, secureRandom);
        return keyGenerator.generateKey().getEncoded();
    }

    private static byte[] b(byte[] bArr, byte[] bArr2) {
        SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, a);
        Cipher cipher = Cipher.getInstance(a);
        cipher.init(2, secretKeySpec);
        return cipher.doFinal(bArr2);
    }

    private static byte c(int i) {
        return Byte.parseByte(i + "");
    }

    public static byte[] c(String str) {
        int length = str.length() / 2;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            bArr[i] = Integer.valueOf(str.substring(i * 2, (i * 2) + 2), 16).byteValue();
        }
        return bArr;
    }
}
