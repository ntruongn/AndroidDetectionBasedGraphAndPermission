package com.droidhen.game.racingmototerLHL.a.a;

import com.droidhen.game.racingmototerLHL.GameActivity;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class p implements com.droidhen.game.racingengine.a.g {
    final /* synthetic */ j a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(j jVar) {
        this.a = jVar;
    }

    @Override // com.droidhen.game.racingengine.a.g
    public void a(com.droidhen.game.racingengine.a.d dVar) {
        com.droidhen.game.racingengine.a.d dVar2;
        com.droidhen.game.racingengine.b.c.d dVar3;
        com.droidhen.game.racingengine.a.d dVar4;
        com.droidhen.game.racingengine.b.c.d dVar5;
        com.droidhen.game.racingmototerLHL.global.f.e = !com.droidhen.game.racingmototerLHL.global.f.e;
        if (com.droidhen.game.racingmototerLHL.global.f.e) {
            GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.a);
            dVar4 = this.a.m;
            dVar5 = j.p;
            dVar4.C = dVar5;
        } else {
            dVar2 = this.a.m;
            dVar3 = j.q;
            dVar2.C = dVar3;
        }
        com.droidhen.game.racingmototerLHL.d.a(com.droidhen.game.racingengine.a.a.a(), com.droidhen.game.racingmototerLHL.global.f.e);
    }
}
