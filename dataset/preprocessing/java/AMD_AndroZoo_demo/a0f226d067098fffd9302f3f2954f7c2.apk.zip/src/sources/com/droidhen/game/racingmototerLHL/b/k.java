package com.droidhen.game.racingmototerLHL.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class k extends com.droidhen.game.racingengine.j.a implements Cloneable {
    static com.droidhen.game.racingengine.g.e k = new com.droidhen.game.racingengine.g.e();
    static com.droidhen.game.racingengine.g.c l = new com.droidhen.game.racingengine.g.c();
    static com.droidhen.game.racingengine.g.e m = new com.droidhen.game.racingengine.g.e();
    static com.droidhen.game.racingengine.g.c n = new com.droidhen.game.racingengine.g.c();
    static com.droidhen.game.racingengine.g.c o = new com.droidhen.game.racingengine.g.c();
    static com.droidhen.game.racingengine.g.c p = new com.droidhen.game.racingengine.g.c();
    static com.droidhen.game.racingengine.g.c q = new com.droidhen.game.racingengine.g.c();
    private a D;
    private int E;
    public com.droidhen.game.racingengine.b.a a;
    public d b;
    public com.droidhen.game.racingengine.j.a.a d;
    private com.droidhen.game.racingengine.b.g u;
    private com.droidhen.game.racingengine.b.g v;
    private com.droidhen.game.racingengine.b.g w;
    private com.droidhen.game.racingengine.g.c z = new com.droidhen.game.racingengine.g.c(0.0f, -60.0f, 0.0f);
    private com.droidhen.game.racingengine.g.c A = new com.droidhen.game.racingengine.g.c();
    private float B = 100.0f;
    private com.droidhen.game.racingengine.g.e C = new com.droidhen.game.racingengine.g.e();
    public boolean c = false;
    public com.droidhen.game.racingengine.b.c.d[] e = null;
    public int f = 0;
    public int g = -1;
    private int F = 0;
    public boolean h = true;
    public boolean i = false;
    public boolean j = false;
    boolean r = true;
    boolean s = true;
    private float G = 3000.0f;
    private float H = 2000.0f;

    /* renamed from: I, reason: collision with root package name */
    private float f2I = 50.0f;
    private float J = 30.0f;
    private float K = 15.0f;
    private float[] L = {-g.a, 0.0f, g.a};
    float t = 0.0f;
    private com.droidhen.game.racingengine.b.c.d x = com.droidhen.game.racingengine.a.e.a("chedeng_hong");
    private com.droidhen.game.racingengine.b.c.d y = com.droidhen.game.racingengine.a.e.a("9ee61e203fcf");

    public k(com.droidhen.game.racingengine.b.a aVar, com.droidhen.game.racingengine.b.g gVar) {
        this.a = aVar;
        this.w = gVar;
        this.u = aVar.a("qiche_weideng_L");
        this.v = aVar.a("qiche_weideng_R");
    }

    private void a(float f, com.droidhen.game.racingengine.b.b.b bVar) {
        n.a((1.8f / com.droidhen.game.racingengine.g.f.d(f)) * 50.0f, 1.8f, 0.0f);
        com.droidhen.game.racingengine.g.c d = com.droidhen.game.racingengine.g.c.d();
        float c = ((((f / com.droidhen.game.racingengine.g.f.c(f)) * this.z.a(bVar.c(), d).b()) * 1000.0f) / n.b()) * 57.295776f;
        com.droidhen.game.racingengine.g.c.f(d);
        n.a(this.B, p);
        this.a.o.a(p, o);
        m.b(o);
        l.a(0.0f, 0.0f, c);
        k.a(l);
        com.droidhen.game.racingengine.g.e d2 = com.droidhen.game.racingengine.g.e.d();
        com.droidhen.game.racingengine.g.e d3 = com.droidhen.game.racingengine.g.e.d();
        com.droidhen.game.racingengine.g.e.a(m, k, d2);
        com.droidhen.game.racingengine.g.e.a(m, d3);
        com.droidhen.game.racingengine.g.e.a(d2, d3, this.C);
        com.droidhen.game.racingengine.g.e.d(d2);
        com.droidhen.game.racingengine.g.e.d(d3);
        this.a.o.b(this.C);
    }

    private void i() {
        this.v.i = false;
        this.u.i = false;
        this.r = true;
        this.s = true;
        this.D = a.GearNormal;
    }

    public synchronized void a() {
        com.droidhen.game.racingengine.b.b.b g = com.droidhen.game.racingengine.a.b.g();
        this.J = (com.droidhen.game.racingmototerLHL.f.f.c / 4.0f) * 3.0f;
        if (this.j && this.z.b < (-this.J)) {
            this.z.b += 2.0f;
        }
        if (this.D == a.TurnLeft) {
            this.v.i = false;
            this.u.a(this.y);
            this.u.i = true;
            if (this.r) {
                a(0.27925268f, g);
                if (this.a.o.d(n).a >= this.L[this.E] + (g.a / 2.0f)) {
                    this.r = false;
                    this.E++;
                }
            } else {
                a(-0.19198622f, g);
                if (this.a.o.d(n).a >= this.L[this.E]) {
                    i();
                }
            }
        } else if (this.D == a.TurnRight) {
            this.v.a(this.y);
            this.v.i = true;
            this.u.i = false;
            if (this.r) {
                a(-0.27925268f, g);
                if (this.a.o.d(n).a <= this.L[this.E] - (g.a / 2.0f)) {
                    this.r = false;
                    this.E--;
                }
            } else {
                a(0.19198622f, g);
                if (this.a.o.d(n).a <= this.L[this.E]) {
                    i();
                }
            }
        } else {
            if (this.F > 0) {
                this.F--;
            } else {
                this.u.i = false;
                this.v.i = false;
            }
            this.z.a(g.c() * 1000.0f * this.B, q);
            this.C.b(q);
            this.a.o.b(this.C);
        }
        if (this.f > 0) {
            this.f--;
        }
    }

    public void a(float f) {
        this.z.b -= f;
    }

    public void a(com.droidhen.game.racingengine.j.a.b bVar) {
        this.d = new o(this, 203.0f, 220.0f, 70.0f, 185.0f);
        this.d.a(this);
        bVar.b(this.d);
    }

    public void a(m mVar) {
        a(mVar, false, null, null);
    }

    public void a(m mVar, boolean z) {
        a(mVar, z, null, null);
    }

    public synchronized void a(m mVar, boolean z, com.droidhen.game.racingengine.g.c cVar, com.droidhen.game.racingengine.g.c cVar2) {
        float a;
        int a2 = (int) (com.droidhen.game.racingengine.g.f.a() * 3.0f);
        if (mVar == m.FRONT) {
            int a3 = com.droidhen.game.racingengine.g.f.a(0, 44);
            a = ((-com.droidhen.game.racingmototerLHL.global.f.d) - this.G) - ((a3 / 3) * 200.0f);
            a2 = a3 % 3;
        } else {
            a = mVar == m.INIT ? ((-com.droidhen.game.racingmototerLHL.global.f.d) - this.H) - (com.droidhen.game.racingengine.g.f.a() * g.b) : 0.0f;
        }
        if (this.e != null) {
            this.w.a(this.e[(int) (com.droidhen.game.racingengine.g.f.a() * this.e.length)]);
        }
        this.E = a2;
        this.D = a.GearNormal;
        this.s = true;
        this.r = true;
        this.u.a(this.y);
        this.v.a(this.y);
        this.h = true;
        this.i = false;
        this.c = false;
        if (cVar2 != null) {
            this.z.a(cVar2);
        } else if (g.e[this.E] != 0.0f) {
            this.z.b = g.e[this.E];
        } else {
            this.z.b = (-this.f2I) - (this.K * (com.droidhen.game.racingengine.g.f.a() - 0.5f));
            g.e[this.E] = this.z.b;
        }
        if (cVar == null) {
            com.droidhen.game.racingengine.g.c d = com.droidhen.game.racingengine.g.c.d();
            d.a(this.L[a2], a, 0.0f);
            this.C.b(d);
            com.droidhen.game.racingengine.g.c.f(d);
        } else {
            this.C.b(cVar);
        }
        this.a.o.c(this.C);
        this.u.i = false;
        this.v.i = false;
    }

    public void b() {
        if ((this.f <= 0 || this.g != this.E - 1) && this.s) {
            this.D = a.TurnRight;
            this.s = false;
        }
    }

    public void b(float f) {
        float f2 = f < 0.0f ? -f : f;
        if (this.z.b < (-this.J)) {
            com.droidhen.game.racingengine.g.c cVar = this.z;
            cVar.b = f2 + cVar.b;
        }
        this.F = 4;
        this.u.a(this.x);
        this.u.i = true;
        this.v.a(this.x);
        this.v.i = true;
    }

    public void c() {
        if ((this.f <= 0 || this.g != this.E + 1) && this.s) {
            this.D = a.TurnLeft;
            this.s = false;
        }
    }

    public void c(float f) {
        this.f2I = f;
    }

    public void d() {
        b(2.0f);
    }

    public void e() {
        if (this.z.b < (-com.droidhen.game.racingmototerLHL.f.f.c) / 2.0f) {
            this.z.b += 2.0f;
        }
    }

    public a f() {
        return this.D;
    }

    public int g() {
        return this.E;
    }

    /* renamed from: h, reason: merged with bridge method [inline-methods] */
    public k clone() {
        com.droidhen.game.racingengine.b.a clone = this.a.clone();
        k kVar = new k(clone, (com.droidhen.game.racingengine.b.g) clone.d.get(1));
        kVar.e = new com.droidhen.game.racingengine.b.c.d[this.e.length];
        System.arraycopy(this.e, 0, kVar.e, 0, this.e.length);
        kVar.b = this.b;
        return kVar;
    }
}
