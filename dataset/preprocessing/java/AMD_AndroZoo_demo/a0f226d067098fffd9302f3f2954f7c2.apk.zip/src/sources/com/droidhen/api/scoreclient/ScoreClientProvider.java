package com.droidhen.api.scoreclient;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class ScoreClientProvider extends ContentProvider {
    private d c;
    private static final UriMatcher b = new UriMatcher(-1);
    static final b a = new b(null);

    public static void a() {
        b.addURI(com.droidhen.api.scoreclient.c.b.a, "score", 1);
        b.addURI(com.droidhen.api.scoreclient.c.b.a, "score/#", 2);
    }

    private void a(Uri uri, int i, String str, b bVar) {
        switch (i) {
            case 1:
                bVar.a = "score";
                break;
            case 2:
                bVar.a = "score";
                bVar.b = "_id=" + uri.getPathSegments().get(1);
                break;
            default:
                throw new UnsupportedOperationException("Unknown or unsupported URL: " + uri.toString());
        }
        if (TextUtils.isEmpty(str)) {
            return;
        }
        if (TextUtils.isEmpty(bVar.b)) {
            bVar.b = str;
        } else {
            bVar.b = String.valueOf(bVar.b) + " AND (" + str + ")";
        }
    }

    @Override // android.content.ContentProvider
    public int delete(Uri uri, String str, String[] strArr) {
        int delete;
        int match = b.match(uri);
        if (this.c == null) {
            throw new UnsupportedOperationException("Unknown URI: " + uri);
        }
        SQLiteDatabase writableDatabase = this.c.getWritableDatabase();
        synchronized (a) {
            a(uri, match, str, a);
            delete = writableDatabase.delete(a.a, a.b, strArr);
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return delete;
    }

    @Override // android.content.ContentProvider
    public String getType(Uri uri) {
        return null;
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues contentValues) {
        Uri withAppendedId;
        if (contentValues == null) {
            return null;
        }
        SQLiteDatabase writableDatabase = this.c.getWritableDatabase();
        switch (b.match(uri)) {
            case 1:
                long insert = writableDatabase.insert("score", null, contentValues);
                if (insert > 0) {
                    withAppendedId = ContentUris.withAppendedId(uri, insert);
                    break;
                }
            default:
                withAppendedId = null;
                break;
        }
        if (withAppendedId == null) {
            return withAppendedId;
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return withAppendedId;
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        this.c = new d(getContext());
        return true;
    }

    @Override // android.content.ContentProvider
    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        SQLiteQueryBuilder sQLiteQueryBuilder = new SQLiteQueryBuilder();
        switch (b.match(uri)) {
            case 1:
                sQLiteQueryBuilder.setTables("score");
                break;
            case 2:
                sQLiteQueryBuilder.setTables("score");
                sQLiteQueryBuilder.appendWhere("score._id = " + uri.getPathSegments().get(1));
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        Cursor query = sQLiteQueryBuilder.query(this.c.getReadableDatabase(), strArr, str, strArr2, null, null, str2);
        if (query != null) {
            query.setNotificationUri(getContext().getContentResolver(), uri);
        }
        return query;
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        int update;
        int match = b.match(uri);
        if (this.c == null) {
            throw new UnsupportedOperationException("Unknown URI: " + uri);
        }
        SQLiteDatabase writableDatabase = this.c.getWritableDatabase();
        synchronized (a) {
            a(uri, match, str, a);
            update = writableDatabase.update(a.a, contentValues, a.b, strArr);
        }
        if (update > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return update;
    }
}
