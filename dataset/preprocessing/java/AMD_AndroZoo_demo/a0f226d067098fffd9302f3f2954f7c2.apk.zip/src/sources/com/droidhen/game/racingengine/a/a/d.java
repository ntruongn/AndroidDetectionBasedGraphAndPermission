package com.droidhen.game.racingengine.a.a;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public abstract class d extends com.droidhen.game.racingengine.a.a {
    protected static float[] n = {0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f};
    protected static short[] o = {0, 1, 3, 1, 2, 3};
    protected static float[] p = {1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f};
    public float[] q;
    public float[] r;
    protected float s = 0.0f;
    protected float t = 0.0f;
    protected boolean u = true;

    public d() {
        this.q = null;
        this.r = null;
        this.q = new float[12];
        this.r = new float[8];
        this.D = 6;
    }

    @Override // com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        super.a();
        k(this.E, this.F);
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        boolean z;
        if (this.z) {
            c();
            if (this.B != 1.0f) {
                z = true;
                gl10.glColor4f(1.0f, 1.0f, 1.0f, this.B);
            } else {
                z = false;
            }
            gl10.glBindTexture(3553, this.C.a);
            gl10.glPushMatrix();
            gl10.glTranslatef(this.G.a, this.G.b, 0.0f);
            gl10.glTranslatef(this.f0I, this.J, 0.0f);
            this.M.position(0);
            gl10.glTexCoordPointer(2, 5126, 0, this.M);
            this.N.position(0);
            gl10.glVertexPointer(3, 5126, 0, this.N);
            this.O.position(0);
            gl10.glDrawElements(4, this.D, 5123, this.O);
            gl10.glPopMatrix();
            if (z) {
                gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
    }

    public void b(int i) {
        this.M = com.droidhen.game.racingengine.f.a.a(i * 32).asFloatBuffer();
        this.N = com.droidhen.game.racingengine.f.a.a(i * 48).asFloatBuffer();
        this.O = com.droidhen.game.racingengine.f.a.a(i * 12).asShortBuffer();
    }

    public void b(com.droidhen.game.racingengine.b.c.d dVar) {
        this.C = dVar;
        this.s = dVar.g;
        this.t = dVar.h;
        i(0.0f, this.s);
        j(0.0f, this.t);
        this.u = true;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
    }

    public void f(float f, float f2) {
        this.f0I = this.E * f;
        this.J = this.F * f2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void g(float f, float f2) {
        float[] fArr = this.q;
        this.q[10] = f;
        fArr[1] = f;
        float[] fArr2 = this.q;
        this.q[7] = f2;
        fArr2[4] = f2;
    }

    public void h() {
        this.M = com.droidhen.game.racingengine.f.a.a(32).asFloatBuffer();
        this.N = com.droidhen.game.racingengine.f.a.a(48).asFloatBuffer();
        this.O = com.droidhen.game.racingengine.f.a.a(12).asShortBuffer();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void h(float f, float f2) {
        float[] fArr = this.q;
        this.q[3] = f;
        fArr[0] = f;
        float[] fArr2 = this.q;
        this.q[9] = f2;
        fArr2[6] = f2;
    }

    protected void i(float f, float f2) {
        float[] fArr = this.r;
        this.r[2] = f;
        fArr[0] = f;
        float[] fArr2 = this.r;
        this.r[6] = f2;
        fArr2[4] = f2;
    }

    protected void j(float f, float f2) {
        float[] fArr = this.r;
        this.r[7] = f;
        fArr[1] = f;
        float[] fArr2 = this.r;
        this.r[5] = f2;
        fArr2[3] = f2;
    }

    public void k(float f, float f2) {
        this.E = f;
        this.F = f2;
        h(0.0f, f);
        g(f2, 0.0f);
        this.u = true;
    }
}
