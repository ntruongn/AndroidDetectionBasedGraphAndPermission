package com.droidhen.game.racingmototerLHL.a.a;

import javax.microedition.khronos.opengles.GL10;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class o extends com.droidhen.game.racingengine.a.a {
    final /* synthetic */ k d;
    private al e;

    public o(k kVar) {
        this.d = kVar;
        al alVar = new al();
        alVar.a(400.0f, 600.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        a(alVar);
    }

    @Override // com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.P.size()) {
                return;
            }
            ((com.droidhen.game.racingengine.a.l) this.P.get(i2)).a();
            i = i2 + 1;
        }
    }

    public void a(int i, int i2) {
        int i3 = 0;
        while (true) {
            int i4 = i3;
            if (i4 < this.P.size()) {
                this.e = (al) this.P.get(i4);
                if (!this.e.z) {
                    break;
                } else {
                    i3 = i4 + 1;
                }
            } else {
                break;
            }
        }
        if (this.e.z) {
            this.e = this.e.clone();
            a(this.e);
        }
        this.e.a(i, i2);
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.P.size()) {
                return;
            }
            ((com.droidhen.game.racingengine.a.l) this.P.get(i2)).a(gl10);
            i = i2 + 1;
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void e() {
    }
}
