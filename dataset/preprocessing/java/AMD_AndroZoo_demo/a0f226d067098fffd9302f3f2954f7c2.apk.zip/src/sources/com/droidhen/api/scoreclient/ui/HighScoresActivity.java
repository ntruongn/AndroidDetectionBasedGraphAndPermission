package com.droidhen.api.scoreclient.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class HighScoresActivity extends Activity implements View.OnClickListener {
    private ListView b;
    private h c;
    private com.droidhen.api.scoreclient.a.b h;
    private List i;
    private f j;
    private int k;
    private int l;
    private int m;
    private double n;
    private LinearLayout q;
    private ImageView r;
    private TextView s;
    private TextView t;
    private LinearLayout u;
    private Toast v;
    private Button[] d = new Button[6];
    private int e = 0;
    private int f = 6;
    private Button[] g = new Button[3];
    private boolean o = false;
    private boolean p = false;
    private int w = 0;
    private int x = 20;
    private int y = 0;
    private View.OnClickListener z = new j(this);
    private int A = 0;
    private int B = 0;
    Handler a = new l(this);
    private q C = null;
    private d D = null;

    /* JADX INFO: Access modifiers changed from: private */
    public void a() {
        this.i = this.h.c();
        this.j = new f(this, this, 2130903043, this.i);
        this.b.setAdapter((ListAdapter) this.j);
        this.w = this.h.f();
        this.y = this.h.e();
        if (this.w > 0) {
            this.A = 1;
        } else {
            this.A = 0;
        }
        if (this.w + this.x < this.y) {
            this.B = 1;
        } else {
            this.B = 0;
        }
        com.droidhen.api.scoreclient.b.b d = this.h.d();
        if (d == null) {
            this.p = true;
            this.q.setVisibility(0);
            this.r.setVisibility(8);
            this.u.setVisibility(8);
            this.s.setVisibility(0);
            this.t.setVisibility(0);
            this.s.setText(i.a().a());
            return;
        }
        this.p = false;
        this.q.setVisibility(0);
        this.r.setVisibility(0);
        this.u.setVisibility(0);
        this.s.setVisibility(8);
        this.t.setVisibility(8);
        TextView textView = (TextView) findViewById(2131230756);
        TextView textView2 = (TextView) findViewById(2131230757);
        TextView textView3 = (TextView) findViewById(2131230758);
        textView.setText(String.valueOf(d.d()), (TextView.BufferType) null);
        textView2.setText(d.c(), (TextView.BufferType) null);
        if (this.k == 1) {
            textView3.setText(String.valueOf(d.a()), (TextView.BufferType) null);
        } else {
            textView3.setText(String.valueOf((int) d.a()), (TextView.BufferType) null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(double d, int i) {
        if (this.C == null) {
            a(true);
            this.C = new q(this, d, i);
            this.C.start();
        }
    }

    private void a(int i) {
        Resources resources = getResources();
        int color = resources.getColor(2131099650);
        int color2 = resources.getColor(2131099649);
        int color3 = resources.getColor(2131099658);
        int color4 = resources.getColor(2131099659);
        for (int i2 = 0; i2 < this.e; i2++) {
            if (i2 == i) {
                this.d[i2].setBackgroundResource(2130837537);
                this.d[i2].setTextColor(color);
                this.d[i2].setShadowLayer(1.0f, 1.0f, 1.0f, color3);
            } else {
                this.d[i2].setBackgroundResource(2130837536);
                this.d[i2].setTextColor(color2);
                this.d[i2].setShadowLayer(1.0f, 1.0f, 1.0f, color4);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(int i, int i2, int i3) {
        if (this.D == null) {
            a(true);
            this.D = new d(this, i, i2, i3);
            this.D.start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(boolean z) {
        ProgressBar progressBar = (ProgressBar) findViewById(2131230761);
        if (z) {
            progressBar.setVisibility(0);
        } else {
            progressBar.setVisibility(8);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b() {
        if (this.m == 0) {
            c(this.l);
            return;
        }
        this.o = false;
        this.w = 0;
        if (this.m == 2) {
            a(this.w, this.x, 1);
        } else {
            a(this.w, this.x, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b(int i) {
        for (int i2 = 0; i2 < 3; i2++) {
            if (i2 == i) {
                if (i2 == 0) {
                    this.g[i2].setBackgroundResource(2130837557);
                } else if (i2 == 2) {
                    this.g[i2].setBackgroundResource(2130837559);
                } else {
                    this.g[i2].setBackgroundResource(2130837558);
                }
            } else if (i2 == 0) {
                this.g[i2].setBackgroundResource(2130837551);
            } else if (i2 == 2) {
                this.g[i2].setBackgroundResource(2130837556);
            } else {
                this.g[i2].setBackgroundResource(2130837552);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c(int i) {
        this.A = 0;
        this.B = 0;
        this.q.setVisibility(8);
        this.i = this.h.b(i);
        this.j = new f(this, this, 2130903043, this.i);
        this.b.setAdapter((ListAdapter) this.j);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        if (this.C == null && this.D == null) {
            switch (view.getId()) {
                case 2131230742:
                    if (this.l != 0) {
                        this.l = 0;
                        a(this.l);
                        b();
                        return;
                    }
                    return;
                case 2131230743:
                    if (this.l != 1) {
                        this.l = 1;
                        a(this.l);
                        b();
                        return;
                    }
                    return;
                case 2131230744:
                    if (this.l != 2) {
                        this.l = 2;
                        a(this.l);
                        b();
                        return;
                    }
                    return;
                case 2131230745:
                case 2131230746:
                case 2131230747:
                case 2131230752:
                case 2131230753:
                case 2131230754:
                case 2131230755:
                case 2131230756:
                case 2131230757:
                case 2131230758:
                case 2131230759:
                case 2131230760:
                case 2131230761:
                default:
                    return;
                case 2131230748:
                    if (this.m != 0) {
                        this.m = 0;
                        b(this.m);
                        c(this.l);
                        return;
                    }
                    return;
                case 2131230749:
                    if (this.m != 1) {
                        this.m = 1;
                        b(this.m);
                        this.o = false;
                        this.w = 0;
                        a(this.w, this.x, 0);
                        return;
                    }
                    return;
                case 2131230750:
                    if (this.m != 2) {
                        this.m = 2;
                        b(this.m);
                        this.o = false;
                        this.w = 0;
                        a(this.w, this.x, 1);
                        return;
                    }
                    return;
                case 2131230751:
                    if (this.p) {
                        return;
                    }
                    this.o = true;
                    if (this.m == 2) {
                        a(0, this.x, 1);
                        return;
                    } else {
                        a(0, this.x, 0);
                        return;
                    }
                case 2131230762:
                    if (this.l != 3) {
                        this.l = 3;
                        a(this.l);
                        b();
                        return;
                    }
                    return;
                case 2131230763:
                    if (this.l != 4) {
                        this.l = 4;
                        a(this.l);
                        b();
                        return;
                    }
                    return;
                case 2131230764:
                    if (this.l != 5) {
                        this.l = 5;
                        a(this.l);
                        b();
                        return;
                    }
                    return;
            }
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2130903043);
        this.b = (ListView) findViewById(2131230759);
        this.d[0] = (Button) findViewById(2131230742);
        this.d[1] = (Button) findViewById(2131230743);
        this.d[2] = (Button) findViewById(2131230744);
        this.d[3] = (Button) findViewById(2131230762);
        this.d[4] = (Button) findViewById(2131230763);
        this.d[5] = (Button) findViewById(2131230764);
        this.g[0] = (Button) findViewById(2131230748);
        this.g[1] = (Button) findViewById(2131230749);
        this.g[2] = (Button) findViewById(2131230750);
        this.q = (LinearLayout) findViewById(2131230751);
        this.q.setOnClickListener(this);
        this.r = (ImageView) findViewById(2131230752);
        this.s = (TextView) findViewById(2131230753);
        this.t = (TextView) findViewById(2131230754);
        this.u = (LinearLayout) findViewById(2131230755);
        if (this.d[3] == null) {
            this.f = 3;
        }
        this.c = h.a(i.a());
        this.h = this.c.e();
        this.k = this.h.b();
        p f = this.c.f();
        if (f != null) {
            ((LinearLayout) findViewById(2131230740)).setBackgroundColor(f.a());
        }
        e c = this.c.c();
        TextView textView = (TextView) findViewById(2131230730);
        ImageView imageView = (ImageView) findViewById(2131230729);
        if (c != null) {
            try {
                textView.setText(c.a(), (TextView.BufferType) null);
                imageView.setImageBitmap(BitmapFactory.decodeStream(getAssets().open(c.b())));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                String packageName = getPackageName();
                PackageManager packageManager = getPackageManager();
                textView.setText(packageManager.getApplicationLabel(getApplicationInfo()));
                imageView.setImageDrawable(packageManager.getApplicationIcon(packageName));
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        Intent intent = getIntent();
        this.l = intent.getIntExtra("mode", 0);
        boolean booleanExtra = intent.getBooleanExtra("submit", false);
        this.n = intent.getDoubleExtra("score", 0.0d);
        boolean booleanExtra2 = intent.getBooleanExtra("global", false);
        this.m = intent.getIntExtra("board", 0);
        if (bundle != null) {
            if (bundle.containsKey("mode")) {
                this.l = bundle.getInt("mode");
            }
            if (bundle.containsKey("board")) {
                this.m = bundle.getInt("board");
            }
        }
        if (booleanExtra) {
            this.m = 1;
        }
        if (booleanExtra || booleanExtra2) {
            ((RelativeLayout) findViewById(2131230746)).setVisibility(8);
            ((LinearLayout) findViewById(2131230747)).setVisibility(0);
            for (int i = 0; i < 3; i++) {
                this.g[i].setOnClickListener(this);
            }
            b(this.m);
        }
        List a = this.h.a();
        this.e = a.size();
        LinearLayout linearLayout = (LinearLayout) findViewById(2131230741);
        Spinner spinner = (Spinner) findViewById(2131230745);
        if (spinner == null || this.e <= this.f) {
            for (int i2 = this.e; i2 < this.f; i2++) {
                if (this.d[i2] != null) {
                    this.d[i2].setVisibility(8);
                }
            }
            for (int i3 = 0; i3 < this.e; i3++) {
                if (this.d[i3] != null) {
                    this.d[i3].setText(((com.droidhen.api.scoreclient.b.c) a.get(i3)).a());
                    this.d[i3].setOnClickListener(this);
                }
            }
            a(this.l);
        } else {
            spinner.setVisibility(0);
            linearLayout.setVisibility(8);
            ArrayList arrayList = new ArrayList();
            for (int i4 = 0; i4 < this.e; i4++) {
                arrayList.add(((com.droidhen.api.scoreclient.b.c) a.get(i4)).a());
            }
            ArrayAdapter arrayAdapter = new ArrayAdapter(this, 17367048, arrayList);
            arrayAdapter.setDropDownViewResource(17367049);
            spinner.setAdapter((SpinnerAdapter) arrayAdapter);
            spinner.setSelection(this.l);
            spinner.setOnItemSelectedListener(new k(this));
        }
        this.w = 0;
        if (booleanExtra) {
            a();
            a(this.n, this.l);
            this.o = true;
        } else if (!booleanExtra2 || this.m == 0) {
            c(this.l);
        } else {
            a();
            if (this.m == 2) {
                a(this.w, this.x, 1);
            } else {
                a(this.w, this.x, 0);
            }
            this.o = false;
        }
        LinearLayout linearLayout2 = (LinearLayout) findViewById(2131230760);
        com.droidhen.api.scoreclient.c cVar = c.a;
        if (cVar == null || linearLayout2 == null) {
            return;
        }
        cVar.b(this, linearLayout2);
    }

    @Override // android.app.Activity
    protected Dialog onCreateDialog(int i) {
        switch (i) {
            case 1:
                return new AlertDialog.Builder(this).setMessage(2131034119).setPositiveButton(2131034120, new n(this)).setNegativeButton(2131034121, new m(this)).create();
            default:
                return super.onCreateDialog(i);
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        switch (i) {
            case 82:
            case 84:
                return true;
            case 83:
            default:
                return super.onKeyDown(i, keyEvent);
        }
    }

    @Override // android.app.Activity
    protected void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("mode", this.l);
        bundle.putInt("board", this.m);
        super.onSaveInstanceState(bundle);
    }
}
