package com.droidhen.api.promptclient.prompt;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class g {
    private static SharedPreferences a;

    public static synchronized long a(Context context) {
        long j;
        synchronized (g.class) {
            c(context);
            j = a.getLong("last_rate", 0L);
        }
        return j;
    }

    public static synchronized void a(Context context, long j) {
        synchronized (g.class) {
            c(context);
            SharedPreferences.Editor edit = a.edit();
            edit.putLong("last_rate", j);
            edit.commit();
        }
    }

    public static synchronized void a(Context context, boolean z) {
        synchronized (g.class) {
            c(context);
            SharedPreferences.Editor edit = a.edit();
            edit.putBoolean("rate_clicked", z);
            edit.commit();
        }
    }

    public static synchronized boolean b(Context context) {
        boolean z;
        synchronized (g.class) {
            c(context);
            z = a.getBoolean("rate_clicked", false);
        }
        return z;
    }

    private static void c(Context context) {
        if (a == null) {
            a = context.getSharedPreferences("config", 0);
        }
    }
}
