package com.google.ads;

import com.google.ads.AdRequest;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public interface AdListener {
    void onDismissScreen(Ad ad);

    void onFailedToReceiveAd(Ad ad, AdRequest.ErrorCode errorCode);

    void onLeaveApplication(Ad ad);

    void onPresentScreen(Ad ad);

    void onReceiveAd(Ad ad);
}
