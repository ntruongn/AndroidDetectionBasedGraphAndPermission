package com.droidhen.game.racingmototerLHL.b;

import com.droidhen.game.racingmototerLHL.GameActivity;
import com.droidhen.game.racingmototerLHL.a.a.y;
import java.util.ArrayList;
import java.util.Timer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class h {
    public static float f = 70.0f;
    public static float g = 120.0f;
    private com.droidhen.game.racingengine.b.g A;
    private com.droidhen.game.racingengine.b.g B;
    private a C;
    private float F;
    public com.droidhen.game.racingengine.b.a a;
    private com.droidhen.game.racingengine.b.g w;
    private com.droidhen.game.racingengine.b.g x;
    private com.droidhen.game.racingengine.b.g y;
    private com.droidhen.game.racingengine.b.g z;
    public com.droidhen.game.racingengine.g.c b = new com.droidhen.game.racingengine.g.c(0.0f, -90.0f, 0.0f);
    private com.droidhen.game.racingengine.g.c D = new com.droidhen.game.racingengine.g.c();
    private com.droidhen.game.racingengine.g.c E = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c c = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c d = new com.droidhen.game.racingengine.g.c(0.0f, 56.0f, 0.0f);
    public com.droidhen.game.racingengine.g.c e = new com.droidhen.game.racingengine.g.c();
    private float G = 0.2617994f;
    private float H = 0.05f;

    /* renamed from: I, reason: collision with root package name */
    private float f1I = 100.0f;
    private com.droidhen.game.racingengine.g.e J = new com.droidhen.game.racingengine.g.e();
    float h = 0.0f;
    Timer i = null;
    com.droidhen.game.racingengine.g.e j = new com.droidhen.game.racingengine.g.e();
    com.droidhen.game.racingengine.g.e k = new com.droidhen.game.racingengine.g.e();
    com.droidhen.game.racingengine.g.c l = new com.droidhen.game.racingengine.g.c();
    com.droidhen.game.racingengine.g.e m = new com.droidhen.game.racingengine.g.e();
    com.droidhen.game.racingengine.g.e n = new com.droidhen.game.racingengine.g.e();
    com.droidhen.game.racingengine.g.c o = new com.droidhen.game.racingengine.g.c();
    com.droidhen.game.racingengine.g.c p = new com.droidhen.game.racingengine.g.c();
    com.droidhen.game.racingengine.g.c q = new com.droidhen.game.racingengine.g.c();
    int r = 0;
    int s = 0;
    float[] t = {0.0f, 5.0f};
    com.droidhen.game.racingengine.b.c.d[] u = null;
    float v = 0.0f;

    public h(com.droidhen.game.racingengine.b.a aVar, int i) {
        a(aVar, i);
    }

    private void h() {
        this.r++;
        if (this.r > 1) {
            this.r = 0;
        }
        this.z.l.a = this.t[this.r];
    }

    private void i() {
        this.v += 0.8f;
        if (this.v >= this.u.length) {
            this.s = 0;
            this.v = 0.0f;
        }
        this.s = (int) this.v;
        this.A.a(this.u[this.s]);
    }

    public com.droidhen.game.racingengine.b.g a() {
        return this.z;
    }

    public void a(float f2) {
        this.h = this.H * f2;
        this.F = ((this.H * f2) + this.F) / 2.0f;
    }

    public void a(com.droidhen.game.racingengine.b.a aVar, int i) {
        i iVar = l.d[i];
        this.a = aVar;
        this.w = aVar.a(iVar.i);
        this.x = aVar.a(iVar.j);
        this.y = aVar.a(iVar.e);
        this.z = aVar.a(iVar.g);
        this.z.i = false;
        this.A = aVar.a(iVar.f);
        this.A.i = false;
        this.B = aVar.a(iVar.h);
        this.a.c = true;
        this.y.p = true;
        ArrayList arrayList = new ArrayList();
        for (String str : iVar.k) {
            arrayList.add(com.droidhen.game.racingengine.a.e.a(str));
        }
        this.u = (com.droidhen.game.racingengine.b.c.d[]) arrayList.toArray(new com.droidhen.game.racingengine.b.c.d[arrayList.size()]);
    }

    public a b() {
        return this.C;
    }

    public void c() {
        if (this.C == a.Crash) {
            return;
        }
        this.C = a.GearUp;
        this.A.i = true;
        this.z.i = true;
        com.droidhen.game.racingmototerLHL.global.f.a().a(y.Smile);
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.f);
    }

    public void d() {
        if (this.C == a.Crash) {
            return;
        }
        this.C = a.GearNormal;
        this.A.i = false;
        this.z.i = false;
        com.droidhen.game.racingmototerLHL.global.f.a().a(y.Normal);
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.g);
    }

    public void e() {
        this.C = a.GearNormal;
        this.F = 0.0f;
        this.w.l.c = 0.0f;
        this.w.l.a = 0.0f;
        this.b.a = 0.0f;
        this.b.b = -f;
        this.k.a();
        this.l.a();
        com.droidhen.game.racingmototerLHL.global.f.d = 0.0f;
        this.B.i = true;
    }

    public void f() {
        com.droidhen.game.racingmototerLHL.global.f.b().p();
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.h);
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.e);
        this.w.l.c = 0.0f;
        this.w.l.a = 0.0f;
        this.b.a = (-this.b.a) / 5.0f;
        this.b.b /= 15.0f;
        if (this.C != a.Crash) {
            com.droidhen.game.racingengine.g.e d = com.droidhen.game.racingengine.g.e.d();
            com.droidhen.game.racingengine.g.e d2 = com.droidhen.game.racingengine.g.e.d();
            d.a();
            com.droidhen.game.racingengine.g.c d3 = com.droidhen.game.racingengine.g.c.d();
            d3.a(0.0f, 0.0f, 0.0f);
            d.b(d3);
            d2.a();
            d3.a(0.0f, 90.0f, 0.0f);
            d2.a(d3);
            com.droidhen.game.racingengine.g.c.f(d3);
            com.droidhen.game.racingengine.g.e d4 = com.droidhen.game.racingengine.g.e.d();
            com.droidhen.game.racingengine.g.e d5 = com.droidhen.game.racingengine.g.e.d();
            com.droidhen.game.racingengine.g.e.a(com.droidhen.game.racingengine.g.e.a(d.a(d4), d2, d5), d, this.J);
            com.droidhen.game.racingengine.g.e.d(d2);
            com.droidhen.game.racingengine.g.e.d(d);
            com.droidhen.game.racingengine.g.e.d(d5);
            com.droidhen.game.racingengine.g.e.d(d4);
            this.k.b(this.J);
        }
        this.C = a.Crash;
    }

    public void g() {
        com.droidhen.game.racingengine.b.b.b g2 = com.droidhen.game.racingengine.a.b.g();
        if (this.C == a.Crash) {
            this.b.a(-0.2f, this.E);
            this.E.a(1.0f, this.D);
            this.A.i = false;
            this.z.i = false;
            this.B.i = false;
            if (this.i == null) {
                this.i = new Timer();
                this.i.schedule(new f(this), 2000L);
            }
        } else if (this.C == a.GearUp) {
            if (this.b.b > (-g)) {
                this.D.b = (-(g - f)) / 2.0f;
            } else {
                this.b.b = -g;
                this.D.b = 0.0f;
            }
        } else if (this.C == a.GearNormal) {
            if (this.b.b < (-f)) {
                this.D.b = (g - f) / 4.0f;
            } else {
                this.b.b = -f;
                this.D.b = 0.0f;
            }
        }
        com.droidhen.game.racingengine.g.c d = com.droidhen.game.racingengine.g.c.d();
        this.b.d(this.D.a(g2.b() * 3.6f, d));
        com.droidhen.game.racingengine.g.c.f(d);
        com.droidhen.game.racingengine.g.c d2 = com.droidhen.game.racingengine.g.c.d();
        float b = ((this.b.a(g2.c(), d2).b() * 1000.0f) / 0.23f) * 57.295776f;
        com.droidhen.game.racingengine.g.c.f(d2);
        this.x.l.a = -b;
        if (com.droidhen.game.racingengine.g.f.c(this.F) > 0.004d) {
            if (this.C != a.Crash) {
                this.b.a = this.F * 90.0f;
                this.k.a();
                this.n.a();
                this.o.a(0.0f, 0.0f, -44.0f);
                this.n.b(this.o);
                this.m.a();
                this.q.a(0.0f, (this.F * 57.295776f) / 0.5f, 0.0f);
                this.m.a(this.q);
                com.droidhen.game.racingengine.g.e d3 = com.droidhen.game.racingengine.g.e.d();
                com.droidhen.game.racingengine.g.e d4 = com.droidhen.game.racingengine.g.e.d();
                com.droidhen.game.racingengine.g.e.a(this.n, this.m, d3);
                com.droidhen.game.racingengine.g.e.a(this.n, d4);
                com.droidhen.game.racingengine.g.e.a(d3, d4, this.J);
                com.droidhen.game.racingengine.g.e.d(d3);
                com.droidhen.game.racingengine.g.e.d(d4);
                this.k.b(this.J);
                this.n.a();
                this.o.a(0.0f, 60.0f, 0.0f);
                this.n.b(this.o);
                this.m.a();
                this.q.a(0.0f, 0.0f, (this.F * 57.295776f) / 0.8f);
                this.m.a(this.q);
                com.droidhen.game.racingengine.g.e d5 = com.droidhen.game.racingengine.g.e.d();
                com.droidhen.game.racingengine.g.e d6 = com.droidhen.game.racingengine.g.e.d();
                com.droidhen.game.racingengine.g.e.a(this.n, this.m, d5);
                com.droidhen.game.racingengine.g.e.a(this.n, d6);
                com.droidhen.game.racingengine.g.e.a(d5, d6, this.J);
                com.droidhen.game.racingengine.g.e.d(d5);
                com.droidhen.game.racingengine.g.e.d(d6);
                this.k.b(this.J);
            }
            com.droidhen.game.racingengine.g.c d7 = com.droidhen.game.racingengine.g.c.d();
            this.l.d(this.b.a(g2.c() * 1000.0f * this.f1I, d2));
            com.droidhen.game.racingengine.g.c.f(d7);
        } else {
            if (this.C != a.Crash) {
                this.b.a = 0.0f;
                this.w.l.c = 0.0f;
                this.k.a();
            }
            com.droidhen.game.racingengine.g.c d8 = com.droidhen.game.racingengine.g.c.d();
            this.l.d(this.b.a(g2.c() * 1000.0f * this.f1I, d2));
            com.droidhen.game.racingengine.g.c.f(d8);
        }
        this.n.b(this.l);
        com.droidhen.game.racingengine.g.e.a(this.n, this.k, this.j);
        this.a.o.c(this.j);
        this.j.d(this.p);
        com.droidhen.game.racingmototerLHL.global.f.d = -this.p.b;
        if (this.C != a.Crash) {
            h();
            i();
        }
    }
}
