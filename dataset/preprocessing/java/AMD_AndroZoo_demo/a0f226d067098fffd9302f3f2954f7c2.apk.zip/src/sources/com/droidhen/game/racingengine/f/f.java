package com.droidhen.game.racingengine.f;

import java.util.Comparator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class f implements Comparator {
    @Override // java.util.Comparator
    public int compare(Object obj, Object obj2) {
        int length = obj instanceof g ? ((g) obj).a : ((float[]) obj).length;
        int length2 = obj2 instanceof g ? ((g) obj2).a : ((float[]) obj2).length;
        if (length > length2) {
            return 1;
        }
        return length < length2 ? -1 : 0;
    }
}
