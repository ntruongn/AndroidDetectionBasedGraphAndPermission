package com.droidhen.api.promptclient.more;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.LinearLayout;
import com.droidhen.api.promptclient.a.c;
import com.droidhen.api.promptclient.a.e;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class MoreActivity extends Activity {
    private String a() {
        List<PackageInfo> installedPackages = getPackageManager().getInstalledPackages(0);
        ArrayList arrayList = new ArrayList(10);
        for (int i = 0; i < installedPackages.size(); i++) {
            PackageInfo packageInfo = installedPackages.get(i);
            if (a(packageInfo.packageName)) {
                arrayList.add(packageInfo.packageName);
            }
        }
        return c.a(";", arrayList);
    }

    private boolean a(String str) {
        for (int i = 0; i < e.b.length; i++) {
            if (str.startsWith(e.b[i])) {
                return true;
            }
        }
        return false;
    }

    private String b() {
        StringBuilder sb = new StringBuilder("&from=");
        sb.append(getPackageName()).append("&sdk=").append(Build.VERSION.SDK_INT);
        return sb.toString();
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LinearLayout linearLayout = new LinearLayout(this);
        ViewGroup.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setOrientation(1);
        addContentView(linearLayout, layoutParams);
        WebView webView = new WebView(this);
        webView.loadUrl(String.valueOf(com.droidhen.api.promptclient.a.c.a()) + "?exclude=" + a() + b());
        linearLayout.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        b bVar = a.a;
        if (bVar != null) {
            bVar.a(this, linearLayout);
        }
    }
}
