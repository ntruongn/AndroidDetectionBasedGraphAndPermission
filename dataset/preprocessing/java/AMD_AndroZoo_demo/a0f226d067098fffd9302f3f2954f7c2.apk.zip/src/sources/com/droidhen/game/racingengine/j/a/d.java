package com.droidhen.game.racingengine.j.a;

import com.droidhen.game.racingengine.g.e;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d {
    protected com.droidhen.game.racingengine.g.c[] a;
    public com.droidhen.game.racingengine.g.c b;
    protected com.droidhen.game.racingengine.g.c[] c;
    protected com.droidhen.game.racingengine.g.c d;
    public float e;
    public float f;
    public float g;
    public float h;

    public d(float f, float f2) {
        this.b = null;
        this.d = null;
        this.e = 0.0f;
        this.f = 0.0f;
        this.g = 0.0f;
        this.h = 0.0f;
        this.e = (-f) / 2.0f;
        this.f = f / 2.0f;
        this.g = (-f2) / 2.0f;
        this.h = f2 / 2.0f;
        this.c = new com.droidhen.game.racingengine.g.c[]{new com.droidhen.game.racingengine.g.c(this.f, this.g, 0.0f), new com.droidhen.game.racingengine.g.c(this.f, this.h, 0.0f), new com.droidhen.game.racingengine.g.c(this.e, this.h, 0.0f), new com.droidhen.game.racingengine.g.c(this.e, this.g, 0.0f)};
        this.d = new com.droidhen.game.racingengine.g.c();
        this.a = new com.droidhen.game.racingengine.g.c[]{new com.droidhen.game.racingengine.g.c(this.f, this.g, 0.0f), new com.droidhen.game.racingengine.g.c(this.f, this.h, 0.0f), new com.droidhen.game.racingengine.g.c(this.e, this.h, 0.0f), new com.droidhen.game.racingengine.g.c(this.e, this.g, 0.0f)};
        this.b = new com.droidhen.game.racingengine.g.c();
    }

    public void a(com.droidhen.game.racingengine.g.c cVar) {
        for (int i = 0; i < this.a.length; i++) {
            this.a[i].a(cVar.a + this.c[i].a, cVar.b + this.c[i].b, 0.0f);
        }
        this.b.a(cVar.a + this.d.a, cVar.b + this.d.b, 0.0f);
    }

    public void a(e eVar) {
        for (int i = 0; i < this.a.length; i++) {
            eVar.a(this.c[i], this.a[i]);
        }
        eVar.a(this.d, this.b);
    }

    public boolean a(d dVar) {
        if (this.a[2].a > dVar.a[1].a || this.a[1].a < dVar.a[2].a) {
            return false;
        }
        return this.a[0].b <= dVar.a[1].b && this.a[1].b >= dVar.a[0].b;
    }
}
