package com.droidhen.game.racingmototerLHL.a.a;

import com.droidhen.game.racingmototerLHL.GameActivity;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class ae extends com.droidhen.game.racingengine.a.a {
    private com.droidhen.game.racingengine.a.a.e g;
    private com.droidhen.game.racingengine.a.a.e h;
    private com.droidhen.game.racingengine.a.a.e i;
    private com.droidhen.game.racingengine.a.a.e j;
    private com.droidhen.game.racingengine.a.a.e k;
    private com.droidhen.game.racingengine.a.d l;
    private float p;
    private com.droidhen.game.racingmototerLHL.b.k x;
    private static float q = 3.0f;
    private static float r = 80.0f;
    private static float s = r;
    private static float t = 20.0f;
    private static float u = 3.0f;
    private static float v = 3.0f;
    private static int w = 0;
    public static boolean d = false;
    public static boolean e = false;
    private boolean m = false;
    private float n = 0.0f;
    private float o = 1.0f;
    private long U = 0;
    private com.droidhen.game.racingengine.g.c V = new com.droidhen.game.racingengine.g.c();
    private com.droidhen.game.racingengine.a.a.e f = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("help_1"));

    public ae() {
        this.f.a(240.0f, 600.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        this.f.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.f);
        this.g = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("help_2"));
        this.g.a(240.0f, 340.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        this.g.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.g);
        this.h = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("help_3"));
        this.h.a(130.0f, 200.0f, com.droidhen.game.racingengine.a.h.LEFTBOTTOM);
        this.h.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.h);
        this.j = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("line"));
        this.j.a(240.0f, 212.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        a(this.j);
        this.i = new d(this, com.droidhen.game.racingengine.a.e.a("phone"));
        this.i.a(240.0f, 192.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        a(this.i);
        this.k = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("help3_bg"));
        this.k.a(240.0f, 180.0f, com.droidhen.game.racingengine.a.h.CENTERTOP);
        this.k.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.k);
        this.l = new com.droidhen.game.racingengine.a.d(240.0f, 450.0f, com.droidhen.game.racingengine.a.h.CENTERTOP, com.droidhen.game.racingengine.a.e.a("b_start_a"), com.droidhen.game.racingengine.a.e.a("b_start_b"));
        this.l.a(new c(this));
        a(this.l);
        w = 0;
        this.f.z = false;
        this.g.z = false;
        this.h.z = false;
        this.i.z = false;
        this.j.z = false;
        this.l.z = false;
        this.k.z = false;
    }

    public static void f() {
        w = 0;
        e = false;
        d = false;
    }

    @Override // com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.P.size()) {
                return;
            }
            ((com.droidhen.game.racingengine.a.l) this.P.get(i2)).a();
            i = i2 + 1;
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        if (!this.z || !com.droidhen.game.racingmototerLHL.global.f.b().o) {
            com.droidhen.game.racingmototerLHL.global.f.a().g.e();
            return;
        }
        com.droidhen.game.racingmototerLHL.global.f.a().g.d();
        c();
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.P.size()) {
                return;
            }
            ((com.droidhen.game.racingengine.a.l) this.P.get(i2)).a(gl10);
            i = i2 + 1;
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean b(float f, float f2) {
        if (this.z && com.droidhen.game.racingmototerLHL.global.f.b().o) {
            return this.l.b(f, f2);
        }
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.PLAYING && com.droidhen.game.racingmototerLHL.global.f.b().o) {
            com.droidhen.game.racingengine.b.b.b g = com.droidhen.game.racingengine.a.b.g();
            if (w == 0) {
                if (com.droidhen.game.racingmototerLHL.global.f.f) {
                    this.U += g.a();
                } else {
                    this.U = 0L;
                }
                if (this.U > 500) {
                    w = 1;
                }
            }
            if (w == 1 && af.e == 3) {
                w = 2;
                this.x = com.droidhen.game.racingmototerLHL.global.f.b().j().a(com.droidhen.game.racingmototerLHL.b.d.Pickup);
                com.droidhen.game.racingengine.g.c cVar = com.droidhen.game.racingmototerLHL.global.f.b().d.b;
                com.droidhen.game.racingmototerLHL.global.f.b().d.a.o.d(this.V);
                com.droidhen.game.racingengine.g.c d2 = com.droidhen.game.racingengine.g.c.d();
                com.droidhen.game.racingengine.g.c d3 = com.droidhen.game.racingengine.g.c.d();
                d2.a(this.V.a, this.V.b + (cVar.b * 15.0f), 0.0f);
                d3.a(0.0f, cVar.b + 20.0f, 0.0f);
                this.x.a(com.droidhen.game.racingmototerLHL.b.m.FRONT, false, d2, d3);
                com.droidhen.game.racingengine.g.c.f(d3);
                com.droidhen.game.racingengine.g.c.f(d2);
                com.droidhen.game.racingmototerLHL.global.f.b().k().a();
            }
            if (w == 2 && d) {
                w = 3;
                com.droidhen.game.racingmototerLHL.global.f.b().j().a(this.x);
                GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.d);
                e = true;
                com.droidhen.game.racingmototerLHL.global.f.b().c();
            }
            this.n += s * g.b();
            if (this.n > t) {
                s = -r;
            } else if (this.n < (-t)) {
                s = r;
            }
            this.o = (g.b() * u) + this.o;
            if (this.o > v) {
                this.o = 1.0f;
            }
            if (w == 0) {
                this.f.z = true;
                this.g.z = false;
                this.h.z = false;
                this.i.z = false;
                this.j.z = false;
                this.l.z = false;
                this.k.z = false;
            }
            if (w == 1) {
                this.f.z = true;
                this.g.z = false;
                this.h.z = true;
                this.i.z = false;
                this.j.z = false;
            }
            if (w == 2) {
                this.f.z = false;
                this.g.z = true;
                this.h.z = false;
                this.i.z = true;
                this.j.z = true;
            }
            if (w == 3) {
                this.f.z = false;
                this.g.z = false;
                this.h.z = false;
                this.i.z = false;
                this.j.z = false;
                this.l.z = true;
                this.k.z = true;
            }
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean c(float f, float f2) {
        if (this.z && com.droidhen.game.racingmototerLHL.global.f.b().o) {
            return this.l.c(f, f2);
        }
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean d(float f, float f2) {
        if (this.z && com.droidhen.game.racingmototerLHL.global.f.b().o) {
            return this.l.d(f, f2);
        }
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void e() {
    }
}
