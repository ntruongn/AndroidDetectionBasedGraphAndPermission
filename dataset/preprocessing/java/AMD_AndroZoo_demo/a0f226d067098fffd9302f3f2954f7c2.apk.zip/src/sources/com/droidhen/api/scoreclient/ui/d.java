package com.droidhen.api.scoreclient.ui;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d extends Thread {
    int a;
    int b;
    int c;
    final /* synthetic */ HighScoresActivity d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(HighScoresActivity highScoresActivity, int i, int i2, int i3) {
        this.d = highScoresActivity;
        this.a = i;
        this.b = i2;
        this.c = i3;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        com.droidhen.api.scoreclient.a.b bVar;
        int i;
        boolean z;
        bVar = this.d.h;
        i = this.d.l;
        int i2 = this.a;
        int i3 = this.b;
        z = this.d.o;
        int a = bVar.a(i, i2, i3, z, this.c);
        this.d.D = null;
        this.d.a.sendEmptyMessage(a);
    }
}
