package com.droidhen.game.racingengine.b.c;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLUtils;
import android.util.Log;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.opengles.GL11;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c {
    private static int e = 1000001;
    private boolean f = true;
    private HashMap a = new HashMap();
    private ArrayList c = new ArrayList();
    private ArrayList b = new ArrayList();
    private HashMap d = new HashMap();

    private int a(GL10 gl10, Bitmap bitmap, boolean z) {
        int[] iArr = new int[1];
        gl10.glGenTextures(1, iArr, 0);
        int i = iArr[0];
        gl10.glBindTexture(3553, i);
        if (z && (gl10 instanceof GL11)) {
            gl10.glTexParameterf(3553, 33169, 1.0f);
        } else {
            gl10.glTexParameterf(3553, 33169, 0.0f);
        }
        gl10.glTexParameterf(3553, 10241, 9728.0f);
        gl10.glTexParameterf(3553, 10240, 9728.0f);
        gl10.glTexParameterf(3553, 10242, 10497.0f);
        gl10.glTexParameterf(3553, 10243, 10497.0f);
        GLUtils.texImage2D(3553, 0, bitmap, 0);
        gl10.glGetError();
        bitmap.recycle();
        return i;
    }

    private void a(GL10 gl10, int i) {
        gl10.glDeleteTextures(1, new int[]{i}, 0);
    }

    public d a(String str) {
        e eVar;
        e eVar2 = (e) this.a.get(str);
        if (eVar2 == null) {
            Iterator it = this.a.entrySet().iterator();
            while (it.hasNext() && eVar2 == null) {
                eVar2 = ((e) ((Map.Entry) it.next()).getValue()).a(str);
            }
            eVar = eVar2;
        } else {
            eVar = eVar2;
        }
        if (eVar == null || eVar.i() != 0) {
            throw new Error("Can't find: " + str + " in textureManager.");
        }
        return (d) eVar;
    }

    public void a(e eVar) {
        if (eVar.i() != 0) {
            this.a.put(eVar.h(), eVar);
        } else {
            String[] split = eVar.h().split("[/]");
            this.a.put(split[split.length - 1], eVar);
        }
    }

    public void a(GL10 gl10) {
        for (int size = this.b.size() - 1; size >= 0; size--) {
            if (!((e) this.b.get(size)).f()) {
                ((e) this.b.get(size)).d();
            }
            this.b.remove(size);
        }
    }

    public boolean a() {
        Iterator it = this.a.entrySet().iterator();
        while (it.hasNext()) {
            ((e) ((Map.Entry) it.next()).getValue()).g();
        }
        this.d.clear();
        e = 1000001;
        return true;
    }

    public boolean a(d dVar) {
        int i;
        Integer[] numArr = this.d.containsKey(dVar.c) ? (Integer[]) this.d.get(dVar.c) : new Integer[]{0, 0};
        if (numArr[0].intValue() > 0) {
            int intValue = numArr[1].intValue();
            numArr[0] = Integer.valueOf(numArr[0].intValue() + 1);
            this.d.put(dVar.c, numArr);
            i = intValue;
        } else {
            try {
                int a = a(com.droidhen.game.racingengine.a.f, BitmapFactory.decodeStream(com.droidhen.game.racingengine.a.d.open(dVar.c)), dVar.d);
                numArr[0] = 1;
                numArr[1] = Integer.valueOf(a);
                this.d.put(dVar.c, numArr);
                i = a;
            } catch (IOException e2) {
                throw new Error("Texture Path: " + dVar.c + " is Not exists in fileSystem.");
            }
        }
        dVar.a = i;
        dVar.a(true);
        return true;
    }

    public void b(d dVar) {
        if (!this.d.containsKey(dVar.c)) {
            Log.e("RacingEngine", "Texture file path: " + dVar.c + " have not been loaded.");
            return;
        }
        Integer[] numArr = (Integer[]) this.d.get(dVar.c);
        numArr[0] = Integer.valueOf(numArr[0].intValue() - 1);
        if (numArr[0].intValue() <= 0) {
            a(com.droidhen.game.racingengine.a.f, dVar.a);
            this.d.remove(dVar.c);
        } else {
            this.d.put(dVar.c, numArr);
        }
        dVar.a = -1;
        dVar.a(false);
    }

    public void b(e eVar) {
        this.b.add(eVar);
        this.f = true;
    }

    public void b(GL10 gl10) {
        for (int size = this.c.size() - 1; size >= 0; size--) {
            if (((e) this.c.get(size)).f()) {
                ((e) this.c.get(size)).e();
            }
            this.c.remove(size);
        }
    }

    public void c(e eVar) {
        this.c.add(eVar);
        this.f = true;
    }

    public void c(GL10 gl10) {
        if (this.f) {
            if (this.b.size() > 0) {
                a(gl10);
                System.gc();
            }
            if (this.c.size() > 0) {
                b(gl10);
                System.gc();
            }
            this.f = false;
        }
    }
}
