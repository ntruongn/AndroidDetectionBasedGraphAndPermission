package com.droidhen.api.scoreclient.widget;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;
import com.droidhen.api.scoreclient.ui.i;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class UsernameEdit extends EditText {
    private static String a = "Tap here to input";
    private static String b = "用户名不可为空";
    private int c;
    private boolean d;
    private final View.OnFocusChangeListener e;
    private final View.OnClickListener f;
    private final TextWatcher g;

    public UsernameEdit(Context context) {
        this(context, null);
    }

    public UsernameEdit(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d = false;
        this.e = new b(this);
        this.f = new d(this);
        this.g = new c(this);
        b(false);
    }

    public UsernameEdit(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.d = false;
        this.e = new b(this);
        this.f = new d(this);
        this.g = new c(this);
        b(false);
    }

    public static void b(String str) {
        a = str;
    }

    private void b(boolean z) {
        this.d = z;
        String a2 = i.a().a();
        if (this.d && a2.equals("me")) {
            a2 = a;
        }
        setText(a2);
        addTextChangedListener(this.g);
        setOnFocusChangeListener(this.e);
        setOnClickListener(this.f);
        setCursorVisible(false);
        c(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c(boolean z) {
        InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
        if (!z) {
            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            }
            setInputType(0);
        } else {
            setInputType(1);
            if (inputMethodManager != null) {
                inputMethodManager.showSoftInput(this, 0);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d(boolean z) {
        com.droidhen.api.scoreclient.ui.b a2 = i.a();
        String trim = getText().toString().trim();
        if (this.d && trim.equals(a)) {
            trim = "me";
        } else if (trim.length() == 0) {
            if (z) {
                Toast.makeText(getContext(), b, 1).show();
                return;
            }
            return;
        }
        if (trim.equals(a2.a())) {
            return;
        }
        a2.a(trim);
        if (this.c >= 0) {
            a2.a(this.c, trim);
        }
    }

    public void a() {
        Editable text = getText();
        setSelection(text.length());
        setCursorVisible(true);
        c(true);
        if (this.d && text.toString().equals(a)) {
            setText("");
        }
    }

    public void a(double d, int i) {
        this.c = i.a().a(d, Integer.valueOf(i));
    }

    public void a(boolean z) {
        if (this.d != z) {
            this.d = z;
            String a2 = i.a().a();
            if (this.d && a2.equals("me")) {
                setText(a);
            }
        }
    }

    public boolean a(String str) {
        String trim = str.trim();
        if (trim.length() == 0) {
            Toast.makeText(getContext(), b, 1).show();
            return false;
        }
        com.droidhen.api.scoreclient.ui.b a2 = i.a();
        a2.a(trim);
        if (this.c >= 0) {
            a2.a(this.c, trim);
        }
        setText(trim);
        return true;
    }

    @Override // android.widget.TextView, android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        switch (i) {
            case 66:
                c(false);
                clearFocus();
                setCursorVisible(false);
                return true;
            default:
                return super.onKeyUp(i, keyEvent);
        }
    }
}
