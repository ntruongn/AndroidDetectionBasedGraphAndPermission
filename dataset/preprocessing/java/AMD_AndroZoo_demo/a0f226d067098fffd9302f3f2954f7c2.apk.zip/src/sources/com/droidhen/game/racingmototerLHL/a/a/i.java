package com.droidhen.game.racingmototerLHL.a.a;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class i extends com.droidhen.game.racingengine.a.a.e {
    private long d;
    private long e;
    private float f;
    private float g;
    private float h;

    public i() {
        super(com.droidhen.game.racingengine.a.e.a("speeding_up"));
        this.g = 1.0f;
        this.h = 1.0f;
        this.z = false;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        boolean z;
        if (this.z) {
            c();
            if (this.B != 1.0f) {
                z = true;
                gl10.glColor4f(1.0f, 1.0f, 1.0f, this.B);
            } else {
                z = false;
            }
            gl10.glBindTexture(3553, this.C.a);
            gl10.glPushMatrix();
            gl10.glTranslatef(this.G.a, this.G.b, this.G.c);
            gl10.glTranslatef(this.E * 0.5f, this.F * 0.5f, 0.0f);
            gl10.glRotatef(-this.f, 0.0f, 0.0f, 1.0f);
            gl10.glScalef(this.g, this.h, 1.0f);
            gl10.glTranslatef(this.E * (-0.5f), this.F * (-0.5f), 0.0f);
            gl10.glTexCoordPointer(2, 5126, 0, this.M);
            gl10.glVertexPointer(3, 5126, 0, this.N);
            gl10.glDrawElements(4, this.D, 5123, this.O);
            if (z) {
                gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            }
            gl10.glPopMatrix();
        }
    }

    @Override // com.droidhen.game.racingengine.a.a.e, com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        if (this.z) {
            super.c();
            this.e = System.currentTimeMillis() - this.d;
            if (this.e < 700) {
                this.g = (((float) this.e) * 5.7142857E-4f) + 1.0f;
                this.h = 1.0f - (((float) this.e) * 5.7142857E-4f);
            } else if (this.e < 1100) {
                this.g = 1.4f - (0.0034999999f * ((float) (this.e - 700)));
                this.h = 0.6f - (0.0015f * ((float) (this.e - 700)));
                this.f = 0.1125f * ((float) (this.e - 700));
            } else {
                this.z = false;
                this.e = 0L;
                this.f = 0.0f;
            }
        }
    }

    @Override // com.droidhen.game.racingengine.a.a.e, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        this.z = true;
        this.d = System.currentTimeMillis();
    }
}
