package com.droidhen.game.racingengine.b.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    private static float b = 1000.0f;
    private static float c = 3600.0f;
    private static float d = 1000000.0f;
    private long a = 0;

    public long a() {
        return ((float) this.a) / d;
    }

    public b a(long j) {
        this.a = ((float) j) * d;
        return this;
    }

    public float b() {
        return (((float) this.a) / d) / b;
    }

    public b b(long j) {
        this.a = j;
        return this;
    }

    public float c() {
        return ((((float) this.a) / d) / b) / c;
    }
}
