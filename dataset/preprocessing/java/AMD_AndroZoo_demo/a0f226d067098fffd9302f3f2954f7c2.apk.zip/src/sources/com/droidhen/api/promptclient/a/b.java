package com.droidhen.api.promptclient.a;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    public static void a(Activity activity) {
        activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(b(activity))));
    }

    private static String b(Activity activity) {
        return "market://details?id=" + activity.getPackageName();
    }
}
