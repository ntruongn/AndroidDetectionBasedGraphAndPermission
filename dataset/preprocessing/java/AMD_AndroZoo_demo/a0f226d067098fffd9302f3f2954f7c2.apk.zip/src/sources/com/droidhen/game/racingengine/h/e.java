package com.droidhen.game.racingengine.h;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e {
    private int a;
    private boolean b;
    private int c;
    private float d;

    public e(int i, boolean z, float f) {
        this.a = i;
        this.b = z;
        this.d = f;
    }

    public int a() {
        return this.a;
    }

    public void a(int i) {
        this.c = i;
    }

    public boolean b() {
        return this.b;
    }

    public float c() {
        return this.d;
    }

    public int d() {
        return this.c;
    }
}
