package com.droidhen.api.scoreclient.a;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import com.droidhen.api.scoreclient.ui.i;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    private int a;
    private int b;
    private int c;
    private String d;
    private String e;
    private String f;
    private int g;
    private List h;
    private Context i;
    private SharedPreferences j;
    private boolean k;
    private JSONArray l;
    private JSONObject m;
    private JSONObject n;
    private int o;

    public b(Context context) {
        this.d = "default";
        this.f = null;
        this.g = 0;
        this.i = null;
        this.i = context;
        this.e = this.i.getPackageName();
        this.j = this.i.getSharedPreferences("achievement_data", 0);
        this.a = this.j.getInt("local_score_list_size", 10);
        this.b = this.j.getInt("score_type", 0);
        this.c = this.j.getInt("score_sort_order", 1);
        this.f = this.j.getString("checksum", null);
        this.g = this.j.getInt("count", 0);
        try {
            String macAddress = ((WifiManager) context.getSystemService("wifi")).getConnectionInfo().getMacAddress();
            if (macAddress != null) {
                this.d = macAddress;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String g() {
        try {
            File databasePath = this.i.getDatabasePath("scoreclient.db");
            int length = (int) databasePath.length();
            if (length > 32768) {
                length = 32768;
            }
            byte[] bytes = this.d.getBytes();
            byte[] bArr = new byte[bytes.length + length];
            for (int i = 0; i < bytes.length; i++) {
                bArr[i] = bytes[i];
            }
            FileInputStream fileInputStream = new FileInputStream(databasePath);
            fileInputStream.read(bArr, bytes.length, length);
            fileInputStream.close();
            return com.droidhen.api.scoreclient.a.a(bArr);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public int a(int i, int i2, int i3, boolean z, int i4) {
        this.o = i;
        String a = i4 == 0 ? com.droidhen.api.scoreclient.d.b.a("http://leaderboard.droidhen.com/games/daily.php", a(i, i2, i3, z)) : com.droidhen.api.scoreclient.d.b.a("http://leaderboard.droidhen.com/games/query.php", a(i, i2, i3, z));
        if (a != null) {
            try {
                JSONObject jSONObject = new JSONObject(a);
                this.l = jSONObject.optJSONArray("scores");
                this.m = jSONObject.optJSONObject("own");
                this.n = jSONObject.optJSONObject("meta");
            } catch (JSONException e) {
                e.printStackTrace();
                return 3;
            }
        }
        return (a == null || this.l == null) ? 3 : 2;
    }

    public int a(com.droidhen.api.scoreclient.b.b bVar) {
        int i;
        boolean z;
        boolean z2;
        this.k = false;
        ContentResolver contentResolver = this.i.getContentResolver();
        int b = bVar.b();
        if (this.h == null || b >= this.h.size()) {
            throw new IllegalStateException("Invalid mode id: " + b);
        }
        double a = bVar.a();
        Cursor query = contentResolver.query(com.droidhen.api.scoreclient.c.a.a, new String[]{"score_value", "_id"}, "mode_id=" + b, null, this.c == 0 ? "score_value DESC, score._id DESC" : "score_value ASC, score._id DESC");
        if (query != null) {
            int count = query.getCount();
            if (count >= this.a) {
                query.moveToFirst();
                double d = query.getDouble(query.getColumnIndexOrThrow("score_value"));
                if ((this.c != 1 || a <= d) && (this.c != 0 || a >= d)) {
                    z2 = false;
                } else {
                    contentResolver.delete(Uri.parse(com.droidhen.api.scoreclient.c.a.a + "/" + query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
                    z2 = true;
                }
            } else {
                z2 = true;
            }
            query.close();
            i = count;
            z = z2;
        } else {
            i = 0;
            z = true;
        }
        if (z) {
            try {
                if (this.f == null) {
                    if (i > 0) {
                        this.g++;
                        SharedPreferences.Editor edit = this.j.edit();
                        edit.putInt("count", this.g);
                        edit.commit();
                    }
                } else if (!this.f.equals(g())) {
                    this.g++;
                    SharedPreferences.Editor edit2 = this.j.edit();
                    edit2.putInt("count", this.g);
                    edit2.commit();
                }
                ContentValues contentValues = new ContentValues();
                contentValues.put("score_value", Double.valueOf(a));
                contentValues.put("mode_id", Integer.valueOf(b));
                contentValues.put("user_name", bVar.c());
                Uri insert = contentResolver.insert(com.droidhen.api.scoreclient.c.a.a, contentValues);
                this.f = g();
                SharedPreferences.Editor edit3 = this.j.edit();
                edit3.putString("checksum", this.f);
                edit3.commit();
                return Integer.valueOf(insert.getPathSegments().get(1)).intValue();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return -1;
    }

    public int a(com.droidhen.api.scoreclient.b.b bVar, int i, int i2) {
        this.o = bVar.b();
        if (this.k) {
            return 4;
        }
        String a = com.droidhen.api.scoreclient.d.b.a("http://leaderboard.droidhen.com/games/submit.php", b(bVar, i, i2));
        if (a != null) {
            try {
                JSONObject jSONObject = new JSONObject(a);
                this.l = jSONObject.optJSONArray("scores");
                this.m = jSONObject.optJSONObject("own");
                this.n = jSONObject.optJSONObject("meta");
                this.k = true;
            } catch (JSONException e) {
                e.printStackTrace();
                return 3;
            }
        }
        return (a == null || this.l == null) ? 1 : 0;
    }

    public List a() {
        if (this.h == null) {
            this.h = new ArrayList();
        }
        return this.h;
    }

    public List a(int i, int i2, int i3, boolean z) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new BasicNameValuePair("deviceid", this.d));
        arrayList.add(new BasicNameValuePair("mode", String.valueOf(i)));
        arrayList.add(new BasicNameValuePair("name", i.a().a()));
        arrayList.add(new BasicNameValuePair("appid", this.e));
        arrayList.add(new BasicNameValuePair("count", String.valueOf(i3)));
        arrayList.add(new BasicNameValuePair("version", "1"));
        if (z) {
            arrayList.add(new BasicNameValuePair("action", "showme"));
        } else {
            arrayList.add(new BasicNameValuePair("offset", String.valueOf(i2)));
        }
        return arrayList;
    }

    public void a(int i) {
        if (i <= 0) {
            return;
        }
        this.a = i;
        SharedPreferences.Editor edit = this.j.edit();
        edit.putInt("local_score_list_size", this.a);
        edit.commit();
    }

    public void a(int i, String str) {
        if (this.f == null) {
            this.g++;
            SharedPreferences.Editor edit = this.j.edit();
            edit.putInt("count", this.g);
            edit.commit();
        } else {
            if (!this.f.equals(g())) {
                this.g++;
                SharedPreferences.Editor edit2 = this.j.edit();
                edit2.putInt("count", this.g);
                edit2.commit();
            }
        }
        ContentResolver contentResolver = this.i.getContentResolver();
        Uri parse = Uri.parse(com.droidhen.api.scoreclient.c.a.a + "/" + i);
        ContentValues contentValues = new ContentValues();
        contentValues.put("user_name", str);
        if (contentResolver.update(parse, contentValues, null, null) > 0) {
            this.f = g();
            SharedPreferences.Editor edit3 = this.j.edit();
            edit3.putString("checksum", this.f);
            edit3.commit();
        }
    }

    public void a(String[] strArr) {
        int length = strArr.length;
        if (this.h == null) {
            this.h = new ArrayList();
        }
        for (int i = 0; i < length; i++) {
            this.h.add(new com.droidhen.api.scoreclient.b.c(0 + i, strArr[i]));
        }
    }

    public int b() {
        return this.b;
    }

    public List b(int i) {
        ArrayList arrayList = new ArrayList();
        Cursor query = this.i.getContentResolver().query(com.droidhen.api.scoreclient.c.a.a, new String[]{"user_name", "score_value"}, "mode_id=" + i, null, this.c == 0 ? "score_value ASC, score._id ASC" : "score_value DESC, score._id ASC");
        if (query != null && query.getCount() > 0) {
            if (this.f == null) {
                this.g++;
                SharedPreferences.Editor edit = this.j.edit();
                edit.putInt("count", this.g);
                edit.commit();
            } else if (!this.f.equals(g())) {
                this.g++;
                SharedPreferences.Editor edit2 = this.j.edit();
                edit2.putInt("count", this.g);
                edit2.commit();
            }
            int i2 = 1;
            while (query.moveToNext()) {
                com.droidhen.api.scoreclient.b.b bVar = new com.droidhen.api.scoreclient.b.b(query.getDouble(query.getColumnIndexOrThrow("score_value")), i, query.getString(query.getColumnIndexOrThrow("user_name")));
                bVar.a(i2);
                arrayList.add(bVar);
                i2++;
            }
        }
        if (query != null) {
            query.close();
        }
        return arrayList;
    }

    public List b(com.droidhen.api.scoreclient.b.b bVar, int i, int i2) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new BasicNameValuePair("score", String.valueOf(bVar.a())));
        arrayList.add(new BasicNameValuePair("deviceid", this.d));
        arrayList.add(new BasicNameValuePair("mode", String.valueOf(bVar.b())));
        arrayList.add(new BasicNameValuePair("name", i.a().a()));
        arrayList.add(new BasicNameValuePair("appid", this.e));
        arrayList.add(new BasicNameValuePair("cs", com.droidhen.api.scoreclient.d.a.a(this.e, this.d, bVar.a())));
        arrayList.add(new BasicNameValuePair("count", String.valueOf(i)));
        arrayList.add(new BasicNameValuePair("model", Build.MODEL));
        arrayList.add(new BasicNameValuePair("version", "1"));
        if (i2 == 0) {
            arrayList.add(new BasicNameValuePair("type", "daily"));
        } else {
            arrayList.add(new BasicNameValuePair("type", "all"));
        }
        return arrayList;
    }

    public Double c(int i) {
        Cursor query = this.i.getContentResolver().query(com.droidhen.api.scoreclient.c.a.a, new String[]{"user_name", "score_value"}, "mode_id=" + i, null, this.c == 0 ? "score_value ASC, score._id ASC" : "score_value DESC, score._id ASC");
        if (query == null || query.getCount() <= 0) {
            if (query != null) {
                query.close();
            }
            return null;
        }
        if (this.f == null) {
            this.g++;
            SharedPreferences.Editor edit = this.j.edit();
            edit.putInt("count", this.g);
            edit.commit();
        } else if (!this.f.equals(g())) {
            this.g++;
            SharedPreferences.Editor edit2 = this.j.edit();
            edit2.putInt("count", this.g);
            edit2.commit();
        }
        query.moveToFirst();
        double d = query.getDouble(query.getColumnIndexOrThrow("score_value"));
        query.close();
        return Double.valueOf(d);
    }

    public List c() {
        ArrayList arrayList = new ArrayList();
        if (this.l != null) {
            int length = this.l.length();
            for (int i = 0; i < length; i++) {
                if (!this.l.isNull(i)) {
                    JSONObject optJSONObject = this.l.optJSONObject(i);
                    int optInt = optJSONObject.optInt("seq");
                    com.droidhen.api.scoreclient.b.b bVar = new com.droidhen.api.scoreclient.b.b(optJSONObject.optDouble("score"), this.o, optJSONObject.optString("name"));
                    bVar.a(optInt);
                    arrayList.add(bVar);
                }
            }
        }
        return arrayList;
    }

    public com.droidhen.api.scoreclient.b.b d() {
        if (this.m == null) {
            return null;
        }
        try {
            int i = this.m.getInt("seq");
            com.droidhen.api.scoreclient.b.b bVar = new com.droidhen.api.scoreclient.b.b(this.m.getDouble("score"), this.o, this.m.getString("name"));
            bVar.a(i);
            return bVar;
        } catch (JSONException e) {
            return null;
        }
    }

    public int e() {
        if (this.n == null) {
            return 0;
        }
        try {
            return this.n.getInt("allcount");
        } catch (JSONException e) {
            return 0;
        }
    }

    public int f() {
        if (this.n == null) {
            return 0;
        }
        try {
            return this.n.getInt("offset");
        } catch (JSONException e) {
            return 0;
        }
    }
}
