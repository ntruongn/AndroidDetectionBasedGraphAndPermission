package com.droidhen.game.racingmototerLHL.b;

import java.util.ArrayList;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b implements com.droidhen.game.racingengine.i.a {
    private static final int[] m = {0, 1, 2, 1, 3};
    private int b;
    private boolean d = true;
    private ArrayList e = new ArrayList();
    private com.droidhen.game.racingengine.b.g f = null;
    private com.droidhen.game.racingengine.b.g g = null;
    private com.droidhen.game.racingengine.b.a h = null;
    private float i = 1968.0f;
    private float j = 0.0f;
    private int k = 0;
    private int l = 0;
    int a = 0;
    private int[] c = new int[8];

    private int b(int i) {
        return this.k != -1 ? this.k : this.c[(this.b + i) % this.c.length];
    }

    private com.droidhen.game.racingengine.b.a c(int i) {
        return (com.droidhen.game.racingengine.b.a) this.e.get(b(i));
    }

    public void a() {
        this.b = 0;
        this.j = 0.0f;
        this.k = 0;
        this.a = 0;
    }

    public void a(int i) {
        if (this.k != -1) {
            this.c[0] = this.k;
            this.c[1] = this.k;
            this.c[2] = this.k;
            this.c[3] = 4;
            this.c[4] = 4;
            this.c[5] = 4;
            this.c[6] = i;
            this.c[7] = i;
            this.b = 0;
            this.l = i;
            this.k = -1;
        }
    }

    public void a(com.droidhen.game.racingengine.b.a aVar) {
        this.e.add(aVar);
    }

    public void a(com.droidhen.game.racingengine.b.g gVar) {
        this.f = gVar;
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void a(GL10 gl10) {
        gl10.glPushMatrix();
        gl10.glTranslatef(0.0f, 0.0f, this.j + (4.0f * this.i));
        int i = 3;
        while (true) {
            int i2 = i;
            if (i2 <= -1) {
                gl10.glPopMatrix();
                return;
            }
            gl10.glTranslatef(0.0f, 0.0f, -this.i);
            if (b(i2 + 1) == 4 && b(i2) != 4) {
                gl10.glPushMatrix();
                gl10.glTranslatef(0.0f, 0.0f, this.i);
                this.g.a(gl10);
                gl10.glPopMatrix();
            }
            gl10.glPushMatrix();
            c(i2).a(gl10);
            gl10.glPopMatrix();
            if (b(i2 + 1) != 4 && b(i2) == 4) {
                gl10.glPushMatrix();
                ((com.droidhen.game.racingengine.b.a) this.e.get(6)).a(gl10);
                gl10.glPopMatrix();
            } else if (b(i2 + 1) == 4 && b(i2) != 4) {
                gl10.glPushMatrix();
                gl10.glTranslatef(0.0f, 0.0f, this.i);
                ((com.droidhen.game.racingengine.b.a) this.e.get(5)).a(gl10);
                gl10.glPopMatrix();
            }
            if (b(i2) == 4) {
                this.h.a(gl10);
            }
            i = i2 - 1;
        }
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void b() {
        if (com.droidhen.game.racingmototerLHL.global.f.d - this.j >= this.i) {
            this.b++;
            this.j += this.i;
        }
        if (this.k != -1 || this.b <= this.c.length - 3) {
            return;
        }
        this.k = this.l;
    }

    public void b(com.droidhen.game.racingengine.b.a aVar) {
        this.h = aVar;
    }

    public void b(com.droidhen.game.racingengine.b.g gVar) {
        this.g = gVar;
    }

    public void c() {
        this.a++;
        this.a %= 5;
        a(m[this.a]);
        if (m[this.a] == 2) {
            com.droidhen.game.racingmototerLHL.global.f.b().n().a().g = 5500.0f;
        } else {
            com.droidhen.game.racingmototerLHL.global.f.b().n().a().g = 3500.0f;
        }
    }
}
