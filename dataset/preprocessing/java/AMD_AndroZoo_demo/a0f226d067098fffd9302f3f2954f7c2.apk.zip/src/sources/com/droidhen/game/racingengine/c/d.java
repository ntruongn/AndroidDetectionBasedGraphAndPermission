package com.droidhen.game.racingengine.c;

import android.util.Log;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d {
    private static com.droidhen.game.racingengine.g.e o = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e p = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e q = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e r = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e s = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.c t = new com.droidhen.game.racingengine.g.c();
    private static com.droidhen.game.racingengine.g.c u = new com.droidhen.game.racingengine.g.c();
    private static com.droidhen.game.racingengine.g.c v = new com.droidhen.game.racingengine.g.c();
    private static com.droidhen.game.racingengine.g.e w = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e x = new com.droidhen.game.racingengine.g.e();
    private static com.droidhen.game.racingengine.g.e y = new com.droidhen.game.racingengine.g.e();
    private long c;
    private long d;
    private long e;
    private long f;
    private float g;
    private int h;
    private int i;
    private g j;
    private g k;
    private long m;
    private long n;
    protected e a = null;
    private ArrayList b = new ArrayList();
    private h l = null;

    private float a(long j) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.h) {
                break;
            }
            if (j <= ((g) this.b.get(i2)).a()) {
                if (i2 == 0) {
                    this.j = (g) this.b.get(i2);
                    this.k = (g) this.b.get(i2);
                    this.g = 0.0f;
                } else {
                    this.j = (g) this.b.get(i2 - 1);
                    this.k = (g) this.b.get(i2);
                    this.g = ((float) (j - this.j.a())) / ((float) (this.k.a() - this.j.a()));
                }
                this.i = i2;
            } else {
                i = i2 + 1;
            }
        }
        return this.g;
    }

    private void b(com.droidhen.game.racingengine.g.e eVar) {
        com.droidhen.game.racingengine.g.c.a(this.k.b(), this.j.b(), t);
        t.a(this.g);
        t.d(this.j.b());
        com.droidhen.game.racingengine.g.c.a(this.k.c(), this.j.c(), u);
        u.a(this.g);
        u.d(this.j.c());
        com.droidhen.game.racingengine.g.c.a(this.k.d(), this.j.d(), v);
        v.a(this.g);
        v.d(this.j.d());
        o.a(this.l.n);
        p.a(this.l.o);
        q.a(u);
        x.a();
        w.a();
        com.droidhen.game.racingengine.g.e.a(o, q, w);
        com.droidhen.game.racingengine.g.e.a(w, p, x);
        s.b(t);
        r.c(v);
        w.a();
        com.droidhen.game.racingengine.g.e.a(s, x, w);
        y.a();
        com.droidhen.game.racingengine.g.e.a(w, r, y);
        eVar.c(y);
    }

    public int a() {
        return this.i;
    }

    public g a(int i) {
        return (g) this.b.get(i);
    }

    public com.droidhen.game.racingengine.g.e a(com.droidhen.game.racingengine.g.e eVar) {
        long j;
        long j2;
        this.m = this.a.c;
        this.n = this.a.d;
        this.f = this.c;
        b c = this.a.c();
        if (c != null) {
            long a = c.a();
            c.b();
            this.f = c.c();
            j = a;
        } else {
            j = 0;
        }
        if (this.a == null) {
            Log.e("RacingEngine", "AnimationTrack: No animation for this track.");
            j2 = 0;
        } else if (this.a.b()) {
            j2 = j + ((((float) (this.m - this.n)) * this.a.a()) % this.f);
        } else {
            long a2 = (((float) (this.m - this.n)) * this.a.a()) + j;
            j2 = a2 > this.c + j ? j + this.c : a2;
        }
        a(j2);
        b(eVar);
        return eVar;
    }

    public void a(g gVar) {
        this.b.add(gVar);
        this.e = gVar.a();
        this.h++;
    }

    public void a(h hVar) {
        this.l = hVar;
        hVar.p = this;
    }

    public void b() {
        this.h = this.b.size();
        this.d = ((g) this.b.get(0)).a();
        this.e = ((g) this.b.get(this.h - 1)).a();
        this.c = this.e - this.d;
    }
}
