package com.droidhen.api.promptclient.more;

import android.content.Context;
import android.content.Intent;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    public static b a;

    public static void a(Context context, b bVar) {
        a(context, bVar, true);
    }

    public static void a(Context context, b bVar, boolean z) {
        Intent intent = new Intent(context, (Class<?>) MoreActivity.class);
        a = bVar;
        context.startActivity(intent);
    }
}
