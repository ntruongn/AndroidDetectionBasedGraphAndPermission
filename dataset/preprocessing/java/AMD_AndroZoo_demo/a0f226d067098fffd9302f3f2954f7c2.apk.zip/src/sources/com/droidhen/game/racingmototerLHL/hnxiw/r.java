package com.droidhen.game.racingmototerLHL.hnxiw;

import android.content.Context;
import java.io.File;
import java.io.IOException;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class r {
    private String a() {
        String str = "";
        String str2 = dem.e + dem.f + dem.h;
        if (!dem.a()) {
            return dem.y;
        }
        File file = new File(str2);
        if (!file.exists() || !file.isDirectory()) {
            return dem.y;
        }
        String[] list = file.list();
        for (int i = 0; i < list.length; i++) {
            if (list[i].endsWith(dem.l) && list[i].length() >= 10) {
                str = str + list[i].substring(6, 10) + ((String) pj.b.get(75));
            }
        }
        return str.equals("") ? dem.y : str.substring(0, str.length() - 1);
    }

    public String a(Context context, gk gkVar) {
        return (((((((((((((dem.V + gkVar.a()) + dem.W + gkVar.b()) + dem.X + gkVar.c()) + dem.Y + gkVar.d()) + dem.Z + gkVar.e()) + dem.aa + gkVar.n()) + dem.ab + gkVar.f()) + dem.ac + gkVar.g()) + dem.ad + gkVar.h()) + dem.ae + gkVar.j()) + dem.af + gkVar.k()) + dem.ag + gkVar.l()) + dem.ah + gkVar.m()) + dem.ai + a() + dem.aj;
    }

    public String a(gk gkVar) {
        return (((((dem.V + gkVar.a()) + dem.W + gkVar.h()) + dem.X + gkVar.j()) + dem.Y + gkVar.k()) + dem.Z + gkVar.l()) + dem.aa + gkVar.m();
    }

    public String a(String str, String str2, String str3) {
        String str4 = "";
        int i = 3;
        boolean z = true;
        String str5 = str;
        while (z) {
            int i2 = i - 1;
            try {
                str5 = str5.replaceAll(" ", dem.D);
                HttpGet httpGet = new HttpGet(str5);
                BasicHttpParams basicHttpParams = new BasicHttpParams();
                HttpConnectionParams.setConnectionTimeout(basicHttpParams, 20000);
                HttpConnectionParams.setSoTimeout(basicHttpParams, 20000);
                DefaultHttpClient defaultHttpClient = new DefaultHttpClient(basicHttpParams);
                if (str3 != null && !str3.equals("")) {
                    httpGet.addHeader(str2, str3);
                }
                str4 = EntityUtils.toString(defaultHttpClient.execute(httpGet).getEntity());
                break;
            } catch (Exception e) {
                boolean z2 = i2 >= 0;
                try {
                    Thread.sleep(3000L);
                    z = z2;
                    i = i2;
                } catch (InterruptedException e2) {
                    z = z2;
                    i = i2;
                }
            }
        }
        return str4;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void a(String str, String str2) {
        byte[] bytes = str2.getBytes();
        try {
            HttpPost httpPost = new HttpPost(str.replaceAll(" ", "%20"));
            BasicHttpParams basicHttpParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(basicHttpParams, 12000);
            HttpConnectionParams.setSoTimeout(basicHttpParams, 80000);
            DefaultHttpClient defaultHttpClient = new DefaultHttpClient(basicHttpParams);
            httpPost.setParams(basicHttpParams);
            if (bytes != null) {
                httpPost.setEntity(new ByteArrayEntity(bytes));
            }
            defaultHttpClient.execute(httpPost);
        } catch (IOException e) {
        } catch (ParseException e2) {
        }
    }

    public boolean a(gk gkVar, String str) {
        if (gkVar.a() == null || !(gkVar.a().equals(dem.z) || gkVar.a().equals(""))) {
            return ((gkVar.b() != null && gkVar.b().startsWith(dem.A)) || str.toLowerCase().contains(dem.B) || str.toLowerCase().contains(dem.C) || gkVar.d().toLowerCase().equals(dem.B) || gkVar.d().toLowerCase().equals(dem.C)) ? false : true;
        }
        return false;
    }

    public String b(gk gkVar) {
        return (((((dem.V + gkVar.a()) + dem.W + gkVar.h()) + dem.X + gkVar.j()) + dem.Y + gkVar.k()) + dem.Z + gkVar.l()) + dem.aa + gkVar.m();
    }

    public String c(gk gkVar) {
        return gkVar.h() + gkVar.i() + 1;
    }
}
