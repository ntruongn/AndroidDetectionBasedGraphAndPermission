package com.droidhen.game.racingmototerLHL.b;

import java.util.TimerTask;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f extends TimerTask {
    final /* synthetic */ h a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(h hVar) {
        this.a = hVar;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public void run() {
        com.droidhen.game.racingmototerLHL.global.f.b().q();
        this.a.i.cancel();
        this.a.i = null;
    }
}
