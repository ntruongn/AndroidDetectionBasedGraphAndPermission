package com.droidhen.game.racingmototerLHL.global;

import android.app.Application;
import android.content.Context;
import com.droidhen.api.scoreclient.ui.i;
import com.droidhen.api.scoreclient.widget.UsernameEdit;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class SCApplication extends Application {
    public static final String[] a = {"RacingMoto"};

    public static final int a() {
        return 0;
    }

    public static final String a(Context context) {
        return com.droidhen.api.promptclient.a.a.a(context, "share.jpg");
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        UsernameEdit.b("点击即可输入");
        com.droidhen.api.scoreclient.ui.b a2 = i.a(this);
        a2.a(a);
        a2.a(50);
        com.droidhen.api.scoreclient.ui.b a3 = i.a();
        a3.a("Test", "a test achievement", null, null);
        a3.a(55, "Hey", "heiheiheihei", null, null, 1);
        a3.c(55);
        int a4 = a3.a("Scroll Test", "with this achievement, a scrollbar will be displayed", null, null);
        a3.b(a4, "Hey, it has beed changed!");
        a3.c(a4);
    }
}
