package com.droidhen.game.racingengine.d;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public enum a {
    POINTS(0),
    LINES(1),
    LINE_LOOP(2),
    LINE_STRIP(3),
    TRIANGLES(4),
    TRIANGLE_STRIP(5),
    TRIANGLE_FAN(6);

    private final int h;

    a(int i2) {
        this.h = i2;
    }

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static a[] valuesCustom() {
        a[] valuesCustom = values();
        int length = valuesCustom.length;
        a[] aVarArr = new a[length];
        System.arraycopy(valuesCustom, 0, aVarArr, 0, length);
        return aVarArr;
    }

    public int a() {
        return this.h;
    }
}
