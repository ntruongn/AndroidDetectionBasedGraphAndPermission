package com.droidhen.game.racingengine.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d extends com.droidhen.game.racingengine.a.a.e {
    g d;
    private com.droidhen.game.racingengine.b.c.d e;
    private com.droidhen.game.racingengine.b.c.d f;
    private boolean g;

    public d(float f, float f2, h hVar, com.droidhen.game.racingengine.b.c.d dVar) {
        super(dVar);
        this.d = null;
        this.g = false;
        this.e = dVar;
        this.f = dVar;
        a(f, f2, hVar);
    }

    public d(float f, float f2, h hVar, com.droidhen.game.racingengine.b.c.d dVar, com.droidhen.game.racingengine.b.c.d dVar2) {
        this(f, f2, hVar, dVar);
        this.f = dVar2;
    }

    public d a(g gVar) {
        this.d = gVar;
        return this;
    }

    public void a(com.droidhen.game.racingengine.b.c.d dVar, com.droidhen.game.racingengine.b.c.d dVar2) {
        this.e = dVar;
        this.f = dVar2;
        this.C = dVar;
    }

    @Override // com.droidhen.game.racingengine.a.a.e, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean b(float f, float f2) {
        if (!this.z) {
            return false;
        }
        if (f <= n() || f >= o() || f2 <= m() || f2 >= l()) {
            return false;
        }
        f();
        return true;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean c(float f, float f2) {
        if (!this.z) {
            return false;
        }
        if (f <= n() || f >= o() || f2 <= m() || f2 >= l()) {
            return false;
        }
        g();
        if (this.d != null) {
            this.d.a(this);
        }
        return true;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean d(float f, float f2) {
        if (!this.z) {
            return false;
        }
        if (f <= n() || f >= o() || f2 <= m() || f2 >= l()) {
            this.C = this.e;
            return false;
        }
        this.C = this.f;
        return true;
    }

    public void f() {
        this.g = true;
        this.C = this.f;
    }

    public void g() {
        this.g = false;
        this.C = this.e;
    }
}
