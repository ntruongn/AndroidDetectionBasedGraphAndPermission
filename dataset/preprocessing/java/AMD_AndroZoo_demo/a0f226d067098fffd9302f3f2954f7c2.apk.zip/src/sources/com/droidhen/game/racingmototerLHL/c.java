package com.droidhen.game.racingmototerLHL;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c implements DialogInterface.OnClickListener {
    final /* synthetic */ GameActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(GameActivity gameActivity) {
        this.a = gameActivity;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        com.droidhen.api.promptclient.prompt.a aVar;
        StringBuilder sb = new StringBuilder("market://details?id=");
        aVar = this.a.f;
        sb.append(aVar.c);
        this.a.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(sb.toString())));
    }
}
