package com.droidhen.api.promptclient.prompt;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class l {
    private static Thread a;

    private static String a(Context context, int i, String str) {
        StringBuilder sb = new StringBuilder(com.droidhen.api.promptclient.a.c.b());
        sb.append("?id=").append(i).append("&package=").append(str).append("&from=").append(context.getPackageName()).append("&sdk=").append(Build.VERSION.SDK_INT).append("&version=1");
        return sb.toString();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(Context context) {
        if (a == null || !a.isAlive()) {
            a b = f.b(context);
            if (a(context, b) || System.currentTimeMillis() - b.e <= 43200000) {
                return;
            }
            new j(context, b).start();
        }
    }

    private static boolean a(Context context, a aVar) {
        if (com.droidhen.api.promptclient.a.c.a(aVar.c) || com.droidhen.api.promptclient.a.c.a(aVar.d)) {
            return false;
        }
        if (System.currentTimeMillis() - aVar.e <= 86400000) {
            return true;
        }
        f.a(context);
        return false;
    }

    private static boolean a(String str) {
        for (int i = 0; i < com.droidhen.api.promptclient.a.e.a.length; i++) {
            if (str.startsWith(com.droidhen.api.promptclient.a.e.a[i])) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void b(android.content.Context r7, int r8) {
        /*
            r4 = 0
            java.lang.String r0 = c(r7)
            java.lang.String r0 = a(r7, r8, r0)
            java.net.URL r1 = new java.net.URL     // Catch: java.io.IOException -> L63 org.json.JSONException -> L6c java.net.SocketException -> L89
            r1.<init>(r0)     // Catch: java.io.IOException -> L63 org.json.JSONException -> L6c java.net.SocketException -> L89
            java.net.URLConnection r0 = r1.openConnection()     // Catch: java.io.IOException -> L63 org.json.JSONException -> L6c java.net.SocketException -> L89
            java.net.HttpURLConnection r0 = (java.net.HttpURLConnection) r0     // Catch: java.io.IOException -> L63 org.json.JSONException -> L6c java.net.SocketException -> L89
            r1 = 5000(0x1388, float:7.006E-42)
            r0.setConnectTimeout(r1)     // Catch: org.json.JSONException -> L75 java.io.IOException -> L7f java.net.SocketException -> L8d
            java.io.DataInputStream r1 = new java.io.DataInputStream     // Catch: org.json.JSONException -> L75 java.io.IOException -> L7f java.net.SocketException -> L8d
            java.io.BufferedInputStream r2 = new java.io.BufferedInputStream     // Catch: org.json.JSONException -> L75 java.io.IOException -> L7f java.net.SocketException -> L8d
            java.io.InputStream r3 = r0.getInputStream()     // Catch: org.json.JSONException -> L75 java.io.IOException -> L7f java.net.SocketException -> L8d
            r2.<init>(r3)     // Catch: org.json.JSONException -> L75 java.io.IOException -> L7f java.net.SocketException -> L8d
            r1.<init>(r2)     // Catch: org.json.JSONException -> L75 java.io.IOException -> L7f java.net.SocketException -> L8d
            java.io.ByteArrayOutputStream r2 = new java.io.ByteArrayOutputStream     // Catch: java.net.SocketException -> L59 org.json.JSONException -> L7a java.io.IOException -> L84
            r2.<init>()     // Catch: java.net.SocketException -> L59 org.json.JSONException -> L7a java.io.IOException -> L84
            r3 = 1024(0x400, float:1.435E-42)
            byte[] r3 = new byte[r3]     // Catch: java.net.SocketException -> L59 org.json.JSONException -> L7a java.io.IOException -> L84
        L30:
            r4 = 0
            r5 = 1024(0x400, float:1.435E-42)
            int r4 = r1.read(r3, r4, r5)     // Catch: java.net.SocketException -> L59 org.json.JSONException -> L7a java.io.IOException -> L84
            if (r4 >= 0) goto L54
            java.lang.String r3 = "UTF-8"
            java.lang.String r2 = r2.toString(r3)     // Catch: java.net.SocketException -> L59 org.json.JSONException -> L7a java.io.IOException -> L84
            com.droidhen.api.promptclient.prompt.a r2 = com.droidhen.api.promptclient.prompt.a.a(r2)     // Catch: java.net.SocketException -> L59 org.json.JSONException -> L7a java.io.IOException -> L84
            if (r2 == 0) goto L92
            com.droidhen.api.promptclient.prompt.f.a(r7, r2)     // Catch: java.net.SocketException -> L59 org.json.JSONException -> L7a java.io.IOException -> L84
            r6 = r1
            r1 = r0
            r0 = r6
        L4b:
            com.droidhen.api.promptclient.a.d.a(r0)
            if (r1 == 0) goto L53
            r1.disconnect()
        L53:
            return
        L54:
            r5 = 0
            r2.write(r3, r5, r4)     // Catch: java.net.SocketException -> L59 org.json.JSONException -> L7a java.io.IOException -> L84
            goto L30
        L59:
            r2 = move-exception
            r6 = r2
            r2 = r0
            r0 = r6
        L5d:
            r0.printStackTrace()
            r0 = r1
            r1 = r2
            goto L4b
        L63:
            r0 = move-exception
            r1 = r4
            r2 = r4
        L66:
            r0.printStackTrace()
            r0 = r1
            r1 = r2
            goto L4b
        L6c:
            r0 = move-exception
            r1 = r4
            r2 = r4
        L6f:
            r0.printStackTrace()
            r0 = r1
            r1 = r2
            goto L4b
        L75:
            r1 = move-exception
            r2 = r0
            r0 = r1
            r1 = r4
            goto L6f
        L7a:
            r2 = move-exception
            r6 = r2
            r2 = r0
            r0 = r6
            goto L6f
        L7f:
            r1 = move-exception
            r2 = r0
            r0 = r1
            r1 = r4
            goto L66
        L84:
            r2 = move-exception
            r6 = r2
            r2 = r0
            r0 = r6
            goto L66
        L89:
            r0 = move-exception
            r1 = r4
            r2 = r4
            goto L5d
        L8d:
            r1 = move-exception
            r2 = r0
            r0 = r1
            r1 = r4
            goto L5d
        L92:
            r6 = r1
            r1 = r0
            r0 = r6
            goto L4b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.droidhen.api.promptclient.prompt.l.b(android.content.Context, int):void");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean b(Context context) {
        return a(context, f.b(context));
    }

    private static String c(Context context) {
        List<PackageInfo> installedPackages = context.getPackageManager().getInstalledPackages(0);
        ArrayList arrayList = new ArrayList(10);
        for (int i = 0; i < installedPackages.size(); i++) {
            PackageInfo packageInfo = installedPackages.get(i);
            if (a(packageInfo.packageName)) {
                arrayList.add(packageInfo.packageName);
            }
        }
        return com.droidhen.api.promptclient.a.c.a(";", arrayList);
    }
}
