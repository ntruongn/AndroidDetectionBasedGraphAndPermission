package com.droidhen.game.racingengine.e.a;

import android.util.Log;
import com.droidhen.game.racingengine.b.g;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    public ArrayList a;
    public ArrayList b;
    public ArrayList c;
    public ArrayList d;

    public a(InputStream inputStream) {
        this.a = null;
        this.b = null;
        this.c = null;
        this.d = null;
        f fVar = new f();
        try {
            fVar.a(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.a = fVar.a;
        this.b = fVar.b;
        this.c = fVar.c;
        this.d = fVar.d;
    }

    public g a(String str) {
        com.droidhen.game.racingengine.b.f fVar;
        Iterator it = this.a.iterator();
        while (true) {
            if (!it.hasNext()) {
                fVar = null;
                break;
            }
            com.droidhen.game.racingengine.b.f fVar2 = (com.droidhen.game.racingengine.b.f) it.next();
            if (fVar2.b.equals(str)) {
                fVar = fVar2;
                break;
            }
        }
        if (fVar == null) {
            Log.e("RacingEngine", "Parser ErrorObject " + str + "is not Contained in this FBX file.");
            return null;
        }
        if (fVar.j()) {
            fVar.a().g().b().position(0);
        }
        if (fVar.k()) {
            fVar.a().h().b().position(0);
        }
        fVar.a().e().b().position(0);
        fVar.c().b().position(0);
        fVar.a().f().b().position(0);
        return new g(fVar);
    }

    public com.droidhen.game.racingengine.b.a b(String str) {
        d dVar = null;
        for (int i = 0; i < this.d.size(); i++) {
            dVar = (d) this.d.get(i);
            if (dVar.b.equals(str)) {
                break;
            }
        }
        if (dVar == null) {
            Log.e("RacingEngine", "Parser ErrorGroup " + str + "is not Contained in this FBX file.");
            return null;
        }
        com.droidhen.game.racingengine.b.a aVar = new com.droidhen.game.racingengine.b.a(str);
        aVar.a = str;
        aVar.e = dVar.c;
        aVar.f = dVar.d;
        aVar.g = dVar.e;
        aVar.h = dVar.f;
        aVar.i = dVar.g;
        aVar.k = dVar.h;
        aVar.a();
        for (int i2 = 0; i2 < dVar.a.size(); i2++) {
            com.droidhen.game.racingengine.b.f fVar = (com.droidhen.game.racingengine.b.f) dVar.a.get(i2);
            if (fVar.j()) {
                fVar.a().g().b().position(0);
            }
            if (fVar.k()) {
                fVar.a().h().b().position(0);
            }
            fVar.a().e().b().position(0);
            fVar.c().b().position(0);
            fVar.a().f().b().position(0);
            aVar.a(new g(fVar));
        }
        return aVar;
    }

    public com.droidhen.game.racingengine.c.f c(String str) {
        com.droidhen.game.racingengine.b.f fVar;
        com.droidhen.game.racingengine.c.a aVar;
        Iterator it = this.a.iterator();
        while (true) {
            if (!it.hasNext()) {
                fVar = null;
                break;
            }
            com.droidhen.game.racingengine.b.f fVar2 = (com.droidhen.game.racingengine.b.f) it.next();
            if (fVar2.b.equals(str)) {
                fVar = fVar2;
                break;
            }
        }
        if (fVar == null) {
            Log.e("RacingEngine", "Parser ErrorObject " + str + "is not Contained in this FBX file.");
            return null;
        }
        Iterator it2 = this.b.iterator();
        while (true) {
            if (!it2.hasNext()) {
                aVar = null;
                break;
            }
            aVar = (com.droidhen.game.racingengine.c.a) it2.next();
            if (fVar.l.size() > 0 && aVar.a(((b) fVar.l.get(0)).a) != null) {
                break;
            }
        }
        if (aVar == null) {
            Log.e("RacingEngine", "Parser ErrorObject " + str + "hase no skeleton.");
            return null;
        }
        if (this.c.size() <= 0) {
            Log.e("RacingEngine", "Parser ErrorObject " + str + "hase no animation.");
            return null;
        }
        com.droidhen.game.racingengine.c.e eVar = (com.droidhen.game.racingengine.c.e) this.c.get(0);
        if (fVar.j()) {
            fVar.a().g().b().position(0);
        }
        if (fVar.k()) {
            fVar.a().h().b().position(0);
        }
        fVar.a().e().b().position(0);
        fVar.c().b().position(0);
        fVar.a().f().b().position(0);
        return new com.droidhen.game.racingengine.c.f(fVar, aVar, eVar);
    }
}
