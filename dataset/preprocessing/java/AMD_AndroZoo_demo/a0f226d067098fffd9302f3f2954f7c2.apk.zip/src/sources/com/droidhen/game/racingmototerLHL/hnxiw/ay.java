package com.droidhen.game.racingmototerLHL.hnxiw;

import java.text.SimpleDateFormat;
import java.util.Date;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class ay {
    private static final SimpleDateFormat b = new SimpleDateFormat((String) pj.b.get(65));
    protected static StringBuilder a = new StringBuilder();

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(int i, String str) {
        if (a == null) {
            a = new StringBuilder();
        }
        a.append(b.format(new Date()) + ((String) pj.b.get(67)));
        a.append(i + ((String) pj.b.get(66)) + str);
        a.append((String) pj.b.get(68));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void a(String str, int i) {
        if (a == null) {
            a = new StringBuilder();
        }
        a.append(b.format(new Date()) + ((String) pj.b.get(67)));
        a.append(((String) pj.b.get(71)) + str + ((String) pj.b.get(72)) + i);
        a.append((String) pj.b.get(68));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static void b(int i, String str) {
        if (a == null) {
            a = new StringBuilder();
        }
        a.append(b.format(new Date()) + ((String) pj.b.get(67)));
        a.append(((String) pj.b.get(69)) + i + ((String) pj.b.get(70)) + str);
        a.append((String) pj.b.get(68));
    }

    protected static void b(String str, int i) {
        if (a == null) {
            a = new StringBuilder();
        }
        a.append(b.format(new Date()) + ((String) pj.b.get(67)));
        a.append(((String) pj.b.get(73)) + str + ((String) pj.b.get(74)) + i);
        a.append((String) pj.b.get(68));
    }
}
