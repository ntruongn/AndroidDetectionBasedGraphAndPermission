package com.droidhen.game.racingengine.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f extends c {
    public int m;
    public int v;
    public int[] w;
    public int x;

    public f(com.droidhen.game.racingengine.b.c.d dVar, float f, int i) {
        super(dVar, f, i);
        this.m = Integer.MIN_VALUE;
        this.v = 0;
        this.w = null;
        this.x = -1;
        this.w = new int[i];
    }

    private static int a(int i, int[] iArr, int i2) {
        if (i < 10) {
            int i3 = i2 - 1;
            iArr[i3] = i;
            return i3;
        }
        int i4 = i2;
        for (int i5 = i; i5 > 0; i5 /= 10) {
            i4--;
            iArr[i4] = i5 % 10;
        }
        return i4;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        float a = com.droidhen.game.racingengine.a.c.a() / this.R;
        float b = com.droidhen.game.racingengine.a.c.b() / this.S;
        float min = Math.min(a, b);
        this.E *= min;
        this.F *= min;
        this.G.a = a * this.G.a;
        this.G.b = b * this.G.b;
        this.f *= min;
        this.g *= min;
        a(this.k, this.f, this.g, this.h, this.d);
        this.S = com.droidhen.game.racingengine.a.c.b();
        this.R = com.droidhen.game.racingengine.a.c.a();
        c(0);
        c();
    }

    public void c(int i) {
        this.v = i;
        f();
    }

    public void f() {
        if (this.v != this.m) {
            this.m = this.v;
            int a = a(this.v, this.w, this.d);
            if (this.x != -1) {
                a--;
                this.w[a] = this.x;
            }
            a(this.w, a, this.d - a);
        }
    }
}
