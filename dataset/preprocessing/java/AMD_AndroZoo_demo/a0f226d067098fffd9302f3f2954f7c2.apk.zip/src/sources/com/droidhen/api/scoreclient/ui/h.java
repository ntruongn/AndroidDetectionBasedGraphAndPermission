package com.droidhen.api.scoreclient.ui;

import android.content.Context;
import android.content.SharedPreferences;
import com.droidhen.api.scoreclient.ScoreClientProvider;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class h implements b {
    private final Context a;
    private String b;
    private e c = null;
    private p d = null;
    private com.droidhen.api.scoreclient.a.c e;
    private com.droidhen.api.scoreclient.a.b f;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h(Context context) {
        this.a = context;
        this.b = context.getSharedPreferences("scoreclient_config", 0).getString("local_user_name", "me");
        com.droidhen.api.scoreclient.c.b.a = String.valueOf(context.getPackageName()) + ".ScoreClient";
        ScoreClientProvider.a();
        this.f = new com.droidhen.api.scoreclient.a.b(this.a);
        this.e = new com.droidhen.api.scoreclient.a.c(this.a);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static h a(b bVar) {
        return (h) bVar;
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public int a(double d, Integer num) {
        com.droidhen.api.scoreclient.b.b bVar = num == null ? new com.droidhen.api.scoreclient.b.b(d) : new com.droidhen.api.scoreclient.b.b(d, num.intValue());
        bVar.a(this.b);
        return a(bVar);
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public int a(double d, Integer num, int i) {
        com.droidhen.api.scoreclient.b.b bVar = num == null ? new com.droidhen.api.scoreclient.b.b(d) : new com.droidhen.api.scoreclient.b.b(d, num.intValue());
        bVar.a(this.b);
        return a(bVar, i);
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public int a(int i, String str, String str2, String str3, String str4, int i2) {
        return this.e.a(i, str, str2, str3, str4, i2);
    }

    public int a(com.droidhen.api.scoreclient.b.b bVar) {
        return this.f.a(bVar);
    }

    public int a(com.droidhen.api.scoreclient.b.b bVar, int i) {
        return this.f.a(bVar, 20, i);
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public int a(String str, String str2, String str3, String str4) {
        return this.e.a(str, str2, str3, str4);
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public String a() {
        return this.b;
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public void a(int i) {
        this.f.a(i);
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public void a(int i, String str) {
        this.f.a(i, str);
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public void a(String str) {
        this.b = str;
        SharedPreferences.Editor edit = this.a.getSharedPreferences("scoreclient_config", 0).edit();
        edit.putString("local_user_name", this.b);
        edit.commit();
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public void a(String[] strArr) {
        this.f.a(strArr);
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public Integer b(int i) {
        Double c = this.f.c(i);
        if (c == null) {
            return null;
        }
        return Integer.valueOf(c.intValue());
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public void b(int i, String str) {
        this.e.a(i, str);
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public boolean b() {
        return !this.a.getSharedPreferences("scoreclient_config", 0).contains("local_user_name");
    }

    public e c() {
        return this.c;
    }

    @Override // com.droidhen.api.scoreclient.ui.b
    public void c(int i) {
        this.e.a(i);
    }

    public com.droidhen.api.scoreclient.a.c d() {
        return this.e;
    }

    public com.droidhen.api.scoreclient.a.b e() {
        return this.f;
    }

    public p f() {
        return this.d;
    }
}
