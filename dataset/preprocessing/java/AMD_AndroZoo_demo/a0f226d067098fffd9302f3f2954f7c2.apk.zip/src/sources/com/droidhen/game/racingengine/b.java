package com.droidhen.game.racingengine;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public abstract class b extends com.droidhen.game.racingengine.i.b {
    public void a(GL10 gl10) {
        a();
        b(gl10);
    }

    @Override // com.droidhen.game.racingengine.i.b
    protected void b() {
    }

    public void b(GL10 gl10) {
    }

    @Override // com.droidhen.game.racingengine.i.b
    public void c() {
        super.c();
    }

    @Override // com.droidhen.game.racingengine.i.b
    public void d() {
        super.d();
    }

    public void h() {
    }

    public void i() {
    }
}
