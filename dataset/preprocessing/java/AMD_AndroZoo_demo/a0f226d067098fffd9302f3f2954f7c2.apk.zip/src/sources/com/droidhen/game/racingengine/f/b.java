package com.droidhen.game.racingengine.f;

import java.util.Collections;
import java.util.Comparator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    private static Comparator d = new f();
    private static ThreadLocal e = new e();
    private d a = new d();
    private g c = new g(null);
    private Comparator b = d;

    public static b a() {
        return (b) e.get();
    }

    private float[] b(int i) {
        return new float[i];
    }

    public void a(float[] fArr) {
        int binarySearch = Collections.binarySearch(this.a, fArr, this.b);
        if (binarySearch < 0) {
            binarySearch = (-binarySearch) - 1;
        }
        this.a.add(binarySearch, fArr);
    }

    public float[] a(int i) {
        this.c.a = i;
        int binarySearch = Collections.binarySearch(this.a, this.c, this.b);
        return binarySearch < 0 ? b(i) : this.a.remove(binarySearch);
    }
}
