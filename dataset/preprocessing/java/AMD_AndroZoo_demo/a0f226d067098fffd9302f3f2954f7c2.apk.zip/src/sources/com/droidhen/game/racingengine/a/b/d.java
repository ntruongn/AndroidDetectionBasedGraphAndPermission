package com.droidhen.game.racingengine.a.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d extends c {
    public d(float f, float f2, float f3) {
        this.a = f;
        this.b = f2;
        this.c = f3;
    }

    @Override // com.droidhen.game.racingengine.a.b.c
    public void c() {
        super.c();
        if (this.h == b.Running) {
            this.d = ((e().b() / this.c) * (this.b - this.a)) + this.a;
        }
    }
}
