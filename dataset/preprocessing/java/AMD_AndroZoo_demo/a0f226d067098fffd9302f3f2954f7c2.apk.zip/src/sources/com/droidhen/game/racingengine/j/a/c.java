package com.droidhen.game.racingengine.j.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c {
    static com.droidhen.game.racingengine.g.c a = new com.droidhen.game.racingengine.g.c();
    static com.droidhen.game.racingengine.g.c b = new com.droidhen.game.racingengine.g.c(1.0f, 0.0f, 0.0f);

    public static boolean a(d dVar, float f) {
        float f2 = 0.0f;
        float f3 = 0.0f;
        for (int i = 0; i < 4; i++) {
            float b2 = dVar.a[i].b(b);
            if (i == 0) {
                f2 = b2;
                f3 = b2;
            } else {
                if (b2 < f3) {
                    f3 = b2;
                }
                if (b2 > f2) {
                    f2 = b2;
                }
            }
        }
        return f > f3 && f < f2;
    }

    public static boolean a(d dVar, d dVar2) {
        boolean z;
        boolean z2;
        com.droidhen.game.racingengine.g.c d = com.droidhen.game.racingengine.g.c.d();
        int i = 0;
        boolean z3 = true;
        while (true) {
            if (!z3) {
                z = z3;
                break;
            }
            z3 = a(dVar, dVar2, dVar.a[i + 1].a(dVar.a[i], d).c());
            i++;
            if (i > 1) {
                z = z3;
                break;
            }
        }
        boolean z4 = z;
        int i2 = 0;
        while (true) {
            if (!z4) {
                z2 = z4;
                break;
            }
            z4 = a(dVar, dVar2, dVar2.a[i2 + 1].a(dVar2.a[i2], d).c());
            i2++;
            if (i2 > 1) {
                z2 = z4;
                break;
            }
        }
        com.droidhen.game.racingengine.g.c.f(d);
        return z2;
    }

    private static boolean a(d dVar, d dVar2, com.droidhen.game.racingengine.g.c cVar) {
        float f = 0.0f;
        float f2 = 0.0f;
        for (int i = 0; i < 4; i++) {
            float b2 = dVar.a[i].b(cVar);
            if (i == 0) {
                f = b2;
                f2 = b2;
            } else {
                if (b2 < f2) {
                    f2 = b2;
                }
                if (b2 > f) {
                    f = b2;
                }
            }
        }
        float f3 = 0.0f;
        float f4 = 0.0f;
        for (int i2 = 0; i2 < 4; i2++) {
            float b3 = dVar2.a[i2].b(cVar);
            if (i2 == 0) {
                f3 = b3;
                f4 = b3;
            } else {
                if (b3 < f4) {
                    f4 = b3;
                }
                if (b3 > f3) {
                    f3 = b3;
                }
            }
        }
        return f >= f4 && f2 <= f3;
    }
}
