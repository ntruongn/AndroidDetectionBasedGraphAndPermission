package com.droidhen.game.racingengine.e.a;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c {
    public static int a(InputStream inputStream) {
        return ((inputStream.read() & 255) << 24) + ((inputStream.read() & 255) << 16) + ((inputStream.read() & 255) << 8) + (inputStream.read() & 255);
    }

    public static FloatBuffer a(InputStream inputStream, int i) {
        byte[] bArr = new byte[i * 4];
        inputStream.read(bArr, 0, i * 4);
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(i * 4);
        allocateDirect.order(ByteOrder.nativeOrder());
        allocateDirect.put(bArr);
        FloatBuffer asFloatBuffer = ((ByteBuffer) allocateDirect.rewind()).asFloatBuffer();
        asFloatBuffer.position(0);
        return asFloatBuffer;
    }

    public static int b(InputStream inputStream) {
        return (inputStream.read() & 255) + ((inputStream.read() & 255) << 8) + ((inputStream.read() & 255) << 16) + ((inputStream.read() & 255) << 24);
    }

    public static com.droidhen.game.racingengine.g.c[] b(InputStream inputStream, int i) {
        byte[] bArr = new byte[i * 3 * 4];
        com.droidhen.game.racingengine.g.c[] cVarArr = new com.droidhen.game.racingengine.g.c[i];
        for (int i2 = 0; i2 < i; i2++) {
            cVarArr[i2] = new com.droidhen.game.racingengine.g.c();
        }
        inputStream.read(bArr, 0, i * 3 * 4);
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(i * 3 * 4);
        allocateDirect.order(ByteOrder.nativeOrder());
        allocateDirect.put(bArr);
        FloatBuffer asFloatBuffer = ((ByteBuffer) allocateDirect.rewind()).asFloatBuffer();
        asFloatBuffer.position(0);
        for (int i3 = 0; i3 < i; i3++) {
            cVarArr[i3].a = asFloatBuffer.get(i3 * 3);
            cVarArr[i3].b = asFloatBuffer.get((i3 * 3) + 1);
            cVarArr[i3].c = asFloatBuffer.get((i3 * 3) + 2);
        }
        return cVarArr;
    }

    public static ArrayList c(InputStream inputStream) {
        ArrayList arrayList = new ArrayList();
        int a = a(inputStream);
        while (a != -1) {
            arrayList.add(a(inputStream, a));
            a = a(inputStream);
        }
        return arrayList;
    }

    public static int[] c(InputStream inputStream, int i) {
        byte[] bArr = new byte[i * 4];
        int[] iArr = new int[i];
        inputStream.read(bArr, 0, i * 4);
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(i * 4);
        allocateDirect.order(ByteOrder.nativeOrder());
        allocateDirect.put(bArr);
        IntBuffer asIntBuffer = ((ByteBuffer) allocateDirect.rewind()).asIntBuffer();
        asIntBuffer.position(0);
        asIntBuffer.get(iArr);
        return iArr;
    }

    public static com.droidhen.game.racingengine.g.c d(InputStream inputStream) {
        byte[] bArr = new byte[3 * 4];
        com.droidhen.game.racingengine.g.c cVar = new com.droidhen.game.racingengine.g.c();
        inputStream.read(bArr, 0, 3 * 4);
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(3 * 4);
        allocateDirect.order(ByteOrder.nativeOrder());
        allocateDirect.put(bArr);
        FloatBuffer asFloatBuffer = ((ByteBuffer) allocateDirect.rewind()).asFloatBuffer();
        asFloatBuffer.position(0);
        cVar.a = asFloatBuffer.get(0);
        cVar.b = asFloatBuffer.get(1);
        cVar.c = asFloatBuffer.get(2);
        return cVar;
    }

    public static float[] d(InputStream inputStream, int i) {
        byte[] bArr = new byte[i * 4];
        float[] fArr = new float[i];
        inputStream.read(bArr, 0, i * 4);
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(i * 4);
        allocateDirect.order(ByteOrder.nativeOrder());
        allocateDirect.put(bArr);
        FloatBuffer asFloatBuffer = ((ByteBuffer) allocateDirect.rewind()).asFloatBuffer();
        asFloatBuffer.position(0);
        asFloatBuffer.get(fArr);
        return fArr;
    }

    public static float e(InputStream inputStream) {
        byte[] bArr = new byte[4];
        try {
            inputStream.read(bArr, 0, 4);
        } catch (IOException e) {
            e.printStackTrace();
        }
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(4);
        allocateDirect.order(ByteOrder.nativeOrder());
        allocateDirect.put(bArr);
        return allocateDirect.getFloat(0);
    }

    public static long f(InputStream inputStream) {
        byte[] bArr = new byte[8];
        try {
            inputStream.read(bArr, 0, 8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(8);
        allocateDirect.order(ByteOrder.nativeOrder());
        allocateDirect.put(bArr);
        return allocateDirect.getLong(0);
    }

    public static String g(InputStream inputStream) {
        StringBuffer stringBuffer = new StringBuffer();
        int b = b(inputStream);
        byte[] bArr = new byte[b];
        inputStream.read(bArr, 0, b);
        stringBuffer.append(new String(bArr, 0, b));
        return stringBuffer.toString();
    }
}
