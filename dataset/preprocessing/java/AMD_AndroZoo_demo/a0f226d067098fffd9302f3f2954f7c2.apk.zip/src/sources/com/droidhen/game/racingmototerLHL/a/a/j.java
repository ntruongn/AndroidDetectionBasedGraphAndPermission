package com.droidhen.game.racingmototerLHL.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class j extends com.droidhen.game.racingengine.a.f {
    private static com.droidhen.game.racingengine.b.c.d p = null;
    private static com.droidhen.game.racingengine.b.c.d q = null;
    private com.droidhen.game.racingengine.a.d d;
    private com.droidhen.game.racingengine.a.d e;
    private com.droidhen.game.racingengine.a.d j;
    private com.droidhen.game.racingengine.a.d k;
    private com.droidhen.game.racingengine.a.d l;
    private com.droidhen.game.racingengine.a.d m;
    private com.droidhen.game.racingengine.a.d n;
    private com.droidhen.game.racingengine.a.a.e o;

    public j() {
        super(0.5f, 0.5f, 480.0f, 800.0f, -1);
        this.B = 0.0f;
        a(com.droidhen.game.racingengine.a.j.FitScreen);
        this.y = "GameMenu";
        this.o = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("begin_bg"));
        this.o.a(0.0f, 0.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.o.a(com.droidhen.game.racingengine.a.j.FitScreen);
        this.o.y = "Menu_bg";
        a(this.o);
        this.d = new com.droidhen.game.racingengine.a.d(0.0f, 103.0f, com.droidhen.game.racingengine.a.h.LEFTTOP, com.droidhen.game.racingengine.a.e.a("share_menu"));
        this.d.a(new s(this));
        this.e = new com.droidhen.game.racingengine.a.d(240.0f, 350.0f, com.droidhen.game.racingengine.a.h.CENTERTOP, com.droidhen.game.racingengine.a.e.a("play_a"), com.droidhen.game.racingengine.a.e.a("play_b"));
        this.e.a(new r(this));
        this.n = new com.droidhen.game.racingengine.a.d(240.0f, 420.0f, com.droidhen.game.racingengine.a.h.CENTERTOP, com.droidhen.game.racingengine.a.e.a("b_selectmoto_a"), com.droidhen.game.racingengine.a.e.a("b_selectmoto_b"));
        this.n.a(new q(this));
        this.j = new com.droidhen.game.racingengine.a.d(240.0f, 490.0f, com.droidhen.game.racingengine.a.h.CENTERTOP, com.droidhen.game.racingengine.a.e.a("score_a"), com.droidhen.game.racingengine.a.e.a("score_b"));
        this.j.a(new w(this));
        this.k = new com.droidhen.game.racingengine.a.d(240.0f, 560.0f, com.droidhen.game.racingengine.a.h.CENTERTOP, com.droidhen.game.racingengine.a.e.a("tutorial_a"), com.droidhen.game.racingengine.a.e.a("tutorial_b"));
        this.k.a(new v(this));
        this.l = new com.droidhen.game.racingengine.a.d(240.0f, 630.0f, com.droidhen.game.racingengine.a.h.CENTERTOP, com.droidhen.game.racingengine.a.e.a("more_a"), com.droidhen.game.racingengine.a.e.a("more_b"));
        this.l.a(new u(this));
        this.m = new t(this, 16.0f, 590.0f, com.droidhen.game.racingengine.a.h.LEFTTOP, com.droidhen.game.racingengine.a.e.a("music_01"), com.droidhen.game.racingengine.a.e.a("music_02"));
        this.m.a(new p(this));
        a(this.k);
        a(this.l);
        a(this.e);
        a(this.n);
        a(this.j);
        a(this.d);
        a(this.m);
        a(com.droidhen.game.racingmototerLHL.global.f.a().c);
        p = com.droidhen.game.racingengine.a.e.a("music_01");
        q = com.droidhen.game.racingengine.a.e.a("music_02");
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        if (com.droidhen.game.racingmototerLHL.d.a(com.droidhen.game.racingengine.a.a.a())) {
            com.droidhen.game.racingmototerLHL.global.f.e = true;
            this.m.C = p;
        } else {
            com.droidhen.game.racingmototerLHL.global.f.e = false;
            this.m.C = q;
        }
        com.droidhen.game.racingmototerLHL.global.f.b().A();
        super.d();
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l
    public void e() {
        com.droidhen.game.racingmototerLHL.global.f.b().B();
        super.e();
    }
}
