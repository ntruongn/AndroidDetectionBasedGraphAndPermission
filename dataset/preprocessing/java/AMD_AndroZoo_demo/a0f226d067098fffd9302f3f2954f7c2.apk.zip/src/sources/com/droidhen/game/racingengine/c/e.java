package com.droidhen.game.racingengine.c;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e {
    public ArrayList a = new ArrayList();
    private ArrayList e = new ArrayList();
    private int f = -1;
    private boolean g = false;
    protected boolean b = true;
    private float h = 1.0f;
    protected long c = 0;
    protected long d = 0;

    public float a() {
        return this.h;
    }

    public void a(float f) {
        this.h = f;
    }

    public void a(int i) {
        this.f = i;
    }

    public void a(b bVar) {
        bVar.a(this);
        this.e.add(bVar);
    }

    public void a(d dVar) {
        dVar.a = this;
        this.a.add(dVar);
    }

    public void a(boolean z) {
        this.b = z;
    }

    public void b(boolean z) {
        this.g = z;
    }

    public boolean b() {
        return this.b;
    }

    public b c() {
        if (this.f == -1 || !this.g) {
            return null;
        }
        return (b) this.e.get(this.f);
    }
}
