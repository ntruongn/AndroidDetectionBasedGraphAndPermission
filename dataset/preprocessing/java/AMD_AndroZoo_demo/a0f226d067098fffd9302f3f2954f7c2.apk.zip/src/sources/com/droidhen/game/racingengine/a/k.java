package com.droidhen.game.racingengine.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class k {
    public com.droidhen.game.racingengine.g.e a;
    public float b = 0.0f;
    public float c = 0.0f;
    final /* synthetic */ a d;

    public k(a aVar) {
        this.d = aVar;
        this.a = null;
        this.a = new com.droidhen.game.racingengine.g.e();
    }
}
