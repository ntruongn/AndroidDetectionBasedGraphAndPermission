package com.droidhen.game.racingengine.j.a;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    public a c;
    public float a = 0.0f;
    public float b = 0.0f;
    private boolean f = true;
    a d = null;
    private ArrayList e = new ArrayList();

    public void a() {
        this.c.a();
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.e.size()) {
                return;
            }
            this.d = (a) this.e.get(i2);
            this.d.a();
            i = i2 + 1;
        }
    }

    public void a(boolean z) {
        this.c.a(z);
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.e.size()) {
                this.f = z;
                return;
            } else {
                ((a) this.e.get(i2)).a(z);
                i = i2 + 1;
            }
        }
    }

    public boolean a(a aVar) {
        for (int i = 0; i < this.e.size(); i++) {
            if (aVar.d != ((a) this.e.get(i)).d && aVar.a((a) this.e.get(i))) {
                return true;
            }
        }
        return false;
    }

    public void b(a aVar) {
        this.e.add(aVar);
        aVar.d = this.e.indexOf(aVar);
    }

    public boolean b() {
        if (this.c.b.b.a > this.b || this.c.b.b.a < this.a) {
            this.c.b(this.c, null);
            return true;
        }
        if (c.a(this.c.a, this.a) || c.a(this.c.a, this.b)) {
            this.c.a(this.c, null);
            if (c.a(this.c.b, this.a) || c.a(this.c.b, this.b)) {
                this.c.b(this.c, null);
                return true;
            }
        }
        for (int i = 0; i < this.e.size(); i++) {
            this.c.a((a) this.e.get(i));
        }
        for (int i2 = 0; i2 < this.e.size(); i2++) {
            a aVar = (a) this.e.get(i2);
            int i3 = i2 + 1;
            while (true) {
                int i4 = i3;
                if (i4 >= this.e.size()) {
                    break;
                }
                aVar.a((a) this.e.get(i4));
                i3 = i4 + 1;
            }
        }
        return false;
    }

    public void c(a aVar) {
        this.e.remove(aVar);
    }
}
