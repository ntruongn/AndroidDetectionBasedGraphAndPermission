package com.droidhen.api.scoreclient;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class d extends SQLiteOpenHelper {
    /* JADX INFO: Access modifiers changed from: package-private */
    public d(Context context) {
        super(context, "scoreclient.db", (SQLiteDatabase.CursorFactory) null, 4);
    }

    private void a(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE score (_id INTEGER PRIMARY KEY,score_value FLOAT,mode_id INTEGER,user_name TEXT);");
        sQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS mode_id ON score(mode_id);");
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        a(sQLiteDatabase);
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        Log.w("ScoreClientProvider", "Upgrading database from version " + i + " to " + i2 + ", which will destroy all old data");
        switch (i) {
            case 1:
                sQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS mode_id ON score(mode_id);");
                return;
            case 2:
                sQLiteDatabase.execSQL("DROP TABLE IF EXISTS achievement");
                return;
            case 3:
                sQLiteDatabase.execSQL("DROP TABLE IF EXISTS mode");
                return;
            default:
                sQLiteDatabase.execSQL("DROP TABLE IF EXISTS mode");
                sQLiteDatabase.execSQL("DROP TABLE IF EXISTS score");
                sQLiteDatabase.execSQL("DROP TABLE IF EXISTS achievement");
                onCreate(sQLiteDatabase);
                return;
        }
    }
}
