package com.droidhen.game.racingengine.e.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    public long a;
    public int b;
    public int[] c;
    public float[] d;
    public com.droidhen.game.racingengine.g.e e = new com.droidhen.game.racingengine.g.e();
    public com.droidhen.game.racingengine.g.e f = new com.droidhen.game.racingengine.g.e();
}
