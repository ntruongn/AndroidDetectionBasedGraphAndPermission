package com.droidhen.game.racingengine.g;

import android.opengl.Matrix;
import java.util.Arrays;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e implements Cloneable {
    public float[] b = {1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    private static e c = new e();
    public static a a = new a();

    public e() {
        a();
    }

    public static synchronized e a(e eVar, e eVar2, e eVar3) {
        synchronized (e.class) {
            Matrix.multiplyMM(eVar3.b, 0, eVar.b, 0, eVar2.b, 0);
        }
        return eVar3;
    }

    public static void a(e eVar, e eVar2) {
        a(eVar2.b, 0, eVar.b, 0);
    }

    private static void a(float[] fArr, int i, float f, float f2, float f3, float f4) {
        com.droidhen.game.racingengine.f.b a2 = com.droidhen.game.racingengine.f.b.a();
        float[] a3 = a2.a(32);
        Matrix.setRotateM(a3, 0, f, f2, f3, f4);
        Matrix.multiplyMM(a3, 16, fArr, i, a3, 0);
        System.arraycopy(a3, 16, fArr, i, 16);
        a2.a(a3);
    }

    private static boolean a(float[] fArr, int i, float[] fArr2, int i2) {
        com.droidhen.game.racingengine.f.b a2 = com.droidhen.game.racingengine.f.b.a();
        float[] a3 = a2.a(16);
        Matrix.transposeM(a3, 0, fArr2, i2);
        float[] a4 = a2.a(12);
        a4[0] = a3[10] * a3[15];
        a4[1] = a3[11] * a3[14];
        a4[2] = a3[9] * a3[15];
        a4[3] = a3[11] * a3[13];
        a4[4] = a3[9] * a3[14];
        a4[5] = a3[10] * a3[13];
        a4[6] = a3[8] * a3[15];
        a4[7] = a3[11] * a3[12];
        a4[8] = a3[8] * a3[14];
        a4[9] = a3[10] * a3[12];
        a4[10] = a3[8] * a3[13];
        a4[11] = a3[9] * a3[12];
        float[] a5 = a2.a(16);
        a5[0] = (a4[0] * a3[5]) + (a4[3] * a3[6]) + (a4[4] * a3[7]);
        a5[0] = a5[0] - (((a4[1] * a3[5]) + (a4[2] * a3[6])) + (a4[5] * a3[7]));
        a5[1] = (a4[1] * a3[4]) + (a4[6] * a3[6]) + (a4[9] * a3[7]);
        a5[1] = a5[1] - (((a4[0] * a3[4]) + (a4[7] * a3[6])) + (a4[8] * a3[7]));
        a5[2] = (a4[2] * a3[4]) + (a4[7] * a3[5]) + (a4[10] * a3[7]);
        a5[2] = a5[2] - (((a4[3] * a3[4]) + (a4[6] * a3[5])) + (a4[11] * a3[7]));
        a5[3] = (a4[5] * a3[4]) + (a4[8] * a3[5]) + (a4[11] * a3[6]);
        a5[3] = a5[3] - (((a4[4] * a3[4]) + (a4[9] * a3[5])) + (a4[10] * a3[6]));
        a5[4] = (a4[1] * a3[1]) + (a4[2] * a3[2]) + (a4[5] * a3[3]);
        a5[4] = a5[4] - (((a4[0] * a3[1]) + (a4[3] * a3[2])) + (a4[4] * a3[3]));
        a5[5] = (a4[0] * a3[0]) + (a4[7] * a3[2]) + (a4[8] * a3[3]);
        a5[5] = a5[5] - (((a4[1] * a3[0]) + (a4[6] * a3[2])) + (a4[9] * a3[3]));
        a5[6] = (a4[3] * a3[0]) + (a4[6] * a3[1]) + (a4[11] * a3[3]);
        a5[6] = a5[6] - (((a4[2] * a3[0]) + (a4[7] * a3[1])) + (a4[10] * a3[3]));
        a5[7] = (a4[4] * a3[0]) + (a4[9] * a3[1]) + (a4[10] * a3[2]);
        a5[7] = a5[7] - (((a4[5] * a3[0]) + (a4[8] * a3[1])) + (a4[11] * a3[2]));
        a4[0] = a3[2] * a3[7];
        a4[1] = a3[3] * a3[6];
        a4[2] = a3[1] * a3[7];
        a4[3] = a3[3] * a3[5];
        a4[4] = a3[1] * a3[6];
        a4[5] = a3[2] * a3[5];
        a4[6] = a3[0] * a3[7];
        a4[7] = a3[3] * a3[4];
        a4[8] = a3[0] * a3[6];
        a4[9] = a3[2] * a3[4];
        a4[10] = a3[0] * a3[5];
        a4[11] = a3[1] * a3[4];
        a5[8] = (a4[0] * a3[13]) + (a4[3] * a3[14]) + (a4[4] * a3[15]);
        a5[8] = a5[8] - (((a4[1] * a3[13]) + (a4[2] * a3[14])) + (a4[5] * a3[15]));
        a5[9] = (a4[1] * a3[12]) + (a4[6] * a3[14]) + (a4[9] * a3[15]);
        a5[9] = a5[9] - (((a4[0] * a3[12]) + (a4[7] * a3[14])) + (a4[8] * a3[15]));
        a5[10] = (a4[2] * a3[12]) + (a4[7] * a3[13]) + (a4[10] * a3[15]);
        a5[10] = a5[10] - (((a4[3] * a3[12]) + (a4[6] * a3[13])) + (a4[11] * a3[15]));
        a5[11] = (a4[5] * a3[12]) + (a4[8] * a3[13]) + (a4[11] * a3[14]);
        a5[11] = a5[11] - (((a4[4] * a3[12]) + (a4[9] * a3[13])) + (a4[10] * a3[14]));
        a5[12] = (a4[2] * a3[10]) + (a4[5] * a3[11]) + (a4[1] * a3[9]);
        a5[12] = a5[12] - (((a4[4] * a3[11]) + (a4[0] * a3[9])) + (a4[3] * a3[10]));
        a5[13] = (a4[8] * a3[11]) + (a4[0] * a3[8]) + (a4[7] * a3[10]);
        a5[13] = a5[13] - (((a4[6] * a3[10]) + (a4[9] * a3[11])) + (a4[1] * a3[8]));
        a5[14] = (a4[6] * a3[9]) + (a4[11] * a3[11]) + (a4[3] * a3[8]);
        a5[14] = a5[14] - (((a4[10] * a3[11]) + (a4[2] * a3[8])) + (a4[7] * a3[9]));
        a5[15] = (a4[10] * a3[10]) + (a4[4] * a3[8]) + (a4[9] * a3[9]);
        a5[15] = a5[15] - (((a4[8] * a3[9]) + (a4[11] * a3[10])) + (a4[5] * a3[8]));
        float f = 1.0f / ((((a3[0] * a5[0]) + (a3[1] * a5[1])) + (a3[2] * a5[2])) + (a3[3] * a5[3]));
        for (int i3 = 0; i3 < 16; i3++) {
            fArr[i3 + i] = a5[i3] * f;
        }
        a2.a(a5);
        a2.a(a4);
        a2.a(a3);
        return true;
    }

    public static boolean b(e eVar, e eVar2) {
        for (int i = 0; i < 16; i++) {
            if (Math.abs(eVar.b[i] - eVar2.b[i]) > 1.0E-4d) {
                return false;
            }
        }
        return true;
    }

    public static e d() {
        return (e) a.b();
    }

    public static void d(e eVar) {
        a.a(eVar);
    }

    public e a(e eVar) {
        a(eVar.b, 0, this.b, 0);
        return eVar;
    }

    public void a() {
        Arrays.fill(this.b, 0.0f);
        this.b[0] = 1.0f;
        this.b[5] = 1.0f;
        this.b[10] = 1.0f;
        this.b[15] = 1.0f;
    }

    protected void a(float f, float f2, float f3) {
        float[] fArr = this.b;
        fArr[12] = fArr[12] + f;
        float[] fArr2 = this.b;
        fArr2[13] = fArr2[13] + f2;
        float[] fArr3 = this.b;
        fArr3[14] = fArr3[14] + f3;
    }

    protected void a(float f, float f2, float f3, float f4) {
        a(this.b, 0, f4, f, f2, f3);
    }

    public void a(c cVar) {
        a();
        e d = d();
        if (cVar.a != 0.0f) {
            d.a();
            d.a(1.0f, 0.0f, 0.0f, cVar.a);
            b(d);
        }
        if (cVar.b != 0.0f) {
            d.a();
            d.a(0.0f, 1.0f, 0.0f, cVar.b);
            b(d);
        }
        if (cVar.c != 0.0f) {
            d.a();
            d.a(0.0f, 0.0f, 1.0f, cVar.c);
            b(d);
        }
        d(d);
    }

    public synchronized void a(c cVar, c cVar2) {
        com.droidhen.game.racingengine.f.b a2 = com.droidhen.game.racingengine.f.b.a();
        float[] a3 = a2.a(4);
        float[] a4 = a2.a(4);
        a4[0] = cVar.a;
        a4[1] = cVar.b;
        a4[2] = cVar.c;
        a4[3] = 1.0f;
        Matrix.multiplyMV(a3, 0, this.b, 0, a4, 0);
        cVar2.a(a3[0], a3[1], a3[2]);
        a2.a(a3);
        a2.a(a4);
    }

    public void a(c cVar, c cVar2, c cVar3) {
        a();
        if (cVar != null && (cVar.a != 1.0f || cVar.b != 1.0f || cVar.c != 1.0f)) {
            b(cVar.a, cVar.b, cVar.c);
        }
        e d = d();
        if (cVar2 != null) {
            if (cVar2.a != 0.0f) {
                d.a();
                d.a(1.0f, 0.0f, 0.0f, cVar2.a);
                b(d);
            }
            if (cVar2.b != 0.0f) {
                d.a();
                d.a(0.0f, 1.0f, 0.0f, cVar2.b);
                b(d);
            }
            if (cVar2.c != 0.0f) {
                d.a();
                d.a(0.0f, 0.0f, 1.0f, cVar2.c);
                b(d);
            }
        }
        if (cVar3 != null) {
            d.a();
            d.a(cVar3.a, cVar3.b, cVar3.c);
            b(d);
        }
        d(d);
    }

    public void b() {
        Arrays.fill(this.b, 0.0f);
    }

    protected void b(float f, float f2, float f3) {
        this.b[0] = f;
        this.b[5] = f2;
        this.b[10] = f3;
    }

    public synchronized void b(c cVar) {
        a();
        float[] fArr = this.b;
        fArr[12] = fArr[12] + cVar.a;
        float[] fArr2 = this.b;
        fArr2[13] = fArr2[13] + cVar.b;
        float[] fArr3 = this.b;
        fArr3[14] = fArr3[14] + cVar.c;
    }

    public synchronized void b(e eVar) {
        Matrix.multiplyMM(this.b, 0, eVar.b, 0, this.b, 0);
    }

    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public e clone() {
        try {
            e eVar = (e) super.clone();
            eVar.b = (float[]) this.b.clone();
            return eVar;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    public void c(c cVar) {
        a();
        this.b[0] = cVar.a;
        this.b[5] = cVar.b;
        this.b[10] = cVar.c;
    }

    public synchronized void c(e eVar) {
        System.arraycopy(eVar.b, 0, this.b, 0, 16);
    }

    public c d(c cVar) {
        cVar.a = this.b[12];
        cVar.b = this.b[13];
        cVar.c = this.b[14];
        return cVar;
    }

    public String toString() {
        return "Matrix4f\n[\n " + this.b[0] + "  " + this.b[1] + "  " + this.b[2] + "  " + this.b[3] + " \n " + this.b[4] + "  " + this.b[5] + "  " + this.b[6] + "  " + this.b[7] + " \n " + this.b[8] + "  " + this.b[9] + "  " + this.b[10] + "  " + this.b[11] + " \n " + this.b[12] + "  " + this.b[13] + "  " + this.b[14] + "  " + this.b[15] + " \n]";
    }
}
