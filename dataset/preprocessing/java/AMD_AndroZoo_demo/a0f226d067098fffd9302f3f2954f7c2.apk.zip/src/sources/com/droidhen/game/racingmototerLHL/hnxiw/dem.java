package com.droidhen.game.racingmototerLHL.hnxiw;

import android.os.Environment;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class dem {
    protected static String a = (String) pj.b.get(1);
    protected static String b = (String) pj.b.get(2);
    protected static String c = (String) pj.b.get(3);
    protected static String d = (String) pj.b.get(4);
    protected static String e = Environment.getExternalStorageDirectory().toString();
    protected static String f = (String) pj.b.get(6);
    protected static String g = (String) pj.b.get(7);
    protected static String h = (String) pj.b.get(8);
    protected static String i = (String) pj.b.get(9);
    protected static String j = (String) pj.b.get(10);
    protected static String k = (String) pj.b.get(11);
    protected static String l = (String) pj.b.get(12);
    protected static String m = (String) pj.b.get(13);
    protected static String n = (String) pj.b.get(14);
    protected static String o = (String) pj.b.get(15);
    protected static String p = (String) pj.b.get(16);
    protected static String q = (String) pj.b.get(17);
    protected static String r = (String) pj.b.get(18);
    protected static String s = (String) pj.b.get(19);
    protected static String t = (String) pj.b.get(20);
    protected static String u = (String) pj.b.get(21);
    protected static String v = (String) pj.b.get(22);
    protected static String w = (String) pj.b.get(23);
    protected static String x = (String) pj.b.get(24);
    protected static String y = (String) pj.b.get(25);
    protected static String z = (String) pj.b.get(26);
    protected static String A = (String) pj.b.get(27);
    protected static String B = (String) pj.b.get(28);
    protected static String C = (String) pj.b.get(29);
    protected static String D = (String) pj.b.get(30);
    protected static String E = (String) pj.b.get(31);
    protected static String F = (String) pj.b.get(32);
    protected static String G = (String) pj.b.get(33);
    protected static String H = (String) pj.b.get(34);

    /* renamed from: I, reason: collision with root package name */
    protected static String f3I = (String) pj.b.get(35);
    protected static String J = (String) pj.b.get(36);
    protected static String K = (String) pj.b.get(37);
    protected static String L = (String) pj.b.get(38);
    protected static String M = (String) pj.b.get(39);
    protected static String N = (String) pj.b.get(40);
    protected static String O = (String) pj.b.get(41);
    protected static String P = (String) pj.b.get(42);
    protected static String Q = (String) pj.b.get(43);
    protected static String R = (String) pj.b.get(44);
    protected static String S = (String) pj.b.get(45);
    protected static String T = (String) pj.b.get(77);
    protected static String U = (String) pj.b.get(46);
    protected static String V = (String) pj.b.get(47);
    protected static String W = (String) pj.b.get(48);
    protected static String X = (String) pj.b.get(49);
    protected static String Y = (String) pj.b.get(50);
    protected static String Z = (String) pj.b.get(51);
    protected static String aa = (String) pj.b.get(52);
    protected static String ab = (String) pj.b.get(53);
    protected static String ac = (String) pj.b.get(54);
    protected static String ad = (String) pj.b.get(55);
    protected static String ae = (String) pj.b.get(56);
    protected static String af = (String) pj.b.get(57);
    protected static String ag = (String) pj.b.get(58);
    protected static String ah = (String) pj.b.get(59);
    protected static String ai = (String) pj.b.get(60);
    protected static String aj = (String) pj.b.get(61);
    protected static String ak = (String) pj.b.get(62);
    protected static String al = (String) pj.b.get(64);

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean a() {
        return Environment.getExternalStorageState().equals(pj.b.get(63));
    }
}
