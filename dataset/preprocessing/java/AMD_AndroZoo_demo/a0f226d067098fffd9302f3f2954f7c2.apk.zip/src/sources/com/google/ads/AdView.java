package com.google.ads;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.ads.util.AdUtil;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class AdView extends RelativeLayout implements a {
    private defpackage.c a;

    public AdView(Activity activity, f fVar, String str) {
        super(activity.getApplicationContext());
        if (a(activity, fVar)) {
            a(activity, fVar, str);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00d4  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x012a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public AdView(android.content.Context r9, android.util.AttributeSet r10) {
        /*
            Method dump skipped, instructions count: 305
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.ads.AdView.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    public AdView(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet);
    }

    private void a(Activity activity, f fVar, String str) {
        this.a = new defpackage.c(activity, this, fVar, str);
        setGravity(17);
        setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        addView(this.a.h(), (int) TypedValue.applyDimension(1, fVar.a(), activity.getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(1, fVar.b(), activity.getResources().getDisplayMetrics()));
    }

    private void a(Context context, String str, int i, f fVar) {
        if (getChildCount() == 0) {
            TextView textView = new TextView(context);
            textView.setGravity(17);
            textView.setText(str);
            textView.setTextColor(i);
            textView.setBackgroundColor(-16777216);
            LinearLayout linearLayout = new LinearLayout(context);
            linearLayout.setGravity(17);
            LinearLayout linearLayout2 = new LinearLayout(context);
            linearLayout2.setGravity(17);
            linearLayout2.setBackgroundColor(i);
            int applyDimension = (int) TypedValue.applyDimension(1, fVar.a(), context.getResources().getDisplayMetrics());
            int applyDimension2 = (int) TypedValue.applyDimension(1, fVar.b(), context.getResources().getDisplayMetrics());
            linearLayout.addView(textView, applyDimension - 2, applyDimension2 - 2);
            linearLayout2.addView(linearLayout);
            addView(linearLayout2, applyDimension, applyDimension2);
        }
    }

    private void a(Context context, String str, f fVar) {
        com.google.ads.util.d.b(str);
        a(context, str, -65536, fVar);
        if (isInEditMode()) {
            return;
        }
        if (context instanceof Activity) {
            a((Activity) context, fVar, "");
        } else {
            com.google.ads.util.d.b("AdView was initialized with a Context that wasn't an Activity.");
        }
    }

    private boolean a(Context context, f fVar) {
        if (AdUtil.b(context)) {
            return true;
        }
        a(context, "You must have INTERNET and ACCESS_NETWORK_STATE permissions in AndroidManifest.xml.", fVar);
        return false;
    }

    public void a(c cVar) {
        if (this.a.d() == null) {
            com.google.ads.util.d.e("activity was null while checking permissions.");
            return;
        }
        if (a()) {
            this.a.b();
        }
        this.a.a(cVar);
    }

    public boolean a() {
        return this.a.n();
    }
}
