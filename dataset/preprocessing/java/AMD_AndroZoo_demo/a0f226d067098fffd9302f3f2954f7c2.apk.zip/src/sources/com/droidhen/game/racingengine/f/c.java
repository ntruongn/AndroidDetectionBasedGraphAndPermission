package com.droidhen.game.racingengine.f;

import java.util.ArrayList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public abstract class c {
    private int a = 5;
    private ArrayList b = null;
    private int c = 0;

    private void c() {
        this.b = new ArrayList();
        this.c = 0;
        for (int i = 0; i < this.a; i++) {
            this.b.add(a());
        }
    }

    public abstract Object a();

    public void a(Object obj) {
        synchronized (this.b) {
            this.c--;
            this.b.add(obj);
        }
    }

    public Object b() {
        Object remove;
        if (this.b == null) {
            c();
        }
        synchronized (this.b) {
            remove = this.b.size() > 0 ? this.b.remove(this.b.size() - 1) : null;
            if (remove == null) {
                remove = a();
            }
            this.c++;
        }
        return remove;
    }
}
