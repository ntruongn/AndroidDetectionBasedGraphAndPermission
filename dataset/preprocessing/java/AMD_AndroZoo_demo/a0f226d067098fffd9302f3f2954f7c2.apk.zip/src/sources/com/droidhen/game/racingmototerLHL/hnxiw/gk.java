package com.droidhen.game.racingmototerLHL.hnxiw;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class gk {
    String a;
    String b;
    String c;
    String d;
    String e;
    String f;
    String g;
    String h;
    String i;
    String j;
    String k;
    String l;
    String m;
    String n;

    public gk(Context context) {
        this.a = "";
        this.b = "";
        this.c = "";
        this.d = "";
        this.e = "";
        this.f = "";
        this.g = "";
        this.h = "";
        this.i = dem.al;
        this.j = "";
        this.k = "";
        this.l = "";
        this.m = "";
        this.n = "";
    }

    public gk(Context context, String str) {
        this.a = "";
        this.b = "";
        this.c = "";
        this.d = "";
        this.e = "";
        this.f = "";
        this.g = "";
        this.h = "";
        this.i = dem.al;
        this.j = "";
        this.k = "";
        this.l = "";
        this.m = "";
        this.n = "";
        this.n = str;
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(dem.w);
        this.a = telephonyManager.getDeviceId();
        this.b = telephonyManager.getSubscriberId();
        this.c = Build.VERSION.RELEASE;
        this.d = Build.MODEL;
        this.e = a(context);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((WindowManager) context.getSystemService(dem.x)).getDefaultDisplay().getMetrics(displayMetrics);
        this.f = "" + displayMetrics.widthPixels;
        this.g = "" + displayMetrics.heightPixels;
        this.h = dem.a;
        this.j = this.i.substring(0, 2);
        this.k = this.i.substring(2, 5);
        this.l = this.i.substring(5, 9);
        this.m = this.i.substring(9, 11);
    }

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:15:0x0025 -> B:8:0x001a). Please submit an issue!!! */
    private String a(Context context) {
        try {
            NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
            if (activeNetworkInfo != null) {
                int type = activeNetworkInfo.getType();
                if (type == 0) {
                    String subtypeName = activeNetworkInfo.getSubtypeName();
                    return subtypeName != null ? subtypeName : dem.u;
                }
                if (type == 1) {
                    return dem.v;
                }
            }
        } catch (Exception e) {
        }
        return dem.t;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String a() {
        return this.a;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String b() {
        return this.b;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String c() {
        return this.c;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String d() {
        return this.d;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String e() {
        return this.e;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String f() {
        return this.f;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String g() {
        return this.g;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String h() {
        return this.h;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String i() {
        return this.i;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String j() {
        return this.j;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String k() {
        return this.k;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String l() {
        return this.l;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String m() {
        return this.m;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public String n() {
        return this.n;
    }
}
