package com.droidhen.game.racingmototerLHL.b;

import java.util.ArrayList;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class n implements com.droidhen.game.racingengine.i.a {
    int d;
    int e;
    private ArrayList h = null;
    k a = null;
    k b = null;
    k c = null;
    com.droidhen.game.racingengine.i.a f = null;
    private ArrayList g = new ArrayList();

    public void a(com.droidhen.game.racingengine.i.a aVar) {
        this.g.add(aVar);
    }

    public void a(ArrayList arrayList) {
        this.h = arrayList;
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void a(GL10 gl10) {
        if (this.h == null) {
            return;
        }
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.h.size()) {
                return;
            }
            this.f = ((k) this.h.get(i2)).a;
            this.f.a(gl10);
            i = i2 + 1;
        }
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void b() {
        if (this.h == null) {
            return;
        }
        int size = this.h.size();
        this.d = 0;
        while (this.d < size) {
            this.e = 0;
            while (this.e < (size - this.d) - 1) {
                this.a = (k) this.h.get(this.e);
                this.b = (k) this.h.get(this.e + 1);
                if (this.a.d.b.b.b > this.b.d.b.b.b) {
                    this.h.set(this.e, this.b);
                    this.h.set(this.e + 1, this.a);
                }
                this.e++;
            }
            this.d++;
        }
    }

    public boolean b(com.droidhen.game.racingengine.i.a aVar) {
        return this.g.remove(aVar);
    }
}
