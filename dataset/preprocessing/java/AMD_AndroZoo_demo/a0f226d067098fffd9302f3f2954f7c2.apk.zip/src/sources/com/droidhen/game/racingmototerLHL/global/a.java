package com.droidhen.game.racingmototerLHL.global;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    public int[] a;
    public float b;
    public float c;
    public float d;

    public a() {
        this.a = new int[3];
    }

    public a(int[] iArr, float f, float f2, float f3) {
        this.a = new int[3];
        this.a = iArr;
        this.b = f;
        this.c = f2;
        this.d = f3;
    }

    public void a(a aVar) {
        for (int i = 0; i < 3; i++) {
            this.a[i] = aVar.a[i];
        }
        this.b = aVar.b;
        this.c = aVar.c;
        this.d = aVar.d;
    }
}
