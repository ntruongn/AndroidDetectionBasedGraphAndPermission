package com.droidhen.game.racingengine.b.a;

import android.opengl.GLU;
import com.droidhen.game.racingengine.g.c;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class b {
    public c a;
    public c b;
    public c c;
    public c d;
    public float e;
    public float f;
    public float g;

    public b() {
        this.d = null;
        this.e = 50.0f;
        this.f = 500.0f;
        this.g = 3500.0f;
        this.a = new c();
        this.b = new c();
        this.c = new c();
        this.d = new c();
        this.b.c = 260.0f;
        this.a.a = 0.0f;
        this.a.b = 600.0f;
        this.a.c = -600.0f;
        c d = c.d();
        this.c.a(this.b.a(this.a, d).c(c.d).c());
        c.f(d);
    }

    public b(c cVar, c cVar2) {
        this.d = null;
        this.e = 50.0f;
        this.f = 500.0f;
        this.g = 3500.0f;
        this.b = cVar;
        this.a = cVar2;
        this.c = new c();
        c d = c.d();
        this.c.a(cVar.a(cVar2, d).c(c.d).c());
        c.f(d);
    }

    public void a(GL10 gl10) {
        gl10.glMatrixMode(5889);
        gl10.glLoadIdentity();
        GLU.gluPerspective(gl10, this.e, com.droidhen.game.racingengine.a.c.a() / com.droidhen.game.racingengine.a.c.b(), this.f, this.g);
        gl10.glMatrixMode(5888);
        gl10.glLoadIdentity();
        GLU.gluLookAt(gl10, this.a.a, this.a.b, this.a.c, this.b.a, this.b.b, this.b.c, this.c.a, this.c.b, this.c.c);
    }
}
