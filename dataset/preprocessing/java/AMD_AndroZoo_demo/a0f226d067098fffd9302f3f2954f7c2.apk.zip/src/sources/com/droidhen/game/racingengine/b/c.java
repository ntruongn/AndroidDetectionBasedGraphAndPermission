package com.droidhen.game.racingengine.b;

import java.nio.ByteBuffer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class c {
    private ByteBuffer a;
    private int b;

    public c(ByteBuffer byteBuffer, int i) {
        this.a = ByteBuffer.allocate(byteBuffer.limit() * 1);
        this.a.put(byteBuffer);
        this.b = i;
    }

    public int a() {
        return this.b;
    }

    public ByteBuffer b() {
        return this.a;
    }

    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public c clone() {
        this.a.position(0);
        return new c(this.a, a());
    }
}
