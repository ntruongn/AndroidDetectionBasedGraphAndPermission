package com.droidhen.game.racingmototerLHL.a.a;

import android.widget.Toast;
import com.droidhen.game.racingmototerLHL.GameActivity;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class am implements com.droidhen.game.racingengine.a.g {
    final /* synthetic */ e a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public am(e eVar) {
        this.a = eVar;
    }

    @Override // com.droidhen.game.racingengine.a.g
    public void a(com.droidhen.game.racingengine.a.d dVar) {
        float f;
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.b);
        int f2 = com.droidhen.game.racingmototerLHL.b.j.f();
        if (this.a.e < com.droidhen.game.racingmototerLHL.b.l.d[f2].c) {
            f = this.a.w;
            if (f <= 0.0f) {
                Toast.makeText(com.droidhen.game.racingengine.a.a.a(), "You need more socre to unlock this moto", 0).show();
                this.a.w = 3.0f;
                return;
            }
            return;
        }
        com.droidhen.game.racingengine.b.a e = com.droidhen.game.racingmototerLHL.b.j.a().e();
        com.droidhen.game.racingmototerLHL.global.f.b().n().c();
        com.droidhen.game.racingmototerLHL.global.f.b().a(e, f2);
        com.droidhen.game.racingmototerLHL.global.f.b().o = !com.droidhen.game.racingmototerLHL.d.b(com.droidhen.game.racingengine.a.a.a());
        com.droidhen.game.racingmototerLHL.global.f.b().t();
    }
}
