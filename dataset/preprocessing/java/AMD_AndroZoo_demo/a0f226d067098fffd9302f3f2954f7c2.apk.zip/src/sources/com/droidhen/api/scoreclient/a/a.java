package com.droidhen.api.scoreclient.a;

import java.util.Comparator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class a implements Comparator {
    final /* synthetic */ c a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(c cVar) {
        this.a = cVar;
    }

    @Override // java.util.Comparator
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public int compare(com.droidhen.api.scoreclient.b.a aVar, com.droidhen.api.scoreclient.b.a aVar2) {
        return aVar.b() - aVar2.b();
    }
}
