package com.droidhen.game.racingengine.b;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class h {
    private FloatBuffer a;
    private int b;

    public h(FloatBuffer floatBuffer, int i) {
        this.b = 0;
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(floatBuffer.limit() * 4);
        allocateDirect.order(ByteOrder.nativeOrder());
        this.a = allocateDirect.asFloatBuffer();
        this.a.put(floatBuffer);
        this.b = i;
    }

    public int a() {
        return this.b;
    }

    public FloatBuffer b() {
        return this.a;
    }

    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public h clone() {
        this.a.position(0);
        return new h(this.a, a());
    }
}
