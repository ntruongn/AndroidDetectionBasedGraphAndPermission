package com.droidhen.game.racingengine.b;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class g implements com.droidhen.game.racingengine.i.a {
    public String e;
    protected a f;
    protected f g;
    protected com.droidhen.game.racingengine.b.c.d h = null;
    public boolean i = true;
    protected float j = 1.0f;
    public com.droidhen.game.racingengine.g.c k = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c l = new com.droidhen.game.racingengine.g.c();
    public com.droidhen.game.racingengine.g.c m = new com.droidhen.game.racingengine.g.c(1.0f, 1.0f, 1.0f);
    public com.droidhen.game.racingengine.g.e n = null;
    public com.droidhen.game.racingengine.g.e o = new com.droidhen.game.racingengine.g.e();
    public boolean p = false;
    public boolean q = false;
    public boolean r = true;
    boolean s = false;
    boolean t = false;
    boolean u = false;
    com.droidhen.game.racingengine.g.e v = new com.droidhen.game.racingengine.g.e();

    public g(f fVar) {
        this.g = fVar;
        this.e = fVar.b;
    }

    public void a(com.droidhen.game.racingengine.b.c.d dVar) {
        this.h = dVar;
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void a(GL10 gl10) {
        if (this.i && this.g.g) {
            if (this.j != 1.0f) {
                this.s = true;
                gl10.glColor4f(1.0f, 1.0f, 1.0f, this.j);
            }
            if (this.p && (this.f == null || !this.f.c)) {
                gl10.glEnable(2929);
                gl10.glDepthFunc(513);
                gl10.glClearDepthf(1.0f);
                gl10.glClear(256);
            }
            if (this.g.j() && this.g.d) {
                gl10.glNormalPointer(5126, 0, this.g.a().g().b());
                gl10.glEnableClientState(32885);
            } else {
                gl10.glDisableClientState(32885);
            }
            if (this.g.k() && this.g.f) {
                gl10.glColorPointer(4, 5121, 0, this.g.a().h().b());
                gl10.glEnableClientState(32886);
            } else {
                gl10.glDisableClientState(32886);
            }
            if (this.g.d() == com.droidhen.game.racingengine.d.a.POINTS) {
                if (this.g.f()) {
                    gl10.glEnable(2832);
                    gl10.glHint(3153, 4354);
                } else {
                    gl10.glDisable(2832);
                }
                gl10.glPointSize(this.g.e());
            }
            if (this.g.d() == com.droidhen.game.racingengine.d.a.LINES || this.g.d() == com.droidhen.game.racingengine.d.a.LINE_STRIP || this.g.d() == com.droidhen.game.racingengine.d.a.LINE_LOOP) {
                if (this.g.h()) {
                    gl10.glEnable(2848);
                    gl10.glHint(3154, 4354);
                } else {
                    gl10.glDisable(2848);
                }
                gl10.glLineWidth(this.g.g());
            }
            if (this.g.i() && this.g.h) {
                gl10.glEnable(3553);
                gl10.glEnableClientState(32888);
                if (this.g.b().a() <= 0) {
                    return;
                }
                com.droidhen.game.racingengine.d.c a = this.g.b().a(0);
                if (this.h == null) {
                    this.h = com.droidhen.game.racingengine.a.e.a(a.a);
                }
                gl10.glBindTexture(3553, this.h.a);
                gl10.glTexCoordPointer(2, 5126, 0, this.g.a().f().b());
                if (this.r && this.h.d) {
                    gl10.glTexParameterf(3553, 10241, 9985.0f);
                } else {
                    gl10.glTexParameterf(3553, 10241, 9728.0f);
                }
                gl10.glTexParameterf(3553, 10240, 9729.0f);
                for (int i = 0; i < a.i.size(); i++) {
                    gl10.glTexEnvx(8960, ((com.droidhen.game.racingengine.d.b) a.i.get(i)).a, ((com.droidhen.game.racingengine.d.b) a.i.get(i)).b);
                }
                gl10.glTexParameterx(3553, 10242, a.c ? 10497 : 33071);
                gl10.glTexParameterx(3553, 10243, a.d ? 10497 : 33071);
                if (a.e != 0.0f || a.f != 0.0f || a.g != 1.0f || a.h != 1.0f) {
                    this.t = true;
                    gl10.glMatrixMode(5890);
                    gl10.glLoadIdentity();
                    gl10.glTranslatef(a.e, a.f, 0.0f);
                    gl10.glScalef(a.g, a.h, 1.0f);
                    gl10.glMatrixMode(5888);
                }
            } else {
                gl10.glDisable(3553);
                gl10.glDisableClientState(32888);
            }
            gl10.glPushMatrix();
            if (this.n == null) {
                e();
            }
            gl10.glMultMatrixf(this.n.b, 0);
            this.v.a(this.m, this.l, this.k);
            gl10.glMultMatrixf(this.v.b, 0);
            gl10.glMultMatrixf(this.o.b, 0);
            if (!(this instanceof com.droidhen.game.racingengine.c.f)) {
                gl10.glMultMatrixf(this.g.u.b, 0);
            }
            gl10.glVertexPointer(3, 5126, 0, this.g.a().e().b());
            gl10.glDrawElements(this.g.d().a(), this.g.a().a(), 5123, this.g.c().b());
            gl10.glPopMatrix();
            if (this.t) {
                gl10.glMatrixMode(5890);
                gl10.glLoadIdentity();
                gl10.glMatrixMode(5888);
            }
            if (this.p && (this.f == null || !this.f.c)) {
                gl10.glDisable(2929);
            }
            if (this.s) {
                gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
    }

    @Override // com.droidhen.game.racingengine.i.a
    public void b() {
    }

    public f d() {
        return this.g;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void e() {
        com.droidhen.game.racingengine.g.e d = com.droidhen.game.racingengine.g.e.d();
        d.a(this.g.s);
        com.droidhen.game.racingengine.g.e d2 = com.droidhen.game.racingengine.g.e.d();
        d2.a(this.g.t);
        com.droidhen.game.racingengine.g.e d3 = com.droidhen.game.racingengine.g.e.d();
        d3.a(this.g.q);
        com.droidhen.game.racingengine.g.e d4 = com.droidhen.game.racingengine.g.e.d();
        com.droidhen.game.racingengine.g.e d5 = com.droidhen.game.racingengine.g.e.d();
        com.droidhen.game.racingengine.g.e.a(com.droidhen.game.racingengine.g.e.a(d, d3, d4), d2, d5);
        com.droidhen.game.racingengine.g.e.d(d4);
        com.droidhen.game.racingengine.g.e.d(d3);
        com.droidhen.game.racingengine.g.e.d(d2);
        com.droidhen.game.racingengine.g.e.d(d);
        com.droidhen.game.racingengine.g.e d6 = com.droidhen.game.racingengine.g.e.d();
        d6.b(this.g.p);
        com.droidhen.game.racingengine.g.e d7 = com.droidhen.game.racingengine.g.e.d();
        d7.c(this.g.r);
        com.droidhen.game.racingengine.g.e d8 = com.droidhen.game.racingengine.g.e.d();
        com.droidhen.game.racingengine.g.e d9 = com.droidhen.game.racingengine.g.e.d();
        com.droidhen.game.racingengine.g.e.a(com.droidhen.game.racingengine.g.e.a(d6, d5, d8), d7, d9);
        com.droidhen.game.racingengine.g.e.d(d5);
        com.droidhen.game.racingengine.g.e.d(d8);
        com.droidhen.game.racingengine.g.e.d(d6);
        com.droidhen.game.racingengine.g.e.d(d7);
        this.n = new com.droidhen.game.racingengine.g.e();
        com.droidhen.game.racingengine.g.e.a(d9, new com.droidhen.game.racingengine.g.e(), this.n);
        com.droidhen.game.racingengine.g.e.d(d9);
    }

    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public g clone() {
        g gVar = new g(this.g);
        if (this.n != null) {
            gVar.n = new com.droidhen.game.racingengine.g.e();
            gVar.n.c(this.n);
        }
        gVar.p = this.p;
        gVar.q = this.q;
        return gVar;
    }

    public a g() {
        return this.f;
    }
}
