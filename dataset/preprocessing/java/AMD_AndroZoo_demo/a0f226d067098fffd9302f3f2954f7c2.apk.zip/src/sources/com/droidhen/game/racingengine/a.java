package com.droidhen.game.racingengine;

import android.content.res.AssetManager;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a {
    public static BaseActivity a;
    public static b b;
    public static c c;
    public static AssetManager d;
    public static com.droidhen.game.racingengine.b.c.c e;
    public static GL10 f;
    public static boolean g;
}
