package com.droidhen.game.racingmototerLHL.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class i {
    public String a;
    public String b;
    public int c;
    public String d;
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;
    public String j;
    public String[] k;
    public String l;
    public int m;
    public int n;

    public i(String str, String str2, int i, String str3, String str4, String str5, String[] strArr, String str6, String str7, String str8, String str9, String str10, int i2, int i3) {
        this.a = str;
        this.b = str2;
        this.c = i;
        this.d = str3;
        this.e = str4;
        this.f = str5;
        this.k = strArr;
        this.l = str6;
        this.g = str7;
        this.h = str8;
        this.i = str9;
        this.j = str10;
        this.m = i2;
        this.n = i3;
    }
}
