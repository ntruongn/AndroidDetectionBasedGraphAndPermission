package com.droidhen.game.racingmototerLHL.a.a;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class aj extends com.droidhen.game.racingengine.a.a.e {
    final /* synthetic */ a d;
    private float e;
    private float f;
    private float g;
    private float h;
    private int i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public aj(a aVar) {
        super(com.droidhen.game.racingengine.a.e.a("rotate"));
        this.d = aVar;
        this.e = 0.0f;
        this.f = 0.0f;
        this.g = 70.0f;
        this.h = 9.0f;
    }

    @Override // com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        this.g = this.E * 0.5f;
        c();
        gl10.glBindTexture(3553, this.C.a);
        gl10.glPushMatrix();
        gl10.glTranslatef(this.G.a, this.G.b, 0.0f);
        gl10.glTranslatef(this.g, this.F * 0.5f, 0.0f);
        gl10.glRotatef(-this.e, 0.0f, 0.0f, 1.0f);
        gl10.glTranslatef(-this.g, (-0.5f) * this.F, 0.0f);
        gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.M.position(0);
        gl10.glTexCoordPointer(2, 5126, 0, this.M);
        this.N.position(0);
        gl10.glVertexPointer(3, 5126, 0, this.N);
        this.O.position(0);
        gl10.glDrawElements(4, this.D, 5123, this.O);
        gl10.glPopMatrix();
    }

    @Override // com.droidhen.game.racingengine.a.a.e, com.droidhen.game.racingengine.a.a.d, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        super.c();
        this.f += this.h;
        if (((int) (this.f / 45.0f)) > this.i) {
            this.i++;
            this.e = this.i * 45.0f;
        }
    }
}
