package com.droidhen.game.racingengine.a;

import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public abstract class l implements i {
    public com.droidhen.game.racingengine.b.c.d C;
    protected float E;
    protected float F;
    public String y = "none";
    public boolean z = true;
    public boolean A = true;
    public float B = 1.0f;
    protected int D = 0;
    protected com.droidhen.game.racingengine.g.c G = new com.droidhen.game.racingengine.g.c();
    protected h H = h.LEFTBOTTOM;

    /* renamed from: I, reason: collision with root package name */
    protected float f0I = 0.0f;
    protected float J = 0.0f;
    protected h K = h.LEFTBOTTOM;
    public boolean L = true;
    protected FloatBuffer M = null;
    protected FloatBuffer N = null;
    protected ShortBuffer O = null;
    protected ArrayList P = null;
    protected l Q = null;
    protected float R = 480.0f;
    protected float S = 800.0f;
    protected j T = j.KeepRatio;

    public void a() {
    }

    public void a(h hVar) {
        this.H = hVar;
    }

    public void a(j jVar) {
        this.T = jVar;
    }

    public void a(l lVar) {
        if (this.P == null) {
            this.P = new ArrayList();
        }
        this.P.add(lVar);
        lVar.Q = this;
        if (lVar.L) {
            lVar.G.e(this.G);
        }
    }

    @Override // com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        if (this.z) {
            gl10.glPushMatrix();
            gl10.glTranslatef(this.G.a, this.G.b, this.G.c);
            gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            gl10.glBindTexture(3553, this.C.a);
            gl10.glTexCoordPointer(2, 5126, 0, this.M);
            gl10.glVertexPointer(3, 5126, 0, this.N);
            gl10.glDrawElements(4, this.D, 5123, this.O);
            gl10.glPopMatrix();
        }
    }

    public void b(float f) {
        this.B = f;
    }

    @Override // com.droidhen.game.racingengine.a.i
    public boolean b(float f, float f2) {
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.i
    public void c() {
    }

    @Override // com.droidhen.game.racingengine.a.i
    public boolean c(float f, float f2) {
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.i
    public void d() {
    }

    @Override // com.droidhen.game.racingengine.a.i
    public boolean d(float f, float f2) {
        return false;
    }

    public void e() {
    }

    public float l() {
        return this.Q != null ? this.Q.G.b + this.G.b + this.F : this.G.b + this.F;
    }

    public void l(float f, float f2) {
        this.G.a = f;
        this.G.b = f2;
    }

    public float m() {
        return this.Q != null ? this.Q.G.b + this.G.b : this.G.b;
    }

    public float n() {
        return this.Q != null ? this.Q.G.a + this.G.a : this.G.a;
    }

    public float o() {
        return this.Q != null ? this.Q.G.a + this.G.a + this.E : this.G.a + this.E;
    }

    @Override // com.droidhen.game.racingengine.a.i
    public String p() {
        return this.y;
    }
}
