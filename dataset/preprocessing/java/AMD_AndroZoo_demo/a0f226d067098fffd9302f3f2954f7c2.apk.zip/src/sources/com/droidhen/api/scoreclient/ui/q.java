package com.droidhen.api.scoreclient.ui;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class q extends Thread {
    double a;
    int b;
    final /* synthetic */ HighScoresActivity c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public q(HighScoresActivity highScoresActivity, double d, int i) {
        this.c = highScoresActivity;
        this.a = d;
        this.b = i;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        int a = i.a().a(this.a, Integer.valueOf(this.b), 0);
        this.c.C = null;
        this.c.a.sendEmptyMessage(a);
    }
}
