package com.droidhen.game.racingengine.c;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class g {
    private long a;
    private com.droidhen.game.racingengine.g.c b;
    private com.droidhen.game.racingengine.g.c c;
    private com.droidhen.game.racingengine.g.c d;
    private com.droidhen.game.racingengine.g.e e;

    public g() {
        this.e = null;
        this.a = 0L;
        this.b = new com.droidhen.game.racingengine.g.c();
        this.c = new com.droidhen.game.racingengine.g.c();
        this.c = new com.droidhen.game.racingengine.g.c();
    }

    public g(long j, com.droidhen.game.racingengine.g.c cVar, com.droidhen.game.racingengine.g.c cVar2, com.droidhen.game.racingengine.g.c cVar3) {
        this();
        this.a = j;
        this.b = cVar;
        this.c = cVar2;
        this.d = cVar3;
    }

    public long a() {
        return this.a;
    }

    public com.droidhen.game.racingengine.g.c b() {
        return this.b;
    }

    public com.droidhen.game.racingengine.g.c c() {
        return this.c;
    }

    public com.droidhen.game.racingengine.g.c d() {
        return this.d;
    }
}
