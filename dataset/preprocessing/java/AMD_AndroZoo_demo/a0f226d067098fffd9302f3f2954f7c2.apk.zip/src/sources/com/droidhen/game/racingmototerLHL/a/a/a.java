package com.droidhen.game.racingmototerLHL.a.a;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a extends com.droidhen.game.racingengine.a.f {
    private com.droidhen.game.racingengine.a.a.e d;
    private com.droidhen.game.racingengine.a.a.e e;
    private com.droidhen.game.racingengine.a.a.e j;
    private float k;

    public a() {
        super(0.5f, 0.5f, 480.0f, 800.0f, -1);
        this.k = 0.0f;
        this.B = 0.6f;
        a(com.droidhen.game.racingengine.a.j.FitScreen);
        this.j = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("loading_bg"));
        this.j.a(0.0f, 0.0f, com.droidhen.game.racingengine.a.h.LEFTTOP);
        this.j.a(com.droidhen.game.racingengine.a.j.FitScreen);
        a(this.j);
        this.d = new com.droidhen.game.racingengine.a.a.e(com.droidhen.game.racingengine.a.e.a("loading"));
        this.d.a(260.0f, 600.0f, com.droidhen.game.racingengine.a.h.CENTER);
        this.e = new aj(this);
        this.e.a(156.0f, 600.0f, com.droidhen.game.racingengine.a.h.CENTER);
        a(this.d);
        a(this.e);
        a(com.droidhen.game.racingmototerLHL.global.f.a().b);
    }

    @Override // com.droidhen.game.racingengine.a.f, com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        super.c();
        this.k += 5.0f;
    }
}
