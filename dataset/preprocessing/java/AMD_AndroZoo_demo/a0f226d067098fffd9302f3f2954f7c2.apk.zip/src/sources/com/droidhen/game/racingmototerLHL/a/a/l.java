package com.droidhen.game.racingmototerLHL.a.a;

import javax.microedition.khronos.opengles.GL10;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class l extends com.droidhen.game.racingengine.a.a {
    protected long d;
    final /* synthetic */ k e;

    public l(k kVar, float f, float f2) {
        this.e = kVar;
        this.E = f;
        this.F = f2;
        this.G.a = 0.0f;
        this.G.b = 0.0f;
        this.H = com.droidhen.game.racingengine.a.h.CENTER;
        this.C = com.droidhen.game.racingengine.a.e.a("warning_64_32");
        a(f, f2, 32.0f);
        b();
    }

    private void a(float f, float f2, float f3) {
        float[] fArr = {(-f) / 2.0f, (-f2) / 2.0f, 0.0f, f / 2.0f, (-f2) / 2.0f, 0.0f, -((f / 2.0f) - f3), -((f2 / 2.0f) - f3), 0.0f, f / 2.0f, (-f2) / 2.0f, 0.0f, (f / 2.0f) - f3, -((f2 / 2.0f) - f3), 0.0f, -((f / 2.0f) - f3), -((f2 / 2.0f) - f3), 0.0f, (-f) / 2.0f, f2 / 2.0f, 0.0f, -((f / 2.0f) - f3), (f2 / 2.0f) - f3, 0.0f, (f / 2.0f) - f3, (f2 / 2.0f) - f3, 0.0f, (f / 2.0f) - f3, (f2 / 2.0f) - f3, 0.0f, f / 2.0f, f2 / 2.0f, 0.0f, -(f / 2.0f), f2 / 2.0f, 0.0f, (f / 2.0f) - f3, -((f2 / 2.0f) - f3), 0.0f, f / 2.0f, -(f2 / 2.0f), 0.0f, (f / 2.0f) - f3, (f2 / 2.0f) - f3, 0.0f, f / 2.0f, -(f2 / 2.0f), 0.0f, f / 2.0f, f2 / 2.0f, 0.0f, (f / 2.0f) - f3, (f2 / 2.0f) - f3, 0.0f, -(f / 2.0f), -(f2 / 2.0f), 0.0f, -((f / 2.0f) - f3), -((f2 / 2.0f) - f3), 0.0f, -(f / 2.0f), f2 / 2.0f, 0.0f, -((f / 2.0f) - f3), -((f2 / 2.0f) - f3), 0.0f, -((f / 2.0f) - f3), (f2 / 2.0f) - f3, 0.0f, -(f / 2.0f), f2 / 2.0f, 0.0f};
        float[] fArr2 = {0.0f, 0.0f, 7.5f, 0.0f, 0.5f, 1.0f, 7.5f, 0.0f, 7.0f, 1.0f, 0.5f, 1.0f, 0.0f, 0.0f, 0.5f, 1.0f, 7.0f, 1.0f, 7.0f, 1.0f, 7.5f, 0.0f, 0.0f, 0.0f, 0.5f, 1.0f, 1.0f, 0.0f, -11.0f, 1.0f, 1.0f, 0.0f, -11.5f, 0.0f, -11.0f, 1.0f, 0.5f, 0.0f, 1.0f, 1.0f, -11.0f, 0.0f, 1.0f, 1.0f, -11.5f, 1.0f, -11.0f, 0.0f};
        short[] sArr = new short[24];
        for (int i = 0; i < sArr.length; i++) {
            sArr[i] = (short) i;
        }
        this.D = sArr.length;
        this.M = com.droidhen.game.racingengine.f.a.a(fArr2);
        this.N = com.droidhen.game.racingengine.f.a.a(fArr);
        this.O = com.droidhen.game.racingengine.f.a.a(sArr);
        this.M.position(0);
        this.N.position(0);
        this.O.position(0);
    }

    @Override // com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        super.a();
        a(this.E, this.F, (this.E / 480.0f) * 32.0f);
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        boolean z;
        com.droidhen.game.racingengine.g.e eVar;
        if (this.z) {
            c();
            if (this.B != 1.0f) {
                z = true;
                gl10.glColor4f(1.0f, 1.0f, 1.0f, this.B);
            } else {
                z = false;
            }
            gl10.glBindTexture(3553, this.C.a);
            gl10.glPushMatrix();
            eVar = this.e.f;
            gl10.glMultMatrixf(eVar.b, 0);
            gl10.glTexCoordPointer(2, 5126, 0, this.M);
            gl10.glVertexPointer(3, 5126, 0, this.N);
            gl10.glDrawElements(4, this.D, 5123, this.O);
            if (z) {
                gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            }
            gl10.glPopMatrix();
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        super.c();
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.PAUSE) {
            e();
            return;
        }
        if (com.droidhen.game.racingmototerLHL.global.f.b().u() == com.droidhen.game.racingmototerLHL.global.e.CRASH) {
            e();
        } else if (System.currentTimeMillis() - this.d > 300) {
            e();
        } else {
            this.B = com.droidhen.game.racingengine.g.f.a();
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        this.d = System.currentTimeMillis();
        this.z = true;
        super.d();
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void e() {
        this.z = false;
    }
}
