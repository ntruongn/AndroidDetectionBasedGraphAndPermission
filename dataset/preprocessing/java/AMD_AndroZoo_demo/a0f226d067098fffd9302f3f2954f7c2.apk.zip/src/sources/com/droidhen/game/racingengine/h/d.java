package com.droidhen.game.racingengine.h;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.SoundPool;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class d implements b {
    private static d b;
    protected SoundPool a = new SoundPool(5, 3, 0);
    private MediaPlayer[] c;

    public d(Context context, e[] eVarArr) {
        int i = 0;
        for (e eVar : eVarArr) {
            if (!eVar.b()) {
                i++;
            }
        }
        this.c = new MediaPlayer[i];
        int i2 = 0;
        for (e eVar2 : eVarArr) {
            if (eVar2.b()) {
                eVar2.a(this.a.load(context, eVar2.a(), 1));
            } else {
                MediaPlayer create = MediaPlayer.create(context.getApplicationContext(), eVar2.a());
                if (create != null) {
                    create.setLooping(true);
                    create.setVolume(eVar2.c(), eVar2.c());
                    create.setAudioStreamType(3);
                }
                this.c[i2] = create;
                eVar2.a(i2);
                i2++;
            }
        }
    }

    public static d a(Context context, e[] eVarArr) {
        if (b == null) {
            synchronized (d.class) {
                if (b == null) {
                    b = new d(context, eVarArr);
                }
            }
        }
        return b;
    }

    private void a(MediaPlayer mediaPlayer) {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    return;
                }
                mediaPlayer.start();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
        }
    }

    private void b(MediaPlayer mediaPlayer) {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                }
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
        }
    }

    @Override // com.droidhen.game.racingengine.h.b
    public void a() {
        for (int length = this.c.length - 1; length >= 0; length--) {
            b(this.c[length]);
        }
    }

    @Override // com.droidhen.game.racingengine.h.b
    public void a(e eVar) {
        if (eVar.b()) {
            this.a.play(eVar.d(), eVar.c(), eVar.c(), 1, 0, 1.0f);
        } else {
            a(this.c[eVar.d()]);
        }
    }
}
