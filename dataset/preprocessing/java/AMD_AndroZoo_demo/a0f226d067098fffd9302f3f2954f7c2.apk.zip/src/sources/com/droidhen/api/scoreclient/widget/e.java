package com.droidhen.api.scoreclient.widget;

import android.app.Dialog;
import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e extends Dialog {
    private a a;

    public e(Context context) {
        super(context, 2131165184);
        a();
    }

    public e(Context context, a aVar) {
        this(context);
        this.a = aVar;
    }

    private void a() {
        setContentView(2130903041);
    }

    public void a(View.OnClickListener onClickListener) {
        ((ImageButton) findViewById(2131230735)).setOnClickListener(onClickListener);
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        switch (i) {
            case 4:
                if (this.a != null) {
                    this.a.a();
                    break;
                }
                break;
        }
        return super.onKeyUp(i, keyEvent);
    }
}
