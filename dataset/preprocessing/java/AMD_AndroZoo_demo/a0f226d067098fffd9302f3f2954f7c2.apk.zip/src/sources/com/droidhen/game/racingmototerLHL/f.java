package com.droidhen.game.racingmototerLHL;

import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.os.Handler;
import com.droidhen.game.racingmototerLHL.a.a.ae;
import com.droidhen.game.racingmototerLHL.a.a.af;
import com.droidhen.game.racingmototerLHL.b.h;
import com.droidhen.game.racingmototerLHL.b.l;
import com.droidhen.game.racingmototerLHL.b.n;
import java.io.IOException;
import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f extends com.droidhen.game.racingengine.b {
    public static float b;
    public static int e = 0;
    public static com.droidhen.game.racingmototerLHL.global.a f = new com.droidhen.game.racingmototerLHL.global.a();
    public static int i = 0;
    static final float[][] m = {new float[]{43.0f, 6.0f}, new float[]{41.0f, 0.0f}, new float[]{49.0f, 0.0f}};
    private com.droidhen.game.racingengine.j.a.b A;
    private SensorManager B;
    private SensorListener C;
    public boolean o;
    private GameActivity u;
    private com.droidhen.game.racingengine.b.a.a v;
    private com.droidhen.game.racingmototerLHL.b.g z;
    public boolean c = true;
    private com.droidhen.game.racingmototerLHL.global.e w = com.droidhen.game.racingmototerLHL.global.e.STOP;
    public h d = null;
    private com.droidhen.game.racingmototerLHL.b.b x = null;
    private com.droidhen.game.racingmototerLHL.b.e y = null;
    boolean g = true;
    boolean h = true;
    com.droidhen.game.racingengine.c.f j = null;
    com.droidhen.game.racingengine.b.a k = null;
    n l = null;
    g n = null;
    public com.droidhen.game.racingengine.b.c.b p = null;
    public com.droidhen.game.racingengine.b.c.b q = null;
    public com.droidhen.game.racingengine.b.c.b r = null;
    public com.droidhen.game.racingengine.b.c.b s = null;
    public com.droidhen.game.racingengine.b.c.b t = null;

    public f(GameActivity gameActivity, Handler handler) {
        this.z = null;
        this.A = null;
        this.o = true;
        this.u = gameActivity;
        this.a = handler;
        this.v = new com.droidhen.game.racingengine.b.a.a();
        this.A = new com.droidhen.game.racingengine.j.a.b();
        this.A.a = -198.0f;
        this.A.b = 198.0f;
        this.z = new com.droidhen.game.racingmototerLHL.b.g(this.A);
        if (d.b(gameActivity)) {
            this.o = false;
        }
    }

    private void D() {
        if (this.c) {
            this.w = com.droidhen.game.racingmototerLHL.global.e.LOADING_MODEL;
            com.droidhen.game.racingmototerLHL.global.f.a().a("loading_panel");
            l();
            this.w = com.droidhen.game.racingmototerLHL.global.e.PLAYING;
            this.c = false;
        }
    }

    private g E() {
        if (this.n != null && this.n.b == i) {
            return this.n;
        }
        com.droidhen.game.racingengine.g.c d = com.droidhen.game.racingengine.g.c.d();
        com.droidhen.game.racingengine.g.c d2 = com.droidhen.game.racingengine.g.c.d();
        com.droidhen.game.racingengine.g.c d3 = com.droidhen.game.racingengine.g.c.d();
        d3.a(1.0f, 1.0f, 1.0f);
        d.a();
        d2.a();
        d.a = 90.0f;
        d2.b = m[i][0];
        d2.c = m[i][1];
        if (this.n == null) {
            this.n = new g(this);
        }
        this.n.a.a();
        this.n.a.a(d3, d, d2);
        this.n.b = i;
        com.droidhen.game.racingengine.g.c.f(d3);
        com.droidhen.game.racingengine.g.c.f(d);
        com.droidhen.game.racingengine.g.c.f(d2);
        return this.n;
    }

    private synchronized void F() {
        super.e();
        super.c();
        if (this.o) {
            ae.f();
        }
        com.droidhen.game.racingmototerLHL.global.f.c = 0.0f;
        com.droidhen.game.racingmototerLHL.global.f.b = 0.0f;
        e = 0;
        a(true);
        this.d.e();
        this.y.d();
        this.z.a();
        super.d();
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.g);
        this.w = com.droidhen.game.racingmototerLHL.global.e.PLAYING;
        com.droidhen.game.racingmototerLHL.global.f.a().a("game_panel");
    }

    private void a(boolean z) {
        if (z) {
            this.x.a();
        } else {
            this.x.c();
            com.droidhen.game.racingmototerLHL.global.f.a().c();
        }
        if (this.o) {
            h.g = com.droidhen.game.racingmototerLHL.global.d.c.d;
            h.f = com.droidhen.game.racingmototerLHL.global.d.c.c;
            this.z.a(com.droidhen.game.racingmototerLHL.global.d.c);
            return;
        }
        if (e < com.droidhen.game.racingmototerLHL.global.d.d.length) {
            h.g = com.droidhen.game.racingmototerLHL.global.d.d[e].d;
            h.f = com.droidhen.game.racingmototerLHL.global.d.d[e].c;
            this.z.a(com.droidhen.game.racingmototerLHL.global.d.d[e]);
            f.a(com.droidhen.game.racingmototerLHL.global.d.d[e]);
            return;
        }
        if (e < 40) {
            int a = (int) (com.droidhen.game.racingengine.g.f.a() * 3.0f);
            int[] iArr = f.a;
            iArr[a] = iArr[a] + 1;
        }
        f.b = (float) (r0.b + 0.1d);
        f.d += 20.0f;
        f.c += 10.0f;
        h.g = f.d;
        h.f = f.c;
        this.z.a(f);
    }

    public void A() {
        this.a.sendMessage(this.a.obtainMessage(4));
    }

    public void B() {
        this.a.sendMessage(this.a.obtainMessage(5));
    }

    public void C() {
        this.p = new com.droidhen.game.racingengine.b.c.b("Textures/ModelTextures/Scenes", "ScenesTexGroup");
        this.p.a(true);
        this.q = new com.droidhen.game.racingengine.b.c.b("Textures/ModelTextures/Cars", "CarsTexGroup");
        this.q.a(true);
        this.r = new com.droidhen.game.racingengine.b.c.b("Textures/ModelTextures/Motos", "MotosTexGroup");
        this.r.a(true);
        this.s = new com.droidhen.game.racingengine.b.c.b("Textures/ModelTextures/Man", "ManTexGroup");
        this.s.a(true);
        this.t = new com.droidhen.game.racingengine.b.c.b("Textures/ModelTextures/SelectMoto", "SelectMotoTexGroup");
        this.t.a(true);
        this.p.c();
        this.q.c();
        this.r.c();
        this.s.c();
        this.t.c();
    }

    public void a(float f2) {
        b = f2;
    }

    public void a(int i2) {
        com.droidhen.game.racingmototerLHL.global.f.b += i2;
    }

    public void a(com.droidhen.game.racingengine.b.a aVar, int i2) {
        i = i2;
        this.k = aVar;
        D();
        this.d.a(aVar, i2);
        this.y.a.a(l.d[i].m);
    }

    public void a(com.droidhen.game.racingmototerLHL.global.e eVar) {
        this.w = eVar;
    }

    @Override // com.droidhen.game.racingengine.b, com.droidhen.game.racingengine.i.b
    public synchronized void b() {
        if (this.d.b() != com.droidhen.game.racingmototerLHL.b.a.Crash) {
            if (com.droidhen.game.racingmototerLHL.global.f.f) {
                if (this.d.b() != com.droidhen.game.racingmototerLHL.b.a.GearUp) {
                    this.d.c();
                }
            } else if (this.d.b() != com.droidhen.game.racingmototerLHL.b.a.GearNormal) {
                this.d.d();
            }
            this.d.a(b);
        }
        this.d.g();
        if (this.y.d) {
            if (this.y.a.g() != null) {
                this.d.a.b(this.y.a);
                this.y.a.o.a();
                this.y.a.k.a(this.d.a.o.b[12], this.d.a.o.b[13], this.d.a.o.b[14]);
                this.v.a(this.y.a);
            }
            this.y.a();
        } else {
            this.y.b.a(this.d.b);
            if (this.y.a.g() == null) {
                this.y.a.k.a();
                this.y.a.o.c(E().a);
                this.d.a.a(this.y.a, -2);
                this.v.b(this.y.a);
            }
        }
        if (com.droidhen.game.racingmototerLHL.global.f.c > 2000.0f * (e + 1.0f)) {
            e++;
            a(false);
        }
        this.x.b();
        this.z.c();
        this.A.a();
        for (int i2 = 0; i2 < this.v.b(); i2++) {
            this.v.a(i2).b();
        }
        this.A.b();
        if (this.w == com.droidhen.game.racingmototerLHL.global.e.PLAYING) {
            com.droidhen.game.racingmototerLHL.global.f.c += this.d.b.b() * com.droidhen.game.racingengine.a.b.g().b();
            com.droidhen.game.racingmototerLHL.global.f.b += this.d.b.b() * com.droidhen.game.racingengine.a.b.g().b() * (af.e + 1);
        }
        com.droidhen.game.racingmototerLHL.global.f.a = (int) this.d.b.b();
    }

    @Override // com.droidhen.game.racingengine.b
    public void b(GL10 gl10) {
        if (this.w != com.droidhen.game.racingmototerLHL.global.e.GAME_MENU) {
            this.v.a(gl10);
            gl10.glPushMatrix();
            if (this.w != com.droidhen.game.racingmototerLHL.global.e.SELECT_MOTO) {
                gl10.glTranslatef(0.0f, 0.0f, -com.droidhen.game.racingmototerLHL.global.f.d);
            }
            this.v.b(gl10);
            gl10.glPopMatrix();
        }
        com.droidhen.game.racingmototerLHL.global.f.a().a(gl10);
    }

    @Override // com.droidhen.game.racingengine.b, com.droidhen.game.racingengine.i.b
    public void c() {
        GameActivity.b();
        super.c();
        this.w = com.droidhen.game.racingmototerLHL.global.e.PAUSE;
    }

    @Override // com.droidhen.game.racingengine.b, com.droidhen.game.racingengine.i.b
    public void d() {
        super.d();
        GameActivity.a(com.droidhen.game.racingmototerLHL.global.b.g);
        this.w = com.droidhen.game.racingmototerLHL.global.e.PLAYING;
    }

    @Override // com.droidhen.game.racingengine.b
    public void h() {
        com.droidhen.game.racingengine.b.b.a.a(com.droidhen.game.racingengine.a.f);
        com.droidhen.game.racingmototerLHL.global.f.b().p.a();
        com.droidhen.game.racingmototerLHL.global.f.b().r.a();
        com.droidhen.game.racingmototerLHL.global.f.b().s.a();
        com.droidhen.game.racingmototerLHL.global.f.b().q.a();
        if (this.g) {
            com.droidhen.game.racingmototerLHL.global.f.a().b();
            this.g = false;
        }
        if (this.h) {
            com.droidhen.game.racingmototerLHL.global.f.a().a("game_menu");
            com.droidhen.game.racingmototerLHL.global.f.b().a(com.droidhen.game.racingmototerLHL.global.e.GAME_MENU);
            this.h = false;
        }
    }

    @Override // com.droidhen.game.racingengine.b
    public void i() {
        if (com.droidhen.game.racingengine.a.c.b() > com.droidhen.game.racingengine.a.c.a()) {
            com.droidhen.game.racingmototerLHL.global.f.a().g();
        }
    }

    public com.droidhen.game.racingmototerLHL.b.g j() {
        return this.z;
    }

    public com.droidhen.game.racingengine.j.a.b k() {
        return this.A;
    }

    public void l() {
        com.droidhen.game.racingengine.e.a.a aVar;
        com.droidhen.game.racingengine.e.a.a aVar2;
        com.droidhen.game.racingengine.e.a.a aVar3 = null;
        if (this.k == null) {
            try {
                aVar3 = new com.droidhen.game.racingengine.e.a.a(com.droidhen.game.racingengine.a.d.open(l.d[i].a));
            } catch (IOException e2) {
                e2.printStackTrace();
            }
            this.k = aVar3.b(l.d[i].d);
        }
        this.k.c = true;
        this.k.a(l.d[i].e).p = true;
        this.d = new h(this.k, i);
        try {
            aVar = new com.droidhen.game.racingengine.e.a.a(com.droidhen.game.racingengine.a.d.open("Models/Man/group_Man.data"));
        } catch (IOException e3) {
            e3.printStackTrace();
            aVar = aVar3;
        }
        this.j = aVar.c("man");
        this.j.p = true;
        this.j.a(l.d[i].m);
        this.j.d().l();
        this.j.a().a(new com.droidhen.game.racingengine.c.b(((com.droidhen.game.racingengine.c.d) this.j.a().a.get(0)).a(8).a(), ((com.droidhen.game.racingengine.c.d) this.j.a().a.get(0)).a(19).a()));
        this.j.a().a(0);
        this.j.a().a(false);
        this.y = new com.droidhen.game.racingmototerLHL.b.e(this.j);
        this.A.c = new e(this, 129.0f, 129.0f, 45.0f, 120.0f);
        try {
            aVar2 = new com.droidhen.game.racingengine.e.a.a(com.droidhen.game.racingengine.a.d.open("Models/changjing.data"));
        } catch (IOException e4) {
            e4.printStackTrace();
            aVar2 = aVar;
        }
        this.x = new com.droidhen.game.racingmototerLHL.b.b();
        com.droidhen.game.racingengine.b.a b2 = aVar2.b("shatan");
        com.droidhen.game.racingengine.b.g a = b2.a("shatan_yingzi");
        b2.d.remove(a);
        b2.d.add(2, a);
        b2.a("gelidai_an").r = false;
        b2.a("gelidai_liang").r = false;
        this.x.a(b2);
        com.droidhen.game.racingengine.b.a b3 = aVar2.b("Group_chengshi");
        b3.a("gelidai_an").r = false;
        b3.a("gelidai_liang").r = false;
        this.x.a(b3);
        this.x.a(aVar2.b("diaoqiao"));
        this.x.a(aVar2.b("Group_fengshu"));
        this.x.a(aVar2.b("suidao"));
        this.x.a(aVar2.b("suidao_rukou"));
        com.droidhen.game.racingengine.b.a b4 = aVar2.b("suidao_chukou");
        com.droidhen.game.racingengine.b.g a2 = b4.a("suidao_chukou");
        b4.d.remove(a2);
        b4.d.add(a2);
        this.x.a(b4);
        this.x.a(aVar2.a("lupai"));
        this.x.b(aVar2.a("suidao_rukou_xia"));
        this.x.b(aVar2.b("Group_dengxiang"));
        this.l = new n();
        try {
            aVar2 = new com.droidhen.game.racingengine.e.a.a(com.droidhen.game.racingengine.a.d.open("Models/Cars/car.data"));
        } catch (IOException e5) {
            e5.printStackTrace();
        }
        this.z.a(aVar2, this.l);
    }

    public void m() {
        this.v.c();
        this.v.a(this.x);
        this.v.a(this.l);
        this.v.a(this.k);
        this.k.o.a();
        this.k.m.c = 0.0f;
    }

    public com.droidhen.game.racingengine.b.a.a n() {
        return this.v;
    }

    public h o() {
        return this.d;
    }

    public void p() {
        this.w = com.droidhen.game.racingmototerLHL.global.e.CRASH;
    }

    public void q() {
        com.droidhen.game.racingmototerLHL.global.f.a().a("game_over");
        GameActivity.b();
        super.c();
        this.w = com.droidhen.game.racingmototerLHL.global.e.GAME_OVER;
    }

    public void r() {
        com.droidhen.game.racingmototerLHL.global.f.a().a("game_menu");
        s();
        super.c();
        this.w = com.droidhen.game.racingmototerLHL.global.e.GAME_MENU;
    }

    public void s() {
        if (this.d == null || this.y == null || this.y.a.g() == null) {
            return;
        }
        this.d.a.b(this.y.a);
        this.y.a.o.a();
    }

    public void t() {
        D();
        if (this.y.a.g() != null) {
            this.d.a.b(this.y.a);
            this.y.a.o.a();
        }
        this.y.a.a(l.d[i].m);
        m();
        F();
    }

    public com.droidhen.game.racingmototerLHL.global.e u() {
        return this.w;
    }

    public void v() {
        this.B = (SensorManager) this.u.getSystemService("sensor");
        this.C = new com.droidhen.game.racingmototerLHL.global.c(this);
        this.B.registerListener(this.C, 2, 1);
    }

    public void w() {
        this.B.unregisterListener(this.C);
    }

    public void x() {
        this.a.sendMessage(this.a.obtainMessage(1));
    }

    public void y() {
        this.a.sendMessage(this.a.obtainMessage(2));
    }

    public void z() {
        this.a.sendMessage(this.a.obtainMessage(3));
    }
}
