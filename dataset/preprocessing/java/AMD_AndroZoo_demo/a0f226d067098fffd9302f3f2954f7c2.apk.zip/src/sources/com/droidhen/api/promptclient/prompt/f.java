package com.droidhen.api.promptclient.prompt;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f {
    private static SharedPreferences a;

    public static void a(Context context) {
        c(context);
        SharedPreferences.Editor edit = a.edit();
        edit.remove("r_extra");
        edit.remove("r_extra2");
        edit.commit();
    }

    public static synchronized void a(Context context, a aVar) {
        synchronized (f.class) {
            c(context);
            SharedPreferences.Editor edit = a.edit();
            edit.putInt("r_id", aVar.a);
            edit.putLong("r_last_fetch_time", aVar.e);
            edit.putInt("r_show_count", aVar.f);
            for (int i = 0; i < 3; i++) {
                i iVar = aVar.b[i];
                edit.putString("r_icon_url" + i, iVar.a);
                edit.putString("r_LINK" + i, iVar.c);
                edit.putString("r_title" + i, iVar.b);
            }
            if (com.droidhen.api.promptclient.a.c.b(aVar.c)) {
                edit.putString("r_extra", aVar.c);
            }
            if (com.droidhen.api.promptclient.a.c.b(aVar.d)) {
                edit.putString("r_extra2", aVar.d);
            }
            edit.commit();
        }
    }

    public static synchronized a b(Context context) {
        a aVar;
        synchronized (f.class) {
            c(context);
            aVar = new a();
            aVar.a = a.getInt("r_id", 0);
            aVar.f = a.getInt("r_show_count", 0);
            aVar.e = a.getLong("r_last_fetch_time", 0L);
            if (aVar.e == 0) {
                SharedPreferences.Editor edit = a.edit();
                edit.putLong("r_last_fetch_time", (System.currentTimeMillis() - 43200000) + 7200000);
                edit.commit();
                aVar.e = System.currentTimeMillis();
            }
            i[] iVarArr = new i[3];
            for (int i = 0; i < 3; i++) {
                iVarArr[i] = new i(a.getString("r_icon_url" + i, ""), a.getString("r_title" + i, ""), a.getString("r_LINK" + i, ""));
            }
            aVar.b = iVarArr;
            aVar.c = a.getString("r_extra", null);
            aVar.d = a.getString("r_extra2", null);
        }
        return aVar;
    }

    private static void c(Context context) {
        if (a == null) {
            a = PreferenceManager.getDefaultSharedPreferences(context);
        }
    }
}
