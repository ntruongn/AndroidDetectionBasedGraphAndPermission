package com.droidhen.api.promptclient.prompt;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class b extends Thread {
    final /* synthetic */ RecommendActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(RecommendActivity recommendActivity) {
        this.a = recommendActivity;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        for (int i = 0; i < k.a.length; i++) {
            try {
                this.a.a(this.a.a.b[i].a, k.a[i]);
            } finally {
                this.a.c.sendEmptyMessageDelayed(9527, 1000L);
            }
        }
    }
}
