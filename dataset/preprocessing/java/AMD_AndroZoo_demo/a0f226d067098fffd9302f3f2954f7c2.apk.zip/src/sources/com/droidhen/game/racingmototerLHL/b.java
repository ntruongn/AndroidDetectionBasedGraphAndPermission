package com.droidhen.game.racingmototerLHL;

import android.os.Handler;
import android.os.Message;
import com.droidhen.api.scoreclient.widget.UsernameEdit;
import com.google.ads.AdView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class b extends Handler {
    final /* synthetic */ GameActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(GameActivity gameActivity) {
        this.a = gameActivity;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        AdView adView;
        AdView adView2;
        UsernameEdit usernameEdit;
        UsernameEdit usernameEdit2;
        switch (message.what) {
            case 1:
                usernameEdit2 = this.a.h;
                usernameEdit2.setVisibility(0);
                GameActivity.e = true;
                return;
            case 2:
                usernameEdit = this.a.h;
                usernameEdit.setVisibility(4);
                GameActivity.e = false;
                return;
            case 3:
                this.a.e();
                return;
            case 4:
                adView2 = this.a.i;
                adView2.setVisibility(0);
                return;
            case 5:
                adView = this.a.i;
                adView.setVisibility(4);
                return;
            default:
                return;
        }
    }
}
