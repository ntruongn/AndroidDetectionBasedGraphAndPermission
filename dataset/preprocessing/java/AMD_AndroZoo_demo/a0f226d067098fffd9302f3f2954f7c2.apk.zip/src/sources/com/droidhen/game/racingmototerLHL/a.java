package com.droidhen.game.racingmototerLHL;

import android.app.Activity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.google.ads.AdView;
import java.util.HashSet;
import java.util.Set;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class a implements com.droidhen.api.promptclient.more.b, com.droidhen.api.scoreclient.c {
    public static final Set a = new HashSet();
    public static final a b;

    static {
        a.add("traffic");
        a.add("moto");
        a.add("racing");
        b = new a();
    }

    private static void a(AdView adView) {
        adView.setVisibility(0);
        com.google.ads.c cVar = new com.google.ads.c();
        cVar.a(false);
        cVar.a(a);
        adView.a(cVar);
    }

    private void c(Activity activity, LinearLayout linearLayout) {
        AdView adView = new AdView(activity, com.google.ads.f.a, "a14e20172da37d6");
        ViewGroup.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        linearLayout.setGravity(1);
        linearLayout.addView(adView, layoutParams);
        a(adView);
    }

    @Override // com.droidhen.api.promptclient.more.b
    public void a(Activity activity, LinearLayout linearLayout) {
        c(activity, linearLayout);
    }

    @Override // com.droidhen.api.scoreclient.c
    public void b(Activity activity, LinearLayout linearLayout) {
        c(activity, linearLayout);
    }
}
