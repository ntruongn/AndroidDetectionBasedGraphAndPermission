package com.droidhen.game.racingengine.e.a;

import com.droidhen.game.racingengine.c.g;
import com.droidhen.game.racingengine.c.h;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f {
    public static ByteOrder e = ByteOrder.LITTLE_ENDIAN;
    public ArrayList a = new ArrayList();
    public ArrayList b = new ArrayList();
    public ArrayList c = new ArrayList();
    public ArrayList d = new ArrayList();

    private static com.droidhen.game.racingengine.c.a a(com.droidhen.game.racingengine.c.e eVar, InputStream inputStream) {
        com.droidhen.game.racingengine.c.a aVar = new com.droidhen.game.racingengine.c.a();
        aVar.a(b(eVar, inputStream));
        return aVar;
    }

    private static d a(ArrayList arrayList, InputStream inputStream) {
        d dVar = new d(c.g(inputStream));
        com.droidhen.game.racingengine.g.c d = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d2 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d3 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d4 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d5 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d6 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d7 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d8 = c.d(inputStream);
        dVar.c = d;
        dVar.d = d2;
        dVar.e = d3;
        dVar.f = d4;
        dVar.g = d5;
        dVar.h.a(d8, d7, d6);
        int a = c.a(inputStream);
        while (a != -1) {
            if (a == e.MESH.a()) {
                com.droidhen.game.racingengine.b.f b = b(inputStream);
                arrayList.add(b);
                dVar.a.add(b);
            }
            a = c.a(inputStream);
        }
        return dVar;
    }

    private void a() {
        Iterator it = this.a.iterator();
        while (it.hasNext()) {
            com.droidhen.game.racingengine.b.f fVar = (com.droidhen.game.racingengine.b.f) it.next();
            Iterator it2 = this.b.iterator();
            while (it2.hasNext()) {
                com.droidhen.game.racingengine.c.a aVar = (com.droidhen.game.racingengine.c.a) it2.next();
                if (fVar.l.size() > 0 && aVar.a(((b) fVar.l.get(0)).a) != null) {
                    Iterator it3 = fVar.l.iterator();
                    while (it3.hasNext()) {
                        b bVar = (b) it3.next();
                        h a = aVar.a(bVar.a);
                        a.g = bVar.c;
                        a.h = bVar.d;
                        a.b(bVar.b);
                        a.q = bVar.e;
                        a.r = bVar.f;
                    }
                }
            }
        }
    }

    private static com.droidhen.game.racingengine.b.f b(InputStream inputStream) {
        long f = c.f(inputStream);
        String g = c.g(inputStream);
        com.droidhen.game.racingengine.g.c d = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d2 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d3 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d4 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d5 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d6 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d7 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d8 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c[] b = c.b(inputStream, c.a(inputStream));
        int[] c = c.c(inputStream, c.a(inputStream));
        int a = c.a(inputStream);
        byte[] bArr = new byte[a * 2];
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(a * 2);
        allocateDirect.order(ByteOrder.nativeOrder());
        inputStream.read(bArr, 0, a * 2);
        allocateDirect.put(bArr);
        ShortBuffer asShortBuffer = ((ByteBuffer) allocateDirect.rewind()).asShortBuffer();
        asShortBuffer.position(0);
        FloatBuffer a2 = c.a(inputStream, c.a(inputStream));
        c.c(inputStream);
        ArrayList c2 = c.c(inputStream);
        c.a(inputStream, c.a(inputStream));
        com.droidhen.game.racingengine.b.f fVar = new com.droidhen.game.racingengine.b.f(new com.droidhen.game.racingengine.b.e(new com.droidhen.game.racingengine.b.b(a2, a), new com.droidhen.game.racingengine.b.h((FloatBuffer) c2.get(0), a), null, null), e(inputStream), new com.droidhen.game.racingengine.b.d(asShortBuffer, a / 3));
        fVar.a = f;
        fVar.b = g;
        fVar.n = c;
        fVar.m = b;
        fVar.p.a(d);
        fVar.q.a(d2);
        fVar.r.a(d3);
        fVar.s.a(d4);
        fVar.t.a(d5);
        fVar.u.a(d8, d7, d6);
        int a3 = c.a(inputStream);
        for (int i = 0; i < a3; i++) {
            fVar.l.add(c(inputStream));
        }
        return fVar;
    }

    private static h b(com.droidhen.game.racingengine.c.e eVar, InputStream inputStream) {
        h hVar = new h();
        hVar.a(c.f(inputStream));
        hVar.a(c.g(inputStream));
        hVar.a(c.b(inputStream));
        com.droidhen.game.racingengine.g.c d = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d2 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d3 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d4 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d5 = c.d(inputStream);
        hVar.a(d);
        hVar.b(d2);
        hVar.c(d3);
        hVar.d(d4);
        hVar.e(d5);
        if (com.droidhen.game.racingengine.a.g) {
            com.droidhen.game.racingengine.g.c d6 = c.d(inputStream);
            com.droidhen.game.racingengine.g.c d7 = c.d(inputStream);
            com.droidhen.game.racingengine.g.c d8 = c.d(inputStream);
            com.droidhen.game.racingengine.g.e eVar2 = new com.droidhen.game.racingengine.g.e();
            eVar2.a(d8, d7, d6);
            hVar.s = eVar2;
        }
        int b = c.b(inputStream);
        if (b > 0) {
            com.droidhen.game.racingengine.c.d dVar = new com.droidhen.game.racingengine.c.d();
            for (int i = 0; i < b; i++) {
                dVar.a(d(inputStream));
            }
            dVar.b();
            dVar.a(hVar);
            eVar.a(dVar);
        }
        int b2 = c.b(inputStream);
        if (b2 > 0) {
            for (int i2 = 0; i2 < b2; i2++) {
                h b3 = b(eVar, inputStream);
                hVar.a(b3);
                b3.b(hVar);
            }
        }
        return hVar;
    }

    private static b c(InputStream inputStream) {
        b bVar = new b();
        bVar.a = c.f(inputStream);
        bVar.b = c.b(inputStream);
        int b = c.b(inputStream);
        bVar.c = c.c(inputStream, b);
        bVar.d = c.d(inputStream, b);
        com.droidhen.game.racingengine.g.c d = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d2 = c.d(inputStream);
        bVar.e.a(c.d(inputStream), d2, d);
        com.droidhen.game.racingengine.g.c d3 = c.d(inputStream);
        com.droidhen.game.racingengine.g.c d4 = c.d(inputStream);
        bVar.f.a(c.d(inputStream), d4, d3);
        return bVar;
    }

    private static g d(InputStream inputStream) {
        return new g(c.f(inputStream), c.d(inputStream), c.d(inputStream), c.d(inputStream));
    }

    private static com.droidhen.game.racingengine.b.c.a e(InputStream inputStream) {
        com.droidhen.game.racingengine.b.c.a aVar = new com.droidhen.game.racingengine.b.c.a();
        long f = c.f(inputStream);
        while (f != -1) {
            String g = c.g(inputStream);
            float e2 = c.e(inputStream);
            float e3 = c.e(inputStream);
            float e4 = c.e(inputStream);
            float e5 = c.e(inputStream);
            com.droidhen.game.racingengine.d.c cVar = new com.droidhen.game.racingengine.d.c(g);
            cVar.e = e2;
            cVar.f = e3;
            cVar.g = e4;
            cVar.h = e5;
            aVar.a(cVar);
            f = c.f(inputStream);
        }
        return aVar;
    }

    public void a(InputStream inputStream) {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
        if (bufferedInputStream.read() == 1) {
            e = ByteOrder.BIG_ENDIAN;
        }
        c.a(bufferedInputStream);
        c.a(bufferedInputStream);
        if (c.a(bufferedInputStream) == 1) {
            com.droidhen.game.racingengine.a.g = true;
        }
        for (int a = c.a(bufferedInputStream); a != -1; a = c.a(bufferedInputStream)) {
            if (a == e.MESH.a()) {
                this.a.add(b(bufferedInputStream));
            } else if (a == e.SKELETON.a()) {
                com.droidhen.game.racingengine.c.e eVar = new com.droidhen.game.racingengine.c.e();
                this.b.add(a(eVar, bufferedInputStream));
                this.c.add(eVar);
            } else if (a == e.NULL.a()) {
                this.d.add(a(this.a, bufferedInputStream));
            }
        }
        a();
    }
}
