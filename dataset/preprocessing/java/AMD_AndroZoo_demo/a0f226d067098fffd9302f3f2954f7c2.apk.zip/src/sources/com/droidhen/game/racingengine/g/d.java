package com.droidhen.game.racingengine.g;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class d {
    public float a;
    public float b;

    public d() {
        this.a = 0.0f;
        this.b = 0.0f;
    }

    public d(float f, float f2) {
        this.a = 0.0f;
        this.b = 0.0f;
        this.a = f;
        this.b = f2;
    }

    public boolean equals(Object obj) {
        d dVar = (d) obj;
        return this.a == dVar.a && this.b == dVar.b;
    }

    public String toString() {
        return "V( " + this.a + ", " + this.b + " )";
    }
}
