package com.droidhen.game.racingengine.f;

import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.AbstractList;
import java.util.RandomAccess;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class d extends AbstractList implements Externalizable, RandomAccess {
    private float[][] a;
    private int b;

    public d() {
        this(16);
    }

    public d(int i) {
        this.a = new float[i];
    }

    private void a() {
        float[][] fArr = (float[][]) new Object[this.a.length << 1];
        System.arraycopy(this.a, 0, fArr, 0, this.a.length);
        this.a = fArr;
    }

    @Override // java.util.AbstractList, java.util.List
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void add(int i, float[] fArr) {
        if (this.b == this.a.length) {
            a();
        }
        int i2 = this.b - i;
        if (i2 > 0) {
            System.arraycopy(this.a, i, this.a, i + 1, i2);
        }
        this.a[i] = fArr;
        this.b++;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public boolean add(float[] fArr) {
        if (this.b == this.a.length) {
            a();
        }
        float[][] fArr2 = this.a;
        int i = this.b;
        this.b = i + 1;
        fArr2[i] = fArr;
        return true;
    }

    @Override // java.util.AbstractList, java.util.List
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public float[] remove(int i) {
        if (i < 0 || i >= this.b) {
            throw new IndexOutOfBoundsException();
        }
        float[] fArr = this.a[i];
        System.arraycopy(this.a, i + 1, this.a, i, (this.b - i) - 1);
        this.a[this.b - 1] = null;
        this.b--;
        return fArr;
    }

    @Override // java.util.AbstractList, java.util.List
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public float[] get(int i) {
        if (i >= this.b) {
            throw new IndexOutOfBoundsException();
        }
        return this.a[i];
    }

    @Override // java.util.AbstractList, java.util.List
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public float[] set(int i, float[] fArr) {
        if (i >= this.b) {
            throw new IndexOutOfBoundsException();
        }
        float[] fArr2 = this.a[i];
        this.a[i] = fArr;
        return fArr2;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public void clear() {
        this.b = 0;
    }

    @Override // java.util.AbstractList, java.util.List
    public int indexOf(Object obj) {
        int i = this.b;
        float[][] fArr = this.a;
        for (int i2 = 0; i2 < i; i2++) {
            if (obj == null) {
                if (fArr[i2] == null) {
                    return i2;
                }
            } else {
                if (obj.equals(fArr[i2])) {
                    return i2;
                }
            }
        }
        return -1;
    }

    @Override // java.io.Externalizable
    public void readExternal(ObjectInput objectInput) {
        this.b = objectInput.readInt();
        int i = 16;
        while (i < this.b) {
            i <<= 1;
        }
        this.a = (float[][]) new Object[i];
        int i2 = 0;
        while (true) {
            int i3 = i2;
            if (i3 >= this.b) {
                return;
            }
            this.a[i3] = (float[]) objectInput.readObject();
            i2 = i3 + 1;
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public int size() {
        return this.b;
    }

    @Override // java.io.Externalizable
    public void writeExternal(ObjectOutput objectOutput) {
        objectOutput.writeInt(this.b);
        for (int i = 0; i < this.b; i++) {
            objectOutput.writeObject(this.a[i]);
        }
    }
}
