package com.droidhen.api.scoreclient.ui;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.io.IOException;
import java.util.List;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class AchievementListActivity extends Activity {
    private ListView a;
    private com.droidhen.api.scoreclient.a.c b;
    private Integer c;
    private List d;

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2130903040);
        this.a = (ListView) findViewById(2131230734);
        h a = h.a(i.a());
        e c = a.c();
        TextView textView = (TextView) findViewById(2131230730);
        ImageView imageView = (ImageView) findViewById(2131230729);
        if (c != null) {
            try {
                textView.setText(c.a(), (TextView.BufferType) null);
                imageView.setImageBitmap(BitmapFactory.decodeStream(getAssets().open(c.b())));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                String packageName = getPackageName();
                PackageManager packageManager = getPackageManager();
                textView.setText(packageManager.getApplicationLabel(getApplicationInfo()));
                imageView.setImageDrawable(packageManager.getApplicationIcon(packageName));
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        this.b = a.d();
        this.d = this.b.a();
        this.a.setAdapter((ListAdapter) new o(this, this, 2130903040, this.d));
        StringBuilder sb = new StringBuilder();
        sb.append(this.b.b()).append("/").append(this.d.size());
        ((TextView) findViewById(2131230731)).setText(sb.toString());
        String c2 = this.b.c();
        if (c2 != null) {
            ((TextView) findViewById(2131230732)).setText(c2);
        }
        p f = a.f();
        if (f != null) {
            this.c = Integer.valueOf(f.b());
            ((LinearLayout) findViewById(2131230728)).setBackgroundColor(f.a());
            findViewById(2131230733).setBackgroundColor(this.c.intValue());
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        switch (i) {
            case 82:
            case 84:
                return true;
            case 83:
            default:
                return super.onKeyDown(i, keyEvent);
        }
    }
}
