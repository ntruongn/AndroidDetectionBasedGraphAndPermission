package com.droidhen.api.scoreclient.ui;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e {
    String a;
    String b;

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }
}
