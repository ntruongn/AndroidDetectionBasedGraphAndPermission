package com.droidhen.game.racingengine.b;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class e {
    private b a;
    private h b;
    private b c;
    private c d;
    private boolean e;
    private boolean f;
    private boolean g;

    public e(b bVar, h hVar, b bVar2, c cVar) {
        this.a = bVar;
        this.b = hVar;
        this.c = bVar2;
        this.d = cVar;
        this.e = this.b != null && this.b.a() > 0;
        this.f = this.c != null && this.c.a() > 0;
        this.g = this.d != null && this.d.a() > 0;
    }

    public int a() {
        return this.a.a();
    }

    public boolean b() {
        return this.e;
    }

    public boolean c() {
        return this.f;
    }

    public boolean d() {
        return this.g;
    }

    public b e() {
        return this.a;
    }

    public h f() {
        return this.b;
    }

    public b g() {
        return this.c;
    }

    public c h() {
        return this.d;
    }
}
