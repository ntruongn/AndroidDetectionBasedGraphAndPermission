package com.droidhen.game.racingengine.g;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class c implements Cloneable {
    public static c d = new c(1.0f, 0.0f, 0.0f);
    public static c e = new c(0.0f, 1.0f, 0.0f);
    public static c f = new c(0.0f, 0.0f, 1.0f);
    public static b g = new b();
    public float a;
    public float b;
    public float c;

    public c() {
        this.a = 0.0f;
        this.b = 0.0f;
        this.c = 0.0f;
    }

    public c(float f2, float f3, float f4) {
        this.a = 0.0f;
        this.b = 0.0f;
        this.c = 0.0f;
        this.a = f2;
        this.b = f3;
        this.c = f4;
    }

    public static c a(c cVar, c cVar2, c cVar3) {
        cVar3.a = cVar.a - cVar2.a;
        cVar3.b = cVar.b - cVar2.b;
        cVar3.c = cVar.c - cVar2.c;
        return cVar3;
    }

    public static c d() {
        return (c) g.b();
    }

    public static void f(c cVar) {
        g.a(cVar);
    }

    public c a(float f2) {
        this.a *= f2;
        this.b *= f2;
        this.c *= f2;
        return this;
    }

    public c a(float f2, c cVar) {
        cVar.a(this.a * f2, this.b * f2, this.c * f2);
        return cVar;
    }

    public c a(c cVar) {
        this.a = cVar.a;
        this.b = cVar.b;
        this.c = cVar.c;
        return this;
    }

    public c a(c cVar, c cVar2) {
        cVar2.a = this.a - cVar.a;
        cVar2.b = this.b - cVar.b;
        cVar2.c = this.c - cVar.c;
        return cVar2;
    }

    public void a() {
        this.a = 0.0f;
        this.b = 0.0f;
        this.c = 0.0f;
    }

    public void a(float f2, float f3, float f4) {
        this.a = f2;
        this.b = f3;
        this.c = f4;
    }

    public float b() {
        return (float) Math.sqrt((this.a * this.a) + (this.b * this.b) + (this.c * this.c));
    }

    public float b(c cVar) {
        return (this.a * cVar.a) + (this.b * cVar.b) + (this.c * cVar.c);
    }

    public c c() {
        float b = b();
        this.a /= b;
        this.b /= b;
        this.c /= b;
        return this;
    }

    public c c(c cVar) {
        float f2 = (this.b * cVar.c) - (this.c * cVar.b);
        float f3 = (this.c * cVar.a) - (this.a * cVar.c);
        this.c = (this.a * cVar.b) - (this.b * cVar.a);
        this.a = f2;
        this.b = f3;
        return this;
    }

    public c d(c cVar) {
        this.a += cVar.a;
        this.b += cVar.b;
        this.c += cVar.c;
        return this;
    }

    /* renamed from: e, reason: merged with bridge method [inline-methods] */
    public c clone() {
        try {
            return (c) super.clone();
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError();
        }
    }

    public c e(c cVar) {
        this.a -= cVar.a;
        this.b -= cVar.b;
        this.c -= cVar.c;
        return this;
    }

    public boolean equals(Object obj) {
        c cVar = (c) obj;
        return this.a == cVar.a && this.b == cVar.b && this.c == cVar.c;
    }

    public String toString() {
        return "V( " + this.a + ", " + this.b + ", " + this.c + " )";
    }
}
