package com.droidhen.game.racingengine.a;

import javax.microedition.khronos.opengles.GL10;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public class f extends a {
    private com.droidhen.game.racingengine.a.b.c d;
    private com.droidhen.game.racingengine.a.b.c e;
    protected com.droidhen.game.racingengine.g.e f = new com.droidhen.game.racingengine.g.e();
    private boolean j = false;
    private boolean k = true;
    public float g = 1.0f;
    protected com.droidhen.game.racingengine.b.c.b h = new com.droidhen.game.racingengine.b.c.b();
    public boolean i = false;

    public f(float f, float f2, float f3, float f4, int i) {
        this.E = f3;
        this.F = f4;
        this.G.a = (f - 0.5f) * com.droidhen.game.racingengine.a.c.a();
        this.G.b = ((-f2) + 0.5f) * com.droidhen.game.racingengine.a.c.b();
        this.f.b(this.G);
        this.H = h.CENTER;
        if (i == -1) {
            this.C = new com.droidhen.game.racingengine.b.c.d("");
        } else {
            this.C = new com.droidhen.game.racingengine.b.c.d("");
            this.C.a = i;
        }
        e(f3, f4);
        h();
        b();
    }

    @Override // com.droidhen.game.racingengine.a.a, com.droidhen.game.racingengine.a.l
    public void a() {
        super.a();
        e(this.E, this.F);
        if (this.P == null) {
            return;
        }
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.P.size()) {
                return;
            }
            ((l) this.P.get(i2)).a();
            i = i2 + 1;
        }
    }

    @Override // com.droidhen.game.racingengine.a.a
    public void a(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        super.a(f, f2, f3, f4, f5, f6, f7, f8);
        this.f.b(this.G);
    }

    public void a(com.droidhen.game.racingengine.b.c.e eVar) {
        if (eVar.i() != 0) {
            this.h = (com.droidhen.game.racingengine.b.c.b) eVar;
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void a(GL10 gl10) {
        boolean z;
        if (!this.z) {
            this.h.e();
            return;
        }
        this.h.d();
        if (this.B != 1.0f) {
            z = true;
            gl10.glColor4f(0.0f, 0.0f, 0.0f, this.B);
        } else {
            z = false;
        }
        gl10.glBindTexture(3553, this.C.a);
        gl10.glPushMatrix();
        gl10.glMultMatrixf(this.f.b, 0);
        gl10.glTexCoordPointer(2, 5126, 0, this.M);
        gl10.glVertexPointer(3, 5126, 0, this.N);
        gl10.glDrawElements(4, this.D, 5123, this.O);
        if (z) {
            gl10.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        }
        if (this.P != null) {
            for (int i = 0; i < this.P.size(); i++) {
                ((l) this.P.get(i)).a(gl10);
            }
        }
        gl10.glPopMatrix();
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean b(float f, float f2) {
        if (this.z && this.A) {
            if (f <= n() || f >= o() || f2 <= m() || f2 >= l()) {
                return false;
            }
            if (this.P != null) {
                for (int i = 0; i < this.P.size(); i++) {
                    if (((l) this.P.get(i)).b(f, f2)) {
                        return true;
                    }
                }
            }
            return false;
        }
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void c() {
        if (this.z) {
            i();
        }
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean c(float f, float f2) {
        if (this.z && this.A) {
            if (f <= n() || f >= o() || f2 <= m() || f2 >= l()) {
                return false;
            }
            if (this.P != null) {
                for (int i = 0; i < this.P.size(); i++) {
                    if (((l) this.P.get(i)).c(f, f2)) {
                        return true;
                    }
                }
            }
            return false;
        }
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public void d() {
        this.i = false;
        this.z = true;
        this.j = true;
        this.d.a();
    }

    @Override // com.droidhen.game.racingengine.a.l, com.droidhen.game.racingengine.a.i
    public boolean d(float f, float f2) {
        if (this.z && this.A) {
            if (f <= n() || f >= o() || f2 <= m() || f2 >= l()) {
                return false;
            }
            if (this.P != null) {
                for (int i = 0; i < this.P.size(); i++) {
                    ((l) this.P.get(i)).d(f, f2);
                }
            }
            return false;
        }
        return false;
    }

    @Override // com.droidhen.game.racingengine.a.l
    public void e() {
        this.i = false;
        this.z = true;
        this.j = false;
        this.e.a();
    }

    protected void e(float f, float f2) {
        short[] sArr = {0, 1, 2, 2, 3};
        this.D = sArr.length;
        this.M = com.droidhen.game.racingengine.f.a.a(new float[]{0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f});
        this.N = com.droidhen.game.racingengine.f.a.a(new float[]{(-f) / 2.0f, (-f2) / 2.0f, 0.0f, f / 2.0f, (-f2) / 2.0f, 0.0f, f / 2.0f, f2 / 2.0f, 0.0f, (-f) / 2.0f, f2 / 2.0f, 0.0f});
        this.O = com.droidhen.game.racingengine.f.a.a(sArr);
    }

    public void h() {
        this.d = new com.droidhen.game.racingengine.a.b.d(0.7f, 1.0f, 0.1f);
        this.d.a(new b(this));
        this.e = new com.droidhen.game.racingengine.a.b.d(1.5f, 60.0f, 0.1f);
        this.e.a(new c(this));
    }

    public void i() {
        if (this.i) {
            return;
        }
        if (this.j) {
            this.d.c();
            this.f.c(new com.droidhen.game.racingengine.g.c(this.d.d(), this.d.d(), 1.0f));
        } else {
            this.e.c();
            this.f.c(new com.droidhen.game.racingengine.g.c(this.e.d(), this.e.d(), 1.0f));
        }
    }

    public void j() {
        this.i = true;
        this.e.b();
        this.d.b();
        this.z = true;
        this.f.c(new com.droidhen.game.racingengine.g.c(1.0f, 1.0f, 1.0f));
    }

    public com.droidhen.game.racingengine.b.c.b k() {
        return this.h;
    }

    @Override // com.droidhen.game.racingengine.a.l
    public float l() {
        return this.G.b + (this.F / 2.0f);
    }

    @Override // com.droidhen.game.racingengine.a.l
    public float m() {
        return this.G.b - (this.F / 2.0f);
    }

    @Override // com.droidhen.game.racingengine.a.l
    public float n() {
        return this.G.a - (this.E / 2.0f);
    }

    @Override // com.droidhen.game.racingengine.a.l
    public float o() {
        return this.G.a + (this.E / 2.0f);
    }
}
