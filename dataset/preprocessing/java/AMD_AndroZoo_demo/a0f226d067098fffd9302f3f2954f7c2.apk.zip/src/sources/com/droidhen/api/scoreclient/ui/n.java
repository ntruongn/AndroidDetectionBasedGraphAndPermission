package com.droidhen.api.scoreclient.ui;

import android.content.DialogInterface;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
class n implements DialogInterface.OnClickListener {
    final /* synthetic */ HighScoresActivity a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public n(HighScoresActivity highScoresActivity) {
        this.a = highScoresActivity;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        double d;
        int i2;
        HighScoresActivity highScoresActivity = this.a;
        d = this.a.n;
        i2 = this.a.l;
        highScoresActivity.a(d, i2);
    }
}
