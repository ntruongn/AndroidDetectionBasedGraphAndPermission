package defpackage;

import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.ads.AdActivity;
import com.google.ads.util.AdUtil;
import com.google.ads.util.d;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class n extends WebViewClient {
    private c a;
    private Map b;
    private boolean c;
    private boolean d;
    private boolean e = false;
    private boolean f = false;

    public n(c cVar, Map map, boolean z, boolean z2) {
        this.a = cVar;
        this.b = map;
        this.c = z;
        this.d = z2;
    }

    public final void a() {
        this.e = true;
    }

    public final void b() {
        this.f = true;
    }

    @Override // android.webkit.WebViewClient
    public final void onPageFinished(WebView webView, String str) {
        if (this.e) {
            f f = this.a.f();
            if (f != null) {
                f.a();
            } else {
                d.a("adLoader was null while trying to setFinishedLoadingHtml().");
            }
            this.e = false;
        }
        if (this.f) {
            g.a(webView);
            this.f = false;
        }
    }

    @Override // android.webkit.WebViewClient
    public final boolean shouldOverrideUrlLoading(WebView webView, String str) {
        d.a("shouldOverrideUrlLoading(\"" + str + "\")");
        Uri parse = Uri.parse(str);
        if (g.a(parse)) {
            g.a(this.a, this.b, parse, webView);
            return true;
        }
        if (this.d) {
            if (AdUtil.a(parse)) {
                return super.shouldOverrideUrlLoading(webView, str);
            }
            HashMap hashMap = new HashMap();
            hashMap.put("u", str);
            AdActivity.a(this.a, new d("intent", hashMap));
            return true;
        }
        if (!this.c) {
            d.e("URL is not a GMSG and can't handle URL: " + str);
            return true;
        }
        HashMap b = AdUtil.b(parse);
        if (b == null) {
            d.e("An error occurred while parsing the url parameters.");
            return true;
        }
        this.a.k().a((String) b.get("ai"));
        String str2 = (this.a.t() && AdUtil.a(parse)) ? "webapp" : "intent";
        HashMap hashMap2 = new HashMap();
        hashMap2.put("u", parse.toString());
        AdActivity.a(this.a, new d(str2, hashMap2));
        return true;
    }
}
