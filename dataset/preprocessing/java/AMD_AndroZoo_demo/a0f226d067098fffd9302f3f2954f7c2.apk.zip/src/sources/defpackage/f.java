package defpackage;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.webkit.WebView;
import com.google.ads.b;
import com.google.ads.c;
import com.google.ads.e;
import com.google.ads.util.AdUtil;
import com.google.ads.util.d;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class f extends AsyncTask {
    private String d;
    private e e;
    private c f;
    private WebView g;
    public String b = null;
    String a = null;
    public b c = null;
    private boolean h = false;
    private boolean i = false;

    public f(c cVar) {
        this.f = cVar;
        Activity d = cVar.d();
        if (d == null) {
            this.g = null;
            this.e = null;
            d.e("activity was null while trying to create an AdLoader.");
            return;
        }
        this.g = new WebView(d.getApplicationContext());
        this.g.getSettings().setJavaScriptEnabled(true);
        this.g.setWebViewClient(new n(cVar, g.a, false, false));
        AdUtil.a(this.g);
        this.g.setVisibility(8);
        this.g.setWillNotDraw(true);
        this.e = new e(this, cVar, d.getApplicationContext());
    }

    /* JADX INFO: Access modifiers changed from: private */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public b doInBackground(c... cVarArr) {
        synchronized (this) {
            if (this.g == null || this.e == null) {
                d.e("adRequestWebView was null while trying to load an ad.");
                return b.INTERNAL_ERROR;
            }
            c cVar = cVarArr[0];
            Activity d = this.f.d();
            if (d == null) {
                d.e("activity was null while forming an ad request.");
                return b.INTERNAL_ERROR;
            }
            try {
                this.g.loadDataWithBaseURL(null, a(cVar, d), "text/html", "utf-8", null);
                long m = this.f.m();
                long elapsedRealtime = SystemClock.elapsedRealtime();
                if (m > 0) {
                    try {
                        wait(m);
                    } catch (InterruptedException e) {
                        d.e("AdLoader InterruptedException while getting the URL: " + e);
                        return b.INTERNAL_ERROR;
                    }
                }
                if (this.c != null) {
                    return this.c;
                }
                if (this.b == null) {
                    d.c("AdLoader timed out after " + m + "ms while getting the URL.");
                    return b.NETWORK_ERROR;
                }
                publishProgress(this.b);
                long elapsedRealtime2 = m - (SystemClock.elapsedRealtime() - elapsedRealtime);
                if (elapsedRealtime2 > 0) {
                    try {
                        wait(elapsedRealtime2);
                    } catch (InterruptedException e2) {
                        d.e("AdLoader InterruptedException while getting the HTML: " + e2);
                        return b.INTERNAL_ERROR;
                    }
                }
                if (this.c != null) {
                    return this.c;
                }
                if (this.a == null) {
                    d.c("AdLoader timed out after " + m + "ms while getting the HTML.");
                    return b.NETWORK_ERROR;
                }
                b h = this.f.h();
                this.f.i().a();
                h.loadDataWithBaseURL(this.d, this.a, "text/html", "utf-8", null);
                long elapsedRealtime3 = m - (SystemClock.elapsedRealtime() - elapsedRealtime);
                if (elapsedRealtime3 > 0) {
                    try {
                        wait(elapsedRealtime3);
                    } catch (InterruptedException e3) {
                        d.e("AdLoader InterruptedException while loading the HTML: " + e3);
                        h.stopLoading();
                        return b.INTERNAL_ERROR;
                    }
                }
                if (this.i) {
                    return null;
                }
                h.stopLoading();
                this.h = true;
                d.c("AdLoader timed out after " + m + "ms while loading the HTML.");
                return b.NETWORK_ERROR;
            } catch (y e4) {
                d.b("Caught internal exception.", e4);
                return b.INTERNAL_ERROR;
            } catch (z e5) {
                d.b("Unable to connect to network.", e5);
                return b.NETWORK_ERROR;
            }
        }
    }

    private String a(c cVar, Activity activity) {
        Context applicationContext = activity.getApplicationContext();
        Map a = cVar.a(applicationContext);
        a k = this.f.k();
        long h = k.h();
        if (h > 0) {
            a.put("prl", Long.valueOf(h));
        }
        String g = k.g();
        if (g != null) {
            a.put("ppcl", g);
        }
        String f = k.f();
        if (f != null) {
            a.put("pcl", f);
        }
        long e = k.e();
        if (e > 0) {
            a.put("pcc", Long.valueOf(e));
        }
        a.put("preqs", Long.valueOf(a.i()));
        String j = k.j();
        if (j != null) {
            a.put("pai", j);
        }
        if (k.k()) {
            a.put("aoi_timeout", "true");
        }
        if (k.m()) {
            a.put("aoi_nofill", "true");
        }
        String p = k.p();
        if (p != null) {
            a.put("pit", p);
        }
        k.a();
        k.d();
        if (this.f.e() instanceof e) {
            a.put("format", "interstitial_mb");
        } else {
            com.google.ads.f j2 = this.f.j();
            String fVar = j2.toString();
            if (fVar != null) {
                a.put("format", fVar);
            } else {
                HashMap hashMap = new HashMap();
                hashMap.put("w", Integer.valueOf(j2.a()));
                hashMap.put("h", Integer.valueOf(j2.b()));
                a.put("ad_frame", hashMap);
            }
        }
        a.put("slotname", this.f.g());
        a.put("js", "afma-sdk-a-v4.1.0");
        try {
            int i = applicationContext.getPackageManager().getPackageInfo(applicationContext.getPackageName(), 0).versionCode;
            a.put("msid", applicationContext.getPackageName());
            a.put("app_name", i + ".android." + applicationContext.getPackageName());
            a.put("isu", AdUtil.a(applicationContext));
            String d = AdUtil.d(applicationContext);
            if (d == null) {
                throw new z(this, "NETWORK_ERROR");
            }
            a.put("net", d);
            String e2 = AdUtil.e(applicationContext);
            if (e2 != null && e2.length() != 0) {
                a.put("cap", e2);
            }
            a.put("u_audio", Integer.valueOf(AdUtil.f(applicationContext).ordinal()));
            a.put("u_so", AdUtil.g(applicationContext));
            DisplayMetrics a2 = AdUtil.a(activity);
            a.put("u_sd", Float.valueOf(a2.density));
            a.put("u_h", Integer.valueOf((int) (a2.heightPixels / a2.density)));
            a.put("u_w", Integer.valueOf((int) (a2.widthPixels / a2.density)));
            a.put("hl", Locale.getDefault().getLanguage());
            if (AdUtil.a()) {
                a.put("simulator", 1);
            }
            String str = "<html><head><script src=\"http://www.gstatic.com/afma/sdk-core-v40.js\"></script><script>AFMA_buildAdURL(" + AdUtil.a(a) + ");</script></head><body></body></html>";
            d.c("adRequestUrlHtml: " + str);
            return str;
        } catch (PackageManager.NameNotFoundException e3) {
            throw new y(this, "NameNotFound!");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final synchronized void a() {
        this.i = true;
        notify();
    }

    public final synchronized void a(b bVar) {
        this.c = bVar;
        notify();
    }

    public final synchronized void a(String str) {
        this.b = str;
        notify();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final synchronized void a(String str, String str2) {
        this.d = str2;
        this.a = str;
        notify();
    }

    @Override // android.os.AsyncTask
    protected final void onCancelled() {
        d.a("AdLoader cancelled.");
        this.g.stopLoading();
        this.g.destroy();
        this.e.cancel(false);
    }

    @Override // android.os.AsyncTask
    protected final /* synthetic */ void onPostExecute(Object obj) {
        b bVar = (b) obj;
        synchronized (this) {
            if (bVar == null) {
                this.f.o();
            } else {
                this.g.stopLoading();
                this.g.destroy();
                this.e.cancel(false);
                if (this.h) {
                    this.f.h().setVisibility(8);
                }
                this.f.a(bVar);
            }
        }
    }

    @Override // android.os.AsyncTask
    protected final /* synthetic */ void onProgressUpdate(Object[] objArr) {
        this.e.execute(((String[]) objArr)[0]);
    }
}
