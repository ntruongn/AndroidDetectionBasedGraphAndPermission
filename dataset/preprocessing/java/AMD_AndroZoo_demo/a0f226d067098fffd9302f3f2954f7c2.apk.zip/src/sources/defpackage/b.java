package defpackage;

import android.content.Context;
import android.view.View;
import android.webkit.WebView;
import com.google.ads.AdActivity;
import com.google.ads.f;
import com.google.ads.util.AdUtil;
import com.google.ads.util.d;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class b extends WebView {
    private AdActivity a;
    private f b;

    public b(Context context, f fVar) {
        super(context);
        this.b = fVar;
        setBackgroundColor(0);
        AdUtil.a(this);
        getSettings().setJavaScriptEnabled(true);
        setScrollBarStyle(0);
    }

    public final void a() {
        if (this.a != null) {
            this.a.finish();
        }
    }

    public final void a(AdActivity adActivity) {
        this.a = adActivity;
    }

    public final AdActivity b() {
        return this.a;
    }

    @Override // android.webkit.WebView, android.widget.AbsoluteLayout, android.view.View
    protected final void onMeasure(int i, int i2) {
        if (isInEditMode()) {
            super.onMeasure(i, i2);
            return;
        }
        if (this.b == null) {
            super.onMeasure(i, i2);
            return;
        }
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        float f = getContext().getResources().getDisplayMetrics().density;
        int a = (int) (this.b.a() * f);
        int b = (int) (this.b.b() * f);
        if (mode == 0 || mode2 == 0) {
            super.onMeasure(i, i2);
            return;
        }
        if (a - (6.0f * f) <= size && b <= size2) {
            super.onMeasure(i, i2);
            return;
        }
        d.e("Not enough space to show ad! Wants: <" + a + ", " + b + ">, Has: <" + size + ", " + size2 + ">");
        setVisibility(8);
        setMeasuredDimension(0, 0);
    }
}
