package defpackage;

import android.content.Context;
import android.os.AsyncTask;
import com.google.ads.util.d;
import java.net.HttpURLConnection;
import java.util.StringTokenizer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class e extends AsyncTask {
    private f a;
    private c b;
    private Context c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(f fVar, c cVar, Context context) {
        this.a = fVar;
        this.b = cVar;
        this.c = context;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x006a, code lost:
    
        if (r2 != 200) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x006c, code lost:
    
        a(r0);
        r2 = new java.io.BufferedReader(new java.io.InputStreamReader(r0.getInputStream()), 4096);
        r0 = new java.lang.StringBuilder();
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0084, code lost:
    
        r3 = r2.readLine();
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0088, code lost:
    
        if (r3 == null) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x008a, code lost:
    
        r0.append(r3);
        r0.append("\n");
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00a2, code lost:
    
        r0 = r0.toString();
        com.google.ads.util.d.a("Response content is: " + r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00bc, code lost:
    
        if (r0 == null) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00c6, code lost:
    
        if (r0.trim().length() > 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00e8, code lost:
    
        r6.a.a(r0, r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:?, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00c8, code lost:
    
        com.google.ads.util.d.a("Response message is null or zero length: " + r0);
        r6.a.a(com.google.ads.b.NO_FILL);
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:?, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x00f0, code lost:
    
        if (r2 != 400) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x00f2, code lost:
    
        com.google.ads.util.d.c("Bad request");
        r6.a.a(com.google.ads.b.INVALID_REQUEST);
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:?, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0101, code lost:
    
        com.google.ads.util.d.c("Invalid response code: " + r2);
        r6.a.a(com.google.ads.b.INTERNAL_ERROR);
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:?, code lost:
    
        return null;
     */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Void doInBackground(java.lang.String... r7) {
        /*
            Method dump skipped, instructions count: 289
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.e.doInBackground(java.lang.String[]):java.lang.Void");
    }

    private void a(HttpURLConnection httpURLConnection) {
        String headerField = httpURLConnection.getHeaderField("X-Afma-Tracking-Urls");
        if (headerField != null) {
            StringTokenizer stringTokenizer = new StringTokenizer(headerField);
            while (stringTokenizer.hasMoreTokens()) {
                this.b.a(stringTokenizer.nextToken());
            }
        }
        b(httpURLConnection);
        String headerField2 = httpURLConnection.getHeaderField("X-Afma-Refresh-Rate");
        if (headerField2 != null) {
            try {
                this.b.a(Float.parseFloat(headerField2));
                if (!this.b.n()) {
                    this.b.c();
                }
            } catch (NumberFormatException e) {
                d.c("Could not get refresh value: " + headerField2, e);
            }
        }
        String headerField3 = httpURLConnection.getHeaderField("X-Afma-Interstitial-Timeout");
        if (headerField3 != null) {
            try {
                this.b.a(Float.parseFloat(headerField3) * 1000.0f);
            } catch (NumberFormatException e2) {
                d.c("Could not get timeout value: " + headerField3, e2);
            }
        }
        String headerField4 = httpURLConnection.getHeaderField("X-Afma-Orientation");
        if (headerField4 != null) {
            if (headerField4.equals("portrait")) {
                this.b.a(1);
            } else if (headerField4.equals("landscape")) {
                this.b.a(0);
            }
        }
    }

    private void b(HttpURLConnection httpURLConnection) {
        String headerField = httpURLConnection.getHeaderField("X-Afma-Click-Tracking-Urls");
        if (headerField != null) {
            StringTokenizer stringTokenizer = new StringTokenizer(headerField);
            while (stringTokenizer.hasMoreTokens()) {
                this.b.b(stringTokenizer.nextToken());
            }
        }
    }
}
