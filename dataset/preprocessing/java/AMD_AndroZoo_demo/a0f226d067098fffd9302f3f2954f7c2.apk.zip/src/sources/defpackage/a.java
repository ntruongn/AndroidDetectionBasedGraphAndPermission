package defpackage;

import android.os.SystemClock;
import com.google.ads.util.d;
import java.util.LinkedList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class a {
    private static long f = 0;
    public String a;
    private long c;
    private long d;
    private String g;
    private boolean h = false;
    private boolean i = false;
    private LinkedList b = new LinkedList();
    private LinkedList e = new LinkedList();

    /* JADX INFO: Access modifiers changed from: package-private */
    public a() {
        a();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long i() {
        return f;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a() {
        this.b.clear();
        this.c = 0L;
        this.d = 0L;
        this.e.clear();
        this.g = null;
        this.h = false;
        this.i = false;
    }

    public final void a(String str) {
        d.d("Prior ad identifier = " + str);
        this.g = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void b() {
        d.d("Ad clicked.");
        this.b.add(Long.valueOf(SystemClock.elapsedRealtime()));
    }

    public final void b(String str) {
        d.d("Prior impression ticket = " + str);
        this.a = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void c() {
        d.d("Ad request loaded.");
        this.c = SystemClock.elapsedRealtime();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void d() {
        d.d("Ad request started.");
        this.d = SystemClock.elapsedRealtime();
        f++;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final long e() {
        if (this.b.size() != this.e.size()) {
            return -1L;
        }
        return this.b.size();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final String f() {
        if (this.b.isEmpty() || this.b.size() != this.e.size()) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.b.size()) {
                return sb.toString();
            }
            if (i2 != 0) {
                sb.append(",");
            }
            sb.append(Long.toString(((Long) this.e.get(i2)).longValue() - ((Long) this.b.get(i2)).longValue()));
            i = i2 + 1;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final String g() {
        if (this.b.isEmpty()) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.b.size()) {
                return sb.toString();
            }
            if (i2 != 0) {
                sb.append(",");
            }
            sb.append(Long.toString(((Long) this.b.get(i2)).longValue() - this.c));
            i = i2 + 1;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final long h() {
        return this.c - this.d;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final String j() {
        return this.g;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final boolean k() {
        return this.h;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void l() {
        d.d("Interstitial network error.");
        this.h = true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final boolean m() {
        return this.i;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void n() {
        d.d("Interstitial no fill.");
        this.i = true;
    }

    public final void o() {
        d.d("Landing page dismissed.");
        this.e.add(Long.valueOf(SystemClock.elapsedRealtime()));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final String p() {
        return this.a;
    }
}
