package defpackage;

import android.app.Activity;
import android.webkit.WebView;
import android.widget.VideoView;
import com.google.ads.AdActivity;
import com.google.ads.util.d;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class q implements o {
    @Override // defpackage.o
    public final void a(c cVar, HashMap hashMap, WebView webView) {
        String str = (String) hashMap.get("action");
        if (!(webView instanceof b)) {
            d.a("Could not get adWebView to create the video.");
            return;
        }
        AdActivity b = ((b) webView).b();
        if (b == null) {
            d.a("Could not get adActivity to create the video.");
            return;
        }
        if (str.equals("load")) {
            String str2 = (String) hashMap.get("url");
            Activity d = cVar.d();
            if (d == null) {
                d.e("activity was null while loading a video.");
                return;
            }
            VideoView videoView = new VideoView(d);
            videoView.setVideoPath(str2);
            b.a(videoView);
            return;
        }
        VideoView a = b.a();
        if (a == null) {
            d.e("Could not get the VideoView for a video GMSG.");
            return;
        }
        if (str.equals("play")) {
            a.setVisibility(0);
            a.start();
            d.d("Video is now playing.");
            webView.loadUrl("javascript:AFMA_ReceiveMessage('onVideoEvent', {'event': 'playing'});");
            return;
        }
        if (str.equals("pause")) {
            a.pause();
            return;
        }
        if (str.equals("stop")) {
            a.stopPlayback();
            return;
        }
        if (str.equals("remove")) {
            a.setVisibility(8);
            return;
        }
        if (str.equals("replay")) {
            a.setVisibility(0);
            a.seekTo(0);
            a.start();
        } else if (!str.equals("currentTime")) {
            if (str.equals("position")) {
                return;
            }
            d.e("Unknown movie action: " + str);
        } else {
            String str3 = (String) hashMap.get("time");
            if (str3 == null) {
                d.e("No \"time\" parameter!");
            } else {
                a.seekTo((int) (Float.valueOf(str3).floatValue() * 1000.0f));
            }
        }
    }
}
