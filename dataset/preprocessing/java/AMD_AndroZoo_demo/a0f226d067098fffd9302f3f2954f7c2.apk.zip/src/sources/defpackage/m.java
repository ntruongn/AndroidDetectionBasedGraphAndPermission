package defpackage;

import android.net.Uri;
import android.webkit.WebView;
import com.google.ads.util.d;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class m implements o {
    @Override // defpackage.o
    public final void a(c cVar, HashMap hashMap, WebView webView) {
        Uri parse;
        String host;
        String str;
        String str2 = (String) hashMap.get("u");
        if (str2 == null) {
            d.e("Could not get URL from click gmsg.");
            return;
        }
        cVar.k().a((String) hashMap.get("ai"));
        a k = cVar.k();
        if (k != null && (host = (parse = Uri.parse(str2)).getHost()) != null && host.toLowerCase().endsWith(".admob.com")) {
            String path = parse.getPath();
            if (path != null) {
                String[] split = path.split("/");
                if (split.length >= 4) {
                    str = split[2] + "/" + split[3];
                    k.b(str);
                }
            }
            str = null;
            k.b(str);
        }
        new Thread(new p(str2, webView.getContext().getApplicationContext())).start();
    }
}
