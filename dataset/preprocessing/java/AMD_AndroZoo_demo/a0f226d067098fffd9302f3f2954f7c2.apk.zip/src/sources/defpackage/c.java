package defpackage;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Handler;
import com.google.ads.AdView;
import com.google.ads.d;
import com.google.ads.e;
import com.google.ads.f;
import com.google.ads.util.AdUtil;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedList;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class c {
    private static final Object a = new Object();
    private WeakReference b;
    private com.google.ads.a c;
    private f g;
    private String i;
    private defpackage.b j;
    private n k;
    private long m;
    private SharedPreferences p;
    private x r;
    private LinkedList s;
    private LinkedList t;
    private int u = 4;
    private defpackage.a h = new defpackage.a();
    private d d = null;
    private f e = null;
    private com.google.ads.c f = null;
    private boolean n = false;
    private Handler l = new Handler();
    private long q = 0;
    private boolean o = false;

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
    private class a extends Exception {
        public a(String str) {
            super(str);
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
    private class b extends Exception {
        public b(String str) {
            super(str);
        }
    }

    public c(Activity activity, com.google.ads.a aVar, f fVar, String str) {
        this.b = new WeakReference(activity);
        this.c = aVar;
        this.g = fVar;
        this.i = str;
        synchronized (a) {
            this.p = activity.getApplicationContext().getSharedPreferences("GoogleAdMobAdsPrefs", 0);
            long j = this.p.getLong("InterstitialTimeout" + str, -1L);
            if (j < 0) {
                this.m = 5000L;
            } else {
                this.m = j;
            }
        }
        this.r = new x(this);
        this.s = new LinkedList();
        this.t = new LinkedList();
        a();
        AdUtil.h(activity.getApplicationContext());
    }

    private synchronized boolean v() {
        return this.e != null;
    }

    public final synchronized void a() {
        Activity d = d();
        if (d == null) {
            com.google.ads.util.d.a("activity was null while trying to create an AdWebView.");
        } else {
            this.j = new defpackage.b(d.getApplicationContext(), this.g);
            this.j.setVisibility(8);
            if (this.c instanceof AdView) {
                this.k = new n(this, g.b, true, false);
            } else {
                this.k = new n(this, g.b, true, true);
            }
            this.j.setWebViewClient(this.k);
        }
    }

    public final synchronized void a(float f) {
        this.q = 1000.0f * f;
    }

    public final synchronized void a(int i) {
        this.u = i;
    }

    public final void a(long j) {
        synchronized (a) {
            SharedPreferences.Editor edit = this.p.edit();
            edit.putLong("InterstitialTimeout" + this.i, j);
            edit.commit();
            this.m = j;
        }
    }

    public final synchronized void a(com.google.ads.b bVar) {
        this.e = null;
        if (this.c instanceof e) {
            if (bVar == com.google.ads.b.NO_FILL) {
                this.h.n();
            } else if (bVar == com.google.ads.b.NETWORK_ERROR) {
                this.h.l();
            }
        }
        com.google.ads.util.d.c("onFailedToReceiveAd(" + bVar + ")");
        if (this.d != null) {
            this.d.a(this.c, bVar);
        }
    }

    public final synchronized void a(com.google.ads.c cVar) {
        if (v()) {
            com.google.ads.util.d.e("loadAd called while the ad is already loading.");
        } else {
            Activity d = d();
            if (d == null) {
                com.google.ads.util.d.e("activity is null while trying to load an ad.");
            } else if (AdUtil.c(d.getApplicationContext()) && AdUtil.b(d.getApplicationContext())) {
                this.n = false;
                this.f = cVar;
                this.e = new f(this);
                this.e.execute(cVar);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final synchronized void a(String str) {
        this.s.add(str);
    }

    public final synchronized void b() {
        if (this.o) {
            com.google.ads.util.d.a("Disabling refreshing.");
            this.l.removeCallbacks(this.r);
            this.o = false;
        } else {
            com.google.ads.util.d.a("Refreshing is already disabled.");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final synchronized void b(String str) {
        this.t.add(str);
    }

    public final synchronized void c() {
        if (!(this.c instanceof AdView)) {
            com.google.ads.util.d.a("Tried to enable refreshing on something other than an AdView.");
        } else if (this.o) {
            com.google.ads.util.d.a("Refreshing is already enabled.");
        } else {
            com.google.ads.util.d.a("Enabling refreshing every " + this.q + " milliseconds.");
            this.l.postDelayed(this.r, this.q);
            this.o = true;
        }
    }

    public final Activity d() {
        return (Activity) this.b.get();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final com.google.ads.a e() {
        return this.c;
    }

    public final synchronized f f() {
        return this.e;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final String g() {
        return this.i;
    }

    public final synchronized defpackage.b h() {
        return this.j;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final synchronized n i() {
        return this.k;
    }

    public final f j() {
        return this.g;
    }

    public final defpackage.a k() {
        return this.h;
    }

    public final synchronized int l() {
        return this.u;
    }

    public final long m() {
        long j;
        if (!(this.c instanceof e)) {
            return 60000L;
        }
        synchronized (a) {
            j = this.m;
        }
        return j;
    }

    public final synchronized boolean n() {
        return this.o;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final synchronized void o() {
        this.e = null;
        this.n = true;
        this.j.setVisibility(0);
        this.h.c();
        if (this.c instanceof AdView) {
            s();
        }
        com.google.ads.util.d.c("onReceiveAd()");
        if (this.d != null) {
            this.d.a(this.c);
        }
    }

    public final synchronized void p() {
        this.h.o();
        com.google.ads.util.d.c("onDismissScreen()");
        if (this.d != null) {
            this.d.c(this.c);
        }
    }

    public final synchronized void q() {
        this.h.b();
        com.google.ads.util.d.c("onPresentScreen()");
        if (this.d != null) {
            this.d.b(this.c);
        }
    }

    public final synchronized void r() {
        com.google.ads.util.d.c("onLeaveApplication()");
        if (this.d != null) {
            this.d.d(this.c);
        }
    }

    public final synchronized void s() {
        Activity activity = (Activity) this.b.get();
        if (activity == null) {
            com.google.ads.util.d.e("activity was null while trying to ping tracking URLs.");
        } else {
            Iterator it = this.s.iterator();
            while (it.hasNext()) {
                new Thread(new p((String) it.next(), activity.getApplicationContext())).start();
            }
            this.s.clear();
        }
    }

    public final synchronized boolean t() {
        boolean z;
        boolean z2 = !this.t.isEmpty();
        Activity activity = (Activity) this.b.get();
        if (activity == null) {
            com.google.ads.util.d.e("activity was null while trying to ping click tracking URLs.");
            z = z2;
        } else {
            Iterator it = this.t.iterator();
            while (it.hasNext()) {
                new Thread(new p((String) it.next(), activity.getApplicationContext())).start();
            }
            this.t.clear();
            z = z2;
        }
        return z;
    }

    public final synchronized void u() {
        if (this.f == null) {
            com.google.ads.util.d.a("Tried to refresh before calling loadAd().");
        } else if (this.c instanceof AdView) {
            if (((AdView) this.c).isShown() && AdUtil.b()) {
                com.google.ads.util.d.c("Refreshing ad.");
                a(this.f);
            } else {
                com.google.ads.util.d.a("Not refreshing because the ad is not visible.");
            }
            this.l.postDelayed(this.r, this.q);
        } else {
            com.google.ads.util.d.a("Tried to refresh an ad that wasn't an AdView.");
        }
    }
}
