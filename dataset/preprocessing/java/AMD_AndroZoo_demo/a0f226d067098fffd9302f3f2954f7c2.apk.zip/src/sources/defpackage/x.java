package defpackage;

import com.google.ads.util.d;
import java.lang.ref.WeakReference;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class x implements Runnable {
    private WeakReference a;

    public x(c cVar) {
        this.a = new WeakReference(cVar);
    }

    @Override // java.lang.Runnable
    public final void run() {
        c cVar = (c) this.a.get();
        if (cVar == null) {
            d.a("The ad must be gone, so cancelling the refresh timer.");
        } else {
            cVar.u();
        }
    }
}
