package defpackage;

import android.content.Context;
import com.google.ads.util.AdUtil;
import com.google.ads.util.d;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class p implements Runnable {
    private Context a;
    private String b;

    public p(String str, Context context) {
        this.b = str;
        this.a = context;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(this.b).openConnection();
            AdUtil.a(httpURLConnection, this.a);
            httpURLConnection.setInstanceFollowRedirects(true);
            httpURLConnection.connect();
            if (httpURLConnection.getResponseCode() != 200) {
                d.e("Did not receive HTTP_OK from URL: " + this.b);
            }
        } catch (IOException e) {
            d.c("Unable to ping the URL: " + this.b, e);
        }
    }
}
