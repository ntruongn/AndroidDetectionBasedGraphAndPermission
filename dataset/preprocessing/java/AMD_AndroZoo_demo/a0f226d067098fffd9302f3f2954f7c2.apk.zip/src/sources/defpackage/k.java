package defpackage;

import android.webkit.WebView;
import com.google.ads.AdActivity;
import com.google.ads.util.d;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/a0f226d067098fffd9302f3f2954f7c2.apk/classes.dex */
public final class k implements o {
    @Override // defpackage.o
    public final void a(c cVar, HashMap hashMap, WebView webView) {
        String str = (String) hashMap.get("js");
        if (str == null) {
            d.b("Could not get the JS to evaluate.");
        }
        if (!(webView instanceof b)) {
            d.b("Trying to evaluate JS in a WebView that isn't an AdWebView");
            return;
        }
        AdActivity b = ((b) webView).b();
        if (b == null) {
            d.b("Could not get the AdActivity from the AdWebView.");
            return;
        }
        b b2 = b.b();
        if (b2 == null) {
            d.b("Could not get the opening WebView.");
        } else {
            g.a(b2, str);
        }
    }
}
