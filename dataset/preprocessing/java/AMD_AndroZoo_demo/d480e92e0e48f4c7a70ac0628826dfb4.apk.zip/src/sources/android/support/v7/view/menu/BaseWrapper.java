package android.support.v7.view.menu;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/d480e92e0e48f4c7a70ac0628826dfb4.apk/classes.dex */
class BaseWrapper {
    final Object mWrappedObject;

    /* JADX INFO: Access modifiers changed from: package-private */
    public BaseWrapper(Object obj) {
        if (obj == null) {
            throw new IllegalArgumentException("Wrapped Object can not be null.");
        }
        this.mWrappedObject = obj;
    }

    public Object getWrappedObject() {
        return this.mWrappedObject;
    }
}
