package com.google.android.gms.ads.mediation.customevent;

import com.google.ads.mediation.NetworkExtras;
import java.util.HashMap;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class CustomEventExtras implements NetworkExtras {
    private final HashMap<String, Object> in = new HashMap<>();

    public Object getExtra(String label) {
        return this.in.get(label);
    }

    public void setExtra(String label, Object value) {
        this.in.put(label, value);
    }
}
