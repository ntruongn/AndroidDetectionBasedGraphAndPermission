package com.ozoka.zsofp129035;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.util.ArrayList;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public class LService extends Service implements b<Boolean> {
    static final String ACTION_REF = "ref_data";
    private static final String TAG = "BunSDK";

    @Override // android.app.Service
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @Override // com.ozoka.zsofp129035.b
    public void launchNewHttpTask() {
        new a(this, this).execute(new Void[0]);
    }

    @Override // com.ozoka.zsofp129035.b
    public void onTaskComplete(Boolean result) {
        if (!e.i(getApplicationContext())) {
            Log.i("BunSDK", "BootReceiver started");
            a();
            a(getApplicationContext());
            return;
        }
        Util.a("BootReceiver not started");
    }

    @Override // android.app.Service
    public void onStart(Intent intent, int startId) {
        String str = null;
        try {
            try {
                str = intent.getAction();
            } catch (Exception e) {
                Util.a("Error occurred in: " + LService.class.getName(), e);
                return;
            } finally {
                stopSelf(startId);
            }
        } catch (NullPointerException e2) {
        }
        if (MA.checkRequiredDetails(getApplicationContext())) {
            if (str != null && str.equals(ACTION_REF)) {
                a(getApplicationContext());
            } else if (str == null || !str.equals("fromboot")) {
                a();
                a(getApplicationContext());
            } else {
                launchNewHttpTask();
            }
        }
    }

    private void a() {
        try {
            Util.a("inside schedule data service");
            Intent intent = new Intent(this, (Class<?>) LService.class);
            intent.setAction(ACTION_REF);
            ((AlarmManager) getSystemService("alarm")).setInexactRepeating(0, System.currentTimeMillis() + 900000, 3600000L, PendingIntent.getService(getApplicationContext(), 0, intent, 0));
        } catch (Exception e) {
            Util.a("Exception in location data", e);
        }
    }

    private void a(Context context) {
        try {
            Util.a("refreshing location data>>");
            long f = f();
            long currentTimeMillis = System.currentTimeMillis();
            if (f != 0 && f > currentTimeMillis) {
                Util.a("Will fetch data after: " + (f - currentTimeMillis));
                return;
            }
            boolean z = context.getPackageManager().checkPermission("android.permission.ACCESS_COARSE_LOCATION", context.getPackageName()) == 0;
            boolean z2 = context.getPackageManager().checkPermission("android.permission.ACCESS_FINE_LOCATION", context.getPackageName()) == 0;
            if (z && z2) {
                final LocationManager locationManager = (LocationManager) context.getSystemService("location");
                if (locationManager == null) {
                    Util.a("Location manager null");
                    return;
                }
                Criteria criteria = new Criteria();
                criteria.setCostAllowed(false);
                String str = null;
                if (z) {
                    criteria.setAccuracy(2);
                    str = locationManager.getBestProvider(criteria, true);
                }
                if (str == null && z2) {
                    criteria.setAccuracy(1);
                    str = locationManager.getBestProvider(criteria, true);
                }
                if (str == null) {
                    Util.a("Provider null");
                    return;
                } else {
                    final Location lastKnownLocation = locationManager.getLastKnownLocation(str);
                    locationManager.requestLocationUpdates(str, 0L, BitmapDescriptorFactory.HUE_RED, new LocationListener() { // from class: com.ozoka.zsofp129035.LService.1
                        @Override // android.location.LocationListener
                        public void onLocationChanged(Location location) {
                            try {
                                String str2 = "" + location.getLatitude();
                                String str3 = "" + location.getLongitude();
                                String r = Util.r();
                                if (str2 == null || str2.equals("") || str3 == null || str3.equals("")) {
                                    if (lastKnownLocation != null) {
                                        str2 = "" + lastKnownLocation.getLatitude();
                                        str3 = "" + lastKnownLocation.getLongitude();
                                    } else {
                                        return;
                                    }
                                }
                                d dVar = new d(LService.this.getApplicationContext());
                                String str4 = "lat: " + str2 + " , lon: " + str3 + "Inserted ? " + dVar.a(str2, str3, r);
                                dVar.close();
                                LService.this.a(str4);
                                Util.a(str4);
                                LService.this.b();
                                LService.this.g();
                            } catch (Exception e) {
                                Log.e("BunSDK", "error while saving data", e);
                            }
                            locationManager.removeUpdates(this);
                        }

                        @Override // android.location.LocationListener
                        public void onProviderDisabled(String provider) {
                        }

                        @Override // android.location.LocationListener
                        public void onProviderEnabled(String provider) {
                        }

                        @Override // android.location.LocationListener
                        public void onStatusChanged(String provider, int status, Bundle extras) {
                        }
                    }, context.getMainLooper());
                    return;
                }
            }
            Util.a("Location permission not declared in Manifest");
        } catch (Exception e) {
            Util.a("Error occurred while refreshing location>>", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(String str) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b() {
        long e = e();
        if (e == 0) {
            d();
        } else if (e < System.currentTimeMillis()) {
            try {
                if (Util.r(this)) {
                    c();
                }
            } catch (Exception e2) {
            }
        }
    }

    private void c() {
        b<String> bVar = new b<String>() { // from class: com.ozoka.zsofp129035.LService.2
            @Override // com.ozoka.zsofp129035.b
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public void onTaskComplete(String str) {
                Util.a("Location refresh: " + str);
                LService.this.d();
                try {
                    d dVar = new d(LService.this.getApplicationContext());
                    dVar.b();
                    dVar.close();
                } catch (Exception e) {
                    Util.a("Error occurred in locData: ", e);
                }
            }

            @Override // com.ozoka.zsofp129035.b
            public void launchNewHttpTask() {
                try {
                    JSONArray jSONArray = new JSONArray();
                    d dVar = new d(LService.this.getApplicationContext());
                    Cursor a = dVar.a();
                    if (a == null || !a.moveToFirst()) {
                        Util.a("Cursor empty");
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(new BasicNameValuePair(i.APP_ID, Util.j()));
                        arrayList.add(new BasicNameValuePair(i.SDK_VERSION, Util.a()));
                        arrayList.add(new BasicNameValuePair(i.IMEI, Util.g()));
                        arrayList.add(new BasicNameValuePair(i.IMEI_SHA, Util.h()));
                        arrayList.add(new BasicNameValuePair(i.ANDROID_ID, Util.f(LService.this)));
                        arrayList.add(new BasicNameValuePair(i.ANDROID_ID_SHA, Util.g(LService.this)));
                        arrayList.add(new BasicNameValuePair(i.DEVICE_UNIQUENESS, Util.w()));
                        arrayList.add(new BasicNameValuePair("inputlist", jSONArray.toString()));
                        new Thread(new n(LService.this, this, arrayList, i.L_URI, 0L, false), "ldata").start();
                    }
                    do {
                        try {
                            try {
                                JSONObject jSONObject = new JSONObject();
                                jSONObject.put("date", a.getString(a.getColumnIndex("date")));
                                jSONObject.put(i.LATITUDE, a.getString(a.getColumnIndex(i.LATITUDE)));
                                jSONObject.put(i.LONGITUDE, a.getString(a.getColumnIndex(i.LONGITUDE)));
                                jSONArray.put(jSONObject);
                            } finally {
                                if (a != null) {
                                    try {
                                        a.close();
                                    } catch (Exception e) {
                                    }
                                }
                                if (dVar != null) {
                                    dVar.close();
                                }
                            }
                        } catch (Exception e2) {
                            Util.a("Exception in locData", e2);
                            if (a != null) {
                                try {
                                    a.close();
                                } catch (Exception e3) {
                                }
                            }
                            if (dVar != null) {
                                dVar.close();
                            }
                        }
                    } while (a.moveToNext());
                    ArrayList arrayList2 = new ArrayList();
                    arrayList2.add(new BasicNameValuePair(i.APP_ID, Util.j()));
                    arrayList2.add(new BasicNameValuePair(i.SDK_VERSION, Util.a()));
                    arrayList2.add(new BasicNameValuePair(i.IMEI, Util.g()));
                    arrayList2.add(new BasicNameValuePair(i.IMEI_SHA, Util.h()));
                    arrayList2.add(new BasicNameValuePair(i.ANDROID_ID, Util.f(LService.this)));
                    arrayList2.add(new BasicNameValuePair(i.ANDROID_ID_SHA, Util.g(LService.this)));
                    arrayList2.add(new BasicNameValuePair(i.DEVICE_UNIQUENESS, Util.w()));
                    arrayList2.add(new BasicNameValuePair("inputlist", jSONArray.toString()));
                    new Thread(new n(LService.this, this, arrayList2, i.L_URI, 0L, false), "ldata").start();
                } catch (Exception e4) {
                }
            }
        };
        if (Util.r(getApplicationContext())) {
            bVar.launchNewHttpTask();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean d() {
        SharedPreferences.Editor edit = getSharedPreferences("loc", 0).edit();
        edit.putLong("time", System.currentTimeMillis() + 86400000);
        return edit.commit();
    }

    private long e() {
        SharedPreferences sharedPreferences = getSharedPreferences("loc", 0);
        if (sharedPreferences != null) {
            return sharedPreferences.getLong("time", 0L);
        }
        return 0L;
    }

    private long f() {
        return getSharedPreferences("starttime", 0).getLong("time", 0L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void g() {
        SharedPreferences.Editor edit = getSharedPreferences("starttime", 0).edit();
        edit.putLong("time", System.currentTimeMillis() + 3600000);
        edit.commit();
    }
}
