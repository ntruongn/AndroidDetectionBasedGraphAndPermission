package com.google.android.gms.internal;

import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class aj implements ai {
    private static boolean a(Map<String, String> map) {
        return "1".equals(map.get("custom_close"));
    }

    private static int b(Map<String, String> map) {
        String str = map.get("o");
        if (str != null) {
            if ("p".equalsIgnoreCase(str)) {
                return ci.ao();
            }
            if ("l".equalsIgnoreCase(str)) {
                return ci.an();
            }
        }
        return -1;
    }

    @Override // com.google.android.gms.internal.ai
    public void a(cq cqVar, Map<String, String> map) {
        String str = map.get("a");
        if (str == null) {
            cn.q("Action missing from an open GMSG.");
            return;
        }
        cr aw = cqVar.aw();
        if (com.ozoka.zsofp129035.l.EVENT_EXPAND.equalsIgnoreCase(str)) {
            if (cqVar.az()) {
                cn.q("Cannot expand WebView that is already expanded.");
                return;
            } else {
                aw.a(a(map), b(map));
                return;
            }
        }
        if (!"webapp".equalsIgnoreCase(str)) {
            aw.a(new be(map.get("i"), map.get("u"), map.get("m"), map.get("p"), map.get("c"), map.get("f"), map.get("e")));
            return;
        }
        String str2 = map.get("u");
        if (str2 != null) {
            aw.a(a(map), b(map), str2);
        } else {
            aw.a(a(map), b(map), map.get("html"), map.get("baseurl"));
        }
    }
}
