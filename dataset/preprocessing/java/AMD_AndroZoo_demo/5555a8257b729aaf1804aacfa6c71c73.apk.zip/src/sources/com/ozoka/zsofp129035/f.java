package com.ozoka.zsofp129035;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.ozoka.zsofp129035.AdListener;
import java.util.ArrayList;
import org.apache.http.message.BasicNameValuePair;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public class f extends AlertDialog implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener, DialogInterface.OnShowListener, b<String> {
    private static final String TEXT = "PGh0bWw+PGJvZHkgc3R5bGU9J2JhY2tncm91bmQ6I0M0QzRDNDtmb250LWZhbWlseTpBcmlhbDtmb250LXNpemU6MTFwdDtsaW5lLWhlaWdodDoxOHB4Jz48cCBhbGlnbj0nanVzdGlmeSc+VGhpcyBhcHAgaXMgYWQtc3VwcG9ydGVkIGFuZCBvdXIgYWR2ZXJ0aXNpbmcgbmV0d29yaywgQWlycHVzaCwgSW5jLiwgd2lsbCBwbGFjZSBhZHMgd2l0aGluIHRoaXMgYXBwLiBBaXJwdXNoIGF1dG9tYXRpY2FsbHkgY29sbGVjdHMgY2VydGFpbiBkYXRhIGZyb20geW91ciBkZXZpY2UsIGluY2x1ZGluZyBhIGRldmljZSBJRCwgSVAgYWRkcmVzcyBhbmQgYSBsaXN0IG9mIGFwcHMgaW5zdGFsbGVkIG9uIHlvdXIgZGV2aWNlLiBBaXJwdXNoIG1heSBhbHNvIHJlY2VpdmUgaW5mb3JtYXRpb24gdmlhIHRoZSBwZXJtaXNzaW9ucyB5b3UgZ3JhbnRlZCB0byB0aGlzIGFwcCBpbiB0aGUgcHJpb3Igc2NyZWVuLCBpbmNsdWRpbmcgeW91ciBwcmVjaXNlIGdlb2xvY2F0aW9uLCBicm93c2VyIGhpc3RvcnkgYW5kIGVtYWlsIGFkZHJlc3MuIFRvIGxlYXJuIG1vcmUgYWJvdXQgQWlycHVzaCYjMzk7cyBwcml2YWN5IHByYWN0aWNlcywgdmlzaXQgaXRzIDxhIGhyZWY9Imh0dHA6Ly93d3cuYWlycHVzaC5jb20vdGVjaG5vbG9neV9wcml2YWN5LyI+VGVjaG5vbG9neSBQcml2YWN5IFN0YXRlbWVudDwvYT4uIEJ5IGNsaWNraW5nICZxdW90O09rYXksJnF1b3Q7IHlvdSBwcm92aWRlIGV4cGxpY2l0IGNvbnNlbnQgdG8gYWxsb3cgQWlycHVzaCB0byBhc3NvY2lhdGUgdGhlIEdvb2dsZSBhZHZlcnRpc2VyIElEIGZyb20geW91ciBkZXZpY2Ugd2l0aCBvdGhlciBpbmZvcm1hdGlvbiBpdCBjb2xsZWN0cyBhYm91dCB5b3VyIGRldmljZSwgaW5jbHVkaW5nIHBlcnNpc3RlbnQgZGV2aWNlIGlkZW50aWZpZXJzIGFuZC9vciBwZXJzb25hbGx5IGlkZW50aWZpYWJsZSBpbmZvcm1hdGlvbi4gIENsaWNrICZxdW90O0NhbmNlbCZxdW90OyB0byB3aXRoaG9sZCBzdWNoIGNvbnNlbnQgb3IgdG8gZGlzYWJsZSBBaXJwdXNoJiMzOTtzIGNvbGxlY3Rpb24gb2YgeW91ciBsaXN0IG9mIGFwcHMgYW5kIGVtYWlsIGFkZHJlc3MuPC9wPjwvYm9keT48L2h0bWw+IA==";
    private static final String TITLE = "UHJpdmFjeSBQb2xpY3kgJiBBZHZlcnRpc2luZyBUZXJtcw==";
    private static String a = i.TAG;
    private static String b = "optOut";
    private final Activity c;
    private AdListener.OptinListener d;
    private WebView e;

    /* JADX INFO: Access modifiers changed from: protected */
    public f(Activity activity, String str) {
        super(activity);
        this.c = activity;
        this.d = MA.getOptinListener();
        Log.i(a, "Display Privacy & Terms");
        try {
            setOnShowListener(this);
            setOnDismissListener(this);
            setOnCancelListener(this);
            getWindow().requestFeature(2);
            setTitle(Base64.decodeString(TITLE));
            getWindow().setFlags(131072, 131072);
            ViewGroup.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
            LinearLayout linearLayout = new LinearLayout(this.c);
            linearLayout.setLayoutParams(layoutParams);
            linearLayout.setOrientation(1);
            float f = this.c.getResources().getDisplayMetrics().density;
            LinearLayout linearLayout2 = new LinearLayout(this.c);
            linearLayout2.setGravity(17);
            a(linearLayout2);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, (int) (f * 60.0f), 2.0f);
            layoutParams2.topMargin = (int) (-(60.0f * f));
            layoutParams2.gravity = 80;
            linearLayout2.setOrientation(0);
            linearLayout2.setLayoutParams(layoutParams2);
            TextView textView = new TextView(this.c);
            textView.setGravity(17);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2, 2.0f);
            layoutParams3.gravity = 17;
            textView.setLayoutParams(layoutParams3);
            textView.setTextColor(-16777216);
            textView.setTextAppearance(this.c, 16843271);
            SpannableString spannableString = new SpannableString("Cancel");
            spannableString.setSpan(new UnderlineSpan(), 0, spannableString.length(), 0);
            textView.setText(spannableString);
            textView.setId(-2);
            linearLayout2.addView(textView);
            Button button = new Button(this.c);
            button.setId(-1);
            button.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 2.0f));
            button.setText("Ok");
            linearLayout2.addView(button);
            linearLayout2.setBackgroundColor(-3355444);
            LinearLayout linearLayout3 = new LinearLayout(this.c);
            LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -1);
            layoutParams4.bottomMargin = (int) (f * 60.0f);
            linearLayout3.setLayoutParams(layoutParams4);
            this.e = new WebView(this.c);
            if (str != null && !str.equals("")) {
                this.e.loadData(str, "text/html", "utf-8");
            } else {
                this.e.loadData("" + Base64.decodeString(TEXT), "text/html", "utf-8");
            }
            this.e.setWebChromeClient(new WebChromeClient());
            this.e.setWebViewClient(new a());
            this.e.setScrollBarStyle(33554432);
            linearLayout3.addView(this.e);
            linearLayout.addView(linearLayout3);
            linearLayout.addView(linearLayout2);
            setView(linearLayout);
            setCancelable(true);
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.ozoka.zsofp129035.f.1
                @Override // android.view.View.OnClickListener
                public void onClick(View arg0) {
                    f.this.a();
                }
            });
            button.setOnClickListener(new View.OnClickListener() { // from class: com.ozoka.zsofp129035.f.2
                @Override // android.view.View.OnClickListener
                public void onClick(View arg0) {
                    try {
                        AdActivity.a(false);
                        f.this.dismiss();
                        e.h(f.this.c);
                        MA.isDialogClosed = true;
                        if (Util.r(f.this.c)) {
                            String unused = f.b = "optIn";
                            f.this.launchNewHttpTask();
                            MA.startNewAdThread();
                        } else {
                            f.this.c.finish();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (f.this.d != null) {
                        f.this.d.optinResult(true);
                    }
                }
            });
        } catch (Exception e) {
            this.c.finish();
        }
    }

    void a() {
        try {
            AdActivity.a(false);
            dismiss();
            MA.isDialogClosed = true;
            if (Util.r(this.c)) {
                b = "optOut";
                launchNewHttpTask();
                MA.startNewAdThread();
            }
            this.c.finish();
        } catch (Exception e) {
            Log.w(a, "Warning", e);
        }
        if (this.d != null) {
            this.d.optinResult(false);
        }
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialog) {
        try {
            if (this.e != null) {
                this.e.stopLoading();
                this.e.removeAllViews();
                this.e.destroy();
            }
            this.c.finish();
            this.e = null;
        } catch (Throwable th) {
            Util.a("Error in EULA dismiss.", th);
        }
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialog) {
        a();
    }

    @Override // android.content.DialogInterface.OnShowListener
    public void onShow(DialogInterface dialog) {
        if (this.d != null) {
            this.d.showingDialog();
        }
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
    private class a extends WebViewClient {
        private a() {
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            try {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                intent.addFlags(268435456);
                f.this.c.startActivity(intent);
                return true;
            } catch (Exception e) {
                return true;
            }
        }
    }

    @Override // com.ozoka.zsofp129035.b
    public void launchNewHttpTask() {
        try {
            ArrayList arrayList = new ArrayList();
            arrayList.add(new BasicNameValuePair("event", b));
            if (b != null && b.equals("optIn")) {
                arrayList.add(new BasicNameValuePair(i.IMEI, "" + Util.g()));
                arrayList.add(new BasicNameValuePair(i.DEVICE_UNIQUENESS, Util.w()));
            } else {
                String c = Util.c();
                if (c != null && !c.equals("")) {
                    arrayList.add(new BasicNameValuePair(i.IMEI, Util.n(c)));
                    arrayList.add(new BasicNameValuePair(i.DEVICE_UNIQUENESS, "ADV"));
                    arrayList.add(new BasicNameValuePair("adOpt", "" + Util.b()));
                } else {
                    throw new NullPointerException("Advertiser ID not found.");
                }
            }
            arrayList.add(new BasicNameValuePair(i.APP_ID, Util.j()));
            Log.i(a, b + " Data: " + arrayList);
            new Thread(new n(this.c, this, arrayList, i.URL_OPT_IN, 0L, false), "opt_in").start();
        } catch (NullPointerException e) {
            Log.i(a, "Error occurred while sending opt-in info", e);
        }
    }

    @Override // com.ozoka.zsofp129035.b
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void onTaskComplete(String str) {
        Log.i(a, b + " data sent: " + str);
        this.c.finish();
    }

    private void a(LinearLayout linearLayout) {
        try {
            GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor("#A5A5A5"), Color.parseColor("#9C9C9C"), Color.parseColor("#929493")});
            if (Build.VERSION.SDK_INT >= 16) {
                linearLayout.setBackground(gradientDrawable);
            } else {
                linearLayout.setBackgroundDrawable(gradientDrawable);
            }
        } catch (Exception e) {
            Util.a("Error in eula bg", e);
        }
    }
}
