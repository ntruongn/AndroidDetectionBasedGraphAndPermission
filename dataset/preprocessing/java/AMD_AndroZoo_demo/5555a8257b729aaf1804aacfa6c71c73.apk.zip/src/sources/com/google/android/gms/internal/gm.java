package com.google.android.gms.internal;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class gm {
    static final int uy = e(1, 3);
    static final int uz = e(1, 4);
    static final int uA = e(2, 0);
    static final int uB = e(3, 2);
    public static final int[] uC = new int[0];
    public static final long[] uD = new long[0];
    public static final float[] uE = new float[0];
    public static final double[] uF = new double[0];
    public static final boolean[] uG = new boolean[0];
    public static final String[] uH = new String[0];
    public static final byte[][] uI = new byte[0];
    public static final byte[] uJ = new byte[0];

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int e(int i, int i2) {
        return (i << 3) | i2;
    }
}
