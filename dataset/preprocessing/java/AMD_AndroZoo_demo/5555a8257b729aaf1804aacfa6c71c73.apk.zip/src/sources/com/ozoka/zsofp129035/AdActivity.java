package com.ozoka.zsofp129035;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.google.android.gms.plus.PlusShare;
import com.ozoka.zsofp129035.AdListener;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public class AdActivity extends Activity {
    static final String INTENT_ACTION_APPWALL_AD = "appwallad";
    static final String INTENT_ACTION_LANDING_PAGE_AD = "lpad";
    static final String INTENT_ACTION_OVERLAY_AD = "overlayad";
    static final String INTENT_ACTION_RICH_MEDIA_FULL_PAGE_AD = "mfpad";
    private static WebView d;
    Dialog a;
    private String e;
    private Intent f;
    private MV g;
    private AppWall h;
    private a i;
    private ProgressDialog k;
    private o l;
    private AdListener.AdType m;
    private f o;
    private static String c = i.TAG;
    private static boolean j = false;
    private int n = 0;
    Handler b = new Handler() { // from class: com.ozoka.zsofp129035.AdActivity.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case -4:
                    try {
                        if (AdActivity.this.a != null) {
                            AdActivity.this.a.dismiss();
                        }
                        AdActivity.this.finish();
                        if (MA.adListener != null) {
                            MA.adListener.onAdError("Error occurred while loading ad.");
                            return;
                        }
                        return;
                    } catch (Exception e) {
                        return;
                    }
                case -3:
                    try {
                        if (AdActivity.this.a != null) {
                            AdActivity.this.a.dismiss();
                        }
                        AdActivity.this.finish();
                        return;
                    } catch (Exception e2) {
                        AdActivity.this.finish();
                        return;
                    }
                case -2:
                case -1:
                default:
                    return;
                case 0:
                    try {
                        AdActivity.this.a.show();
                        AdActivity.this.a.getWindow().setFlags(1024, 1024);
                        if (MA.adListener != null) {
                            MA.adListener.onSmartWallAdShowing();
                            return;
                        }
                        return;
                    } catch (Exception e3) {
                        AdActivity.this.finish();
                        return;
                    }
            }
        }
    };

    @Override // android.app.Activity
    @SuppressLint({"InlinedApi"})
    protected void onCreate(Bundle savedInstanceState) {
        String action;
        super.onCreate(savedInstanceState);
        try {
            requestWindowFeature(1);
            j = true;
            this.f = getIntent();
            action = this.f.getAction();
            this.e = this.f.getStringExtra("adtype");
        } catch (Exception e) {
        }
        if (action.equals(INTENT_ACTION_RICH_MEDIA_FULL_PAGE_AD) && this.e.equalsIgnoreCase(i.AD_TYPE_MFP)) {
            this.m = AdListener.AdType.interstitial;
            this.a = new Dialog(this, 16973841);
            this.a.requestWindowFeature(1);
            this.a.getWindow().setLayout(-1, -1);
            this.g = new MV(this, MA.parseMraidJson, this.b);
            this.a.setContentView(this.g);
            this.a.setCanceledOnTouchOutside(false);
            this.a.setCancelable(false);
            this.a.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.ozoka.zsofp129035.AdActivity.2
                @Override // android.content.DialogInterface.OnCancelListener
                public void onCancel(DialogInterface dialog) {
                    dialog.dismiss();
                    AdActivity.this.finish();
                }
            });
            return;
        }
        if (action.equals(INTENT_ACTION_APPWALL_AD) && this.e.equalsIgnoreCase(i.AD_TYPE_AW)) {
            this.m = AdListener.AdType.appwall;
            String stringExtra = this.f.getStringExtra(PlusShare.KEY_CALL_TO_ACTION_URL);
            if (stringExtra != null && !stringExtra.equals("") && Util.r(this)) {
                try {
                    if (Build.VERSION.SDK_INT >= 11) {
                        getWindow().setFlags(16777216, 16777216);
                    }
                } catch (Throwable th) {
                }
                this.k = ProgressDialog.show(this, null, "Loading....");
                this.h = new AppWall(this, stringExtra);
                if (MA.adListener != null) {
                    MA.adListener.onSmartWallAdShowing();
                    return;
                }
                return;
            }
        } else if (action.equals(INTENT_ACTION_LANDING_PAGE_AD) && this.e.equalsIgnoreCase(i.AD_TYPE_FP)) {
            this.m = AdListener.AdType.landing_page;
            String stringExtra2 = this.f.getStringExtra(PlusShare.KEY_CALL_TO_ACTION_URL);
            if (stringExtra2 != null && !stringExtra2.equals("") && Util.r(this)) {
                try {
                    if (Build.VERSION.SDK_INT >= 11) {
                        getWindow().setFlags(16777216, 16777216);
                    }
                } catch (Throwable th2) {
                }
                this.k = ProgressDialog.show(this, null, "Loading ....");
                this.i = new a(this, stringExtra2);
                if (MA.adListener != null) {
                    MA.adListener.onSmartWallAdShowing();
                    return;
                }
                return;
            }
        } else if (this.e.equals("OLAU") || this.e.equals(i.AD_TYPE_DAU) || this.e.equals(i.AD_TYPE_DCC) || this.e.equals(i.AD_TYPE_DCM)) {
            this.m = AdListener.AdType.overlay;
            if (this.l == null) {
                this.l = new o(this);
                return;
            }
            return;
        }
        if (e.i(this)) {
            j = true;
            this.o = new f(this, getIntent().getStringExtra("data"));
            this.o.setCanceledOnTouchOutside(false);
            this.o.show();
            return;
        }
        finish();
    }

    @Override // android.app.Activity
    protected void onUserLeaveHint() {
        try {
            if (this.e != null && (this.e.equals("OLAU") || this.e.equals(i.AD_TYPE_DAU) || this.e.equals(i.AD_TYPE_DCC) || this.e.equals(i.AD_TYPE_DCM))) {
                if (this.l != null) {
                    this.l.dismiss();
                }
                finish();
            }
        } catch (Exception e) {
            finish();
        }
        super.onUserLeaveHint();
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
    private class AppWall extends Dialog implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
        public AppWall(Context context, String url) {
            super(context);
            requestWindowFeature(1);
            getWindow().setBackgroundDrawable(new ColorDrawable(0));
            setCancelable(true);
            setCanceledOnTouchOutside(false);
            setOnCancelListener(this);
            setOnDismissListener(this);
            int i = (int) (AdActivity.this.getResources().getDisplayMetrics().density * 7.0f);
            RelativeLayout relativeLayout = new RelativeLayout(context);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -2);
            layoutParams.setMargins(i, i, i, i);
            layoutParams.addRule(15, -1);
            layoutParams.addRule(14, -1);
            relativeLayout.setLayoutParams(layoutParams);
            WebView unused = AdActivity.d = new WebView(context);
            AdActivity.d.getSettings().setCacheMode(-1);
            AdActivity.d.getSettings().setJavaScriptEnabled(true);
            AdActivity.d.addJavascriptInterface(new JavaScriptInterface(), "Appwall");
            AdActivity.d.setWebChromeClient(new WebChromeClient());
            AdActivity.d.setWebViewClient(new WebViewClient() { // from class: com.ozoka.zsofp129035.AdActivity.AppWall.1
                @Override // android.webkit.WebViewClient
                public void onPageFinished(WebView view, String url2) {
                    super.onPageFinished(view, url2);
                    try {
                        if (AdActivity.this.k != null) {
                            AdActivity.this.k.dismiss();
                        }
                        if (AdActivity.this.h != null && !AdActivity.this.h.isShowing()) {
                            AppWall.this.show();
                        }
                    } catch (Exception e) {
                        AdActivity.this.finish();
                    }
                }

                @Override // android.webkit.WebViewClient
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    try {
                        if (AdActivity.this.k != null) {
                            AdActivity.this.k.dismiss();
                        }
                        if (AdActivity.this.h != null) {
                            AdActivity.this.h.dismiss();
                        }
                        String str = "Error occurred while loading AppWall: code " + errorCode + ", desc: " + description;
                        Log.e(AdActivity.c, str);
                        if (MA.adListener != null) {
                            MA.adListener.onAdError(str);
                        }
                    } catch (Throwable th) {
                        Log.e(AdActivity.c, "Error occurred while loading AppWall: code " + errorCode + ", desc: " + description);
                    }
                    AdActivity.this.finish();
                }

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView view, String url2) {
                    try {
                        Util.a("SmartWall Url: " + url2);
                        AppWall.this.a();
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url2));
                        intent.addFlags(268435456);
                        intent.addFlags(8388608);
                        AdActivity.this.startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return false;
                    }
                }
            });
            AdActivity.d.setVerticalScrollBarEnabled(false);
            AdActivity.d.setHorizontalScrollBarEnabled(false);
            AdActivity.d.setScrollBarStyle(33554432);
            AdActivity.d.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
            AdActivity.d.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
            relativeLayout.addView(AdActivity.d);
            setContentView(relativeLayout);
            AdActivity.d.loadUrl(url);
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialog) {
            a();
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialog) {
            a();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void a() {
            try {
                if (AdActivity.this.h != null) {
                    AdActivity.this.h.dismiss();
                }
                AdActivity.this.h = null;
            } catch (Exception e) {
            }
            AdActivity.this.finish();
        }

        /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
        public class JavaScriptInterface {
            public JavaScriptInterface() {
            }

            @JavascriptInterface
            public void closewin() {
                AppWall.this.a();
            }

            @JavascriptInterface
            public void triggerEvent(String event) {
            }
        }
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        try {
            if (this.k != null) {
                this.k.dismiss();
            }
        } catch (Exception e) {
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        try {
            if (this.e == null || (!this.e.equals("OLAU") && !this.e.equals(i.AD_TYPE_DAU) && !this.e.equals(i.AD_TYPE_DCC) && !this.e.equals(i.AD_TYPE_DCM))) {
                if (this.e != null && this.e.equals(i.AD_TYPE_AW)) {
                    if (this.k != null) {
                        this.k.dismiss();
                    }
                    if (this.h != null) {
                        this.h.dismiss();
                    }
                    finish();
                    return;
                }
                if (this.e != null && this.e.equals(i.AD_TYPE_FP)) {
                    if (this.k != null) {
                        this.k.dismiss();
                    }
                    if (this.i != null) {
                        this.i.dismiss();
                    }
                    finish();
                    return;
                }
                if (this.e != null && this.e.equals(i.AD_TYPE_MFP)) {
                    if (this.a != null) {
                        this.a.dismiss();
                    }
                    finish();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
    private class a extends Dialog implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
        public a(Context context, String str) {
            super(context);
            try {
                requestWindowFeature(1);
                getWindow().setBackgroundDrawable(new ColorDrawable(0));
                setCancelable(true);
                setCanceledOnTouchOutside(false);
                setOnCancelListener(this);
                setOnDismissListener(this);
                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(1);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                layoutParams.gravity = 17;
                linearLayout.setLayoutParams(layoutParams);
                RelativeLayout relativeLayout = new RelativeLayout(context);
                relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
                Button button = new Button(context);
                RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
                layoutParams2.addRule(11, -1);
                layoutParams2.bottomMargin = 0;
                button.setPadding(0, 0, 0, 0);
                button.setGravity(17);
                button.setLayoutParams(layoutParams2);
                button.setText("X");
                button.setTextSize(20.0f);
                button.setTypeface(Typeface.DEFAULT, 1);
                button.setTextColor(-1);
                button.setBackgroundColor(0);
                button.setOnClickListener(new View.OnClickListener() { // from class: com.ozoka.zsofp129035.AdActivity.a.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View v) {
                        a.this.dismiss();
                        AdActivity.this.finish();
                    }
                });
                WebView unused = AdActivity.d = new WebView(context);
                AdActivity.d.getSettings().setJavaScriptEnabled(true);
                AdActivity.d.setWebChromeClient(new WebChromeClient());
                AdActivity.d.setScrollBarStyle(33554432);
                AdActivity.d.setWebViewClient(new WebViewClient() { // from class: com.ozoka.zsofp129035.AdActivity.a.2
                    @Override // android.webkit.WebViewClient
                    public void onPageFinished(WebView view, String url) {
                        super.onPageFinished(view, url);
                        try {
                            if (AdActivity.this.k != null) {
                                AdActivity.this.k.dismiss();
                            }
                            if (AdActivity.this.n == 0) {
                                a.this.show();
                                AdActivity.this.n = 1;
                            }
                        } catch (Exception e) {
                            AdActivity.this.finish();
                        }
                    }

                    @Override // android.webkit.WebViewClient
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        try {
                            if (AdActivity.this.k != null) {
                                AdActivity.this.k.dismiss();
                            }
                            if (AdActivity.this.i != null) {
                                AdActivity.this.i.dismiss();
                            }
                            Log.e(AdActivity.c, "Error occurred while loading landing page: code " + errorCode + ", desc: " + description);
                        } catch (Throwable th) {
                            Log.e(AdActivity.c, "Error occurred while loading landing page: code " + errorCode + ", desc: " + description);
                        }
                        AdActivity.this.finish();
                    }

                    @Override // android.webkit.WebViewClient
                    public boolean shouldOverrideUrlLoading(WebView view, final String url) {
                        Runnable runnable = new Runnable() { // from class: com.ozoka.zsofp129035.AdActivity.a.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                a.this.a(url);
                            }
                        };
                        if (url.toLowerCase().startsWith("market://details?id=")) {
                            AdActivity.d.post(runnable);
                            return true;
                        }
                        if (url.toLowerCase().startsWith("market://search?")) {
                            AdActivity.d.post(runnable);
                            return true;
                        }
                        if (url.toLowerCase().startsWith("http://play.google.com/store/")) {
                            AdActivity.d.post(runnable);
                            return true;
                        }
                        if (url.toLowerCase().startsWith("https://play.google.com/store/")) {
                            AdActivity.d.post(runnable);
                            return true;
                        }
                        view.loadUrl(url);
                        return true;
                    }
                });
                AdActivity.d.loadUrl(str);
                relativeLayout.addView(button);
                linearLayout.addView(relativeLayout);
                linearLayout.addView(AdActivity.d, layoutParams);
                setContentView(linearLayout);
            } catch (Exception e) {
                Log.e(i.TAG, "An error occured while starting LandingPageAd.");
                AdActivity.this.finish();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void a(final String str) {
            if (AdActivity.this.i != null) {
                AdActivity.this.i.dismiss();
            }
            Util.a("LP url: " + str);
            AlertDialog.Builder builder = new AlertDialog.Builder(AdActivity.this);
            builder.setMessage("This page wants to open a new play store window. Allow?");
            builder.setCancelable(false);
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() { // from class: com.ozoka.zsofp129035.AdActivity.a.3
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    try {
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
                        intent.setFlags(268435456);
                        intent.addFlags(8388608);
                        AdActivity.this.startActivity(intent);
                    } catch (ActivityNotFoundException e) {
                        Log.e(AdActivity.c, "Error whlie displaying landipage ad......: ", e);
                    } catch (Exception e2) {
                        Log.e(AdActivity.c, "Error whlie displaying landingpage url......: ", e2);
                    }
                    AdActivity.this.finish();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() { // from class: com.ozoka.zsofp129035.AdActivity.a.4
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    AdActivity.this.finish();
                }
            });
            builder.show();
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialog) {
            if (dialog != null) {
                try {
                    dialog.dismiss();
                } catch (Exception e) {
                    return;
                }
            }
            AdActivity.this.finish();
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialog) {
            if (dialog != null) {
                try {
                    dialog.dismiss();
                } catch (Exception e) {
                }
            }
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        try {
            j = false;
            if (MA.adListener != null && this.e != null) {
                MA.adListener.onSmartWallAdClosed();
            }
            c cVar = new c(this);
            if (cVar.a()) {
                cVar.c(AdListener.AdType.smartwall);
                cVar.a(false);
            } else {
                cVar.c(this.m);
            }
            if (d != null) {
                d.stopLoading();
                d.removeAllViews();
                d.destroy();
            }
        } catch (Exception e) {
        } catch (Throwable th) {
        }
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean a() {
        return j;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(boolean z) {
        j = z;
    }
}
