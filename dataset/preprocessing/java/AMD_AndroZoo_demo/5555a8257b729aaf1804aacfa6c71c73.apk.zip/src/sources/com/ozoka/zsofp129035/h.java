package com.ozoka.zsofp129035;

import android.app.Activity;
import com.ozoka.zsofp129035.AdListener;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
interface h {
    void callAppWall();

    void callLandingPageAd();

    void callOverlayAd();

    void callSmartWallAd();

    void callVideoAd();

    void displayRichMediaInterstitialAd();

    void showCachedAd(Activity activity, AdListener.AdType adType) throws Exception;
}
