package com.ozoka.zsofp129035;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
abstract class m implements j {
    abstract void downloadApp(String str);

    abstract void open(String str);

    abstract void printJSLog(String str);

    abstract void sendSms(String str, String str2);

    abstract void setExpandProperties(String str);

    abstract void setOrientationProperties(String str);

    abstract void showDialer(String str);

    abstract void showLocation(String str, String str2);
}
