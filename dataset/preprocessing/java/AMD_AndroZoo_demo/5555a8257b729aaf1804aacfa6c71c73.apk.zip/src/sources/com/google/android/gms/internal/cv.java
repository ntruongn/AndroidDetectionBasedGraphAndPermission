package com.google.android.gms.internal;

import com.google.android.gms.internal.cx;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public abstract class cv extends cx.a {
    @Override // com.google.android.gms.internal.cx
    public void a(int i, com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.cx
    public void a(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.cx
    public void m(int i) {
    }

    @Override // com.google.android.gms.internal.cx
    public void onSignOutComplete() {
    }

    @Override // com.google.android.gms.internal.cx
    public void onStateDeleted(int statusCode, int stateKey) {
    }
}
