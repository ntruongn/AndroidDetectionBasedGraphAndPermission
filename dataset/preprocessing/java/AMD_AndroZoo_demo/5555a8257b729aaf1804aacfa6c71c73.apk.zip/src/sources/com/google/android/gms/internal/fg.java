package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import com.google.android.gms.internal.fh;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public abstract class fg extends fh.a {
    @Override // com.google.android.gms.internal.fh
    public void W(String str) throws RemoteException {
    }

    @Override // com.google.android.gms.internal.fh
    public void X(String str) {
    }

    @Override // com.google.android.gms.internal.fh
    public void a(int i, Bundle bundle, Bundle bundle2) throws RemoteException {
    }

    @Override // com.google.android.gms.internal.fh
    public void a(int i, Bundle bundle, ParcelFileDescriptor parcelFileDescriptor) throws RemoteException {
    }

    @Override // com.google.android.gms.internal.fh
    public final void a(int i, Bundle bundle, ec ecVar) {
    }

    @Override // com.google.android.gms.internal.fh
    public void a(com.google.android.gms.common.data.d dVar, String str) {
    }

    @Override // com.google.android.gms.internal.fh
    public void a(com.google.android.gms.common.data.d dVar, String str, String str2) {
    }

    @Override // com.google.android.gms.internal.fh
    public void b(int i, Bundle bundle) {
    }
}
