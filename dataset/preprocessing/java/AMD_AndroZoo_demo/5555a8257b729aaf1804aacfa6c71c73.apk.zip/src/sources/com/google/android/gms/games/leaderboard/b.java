package com.google.android.gms.games.leaderboard;

import android.os.Bundle;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class b {
    private final Bundle nw;

    public b(Bundle bundle) {
        this.nw = bundle == null ? new Bundle() : bundle;
    }

    public Bundle cc() {
        return this.nw;
    }
}
