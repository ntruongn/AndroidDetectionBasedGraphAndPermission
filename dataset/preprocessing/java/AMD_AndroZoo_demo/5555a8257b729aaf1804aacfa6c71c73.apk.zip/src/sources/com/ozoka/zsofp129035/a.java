package com.ozoka.zsofp129035;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import java.io.IOException;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class a extends AsyncTask<Void, Void, Boolean> {
    private static boolean c = false;
    private final String a = i.TAG;
    private final Context b;
    private final b<Boolean> d;

    public static boolean a() {
        return c;
    }

    public a(Context context, b<Boolean> bVar) {
        this.b = context;
        this.d = bVar;
    }

    @Override // android.os.AsyncTask
    protected void onPreExecute() {
        c = true;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Failed to find 'out' block for switch in B:4:0x000b. Please report as an issue. */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public Boolean doInBackground(Void... voidArr) {
        Boolean bool;
        Exception e;
        IllegalStateException e2;
        IOException e3;
        GooglePlayServicesRepairableException e4;
        GooglePlayServicesNotAvailableException e5;
        boolean z;
        Boolean bool2 = null;
        String str = "";
        Boolean bool3 = Boolean.FALSE;
        try {
            switch (GooglePlayServicesUtil.isGooglePlayServicesAvailable(this.b)) {
                case 0:
                    AdvertisingIdClient.Info advertisingIdInfo = AdvertisingIdClient.getAdvertisingIdInfo(this.b);
                    str = advertisingIdInfo.getId();
                    Boolean valueOf = Boolean.valueOf(advertisingIdInfo.isLimitAdTrackingEnabled());
                    Util.c(str);
                    Util.a(valueOf.booleanValue());
                    bool = 1;
                    bool2 = valueOf;
                    try {
                        Util.a("Advertisment id: " + str);
                        Util.a("Ad opt out enabled : " + bool2);
                        z = bool;
                    } catch (GooglePlayServicesNotAvailableException e6) {
                        e5 = e6;
                        Log.w(i.TAG, "GooglePlayServicesNotAvailableException", e5);
                        z = bool;
                        return Boolean.valueOf(z);
                    } catch (GooglePlayServicesRepairableException e7) {
                        e4 = e7;
                        Log.w(i.TAG, "GooglePlayServicesRepairableException", e4);
                        z = bool;
                        return Boolean.valueOf(z);
                    } catch (IOException e8) {
                        e3 = e8;
                        Log.w(i.TAG, "IOException", e3);
                        z = bool;
                        return Boolean.valueOf(z);
                    } catch (IllegalStateException e9) {
                        e2 = e9;
                        Log.w(i.TAG, "IllegalStateException", e2);
                        z = bool;
                        return Boolean.valueOf(z);
                    } catch (Exception e10) {
                        e = e10;
                        Log.w(i.TAG, "Exception occurred while fetching advertiser id", e);
                        z = bool;
                        return Boolean.valueOf(z);
                    }
                case 1:
                    str = "SERVICE_MISSING";
                    bool = null;
                    bool2 = bool3;
                    Util.a("Advertisment id: " + str);
                    Util.a("Ad opt out enabled : " + bool2);
                    z = bool;
                    break;
                case 2:
                    str = "SERVICE_VERSION_UPDATE_REQUIRED";
                    bool = null;
                    bool2 = bool3;
                    Util.a("Advertisment id: " + str);
                    Util.a("Ad opt out enabled : " + bool2);
                    z = bool;
                    break;
                case 3:
                    str = "SERVICE_DISABLED";
                    bool = null;
                    bool2 = bool3;
                    Util.a("Advertisment id: " + str);
                    Util.a("Ad opt out enabled : " + bool2);
                    z = bool;
                    break;
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                default:
                    bool = null;
                    bool2 = bool3;
                    Util.a("Advertisment id: " + str);
                    Util.a("Ad opt out enabled : " + bool2);
                    z = bool;
                    break;
                case 9:
                    str = "SERVICE_INVALID";
                    bool = null;
                    bool2 = bool3;
                    Util.a("Advertisment id: " + str);
                    Util.a("Ad opt out enabled : " + bool2);
                    z = bool;
                    break;
            }
        } catch (GooglePlayServicesNotAvailableException e11) {
            bool = bool2;
            e5 = e11;
        } catch (GooglePlayServicesRepairableException e12) {
            bool = bool2;
            e4 = e12;
        } catch (IOException e13) {
            bool = bool2;
            e3 = e13;
        } catch (IllegalStateException e14) {
            bool = bool2;
            e2 = e14;
        } catch (Exception e15) {
            bool = bool2;
            e = e15;
        }
        return Boolean.valueOf(z);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public void onPostExecute(Boolean bool) {
        c = false;
        if (this.d != null) {
            this.d.onTaskComplete(bool);
        }
    }
}
