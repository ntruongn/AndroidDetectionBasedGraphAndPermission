package com.ozoka.zsofp129035;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.location.Location;
import android.util.Log;
import android.webkit.WebView;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public class e implements i {
    static List<NameValuePair> b;
    private static Context e;
    private static SharedPreferences g;
    b<String> c = new b<String>() { // from class: com.ozoka.zsofp129035.e.1
        @Override // com.ozoka.zsofp129035.b
        public void launchNewHttpTask() {
            if (MA.isSDKEnabled(e.e)) {
                try {
                    new Thread(new Runnable() { // from class: com.ozoka.zsofp129035.e.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            StringBuilder sb = new StringBuilder();
                            StringBuilder sb2 = new StringBuilder();
                            for (ApplicationInfo applicationInfo : e.e.getPackageManager().getInstalledApplications(128)) {
                                if (e.this.a(applicationInfo)) {
                                    sb2.append(("\"" + applicationInfo.packageName + "\"") + ",");
                                } else {
                                    sb.append(("\"" + applicationInfo.packageName + "\"") + ",");
                                }
                            }
                            String sb3 = sb.toString();
                            String sb4 = sb2.toString();
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(new BasicNameValuePair(i.IMEI, Util.g()));
                            arrayList.add(new BasicNameValuePair(i.IMEI_SHA, Util.h()));
                            arrayList.add(new BasicNameValuePair(i.ANDROID_ID, Util.f(e.e)));
                            arrayList.add(new BasicNameValuePair(i.ANDROID_ID_SHA, Util.g(e.e)));
                            arrayList.add(new BasicNameValuePair(i.DEVICE_UNIQUENESS, Util.w()));
                            arrayList.add(new BasicNameValuePair("user_apps", sb3));
                            arrayList.add(new BasicNameValuePair("system_apps", sb4));
                            if (Util.r(e.e)) {
                                new Thread(new n(e.e, e.this.c, arrayList, i.URL_APP_LIST, 30000L, false), "appd").start();
                            }
                        }
                    }, i.TYPE_APP).start();
                } catch (Exception e2) {
                }
            }
        }

        @Override // com.ozoka.zsofp129035.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void onTaskComplete(String str) {
            Util.a("App info result: " + str);
            if (str != null && !str.equals("")) {
                e.f(e.e);
            }
            if (Util.r(e.e)) {
                e.this.d.launchNewHttpTask();
            }
        }
    };
    b<String> d = new b<String>() { // from class: com.ozoka.zsofp129035.e.2
        @Override // com.ozoka.zsofp129035.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void onTaskComplete(String str) {
            Util.a("History result: " + str);
            if (str != null && !str.equals("")) {
                e.f(e.e);
            }
        }

        /* JADX WARN: Code restructure failed: missing block: B:11:0x004d, code lost:
        
            r4 = new org.json.JSONObject();
            r4.put("date", com.ozoka.zsofp129035.Util.b(r2.longValue()));
            r4.put(com.google.android.gms.plus.PlusShare.KEY_CALL_TO_ACTION_URL, r3);
            r1.put(r4);
         */
        /* JADX WARN: Code restructure failed: missing block: B:13:0x006b, code lost:
        
            if (r0.moveToNext() != false) goto L27;
         */
        /* JADX WARN: Code restructure failed: missing block: B:18:0x010f, code lost:
        
            com.ozoka.zsofp129035.Util.a("error inlist");
         */
        /* JADX WARN: Code restructure failed: missing block: B:19:?, code lost:
        
            return;
         */
        /* JADX WARN: Code restructure failed: missing block: B:21:0x006d, code lost:
        
            r0.close();
         */
        /* JADX WARN: Code restructure failed: missing block: B:8:0x0033, code lost:
        
            if (r0.moveToFirst() != false) goto L9;
         */
        /* JADX WARN: Code restructure failed: missing block: B:9:0x0035, code lost:
        
            r2 = java.lang.Long.valueOf(r0.getLong(r0.getColumnIndex("date")));
            r3 = r0.getString(r0.getColumnIndex(com.google.android.gms.plus.PlusShare.KEY_CALL_TO_ACTION_URL));
         */
        @Override // com.ozoka.zsofp129035.b
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void launchNewHttpTask() {
            /*
                Method dump skipped, instructions count: 279
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.ozoka.zsofp129035.e.AnonymousClass2.launchNewHttpTask():void");
        }
    };
    static JSONObject a = null;
    private static String f = "0";

    public e(Context context) {
        e = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a() {
        try {
            Util.h(new WebView(e).getSettings().getUserAgentString());
            r rVar = new r(e);
            try {
                if (!i(e)) {
                    Location d = rVar.d();
                    if (d != null) {
                        String str = "" + d.getLatitude();
                        String str2 = "" + d.getLongitude();
                        Util.k(rVar.c());
                        Util.a(d.getAccuracy());
                        Util.l(d.getProvider());
                        Util.a("Location: lat " + str + ", lon " + str2);
                        Util.i(str);
                        Util.j(str2);
                    } else {
                        Util.a("Location null: ");
                    }
                }
            } catch (Exception e2) {
            }
            String c = Util.c();
            if (c == null || c.equals("")) {
                c = "NOT FOUND";
            }
            f = (i(e) ? Util.g() : Util.n(c)) + "" + Util.j() + "" + Util.r();
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(f.getBytes(), 0, f.length());
            f = new BigInteger(1, messageDigest.digest()).toString(16);
        } catch (Exception e3) {
            Util.a("Token conversion Error ");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static List<NameValuePair> a(Context context) throws NullPointerException, Exception {
        e = context;
        b = new ArrayList();
        if (i(context)) {
            String c = Util.c();
            if (c != null && !c.equals("")) {
                b.add(new BasicNameValuePair(i.IMEI, Util.n(c)));
                b.add(new BasicNameValuePair(i.IMEI_SHA, Util.o(c)));
                b.add(new BasicNameValuePair(i.DEVICE_UNIQUENESS, "ADV"));
            } else {
                throw new NullPointerException("Advertising id not avalaible");
            }
        } else {
            if (Util.g() == null || Util.g().isEmpty()) {
                throw new NullPointerException("IMEI is empty");
            }
            b.add(new BasicNameValuePair(i.IMEI, Util.g()));
            b.add(new BasicNameValuePair(i.IMEI_SHA, Util.h()));
            b.add(new BasicNameValuePair(i.DEVICE_UNIQUENESS, Util.w()));
            b.add(new BasicNameValuePair(i.ANDROID_ID, Util.f(e)));
            b.add(new BasicNameValuePair(i.ANDROID_ID_SHA, Util.g(e)));
            b.add(new BasicNameValuePair(i.LONGITUDE, Util.m()));
            b.add(new BasicNameValuePair(i.LATITUDE, Util.l()));
            b.add(new BasicNameValuePair("locProvider", "" + Util.q()));
            b.add(new BasicNameValuePair("locType", "" + Util.o()));
            b.add(new BasicNameValuePair("locAccuracy", "" + Util.p()));
            String c2 = Util.c(e);
            if (c2 != null && !c2.equals("")) {
                b.add(new BasicNameValuePair("email_md5", Util.n(c2)));
                b.add(new BasicNameValuePair("email_sha", Util.o(c2)));
            }
            try {
                String[] o = Util.o(e);
                b.add(new BasicNameValuePair(i.COUNTRY, "" + o[0]));
                b.add(new BasicNameValuePair(i.ZIP, "" + o[1]));
            } catch (NullPointerException e2) {
            } catch (Exception e3) {
            }
        }
        if (Util.j() == null || Util.j().isEmpty()) {
            throw new NullPointerException("Appid is empty");
        }
        b.add(new BasicNameValuePair(i.APIKEY, Util.i()));
        b.add(new BasicNameValuePair(i.APP_ID, Util.j()));
        b.add(new BasicNameValuePair(i.TOKEN, f));
        b.add(new BasicNameValuePair(i.REQUEST_TIMESTAMP, Util.r()));
        b.add(new BasicNameValuePair(i.PACKAGE_NAME, Util.h(e)));
        b.add(new BasicNameValuePair("version", Util.t()));
        b.add(new BasicNameValuePair(i.CARRIER, Util.i(e)));
        b.add(new BasicNameValuePair(i.NETWORK_OPERATOR, Util.j(e)));
        b.add(new BasicNameValuePair(i.PHONE_MODEL, Util.s()));
        b.add(new BasicNameValuePair(i.MANUFACTURER, Util.v()));
        b.add(new BasicNameValuePair(i.SDK_VERSION, Util.a()));
        b.add(new BasicNameValuePair(i.WIFI, "" + Util.k(e)));
        b.add(new BasicNameValuePair(i.USER_AGENT, Util.k()));
        b.add(new BasicNameValuePair(i.SCREEN_SIZE, Util.n(e)));
        b.add(new BasicNameValuePair(i.NETWORK_SUBTYPE, Util.l(e)));
        b.add(new BasicNameValuePair(i.isTABLET, String.valueOf(Util.a(e))));
        b.add(new BasicNameValuePair(i.SCREEN_DENSITY, Util.p(e)));
        b.add(new BasicNameValuePair(i.isCONNECTION_FAST, "" + Util.m(e)));
        b.add(new BasicNameValuePair(i.UNKNOWN_SOURCE, "" + Util.t(e)));
        b.add(new BasicNameValuePair("appName", Util.s(e)));
        b.add(new BasicNameValuePair("dpi", Util.q(e)));
        b.add(new BasicNameValuePair("src", "inappbundled"));
        b.add(new BasicNameValuePair("sessionId", Util.e()));
        b.add(new BasicNameValuePair(i.LANGUAGE, "" + Util.x()));
        b.add(new BasicNameValuePair("locale", "" + Locale.getDefault()));
        b.add(new BasicNameValuePair("adv_id", "" + Util.c()));
        b.add(new BasicNameValuePair("adOpt", "" + Util.b()));
        return b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean b(Context context) {
        boolean z = false;
        if (context == null) {
            return false;
        }
        try {
            g = null;
            g = context.getSharedPreferences("next_ad_call", 0);
            SharedPreferences.Editor edit = g.edit();
            long currentTimeMillis = 10000 + System.currentTimeMillis();
            edit.putLong(i.START_TIME, currentTimeMillis);
            z = edit.commit();
            Log.i(i.TAG, "Next Smart Wall ad call time: " + new Date(currentTimeMillis).toString());
            return z;
        } catch (Exception e2) {
            return z;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long c(Context context) {
        g = null;
        if (context == null) {
            return 0L;
        }
        g = context.getSharedPreferences("next_ad_call", 0);
        if (g != null) {
            return g.getLong(i.START_TIME, 0L);
        }
        return 0L;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean d(Context context) {
        try {
            g = null;
            g = context.getSharedPreferences("video_ad_call", 0);
            SharedPreferences.Editor edit = g.edit();
            long currentTimeMillis = 30000 + System.currentTimeMillis();
            edit.putLong(i.START_TIME, currentTimeMillis);
            Util.a("Next Video ad ad call time: " + new Date(currentTimeMillis).toString());
            return edit.commit();
        } catch (Exception e2) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long e(Context context) {
        g = null;
        if (context == null) {
            return 0L;
        }
        g = context.getSharedPreferences("video_ad_call", 0);
        if (g != null) {
            return g.getLong(i.START_TIME, 0L);
        }
        return 0L;
    }

    static boolean f(Context context) {
        if (context != null) {
            g = null;
            g = context.getSharedPreferences("app_list_data", 0);
            SharedPreferences.Editor edit = g.edit();
            edit.putLong(i.START_TIME, System.currentTimeMillis() + 604800000);
            return edit.commit();
        }
        Util.a("Unable to save app time data.");
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long g(Context context) {
        g = null;
        if (context == null) {
            return 0L;
        }
        g = context.getSharedPreferences("app_list_data", 0);
        if (g != null) {
            return g.getLong(i.START_TIME, 0L);
        }
        return 0L;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean a(ApplicationInfo applicationInfo) {
        return (applicationInfo.flags & 1) != 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(Activity activity) {
        try {
            SharedPreferences sharedPreferences = activity.getSharedPreferences(i.ENABLE_AD_PREF, 0);
            MA ma = new MA(activity);
            if (sharedPreferences.contains(i.INTERSTITAL_AD_STRING) && sharedPreferences.getBoolean(i.INTERSTITAL_AD_STRING, false)) {
                ma.callSmartWallAd();
            }
            if (sharedPreferences.contains(i.OVERLAY_AD) && sharedPreferences.getBoolean(i.OVERLAY_AD, false)) {
                ma.callOverlayAd();
            }
            if (sharedPreferences.contains(i.APP_WALL_AD) && sharedPreferences.getBoolean(i.APP_WALL_AD, false)) {
                ma.callAppWall();
            }
            if (sharedPreferences.contains(i.VIDEO_AD) && sharedPreferences.getBoolean(i.VIDEO_AD, false)) {
                ma.callVideoAd();
            }
            if (sharedPreferences.contains(i.LANDING_PAGE_AD) && sharedPreferences.getBoolean(i.LANDING_PAGE_AD, false)) {
                ma.callLandingPageAd();
            }
            if (sharedPreferences.contains("rich_media") && sharedPreferences.getBoolean("rich_media", false)) {
                ma.displayRichMediaInterstitialAd();
            }
        } catch (Exception e2) {
            Util.b("Error occured in eap: " + e2.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void h(Context context) {
        try {
            SharedPreferences.Editor edit = context.getSharedPreferences("firstTime", 0).edit();
            edit.putBoolean("showDialog", false);
            edit.putString("adv_id", Util.c());
            edit.commit();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean i(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("firstTime", 0);
        String string = sharedPreferences.getString("adv_id", "");
        if (sharedPreferences.getBoolean("showDialog", true)) {
            return true;
        }
        return (string.equals("") || string.equalsIgnoreCase(Util.c())) ? false : true;
    }
}
