package com.google.android.gms.internal;

import android.net.Uri;
import android.widget.ImageView;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class da extends ImageView {
    private Uri kw;
    private int kx;

    public int aU() {
        return this.kx;
    }

    public void d(Uri uri) {
        this.kw = uri;
    }

    public void w(int i) {
        this.kx = i;
    }
}
