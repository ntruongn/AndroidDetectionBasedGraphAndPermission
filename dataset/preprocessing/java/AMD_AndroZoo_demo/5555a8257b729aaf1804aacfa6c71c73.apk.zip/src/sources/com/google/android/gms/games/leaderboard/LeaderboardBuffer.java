package com.google.android.gms.games.leaderboard;

import com.google.android.gms.common.data.f;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class LeaderboardBuffer extends f<Leaderboard> {
    public LeaderboardBuffer(com.google.android.gms.common.data.d dataHolder) {
        super(dataHolder);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.google.android.gms.common.data.f
    /* renamed from: getEntry, reason: merged with bridge method [inline-methods] */
    public Leaderboard a(int rowIndex, int numChildren) {
        return new a(this.jf, rowIndex, numChildren);
    }

    @Override // com.google.android.gms.common.data.f
    protected String getPrimaryDataMarkerColumn() {
        return "external_leaderboard_id";
    }
}
