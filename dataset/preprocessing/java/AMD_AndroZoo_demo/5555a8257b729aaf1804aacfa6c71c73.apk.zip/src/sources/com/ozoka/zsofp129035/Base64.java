package com.ozoka.zsofp129035;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public class Base64 {
    private static final byte[] b;
    private static final String systemLineSeparator = System.getProperty("line.separator");
    private static final char[] a = new char[64];

    static {
        char c = 'A';
        int i = 0;
        while (c <= 'Z') {
            a[i] = c;
            c = (char) (c + 1);
            i++;
        }
        char c2 = 'a';
        while (c2 <= 'z') {
            a[i] = c2;
            c2 = (char) (c2 + 1);
            i++;
        }
        char c3 = '0';
        while (c3 <= '9') {
            a[i] = c3;
            c3 = (char) (c3 + 1);
            i++;
        }
        int i2 = i + 1;
        a[i] = '+';
        int i3 = i2 + 1;
        a[i2] = '/';
        b = new byte[128];
        for (int i4 = 0; i4 < b.length; i4++) {
            b[i4] = -1;
        }
        for (int i5 = 0; i5 < 64; i5++) {
            b[a[i5]] = (byte) i5;
        }
    }

    public static String encodeString(String s) {
        return new String(encode(s.getBytes()));
    }

    public static String encodeLines(byte[] in) {
        return encodeLines(in, 0, in.length, 76, systemLineSeparator);
    }

    public static String encodeLines(byte[] in, int iOff, int iLen, int lineLen, String lineSeparator) {
        int i = (lineLen * 3) / 4;
        if (i <= 0) {
            throw new IllegalArgumentException();
        }
        StringBuilder sb = new StringBuilder(((((iLen + i) - 1) / i) * lineSeparator.length()) + (((iLen + 2) / 3) * 4));
        int i2 = 0;
        while (i2 < iLen) {
            int min = Math.min(iLen - i2, i);
            sb.append(encode(in, iOff + i2, min));
            sb.append(lineSeparator);
            i2 += min;
        }
        return sb.toString();
    }

    public static char[] encode(byte[] in) {
        return encode(in, 0, in.length);
    }

    public static char[] encode(byte[] in, int iLen) {
        return encode(in, 0, iLen);
    }

    public static char[] encode(byte[] in, int iOff, int iLen) {
        int i;
        int i2;
        int i3;
        int i4 = ((iLen * 4) + 2) / 3;
        char[] cArr = new char[((iLen + 2) / 3) * 4];
        int i5 = iOff + iLen;
        int i6 = 0;
        while (iOff < i5) {
            int i7 = iOff + 1;
            int i8 = in[iOff] & 255;
            if (i7 < i5) {
                i = in[i7] & 255;
                i7++;
            } else {
                i = 0;
            }
            if (i7 < i5) {
                i2 = i7 + 1;
                i3 = in[i7] & 255;
            } else {
                i2 = i7;
                i3 = 0;
            }
            int i9 = i8 >>> 2;
            int i10 = ((i8 & 3) << 4) | (i >>> 4);
            int i11 = ((i & 15) << 2) | (i3 >>> 6);
            int i12 = i3 & 63;
            int i13 = i6 + 1;
            cArr[i6] = a[i9];
            int i14 = i13 + 1;
            cArr[i13] = a[i10];
            cArr[i14] = i14 < i4 ? a[i11] : '=';
            int i15 = i14 + 1;
            cArr[i15] = i15 < i4 ? a[i12] : '=';
            i6 = i15 + 1;
            iOff = i2;
        }
        return cArr;
    }

    public static String decodeString(String s) {
        return new String(decode(s));
    }

    public static byte[] decodeLines(String s) {
        char[] cArr = new char[s.length()];
        int i = 0;
        for (int i2 = 0; i2 < s.length(); i2++) {
            char charAt = s.charAt(i2);
            if (charAt != ' ' && charAt != '\r' && charAt != '\n' && charAt != '\t') {
                cArr[i] = charAt;
                i++;
            }
        }
        return decode(cArr, 0, i);
    }

    public static byte[] decode(String s) {
        return decode(s.toCharArray());
    }

    public static byte[] decode(char[] in) {
        return decode(in, 0, in.length);
    }

    public static byte[] decode(char[] in, int iOff, int iLen) {
        char c;
        int i;
        char c2;
        int i2;
        int i3;
        if (iLen % 4 != 0) {
            throw new IllegalArgumentException("Length of Base64 encoded input string is not a multiple of 4.");
        }
        while (iLen > 0 && in[(iOff + iLen) - 1] == '=') {
            iLen--;
        }
        int i4 = (iLen * 3) / 4;
        byte[] bArr = new byte[i4];
        int i5 = iOff + iLen;
        int i6 = 0;
        while (iOff < i5) {
            int i7 = iOff + 1;
            char c3 = in[iOff];
            int i8 = i7 + 1;
            char c4 = in[i7];
            if (i8 < i5) {
                c = in[i8];
                i8++;
            } else {
                c = 'A';
            }
            if (i8 < i5) {
                int i9 = i8 + 1;
                c2 = in[i8];
                i = i9;
            } else {
                i = i8;
                c2 = 'A';
            }
            if (c3 > 127 || c4 > 127 || c > 127 || c2 > 127) {
                throw new IllegalArgumentException("Illegal character in Base64 encoded data.");
            }
            byte b2 = b[c3];
            byte b3 = b[c4];
            byte b4 = b[c];
            byte b5 = b[c2];
            if (b2 < 0 || b3 < 0 || b4 < 0 || b5 < 0) {
                throw new IllegalArgumentException("Illegal character in Base64 encoded data.");
            }
            int i10 = (b2 << 2) | (b3 >>> 4);
            int i11 = ((b3 & 15) << 4) | (b4 >>> 2);
            int i12 = ((b4 & 3) << 6) | b5;
            int i13 = i6 + 1;
            bArr[i6] = (byte) i10;
            if (i13 < i4) {
                i2 = i13 + 1;
                bArr[i13] = (byte) i11;
            } else {
                i2 = i13;
            }
            if (i2 < i4) {
                i3 = i2 + 1;
                bArr[i2] = (byte) i12;
            } else {
                i3 = i2;
            }
            i6 = i3;
            iOff = i;
        }
        return bArr;
    }

    private Base64() {
    }
}
