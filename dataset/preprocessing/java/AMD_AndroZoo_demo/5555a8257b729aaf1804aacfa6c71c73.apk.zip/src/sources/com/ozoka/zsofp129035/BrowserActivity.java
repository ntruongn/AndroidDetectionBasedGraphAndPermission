package com.ozoka.zsofp129035;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.CookieSyncManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.google.android.gms.plus.PlusShare;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public class BrowserActivity extends Activity implements View.OnClickListener {
    private static final int BUTTON_BACK_ID = 11;
    private static final int BUTTON_CLOSE_ID = 14;
    private static final int BUTTON_FORWARD_ID = 12;
    private static final int BUTTON_REFRESH_ID = 13;
    static final int CALENDER_CREATE_EVENT_REQUEST_CODE = 7;
    static final String INTENT_ACTION_BROWSE = "browser";
    static final String INTENT_ACTION_CREATE_CALENDAR_EVENT = "newCalendarEvent";
    static final String INTENT_ACTION_PLAY_VIDEO = "playVideo";
    Handler a = new Handler() { // from class: com.ozoka.zsofp129035.BrowserActivity.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case -3:
                    BrowserActivity.this.finish();
                    return;
                case -2:
                case -1:
                default:
                    return;
                case 0:
                    BrowserActivity.this.setContentView(BrowserActivity.this.i);
                    BrowserActivity.this.i.setVisibility(0);
                    Toast.makeText(BrowserActivity.this, "Ad is showing on screen.", 0).show();
                    return;
            }
        }
    };
    private float b;
    private Button c;
    private Button d;
    private Button e;
    private Button f;
    private BrowserView g;
    private LinearLayout h;
    private MV i;

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:19:0x00be -> B:10:0x003a). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00e2 -> B:10:0x003a). Please submit an issue!!! */
    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            try {
                Intent intent = getIntent();
                String action = intent.getAction();
                if (action.equals(INTENT_ACTION_BROWSE)) {
                    String stringExtra = intent.getStringExtra(PlusShare.KEY_CALL_TO_ACTION_URL);
                    if (stringExtra.startsWith("market://") || stringExtra.startsWith("tel:")) {
                        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(stringExtra)));
                        finish();
                    } else {
                        a(stringExtra);
                    }
                } else if (action.equals(INTENT_ACTION_PLAY_VIDEO)) {
                    String stringExtra2 = intent.getStringExtra(PlusShare.KEY_CALL_TO_ACTION_URL);
                    requestWindowFeature(1);
                    setTheme(16973840);
                    super.onCreate(savedInstanceState);
                    Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse(stringExtra2));
                    intent2.setDataAndType(Uri.parse(stringExtra2), "video/*");
                    startActivityForResult(intent2, 8);
                } else if (action.equals(INTENT_ACTION_CREATE_CALENDAR_EVENT)) {
                    requestWindowFeature(1);
                    setTheme(16973840);
                    super.onCreate(savedInstanceState);
                    try {
                        String stringExtra3 = intent.getStringExtra("json");
                        if (stringExtra3 == null || stringExtra3.equals("")) {
                            MV.a.a("createCalendarEvent", "Invalid jsonc");
                            MV.a.a(true);
                            finish();
                        } else {
                            CE.a(this, stringExtra3);
                        }
                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                        MV.a.d(IM.EVENT_ERROR);
                        MV.a.a("createCalendarEvent", "Calendar activity not found.");
                        MV.a.a(true);
                        finish();
                    } catch (Exception e2) {
                        MV.a.d(IM.EVENT_ERROR);
                        e2.printStackTrace();
                        MV.a.a("createCalendarEvent", "Calendar json parsing error");
                        MV.a.a(true);
                        finish();
                    }
                }
            } catch (Exception e3) {
                e3.printStackTrace();
                finish();
            }
        } catch (Throwable th) {
            th.printStackTrace();
            finish();
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == 7) {
                if (resultCode == -1) {
                    Util.a("Calender event added");
                    MV.a.d(IM.MRAID_EVENT_CREATE_CALENDER);
                    MV.a.a(true);
                    finish();
                } else if (resultCode == 0) {
                    MV.a.a(true);
                    MV.a.a("createCalendarEvent", "Creating calendar event canceled by user.");
                    finish();
                } else {
                    finish();
                }
            }
            if (requestCode == 8) {
                if (resultCode == -1) {
                    Util.a("Video played added");
                    MV.a.d(IM.MRAID_EVENT_PLAY_VIDEO);
                    MV.a.a(true);
                    finish();
                    return;
                }
                if (resultCode == 0) {
                    MV.a.a(true);
                    MV.a.a(INTENT_ACTION_PLAY_VIDEO, "Play video is canceled by user.");
                    finish();
                    return;
                }
                finish();
            }
        } catch (Exception e) {
        }
    }

    private void a(String str) {
        requestWindowFeature(2);
        this.b = getResources().getDisplayMetrics().density;
        if (str != null) {
            try {
                if (!str.equals("")) {
                    b(str);
                }
            } catch (Exception e) {
                e.printStackTrace();
                finish();
                return;
            }
        }
        Log.i(IM.TAG, "Url is null.");
        finish();
    }

    private void b(String str) {
        this.h = new LinearLayout(this);
        this.h.setOrientation(1);
        this.h.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-1, (int) (40.0f * this.b)));
        this.c = new Button(this);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(9, -1);
        layoutParams.addRule(15, -1);
        this.c.setLayoutParams(layoutParams);
        this.c.setText("Back");
        this.c.setTypeface(null, 1);
        this.c.setTextColor(-1);
        this.c.setId(11);
        relativeLayout.addView(this.c);
        this.d = new Button(this);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(1, 11);
        layoutParams2.addRule(15, -1);
        this.d.setLayoutParams(layoutParams2);
        this.d.setText("Forward");
        this.d.setTypeface(null, 1);
        this.d.setTextColor(-1);
        this.d.setId(12);
        relativeLayout.addView(this.d);
        this.e = new Button(this);
        RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams3.addRule(1, 12);
        layoutParams3.addRule(15, -1);
        this.e.setLayoutParams(layoutParams3);
        this.e.setText("Refresh");
        this.e.setTypeface(null, 1);
        this.e.setTextColor(-1);
        this.e.setId(BUTTON_REFRESH_ID);
        relativeLayout.addView(this.e);
        this.f = new Button(this);
        RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams4.addRule(11, -1);
        layoutParams4.addRule(15, -1);
        this.f.setLayoutParams(layoutParams4);
        this.f.setText("Close");
        this.f.setTypeface(null, 1);
        this.f.setTextColor(-1);
        this.f.setId(BUTTON_CLOSE_ID);
        relativeLayout.addView(this.f);
        relativeLayout.setGravity(17);
        this.h.addView(relativeLayout);
        this.g = new BrowserView(this, str);
        this.g.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.h.addView(this.g);
        setContentView(this.h);
        this.g.loadUrl(str);
        this.c.setOnClickListener(this);
        this.d.setOnClickListener(this);
        this.e.setOnClickListener(this);
        this.f.setOnClickListener(this);
        this.d.setEnabled(false);
        this.c.setEnabled(false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
    public class BrowserView extends WebView {
        @SuppressLint({"InlinedApi"})
        void a() {
            if (Build.VERSION.SDK_INT >= 8) {
                getSettings().setPluginState(WebSettings.PluginState.ON_DEMAND);
            }
        }

        @SuppressLint({"InlinedApi"})
        private void b() {
            try {
                if (Build.VERSION.SDK_INT >= 11) {
                    BrowserActivity.this.getWindow().setFlags(16777216, 16777216);
                }
            } catch (Throwable th) {
            }
        }

        @SuppressLint({"SetJavaScriptEnabled"})
        public BrowserView(Context context, String url) {
            super(context);
            setHorizontalScrollBarEnabled(false);
            setVerticalScrollBarEnabled(false);
            setScrollBarStyle(33554432);
            setBackgroundColor(0);
            CookieSyncManager.createInstance(BrowserActivity.this);
            CookieSyncManager.getInstance().startSync();
            getSettings().setJavaScriptEnabled(true);
            a();
            b();
            setWebChromeClient(new WebChromeClient() { // from class: com.ozoka.zsofp129035.BrowserActivity.BrowserView.1
                @Override // android.webkit.WebChromeClient
                public void onProgressChanged(WebView view, int progress) {
                    r3.setTitle("loading....");
                    r3.setProgress(progress * 100);
                    if (progress == 100) {
                        r3.setTitle(view.getUrl());
                    }
                }

                @Override // android.webkit.WebChromeClient
                public void onHideCustomView() {
                }

                @Override // android.webkit.WebChromeClient
                public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
                }
            });
            setWebViewClient(new WebViewClient() { // from class: com.ozoka.zsofp129035.BrowserActivity.BrowserView.2
                @Override // android.webkit.WebViewClient
                public void onPageFinished(WebView view, String url2) {
                    super.onPageFinished(view, url2);
                    if ((view != null) & view.canGoBack()) {
                        BrowserActivity.this.c.setEnabled(true);
                    } else {
                        BrowserActivity.this.c.setEnabled(false);
                    }
                    if ((view != null) & view.canGoForward()) {
                        BrowserActivity.this.d.setEnabled(true);
                    } else {
                        BrowserActivity.this.d.setEnabled(false);
                    }
                }

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView view, String url2) {
                    if (!url2.startsWith("market://")) {
                        return super.shouldOverrideUrlLoading(view, url2);
                    }
                    view.loadUrl(url2);
                    return true;
                }

                @Override // android.webkit.WebViewClient
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    super.onReceivedError(view, errorCode, description, failingUrl);
                    Log.i(IM.TAG, "Error code: " + errorCode + " ,description: " + description);
                    try {
                        BrowserActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(failingUrl)));
                        BrowserActivity.this.finish();
                    } catch (Exception e) {
                    }
                }
            });
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case 11:
                if (this.g != null && this.g.canGoBack()) {
                    this.g.goBack();
                    return;
                }
                return;
            case 12:
                if (this.g != null && this.g.canGoForward()) {
                    this.g.goForward();
                    return;
                }
                return;
            case BUTTON_REFRESH_ID /* 13 */:
                if (this.g != null) {
                    this.g.reload();
                    return;
                }
                return;
            case BUTTON_CLOSE_ID /* 14 */:
                finish();
                return;
            default:
                return;
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        getWindow().setFormat(1);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        try {
            CookieSyncManager.getInstance().stopSync();
        } catch (Exception e) {
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        try {
            CookieSyncManager.getInstance().startSync();
        } catch (Exception e) {
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        try {
            if (this.g != null) {
                this.g.stopLoading();
                this.h.removeView(this.g);
                this.g.removeAllViews();
                this.g.destroy();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        try {
            if (getIntent().getAction().equals(INTENT_ACTION_PLAY_VIDEO)) {
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onBackPressed();
    }
}
