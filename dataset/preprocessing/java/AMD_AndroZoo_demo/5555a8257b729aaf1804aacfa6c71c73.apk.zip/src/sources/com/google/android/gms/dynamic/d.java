package com.google.android.gms.dynamic;

import com.google.android.gms.dynamic.LifecycleDelegate;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public interface d<T extends LifecycleDelegate> {
    void a(T t);
}
