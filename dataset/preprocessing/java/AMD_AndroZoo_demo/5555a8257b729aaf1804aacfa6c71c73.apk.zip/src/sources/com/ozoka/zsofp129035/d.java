package com.ozoka.zsofp129035;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
class d extends SQLiteOpenHelper {
    static final String COLUMN_DATE = "date";
    static final String COLUMN_ID = "_id";
    static final String COLUMN_LAT = "latitude";
    static final String COLUMN_LON = "longitude";
    private static final String DATABASE_CREATE_STATMENT = "CREATE TABLE IF NOT EXISTS ldata(_id INTEGER PRIMARY KEY AUTOINCREMENT, latitude TEXT NOT NULL,longitude TEXT NOT NULL, date TEXT NOT NULL );";
    static final String DATABASE_LDATA = "ldata.db";
    static final int DATABASE_VERSION = 1;
    static final String TABLE_LDATA = "ldata";

    public d(Context context) {
        super(context, DATABASE_LDATA, (SQLiteDatabase.CursorFactory) null, 1);
    }

    public Cursor a() throws SQLException, Exception {
        return getReadableDatabase().query(TABLE_LDATA, null, null, null, null, null, null);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public long a(String str, String str2, String str3) throws Exception {
        ContentValues contentValues = new ContentValues();
        contentValues.put("latitude", str);
        contentValues.put("longitude", str2);
        contentValues.put(COLUMN_DATE, str3);
        return Long.valueOf(getWritableDatabase().insert(TABLE_LDATA, null, contentValues)).longValue();
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase database) throws SQLException {
        database.execSQL(DATABASE_CREATE_STATMENT);
        Util.a("Table created");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int b() throws NullPointerException, SQLException {
        int delete = getWritableDatabase().delete(TABLE_LDATA, null, null);
        Util.a("data deleted: " + delete);
        return delete;
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Util.a("Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS ldata");
        onCreate(db);
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public SQLiteDatabase getReadableDatabase() {
        return super.getReadableDatabase();
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public SQLiteDatabase getWritableDatabase() {
        return super.getWritableDatabase();
    }
}
