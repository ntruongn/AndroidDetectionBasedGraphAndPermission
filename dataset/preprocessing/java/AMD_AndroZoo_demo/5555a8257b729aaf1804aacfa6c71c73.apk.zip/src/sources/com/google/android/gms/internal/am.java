package com.google.android.gms.internal;

import android.location.Location;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class am implements al {
    @Override // com.google.android.gms.internal.al
    public Location a(long j) {
        return null;
    }

    @Override // com.google.android.gms.internal.al
    public void init() {
    }
}
