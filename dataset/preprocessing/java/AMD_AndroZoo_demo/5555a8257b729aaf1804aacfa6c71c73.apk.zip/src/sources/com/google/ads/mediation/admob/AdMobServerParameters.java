package com.google.ads.mediation.admob;

import com.google.ads.mediation.MediationServerParameters;
import com.ozoka.zsofp129035.i;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class AdMobServerParameters extends MediationServerParameters {

    @MediationServerParameters.Parameter(name = "pubid")
    public String adUnitId;

    @MediationServerParameters.Parameter(name = "mad_hac", required = i.isDebugMode)
    public String allowHouseAds = null;
    public int tagForChildDirectedTreatment = -1;
}
