package com.ozoka.zsofp129035;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public class BootReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        try {
            Intent intent2 = new Intent(context, (Class<?>) LService.class);
            intent2.setAction("fromboot");
            context.startService(intent2);
        } catch (Exception e) {
            Log.e(i.TAG, "Error occurred while start BootReceiver.");
        }
    }
}
