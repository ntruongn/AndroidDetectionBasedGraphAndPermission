package com.google.android.gms.internal;

import com.ozoka.zsofp129035.IM;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class cc {
    private String gX;
    private String gY;
    private List<String> gZ;
    private List<String> ha;
    private List<String> he;
    private long hb = -1;
    private boolean hc = false;
    private final long hd = -1;
    private long hf = -1;
    private int hg = -1;

    private static long a(Map<String, List<String>> map, String str) {
        List<String> list = map.get(str);
        if (list != null && !list.isEmpty()) {
            try {
                return Float.parseFloat(r0) * 1000.0f;
            } catch (NumberFormatException e) {
                cn.q("Could not parse float from " + str + " header: " + list.get(0));
            }
        }
        return -1L;
    }

    private static List<String> b(Map<String, List<String>> map, String str) {
        String str2;
        List<String> list = map.get(str);
        if (list == null || list.isEmpty() || (str2 = list.get(0)) == null) {
            return null;
        }
        return Arrays.asList(str2.trim().split("\\s+"));
    }

    private void e(Map<String, List<String>> map) {
        List<String> b = b(map, "X-Afma-Click-Tracking-Urls");
        if (b != null) {
            this.gZ = b;
        }
    }

    private void f(Map<String, List<String>> map) {
        List<String> b = b(map, "X-Afma-Tracking-Urls");
        if (b != null) {
            this.ha = b;
        }
    }

    private void g(Map<String, List<String>> map) {
        long a = a(map, "X-Afma-Interstitial-Timeout");
        if (a != -1) {
            this.hb = a;
        }
    }

    private void h(Map<String, List<String>> map) {
        List<String> list = map.get("X-Afma-Mediation");
        if (list == null || list.isEmpty()) {
            return;
        }
        this.hc = Boolean.valueOf(list.get(0)).booleanValue();
    }

    private void i(Map<String, List<String>> map) {
        List<String> b = b(map, "X-Afma-Manual-Tracking-Urls");
        if (b != null) {
            this.he = b;
        }
    }

    private void j(Map<String, List<String>> map) {
        long a = a(map, "X-Afma-Refresh-Rate");
        if (a != -1) {
            this.hf = a;
        }
    }

    private void k(Map<String, List<String>> map) {
        List<String> list = map.get("X-Afma-Orientation");
        if (list == null || list.isEmpty()) {
            return;
        }
        String str = list.get(0);
        if (IM.ORIENTATION_PORTRAIT.equalsIgnoreCase(str)) {
            this.hg = ci.ao();
        } else if (IM.ORIENTATION_LANDSCAPE.equalsIgnoreCase(str)) {
            this.hg = ci.an();
        }
    }

    public void a(String str, Map<String, List<String>> map, String str2) {
        this.gX = str;
        this.gY = str2;
        d(map);
    }

    public bw ak() {
        return new bw(this.gX, this.gY, this.gZ, this.ha, this.hb, this.hc, -1L, this.he, this.hf, this.hg);
    }

    public void d(Map<String, List<String>> map) {
        e(map);
        f(map);
        g(map);
        h(map);
        i(map);
        j(map);
        k(map);
    }
}
