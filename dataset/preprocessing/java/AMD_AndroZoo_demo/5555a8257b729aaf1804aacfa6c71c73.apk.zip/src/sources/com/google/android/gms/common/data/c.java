package com.google.android.gms.common.data;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public class c<T extends SafeParcelable> extends DataBuffer<T> {
    private static final String[] jk = {"data"};
    private final Parcelable.Creator<T> jl;

    public c(d dVar, Parcelable.Creator<T> creator) {
        super(dVar);
        this.jl = creator;
    }

    @Override // com.google.android.gms.common.data.DataBuffer
    /* renamed from: p, reason: merged with bridge method [inline-methods] */
    public T get(int i) {
        byte[] e = this.jf.e("data", i, 0);
        Parcel obtain = Parcel.obtain();
        obtain.unmarshall(e, 0, e.length);
        obtain.setDataPosition(0);
        T createFromParcel = this.jl.createFromParcel(obtain);
        obtain.recycle();
        return createFromParcel;
    }
}
