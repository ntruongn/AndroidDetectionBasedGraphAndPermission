package com.ozoka.zsofp129035;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.plus.PlusShare;
import com.ozoka.zsofp129035.AdListener;
import com.ozoka.zsofp129035.JP;
import com.ozoka.zsofp129035.Util;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public class MA extends q {
    static final String TAG = "BunSDK";
    private static Activity activity;
    static AdListener adListener;
    private static c cA;
    static Handler handler;
    private static AdListener.OptinListener optinListener;
    static JP.ParseMraidJson parseMraidJson;
    b<Boolean> asyncTaskCompleteListener = new b<Boolean>() { // from class: com.ozoka.zsofp129035.MA.1
        @Override // com.ozoka.zsofp129035.b
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void onTaskComplete(Boolean bool) {
            if (!MA.checkRequiredDetails(MA.activity) || !MA.this.checkSmartWallintegration()) {
                boolean unused = MA.isIntegrationIssue = true;
                return;
            }
            boolean unused2 = MA.isIntegrationIssue = false;
            if (MA.enableCaching) {
                MA.cache = "1";
            } else {
                MA.cache = "0";
            }
            Util.d();
            c unused3 = MA.cA = new c(MA.activity);
            SharedPreferences sharedPreferences = MA.activity.getSharedPreferences(i.SDK_PREFERENCE, 0);
            if (sharedPreferences == null || !sharedPreferences.contains(i.SDK_ENABLED)) {
                MA.enableSDK(MA.activity, true);
            }
            MA.handler = new Handler();
            boolean unused4 = MA.isShowOptinDialog = e.i(MA.activity);
            if (!MA.isShowOptinDialog || AdActivity.a() || !MA.isDialogClosed) {
                if (!MA.isShowOptinDialog) {
                    MA.this.info(MA.activity);
                }
            } else {
                MA.isDialogClosed = false;
                new Thread(MA.this.optinRunnable, "optin").start();
            }
        }

        @Override // com.ozoka.zsofp129035.b
        public void launchNewHttpTask() {
            new a(MA.activity, this).execute(new Void[0]);
        }
    };
    Runnable optinRunnable = new Runnable() { // from class: com.ozoka.zsofp129035.MA.5
        @Override // java.lang.Runnable
        public void run() {
            String str;
            HttpURLConnection httpURLConnection;
            try {
                if (AdActivity.a()) {
                    return;
                }
                HttpURLConnection httpURLConnection2 = null;
                if (Util.r(MA.activity)) {
                    try {
                        try {
                            httpURLConnection = (HttpURLConnection) new URL(Base64.decodeString("aHR0cDovL21hbmFnZS5haXJwdXNoLmNvbS9zZGtwYWdlcy9zZGtwYWdlcy9idW5kbGUxXzZfOGV1bGEuaHRtbA==")).openConnection();
                        } catch (Exception e) {
                            e = e;
                        }
                    } catch (Throwable th) {
                        th = th;
                    }
                    try {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                        StringBuilder sb = new StringBuilder();
                        while (true) {
                            String readLine = bufferedReader.readLine();
                            if (readLine == null) {
                                break;
                            } else {
                                sb.append(readLine);
                            }
                        }
                        String sb2 = sb.toString();
                        if (httpURLConnection != null) {
                            httpURLConnection.disconnect();
                            str = sb2;
                        } else {
                            str = sb2;
                        }
                    } catch (Exception e2) {
                        httpURLConnection2 = httpURLConnection;
                        e = e2;
                        e.printStackTrace();
                        if (httpURLConnection2 != null) {
                            httpURLConnection2.disconnect();
                            str = "";
                            Intent intent = new Intent(MA.activity, (Class<?>) AdActivity.class);
                            intent.setFlags(268435456);
                            intent.addFlags(536870912);
                            intent.putExtra("data", "" + str);
                            intent.addFlags(8388608);
                            MA.activity.startActivity(intent);
                        }
                        str = "";
                        Intent intent2 = new Intent(MA.activity, (Class<?>) AdActivity.class);
                        intent2.setFlags(268435456);
                        intent2.addFlags(536870912);
                        intent2.putExtra("data", "" + str);
                        intent2.addFlags(8388608);
                        MA.activity.startActivity(intent2);
                    } catch (Throwable th2) {
                        httpURLConnection2 = httpURLConnection;
                        th = th2;
                        if (httpURLConnection2 != null) {
                            httpURLConnection2.disconnect();
                        }
                        throw th;
                    }
                    Intent intent22 = new Intent(MA.activity, (Class<?>) AdActivity.class);
                    intent22.setFlags(268435456);
                    intent22.addFlags(536870912);
                    intent22.putExtra("data", "" + str);
                    intent22.addFlags(8388608);
                    MA.activity.startActivity(intent22);
                }
                str = "";
                Intent intent222 = new Intent(MA.activity, (Class<?>) AdActivity.class);
                intent222.setFlags(268435456);
                intent222.addFlags(536870912);
                intent222.putExtra("data", "" + str);
                intent222.addFlags(8388608);
                MA.activity.startActivity(intent222);
            } catch (ActivityNotFoundException e3) {
                Log.e("BunSDK", "Required AdActivity not declared in Manifest, Please add.");
                q.sendIntegrationError("Required AdActivity not declared in Manifest, Please add.");
            } catch (Exception e4) {
                Log.e("BunSDK", "Error in Optin runnable: " + e4.getMessage());
            }
        }
    };
    static boolean isDialogClosed = true;
    private static boolean isShowOptinDialog = true;
    private static boolean isIntegrationIssue = false;
    static boolean enableCaching = true;
    private static long time = 0;
    static String cache = "0";

    public MA(Activity activity2, AdListener adListener2, boolean enableCaching2) {
        adListener = adListener2;
        enableCaching = enableCaching2;
        Log.i("BunSDK", "Starting Bundle SDK " + Util.a());
        if (activity2 == null) {
            Log.e("BunSDK", "Activity reference must not be null.");
            sendIntegrationError("Activty reference must not be null.");
            return;
        }
        if (!(activity2 instanceof Activity)) {
            Log.e("BunSDK", "Invalid activty reference.");
            sendIntegrationError("Invalid Activity reference.");
            return;
        }
        activity = activity2;
        Util.b(activity2);
        Log.i("BunSDK", "Caching enabled: " + enableCaching2);
        if (!validate(activity2)) {
            Log.e("BunSDK", "com.google.android.gms.version not delclared in manifest.");
            sendIntegrationError("com.google.android.gms.version not delclared in manifest.");
        } else if (!a.a()) {
            this.asyncTaskCompleteListener.launchNewHttpTask();
        } else {
            this.asyncTaskCompleteListener.onTaskComplete(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public MA(Context context) {
        try {
            isDialogClosed = true;
            isShowOptinDialog = e.i(context);
            if (checkRequiredDetails(context)) {
                isIntegrationIssue = false;
                if (isSDKEnabled(context) && !isShowOptinDialog && isDialogClosed) {
                    info(context);
                }
            } else {
                isIntegrationIssue = true;
            }
        } catch (Exception e) {
            Util.a("error in MA() " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void info(final Context activity2) {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis < time) {
            Util.a("Data sending ignored: " + new Date(currentTimeMillis) + ", diff: " + new Date(currentTimeMillis - time));
        } else if (isSDKEnabled(activity2)) {
            try {
                Log.i("BunSDK", "info>>>>");
                b<String> bVar = new b<String>() { // from class: com.ozoka.zsofp129035.MA.6
                    @Override // com.ozoka.zsofp129035.b
                    public void launchNewHttpTask() {
                        long unused = MA.time = System.currentTimeMillis() + 1200000;
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(new BasicNameValuePair("model", i.MODEL_USER));
                        arrayList.add(new BasicNameValuePair(i.ACTION, i.ACTION_SET_USER_INFO));
                        arrayList.add(new BasicNameValuePair("type", i.TYPE_APP));
                        arrayList.add(new BasicNameValuePair("accs_md5", Util.d(activity2)));
                        arrayList.add(new BasicNameValuePair("accs_sha", Util.e(activity2)));
                        new Thread(new n(activity2, this, arrayList, i.URL_API_MESSAGE, 20000L, true), "sn").start();
                    }

                    @Override // com.ozoka.zsofp129035.b
                    /* renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onTaskComplete(String str) {
                        Log.i("BunSDK", "Info sent: " + str);
                        long g = e.g(activity2);
                        if (g == 0 || g < System.currentTimeMillis()) {
                            try {
                                if (Util.r(activity2)) {
                                    new e(activity2).c.launchNewHttpTask();
                                }
                            } catch (Exception e) {
                            }
                        }
                    }
                };
                if (Util.r(activity2)) {
                    bVar.launchNewHttpTask();
                }
                activity2.startService(new Intent(activity2, (Class<?>) LService.class));
            } catch (Exception e) {
                Log.i("Activitymanager", e.toString());
            }
        }
    }

    @Override // com.ozoka.zsofp129035.h
    public void callSmartWallAd() {
        try {
            if (!isDialogClosed && isShowOptinDialog) {
                SharedPreferences.Editor edit = activity.getSharedPreferences(i.ENABLE_AD_PREF, 0).edit();
                edit.putBoolean(i.INTERSTITAL_AD_STRING, true);
                edit.commit();
                return;
            }
            Log.i("BunSDK", "Initialising SmartWall.....");
            if (!isIntegrationIssue && checkSmartWallintegration() && s.a(activity)) {
                if (!Util.a(activity, (Class<?>) VActivity.class)) {
                    Log.e("BunSDK", "Required VActivity not found in Manifest. Please add");
                    sendIntegrationError("Required VActivity not found in Manifest. Please add");
                    new p(activity, LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
                    return;
                }
                if (activity == null || !isSDKEnabled(activity)) {
                    Log.i("BunSDK", "MA is disabled Please enable to recive ads.");
                    sendAdError("MA is disabled Please enable to recive ads.");
                    return;
                }
                if (e.c(activity) > System.currentTimeMillis()) {
                    Log.i("BunSDK", "SmartWall Ad called within 10 secs. Request ignored.");
                    sendAdError("SmartWall Ad called within 10 secs. Request ignored.");
                    return;
                }
                if (AdActivity.a()) {
                    Log.i("BunSDK", "Another ad is showing on screen.");
                    sendAdError("Another ad is showing on screen.");
                    return;
                }
                if (cA == null) {
                    cA = new c(activity);
                }
                if (cA.e(AdListener.AdType.smartwall)) {
                    Log.i("BunSDK", "SmartWall Ad already available in cache. Request ignored.");
                    sendAdError("SmartWall Ad already available in cache. Request Ignored.");
                    return;
                }
                e.b(activity);
                b<String> bVar = new b<String>() { // from class: com.ozoka.zsofp129035.MA.7
                    @Override // com.ozoka.zsofp129035.b
                    /* renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onTaskComplete(String str) {
                        Log.i("BunSDK", "SmartWall JSON: " + str);
                        if (str != null) {
                            try {
                                if (str.contains("<VAST") && Build.VERSION.SDK_INT > 7) {
                                    if (MA.enableCaching) {
                                        new s(MA.activity).a(str, true);
                                        return;
                                    } else {
                                        MA.this.parseSmartwallJson(str);
                                        return;
                                    }
                                }
                                JSONObject jSONObject = new JSONObject(str);
                                int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                String string = jSONObject.isNull("message") ? "" : jSONObject.getString("message");
                                String string2 = jSONObject.isNull("adtype") ? "" : jSONObject.getString("adtype");
                                if (i == 200 && string.equalsIgnoreCase("Success") && !string2.equals("")) {
                                    if (MA.enableCaching) {
                                        MA.cA.a(AdListener.AdType.smartwall, str);
                                        q.sendAdCached(AdListener.AdType.smartwall);
                                        MA.cA.a(true);
                                        return;
                                    }
                                    MA.this.parseSmartwallJson(str);
                                    return;
                                }
                                MA.validateStatusCode(i, string);
                            } catch (Exception e) {
                                Log.e("BunSDK", "Error: ", e);
                            }
                        }
                    }

                    @Override // com.ozoka.zsofp129035.b
                    public void launchNewHttpTask() {
                        try {
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(new BasicNameValuePair("banner_type", "rich_media"));
                            arrayList.add(new BasicNameValuePair("supports", "" + Util.v(MA.activity)));
                            arrayList.add(new BasicNameValuePair("placement_type", "fullpage"));
                            arrayList.add(new BasicNameValuePair("cache", MA.cache));
                            new Thread(new n(MA.activity, this, arrayList, i.URL_INTERSTITIAL, 0L, true), "SmartWall").start();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                };
                if (Util.r(activity)) {
                    bVar.launchNewHttpTask();
                }
            }
        } catch (Exception e) {
            Log.e("BunSDK", "Error occurred in startSmartWall method: ", e);
        }
    }

    void parseSmartwallJson(String result) {
        try {
            if (result.contains("<VAST") && Build.VERSION.SDK_INT > 7) {
                new s(activity).a(result, true);
                return;
            }
            JSONObject jSONObject = new JSONObject(result);
            int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
            String string = jSONObject.isNull("message") ? "" : jSONObject.getString("message");
            String string2 = jSONObject.isNull("adtype") ? "" : jSONObject.getString("adtype");
            if (i == 200 && !string2.equals("")) {
                if (string2.equalsIgnoreCase(i.AD_TYPE_AW)) {
                    parseAppWallJson(result);
                    return;
                }
                if (string2.equals("OLAU") || string2.equals(i.AD_TYPE_DAU) || string2.equals(i.AD_TYPE_DCC) || string2.equals(i.AD_TYPE_DCM)) {
                    showOverlayAd(result);
                    return;
                }
                if (!string2.equals("") && string2.equalsIgnoreCase(i.AD_TYPE_FP)) {
                    parseLandingPageAdJson(result);
                    return;
                } else if (!string2.equals("") && string2.equalsIgnoreCase(i.AD_TYPE_MFP)) {
                    parseRichMediaInterstitialJson(jSONObject);
                    return;
                } else {
                    Log.i("BunSDK", "Invalid ad type delivered in SmartWall: " + string2);
                    return;
                }
            }
            validateStatusCode(i, string);
        } catch (JSONException e) {
            Log.e("BunSDK", "Error in Smart Wall json: ", e);
        } catch (Exception e2) {
            Log.e("BunSDK", "Error in Smart Wall response: ", e2);
        }
    }

    @Override // com.ozoka.zsofp129035.h
    public void callAppWall() {
        try {
            if (!isDialogClosed && isShowOptinDialog) {
                SharedPreferences.Editor edit = activity.getSharedPreferences(i.ENABLE_AD_PREF, 0).edit();
                edit.putBoolean(i.APP_WALL_AD, true);
                edit.commit();
                return;
            }
            Log.i("BunSDK", "Initialising AppWall.....");
            if (!isIntegrationIssue && checkSmartWallActivity()) {
                if (activity == null || !isSDKEnabled(activity)) {
                    Log.i("BunSDK", "MA is disabled Please enable to recive ads.");
                    sendAdError("MA is disabled Please enable to recive ads.");
                    return;
                }
                if (e.c(activity) > System.currentTimeMillis()) {
                    Log.i("BunSDK", "AppWall called within 10 secs. Ignoring request");
                    sendAdError("AppWall called within 10 secs. Ignoring request.");
                    return;
                }
                if (AdActivity.a()) {
                    Log.i("BunSDK", "Another ad is showing on screen.");
                    sendAdError("Another ad is showing on screen.");
                    return;
                }
                if (cA == null) {
                    cA = new c(activity);
                }
                if (cA.e(AdListener.AdType.appwall)) {
                    Log.i("BunSDK", "AppWall Ad already available in cache. Request ignored.");
                    sendAdError("AppWall Ad already available in cache. Request Ignored.");
                    return;
                }
                e.b(activity);
                b<String> bVar = new b<String>() { // from class: com.ozoka.zsofp129035.MA.8
                    @Override // com.ozoka.zsofp129035.b
                    /* renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onTaskComplete(String str) {
                        Log.i("BunSDK", "AppWall Json: " + str);
                        if (str != null) {
                            try {
                                if (MA.enableCaching) {
                                    JSONObject jSONObject = new JSONObject(str);
                                    int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                    String string = jSONObject.isNull("message") ? i.INVALID : jSONObject.getString("message");
                                    if (i == 200 && string.equalsIgnoreCase("Success")) {
                                        MA.cA.a(AdListener.AdType.appwall, str);
                                        q.sendAdCached(AdListener.AdType.appwall);
                                        return;
                                    } else {
                                        MA.validateStatusCode(i, string);
                                        return;
                                    }
                                }
                                MA.this.parseAppWallJson(str);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override // com.ozoka.zsofp129035.b
                    public void launchNewHttpTask() {
                        try {
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(new BasicNameValuePair("cache", MA.cache));
                            new Thread(new n(MA.activity, this, arrayList, i.URL_APP_WALL, 0L, true), "AppWall").start();
                        } catch (NullPointerException e) {
                            e.printStackTrace();
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    }
                };
                if (Util.r(activity)) {
                    bVar.launchNewHttpTask();
                }
            }
        } catch (Exception e) {
            Log.e("BunSDK", "Error occurred in appwall ", e);
        }
    }

    @Override // com.ozoka.zsofp129035.q
    void parseAppWallJson(String json) {
        try {
            JSONObject jSONObject = new JSONObject(json);
            int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
            String string = jSONObject.isNull("message") ? "" : jSONObject.getString("message");
            if (i == 200 && string.equals("Success")) {
                String string2 = jSONObject.getString(PlusShare.KEY_CALL_TO_ACTION_URL);
                if (string2 != null && !string2.equals("")) {
                    e.b(activity);
                    Intent intent = new Intent(activity, (Class<?>) AdActivity.class);
                    intent.setFlags(268435456);
                    intent.addFlags(536870912);
                    intent.addFlags(8388608);
                    intent.setAction("appwallad");
                    intent.putExtra("adtype", i.AD_TYPE_AW);
                    intent.putExtra(PlusShare.KEY_CALL_TO_ACTION_URL, string2);
                    try {
                        activity.startActivity(intent);
                        return;
                    } catch (ActivityNotFoundException e) {
                        Log.e("BunSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                        return;
                    }
                }
                return;
            }
            validateStatusCode(i, string);
        } catch (JSONException e2) {
            Log.e("BunSDK", "Error in AppWall json: ", e2);
        } catch (Exception e3) {
            Log.e("BunSDK", "Error in AppWall response: ", e3);
        }
    }

    @Override // com.ozoka.zsofp129035.h
    public void callLandingPageAd() {
        try {
            if (!isDialogClosed && isShowOptinDialog) {
                SharedPreferences.Editor edit = activity.getSharedPreferences(i.ENABLE_AD_PREF, 0).edit();
                edit.putBoolean(i.LANDING_PAGE_AD, true);
                edit.commit();
                return;
            }
            Log.i("BunSDK", "Initialising LandingPage AD.....");
            if (!isIntegrationIssue && checkSmartWallActivity()) {
                if (activity == null || !isSDKEnabled(activity)) {
                    Log.i("BunSDK", "MA is disabled Please enable to recive ads.");
                    sendAdError("MA is disabled Please enable to recive ads.");
                    return;
                }
                if (e.c(activity) > System.currentTimeMillis()) {
                    Log.i("BunSDK", "LandingPage Ad called within 10 secs. Ignoring request");
                    sendAdError("LandingPage Ad called within 10 secs. Ignoring request");
                    return;
                }
                if (AdActivity.a()) {
                    Log.i("BunSDK", "Another ad is showing on screen.");
                    sendAdError("Another ad is showing on screen.");
                    return;
                }
                if (cA == null) {
                    cA = new c(activity);
                }
                if (cA.e(AdListener.AdType.landing_page)) {
                    Log.i("BunSDK", "LandingPage Ad already available in cache. Request ignored.");
                    sendAdError("LandingPage Ad already available in cache. Request Ignored.");
                    return;
                }
                e.b(activity);
                b<String> bVar = new b<String>() { // from class: com.ozoka.zsofp129035.MA.9
                    @Override // com.ozoka.zsofp129035.b
                    /* renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onTaskComplete(String str) {
                        Log.i("BunSDK", "LandingPage Json: " + str);
                        if (str != null) {
                            try {
                                if (MA.enableCaching) {
                                    JSONObject jSONObject = new JSONObject(str);
                                    int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                    String string = jSONObject.isNull("message") ? i.INVALID : jSONObject.getString("message");
                                    if (i == 200 && string.equalsIgnoreCase("Success")) {
                                        MA.cA.a(AdListener.AdType.landing_page, str);
                                        q.sendAdCached(AdListener.AdType.landing_page);
                                        return;
                                    } else {
                                        MA.validateStatusCode(i, string);
                                        return;
                                    }
                                }
                                MA.this.parseLandingPageAdJson(str);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override // com.ozoka.zsofp129035.b
                    public void launchNewHttpTask() {
                        try {
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(new BasicNameValuePair("cache", MA.cache));
                            new Thread(new n(MA.activity, this, arrayList, i.URL_FULL_PAGE, 0L, true), "LP").start();
                        } catch (Exception e) {
                        }
                    }
                };
                if (Util.r(activity)) {
                    bVar.launchNewHttpTask();
                }
            }
        } catch (Exception e) {
            Log.e("BunSDK", "Error occurred in LandingPage ad: ", e);
        }
    }

    @Override // com.ozoka.zsofp129035.q
    void parseLandingPageAdJson(String json) {
        String string;
        String string2;
        if (json != null) {
            try {
                try {
                    JSONObject jSONObject = new JSONObject(json);
                    int i = jSONObject.isNull("status") ? 200 : jSONObject.getInt("status");
                    if (jSONObject.isNull("message")) {
                        string = i.INVALID;
                    } else {
                        string = jSONObject.getString("message");
                    }
                    if (i == 200 && string.equals("Success")) {
                        if (jSONObject.isNull(PlusShare.KEY_CALL_TO_ACTION_URL)) {
                            string2 = i.INVALID;
                        } else {
                            string2 = jSONObject.getString(PlusShare.KEY_CALL_TO_ACTION_URL);
                        }
                        if (!string2.equals(i.INVALID)) {
                            e.b(activity);
                            Intent intent = new Intent(activity, (Class<?>) AdActivity.class);
                            intent.setAction("lpad");
                            intent.setFlags(268435456);
                            intent.addFlags(536870912);
                            intent.addFlags(8388608);
                            intent.putExtra("adtype", i.AD_TYPE_FP);
                            intent.putExtra(PlusShare.KEY_CALL_TO_ACTION_URL, string2);
                            try {
                                activity.startActivity(intent);
                                return;
                            } catch (ActivityNotFoundException e) {
                                Log.e("BunSDK", "Required SmartWallActivity not found in Manifest. Please add.");
                                return;
                            } catch (Exception e2) {
                                return;
                            }
                        }
                        return;
                    }
                    validateStatusCode(i, string);
                } catch (JSONException e3) {
                    Log.e("BunSDK", "Error in LandingPage json: ", e3);
                }
            } catch (Exception e4) {
                Log.e("BunSDK", "Error in LandingPage response: ", e4);
            }
        }
    }

    @Override // com.ozoka.zsofp129035.h
    public void displayRichMediaInterstitialAd() {
        try {
            if (!isDialogClosed && isShowOptinDialog) {
                SharedPreferences.Editor edit = activity.getSharedPreferences(i.ENABLE_AD_PREF, 0).edit();
                edit.putBoolean("rich_media", true);
                edit.commit();
                return;
            }
            Log.i("BunSDK", "Initialising Rich Media Interstitial Ad.....");
            if (!isIntegrationIssue && checkSmartWallintegration()) {
                if (activity == null || !isSDKEnabled(activity)) {
                    Log.i("BunSDK", "MA is disabled Please enable to recive ads.");
                    sendAdError("MA is disabled Please enable to recive ads.");
                    return;
                }
                if (e.c(activity) > System.currentTimeMillis()) {
                    Log.i("BunSDK", "Rich Media Interstitial Ad called within 10 secs. Ignoring request");
                    sendAdError("Rich Media Interstitial Ad called within 10 secs. Ignoring request");
                    return;
                }
                if (AdActivity.a()) {
                    Log.i("BunSDK", "Another ad is showing on screen.");
                    sendAdError("Another ad is showing on screen.");
                    return;
                }
                if (cA == null) {
                    cA = new c(activity);
                }
                if (cA.e(AdListener.AdType.interstitial)) {
                    Log.i("BunSDK", "Rich media interstitial Ad already available in cache. Request ignored.");
                    sendAdError("Rich media interstitial Ad already available in cache. Request Ignored.");
                    return;
                }
                e.b(activity);
                b<String> bVar = new b<String>() { // from class: com.ozoka.zsofp129035.MA.10
                    @Override // com.ozoka.zsofp129035.b
                    /* renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onTaskComplete(String str) {
                        Log.i("BunSDK", "Rich Media Ad Json: " + str);
                        if (str != null) {
                            try {
                                JSONObject jSONObject = new JSONObject(str);
                                int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                String string = jSONObject.isNull("message") ? i.INVALID : jSONObject.getString("message");
                                String string2 = jSONObject.isNull("adtype") ? null : jSONObject.getString("adtype");
                                if (i == 200 && string.equalsIgnoreCase("Success")) {
                                    if (string2 == null || !string2.equals(i.AD_TYPE_MFP)) {
                                        Log.w("BunSDK", "Invalid adtype: " + string2);
                                        return;
                                    } else if (MA.enableCaching) {
                                        MA.cA.a(AdListener.AdType.interstitial, str);
                                        q.sendAdCached(AdListener.AdType.interstitial);
                                        return;
                                    } else {
                                        MA.this.parseRichMediaInterstitialJson(jSONObject);
                                        return;
                                    }
                                }
                                MA.validateStatusCode(i, string);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override // com.ozoka.zsofp129035.b
                    public void launchNewHttpTask() {
                        try {
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(new BasicNameValuePair("banner_type", "rich_media"));
                            arrayList.add(new BasicNameValuePair("supports", "" + Util.v(MA.activity)));
                            arrayList.add(new BasicNameValuePair("placement_type", "fullpage"));
                            arrayList.add(new BasicNameValuePair("cache", MA.cache));
                            new Thread(new n(MA.activity, this, arrayList, i.URL_MRAID_API, 0L, true), "AdView").start();
                        } catch (Exception e) {
                        }
                    }
                };
                if (Util.r(activity)) {
                    bVar.launchNewHttpTask();
                }
            }
        } catch (Exception e) {
            Log.e("BunSDK", "Error occurred in Rich Media interstital ad: ", e);
        }
    }

    @Override // com.ozoka.zsofp129035.q
    void parseRichMediaInterstitialJson(JSONObject jsonObject) {
        try {
            parseMraidJson = new JP.ParseMraidJson(activity, jsonObject);
            String u = Util.u(activity);
            if (u != null && !u.equals("")) {
                e.b(activity);
                Intent intent = new Intent(activity, (Class<?>) AdActivity.class);
                intent.setAction("mfpad");
                intent.setFlags(268435456);
                intent.addFlags(8388608);
                intent.addFlags(536870912);
                intent.putExtra("adtype", i.AD_TYPE_MFP);
                activity.startActivity(intent);
            } else {
                b<Boolean> bVar = new b<Boolean>() { // from class: com.ozoka.zsofp129035.MA.11
                    @Override // com.ozoka.zsofp129035.b
                    /* renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onTaskComplete(Boolean bool) {
                        if (bool.booleanValue()) {
                            e.b(MA.activity);
                            Intent intent2 = new Intent(MA.activity, (Class<?>) AdActivity.class);
                            intent2.setAction("mfpad");
                            intent2.setFlags(268435456);
                            intent2.addFlags(8388608);
                            intent2.addFlags(536870912);
                            intent2.putExtra("adtype", i.AD_TYPE_MFP);
                            MA.activity.startActivity(intent2);
                            return;
                        }
                        Log.e("BunSDK", "Not able to get doc.");
                    }

                    @Override // com.ozoka.zsofp129035.b
                    public void launchNewHttpTask() {
                        new Thread(new Util.NativeMraid(MA.activity, this), "native").start();
                    }
                };
                if (Util.r(activity)) {
                    bVar.launchNewHttpTask();
                }
            }
        } catch (IOException e) {
            Log.i("BunSDK", "Rich Media Full Page: " + e.getMessage());
        } catch (JSONException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static final void validateStatusCode(int status, String message) {
        if (message != null && !message.equals("")) {
            switch (status) {
                case LocationRequest.PRIORITY_HIGH_ACCURACY /* 100 */:
                    sendIntegrationError(message);
                    return;
                case 120:
                    sendIntegrationError(message);
                    return;
                case 130:
                    sendIntegrationError(message);
                    return;
                case 150:
                    sendNoAdMessage();
                    return;
                case 204:
                    sendNoAdMessage();
                    return;
                default:
                    return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean checkRequiredDetails(Context mContext) {
        boolean z = true;
        if (mContext == null) {
            try {
                Log.e("BunSDK", "Context is null.");
                sendIntegrationError("Context is null");
                z = false;
            } catch (Exception e) {
                Log.e("BunSDK", "Error occurred while checking required details: ", e);
                return false;
            }
        }
        if (!getDataFromManifest(mContext)) {
            z = false;
        }
        if (!checkRequiredPermission(mContext)) {
            z = false;
        }
        if (!new r(mContext).b()) {
            z = false;
        }
        new e(mContext).a();
        if (!Util.b(mContext, (Class<?>) LService.class)) {
            Log.e("BunSDK", "Required LService not found in Manifest. Please add");
            z = false;
        }
        if (isBootReceiverDeclared(mContext)) {
            return z;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isBootReceiverDeclared(Context mContext) {
        try {
            if (mContext.getPackageManager().queryBroadcastReceivers(new Intent(mContext, (Class<?>) BootReceiver.class), 0).size() == 0) {
                Log.i("BunSDK", "BootReceiver is not declared in Manifest. Please add.");
                sendIntegrationError("BootReceiver is not declared in Manifest. Please add.");
                return false;
            }
        } catch (Exception e) {
            Util.a("Error occurred in isBootReceiverDeclared", e);
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean checkSmartWallintegration() {
        try {
            boolean checkSmartWallActivity = checkSmartWallActivity();
            if (Util.a(activity, (Class<?>) BrowserActivity.class)) {
                return checkSmartWallActivity;
            }
            Log.e("BunSDK", "Required BrowserActivity not found in Manifest. Please add.");
            sendIntegrationError("Required BrowserActivity not found in Manifest. Please add.");
            new p(activity, LocationRequest.PRIORITY_LOW_POWER);
            return false;
        } catch (Exception e) {
            Log.e("BunSDK", "Error occurred while validating SmartWall: ", e);
            return false;
        }
    }

    private boolean checkSmartWallActivity() throws NullPointerException, Exception {
        if (Util.a(activity, (Class<?>) AdActivity.class)) {
            return true;
        }
        Log.e("BunSDK", "Required AdActivity not found in Manifest. Please add.");
        sendIntegrationError("Required AdActivity not found in Manifest. Please add.");
        new p(activity, 103);
        return false;
    }

    @Override // com.ozoka.zsofp129035.h
    public void callVideoAd() {
        try {
            if (Build.VERSION.SDK_INT < 8) {
                Log.e("BunSDK", "Video ad supported on Android 2.2 and later devices.");
                sendAdError("Video ad supported on Android 2.2 and later devices.");
                return;
            }
            if (!isDialogClosed && isShowOptinDialog) {
                SharedPreferences.Editor edit = activity.getSharedPreferences(i.ENABLE_AD_PREF, 0).edit();
                edit.putBoolean(i.VIDEO_AD, true);
                edit.commit();
                return;
            }
            Log.i("BunSDK", "Initialising video ad.....");
            if (!isIntegrationIssue && s.a(activity)) {
                if (!Util.a(activity, (Class<?>) VActivity.class)) {
                    Log.e("BunSDK", "Required VActivity not found in Manifest. Please add");
                    sendIntegrationError("Required VActivity not found in Manifest. Please add");
                    new p(activity, LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
                    return;
                }
                if (isSDKEnabled(activity)) {
                    String externalStorageState = Environment.getExternalStorageState();
                    if (externalStorageState != null && externalStorageState.equalsIgnoreCase("mounted")) {
                        if (AdActivity.a()) {
                            Log.w("BunSDK", "Another ad is already showing on screen.");
                            sendAdError("Another ad is already showing on screen.");
                            return;
                        }
                        if (System.currentTimeMillis() < e.e(activity)) {
                            Log.w("BunSDK", "Video ad is called before 30 secs. Ignoring request.");
                            sendAdError("Video ad is called before 30 secs. Ignoring request.");
                            return;
                        }
                        if (cA == null) {
                            cA = new c(activity);
                        }
                        if (cA.e(AdListener.AdType.video)) {
                            Log.i("BunSDK", "Video Ad already available in cache. Request ignored.");
                            sendAdError("Video Ad already available in cache. Request Ignored.");
                            return;
                        } else {
                            s sVar = new s(activity);
                            if (Util.r(activity)) {
                                sVar.launchNewHttpTask();
                                return;
                            }
                            return;
                        }
                    }
                    Log.w("BunSDK", "Can't call video ad at this time. SD card not mounted.");
                    sendAdError("Can't call video ad at this time. SD card not mounted.");
                    return;
                }
                Log.e("BunSDK", "MA is disabled please enable to receive ads.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // com.ozoka.zsofp129035.h
    public void callOverlayAd() {
        try {
            if (!isDialogClosed && isShowOptinDialog) {
                SharedPreferences.Editor edit = activity.getSharedPreferences(i.ENABLE_AD_PREF, 0).edit();
                edit.putBoolean(i.OVERLAY_AD, true);
                edit.commit();
                return;
            }
            Log.i("BunSDK", "Initialising Overlay AD.....");
            if (!isIntegrationIssue && checkSmartWallActivity()) {
                if (!isSDKEnabled(activity)) {
                    Log.i("BunSDK", "MA SDK is disabled Please enable to recive ads.");
                    sendAdError("MA SDK is disabled Please enable to recive ads.");
                    return;
                }
                if (e.c(activity) > System.currentTimeMillis()) {
                    Log.i("BunSDK", "Overlay Ad called within 10 secs. Ignoring request");
                    sendAdError("Overlay Ad called within 10 secs. Ignoring request");
                    return;
                }
                if (AdActivity.a()) {
                    Log.i("BunSDK", "Another ad is showing on screen.");
                    sendAdError("Another ad is showing on screen.");
                    return;
                }
                if (cA == null) {
                    cA = new c(activity);
                }
                if (cA.e(AdListener.AdType.overlay)) {
                    Log.i("BunSDK", "Overlay Ad already available in cache. Request ignored.");
                    sendAdError("Overlay Ad already available in cache. Request Ignored.");
                    return;
                }
                e.b(activity);
                b<String> bVar = new b<String>() { // from class: com.ozoka.zsofp129035.MA.12
                    @Override // com.ozoka.zsofp129035.b
                    /* renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onTaskComplete(String str) {
                        Log.i("BunSDK", "Overlay Json: " + str);
                        if (str != null) {
                            try {
                                if (!MA.enableCaching) {
                                    MA.this.showOverlayAd(str);
                                    return;
                                }
                                JSONObject jSONObject = new JSONObject(str);
                                int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                String string = jSONObject.isNull("message") ? i.INVALID : jSONObject.getString("message");
                                if (i == 200 && string.equalsIgnoreCase("Success")) {
                                    MA.cA.a(AdListener.AdType.overlay, str);
                                    q.sendAdCached(AdListener.AdType.overlay);
                                } else {
                                    MA.validateStatusCode(i, string);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override // com.ozoka.zsofp129035.b
                    public void launchNewHttpTask() {
                        try {
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(new BasicNameValuePair("cache", MA.cache));
                            new Thread(new n(MA.activity, this, arrayList, i.OVERLAY_AD_URL, 0L, true), "overlay").start();
                        } catch (Exception e) {
                            Log.e("BunSDK", "Error occurred in while requesting: ", e);
                        }
                    }
                };
                if (Util.r(activity)) {
                    bVar.launchNewHttpTask();
                }
            }
        } catch (Exception e) {
            Log.e("BunSDK", "Error occurred in Overlay ad: ", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showOverlayAd(String result) {
        try {
            JSONObject jSONObject = new JSONObject(result);
            int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
            String string = jSONObject.isNull("message") ? i.INVALID : jSONObject.getString("message");
            final String string2 = jSONObject.isNull("adtype") ? "" : jSONObject.getString("adtype");
            boolean z = jSONObject.isNull(IM.EVENT_ERROR) ? false : jSONObject.getBoolean(IM.EVENT_ERROR);
            if (i == 200 && string.equalsIgnoreCase("Success")) {
                String string3 = jSONObject.isNull("data") ? "nodata" : jSONObject.getString("data");
                if (!string3.equals("nodata")) {
                    JSONObject jSONObject2 = new JSONObject(string3);
                    String string4 = jSONObject2.getString("tag");
                    int i2 = jSONObject2.getInt("height");
                    int i3 = jSONObject2.getInt("width");
                    String string5 = jSONObject2.getString("api_url");
                    o.d(string2);
                    o.c(string5);
                    o.a(z);
                    o.b(i3);
                    o.a(i2);
                    o.b(string4);
                    if (string2.equals("OLAU") || string2.equals(i.AD_TYPE_DAU) || string2.equals(i.AD_TYPE_DCC) || string2.equals(i.AD_TYPE_DCM)) {
                        new Thread(new Runnable() { // from class: com.ozoka.zsofp129035.MA.2
                            @Override // java.lang.Runnable
                            public void run() {
                                Intent intent = new Intent(MA.activity, (Class<?>) AdActivity.class);
                                intent.setFlags(268435456);
                                intent.addFlags(8388608);
                                intent.setAction("overlayad");
                                intent.putExtra("adtype", string2);
                                MA.activity.startActivity(intent);
                            }
                        }, "overlay_showing").start();
                        return;
                    } else {
                        Log.w("BunSDK", "Invalid adtype delivered in overylay ad " + string2);
                        return;
                    }
                }
                return;
            }
            validateStatusCode(i, string);
        } catch (Exception e) {
            Log.e("BunSDK", "Error occurred in overlay ad", e);
        }
    }

    @Override // com.ozoka.zsofp129035.h
    public void showCachedAd(Activity activity2, AdListener.AdType adType) throws Exception {
        try {
            if (!isDialogClosed) {
                throw new IllegalStateException("EULA is showing on screen.");
            }
            if (activity2 == null || adType == null) {
                Log.e("BunSDK", "Activity or Adtype is null.");
                throw new IllegalStateException("Activity or Adtype is null.");
            }
            activity = activity2;
            if (!isSDKEnabled(activity2)) {
                throw new IllegalStateException("MA SDK is disabled can not show ad.");
            }
            if (AdActivity.a()) {
                throw new IllegalStateException("Another ad is showing on screen.");
            }
            if (!Util.r(activity2)) {
                throw new IllegalStateException("Internet connection not available.");
            }
            if (cA == null) {
                cA = new c(activity2);
            }
            switch (adType) {
                case smartwall:
                    String a = cA.a(AdListener.AdType.smartwall);
                    if (a != null && !a.equals("")) {
                        if (a.contains("<VAST") && Build.VERSION.SDK_INT > 7) {
                            String[] b = cA.b(AdListener.AdType.video);
                            String str = b[0];
                            String str2 = b[1];
                            if (str != null && !str.equals("") && str2 != null && !str2.equals("")) {
                                new s(activity2).a(str, str2);
                                return;
                            } else {
                                Log.e("BunSDK", "SmartWall video was not cached");
                                cA.c(adType);
                                throw new IOException("SmartWall ad is not available in cache");
                            }
                        }
                        parseSmartwallJson(a);
                        return;
                    }
                    cA.c(adType);
                    throw new IOException("SmartWall ad is not available in cache");
                case appwall:
                    String a2 = cA.a(AdListener.AdType.appwall);
                    if (a2 != null && !a2.equals("")) {
                        parseAppWallJson(a2);
                        return;
                    } else {
                        cA.c(adType);
                        throw new IOException("Appwall ad is not available in cache");
                    }
                case landing_page:
                    String a3 = cA.a(AdListener.AdType.landing_page);
                    if (a3 != null && !a3.equals("")) {
                        parseLandingPageAdJson(a3);
                        return;
                    } else {
                        cA.c(adType);
                        throw new IOException("Landingpage ad is not available in cache");
                    }
                case interstitial:
                    String a4 = cA.a(AdListener.AdType.interstitial);
                    if (a4 != null && !a4.equals("")) {
                        parseRichMediaInterstitialJson(new JSONObject(a4));
                        return;
                    } else {
                        cA.c(adType);
                        throw new IOException("Interstitial ad is not available in cache");
                    }
                case video:
                    String[] b2 = cA.b(AdListener.AdType.video);
                    String str3 = b2[0];
                    String str4 = b2[1];
                    if (str3 != null && !str3.equals("") && str4 != null && !str4.equals("")) {
                        new s(activity2).a(str3, str4);
                        return;
                    } else {
                        cA.c(adType);
                        throw new IOException("Video ad is not available in cache");
                    }
                case overlay:
                    String a5 = cA.a(AdListener.AdType.overlay);
                    if (a5 != null && !a5.equals("")) {
                        showOverlayAd(a5);
                        return;
                    } else {
                        cA.c(adType);
                        throw new IOException("Overlay ad is not available in cache");
                    }
                default:
                    throw new IOException("Invalid AdType.");
            }
        } catch (Exception e) {
            Log.e("BunSDK", "Error occurred while showing Cache ad: " + e.getMessage());
            throw new Exception(e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void startNewAdThread() {
        try {
            handler.postDelayed(new Runnable() { // from class: com.ozoka.zsofp129035.MA.3
                @Override // java.lang.Runnable
                public void run() {
                    e.a(MA.activity);
                }
            }, 3000L);
        } catch (Exception e) {
            e.a(activity);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static AdListener.OptinListener getOptinListener() {
        return optinListener;
    }

    public static void setOptinListener(AdListener.OptinListener optinListener2) {
        optinListener = optinListener2;
    }
}
