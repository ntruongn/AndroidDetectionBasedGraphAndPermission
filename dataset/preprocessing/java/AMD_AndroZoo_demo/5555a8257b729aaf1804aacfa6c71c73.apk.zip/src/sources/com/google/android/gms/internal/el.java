package com.google.android.gms.internal;

import com.google.android.gms.games.multiplayer.realtime.RealTimeMessage;
import com.google.android.gms.internal.eq;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public abstract class el extends eq.a {
    @Override // com.google.android.gms.internal.eq
    public void M(int i) {
    }

    @Override // com.google.android.gms.internal.eq
    public void N(int i) {
    }

    @Override // com.google.android.gms.internal.eq
    public void O(int i) {
    }

    @Override // com.google.android.gms.internal.eq
    public void P(int i) {
    }

    @Override // com.google.android.gms.internal.eq
    public void a(int i, int i2, String str) {
    }

    @Override // com.google.android.gms.internal.eq
    public void a(int i, String str, boolean z) {
    }

    @Override // com.google.android.gms.internal.eq
    public void a(com.google.android.gms.common.data.d dVar, com.google.android.gms.common.data.d dVar2) {
    }

    @Override // com.google.android.gms.internal.eq
    public void a(com.google.android.gms.common.data.d dVar, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.eq
    public void b(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void b(com.google.android.gms.common.data.d dVar, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.eq
    public void c(int i, String str) {
    }

    @Override // com.google.android.gms.internal.eq
    public void c(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void c(com.google.android.gms.common.data.d dVar, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.eq
    public void d(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void d(com.google.android.gms.common.data.d dVar, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.eq
    public void e(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void e(com.google.android.gms.common.data.d dVar, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.eq
    public void f(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void f(com.google.android.gms.common.data.d dVar, String[] strArr) {
    }

    @Override // com.google.android.gms.internal.eq
    public void g(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void h(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void i(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void j(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void k(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void l(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void m(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void n(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void o(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void onAchievementUpdated(int statusCode, String achievementId) {
    }

    @Override // com.google.android.gms.internal.eq
    public void onLeftRoom(int statusCode, String roomId) {
    }

    @Override // com.google.android.gms.internal.eq
    public void onP2PConnected(String participantId) {
    }

    @Override // com.google.android.gms.internal.eq
    public void onP2PDisconnected(String participantId) {
    }

    @Override // com.google.android.gms.internal.eq
    public void onRealTimeMessageReceived(RealTimeMessage message) {
    }

    @Override // com.google.android.gms.internal.eq
    public void onSignOutComplete() {
    }

    @Override // com.google.android.gms.internal.eq
    public void p(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void q(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void r(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void s(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void t(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void u(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void v(com.google.android.gms.common.data.d dVar) {
    }

    @Override // com.google.android.gms.internal.eq
    public void w(com.google.android.gms.common.data.d dVar) {
    }
}
