package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.bu;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class bp {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
    public interface a {
        void a(ce ceVar);
    }

    public static cg a(Context context, bu.a aVar, h hVar, cq cqVar, aw awVar, a aVar2) {
        bq bqVar = new bq(context, aVar, hVar, cqVar, awVar, aVar2);
        bqVar.start();
        return bqVar;
    }
}
