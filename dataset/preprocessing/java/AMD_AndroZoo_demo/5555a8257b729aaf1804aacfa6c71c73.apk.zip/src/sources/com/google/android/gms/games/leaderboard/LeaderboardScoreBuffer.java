package com.google.android.gms.games.leaderboard;

import com.google.android.gms.common.data.DataBuffer;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class LeaderboardScoreBuffer extends DataBuffer<LeaderboardScore> {
    private final b nv;

    public LeaderboardScoreBuffer(com.google.android.gms.common.data.d dataHolder) {
        super(dataHolder);
        this.nv = new b(dataHolder.aM());
    }

    public b cb() {
        return this.nv;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.google.android.gms.common.data.DataBuffer
    public LeaderboardScore get(int position) {
        return new d(this.jf, position);
    }
}
