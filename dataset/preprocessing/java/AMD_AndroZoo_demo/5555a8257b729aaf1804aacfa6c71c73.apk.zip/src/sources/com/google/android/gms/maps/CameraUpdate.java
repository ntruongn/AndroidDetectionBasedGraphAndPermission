package com.google.android.gms.maps;

import com.google.android.gms.dynamic.b;
import com.google.android.gms.internal.dm;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class CameraUpdate {
    private final b pd;

    /* JADX INFO: Access modifiers changed from: package-private */
    public CameraUpdate(b remoteObject) {
        this.pd = (b) dm.e(remoteObject);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public b cs() {
        return this.pd;
    }
}
