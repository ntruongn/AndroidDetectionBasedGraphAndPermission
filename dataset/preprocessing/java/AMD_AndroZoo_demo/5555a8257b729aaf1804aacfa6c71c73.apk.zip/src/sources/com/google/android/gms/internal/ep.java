package com.google.android.gms.internal;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class ep {
    private static final dh no = new dh("Games");

    public static void a(String str, String str2, Throwable th) {
        no.a(str, str2, th);
    }

    public static void b(String str, String str2) {
        no.b(str, str2);
    }

    public static void c(String str, String str2) {
        no.c(str, str2);
    }

    public static void d(String str, String str2) {
        no.d(str, str2);
    }

    public static void e(String str, String str2) {
        no.e(str, str2);
    }
}
