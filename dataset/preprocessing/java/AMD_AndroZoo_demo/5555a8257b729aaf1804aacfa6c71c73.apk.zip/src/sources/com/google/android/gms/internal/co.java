package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class co implements SafeParcelable {
    public static final cp CREATOR = new cp();
    public String hP;
    public int hQ;
    public int hR;
    public boolean hS;
    public final int versionCode;

    public co(int i, int i2, boolean z) {
        this(1, "afma-sdk-a-v" + i + "." + i2 + "." + (z ? "0" : "1"), i, i2, z);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public co(int i, String str, int i2, int i3, boolean z) {
        this.versionCode = i;
        this.hP = str;
        this.hQ = i2;
        this.hR = i3;
        this.hS = z;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int flags) {
        cp.a(this, out, flags);
    }
}
