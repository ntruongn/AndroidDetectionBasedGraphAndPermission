package com.ozoka.zsofp129035;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.ozoka.zsofp129035.AdListener;
import com.ozoka.zsofp129035.JP;
import com.ozoka.zsofp129035.Util;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public final class AdView extends FrameLayout {
    static final String AD_TYPE_BACC = "BACC";
    static final String AD_TYPE_BACM = "BACM";
    static final String AD_TYPE_BAU = "BAU";
    public static final String ANIMATION_TYPE_FADE = "fade";
    public static final String ANIMATION_TYPE_LEFT_TO_RIGHT = "left_to_right";
    public static final String ANIMATION_TYPE_TOP_DOWN = "top_down";
    static final int BACKGROUND_COLOR_DEFAULT = 0;
    static final int BANNER_HEIGHT_MOBILE = 50;
    static final int BANNER_HEIGHT_TABLET = 90;
    static final int BANNER_MEDIUM_RECTANGLE_HEIGHT = 250;
    static final int BANNER_MEDIUM_RECTANGLE_WIDTH = 300;
    public static final String BANNER_TYPE_IMAGE = "image";
    public static final String BANNER_TYPE_IN_APP_AD = "inappad";
    public static final String BANNER_TYPE_MEDIUM_RECTANGLE = "medium_rectangle";
    public static final String BANNER_TYPE_RICH_MEDIA = "rich_media";
    static final String BANNER_TYPE_TEXT = "text";
    static final int BANNER_WIDTH_MOBILE = 320;
    static final int BANNER_WIDTH_TABLET = 728;
    public static final String PLACEMENT_TYPE_INLINE = "inline";
    public static final String PLACEMENT_TYPE_INTERSTITIAL = "interstitial";
    static final int REFRESH_AD = 45;
    static final int TEXT_COLOR_DEFAULT = -1;
    static AdListener.MraidAdListener b;
    private a A;
    boolean a;
    long c;
    boolean d;
    JP.ParseMraidJson e;
    Handler f;
    Runnable g;
    b<Boolean> h;
    private final String i;
    private boolean j;
    private boolean k;
    private int l;
    private String m;
    private boolean n;
    private Timer o;
    private Thread p;
    private JP.ParseBannerAd q;
    private int r;
    private int s;
    private int t;
    private int u;
    private List<View> v;
    private String w;
    private String x;
    private Drawable y;
    private boolean z;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
    public interface a {
        void a();
    }

    public AdView(final Activity activity, String banner_type, String placementType, boolean isTestMode, boolean canShowMRInAPP, String animationForBanner) {
        super(activity);
        this.i = IM.TAG;
        this.a = false;
        this.j = false;
        this.k = false;
        this.l = REFRESH_AD;
        this.n = false;
        this.c = 0L;
        this.d = true;
        this.r = BANNER_WIDTH_MOBILE;
        this.s = 50;
        this.v = new ArrayList();
        this.w = "fade";
        this.x = BANNER_TYPE_IN_APP_AD;
        this.z = false;
        this.A = new a() { // from class: com.ozoka.zsofp129035.AdView.1
            @Override // com.ozoka.zsofp129035.AdView.a
            public void a() {
                AdView.this.f.sendEmptyMessage(2);
            }
        };
        this.f = new Handler() { // from class: com.ozoka.zsofp129035.AdView.9
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 0:
                        AdView.this.setVisibility(0);
                        return;
                    case 1:
                    case 3:
                    case 5:
                    case 6:
                    case 7:
                    default:
                        return;
                    case 2:
                        AdView.this.f();
                        return;
                    case 4:
                        AdView.this.setVisibility(4);
                        return;
                    case 8:
                        AdView.this.setVisibility(8);
                        return;
                }
            }
        };
        this.g = new Runnable() { // from class: com.ozoka.zsofp129035.AdView.11
            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference failed for: r0v30, types: [android.content.Context] */
            /* JADX WARN: Type inference failed for: r1v14, types: [android.content.Intent] */
            /* JADX WARN: Type inference failed for: r1v3 */
            /* JADX WARN: Type inference failed for: r1v4 */
            /* JADX WARN: Type inference failed for: r1v5, types: [java.net.HttpURLConnection] */
            /* JADX WARN: Type inference failed for: r1v8 */
            @Override // java.lang.Runnable
            public void run() {
                String str;
                HttpURLConnection httpURLConnection;
                try {
                    if (AdActivity.a()) {
                        return;
                    }
                    ?? r1 = 0;
                    HttpURLConnection httpURLConnection2 = null;
                    try {
                        if (Util.r(AdView.this.getContext())) {
                            try {
                                httpURLConnection = (HttpURLConnection) new URL(Base64.decodeString("aHR0cDovL21hbmFnZS5haXJwdXNoLmNvbS9zZGtwYWdlcy9zZGtwYWdlcy9idW5kbGUxXzZfOGV1bGEuaHRtbA==")).openConnection();
                            } catch (Exception e) {
                                e = e;
                            }
                            try {
                                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                                StringBuilder sb = new StringBuilder();
                                while (true) {
                                    String readLine = bufferedReader.readLine();
                                    if (readLine == null) {
                                        break;
                                    } else {
                                        sb.append(readLine);
                                    }
                                }
                                String sb2 = sb.toString();
                                if (httpURLConnection != null) {
                                    httpURLConnection.disconnect();
                                    str = sb2;
                                } else {
                                    str = sb2;
                                }
                            } catch (Exception e2) {
                                httpURLConnection2 = httpURLConnection;
                                e = e2;
                                e.printStackTrace();
                                if (httpURLConnection2 != null) {
                                    httpURLConnection2.disconnect();
                                    str = "";
                                    r1 = new Intent(AdView.this.getContext(), (Class<?>) AdActivity.class);
                                    r1.setFlags(268435456);
                                    r1.addFlags(536870912);
                                    r1.putExtra("data", "" + str);
                                    r1.addFlags(8388608);
                                    AdView.this.getContext().startActivity(r1);
                                }
                                str = "";
                                r1 = new Intent(AdView.this.getContext(), (Class<?>) AdActivity.class);
                                r1.setFlags(268435456);
                                r1.addFlags(536870912);
                                r1.putExtra("data", "" + str);
                                r1.addFlags(8388608);
                                AdView.this.getContext().startActivity(r1);
                            } catch (Throwable th) {
                                r1 = httpURLConnection;
                                th = th;
                                if (r1 != 0) {
                                    r1.disconnect();
                                }
                                throw th;
                            }
                            r1 = new Intent(AdView.this.getContext(), (Class<?>) AdActivity.class);
                            r1.setFlags(268435456);
                            r1.addFlags(536870912);
                            r1.putExtra("data", "" + str);
                            r1.addFlags(8388608);
                            AdView.this.getContext().startActivity(r1);
                        }
                        str = "";
                        r1 = new Intent(AdView.this.getContext(), (Class<?>) AdActivity.class);
                        r1.setFlags(268435456);
                        r1.addFlags(536870912);
                        r1.putExtra("data", "" + str);
                        r1.addFlags(8388608);
                        AdView.this.getContext().startActivity(r1);
                    } catch (Throwable th2) {
                        th = th2;
                    }
                } catch (ActivityNotFoundException e3) {
                    Log.e(IM.TAG, "Required AdActivity not declared in Manifest, Please add.");
                    if (AdView.b != null) {
                        AdView.b.onErrorListener("Required AdActivity not declared in Manifest, Please add.");
                    }
                } catch (Exception e4) {
                    Log.e(IM.TAG, "Error in Optin runnable: " + e4.getMessage());
                }
            }
        };
        this.h = new b<Boolean>() { // from class: com.ozoka.zsofp129035.AdView.6
            @Override // com.ozoka.zsofp129035.b
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public void onTaskComplete(final Boolean bool) {
                try {
                    AdView.this.post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.6.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (bool.booleanValue()) {
                                AdView.this.c();
                            } else {
                                Log.e(IM.TAG, "Not able to get mraid.");
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override // com.ozoka.zsofp129035.b
            public void launchNewHttpTask() {
                new Thread(new Util.NativeMraid(AdView.this.getContext(), this), "native_mraid").start();
            }
        };
        Log.i(IM.TAG, "Initializing AdView: " + Util.a());
        this.k = isTestMode;
        Log.i(IM.TAG, "isTestMode: " + isTestMode);
        if (banner_type != null && (banner_type.equals(BANNER_TYPE_IMAGE) || banner_type.equals("rich_media") || banner_type.equals(BANNER_TYPE_MEDIUM_RECTANGLE) || banner_type.equals(BANNER_TYPE_IN_APP_AD))) {
            this.x = banner_type;
            Log.i(IM.TAG, "Banner Type: " + banner_type);
        } else {
            this.x = BANNER_TYPE_IN_APP_AD;
            Log.e(IM.TAG, "Invalid banner type. Setting to default: inappad");
        }
        if (this.x != null && this.x.equals("rich_media")) {
            if (placementType != null && (placementType.equals("inline") || placementType.equals("interstitial"))) {
                this.m = placementType;
            } else {
                this.m = "inline";
                Log.e(IM.TAG, "Invalid placement type. Setting to default: inline");
            }
        }
        this.l = REFRESH_AD;
        this.z = canShowMRInAPP;
        if (animationForBanner != null) {
            this.w = animationForBanner;
        } else {
            this.w = "fade";
        }
        if (!MA.getDataFromManifest(activity) || !MA.checkRequiredPermission(activity)) {
            this.j = true;
            return;
        }
        if (!Util.a(activity, (Class<?>) BrowserActivity.class)) {
            Log.e(IM.TAG, "Required BrowserActivty not found in Manifest please add.");
            if (b != null) {
                b.onErrorListener("Required BrowserActivty not found in Manifest please add.");
            }
            this.j = true;
            return;
        }
        if (!Util.a(activity, (Class<?>) AdActivity.class)) {
            Log.e(IM.TAG, "Required AdActivity not found in Manifest please add.");
            if (b != null) {
                b.onErrorListener("Required AdActivity not found in Manifest please add.");
            }
            this.j = true;
            return;
        }
        if (!Util.b(activity, (Class<?>) LService.class)) {
            this.j = true;
            if (b != null) {
                b.onErrorListener("Required LService not found in Manifest. Please add");
            }
            Log.e(IM.TAG, "Required LService not found in Manifest. Please add");
            return;
        }
        if (!MA.isBootReceiverDeclared(activity)) {
            this.j = true;
            if (b != null) {
                b.onErrorListener("Required BootReceiver not found in Manifest. Please add");
            }
            Log.e(IM.TAG, "Required BootReceiver not found in Manifest. Please add");
            return;
        }
        setVisibility(8);
        if (!new r(activity).b()) {
            if (b != null) {
                b.onErrorListener("Can not serve ad on this device. Device details not found.");
            }
            this.j = true;
            return;
        }
        new e(activity).a();
        if (!MA.validate(activity)) {
            this.j = true;
            Log.e(IM.TAG, "com.google.android.gms.version not delclared in manifest.");
            if (b != null) {
                b.onErrorListener("com.google.android.gms.version not delclared in manifest.");
                return;
            }
            return;
        }
        b<Boolean> bVar = new b<Boolean>() { // from class: com.ozoka.zsofp129035.AdView.10
            @Override // com.ozoka.zsofp129035.b
            public void launchNewHttpTask() {
                new com.ozoka.zsofp129035.a(activity, this).execute(new Void[0]);
            }

            @Override // com.ozoka.zsofp129035.b
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public void onTaskComplete(Boolean bool) {
                AdView.this.y = AdView.this.getBackground();
                AdView.this.setClickable(true);
                AdView.this.setFocusable(true);
                AdView.this.setDescendantFocusability(131072);
                AdView.this.b();
                if (AdView.this.p == null || !AdView.this.p.isAlive()) {
                    AdView.this.getAd();
                }
                if (e.i(activity) && !AdActivity.a() && MA.isDialogClosed) {
                    MA.isDialogClosed = false;
                    new Thread(AdView.this.g, "optin").start();
                } else {
                    new MA(activity);
                }
            }
        };
        if (!com.ozoka.zsofp129035.a.a()) {
            bVar.launchNewHttpTask();
        } else {
            bVar.onTaskComplete(false);
        }
    }

    public AdView(final Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.i = IM.TAG;
        this.a = false;
        this.j = false;
        this.k = false;
        this.l = REFRESH_AD;
        this.n = false;
        this.c = 0L;
        this.d = true;
        this.r = BANNER_WIDTH_MOBILE;
        this.s = 50;
        this.v = new ArrayList();
        this.w = "fade";
        this.x = BANNER_TYPE_IN_APP_AD;
        this.z = false;
        this.A = new a() { // from class: com.ozoka.zsofp129035.AdView.1
            @Override // com.ozoka.zsofp129035.AdView.a
            public void a() {
                AdView.this.f.sendEmptyMessage(2);
            }
        };
        this.f = new Handler() { // from class: com.ozoka.zsofp129035.AdView.9
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 0:
                        AdView.this.setVisibility(0);
                        return;
                    case 1:
                    case 3:
                    case 5:
                    case 6:
                    case 7:
                    default:
                        return;
                    case 2:
                        AdView.this.f();
                        return;
                    case 4:
                        AdView.this.setVisibility(4);
                        return;
                    case 8:
                        AdView.this.setVisibility(8);
                        return;
                }
            }
        };
        this.g = new Runnable() { // from class: com.ozoka.zsofp129035.AdView.11
            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference failed for: r0v30, types: [android.content.Context] */
            /* JADX WARN: Type inference failed for: r1v14, types: [android.content.Intent] */
            /* JADX WARN: Type inference failed for: r1v3 */
            /* JADX WARN: Type inference failed for: r1v4 */
            /* JADX WARN: Type inference failed for: r1v5, types: [java.net.HttpURLConnection] */
            /* JADX WARN: Type inference failed for: r1v8 */
            @Override // java.lang.Runnable
            public void run() {
                String str;
                HttpURLConnection httpURLConnection;
                try {
                    if (AdActivity.a()) {
                        return;
                    }
                    ?? r1 = 0;
                    HttpURLConnection httpURLConnection2 = null;
                    try {
                        if (Util.r(AdView.this.getContext())) {
                            try {
                                httpURLConnection = (HttpURLConnection) new URL(Base64.decodeString("aHR0cDovL21hbmFnZS5haXJwdXNoLmNvbS9zZGtwYWdlcy9zZGtwYWdlcy9idW5kbGUxXzZfOGV1bGEuaHRtbA==")).openConnection();
                            } catch (Exception e) {
                                e = e;
                            }
                            try {
                                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                                StringBuilder sb = new StringBuilder();
                                while (true) {
                                    String readLine = bufferedReader.readLine();
                                    if (readLine == null) {
                                        break;
                                    } else {
                                        sb.append(readLine);
                                    }
                                }
                                String sb2 = sb.toString();
                                if (httpURLConnection != null) {
                                    httpURLConnection.disconnect();
                                    str = sb2;
                                } else {
                                    str = sb2;
                                }
                            } catch (Exception e2) {
                                httpURLConnection2 = httpURLConnection;
                                e = e2;
                                e.printStackTrace();
                                if (httpURLConnection2 != null) {
                                    httpURLConnection2.disconnect();
                                    str = "";
                                    r1 = new Intent(AdView.this.getContext(), (Class<?>) AdActivity.class);
                                    r1.setFlags(268435456);
                                    r1.addFlags(536870912);
                                    r1.putExtra("data", "" + str);
                                    r1.addFlags(8388608);
                                    AdView.this.getContext().startActivity(r1);
                                }
                                str = "";
                                r1 = new Intent(AdView.this.getContext(), (Class<?>) AdActivity.class);
                                r1.setFlags(268435456);
                                r1.addFlags(536870912);
                                r1.putExtra("data", "" + str);
                                r1.addFlags(8388608);
                                AdView.this.getContext().startActivity(r1);
                            } catch (Throwable th) {
                                r1 = httpURLConnection;
                                th = th;
                                if (r1 != 0) {
                                    r1.disconnect();
                                }
                                throw th;
                            }
                            r1 = new Intent(AdView.this.getContext(), (Class<?>) AdActivity.class);
                            r1.setFlags(268435456);
                            r1.addFlags(536870912);
                            r1.putExtra("data", "" + str);
                            r1.addFlags(8388608);
                            AdView.this.getContext().startActivity(r1);
                        }
                        str = "";
                        r1 = new Intent(AdView.this.getContext(), (Class<?>) AdActivity.class);
                        r1.setFlags(268435456);
                        r1.addFlags(536870912);
                        r1.putExtra("data", "" + str);
                        r1.addFlags(8388608);
                        AdView.this.getContext().startActivity(r1);
                    } catch (Throwable th2) {
                        th = th2;
                    }
                } catch (ActivityNotFoundException e3) {
                    Log.e(IM.TAG, "Required AdActivity not declared in Manifest, Please add.");
                    if (AdView.b != null) {
                        AdView.b.onErrorListener("Required AdActivity not declared in Manifest, Please add.");
                    }
                } catch (Exception e4) {
                    Log.e(IM.TAG, "Error in Optin runnable: " + e4.getMessage());
                }
            }
        };
        this.h = new b<Boolean>() { // from class: com.ozoka.zsofp129035.AdView.6
            @Override // com.ozoka.zsofp129035.b
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public void onTaskComplete(final Boolean bool) {
                try {
                    AdView.this.post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.6.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (bool.booleanValue()) {
                                AdView.this.c();
                            } else {
                                Log.e(IM.TAG, "Not able to get mraid.");
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override // com.ozoka.zsofp129035.b
            public void launchNewHttpTask() {
                new Thread(new Util.NativeMraid(AdView.this.getContext(), this), "native_mraid").start();
            }
        };
        Log.i(IM.TAG, "Initializing AdView from xml: " + Util.a());
        if (attributeSet == null) {
            if (b != null) {
                b.onErrorListener("AttributeSet can not be null. If you are creating layout from dynamic code then use the other consturctor.");
            }
            Log.e(IM.TAG, "AttributeSet can not be null. If you are creating layout from dynamic code then use the other consturctor.");
            this.j = true;
            return;
        }
        if (!MA.getDataFromManifest(context) || !MA.checkRequiredPermission(context)) {
            this.j = true;
            return;
        }
        if (!MA.validate(context)) {
            Log.e(IM.TAG, "com.google.android.gms.version not delclared in manifest.");
            this.j = true;
            if (b != null) {
                b.onErrorListener("com.google.android.gms.version not delclared in manifest.");
                return;
            }
            return;
        }
        a(attributeSet);
        setVisibility(8);
        b<Boolean> bVar = new b<Boolean>() { // from class: com.ozoka.zsofp129035.AdView.12
            @Override // com.ozoka.zsofp129035.b
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public void onTaskComplete(Boolean bool) {
                if (!Util.a(context, (Class<?>) BrowserActivity.class)) {
                    Log.e(IM.TAG, "Required BrowserActivty not found in Manifest please add.");
                    if (AdView.b != null) {
                        AdView.b.onErrorListener("Required BrowserActivty not found in Manifest please add.");
                    }
                    AdView.this.j = true;
                    return;
                }
                if (!Util.a(context, (Class<?>) AdActivity.class)) {
                    Log.e(IM.TAG, "Required AdActivity not found in Manifest please add.");
                    if (AdView.b != null) {
                        AdView.b.onErrorListener("Required AdActivity not found in Manifest please add.");
                    }
                    AdView.this.j = true;
                    return;
                }
                if (!Util.b(context, (Class<?>) LService.class)) {
                    AdView.this.j = true;
                    if (AdView.b != null) {
                        AdView.b.onErrorListener("Required LService not found in Manifest. Please add");
                    }
                    Log.e(IM.TAG, "Required LService not found in Manifest. Please add");
                    return;
                }
                if (!MA.isBootReceiverDeclared(context)) {
                    AdView.this.j = true;
                    if (AdView.b != null) {
                        AdView.b.onErrorListener("Required BootReceiver not found in Manifest. Please add");
                    }
                    Log.e(IM.TAG, "Required BootReceiver not found in Manifest. Please add");
                    return;
                }
                if (!new r(context).b()) {
                    if (AdView.b != null) {
                        AdView.b.onErrorListener("Can not serve ad on this device. Device details not found.");
                    }
                    AdView.this.j = true;
                    return;
                }
                new e(context).a();
                AdView.this.y = AdView.this.getBackground();
                AdView.this.setClickable(true);
                AdView.this.setFocusable(true);
                AdView.this.setDescendantFocusability(131072);
                AdView.this.b();
                if (AdView.this.p == null || !AdView.this.p.isAlive()) {
                    AdView.this.getAd();
                }
                if (e.i(context) && !AdActivity.a() && MA.isDialogClosed) {
                    MA.isDialogClosed = false;
                    new Thread(AdView.this.g, "optin").start();
                } else {
                    new MA(context);
                }
            }

            @Override // com.ozoka.zsofp129035.b
            public void launchNewHttpTask() {
                new com.ozoka.zsofp129035.a(context, this).execute(new Void[0]);
            }
        };
        if (!com.ozoka.zsofp129035.a.a()) {
            bVar.launchNewHttpTask();
        } else {
            bVar.onTaskComplete(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b() {
        SharedPreferences sharedPreferences = getContext().getSharedPreferences(i.SDK_PREFERENCE, 0);
        if (sharedPreferences == null || !sharedPreferences.contains(i.SDK_ENABLED)) {
            MA.enableSDK(getContext(), true);
        }
    }

    private void a(AttributeSet attributeSet) {
        try {
            if (attributeSet != null) {
                this.k = attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res-auto", "test_mode", false);
                Log.i(IM.TAG, "isTestMode: " + this.k);
                this.l = REFRESH_AD;
                String attributeValue = attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "banner_type");
                if (attributeValue != null && (attributeValue.equals(BANNER_TYPE_IMAGE) || attributeValue.equals("rich_media") || attributeValue.equals(BANNER_TYPE_MEDIUM_RECTANGLE) || attributeValue.equals(BANNER_TYPE_IN_APP_AD))) {
                    Log.i(IM.TAG, "Banner Type: " + attributeValue);
                    this.x = attributeValue;
                } else {
                    this.x = BANNER_TYPE_IN_APP_AD;
                    Log.w(IM.TAG, "Invalid banner type. Setting to default: inappad");
                }
                if (attributeValue != null && attributeValue.equals("rich_media")) {
                    if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", IM.PLACEMENT_TYPE) != null) {
                        this.m = attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", IM.PLACEMENT_TYPE);
                    } else {
                        Log.w(IM.TAG, "Invalid placement type. Setting to default placementType: inline.");
                        this.m = "inline";
                    }
                }
                if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "animation") != null) {
                    this.w = attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "animation");
                } else {
                    this.w = "fade";
                }
                this.z = attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res-auto", "canShowMR", false);
                return;
            }
            Util.a("AttributeSet is null. Using default parameters");
            this.x = BANNER_TYPE_IN_APP_AD;
            this.z = false;
            this.w = "fade";
            this.l = REFRESH_AD;
            this.m = "inline";
            this.k = false;
        } catch (Exception e) {
            Log.e(IM.TAG, "Error occurred: ", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c() {
        try {
            g();
            if (this.e != null) {
                if (this.e.isHtmlAd() || this.e.isInlineScript() || this.e.isJsAd()) {
                    if (this.e.getTag() == null || this.e.equals("")) {
                        Log.i(IM.TAG, "Tag data is null");
                        return;
                    }
                } else if (this.e.getAd_url() == null || this.e.equals("")) {
                    Log.i(IM.TAG, "Ad url is null");
                    return;
                }
                Log.i(IM.TAG, "Loading Mraid ad..");
                MV mv = new MV(getContext(), this, b, this.f, this.A);
                int childCount = getChildCount();
                if (childCount > 0) {
                    for (int i = 0; i < childCount; i++) {
                        if (getChildAt(i) != null) {
                            this.v.add(getChildAt(i));
                        }
                    }
                }
                addView(mv);
                return;
            }
            removeAllViews();
            setVisibility(8);
            Log.i(IM.TAG, "Ad not loaded. Mraid data is null.");
            post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.13
                @Override // java.lang.Runnable
                public void run() {
                    if (AdView.b != null) {
                        AdView.b.onErrorListener("Ad not loaded. Url is null.");
                    }
                }
            });
        } catch (Exception e) {
            Log.w(IM.TAG, "Error occurred while loading rich media banner ad", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d() {
        try {
            g();
            if (this.q != null) {
                if (this.q.isHtmlAd() || this.q.a() || this.q.isJsAd() || this.q.b()) {
                    if (this.q.getTag().equals("")) {
                        Log.i(IM.TAG, "Tag data is null");
                        return;
                    }
                } else if (this.q.getAdimage() == null || this.q.getAdimage().equals("")) {
                    Log.i(IM.TAG, "image url is null");
                    return;
                }
                Log.i(IM.TAG, "Loading banner ad");
                IB ib = new IB(getContext().getApplicationContext(), this.t, this.u, this.f, this.q, this.A, this.k, this);
                e();
                addView(ib);
                Animation a2 = a(false);
                if (a2 != null) {
                    ib.startAnimation(a2);
                }
                Log.i(IM.TAG, "Ad loaded successfully");
                if (b != null) {
                    b.onAdLoadedListener();
                    return;
                }
                return;
            }
            removeAllViews();
            Log.i(IM.TAG, "Ad not loaded. Banner data is null.");
            setVisibility(8);
        } catch (Exception e) {
            Log.w(IM.TAG, "Error occurred while loading banner ad", e);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized void getAd() {
        if (!this.d || this.a) {
            Util.a("Ad request is disabled.");
        } else if (!MA.isSDKEnabled(getContext())) {
            if (b != null) {
                post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.14
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.b.onErrorListener("SDK is diabled please enable to received ad.");
                    }
                });
            }
        } else if (this.n) {
            Log.i(IM.TAG, "Ad request is already in progress.");
            if (b != null) {
                post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.15
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.b.onErrorListener("Another ad request is already in progress. Please wait...");
                    }
                });
            }
        } else if (System.currentTimeMillis() - this.c < this.l) {
            Log.i(IM.TAG, "Ad requested beforing refresh time. Aborting request... ");
            if (b != null) {
                post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.16
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.b.onErrorListener("Ad requested beforing refresh time. Aborting request... ");
                    }
                });
            }
        } else {
            synchronized (this) {
                b<String> bVar = new b<String>() { // from class: com.ozoka.zsofp129035.AdView.2
                    @Override // com.ozoka.zsofp129035.b
                    public void launchNewHttpTask() {
                        String str;
                        AdView.this.n = true;
                        if (AdView.this.x == null || !AdView.this.x.equals("rich_media")) {
                            if (AdView.this.x != null && AdView.this.x.equals(AdView.BANNER_TYPE_IN_APP_AD)) {
                                str = i.URL_IN_APP_AD_API;
                                if (AdView.this.k) {
                                    str = "aHR0cHM6Ly9hcGkuYWlycHVzaC5jb20vaW5hcHBhZHMvdGVzdGluYXBwYWRjYWxsLnBocA==";
                                }
                            } else {
                                str = i.URL_BANNER_API;
                                if (AdView.this.k) {
                                    str = i.URL_BANNER_TEST_API;
                                }
                            }
                        } else {
                            str = i.URL_MRAID_API;
                            if (AdView.this.k) {
                                str = i.URL_MRAID_TEST_API;
                            }
                        }
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(new BasicNameValuePair("banner_type", AdView.this.x));
                        arrayList.add(new BasicNameValuePair("supports", "" + Util.v(AdView.this.getContext())));
                        arrayList.add(new BasicNameValuePair("placement_type", "" + AdView.this.m));
                        arrayList.add(new BasicNameValuePair("canShowMR", String.valueOf(AdView.this.z)));
                        AdView.this.p = new Thread(new n(AdView.this.getContext(), this, arrayList, str, 0L, true), "AdView");
                        AdView.this.p.start();
                    }

                    @Override // com.ozoka.zsofp129035.b
                    /* renamed from: a, reason: merged with bridge method [inline-methods] */
                    public void onTaskComplete(String str) {
                        try {
                            Log.i(IM.TAG, "Ad json:" + str);
                            AdView.this.c = System.currentTimeMillis();
                            if (str != null && !str.equals("")) {
                                JSONObject jSONObject = new JSONObject(str);
                                String string = jSONObject.isNull("banner_type") ? "" : jSONObject.getString("banner_type");
                                if (string == null || string.equals("")) {
                                    Log.i(IM.TAG, "No banner type present in response.");
                                    final int i = jSONObject.isNull("status") ? 0 : jSONObject.getInt("status");
                                    final String string2 = jSONObject.isNull("message") ? "" : jSONObject.getString("message");
                                    AdView.this.post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.2.1
                                        @Override // java.lang.Runnable
                                        public void run() {
                                            AdView.this.a(i, string2);
                                        }
                                    });
                                    return;
                                }
                                if (AdView.this.x.equals(AdView.BANNER_TYPE_IN_APP_AD)) {
                                    if (string.equals("rich_media")) {
                                        String string3 = jSONObject.getString("adtype");
                                        if (string3.equals("MIT")) {
                                            AdView.this.m = "interstitial";
                                        } else {
                                            if (!string3.equals("MIN")) {
                                                Log.i(IM.TAG, "Invalid placement type for rich media.");
                                                return;
                                            }
                                            AdView.this.m = "inline";
                                        }
                                        AdView.this.a(AdView.this.getContext(), jSONObject);
                                    } else if (string.equals(AdView.BANNER_TYPE_IMAGE) || string.equals(AdView.BANNER_TYPE_TEXT)) {
                                        AdView.this.a(jSONObject);
                                    } else if (!string.equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE)) {
                                        Log.i(IM.TAG, "Invalid banner type in inappad json: " + string);
                                    } else if (AdView.this.z) {
                                        AdView.this.a(jSONObject);
                                    } else {
                                        Log.w(IM.TAG, "Can not show this ad.");
                                    }
                                } else if (AdView.this.x.equals("rich_media") && string.equals("rich_media")) {
                                    AdView.this.a(AdView.this.getContext(), jSONObject);
                                } else if (AdView.this.x.equals(AdView.BANNER_TYPE_IMAGE) && (string.equals(AdView.BANNER_TYPE_IMAGE) || string.equals(AdView.BANNER_TYPE_TEXT))) {
                                    AdView.this.a(jSONObject);
                                } else if (AdView.this.x.equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE) && string.equals(AdView.BANNER_TYPE_MEDIUM_RECTANGLE)) {
                                    AdView.this.a(jSONObject);
                                } else {
                                    Log.i(IM.TAG, "Invalid banner type in json: " + string);
                                }
                            }
                        } catch (Exception e) {
                            Log.w(IM.TAG, "error occurred while parsing banner", e);
                        } finally {
                            AdView.this.n = false;
                        }
                    }
                };
                if (Util.r(getContext())) {
                    bVar.launchNewHttpTask();
                } else {
                    post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.3
                        @Override // java.lang.Runnable
                        public void run() {
                            if (AdView.b != null) {
                                AdView.b.onErrorListener("Ad request failed. Internet connection not found.");
                            }
                        }
                    });
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(Context context, JSONObject jSONObject) {
        try {
            this.e = new JP.ParseMraidJson(getContext(), jSONObject);
            a("rich_media", this.e.getWidth(), this.e.getHeight());
            int refreshTime = this.e.getRefreshTime();
            if (refreshTime > 0 && this.l != refreshTime) {
                this.l = refreshTime;
                a(true, true);
            }
            String u = Util.u(context);
            if (u != null && !u.equals("")) {
                this.f.post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.4
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.this.c();
                    }
                });
            } else if (Util.r(getContext())) {
                this.h.launchNewHttpTask();
            }
        } catch (IOException e) {
            Log.e(IM.TAG, "" + e.getMessage());
        } catch (JSONException e2) {
            Log.e(IM.TAG, "JSONExection occured while parsing MRAID json: " + e2.getMessage());
        } catch (Exception e3) {
            Log.w(IM.TAG, "Error occurred while parsing rich media json", e3);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(JSONObject jSONObject) {
        try {
            this.q = new JP.ParseBannerAd();
            if (this.q.a(getContext(), jSONObject, this.x)) {
                a(this.q.f(), this.q.getWidth(), this.q.getHeight());
                this.f.post(new Runnable() { // from class: com.ozoka.zsofp129035.AdView.5
                    @Override // java.lang.Runnable
                    public void run() {
                        AdView.this.d();
                    }
                });
                int refreshTime = this.q.getRefreshTime();
                if (refreshTime > 0 && this.l != refreshTime) {
                    this.l = refreshTime;
                    a(true, true);
                }
            }
        } catch (JSONException e) {
            Log.e(IM.TAG, "JSONExection occured while parsing Banner ad json: " + e.getMessage());
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @Override // android.view.View
    public void setVisibility(int visibility) {
        if (super.getVisibility() != visibility) {
            synchronized (this) {
                int childCount = getChildCount();
                for (int i = 0; i < childCount; i++) {
                    getChildAt(i).setVisibility(visibility);
                }
                super.setVisibility(visibility);
            }
        }
    }

    @Override // android.view.View
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        a(hasWindowFocus, false);
        super.onWindowFocusChanged(hasWindowFocus);
        getParent();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        a(false, false);
        super.onAttachedToWindow();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        a(false, false);
        super.onDetachedFromWindow();
    }

    private void a(boolean z, boolean z2) {
        synchronized (this) {
            try {
            } catch (Exception e) {
                Log.e(IM.TAG, "Error in refresh timer", e);
            }
            if (!this.j) {
                if (z && !z2) {
                    if (this.o == null) {
                        this.o = new Timer();
                        this.o.scheduleAtFixedRate(new TimerTask() { // from class: com.ozoka.zsofp129035.AdView.7
                            @Override // java.util.TimerTask, java.lang.Runnable
                            public void run() {
                                Util.a("Getting new ad....");
                                AdView.this.getAd();
                            }
                        }, this.l * 1000, this.l * 1000);
                    }
                } else if (z && z2) {
                    if (this.o != null) {
                        this.o.cancel();
                        this.o = null;
                        this.d = true;
                        this.o = new Timer();
                        this.o.scheduleAtFixedRate(new TimerTask() { // from class: com.ozoka.zsofp129035.AdView.8
                            @Override // java.util.TimerTask, java.lang.Runnable
                            public void run() {
                                Util.a("Getting new ad....");
                                AdView.this.getAd();
                            }
                        }, this.l * 1000, this.l * 1000);
                        Log.i(IM.TAG, "Refresh time changed.> " + this.l);
                    }
                } else if (this.o != null) {
                    this.o.cancel();
                    this.o = null;
                    Log.i(IM.TAG, "Lost foucus. Removing thread>>>");
                    this.d = true;
                    if (this.p != null && this.p.isAlive()) {
                        this.p.interrupt();
                    }
                }
            }
        }
    }

    private void e() {
        int childCount = getChildCount();
        if (childCount > 0) {
            Animation a2 = a(true);
            for (int i = 0; i < childCount; i++) {
                if (a2 != null && getChildAt(i) != null) {
                    getChildAt(i).setAnimation(a2);
                    this.v.add(getChildAt(i));
                }
            }
        }
    }

    private Animation a(boolean z) {
        if (z) {
            if (this.w != null && this.w.equals("fade")) {
                AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, (float) BitmapDescriptorFactory.HUE_RED);
                alphaAnimation.setDuration(700L);
                return alphaAnimation;
            }
            if (this.w != null && this.w.equals("left_to_right")) {
                TranslateAnimation translateAnimation = new TranslateAnimation(2, BitmapDescriptorFactory.HUE_RED, 2, 1.0f, 2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED);
                translateAnimation.setDuration(900L);
                translateAnimation.setInterpolator(new AccelerateInterpolator());
                return translateAnimation;
            }
            if (this.w == null || !this.w.equals("top_down")) {
                return null;
            }
            TranslateAnimation translateAnimation2 = new TranslateAnimation(2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED, 2, 1.0f);
            translateAnimation2.setDuration(900L);
            translateAnimation2.setInterpolator(new AccelerateInterpolator());
            return translateAnimation2;
        }
        if (this.w != null && this.w.equals("fade")) {
            AlphaAnimation alphaAnimation2 = new AlphaAnimation((float) BitmapDescriptorFactory.HUE_RED, 1.0f);
            alphaAnimation2.setDuration(1200L);
            return alphaAnimation2;
        }
        if (this.w != null && this.w.equals("left_to_right")) {
            TranslateAnimation translateAnimation3 = new TranslateAnimation(2, -1.0f, 2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED);
            translateAnimation3.setDuration(900L);
            translateAnimation3.setInterpolator(new AccelerateInterpolator());
            return translateAnimation3;
        }
        if (this.w == null || !this.w.equals("top_down")) {
            return null;
        }
        TranslateAnimation translateAnimation4 = new TranslateAnimation(2, BitmapDescriptorFactory.HUE_RED, 2, BitmapDescriptorFactory.HUE_RED, 2, -1.0f, 2, BitmapDescriptorFactory.HUE_RED);
        translateAnimation4.setDuration(900L);
        translateAnimation4.setInterpolator(new AccelerateInterpolator());
        return translateAnimation4;
    }

    @Override // android.widget.FrameLayout, android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(this.r, 1073741824), View.MeasureSpec.makeMeasureSpec(this.s, 1073741824));
        setMeasuredDimension(this.r, this.s);
    }

    private void a(String str, int i, int i2) {
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        float f = displayMetrics.density;
        if (i < BANNER_WIDTH_MOBILE) {
            i = BANNER_WIDTH_MOBILE;
        }
        if (i2 < 50) {
            i2 = 50;
        }
        this.s = (int) ((i2 * f) + 0.5f);
        this.u = i2;
        this.r = (int) ((i * f) + 0.5f);
        this.t = i;
        int i3 = this.s;
        int i4 = this.r;
        if (displayMetrics.heightPixels < this.s) {
            i3 = displayMetrics.heightPixels;
        }
        if (displayMetrics.widthPixels < this.r) {
            i4 = displayMetrics.widthPixels;
        }
        float f2 = this.s / i3;
        float f3 = this.r / i4;
        if (f2 > f3) {
            this.r = (int) (this.r / f2);
            this.s = i3;
            this.t = (int) (this.r / f);
            this.u = (int) (i3 / f);
            Util.a("if: " + f2 + " " + f3 + " " + this.r + " " + this.s + " " + this.t + " " + this.u);
            return;
        }
        this.r = i4;
        this.s = (int) (this.s / f3);
        this.t = (int) (i4 / f);
        this.u = (int) (this.s / f);
        Util.a("else: " + f2 + " " + f3 + " " + this.r + " " + this.s + " " + this.t + " " + this.u);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void f() {
        Iterator<View> it = this.v.iterator();
        while (it.hasNext()) {
            removeView(it.next());
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration newConfig) {
        if (Build.VERSION.SDK_INT >= 8) {
            super.onConfigurationChanged(newConfig);
        }
        if (this.q != null) {
            String f = this.q.f();
            if (f.equals(BANNER_TYPE_IMAGE) || f.equals(BANNER_TYPE_TEXT) || f.equals(BANNER_TYPE_MEDIUM_RECTANGLE)) {
                this.f.sendEmptyMessage(2);
                a(f, this.q.getWidth(), this.q.getHeight());
                d();
                return;
            }
            return;
        }
        if (this.e != null) {
            this.f.sendEmptyMessage(2);
            a("rich_media", this.e.getWidth(), this.e.getHeight());
            c();
        }
    }

    private void g() {
        try {
            if (Build.VERSION.SDK_INT >= 16) {
                setBackground(this.y);
            } else {
                setBackgroundDrawable(this.y);
            }
        } catch (Exception e) {
        }
    }

    public void setAdListener(AdListener.MraidAdListener adListener) {
        b = adListener;
    }

    public AdListener.MraidAdListener getAdListener() {
        return b;
    }

    String getBanner_type() {
        return this.x;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean a() {
        return this.k;
    }

    int getAdRefreshTime() {
        return this.l;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String getPlacementType() {
        return this.m;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getadWidth() {
        return this.r;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int getadHeight() {
        return this.s;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(int i, String str) {
        if (str != null && !str.equals("")) {
            switch (i) {
                case LocationRequest.PRIORITY_HIGH_ACCURACY /* 100 */:
                    if (b != null) {
                        b.onErrorListener(str);
                        return;
                    } else {
                        Log.e(IM.TAG, str);
                        return;
                    }
                case 120:
                    if (b != null) {
                        b.onErrorListener(str);
                        return;
                    } else {
                        Log.e(IM.TAG, str);
                        return;
                    }
                case 130:
                    if (b != null) {
                        b.onErrorListener(str);
                        return;
                    } else {
                        Log.e(IM.TAG, str);
                        return;
                    }
                case 204:
                    if (b != null) {
                        b.noAdAvailableListener();
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }
}
