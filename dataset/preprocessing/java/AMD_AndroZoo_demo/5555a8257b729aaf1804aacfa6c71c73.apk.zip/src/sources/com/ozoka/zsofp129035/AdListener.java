package com.ozoka.zsofp129035;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
public interface AdListener {

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
    public enum AdType {
        smartwall,
        overlay,
        video,
        appwall,
        landing_page,
        interstitial
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
    public interface MraidAdListener {
        void noAdAvailableListener();

        void onAdClickListener();

        void onAdExpandedListner();

        void onAdLoadedListener();

        void onAdLoadingListener();

        void onCloseListener();

        void onErrorListener(String str);
    }

    /* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
    public interface OptinListener {
        void optinResult(boolean z);

        void showingDialog();
    }

    void noAdAvailableListener();

    void onAdCached(AdType adType);

    void onAdError(String str);

    void onSDKIntegrationError(String str);

    void onSmartWallAdClosed();

    void onSmartWallAdShowing();
}
