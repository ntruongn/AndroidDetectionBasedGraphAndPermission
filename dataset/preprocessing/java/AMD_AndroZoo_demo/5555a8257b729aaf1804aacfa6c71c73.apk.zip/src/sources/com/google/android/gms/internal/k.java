package com.google.android.gms.internal;

import java.io.IOException;

/* loaded from: /mnt/c/Users/truon/OneDrive/Desktop/MyWorks/Research4IECgroup/Tasks/Graph-Attention-Networks/dataset/preprocessing/apk_tool/AMD_AndroZoo_demo/dex/5555a8257b729aaf1804aacfa6c71c73.apk/classes.dex */
interface k {
    void b(int i, long j) throws IOException;

    void b(int i, String str) throws IOException;

    byte[] h() throws IOException;

    void reset();
}
